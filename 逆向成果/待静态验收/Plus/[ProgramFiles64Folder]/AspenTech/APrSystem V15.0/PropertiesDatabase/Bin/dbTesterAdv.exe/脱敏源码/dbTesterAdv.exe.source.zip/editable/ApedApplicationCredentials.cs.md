# ApedApplicationCredentials.cs

Reads APED application credentials from authorized runtime configuration.
