using System;

internal static class ApedApplicationCredentials
{
    internal static string AspenPlus => ReadRequired("ASPEN_APED_ASPEN_PLUS_PASSWORD");
    internal static string DataManager => ReadRequired("ASPEN_APED_DATA_MANAGER_PASSWORD");

    private static string ReadRequired(string variable)
    {
        string value = Environment.GetEnvironmentVariable(variable);
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new InvalidOperationException("Set the authorized APED application credential in " + variable + ".");
        }

        return value;
    }
}
