using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Threading;
using System.Windows.Forms;
using AspenTech.APED;
using AspenTech.APED.AspenProperties;
using AspenTech.APED.Controls;
using Interop.SECSERVEROBJECTLib;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("AspenTech")]
[assembly: AssemblyProduct("Aspen Properties Enterprise Database V15")]
[assembly: AssemblyCopyright("Copyright © 2025 Aspen Technology, Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("41.0.0.11")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("..\\..\\..\\..\\aped.snk")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyTitle("dbRestore")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.1")]
namespace dbRestore
{
	public class dbRestoreControl : UserControl
	{
		private Rectangle m_initBounds;

		private Rectangle m_prevBounds;

		private string myLevel = "level1";

		private SortedList m_parentControls = new SortedList();

		private IContainer components;

		private Hashtable modelManagerDBMsgHT = new Hashtable();

		private TextBox currentlyTestingTextBox;

		private Label currentlyTestingLabel;

		private Label statusLabel;

		private Button okButton;

		private Label configFileLabel;

		private DataGridView dataGridView2;

		private DataGridViewTextBoxColumn ServerColumn1;

		private DataGridViewTextBoxColumn DatabaseColumn;

		private DataGridViewTextBoxColumn DatabaseConnectionStatusColumn;

		private DataGridViewTextBoxColumn AspenPlusAccessColumn;

		private DataGridViewTextBoxColumn DataManagerAccessColumn;

		private DataGridView dataGridView1;

		private DataGridViewTextBoxColumn ServerColumn;

		private DataGridViewTextBoxColumn AuthenticationColumn;

		private DataGridViewTextBoxColumn StatusColumn;

		private Label label1;

		private Label label2;

		private Button helpButton;

		private Label label3;

		private Label label4;

		private Button buttonRestore;

		private int myInput;

		private string myConfigfilepath = string.Empty;

		public dbRestoreControl()
		{
			InitializeComponent();
			m_initBounds = base.Bounds;
			m_prevBounds = m_initBounds;
			if (base.Controls != null && base.Controls.Count > 0)
			{
				IParentControl parentControl = new ParentControl(this, 1, myLevel);
				m_parentControls.Add(parentControl.Name, parentControl);
			}
		}

		private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
		}

		public void OnResize(object sender, EventArgs e)
		{
			Rectangle bounds = base.Bounds;
			if (bounds.Height != m_prevBounds.Height || bounds.Width != m_prevBounds.Width)
			{
				if (bounds.Height < m_initBounds.Height)
				{
					SetBounds(base.Bounds.Left, base.Bounds.Top, base.Bounds.Width, m_initBounds.Height, BoundsSpecified.Height);
				}
				if (bounds.Width < m_initBounds.Width)
				{
					SetBounds(base.Bounds.Left, base.Bounds.Top, m_initBounds.Width, base.Bounds.Height, BoundsSpecified.Width);
				}
				m_prevBounds = base.Bounds;
				if (m_parentControls != null && m_parentControls.Count > 0)
				{
					foreach (IParentControl value in m_parentControls.Values)
					{
						if (value != null && value.Level == 1)
						{
							ApedGlobal.ResizeControls(this, base.Controls, value.ControlIndexs, value.ControlBounds, value.ControlLefts, value.ControlWidths, value.ControlRights, value.ControlTops, value.ControlHeights, value.ControlBottoms);
						}
					}
				}
				SetColumnWidths();
				Refresh();
			}
		}

		private void SetColumnWidths()
		{
			int num = (dataGridView1.Width - ServerColumn.Width) / 2;
			AuthenticationColumn.Width = num;
			StatusColumn.Width = num;
		}

		private void helpButton_Click(object sender, EventArgs e)
		{
			ApedApplication.APEDHtmlHelpDisplay(GlobalControl.HelpFile + "#html/Database_Configuration_Tester.htm");
		}

		public void SetLocalDBButton(int input, string configfilepath)
		{
			myInput = input;
			myConfigfilepath = configfilepath;
			buttonRestore.Visible = false;
			helpButton.Visible = false;
			okButton.Visible = false;
			StartRestore();
		}

		[DllImport("ApedIntegration.dll", CharSet = CharSet.Auto)]
		public static extern bool InitializeFromConfigFile([MarshalAs(UnmanagedType.LPStr)] string configFileName, [MarshalAs(UnmanagedType.LPStr)] string appPwd);

		[DllImport("ApedIntegration.dll", CharSet = CharSet.Auto)]
		public static extern void ListApedDatabanks([MarshalAs(UnmanagedType.FunctionPtr)] CallBackAddDatabankInfo cbadi, [MarshalAs(UnmanagedType.FunctionPtr)] CallbackAddPureParameterInfo cbappi, [MarshalAs(UnmanagedType.FunctionPtr)] CallBackAddBinaryParameterInfo cbabpi);

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.currentlyTestingTextBox = new System.Windows.Forms.TextBox();
			this.currentlyTestingLabel = new System.Windows.Forms.Label();
			this.statusLabel = new System.Windows.Forms.Label();
			this.okButton = new System.Windows.Forms.Button();
			this.configFileLabel = new System.Windows.Forms.Label();
			this.dataGridView2 = new System.Windows.Forms.DataGridView();
			this.ServerColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DatabaseColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DatabaseConnectionStatusColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AspenPlusAccessColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DataManagerAccessColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.ServerColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.AuthenticationColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.StatusColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.helpButton = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.buttonRestore = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)this.dataGridView2).BeginInit();
			((System.ComponentModel.ISupportInitialize)this.dataGridView1).BeginInit();
			base.SuspendLayout();
			this.currentlyTestingTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.currentlyTestingTextBox.Location = new System.Drawing.Point(29, 38);
			this.currentlyTestingTextBox.Name = "currentlyTestingTextBox";
			this.currentlyTestingTextBox.Size = new System.Drawing.Size(431, 20);
			this.currentlyTestingTextBox.TabIndex = 0;
			this.currentlyTestingLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.currentlyTestingLabel.AutoSize = true;
			this.currentlyTestingLabel.Location = new System.Drawing.Point(26, 22);
			this.currentlyTestingLabel.Name = "currentlyTestingLabel";
			this.currentlyTestingLabel.Size = new System.Drawing.Size(86, 13);
			this.currentlyTestingLabel.TabIndex = 1;
			this.currentlyTestingLabel.Text = "Currently Testing";
			this.statusLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.statusLabel.AutoSize = true;
			this.statusLabel.Location = new System.Drawing.Point(26, 66);
			this.statusLabel.Name = "statusLabel";
			this.statusLabel.Size = new System.Drawing.Size(94, 13);
			this.statusLabel.TabIndex = 2;
			this.statusLabel.Text = "Status Messages :";
			this.okButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.okButton.Location = new System.Drawing.Point(272, 483);
			this.okButton.Name = "okButton";
			this.okButton.Size = new System.Drawing.Size(62, 23);
			this.okButton.TabIndex = 3;
			this.okButton.Text = "OK";
			this.okButton.UseVisualStyleBackColor = true;
			this.okButton.Click += new System.EventHandler(okButton_Click);
			this.configFileLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.configFileLabel.AutoSize = true;
			this.configFileLabel.Location = new System.Drawing.Point(26, 92);
			this.configFileLabel.Name = "configFileLabel";
			this.configFileLabel.Size = new System.Drawing.Size(106, 13);
			this.configFileLabel.TabIndex = 5;
			this.configFileLabel.Text = "1. Configuration File :";
			this.dataGridView2.AllowUserToAddRows = false;
			this.dataGridView2.AllowUserToDeleteRows = false;
			this.dataGridView2.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView2.Columns.AddRange(this.ServerColumn1, this.DatabaseColumn, this.DatabaseConnectionStatusColumn, this.AspenPlusAccessColumn, this.DataManagerAccessColumn);
			this.dataGridView2.Location = new System.Drawing.Point(41, 314);
			this.dataGridView2.Name = "dataGridView2";
			this.dataGridView2.ReadOnly = true;
			this.dataGridView2.Size = new System.Drawing.Size(401, 121);
			this.dataGridView2.TabIndex = 6;
			this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView2_CellContentClick);
			this.ServerColumn1.Frozen = true;
			this.ServerColumn1.HeaderText = "Server";
			this.ServerColumn1.Name = "ServerColumn1";
			this.ServerColumn1.ReadOnly = true;
			this.DatabaseColumn.Frozen = true;
			this.DatabaseColumn.HeaderText = "Database";
			this.DatabaseColumn.Name = "DatabaseColumn";
			this.DatabaseColumn.ReadOnly = true;
			this.DatabaseColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.DatabaseColumn.Width = 75;
			this.DatabaseConnectionStatusColumn.HeaderText = "Database Connection Status";
			this.DatabaseConnectionStatusColumn.Name = "DatabaseConnectionStatusColumn";
			this.DatabaseConnectionStatusColumn.ReadOnly = true;
			this.DatabaseConnectionStatusColumn.Width = 175;
			this.AspenPlusAccessColumn.HeaderText = "Aspen Properties Permission / Access Test";
			this.AspenPlusAccessColumn.Name = "AspenPlusAccessColumn";
			this.AspenPlusAccessColumn.ReadOnly = true;
			this.AspenPlusAccessColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.AspenPlusAccessColumn.Width = 250;
			this.DataManagerAccessColumn.HeaderText = "Data Manager Permission / Access Test";
			this.DataManagerAccessColumn.Name = "DataManagerAccessColumn";
			this.DataManagerAccessColumn.ReadOnly = true;
			this.DataManagerAccessColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.DataManagerAccessColumn.Width = 225;
			this.dataGridView1.AllowUserToAddRows = false;
			this.dataGridView1.AllowUserToDeleteRows = false;
			this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(this.ServerColumn, this.AuthenticationColumn, this.StatusColumn);
			this.dataGridView1.Location = new System.Drawing.Point(41, 161);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.ReadOnly = true;
			this.dataGridView1.Size = new System.Drawing.Size(401, 121);
			this.dataGridView1.TabIndex = 7;
			this.ServerColumn.Frozen = true;
			this.ServerColumn.HeaderText = "Server";
			this.ServerColumn.Name = "ServerColumn";
			this.ServerColumn.ReadOnly = true;
			this.ServerColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.ServerColumn.Width = 75;
			this.AuthenticationColumn.HeaderText = "Authentication Mode";
			this.AuthenticationColumn.Name = "AuthenticationColumn";
			this.AuthenticationColumn.ReadOnly = true;
			this.AuthenticationColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.AuthenticationColumn.Width = 150;
			this.StatusColumn.HeaderText = "Status";
			this.StatusColumn.Name = "StatusColumn";
			this.StatusColumn.ReadOnly = true;
			this.StatusColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
			this.StatusColumn.Width = 125;
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(26, 140);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(194, 13);
			this.label1.TabIndex = 8;
			this.label1.Text = "3. SQL Engine Authentication Settings :";
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(26, 294);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(150, 13);
			this.label2.TabIndex = 9;
			this.label2.Text = "4. Database Access Settings :";
			this.helpButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.helpButton.Location = new System.Drawing.Point(367, 483);
			this.helpButton.Name = "helpButton";
			this.helpButton.Size = new System.Drawing.Size(75, 23);
			this.helpButton.TabIndex = 10;
			this.helpButton.Text = "Help";
			this.helpButton.UseVisualStyleBackColor = true;
			this.helpButton.Click += new System.EventHandler(helpButton_Click);
			this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(26, 116);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(173, 13);
			this.label3.TabIndex = 11;
			this.label3.Text = "2. User Authentication Preference :";
			this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(233, 116);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(35, 13);
			this.label4.TabIndex = 12;
			this.label4.Text = "label4";
			this.label4.Visible = false;
			this.buttonRestore.Location = new System.Drawing.Point(41, 451);
			this.buttonRestore.Name = "buttonRestore";
			this.buttonRestore.Size = new System.Drawing.Size(146, 23);
			this.buttonRestore.TabIndex = 13;
			this.buttonRestore.Text = "Restore databases directly";
			this.buttonRestore.UseVisualStyleBackColor = true;
			this.buttonRestore.Click += new System.EventHandler(buttonRestore_Click);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.Controls.Add(this.buttonRestore);
			base.Controls.Add(this.label4);
			base.Controls.Add(this.label3);
			base.Controls.Add(this.helpButton);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.dataGridView2);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.dataGridView1);
			base.Controls.Add(this.configFileLabel);
			base.Controls.Add(this.okButton);
			base.Controls.Add(this.statusLabel);
			base.Controls.Add(this.currentlyTestingLabel);
			base.Controls.Add(this.currentlyTestingTextBox);
			base.Name = "dbRestoreControl";
			base.Size = new System.Drawing.Size(500, 518);
			base.Load += new System.EventHandler(dbRestoreControl_Load);
			base.Resize += new System.EventHandler(OnResize);
			((System.ComponentModel.ISupportInitialize)this.dataGridView2).EndInit();
			((System.ComponentModel.ISupportInitialize)this.dataGridView1).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		public int callbackFnAddDatabankInfo(string dbankName, string dbaseName, string dbankPassword, string dbankDisplayNameMM, string baseDbank, string helpFileName, int helpCode, string layeredProducts, string pureDbankType, string prompt, int iHasPureParams, int iHasBinaryParams, int iHasReactionData)
		{
			string databaseName = dbaseName;
			if (!modelManagerDBMsgHT.Contains(databaseName))
			{
				modelManagerDBMsgHT.Add(databaseName, "Successful");
			}
			return 1;
		}

		public int callBackFnAddBinaryParameterInfo(string pDbaseName, string pDbankName, string pParamName, string pGammaModelName, string pVaporModelName)
		{
			return 1;
		}

		public int callbackFnAddPureParameterInfo(string pDbaseName, string pDbankName, string pParamName, int NumberOfElements)
		{
			return 1;
		}

		private bool CheckModelManager()
		{
			bool flag = false;
			try
			{
				string appPwd = global::ApedApplicationCredentials.AspenPlus;
				InitializeFromConfigFile(null, appPwd);
				CallBackAddDatabankInfo callBackAddDatabankInfo = callbackFnAddDatabankInfo;
				GCHandle gCHandle = GCHandle.Alloc(callBackAddDatabankInfo);
				ListApedDatabanks(callBackAddDatabankInfo, null, null);
				gCHandle.Free();
				flag = true;
			}
			catch
			{
				flag = false;
			}
			return flag;
		}

		private void ProcessInput(int iCanChange)
		{
			ArrayList arrayList = new ArrayList();
			IDatabaseCollection databaseCollection = new DatabaseCollection();
			IConfigFileInstaller configFileInstaller = new CConfigFileInstaller();
			new Hashtable();
			SortedList sortedList = new SortedList();
			ArrayList arrayList2 = new ArrayList();
			string configfilepath;
			SortedList sortedList2 = new SortedList();
			string text;
			StreamReader streamReader;
			string text2;
			ArrayList ConnStatusMessages;
			ArrayList db_List;
			bool flag;
			string empty;
			try
			{
				if (iCanChange == 1 || iCanChange == 3)
				{
					okButton.Enabled = false;
					configFileInstaller.CreateConfigurationFileDB(ref iCanChange);
					if (iCanChange != 0)
					{
						if (iCanChange >= 3)
						{
							if (iCanChange == 5)
							{
								MessageBox.Show("No backup files are available for restoring.", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							((Form1)base.Parent).Close();
							goto Done;
						}
						text = string.Empty;
						if (iCanChange == 1)
						{
							if (GlobalControl.isWinPC)
							{
								text = "You must run this as administrator to restore Aspen Properties databases.";
							}
							else
							{
								text = "You must have administrative privilege to restore Aspen Properties databases.";
							}
						}
						else if (iCanChange == 2)
						{
							text = "No SQL server instance existed. Install Miscrosoft SQL Server 2012 Express SP3 or later first.";
						}
						MessageBox.Show(text, "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						((Form1)base.Parent).Close();
						goto Done;
					}
					Cursor = Cursors.WaitCursor;
					currentlyTestingTextBox.Text = "Configuration file settings";
					Update();
					configFileLabel.Text = configFileLabel.Text + " " + ApedApplication.ConfigFileCheck(out configfilepath);
					configFileLabel.Visible = true;
					Update();
					if (!File.Exists(configfilepath))
					{
						Cursor = Cursors.Default;
						throw new GatewayException("Configuration file was not found. Database Restore can not proceed further without config.aem file.");
					}
					if (ApedApplication.GetSQLAuthPreference() == 1)
					{
						label4.Text = "Windows authentication";
					}
					else
					{
						label4.Text = "SQL (mixed) authentication";
					}
					label4.Visible = true;
					Update();
					currentlyTestingTextBox.Text = "SQL authentication settings";
					Update();
					streamReader = new StreamReader(new FileStream(configfilepath, FileMode.Open, FileAccess.Read, FileShare.Read));
					text2 = "";
					if (streamReader != null)
					{
						while ((text2 = streamReader.ReadLine()) != null)
						{
							if (text2.ToLowerInvariant().StartsWith("<alias id="))
							{
								int num = text2.IndexOf(">", 0, text2.Length);
								int num2 = text2.IndexOf("<", 1, text2.Length - 1);
								string value = text2.Substring(num + 1, num2 - num - 1);
								arrayList.Add(value);
							}
							if (text2.StartsWith("<dataSource id="))
							{
								int num3 = text2.IndexOf("=", 0, text2.Length);
								int num4 = text2.IndexOf(">", 0, text2.Length);
								int num5 = text2.IndexOf("<", 1, text2.Length - 1);
								if (num5 < 0)
								{
									num5 = text2.Length;
								}
								string key = text2.Substring(num3 + 1, num4 - num3 - 1);
								string text3 = text2.Substring(num4 + 1, num5 - num4 - 1);
								if (text3.Contains("pipe") && text3.Contains("tsql") && text3.Contains("query") && text3.CompareTo(GlobalControl.InstancePipeNname) != 0)
								{
									text3 = GlobalControl.InstancePipeNname;
								}
								arrayList2.Add(text3);
								if (!sortedList.ContainsKey(key))
								{
									sortedList.Add(key, text3);
								}
								if (!sortedList2.Contains(text3))
								{
									sortedList2.Add(text3, text3);
								}
							}
							if (text2.StartsWith("<dataSource href="))
							{
								int num6 = text2.IndexOf("#", 0, text2.Length);
								int num7 = text2.IndexOf("/", 0, text2.Length);
								string text4 = text2.Substring(num6 + 1, num7 - num6 - 1);
								text4 = "\"" + text4;
								string value2 = (string)sortedList[text4];
								arrayList2.Add(value2);
							}
						}
					}
					Hashtable hashtable = CheckSQLAuthentionMode(sortedList2);
					currentlyTestingTextBox.Text = "Database permissions and access settings";
					Update();
					Thread.Sleep(3000);
					ConnStatusMessages = new ArrayList();
					db_List = databaseCollection.InitializeFromConfigurationFileForDBTester(null, out ConnStatusMessages);
					CheckDatabaseAccess(arrayList2, arrayList, db_List, ConnStatusMessages);
					currentlyTestingTextBox.Text = "Finished testing various configuration settings.";
					flag = false;
					empty = string.Empty;
					foreach (DictionaryEntry item in hashtable)
					{
						if ((int)item.Value == -5 || (int)item.Value == 2 || ApedApplication.GetSQLAuthPreference() != 2)
						{
							continue;
						}
						Cursor = Cursors.Default;
						if (!GlobalControl.runAdmin)
						{
							empty = "SQL instance : " + item.Key.ToString() + " was detected to have an incorrect Windows authentication mode.";
							if (GlobalControl.isWinPC)
							{
								empty += " However, you must run as administrator to change the authentication mode to 'SQL Server and Windows'.";
							}
							else
							{
								empty += " However, you must have administrative privilege to change the authentication mode to 'SQL Server and Windows'.";
							}
							MessageBox.Show(empty, "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							((Form1)base.Parent).Close();
						}
						empty = "SQL instance : " + item.Key.ToString() + " was detected to have an incorrect Windows authentication mode. Click OK to change the authentication mode to 'SQL Server and Windows'. Clicking Cancel will not change the authentication mode and Aspen Properties databases will not work. Click Help to learn more about how to change SQL authentication mode yourself.";
						if (MessageBox.Show(empty, "Database Restore", MessageBoxButtons.OKCancel, MessageBoxIcon.Hand) == DialogResult.OK)
						{
							try
							{
								Cursor = Cursors.WaitCursor;
								databaseCollection.ChangeAuthenticationMode(item.Key.ToString());
								flag = true;
								MessageBox.Show("SQL authentication mode has been successfully changed for SQL instance :" + item.Key.ToString() + ".", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							catch (Exception ex)
							{
								Cursor = Cursors.Default;
								MessageBox.Show("An error has occurred while changing SQL authentication mode to 'SQL Server and Windows'.\nClick Help to learn more about how to change SQL authentication mode yourself.\n" + ex.Message, "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
						}
					}
					Cursor = Cursors.Default;
					if (!flag)
					{
						okButton.Text = "OK";
						okButton.Enabled = true;
					}
					else
					{
						RestartTester();
						MessageBox.Show("Please press the Start button again to re-run testing.", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				else
				{
					((Form1)base.Parent).Close();
				}
			Done:;
			}
			catch (Exception ex2)
			{
				MessageBox.Show(ex2.Message, "Database Restore", MessageBoxButtons.OK);
				okButton.Text = "OK";
				okButton.Enabled = true;
			}
		}

		private void StartRestore()
		{
			ArrayList arrayList = new ArrayList();
			IDatabaseCollection databaseCollection = new DatabaseCollection();
			IConfigFileInstaller configFileInstaller = new CConfigFileInstaller();
			new Hashtable();
			SortedList sortedList = new SortedList();
			ArrayList arrayList2 = new ArrayList();
			string configfilepath;
			SortedList sortedList2 = new SortedList();
			int iCanChange = 0;
			bool flag = true;
			string text;
			StreamReader streamReader;
			string text2;
			ArrayList ConnStatusMessages;
			ArrayList db_List;
			string empty;
			_ = string.Empty;
			if (File.Exists(myConfigfilepath))
			{
				try
				{
					File.Delete(myConfigfilepath);
				}
				catch (Exception ex)
				{
					_ = ex.Message;
					flag = false;
				}
			}
			if (!flag)
			{
				MessageBox.Show("config.aem is using by an application and cannot be updated.", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				((Form1)base.Parent).Close();
			}
			try
			{
				configFileInstaller.CreateConfigurationFileDB(ref iCanChange, myInput);
				if (iCanChange != 0)
				{
					if (iCanChange >= 3)
					{
						_ = string.Empty;
						if (iCanChange == 5)
						{
							MessageBox.Show("No backup files are available for restoring.", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						if (iCanChange == 10)
						{
							MessageBox.Show("You do not have permission to restore database.", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						if (iCanChange == 15)
						{
							if (GlobalControl.isWinPC)
							{
								MessageBox.Show("You cannot restore databases because you do not have SqlLocalDB installed.", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
							else
							{
								MessageBox.Show("You cannot restore databases because you do not have SQL server installed.", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							}
						}
						((Form1)base.Parent).Close();
						goto Done;
					}
					else
					{
						text = string.Empty;
						if (iCanChange == 1)
						{
							if (GlobalControl.isWinPC)
							{
								text = "You must run this as administrator to restore Aspen Properties databases.";
							}
							else
							{
								text = "You must have administrative privilege to restore Aspen Properties databases.";
							}
						}
						else if (iCanChange == 2)
						{
							text = "No SQL server instance existed. Install Miscrosoft SQL Server 2012 Express SP3 or later first.";
						}
						MessageBox.Show(text, "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						((Form1)base.Parent).Close();
						goto Done;
					}
				}
				Cursor = Cursors.WaitCursor;
				currentlyTestingTextBox.Text = "Configuration file settings";
				Update();
				configFileLabel.Text = configFileLabel.Text + " " + ApedApplication.ConfigFileCheck(out configfilepath);
				configFileLabel.Visible = true;
				Update();
				if (!File.Exists(configfilepath))
				{
					Cursor = Cursors.Default;
					throw new GatewayException("Configuration file was not found. Database Restore can not proceed further without config.aem file.");
				}
				if (ApedApplication.GetSQLAuthPreference() == 1)
				{
					label4.Text = "Windows authentication";
				}
				else
				{
					label4.Text = "SQL (mixed) authentication";
				}
				label4.Visible = true;
				Update();
				currentlyTestingTextBox.Text = "SQL authentication settings";
				Update();
				streamReader = new StreamReader(new FileStream(configfilepath, FileMode.Open, FileAccess.Read, FileShare.Read));
				text2 = "";
				if (streamReader != null)
				{
					while ((text2 = streamReader.ReadLine()) != null)
					{
						if (text2.ToLowerInvariant().StartsWith("<alias id="))
						{
							int num = text2.IndexOf(">", 0, text2.Length);
							int num2 = text2.IndexOf("<", 1, text2.Length - 1);
							string value = text2.Substring(num + 1, num2 - num - 1);
							arrayList.Add(value);
						}
						if (text2.StartsWith("<dataSource id="))
						{
							int num3 = text2.IndexOf("=", 0, text2.Length);
							int num4 = text2.IndexOf(">", 0, text2.Length);
							int num5 = text2.IndexOf("<", 1, text2.Length - 1);
							if (num5 < 0)
							{
								num5 = text2.Length;
							}
							string key = text2.Substring(num3 + 1, num4 - num3 - 1);
							string text3 = text2.Substring(num4 + 1, num5 - num4 - 1);
							if (text3.Contains("pipe") && text3.Contains("tsql") && text3.Contains("query") && text3.CompareTo(GlobalControl.InstancePipeNname) != 0)
							{
								text3 = GlobalControl.InstancePipeNname;
							}
							arrayList2.Add(text3);
							if (!sortedList.ContainsKey(key))
							{
								sortedList.Add(key, text3);
							}
							if (!sortedList2.Contains(text3))
							{
								sortedList2.Add(text3, text3);
							}
						}
						if (text2.StartsWith("<dataSource href="))
						{
							int num6 = text2.IndexOf("#", 0, text2.Length);
							int num7 = text2.IndexOf("/", 0, text2.Length);
							string text4 = text2.Substring(num6 + 1, num7 - num6 - 1);
							text4 = "\"" + text4;
							string value2 = (string)sortedList[text4];
							arrayList2.Add(value2);
						}
					}
				}
				Hashtable hashtable = CheckSQLAuthentionMode(sortedList2);
				currentlyTestingTextBox.Text = "Database permissions and access settings";
				Update();
				Thread.Sleep(3000);
				ConnStatusMessages = new ArrayList();
				db_List = databaseCollection.InitializeFromConfigurationFileForDBTester(null, out ConnStatusMessages);
				CheckDatabaseAccess(arrayList2, arrayList, db_List, ConnStatusMessages);
				currentlyTestingTextBox.Text = "Finished testing various configuration settings.";
				empty = string.Empty;
				foreach (DictionaryEntry item in hashtable)
				{
					if ((int)item.Value == -5 || (int)item.Value == 2 || ApedApplication.GetSQLAuthPreference() != 2)
					{
						continue;
					}
					Cursor = Cursors.Default;
					if (!GlobalControl.runAdmin)
					{
						empty = "SQL instance : " + item.Key.ToString() + " was detected to have an incorrect Windows authentication mode.";
						if (GlobalControl.isWinPC)
						{
							empty += " However, you must run as administrator to change the authentication mode to 'SQL Server and Windows'.";
						}
						else
						{
							empty += " However, you must have administrative privilege to change the authentication mode to 'SQL Server and Windows'.";
						}
						MessageBox.Show(empty, "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						((Form1)base.Parent).Close();
					}
					empty = "SQL instance : " + item.Key.ToString() + " was detected to have an incorrect Windows authentication mode. Click OK to change the authentication mode to 'SQL Server and Windows'. Clicking Cancel will not change the authentication mode and Aspen Properties databases will not work. Click Help to learn more about how to change SQL authentication mode yourself.";
					if (MessageBox.Show(empty, "Database Restore", MessageBoxButtons.OKCancel, MessageBoxIcon.Hand) == DialogResult.OK)
					{
						try
						{
							Cursor = Cursors.WaitCursor;
							databaseCollection.ChangeAuthenticationMode(item.Key.ToString());
							MessageBox.Show("SQL authentication mode has been successfully changed for SQL instance :" + item.Key.ToString() + ".", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
						catch (Exception ex2)
						{
							Cursor = Cursors.Default;
							MessageBox.Show("An error has occurred while changing SQL authentication mode to 'SQL Server and Windows'.\nClick Help to learn more about how to change SQL authentication mode yourself.\n" + ex2.Message, "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						}
					}
				}
				Cursor = Cursors.Default;
				Thread.Sleep(3000);
				((Form1)base.Parent).Close();
			Done:;
			}
			catch (Exception ex3)
			{
				MessageBox.Show(ex3.Message, "Database Restore", MessageBoxButtons.OK);
				((Form1)base.Parent).Close();
			}
		}

		private void buttonRestore_Click(object sender, EventArgs e)
		{
			bool flag = true;
			_ = string.Empty;
			if (myInput == 1)
			{
				if (MessageBox.Show("Configuration file is found. Do you want to update it?", "Database Restore", MessageBoxButtons.YesNo, MessageBoxIcon.Hand) == DialogResult.Yes)
				{
					try
					{
						File.Delete(myConfigfilepath);
					}
					catch (Exception ex)
					{
						_ = ex.Message;
						flag = false;
					}
				}
				else
				{
					flag = false;
				}
			}
			if (flag)
			{
				int iCanChange = 3;
				buttonRestore.Enabled = false;
				ProcessInput(iCanChange);
			}
		}

		private void okButton_Click(object sender, EventArgs e)
		{
			int iCanChange = 2;
			if (okButton.Text == "Start")
			{
				iCanChange = 1;
				buttonRestore.Enabled = false;
			}
			ProcessInput(iCanChange);
		}

		private void RestartTester()
		{
			currentlyTestingTextBox.Text = "Please press the Start button to begin testing";
			configFileLabel.Text = "1. Configuration File :";
			for (int i = 0; i < dataGridView1.RowCount; i++)
			{
				for (int j = 0; j < dataGridView1.ColumnCount; j++)
				{
					dataGridView1.Rows[i].Cells[j].Value = "";
				}
			}
			for (int k = 0; k < dataGridView2.RowCount; k++)
			{
				for (int l = 0; l < dataGridView2.ColumnCount; l++)
				{
					dataGridView2.Rows[k].Cells[l].Value = "";
				}
			}
			okButton.Text = "Start";
			okButton.Enabled = true;
		}

		private void CheckDatabaseAccess(ArrayList allServersInConfig, ArrayList dbInConfig, ArrayList Db_List, ArrayList connStatusMsgList)
		{
			DataGridViewCell dataGridViewCell = null;
			dataGridView2.RowCount = Db_List.Count;
			for (int i = 0; i < allServersInConfig.Count; i++)
			{
				dataGridViewCell = dataGridView2.Rows[i].Cells[0];
				string text = allServersInConfig[i].ToString();
				if (text.Contains("pipe") && text.Contains("tsql") && text.Contains("query"))
				{
					dataGridViewCell.Value = GlobalControl.localSQLShareName;
				}
				else
				{
					dataGridViewCell.Value = allServersInConfig[i].ToString();
				}
			}
			for (int j = 0; j < dbInConfig.Count; j++)
			{
				dataGridViewCell = dataGridView2.Rows[j].Cells[1];
				dataGridViewCell.Value = dbInConfig[j].ToString();
			}
			for (int k = 0; k < Db_List.Count; k++)
			{
				IDatabase database = (IDatabase)Db_List[k];
				dataGridViewCell = dataGridView2.Rows[k].Cells[2];
				dataGridViewCell.Value = connStatusMsgList[k].ToString();
				if (database != null)
				{
					dataGridViewCell = dataGridView2.Rows[k].Cells[3];
					database.ConfirmApplicationPwd(global::ApedApplicationCredentials.AspenPlus);
					if (database.AspenPlusAccess)
					{
						if (modelManagerDBMsgHT.Contains(database.Alias))
						{
							dataGridViewCell.Value = "Granted / " + (string)modelManagerDBMsgHT[database.Alias];
						}
						else
						{
							dataGridViewCell.Value = "Granted / Failed";
						}
					}
					else
					{
						dataGridViewCell.Value = "Denied / Failed";
					}
					dataGridViewCell = dataGridView2.Rows[k].Cells[4];
					database.ConfirmApplicationPwd(global::ApedApplicationCredentials.DataManager);
					if (database.DataManagerAccess)
					{
						dataGridViewCell.Value = "Granted / Successful";
					}
					else
					{
						dataGridViewCell.Value = "Denied / Failed";
					}
				}
				else
				{
					dataGridViewCell = dataGridView2.Rows[k].Cells[3];
					dataGridViewCell.Value = "-";
					dataGridViewCell = dataGridView2.Rows[k].Cells[4];
					dataGridViewCell.Value = "-";
				}
			}
		}

		private Hashtable CheckSQLAuthentionMode(SortedList serverListInConfig)
		{
			DataGridViewCell dataGridViewCell = null;
			IDatabaseCollection databaseCollection = new DatabaseCollection();
			dataGridView1.RowCount = serverListInConfig.Count;
			Hashtable hashtable = new Hashtable();
			for (int i = 0; i < serverListInConfig.Count; i++)
			{
				string text = (string)serverListInConfig.GetByIndex(i);
				if (text.Contains("pipe") && text.Contains("tsql") && text.Contains("query"))
				{
					dataGridViewCell = dataGridView1.Rows[i].Cells[0];
					dataGridViewCell.Value = GlobalControl.localSQLShareName;
					dataGridViewCell = dataGridView1.Rows[i].Cells[1];
					dataGridViewCell.Value = "SQL Server and Windows";
					dataGridViewCell = dataGridView1.Rows[i].Cells[2];
					dataGridViewCell.Value = "OK";
					continue;
				}
				string[] array = text.Split('\\');
				if (array == null)
				{
					continue;
				}
				dataGridViewCell = dataGridView1.Rows[i].Cells[0];
				dataGridViewCell.Value = text;
				if (array[0] == "." || array[0].ToLowerInvariant().CompareTo("localhost") == 0 || array[0].ToLowerInvariant().CompareTo(Environment.MachineName.ToLowerInvariant()) == 0)
				{
					if (array.Length == 1)
					{
						databaseCollection.RestartSQLInstance("MSSQLSERVER");
						int serverLoginMode = databaseCollection.GetServerLoginMode("localhost");
						hashtable.Add(text, serverLoginMode);
						if (serverLoginMode == -1)
						{
							dataGridViewCell = dataGridView1.Rows[i].Cells[1];
							dataGridViewCell.Value = "Error reading registry.";
							dataGridViewCell = dataGridView1.Rows[i].Cells[2];
							dataGridViewCell.Value = "Must use SQL (mixed) or Windows authentication mode as appropriate.";
							continue;
						}
						if (serverLoginMode == 2)
						{
							dataGridViewCell = dataGridView1.Rows[i].Cells[1];
							dataGridViewCell.Value = "SQL Server and Windows";
							dataGridViewCell = dataGridView1.Rows[i].Cells[2];
							dataGridViewCell.Value = "OK";
							continue;
						}
						dataGridViewCell = dataGridView1.Rows[i].Cells[1];
						dataGridViewCell.Value = "Windows Mode";
						dataGridViewCell = dataGridView1.Rows[i].Cells[2];
						if (ApedApplication.GetSQLAuthPreference() == 1)
						{
							dataGridViewCell.Value = "OK";
						}
						else
						{
							dataGridViewCell.Value = "NOT OK. Must use SQL(mixed) or Windows authentication mode as appropriate.";
						}
					}
					else
					{
						if (array.Length != 2)
						{
							continue;
						}
						databaseCollection.RestartSQLInstance(array[1]);
						int serverLoginMode2 = databaseCollection.GetServerLoginMode(array[1]);
						hashtable.Add(text, serverLoginMode2);
						if (serverLoginMode2 == -1)
						{
							dataGridViewCell = dataGridView1.Rows[i].Cells[1];
							dataGridViewCell.Value = "Error reading registry.";
							dataGridViewCell = dataGridView1.Rows[i].Cells[2];
							dataGridViewCell.Value = "Must use SQL(mixed) or Windows authentication mode as appropriate.";
							continue;
						}
						if (serverLoginMode2 == 2)
						{
							dataGridViewCell = dataGridView1.Rows[i].Cells[1];
							dataGridViewCell.Value = "SQL Server and Windows";
							dataGridViewCell = dataGridView1.Rows[i].Cells[2];
							dataGridViewCell.Value = "OK";
							continue;
						}
						dataGridViewCell = dataGridView1.Rows[i].Cells[1];
						dataGridViewCell.Value = "Windows Mode";
						dataGridViewCell = dataGridView1.Rows[i].Cells[2];
						if (ApedApplication.GetSQLAuthPreference() == 1)
						{
							dataGridViewCell.Value = "OK";
						}
						else
						{
							dataGridViewCell.Value = "NOT OK. Must use SQL (mixed) or Windows authentication mode as appropriate.";
						}
					}
				}
				else
				{
					hashtable.Add(text, -5);
					dataGridViewCell = dataGridView1.Rows[i].Cells[1];
					dataGridViewCell.Value = "Unknown";
					dataGridViewCell = dataGridView1.Rows[i].Cells[2];
					dataGridViewCell.Value = text + " must use SQL(mixed) or Windows authentication mode as appropriate.";
				}
			}
			return hashtable;
		}

		private void dbRestoreControl_Load(object sender, EventArgs e)
		{
			configFileLabel.Visible = true;
			currentlyTestingTextBox.Text = "Please press the start button to begin testing";
			okButton.Text = "Start";
		}

		private string ConfigFileCheck(out string configfilepath)
		{
			string text = "";
			configfilepath = "";
			ApedApplication.GetConfigurationFilePath(out configfilepath);
			if (!File.Exists(configfilepath))
			{
				return "";
			}
			try
			{
				FileStream fileStream = new FileStream(configfilepath, FileMode.Open, FileAccess.ReadWrite, FileShare.Read);
				text = "Configuration file has appropriate access permissions.\n";
				fileStream.Close();
			}
			catch (Exception)
			{
				text = "You do not have read/write permissions on config.aem file.\n";
			}
			return text;
		}

		private string SLMCheck()
		{
			int cookie = 0;
			string text = "";
			if (string.IsNullOrEmpty(text))
			{
				return text;
			}
			SecServer secServer = (SecServer)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("1460FDB4-752B-11D4-B067-0090271CF383")));
			if (secServer != null)
			{
				ISecCallback lostLicenseCallback = null;
				LicenseImportance_enum importance = LicenseImportance_enum.liCritical;
				for (int i = 0; i < GlobalControl.AspenLicensedProducts.Count; i++)
				{
					string license = GlobalControl.AspenLicensedProducts[i].ToString();
					secServer.CheckoutLicense(license, "", out cookie, lostLicenseCallback, importance);
					if (cookie != 0)
					{
						text = "Aspen product license is available.\n";
						break;
					}
				}
			}
			return text;
		}
	}
	public delegate int CallBackAddDatabankInfo(string dbankName, string dbaseName, string dbankPassword, string dbankDisplayNameMM, string baseDbank, string helpFileName, int helpCode, string layeredProducts, string pureDbankType, string prompt, int iHasPureParams, int iHasBinaryParams, int iHasReactionData);
	public delegate int CallBackAddBinaryParameterInfo(string pDbaseName, string pDbankName, string pParamName, string pGammaModelName, string pVaporModelName);
	public delegate int CallbackAddPureParameterInfo(string pDbaseName, string pDbankName, string pParamName, int NumberOfElements);
	public class Form1 : Form
	{
		private IContainer components;

		private Rectangle m_initBounds;

		private Rectangle m_prevBounds;

		private string myLevel = "level1";

		private SortedList m_parentControls = new SortedList();

		private dbRestoreControl myDbTestControl;

		public Form1()
		{
			InitializeComponent();
			m_initBounds = base.Bounds;
			m_prevBounds = m_initBounds;
			if (base.Controls != null && base.Controls.Count > 0)
			{
				IParentControl parentControl = new ParentControl(this, 1, myLevel);
				m_parentControls.Add(parentControl.Name, parentControl);
			}
		}

		private void myDbTestControl_Load(object sender, EventArgs e)
		{
			int input = 0;
			GlobalControl.isAPlusRun = false;
			string ConfigurationFilePath = string.Empty;
			ApedApplication.GetConfigurationFilePath(out ConfigurationFilePath);
			if (GlobalControl.AspenDB == 2)
			{
				if (File.Exists(ConfigurationFilePath))
				{
					MessageBox.Show("You set the registry to access Aspen Properties Enterprise Database via a remote SQL server. Therefore, no databases can be updated to your local machine. Please launch Database Manager to register databases from the remote SQL server.", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				else
				{
					MessageBox.Show("You set the registry to access Aspen Properties Enterprise Database via a remote SQL server. Therefore, no databases can be restored to your local machine. Please launch Database Manager to register databases from the remote SQL server.", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				Close();
				return;
			}
			if (GlobalControl.localDBServer)
			{
				if (File.Exists(ConfigurationFilePath))
				{
					input = 1;
				}
				else
				{
					input = 2;
				}
			}
			else
			{
				if (!GlobalControl.runAdmin)
				{
					MessageBox.Show("You must run dbRestore.bat as administrator", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Hand);
					Close();
					return;
				}
				if (File.Exists(ConfigurationFilePath))
				{
					ApedApplication.ReadConfigFile(ConfigurationFilePath);
				}
			}
			myDbTestControl.SetLocalDBButton(input, ConfigurationFilePath);
		}

		private void Form1_MouseEnter(object sender, EventArgs e)
		{
			Refresh();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.myDbTestControl = new dbRestore.dbRestoreControl();
			base.SuspendLayout();
			this.myDbTestControl.Location = new System.Drawing.Point(20, -2);
			this.myDbTestControl.Name = "myDbTestControl";
			this.myDbTestControl.Size = new System.Drawing.Size(500, 518);
			this.myDbTestControl.TabIndex = 1;
			this.myDbTestControl.Load += new System.EventHandler(myDbTestControl_Load);
			base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(517, 513);
			base.Controls.Add(this.myDbTestControl);
			base.Name = "Form1";
			this.Text = "Database Restore";
			base.MouseEnter += new System.EventHandler(Form1_MouseEnter);
			base.Resize += new System.EventHandler(Form1_Resize);
			base.ResumeLayout(false);
		}

		private void Form1_Resize(object sender, EventArgs e)
		{
			Rectangle bounds = base.Bounds;
			if (bounds.Height != m_prevBounds.Height || bounds.Width != m_prevBounds.Width)
			{
				if (bounds.Height < m_initBounds.Height)
				{
					SetBounds(base.Bounds.Left, base.Bounds.Top, base.Bounds.Width, m_initBounds.Height, BoundsSpecified.Height);
				}
				if (bounds.Width < m_initBounds.Width)
				{
					SetBounds(base.Bounds.Left, base.Bounds.Top, m_initBounds.Width, base.Bounds.Height, BoundsSpecified.Width);
				}
				m_prevBounds = base.Bounds;
				if (m_parentControls != null && m_parentControls.Count > 0)
				{
					foreach (IParentControl value in m_parentControls.Values)
					{
						if (value != null && value.Level == 1)
						{
							ApedGlobal.ResizeControls(this, base.Controls, value.ControlIndexs, value.ControlBounds, value.ControlLefts, value.ControlWidths, value.ControlRights, value.ControlTops, value.ControlHeights, value.ControlBottoms);
						}
					}
				}
				Refresh();
			}
		}
	}
	internal static class Program
	{
		[STAThread]
		private static void Main()
		{
			ApedApplication.GetAspenDBAndSkip();
			// Preserve the original value evaluation without a branch body.
			if (GlobalControl.Next == 8)
			{
			}
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(defaultValue: false);
			Application.Run(new Form1());
		}
	}
}
namespace dbRestore.Properties
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (resourceMan == null)
				{
					resourceMan = new ResourceManager("dbRestore.Properties.Resources", typeof(Resources).Assembly);
				}
				return resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return resourceCulture;
			}
			set
			{
				resourceCulture = value;
			}
		}

		internal Resources()
		{
		}
	}
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

		public static Settings Default => defaultInstance;
	}
}
namespace Interop.SECSERVEROBJECTLib
{
	[ComImport]
	[CompilerGenerated]
	[Guid("1460FDB6-752B-11D4-B067-0090271CF383")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface ISecCallback
	{
	}
	[ComImport]
	[CompilerGenerated]
	[Guid("A61D34E7-943C-4B91-A7CB-EFEC599ED919")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface ISecServer : ISecServer4
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		string CheckoutLicense([In][MarshalAs(UnmanagedType.BStr)] string license, [In][MarshalAs(UnmanagedType.BStr)] string licversion, out int cookie, [Optional][In][MarshalAs(UnmanagedType.Interface)] ISecCallback lostLicenseCallback, [Optional][In] LicenseImportance_enum importance);
	}
	[ComImport]
	[CompilerGenerated]
	[Guid("69C4BC11-E968-4190-A674-F1E0928C63F0")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface ISecServer2 : _ISecServer
	{
	}
	[ComImport]
	[CompilerGenerated]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("A09377DA-340B-4BBC-8DF5-F8A100055DD9")]
	[TypeIdentifier]
	public interface ISecServer3 : ISecServer2
	{
	}
	[ComImport]
	[CompilerGenerated]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("AE942D5A-12E1-42F9-AA95-B77631A4F6DE")]
	[TypeIdentifier]
	public interface ISecServer4 : ISecServer3
	{
	}
	[CompilerGenerated]
	[TypeIdentifier("1460FDB3-752B-11D4-B067-0090271CF383", "Interop.SECSERVEROBJECTLib.LicenseImportance_enum")]
	public enum LicenseImportance_enum
	{
		liNotCritical,
		liCritical
	}
	[ComImport]
	[CompilerGenerated]
	[CoClass(typeof(object))]
	[Guid("A61D34E7-943C-4B91-A7CB-EFEC599ED919")]
	[TypeIdentifier]
	public interface SecServer : ISecServer
	{
	}
	[ComImport]
	[CompilerGenerated]
	[Guid("1460FDB5-752B-11D4-B067-0090271CF383")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface _ISecServer
	{
	}
}
