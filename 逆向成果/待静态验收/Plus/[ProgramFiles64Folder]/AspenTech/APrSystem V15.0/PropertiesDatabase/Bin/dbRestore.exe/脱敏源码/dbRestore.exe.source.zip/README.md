# dbRestore.exe 公开脱敏源码

产品归属 Plus / Properties，以本机 Aspen V15.0 原件为基准。

[C# 源码](editable/dbRestore.decompiled.cs) · [构建输入及资源清单](build-inputs.json) · [公开核验](evidence/公开核验.json)

原件 SHA-256 d4cef0dea1cbc61cf4d83811e3268e11452578253d34f912c4cdea283cb2a5fa。三个凭据出现位置改为读取调用方的受授权运行时配置，其他原源码文本经反向核对一致。

复现编译需要 .NET SDK 9.0.321 的 Roslyn 与构建清单中具有对应指纹的 .NET Framework / Aspen 引用。用清单中的编译器选项，加载两份 C#、已验证的公钥和四项平台或托管资源。此公开版本在本机已完成编译验证。

运行时通过 ASPEN_APED_ASPEN_PLUS_PASSWORD 与 ASPEN_APED_DATA_MANAGER_PASSWORD 读取获授权的应用配置。这两项应用配置与 SQL 登录配置分开。完整逐字节验证材料单独保存在本地。
