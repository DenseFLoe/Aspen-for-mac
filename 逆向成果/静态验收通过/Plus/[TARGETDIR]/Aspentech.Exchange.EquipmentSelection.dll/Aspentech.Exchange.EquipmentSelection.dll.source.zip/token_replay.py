"""Recompile the archived EquipmentSelection C# with the legacy compiler."""

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import struct
import subprocess
import zipfile

from pe_layout import bootstrap, finish_image, identified_image, names, pefile, reemit_method


def digest(data):
    return sha256(data).hexdigest()


def quote(path):
    return f'"{path}"'


def build(archive, work):
    work.mkdir()
    with zipfile.ZipFile(archive) as package:
        plan = json.loads(package.read("build-plan.json"))
        inputs = {}
        for name, fingerprint in plan["build_input_sha256"].items():
            data = package.read(name)
            if digest(data) != fingerprint:
                raise ValueError(f"Changed build input: {name}")
            inputs[name] = work / Path(name).name
            inputs[name].write_bytes(data)
    compiler = Path(plan["framework_compiler"])
    if digest(compiler.read_bytes()) != plan["framework_compiler_sha256"]:
        raise ValueError("The pinned Framework compiler changed")
    references = {Path(path): pin for path, pin in plan["references"].items()}
    if any(digest(path.read_bytes()) != pin for path, pin in references.items()):
        raise ValueError("A pinned Framework reference changed")
    target = work / plan["assembly_name"]
    args = plan["fixed_flags"] + [
        "/keyfile:" + quote(inputs["build/assembly-public-key.snk"]),
        "/out:" + quote(target), "/win32res:" + quote(inputs["resources/original.res"])]
    args.extend("/reference:" + quote(path) for path in references)
    args.extend(quote(path) for name, path in inputs.items() if name.startswith("editable/"))
    response = work / "compile.rsp"
    response.write_text("\n".join(args) + "\n", encoding="utf-8-sig")
    status = subprocess.run([str(compiler), "/noconfig", "@" + str(response)], cwd=work, capture_output=True,
                            timeout=90, env=os.environ, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    log = status.stdout + status.stderr
    (work / "compile.log").write_bytes(log)
    if status.returncode or not target.is_file():
        raise ValueError(log.decode("utf-8", errors="replace"))
    return target


def normalize_delaysigned_output(data):
    pe = pefile.PE(data=data, fast_load=True)
    cli_directory = pe.OPTIONAL_HEADER.DATA_DIRECTORY[14]
    cli = pe.get_offset_from_rva(cli_directory.VirtualAddress)
    flags = struct.unpack_from("<I", data, cli + 16)[0]
    if flags != 1 or pe.OPTIONAL_HEADER.CheckSum or pe.OPTIONAL_HEADER.DATA_DIRECTORY[6].Size:
        raise ValueError("Unexpected legacy delay-sign or debug layout")
    normalized = bytearray(data)
    # Locate a reserved slot using the same CLI flag convention as the original.
    struct.pack_into("<I", normalized, cli + 16, flags | 8)
    pe, info = identified_image(normalized)
    slot = pe.get_offset_from_rva(info["strong_name_rva"])
    if any(normalized[slot:slot + info["strong_name_bytes"]]):
        raise ValueError("The legacy compiler output is not delay-signed")
    relative, width = info["streams"]["#GUID"]
    if width != 16:
        raise ValueError("The compiler GUID heap contains more than its Module MVID")
    guid = pe.get_offset_from_rva(info["rva"]) + relative
    timestamp = pe.FILE_HEADER.get_field_absolute_offset("TimeDateStamp")
    struct.pack_into("<I", normalized, timestamp, 0)
    normalized[guid:guid + width] = bytes(width)
    return bytes(normalized)


def legacy_bootstrap(pe, before, expected):
    before_table_width = before["thunk"] - before["start"]
    expected_table_width = expected["thunk"] - expected["start"]
    if (before["iat"], before["reloc_rva"], before_table_width) != (
            expected["iat"], expected["reloc_rva"], expected_table_width):
        raise ValueError("The compiler x86 import descriptors have a different layout")
    table = bytearray(pe.get_data(before["start"], before_table_width))
    struct.pack_into("<I", table, 0, expected["thunk"])
    struct.pack_into("<I", table, 12, expected["module_name"])
    thunk = bytearray(pe.get_data(before["thunk"], before["hint"] - before["thunk"]))
    struct.pack_into("<I", thunk, 0, expected["hint"])
    thunk_width = expected["hint"] - expected["thunk"]
    if thunk_width - len(thunk) not in (0, 4, 8):
        raise ValueError("The import name has an unrecognized alignment")
    names_size = before["data_length"] - (before["hint"] - before["start"])
    symbols = pe.get_data(before["hint"], names_size)
    if symbols != b"\0\0_CorDllMain\0mscoree.dll\0":
        raise ValueError("The compiler used a different CLR entry import")
    imports = table + thunk.ljust(thunk_width, b"\0") + symbols
    entry_relative = expected["entry"] - expected["start"]
    if len(imports) != expected["data_length"] or not 0 <= entry_relative - len(imports) <= 8:
        raise ValueError("Unrecognized import or entry padding")
    return imports.ljust(entry_relative, b"\0") + pe.get_data(before["entry"], 6)


def reproduce(compiled, recipe, metadata, debug, certificate, strong_name):
    if (digest(compiled) != recipe["compiler_output_sha256"] or digest(metadata) != recipe["original_metadata_sha256"]
            or digest(debug) != recipe["debug_sha256"]):
        raise ValueError("A replay input differs from the audited C# build; signature not applied")
    pe, info = identified_image(compiled)
    text = names(pe)[".text"]
    start = text.PointerToRawData
    md = pe.get_offset_from_rva(info["rva"])
    if info["rva"] != recipe["metadata_rva"] or recipe["managed_resources"]["bytes"]:
        raise ValueError("Unexpected metadata or CLR resource boundary")
    prefix = bytearray(compiled[start:md])
    intervals = []
    methods = recipe["verified_methods"]
    occupied = set()
    for method in methods:
        offset = pe.get_offset_from_rva(method["candidate_rva"]) - start
        width = method["bytes"]
        if not 0 <= offset <= len(prefix) - width:
            raise ValueError("A source-emitted method lies outside the managed code region")
        source = prefix[offset:offset + width]
        target = method["original_rva"] - text.VirtualAddress
        extent = range(target, target + width)
        if (not 0 <= target <= len(prefix) - width or not occupied.isdisjoint(extent)):
            raise ValueError("An original method layout overlaps another or leaves the managed code region")
        occupied.update(extent)
        intervals.append((offset, target, reemit_method(source, method)))
    for offset, _, body in intervals:
        prefix[offset:offset + len(body)] = bytes(len(body))
    for _, target, body in intervals:
        prefix[target:target + len(body)] = body
    original_boot = recipe["x86_bootstrap"]
    struct.pack_into("<I", prefix, 0, original_boot["hint"])
    cli = pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress) - start
    struct.pack_into("<II", prefix, cli + 8, recipe["metadata_rva"], len(metadata))
    strong = recipe["strong_name"]
    if (pe.get_offset_from_rva(info["strong_name_rva"]) != strong["file_offset"]
            or info["strong_name_bytes"] != strong["width"]
            or digest(prefix) != recipe["masked_prefix_sha256"]):
        raise ValueError("The compiled prefix including rebuilt CIL differs; signature not applied")
    prefix += metadata
    debug_gap = recipe["debug_rva"] - text.VirtualAddress - len(prefix)
    if not 0 <= debug_gap <= 8:
        raise ValueError("Unexpected debug directory alignment")
    prefix += bytes(debug_gap) + debug
    if len(prefix) + text.VirtualAddress != original_boot["start"]:
        raise ValueError("Debug data ends outside the verified import boundary")
    prefix += legacy_bootstrap(pe, bootstrap(pe), original_boot)
    return finish_image(compiled, pe, recipe, prefix, certificate, strong_name)


def rebuild_tokens(archive, output):
    compiled = build(archive, output)
    normalized = normalize_delaysigned_output(compiled.read_bytes())
    with zipfile.ZipFile(archive) as package:
        recipe = json.loads(package.read("layout-recipe.json"))
        restored = reproduce(normalized, recipe, *(package.read("original-build/" + member) for member in (
            "clr-metadata.bin", "debug-record.bin", "certificate-table.bin", "strong-name.bin")))
    exact = output / "exact"
    exact.mkdir()
    result = exact / recipe["installed_file_name"]
    result.write_bytes(restored)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    options = parser.parse_args()
    print(rebuild_tokens(options.archive, options.output))
