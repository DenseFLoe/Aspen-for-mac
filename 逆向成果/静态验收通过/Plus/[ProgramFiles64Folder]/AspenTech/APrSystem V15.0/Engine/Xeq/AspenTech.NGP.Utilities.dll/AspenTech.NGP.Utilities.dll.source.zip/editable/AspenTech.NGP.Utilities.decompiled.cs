using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using AspenTech.NGP.Infrastructure;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: ComVisible(false)]
[assembly: Guid("3013ac67-d86b-4163-9886-47289e387c3d")]
[assembly: AssemblyTitle("Utilities")]
[assembly: AssemblyFileVersion("41.0.0.12")]
[assembly: AssemblyProduct("Plex Data Management (NGP)")]
[assembly: AssemblyCopyright("Copyright © 2024 Aspen Technology, Inc.")]
[assembly: AssemblyTrademark("AspenTech is a registered trademark of Aspen Technology, Inc.")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace AspenTech.NGP
{
	public class AssemblyInfo
	{
		public const string ProductName = "Plex Data Management (NGP)";

		public const string CompanyName = "Aspen Technology, Inc.";

		public const string LegalTrademark = "AspenTech is a registered trademark of Aspen Technology, Inc.";

		public const string LegalCopyright = "Copyright © 2024 Aspen Technology, Inc.";

		public const string DeveloperVersion = "41.0";

		public const string DllVersion = "41.0.0.12";

		public const string ReleaseVersion = "V15";

		public const string Name = "";

		public const string Title = "";

		public const string Description = "";

		public const string ProductNameAndVersion = "Plex Data Management (NGP) V15";

		public const short AssemblyCopyrightFrom = 2013;

		public const short AssemblyCopyrightTo = 2024;

		public const string AssemblyCopyrightFrom_string = "2013";

		public const string AssemblyCopyrightTo_string = "2024";
	}
}
namespace AspenTech.NGP.Utilities
{
	public static class AspenPlusUnitsTable
	{
		public static readonly IReadOnlyDictionary<PhysicalQuantities, IReadOnlyList<(string unitName, double ConversionFactor)>> ConversionFactors = new Dictionary<PhysicalQuantities, IReadOnlyList<(string, double)>>
		{
			{
				PhysicalQuantities.Area,
				new List<(string, double)>
				{
					("sqm", 1.0),
					("sqft", 0.09290304),
					("sqm", 1.0),
					("sqcm", 0.0001),
					("sqin", 0.00064516),
					("sqmile", 2589988.110336),
					("sqmm", 1E-06)
				}
			},
			{
				PhysicalQuantities.Composition,
				new List<(string, double)>
				{
					("mol-fr", 1.0),
					("mol-fr", 1.0),
					("mol-fr", 1.0),
					("mass-fr", 1.0)
				}
			},
			{
				PhysicalQuantities.Density,
				new List<(string, double)>
				{
					("kg/cum", 1.0),
					("lb/cuft", 16.0184633739601),
					("gm/cc", 1000.0),
					("lb/gal", 119.826427316897),
					("gm/cum", 0.001),
					("gm/ml", 1000.0),
					("lb/bbl", 2.85301017421182)
				}
			},
			{
				PhysicalQuantities.Diffusivity,
				new List<(string, double)>
				{
					("sqm/sec", 1.0),
					("sqft/hr", 2.58064E-05),
					("sqcm/sec", 0.0001),
					("cs", 1E-06)
				}
			},
			{
				PhysicalQuantities.Energy,
				new List<(string, double)>
				{
					("J", 1.0),
					("Btu", 1055.05585262),
					("cal", 4.1868),
					("kcal", 4186.8),
					("kWhr", 3600000.0),
					("ft-lbf", 1.3558179483314),
					("GJ", 1000000000.0),
					("kJ", 1000.0),
					("N-m", 1.0),
					("MJ", 1000000.0),
					("Mcal", 4186800.0),
					("Gcal", 4186800000.0),
					("MBtu", 1055055.85262),
					("MMBtu", 1055055852.62),
					("hp-hr", 2684519.53769617),
					("MMkcal", 4184100000.0)
				}
			},
			{
				PhysicalQuantities.Enthalpy,
				new List<(string, double)>
				{
					("J/kmol", 1.0),
					("Btu/lbmol", 2326.0),
					("cal/mol", 4186.8),
					("J/kg", 1.0),
					("Btu/lb", 2326.0),
					("cal/gm", 4186.8),
					("MBtu/lbmol", 2326000.0)
				}
			},
			{
				PhysicalQuantities.Entropy,
				new List<(string, double)>
				{
					("J/kmol-K", 1.0),
					("Btu/lbmol-R", 4186.8),
					("cal/mol-K", 4186.8),
					("J/kg-K", 1.0),
					("Btu/lb-R", 4186.8),
					("cal/gm-K", 4186.8),
					("MJ/kmol-K", 1000000.0),
					("kcal/kmol-K", 4186.8),
					("Gcal/kmol-K", 4186800000.0),
					("MBtu/lbmol-R", 4186800.0),
					("kJ/mol-K", 1000000.0),
					("kJ/kmol-K", 1000.0)
				}
			},
			{
				PhysicalQuantities.Fiscal,
				new List<(string, double)>
				{
					("$", 1.0),
					("$", 1.0),
					("$", 1.0)
				}
			},
			{
				PhysicalQuantities.Flow,
				new List<(string, double)>
				{
					("kg/sec", 1.0),
					("lb/hr", 0.000125997880555556),
					("kg/hr", 0.000277777777777778),
					("lb/sec", 0.45359237),
					("Mlb/hr", 0.125997880555556),
					("tons/day", 0.0104998233796296),
					("Mcfh", 0.32151181),
					("tonne/hr", 0.277777777777778),
					("lb/day", 5.24991168981482E-06),
					("kg/day", 1.15740740740741E-05),
					("tons/hr", 0.251995761111111),
					("kg/min", 0.0166666666666667),
					("kg/year", 3.16880878140289E-08),
					("gm/min", 1.66666666666667E-05),
					("gm/hr", 2.77777777777778E-07),
					("gm/day", 1.15740740740741E-08),
					("Mgm/hr", 0.277777777777778),
					("Ggm/hr", 277.777777777778),
					("Mgm/day", 0.0115740740740741),
					("Ggm/day", 11.5740740740741),
					("lb/min", 0.00755987283333333),
					("MMlb/hr", 125.997880555556),
					("Mlb/day", 0.00524991168981481),
					("MMlb/day", 5.24991168981482),
					("lb/year", 1.43734748523335E-08),
					("Mlb/year", 1.43734748523335E-05),
					("MMlb/year", 0.0143734748523335),
					("tons/min", 15.1197456666667),
					("Mtons/year", 0.028746949704667),
					("MMtons/year", 28.746949704667),
					("L-tons/min", 16.9341151466667),
					("L-tons/hr", 0.282235252444444),
					("L-tons/day", 0.0117598021851852),
					("ML-tons/year", 0.0321965836692271),
					("MML-tons/year", 32.1965836692271),
					("ktonne/year", 0.031688087814029),
					("kg/oper-year", 3.16880878140289E-08),
					("lb/oper-year", 1.43734748523335E-08),
					("Mlb/oper-year", 1.43734748523335E-05),
					("MMlb/oper-year", 0.0143734748523335),
					("Mtons/oper-year", 0.028746949704667),
					("MMtons/oper-year", 28.746949704667),
					("ML-tons/oper-year", 0.0321965836692271),
					("MML-tons/oper-year", 32.1965836692271),
					("ktonne/oper-year", 0.031688087814029)
				}
			},
			{
				PhysicalQuantities.MassFlow,
				new List<(string, double)>
				{
					("kg/sec", 1.0),
					("lb/hr", 0.000125997880555556),
					("kg/hr", 0.000277777777777778),
					("lb/sec", 0.45359237),
					("Mlb/hr", 0.125997880555556),
					("tons/day", 0.0104998233796296),
					("gm/sec", 0.001),
					("tonne/hr", 0.277777777777778),
					("lb/day", 5.24991168981482E-06),
					("kg/day", 1.15740740740741E-05),
					("tons/year", 2.8746949704667E-05),
					("tons/hr", 0.251995761111111),
					("tonne/day", 0.0115740740740741),
					("tonne/year", 3.16880878140289E-05),
					("kg/min", 0.0166666666666667),
					("kg/year", 3.16880878140289E-08),
					("gm/min", 1.66666666666667E-05),
					("gm/hr", 2.77777777777778E-07),
					("gm/day", 1.15740740740741E-08),
					("Mgm/hr", 0.277777777777778),
					("Ggm/hr", 277.777777777778),
					("Mgm/day", 0.0115740740740741),
					("Ggm/day", 11.5740740740741),
					("lb/min", 0.00755987283333333),
					("MMlb/hr", 125.997880555556),
					("Mlb/day", 0.00524991168981481),
					("MMlb/day", 5.24991168981482),
					("lb/year", 1.43734748523335E-08),
					("Mlb/year", 1.43734748523335E-05),
					("MMlb/year", 0.0143734748523335),
					("tons/min", 15.1197456666667),
					("Mtons/year", 0.028746949704667),
					("MMtons/year", 28.746949704667),
					("L-tons/min", 16.9341151466667),
					("L-tons/hr", 0.282235252444444),
					("L-tons/day", 0.0117598021851852),
					("ML-tons/year", 0.0321965836692271),
					("MML-tons/year", 32.1965836692271),
					("ktonne/year", 0.031688087814029),
					("tons/oper-year", 2.8746949704667E-05),
					("tonne/oper-year", 3.16880878140289E-05),
					("kg/oper-year", 3.16880878140289E-08),
					("lb/oper-year", 1.43734748523335E-08),
					("Mlb/oper-year", 1.43734748523335E-05),
					("MMlb/oper-year", 0.0143734748523335),
					("Mtons/oper-year", 0.028746949704667),
					("MMtons/oper-year", 28.746949704667),
					("ML-tons/oper-year", 0.0321965836692271),
					("MML-tons/oper-year", 32.1965836692271),
					("ktonne/oper-year", 0.031688087814029)
				}
			},
			{
				PhysicalQuantities.MoleFlow,
				new List<(string, double)>
				{
					("kmol/sec", 1.0),
					("lbmol/hr", 0.000125997880555556),
					("kmol/hr", 0.000277777777777778),
					("MMscfh", 0.33202532796316),
					("MMscmh", 12.3930656071826),
					("mol/sec", 0.001),
					("lbmol/sec", 0.45359237),
					("scmh", 1.23930656071826E-05),
					("lbmol/day", 5.24991168981482E-06),
					("kmol/day", 1.15740740740741E-05),
					("MMscfd", 0.0138343886651317),
					("Mscfd", 1.38343886651317E-05),
					("scfm", 1.99215196777896E-05),
					("mol/min", 1.66666666666667E-05),
					("kmol/khr", 2.77777777777778E-07),
					("kmol/Mhr", 2.77777777777778E-10),
					("mol/hr", 2.77777777777778E-07),
					("Mmol/hr", 0.277777777777778),
					("Mlbmol/hr", 0.125997880555556),
					("lbmol/Mhr", 1.25997880555556E-07),
					("lbmol/MMhr", 1.25997880555556E-10),
					("Mscfm", 0.0199215196777896),
					("scfh", 3.3202532796316E-07),
					("Mscfh", 0.00033202532796316),
					("scfd", 1.38343886651317E-08),
					("ncmh", 1.23930656071826E-05),
					("ncmd", 5.1637773363261E-07),
					("kmol/min", 0.0166666666666667),
					("kmol/week", 1.65343915343915E-06),
					("kmol/month", 3.80257053768347E-07),
					("kmol/year", 3.16880878140289E-08),
					("kmol/oper-year", 3.16880878140289E-08),
					("lbmol/min", 0.00755987283333333)
				}
			},
			{
				PhysicalQuantities.VolumeFlow,
				new List<(string, double)>
				{
					("cum/sec", 1.0),
					("cuft/hr", 7.86579072E-06),
					("l/min", 1.66666666666667E-05),
					("gal/min", 6.30901964E-05),
					("gal/hr", 1.05150327333333E-06),
					("bbl/day", 1.84013072833333E-06),
					("cum/hr", 0.000277777777777778),
					("cuft/min", 0.0004719474432),
					("bbl/hr", 4.416313748E-05),
					("cuft/sec", 0.028316846592),
					("cum/day", 1.15740740740741E-05),
					("cum/year", 3.16880878140289E-08),
					("l/hr", 2.77777777777778E-07),
					("kbbl/day", 0.00184013072833333),
					("MMcuft/hr", 7.86579072),
					("MMcuft/day", 0.32774128),
					("Mcuft/day", 0.00032774128),
					("l/sec", 0.001),
					("l/day", 1.15740740740741E-08),
					("cum/min", 0.0166666666666667),
					("kcum/sec", 1000.0),
					("kcum/hr", 0.277777777777778),
					("kcum/day", 0.0115740740740741),
					("Mcum/sec", 1000000.0),
					("Mcum/hr", 277.777777777778),
					("Mcum/day", 11.5740740740741),
					("ACFM", 0.0004719474432),
					("cuft/day", 3.2774128E-07),
					("Mcuft/min", 0.4719474432),
					("Mcuft/hr", 0.00786579072),
					("MMcuft/hr", 7.86579072),
					("Mgal/min", 0.0630901964),
					("MMgal/min", 63.0901964),
					("Mgal/hr", 0.00105150327333333),
					("MMgal/hr", 1.05150327333333),
					("Mbbl/hr", 0.04416313748),
					("MMbbl/hr", 44.16313748),
					("Mbbl/day", 0.00184013072833333),
					("MMbbl/day", 1.84013072833333),
					("cum/oper-year", 3.16880878140289E-08)
				}
			},
			{
				PhysicalQuantities.EnthalpyFlow,
				new List<(string, double)>
				{
					("Watt", 1.0),
					("Btu/hr", 0.293071070172222),
					("cal/sec", 4.1868),
					("J/sec", 1.0),
					("GJ/hr", 277777.777777778),
					("kcal/hr", 1.163),
					("MMkcal/hr", 1163000.0),
					("MMBtu/hr", 293071.070172222),
					("MMkcal/day", 48458.3333333333),
					("MMBtu/day", 12211.2945905093),
					("Pcu/hr", 0.527527949444444),
					("MMPcu/hr", 527527.949444445),
					("kJ/sec", 1000.0),
					("kW", 1000.0),
					("MW", 1000000.0),
					("GW", 1000000000.0),
					("MJ/hr", 277.777777777778),
					("Gcal/hr", 1163000.0),
					("MBtu/hr", 293.071070172222),
					("Gcal/day", 48458.3333333333),
					("Mcal/hr", 1163.0),
					("kJ/hr", 0.277777777777778)
				}
			},
			{
				PhysicalQuantities.Force,
				new List<(string, double)>
				{
					("Newton", 1.0),
					("lbf", 4.4482216152605),
					("dyne", 1E-05),
					("kg-m/s2", 1.0)
				}
			},
			{
				PhysicalQuantities.MolarHeatCapacity,
				new List<(string, double)>
				{
					("J/kmol-K", 1.0),
					("Btu/lbmol-R", 4186.8),
					("cal/mol-K", 4186.8),
					("kcal/mol-K", 4186800.0),
					("tcal/mol-K", 4184.0),
					("Pcu/lbmol-K", 4186.80018360979),
					("kJ/kmol-K", 1000.0),
					("Btu/lbmol-F", 4186.8)
				}
			},
			{
				PhysicalQuantities.HeatTransferCoefficient,
				new List<(string, double)>
				{
					("Watt/sqm-K", 1.0),
					("Btu/hr-sqft-R", 5.67826334111349),
					("cal/sec-sqcm-K", 41868.0),
					("kcal/sec-sqm-K", 4186.8),
					("kcal/hr-sqm-K", 1.163),
					("Pcu/hr-sqft-K", 5.67826359013058),
					("kW/sqm-K", 1000.0),
					("J/sec-sqm-K", 1.0),
					("kJ/sec-sqm-K", 1000.0),
					("MMBtu/hr-sqft-R", 5678263.34111349),
					("kJ/sec-sqm-C", 1000.0),
					("MJ/sec-sqm-K", 1000000.0),
					("MJ/sec-sqm-C", 1000000.0),
					("GJ/hr-sqm-K", 277777.777777778),
					("GJ/hr-sqm-C", 277777.777777778),
					("kcal/hr-sqm-C", 1.163),
					("Btu/hr-sqft-F", 5.67826334111349),
					("MMBtu/hr-sqft-F", 5678263.34111349),
					("MW/sqm-K", 1000000.0)
				}
			},
			{
				PhysicalQuantities.Length,
				new List<(string, double)>
				{
					("meter", 1.0),
					("ft", 0.3048),
					("meter", 1.0),
					("cm", 0.01),
					("in", 0.0254),
					("mu", 1E-06),
					("mm", 0.001),
					("mile", 1609.344),
					("km", 1000.0),
					("angstrom", 1E-10),
					("Mft", 304.8),
					("micron", 1E-06)
				}
			},
			{
				PhysicalQuantities.Mass,
				new List<(string, double)>
				{
					("kg", 1.0),
					("lb", 0.45359237),
					("kg", 1.0),
					("gm", 0.001),
					("ton", 907.18474),
					("Mlb", 453.59237),
					("tonne", 1000.0),
					("L-ton", 1016.0469088),
					("MMlb", 453592.37)
				}
			},
			{
				PhysicalQuantities.Power,
				new List<(string, double)>
				{
					("Watt", 1.0),
					("hp", 745.69987158227),
					("kW", 1000.0),
					("Btu/hr", 0.29307107),
					("cal/sec", 4.1868),
					("ft-lbf/sec", 1.3558179),
					("MW", 1000000.0),
					("GW", 1000000000.0),
					("MJ/hr", 277.777777777778),
					("kcal/hr", 1.163),
					("Gcal/hr", 1163000.0),
					("MMBtu/hr", 293071.070172222),
					("MBtu/hr", 293.071070172222),
					("Mhp", 745699.87158227)
				}
			},
			{
				PhysicalQuantities.Pressure,
				new List<(string, double)>
				{
					("N/sqm", 1.0),
					("psia", 6894.75729316836),
					("atm", 101325.0),
					("lbf/sqft", 47.8802589803359),
					("bar", 100000.0),
					("torr", 133.322368421053),
					("in-water", 249.0889),
					("kg/sqcm", 98066.5),
					("mmHg", 133.322368421053),
					("kPa", 1000.0),
					("mm-water", 9.80665),
					("mbar", 100.0),
					("psig", 6894.75729316836),
					("atmg", 101325.0),
					("barg", 100000.0),
					("kg/sqcmg", 98066.5),
					("lb/ft-sqsec", 1.48816394356955),
					("kg/m-sqsec", 1.0),
					("Pa", 1.0),
					("MPa", 1000000.0),
					("Pag", 1.0),
					("kPag", 1000.0),
					("MPag", 1000000.0),
					("mbarg", 100.0),
					("in-Hg", 3386.38815789474),
					("mmHg-vac", -133.322368421053),
					("in-Hg-vac", -3386.38815789474),
					("in-water-60F", 248.84),
					("in-water-vac", -249.0889),
					("in-water-60F-vac", -248.84),
					("in-water-g", 249.0889),
					("in-water-60F-g", 248.84),
					("mm-water-g", 9.80665),
					("mm-water-60F-g", 9.79685039370079),
					("psi", 6894.75729316836),
					("mm-water-60F", 9.79685039370079),
					("bara", 100000.0)
				}
			},
			{
				PhysicalQuantities.SurfaceTension,
				new List<(string, double)>
				{
					("N/m", 1.0),
					("dyne/cm", 0.001),
					("dyne/cm", 0.001),
					("lbf/ft", 14.5939029372064),
					("mN/m", 0.001),
					("dyne/m", 1E-05)
				}
			},
			{
				PhysicalQuantities.Temperature,
				new List<(string, double)>
				{
					("K", 1.0),
					("F", 0.555555555555556),
					("K", 1.0),
					("C", 1.0),
					("R", 0.555555555555556)
				}
			},
			{
				PhysicalQuantities.ThermalConductivity,
				new List<(string, double)>
				{
					("Watt/m-K", 1.0),
					("Btu-ft/hr-sqft-R", 1.73073466637139),
					("kcal-m/hr-sqm-K", 1.163),
					("Btu-in/hr-sqft-R", 0.144227888864283),
					("c-cm/sec-sqcm-K", 418.68),
					("cal-cm/sec-sqcm-K", 418.68),
					("Btu/hr-ft-R", 1.73073466637139),
					("kcal/hr-m-K", 1.163),
					("J/sec-m-K", 1.0),
					("kW/m-K", 1000.0),
					("Btu-ft/hr-sqft-F", 1.73073466637139),
					("Btu-in/hr-sqft-F", 0.144227888864283),
					("Btu/hr-ft-F", 1.73073466637139),
					("MW/m-K", 1000000.0)
				}
			},
			{
				PhysicalQuantities.Time,
				new List<(string, double)>
				{
					("sec", 1.0),
					("hr", 3600.0),
					("hr", 3600.0),
					("day", 86400.0),
					("min", 60.0),
					("year", 31557600.0),
					("month", 2629800.0),
					("week", 604800.0),
					("nsec", 1E-09),
					("oper-year", 31557600.0)
				}
			},
			{
				PhysicalQuantities.Velocity,
				new List<(string, double)>
				{
					("m/sec", 1.0),
					("ft/sec", 0.3048),
					("m/sec", 1.0),
					("mile/hr", 0.44704),
					("km/hr", 0.277777777777778),
					("ft/min", 0.00508),
					("mm/day", 1.15740740740741E-08),
					("mm/hr", 2.77777777777778E-07),
					("mm/day30", 3.85802469135802E-10),
					("in/day", 2.93981481481481E-07)
				}
			},
			{
				PhysicalQuantities.Viscosity,
				new List<(string, double)>
				{
					("N-sec/sqm", 1.0),
					("cP", 0.001),
					("cP", 0.001),
					("lb/ft-hr", 0.000413378873213765),
					("mN-sec/sqm", 0.001),
					("p", 0.1),
					("gm/sec-cm", 0.1),
					("dyn-sec/sqcm", 0.1),
					("Pa-sec", 1.0)
				}
			},
			{
				PhysicalQuantities.Volume,
				new List<(string, double)>
				{
					("cum", 1.0),
					("cuft", 0.028316846592),
					("l", 0.001),
					("cuin", 1.6387064E-05),
					("gal", 0.003785411784),
					("bbl", 0.158987294928),
					("cc", 1E-06),
					("kcum", 1000.0),
					("Mcum", 1000000.0),
					("Mcuft", 28.316846592),
					("MMcuft", 28316.846592),
					("ml", 1E-06),
					("kl", 1.0),
					("MMl", 1000.0),
					("Mgal", 3.785411784),
					("MMgal", 3785.411784),
					("UKgal", 0.004546093),
					("MUKgal", 4.546093),
					("MMUKgal", 4546.093),
					("Mbbl", 158.987294928),
					("MMbbl", 158987.294928),
					("kbbl", 158.987294928),
					("cuyd", 0.764554857984)
				}
			},
			{
				PhysicalQuantities.Frequency,
				new List<(string, double)>
				{
					("Hz", 1.0),
					("rpm", 0.0166666666666667),
					("rpm", 0.0166666666666667),
					("rad/sec", 0.159154943091896),
					("rps", 1.0),
					("krpm", 16.6666666666667),
					("MMrpm", 16666.6666666667),
					("rph", 0.000277777777777778)
				}
			},
			{
				PhysicalQuantities.UnitPrice,
				new List<(string, double)>
				{
					("$/kg", 1.0),
					("$/lb", 2.20462262184878),
					("$/kg", 1.0),
					("$/ton", 0.00110231131092439),
					("$/Mlb", 0.00220462262184878),
					("$/gm", 1000.0),
					("$/L-ton", 0.000984206527611061),
					("$/tonne", 0.001),
					("$/MMlb", 2.20462262184878E-06)
				}
			},
			{
				PhysicalQuantities.EnergyPrice,
				new List<(string, double)>
				{
					("$/J", 1.0),
					("$/Btu", 0.000947817120313317),
					("$/cal", 0.238845896627496),
					("$/kcal", 0.000238845896627496),
					("$/kWhr", 2.77777777777778E-07),
					("$/ft-lbf", 0.737562149277265),
					("$/Gcal", 2.38845896627496E-10),
					("$/MMBtu", 9.47817120313317E-10),
					("$/hp-hr", 3.72506135998619E-07),
					("$/MBtu", 9.47817120313317E-07),
					("$/kJ", 0.001),
					("$/MJ", 1E-06),
					("$/GJ", 1E-09),
					("$/N-m", 1.0),
					("$/Mcal", 2.38845896627496E-07)
				}
			},
			{
				PhysicalQuantities.DeltaT,
				new List<(string, double)>
				{
					("K", 1.0),
					("F", 0.555555555555556),
					("K", 1.0),
					("C", 1.0),
					("R", 0.555555555555556),
					("DELTA-K", 1.0),
					("DELTA-F", 0.555555555555556),
					("DELTA-C", 1.0),
					("DELTA-R", 0.555555555555556)
				}
			},
			{
				PhysicalQuantities.Angle,
				new List<(string, double)>
				{
					("rad", 1.0),
					("deg", 0.0174532925199433),
					("deg", 0.0174532925199433)
				}
			},
			{
				PhysicalQuantities.Head,
				new List<(string, double)>
				{
					("J/kg", 1.0),
					("ft-lbf/lb", 2.98906692),
					("m-kgf/kg", 9.80665),
					("sqm/sqsec", 1.0),
					("inch", 0.24908891),
					("ft", 2.98906692),
					("meter", 9.80665),
					("kJ/kg", 1000.0),
					("km-kgf/kg", 9806.65),
					("Mft", 2989.06692),
					("MJ/kg", 1000000.0),
					("Mft-lbf/lb", 2989.06692),
					("ft-head", 2.98906692),
					("meter-head", 9.80665),
					("inch-head", 0.24908891)
				}
			},
			{
				PhysicalQuantities.BondWorkInDe,
				new List<(string, double)>
				{
					("J/kg", 1.0),
					("kWhr/ton", 3968.3207193278),
					("kWhr/ton", 3968.3207193278),
					("kJ/kg", 1000.0)
				}
			},
			{
				PhysicalQuantities.FilterResist,
				new List<(string, double)>
				{
					("1/meter", 1.0),
					("1/ft", 3.28083989501312),
					("1/meter", 1.0),
					("1/cm", 100.0),
					("1/in", 39.3700787401575)
				}
			},
			{
				PhysicalQuantities.SpecFltRes,
				new List<(string, double)>
				{
					("meter/kg", 1.0),
					("ft/lb", 0.671968975139507),
					("meter/kg", 1.0),
					("cm/gm", 10.0)
				}
			},
			{
				PhysicalQuantities.MolarDensity,
				new List<(string, double)>
				{
					("kmol/cum", 1.0),
					("lbmol/cuft", 16.0184633739601),
					("mol/cc", 1000.0),
					("lbmol/gal", 119.826427316897),
					("mol/l", 1.0)
				}
			},
			{
				PhysicalQuantities.MassDensity,
				new List<(string, double)>
				{
					("kg/cum", 1.0),
					("lb/cuft", 16.0184633739601),
					("gm/cc", 1000.0),
					("lb/gal", 119.826427316897),
					("gm/cum", 0.001),
					("gm/ml", 1000.0)
				}
			},
			{
				PhysicalQuantities.MolarEnthalpy,
				new List<(string, double)>
				{
					("J/kmol", 1.0),
					("Btu/lbmol", 2326.0),
					("cal/mol", 4186.8),
					("kcal/mol", 4186800.0),
					("tcal/mol", 4184.0),
					("MMkcal/mol", 4186800000000.0),
					("MMBtu/lbmol", 2326000000.0),
					("Pcu/lbmol", 4186.80018360979),
					("MMPcu/lbmol", 4186800183.60979),
					("kJ/kmol", 1000.0),
					("GJ/kmol", 1000000000.0),
					("MJ/kmol", 1000000.0),
					("kcal/kmol", 4186.8),
					("Gcal/kmol", 4186800000.0),
					("MBtu/lbmol", 2326000.0),
					("Btu/scf", 882676.848691313),
					("Gcal/mol", 4186800000000.0),
					("kJ/mol", 1000000.0)
				}
			},
			{
				PhysicalQuantities.MassEnthalpy,
				new List<(string, double)>
				{
					("J/kg", 1.0),
					("Btu/lb", 2326.0),
					("cal/gm", 4186.8),
					("kcal/kg", 4186.8),
					("MMkcal/kg", 4186800000.0),
					("MMBtu/lb", 2326000000.0),
					("Pcu/lb", 4186.80018360979),
					("MMPcu/lb", 4186800183.60979),
					("kJ/kg", 1000.0),
					("MJ/kg", 1000000.0),
					("Gcal/kg", 4186800000.0),
					("MBtu/lb", 2326000.0)
				}
			},
			{
				PhysicalQuantities.MolarEntropy,
				new List<(string, double)>
				{
					("J/kmol-K", 1.0),
					("Btu/lbmol-R", 4186.8),
					("cal/mol-K", 4186.8),
					("kcal/mol-K", 4186800.0),
					("kJ/kmol-K", 1000.0),
					("tcal/mol-K", 4184.0),
					("MJ/kmol-K", 1000000.0),
					("kcal/kmol-K", 4186.8),
					("Gcal/kmol-K", 4186800000.0),
					("MBtu/lbmol-R", 4186800.0),
					("kJ/mol-K", 1000000.0)
				}
			},
			{
				PhysicalQuantities.MassEntropy,
				new List<(string, double)>
				{
					("J/kg-K", 1.0),
					("Btu/lb-R", 4186.8),
					("cal/gm-K", 4186.8),
					("kcal/kg-K", 4186.8),
					("kJ/kg-K", 1000.0),
					("MJ/kg-K", 1000000.0),
					("Gcal/kg-K", 4186800000.0),
					("MBtu/lb-R", 4186800.0)
				}
			},
			{
				PhysicalQuantities.MolarVolume,
				new List<(string, double)>
				{
					("cum/kmol", 1.0),
					("cuft/lbmol", 0.0624279605761446),
					("cc/mol", 0.001),
					("ml/mol", 0.001),
					("bbl/mscf", 0.133011351124695)
				}
			},
			{
				PhysicalQuantities.Dimensionless,
				new List<(string, double)>
				{
					("Unitless", 1.0),
					("Unitless", 1.0),
					("Unitless", 1.0),
					("Unitless", 1.0),
					("Unitless", 1.0)
				}
			},
			{
				PhysicalQuantities.DipoleMoment,
				new List<(string, double)>
				{
					("(J*cum)**.5", 1.0),
					("(Btu*cuft)**.5", 5.46588096509906),
					("debye", 3.16227766E-25),
					("(kJ*cum)**.5", 31.6227766016838),
					("C*m", 94802.6992569889)
				}
			},
			{
				PhysicalQuantities.SolubilityParameter,
				new List<(string, double)>
				{
					("(J/cum)**.5", 1.0),
					("(Btu/cuft)**.5", 193.025764621802),
					("(cal/cc)**.5", 2046.16714859759),
					("(kcal/cum)**.5", 64.705486629806),
					("(kJ/cum)**.5", 31.6227766016838),
					("(cal/ml)**0.5", 2046.16714859759)
				}
			},
			{
				PhysicalQuantities.ElecPower,
				new List<(string, double)>
				{
					("Watt", 1.0),
					("kW", 1000.0),
					("kW", 1000.0),
					("MW", 1000000.0)
				}
			},
			{
				PhysicalQuantities.ElecPrice,
				new List<(string, double)>
				{
					("$/J", 1.0),
					("$/kWhr", 2.77777777777778E-07),
					("$/kWhr", 2.77777777777778E-07)
				}
			},
			{
				PhysicalQuantities.MassHeatCapacity,
				new List<(string, double)>
				{
					("J/kg-K", 1.0),
					("Btu/lb-R", 4186.8),
					("cal/gm-K", 4186.8),
					("kcal/gm-K", 4186800.0),
					("Pcu/lb-K", 4186.80018360979),
					("kJ/kg-K", 1000.0),
					("Btu/lb-F", 4186.8)
				}
			},
			{
				PhysicalQuantities.Ua,
				new List<(string, double)>
				{
					("J/sec-K", 1.0),
					("Btu/hr-R", 0.52752792631),
					("cal/sec-K", 4.1868),
					("kJ/sec-K", 1000.0),
					("kcal/sec-K", 4186.8),
					("kcal/hr-K", 1.163),
					("Btu/hr-F", 0.52752792631),
					("kW/K", 1000.0)
				}
			},
			{
				PhysicalQuantities.Moles,
				new List<(string, double)>
				{
					("kmol", 1.0),
					("lbmol", 0.45359237),
					("kmol", 1.0),
					("scm", 0.0446150361858575),
					("MMscf", 1195.29118066738),
					("Mscf", 1.19529118066738),
					("MMscm", 44615.0361858575),
					("mol", 0.001),
					("scf", 0.00119529118066738)
				}
			},
			{
				PhysicalQuantities.Wrk,
				new List<(string, double)>
				{
					("J", 1.0),
					("hp-hr", 2684519.53769617),
					("kW-hr", 3600000.0),
					("ft-lbf", 1.3558179483314),
					("kJ", 1000.0),
					("N-m", 1.0),
					("MJ", 1000000.0),
					("MBtu", 1055055.85262),
					("MMBtu", 1055055852.62),
					("Mcal", 4186800.0),
					("Gcal", 4186800000.0)
				}
			},
			{
				PhysicalQuantities.Ht,
				new List<(string, double)>
				{
					("J", 1.0),
					("Btu", 1055.05585262),
					("cal", 4.1868),
					("kcal", 4186.8),
					("MMkcal", 4186800000.0),
					("MMBtu", 1055055852.62),
					("Pcu", 1899.100618),
					("MMPcu", 1899100618.0),
					("kJ", 1000.0),
					("GJ", 1000000000.0),
					("N-m", 1.0),
					("MJ", 1000000.0),
					("Mcal", 4186800.0),
					("Gcal", 4186800000.0),
					("MBtu", 1055055.85262),
					("kW-hr", 3600000.0)
				}
			},
			{
				PhysicalQuantities.AreaPrice,
				new List<(string, double)>
				{
					("$/sqm", 1.0),
					("$/sqft", 10.7639104167097),
					("$/sqm", 1.0),
					("$/sqcm", 10000.0),
					("$/sqin", 1550.0031000062),
					("$/sqmile", 3.86102158542446E-07),
					("$/sqmm", 1000000.0)
				}
			},
			{
				PhysicalQuantities.VolPrice,
				new List<(string, double)>
				{
					("$/cum", 1.0),
					("$/cuft", 35.3146667214886),
					("$/l", 1000.0),
					("$/cc", 1000000.0),
					("$/bbl", 6.28981077043211),
					("$/cuyd", 1.30795061931439),
					("$/kl", 1.0),
					("$/cuin", 61023.7440947323),
					("$/ml", 1000000.0),
					("$/MMl", 0.001),
					("$/gal", 264.172052358148),
					("$/Mgal", 0.264172052358148),
					("$/MMgal", 0.000264172052358148),
					("$/UKgal", 219.969103139773),
					("$/MUKgal", 0.219969103139773),
					("$/MMUKgal", 0.000219969103139773),
					("$/kbbl", 0.00628981077043211),
					("$/Mcuft", 0.0353146667214886),
					("$/MMcuft", 3.53146667214886E-05),
					("$/kcum", 0.001),
					("$/Mcum", 1E-06),
					("$/Mbbl", 0.00628981077043211),
					("$/MMbbl", 6.28981077043211E-06)
				}
			},
			{
				PhysicalQuantities.ItemPrice,
				new List<(string, double)>
				{
					("$/item", 1.0),
					("$/item", 1.0),
					("$/item", 1.0)
				}
			},
			{
				PhysicalQuantities.NumConc,
				new List<(string, double)>
				{
					("no/cum", 1.0),
					("no/cuft", 35.3146667214886),
					("no/l", 1000.0),
					("no/cc", 1000000.0),
					("1e6/cc", 1000000000000.0),
					("1e9/cc", 1000000000000000.0),
					("1e6/l", 1000000000.0),
					("1e9/l", 1000000000000.0),
					("1e6/cum", 1000000.0),
					("1e9/cum", 1000000000.0),
					("1e6/cuft", 35314666.7214886),
					("1e9/cuft", 35314666721.4886)
				}
			},
			{
				PhysicalQuantities.MassConcentration,
				new List<(string, double)>
				{
					("kg/cum", 1.0),
					("lb/cuft", 16.0184633739601),
					("gm/l", 1.0),
					("gm/cc", 1000.0),
					("mg/l", 0.001),
					("mg/cc", 1.0),
					("mg/cum", 1E-06)
				}
			},
			{
				PhysicalQuantities.InverseTime,
				new List<(string, double)>
				{
					("1/sec", 1.0),
					("1/hr", 0.000277777777777778),
					("1/hr", 0.000277777777777778),
					("1/min", 0.0166666666666667),
					("1/day", 1.15740740740741E-05),
					("1/year", 3.16880878140289E-08),
					("1/oper-year", 3.16880878140289E-08)
				}
			},
			{
				PhysicalQuantities.LnOfTime,
				new List<(string, double)>
				{
					("ln(1/sec)", 1.0),
					("ln(1/hr)", 1.0),
					("ln(1/hr)", 1.0),
					("ln(1/min)", 1.0)
				}
			},
			{
				PhysicalQuantities.Flux,
				new List<(string, double)>
				{
					("cum/sqm-sec", 1.0),
					("cuft/sqft-sec", 0.3048),
					("l/sqm-sec", 0.001),
					("l/sqm-hr", 2.77777777777778E-07),
					("gal/sqft-min", 0.000679097222222222),
					("cuft/sqft-hr", 8.466666666666667E-05),
					("l/sqm-min", 1.666666666666667E-05),
					("cum/sqm-hr", 0.000277777777777778)
				}
			},
			{
				PhysicalQuantities.AreaUsage,
				new List<(string, double)>
				{
					("sqm/sec", 1.0),
					("sqft/hr", 2.58064E-05),
					("sqm/hr", 0.000277777777777778),
					("sqm/day", 1.15740740740741E-05),
					("sqm/year", 3.16880878140289E-08),
					("sqm/oper-year", 3.16880878140289E-08)
				}
			},
			{
				PhysicalQuantities.VolumeUsage,
				new List<(string, double)>
				{
					("cum/sec", 1.0),
					("cuft/hr", 7.86579072E-06),
					("l/hr", 2.77777777777778E-07),
					("l/day", 1.15740740740741E-08),
					("l/year", 3.16880878140289E-11),
					("cum/hr", 0.000277777777777778),
					("cum/day", 1.15740740740741E-05),
					("cum/year", 3.16880878140289E-08),
					("l/oper-year", 3.16880878140289E-11),
					("cum/oper-year", 3.16880878140289E-08)
				}
			},
			{
				PhysicalQuantities.MoleConc,
				new List<(string, double)>
				{
					("kmol/cum", 1.0),
					("lbmol/cuft", 16.0184633739601),
					("mol/cc", 1000.0),
					("mol/l", 1.0),
					("mmol/cc", 1.0),
					("mmol/l", 0.001)
				}
			},
			{
				PhysicalQuantities.PowerPerVolume,
				new List<(string, double)>
				{
					("Watt/cum", 1.0),
					("hp/cuft", 26334.1424391847),
					("kW/l", 1000000.0),
					("kW/cum", 1000.0),
					("MW/cum", 1000000.0)
				}
			},
			{
				PhysicalQuantities.MassTransCoe,
				new List<(string, double)>
				{
					("kg/s-sqm-kg/cum", 1.0),
					("lb/hr-sqf-lb/cuf", 8.46666666666667E-05),
					("gm/s-sqcm-gm/cc", 0.01)
				}
			},
			{
				PhysicalQuantities.SpecArea,
				new List<(string, double)>
				{
					("sqm/cum", 1.0),
					("sqft/cuft", 3.28083989501312),
					("sqcm/cc", 100.0)
				}
			},
			{
				PhysicalQuantities.InvLength,
				new List<(string, double)>
				{
					("1/m", 1.0),
					("1/ft", 3.28083989501312),
					("1/cm", 100.0),
					("1/in", 39.3700787401575),
					("1/mm", 1000.0)
				}
			},
			{
				PhysicalQuantities.ChrVelocity,
				new List<(string, double)>
				{
					("m/sec", 1.0),
					("ft/sec", 0.3048),
					("cm/hr", 2.77777777777778E-06)
				}
			},
			{
				PhysicalQuantities.MassFlux,
				new List<(string, double)>
				{
					("kg/sqm-s", 1.0),
					("lb/sqft-hr", 0.00135622989899529),
					("kg/sqm-hr", 0.000277777777777778),
					("lb/sqft-s", 4.88242763638305),
					("gm/sqcm-s", 10.0),
					("kg/sqcm-s", 10000.0),
					("Mlb/sqft-hr", 1.35622989899529),
					("tons/sqft-hr", 2.71245979799058),
					("L-tons/sqft-hr", 3.03795497374945),
					("tonne/sqft-hr", 2.9899751157527)
				}
			},
			{
				PhysicalQuantities.Permeability,
				new List<(string, double)>
				{
					("kg/sqm-s-Pa", 1.0),
					("lb/sqft-hr-atm", 1.33849484233436E-08),
					("kg/sqm-hr-atm", 2.74145351865559E-09),
					("gm/sqcm-s-atm", 9.86923266716013E-05),
					("gm/sqcm-s-Pa", 10.0)
				}
			},
			{
				PhysicalQuantities.SolutePerm,
				new List<(string, double)>
				{
					("sqm/m-s", 1.0),
					("sqft/ft-hr", 8.46666666666667E-05),
					("sqm/m-hr", 0.000277777777777778),
					("sqcm/cm-s", 0.01),
					("sqft/ft-s", 0.3048)
				}
			},
			{
				PhysicalQuantities.SteamRate,
				new List<(string, double)>
				{
					("kg/J", 1.0),
					("lb/hp-hr", 1.68965941067156E-07),
					("kg/kW-hr", 2.77777777777778E-07)
				}
			},
			{
				PhysicalQuantities.PDropPerHeight,
				new List<(string, double)>
				{
					("N/cum", 1.0),
					("in-water/ft", 817.220800524934),
					("mm-water/m", 9.80665),
					("mbar/m", 100.0),
					("mmHg/ft", 437.409345213427),
					("torr/m", 133.322368421053),
					("mmHg/m", 133.322368421053)
				}
			},
			{
				PhysicalQuantities.PresDrop,
				new List<(string, double)>
				{
					("N/sqm", 1.0),
					("psi", 6894.75729316836),
					("atm", 101325.0),
					("lbf/sqft", 47.8802589803359),
					("bar", 100000.0),
					("torr", 133.322368421053),
					("in-water", 249.0889),
					("kg/sqcm", 98066.5),
					("mmHg", 133.322368421053),
					("kPa", 1000.0),
					("mm-water", 9.80665),
					("mbar", 100.0),
					("in-water-60F", 248.84),
					("in-Hg", 3386.38815789474),
					("lb/ft-sqsec", 1.48816394356955),
					("kg/m-sqsec", 1.0),
					("Pa", 1.0),
					("MPa", 1000000.0),
					("psia", 6894.75729316836),
					("mm-water-60F", 9.79685039370079)
				}
			},
			{
				PhysicalQuantities.PackFac,
				new List<(string, double)>
				{
					("1/m", 1.0),
					("1/ft", 3.28083989501312),
					("1/m", 1.0),
					("1/cm", 100.0),
					("1/in", 39.3700787401575),
					("1/mm", 1000.0)
				}
			},
			{
				PhysicalQuantities.NucRate,
				new List<(string, double)>
				{
					("no/cum-sec", 1.0),
					("no/cuft-sec", 35.3146667214886),
					("no/l-sec", 1000.0),
					("no/cc-sec", 1000000.0),
					("no/cum-sec", 1.0),
					("no/cum-min", 0.0166666666666667),
					("no/cuft-min", 0.588577778691477),
					("no/l-min", 16.6666666666667),
					("no/cc-min", 16666.6666666667),
					("no/cum-hr", 0.000277777777777778),
					("no/cuft-hr", 0.00980962964485795),
					("no/l-hr", 0.277777777777778),
					("no/cc-hr", 277.777777777778),
					("1e6/cum-sec", 1000000.0),
					("1e6/cuft-sec", 35314666.7214886),
					("1e6/l-sec", 1000000000.0),
					("1e6/cc-sec", 1000000000000.0),
					("1e6/cum-min", 16666.6666666667),
					("1e6/cuft-min", 588577.778691477),
					("1e6/l-min", 16666666.6666667),
					("1e6/cc-min", 16666666666.6667),
					("1e6/cum-hr", 277.777777777778),
					("1e6/cuft-hr", 9809.62964485795),
					("1e6/l-hr", 277777.777777778),
					("1e6/cc-hr", 277777777.777778),
					("1e9/cum-sec", 1000000000.0),
					("1e9/cuft-sec", 35314666721.4886),
					("1e9/l-sec", 1000000000000.0),
					("1e9/cc-sec", 1000000000000000.0),
					("1e9/cum-min", 16666666.6666667),
					("1e9/cuft-min", 588577778.691477),
					("1e9/l-min", 16666666666.6667),
					("1e9/cc-min", 16666666666666.7),
					("1e9/cum-hr", 277777.777777778),
					("1e9/cuft-hr", 9809629.64485795),
					("1e9/l-hr", 277777777.777778),
					("1e9/cc-hr", 277777777777.778)
				}
			},
			{
				PhysicalQuantities.InvArea,
				new List<(string, double)>
				{
					("1/sqm", 1.0),
					("1/sqft", 10.7639104167097),
					("1/sqm", 1.0)
				}
			},
			{
				PhysicalQuantities.VolHeatCap,
				new List<(string, double)>
				{
					("J/cum-K", 1.0),
					("Btu/cuft-R", 67066.1024540963),
					("cal/cc-K", 4186800.0),
					("kcal/cum-K", 4186.8),
					("kJ/cum-K", 1000.0),
					("Btu/cuft-F", 67066.1024540963)
				}
			},
			{
				PhysicalQuantities.HeatFlux,
				new List<(string, double)>
				{
					("Watt/m", 1.0),
					("Btu/hr-ft", 0.961519259095217),
					("cal/sec-m", 4.1868),
					("J/sec-m", 1.0),
					("MMBtu/hr-ft", 961519.259095217),
					("Gcal/hr-m", 1163000.0),
					("GJ/hr-m", 277777.777777778),
					("kcal/hr-m", 1.163),
					("kJ/hr-m", 0.27778),
					("kW/m", 1000.0),
					("cal/hr-cm", 0.1163)
				}
			},
			{
				PhysicalQuantities.InverseTemperature,
				new List<(string, double)>
				{
					("1/K", 1.0),
					("1/R", 1.8),
					("1/K", 1.0)
				}
			},
			{
				PhysicalQuantities.InversePressure,
				new List<(string, double)>
				{
					("sqm/N", 1.0),
					("1/psi", 0.000145037737730209),
					("1/atm", 9.86923266716013E-06),
					("sqft/lbf", 0.0208854342331501),
					("1/bar", 1E-05),
					("1/torr", 0.0075006168270417),
					("1/in-water", 0.00401463092092823),
					("sqcm/kg", 1.01971621297793E-05),
					("1/mmHg", 0.0075006168270417),
					("1/kPa", 0.001),
					("1/mm-water", 0.101971621297793)
				}
			},
			{
				PhysicalQuantities.TempPerVolume,
				new List<(string, double)>
				{
					("cum-K/kmol", 1.0),
					("cuft-R/lbmol", 0.0346822003200803),
					("cc-K/mol", 0.001)
				}
			},
			{
				PhysicalQuantities.VFlowPerLength,
				new List<(string, double)>
				{
					("sqm/sec", 1.0),
					("gpm/ft", 0.000206988833333333),
					("sqcm/sec", 0.0001),
					("sqm/hr", 0.000277777777777778),
					("sqft/min", 0.001548384),
					("gpm/in", 0.002483866)
				}
			},
			{
				PhysicalQuantities.Contents,
				new List<(string, double)>
				{
					("fraction", 1.0),
					("percent", 0.01),
					("fraction", 1.0),
					("ppm", 1E-06)
				}
			},
			{
				PhysicalQuantities.NumDensity,
				new List<(string, double)>
				{
					("no/m/cum", 1.0),
					("no/ft/cuft", 115.861767458952),
					("no/m/l", 1000.0),
					("no/mm/l", 1000000.0),
					("no/mu/cc", 1000000000000.0),
					("no/in/cuin", 2402509.61002883)
				}
			},
			{
				PhysicalQuantities.InvHeatTr,
				new List<(string, double)>
				{
					("sqm-K/Watt", 1.0),
					("hr-sqft-R/Btu", 0.176110183682306),
					("sec-sqcm-K/cal", 2.38845896627496E-05),
					("sec-sqm-K/kcal", 0.000238845896627496),
					("hr-sqm-K/kcal", 0.859845227858985),
					("hr-sqft-K/Pcu", 0.176110175959092),
					("sqm-K/kW", 0.001),
					("sec-sqm-K/J", 1.0),
					("sec-sqm-K/kJ", 0.001),
					("hr-sqft-R/MBtu", 1.76110183682306E-07)
				}
			},
			{
				PhysicalQuantities.VolEnthalpy,
				new List<(string, double)>
				{
					("J/cum", 1.0),
					("Btu/cuft", 37258.9458078313),
					("cal/cc", 4186800.0),
					("kcal/cum", 4186.8),
					("kJ/cum", 1000.0),
					("MMBtu/bbl", 6636101665.2167),
					("MJ/cum", 1000000.0)
				}
			},
			{
				PhysicalQuantities.MoleFlowPerLength,
				new List<(string, double)>
				{
					("kmol/sec-m", 1.0),
					("lbmol/hr-ft", 0.000413378873213765),
					("kmol/hr-m", 0.000277777777777778),
					("mol/sec-m", 0.001),
					("lbmol/sec-ft", 1.48816394356955),
					("lbmol/day-ft", 1.72241197172402E-05),
					("kmol/day-m", 1.15740740740741E-05),
					("mol/min-m", 1.66666666666667E-05)
				}
			},
			{
				PhysicalQuantities.MolePerm,
				new List<(string, double)>
				{
					("kmol/sqm-sec-Pa", 1.0),
					("lbmol/sqft-hr-psi", 1.96704516392347E-07),
					("kmol/sqm-hr-atm", 2.74145351865559E-09),
					("lbmol/sqft-hr-atm", 1.33849484233436E-08),
					("scft/sqft-day-psi", 2.2830526E-11),
					("scft/sqft-hr-100psi", 5.1840983E-12),
					("stdcc/sqcm-sec-cmhg", 3.3468609E-07),
					("barrers/cm", 3.3468609E-17)
				}
			},
			{
				PhysicalQuantities.Capacity,
				new List<(string, double)>
				{
					("kg/kg", 1.0),
					("lb/lb", 1.0),
					("kg/kg", 1.0)
				}
			},
			{
				PhysicalQuantities.GRate,
				new List<(string, double)>
				{
					("kg/sec-sqm", 1.0),
					("lb/hr-sqft", 0.00135622989899529),
					("kg/hr-sqm", 0.000277777777777778)
				}
			},
			{
				PhysicalQuantities.DesignPres,
				new List<(string, double)>
				{
					("N/sqm-gauge", 1.0),
					("psig", 6894.75729316836),
					("barg", 100000.0),
					("lbf/sqft-gauge", 47.8802589803359),
					("kPa-gauge", 1000.0),
					("mPa-gauge", 1000000.0)
				}
			},
			{
				PhysicalQuantities.PDropPerLength,
				new List<(string, double)>
				{
					("Pa/m", 1.0),
					("psi/ft", 22620.5947938595),
					("kgf/sqcm-km", 98.0665),
					("kPa/1000-m", 1.0),
					("psi/1000-ft", 22.6205947938595),
					("bar/1000-m", 100.0),
					("kPa/m", 1000.0),
					("Pa/1000-m", 0.001),
					("Pa/cm", 100.0),
					("Pa/km", 0.001),
					("psi/100-ft", 226.205947938595),
					("N/sqm-1000ft", 0.00328083989501312)
				}
			},
			{
				PhysicalQuantities.HeatFluxAr,
				new List<(string, double)>
				{
					("Watt/sqm", 1.0),
					("Btu/hr-sqft", 3.15459074506305),
					("cal/sec-sqm", 4.1868),
					("J/sec-sqm", 1.0),
					("MMBtu/hr-sqft", 3154590.74506305)
				}
			},
			{
				PhysicalQuantities.MoleFlux,
				new List<(string, double)>
				{
					("kmol/sqm-s", 1.0),
					("lbmol/sqft-hr", 0.00135622989899529),
					("kmol/sqm-hr", 0.000277777777777778),
					("lbmol/sqft-s", 4.88242763638305),
					("mol/sqcm-s", 10.0)
				}
			},
			{
				PhysicalQuantities.UsrDumm7,
				new List<(string, double)> { ("base-units", 1.0) }
			},
			{
				PhysicalQuantities.UsrDumm8,
				new List<(string, double)> { ("base-units", 1.0) }
			},
			{
				PhysicalQuantities.UsrDumm9,
				new List<(string, double)> { ("base-units", 1.0) }
			},
			{
				PhysicalQuantities.VolFlowPerRpm,
				new List<(string, double)>
				{
					("cum/sec/rpm", 1.0),
					("cuft/hr/rpm", 7.86579072E-06),
					("l/min/rpm", 1.66666666666667E-05),
					("gal/min/rpm", 6.30901964E-05),
					("gal/hr/rpm", 1.05150327333333E-06),
					("bbl/day/rpm", 1.84013072833333E-06),
					("cum/hr/rpm", 0.000277777777777778),
					("cuft/min/rpm", 0.0004719474432),
					("bbl/hr/rpm", 4.416313748E-05),
					("cuft/sec/rpm", 0.028316846592),
					("cum/day/rpm", 1.15740740740741E-05),
					("cum/year/rpm", 3.16880878140289E-08),
					("l/hr/rpm", 2.77777777777778E-07),
					("kbbl/day/rpm", 0.00184013072833333),
					("MMcuft/hr/rpm", 7.86579072),
					("MMcuft/day/rpm", 0.32774128),
					("Mcuft/day/rpm", 0.00032774128),
					("l/sec/rpm", 0.001),
					("l/day/rpm", 1.15740740740741E-08),
					("cum/min/rpm", 0.0166666666666667)
				}
			},
			{
				PhysicalQuantities.FFactor,
				new List<(string, double)>
				{
					("(kg-cum)**.5/sec", 1.0),
					("(lb-cuft)**.5/hr", 3.14813112753195E-05),
					("(gm-l)**.5/min", 1.66666666666667E-05),
					("(lb-gal)**.5/min", 0.000690618463273336)
				}
			},
			{
				PhysicalQuantities.MassCycle,
				new List<(string, double)>
				{
					("kg/cycle", 1.0),
					("lb/cycle", 0.45359237),
					("kg/cycle", 1.0),
					("lb/cycle", 0.45359237),
					("Mlb/cycle", 453.59237),
					("tons/cycle", 907.18474),
					("gm/cycle", 0.001),
					("tonne/cycle", 1000.0),
					("lb/cycle", 0.45359237),
					("kg/cycle", 1.0),
					("tons/cycle", 907.18474),
					("tons/cycle", 907.18474)
				}
			},
			{
				PhysicalQuantities.MolCycle,
				new List<(string, double)>
				{
					("kmol/cycle", 1.0),
					("lbmol/cycle", 0.45359237),
					("kmol/cycle", 1.0),
					("MMscfh/cycle", 1195.305984),
					("MMscmh/cycle", 44615.746),
					("mol/cycle", 0.001),
					("lbmol/cycle", 0.45359237),
					("scmh/cycle", 0.044615746),
					("lbmol/cycle", 0.45359237),
					("kmol/cycle", 1.0),
					("MMscfd/cycle", 1195.305984),
					("scfm/cycle", 0.0011953059)
				}
			},
			{
				PhysicalQuantities.VolCycle,
				new List<(string, double)>
				{
					("cum/cycle", 1.0),
					("cuft/cycle", 0.028316846592),
					("l/cycle", 0.001),
					("gal/cycle", 0.003785411784),
					("gal/cycle", 0.003785411784),
					("bbl/cycle", 0.158987294928),
					("cum/cycle", 1.0),
					("cuft/cycle", 0.028316846592),
					("bbl/cycle", 0.158987294928),
					("cuft/cycle", 0.028316846592),
					("cum/cycle", 1.0),
					("cum/cycle", 1.0),
					("l/cycle", 0.001),
					("kbbl/cycle", 158.987294928),
					("MMcuft/cycle", 28316.846592)
				}
			},
			{
				PhysicalQuantities.EnthalpyCycle,
				new List<(string, double)>
				{
					("Watt/cycle", 1.0),
					("Btu/cycle", 1055.05585262),
					("cal/cycle", 4.1868),
					("J/cycle", 1.0),
					("GJ/cycle", 1000000000.0),
					("kcal/cycle", 4186.8),
					("MMkcal/cycle", 4186800000.0),
					("MMBtu/cycle", 1055055852.62),
					("MMkcal/cycle", 4186800000.0),
					("MMBtu/cycle", 1055055852.62),
					("Pcu/cycle", 1899.100618),
					("MMPcu/cycle", 1899100618.0),
					("kJ/cycle", 1000.0),
					("kW/cycle", 1000.0),
					("Gcal/cycle", 4186800000.0),
					("MW/cycle", 1000000.0)
				}
			},
			{
				PhysicalQuantities.MassOper,
				new List<(string, double)>
				{
					("kg/op-sec", 1.0),
					("lb/op-hr", 0.000125997880555556),
					("kg/op-hr", 0.000277777777777778),
					("lb/op-sec", 0.45359237),
					("Mlb/op-hr", 0.125997880555556),
					("tons/op-day", 0.0104998233796296),
					("gm/op-sec", 0.001),
					("tonne/op-hr", 0.277777777777778),
					("lb/op-day", 5.24991168981482E-06),
					("kg/op-day", 1.15740740740741E-05),
					("tons/op-year", 2.8746949704667E-05),
					("tons/op-hr", 0.251995761111111)
				}
			},
			{
				PhysicalQuantities.MolOper,
				new List<(string, double)>
				{
					("kmol/op-sec", 1.0),
					("lbmol/op-hr", 0.000125997880555556),
					("kmol/op-hr", 0.000277777777777778),
					("MMscf/cycle-hr", 0.33202532796316),
					("MMscm/cycle-hr", 12.3930656071826),
					("mol/op-sec", 0.001),
					("lbmol/op-sec", 0.45359237),
					("scm/cycle-hr", 1.23930656071826E-05),
					("lbmol/op-day", 5.24991168981482E-06),
					("kmol/op-day", 1.15740740740741E-05),
					("MMscf/cycle-day", 0.0138343886651317),
					("scf/cycle-min", 1.99215196777896E-05)
				}
			},
			{
				PhysicalQuantities.VolumeOper,
				new List<(string, double)>
				{
					("cum/op-sec", 1.0),
					("cuft/op-hr", 7.86579072E-06),
					("l/op-min", 1.66666666666667E-05),
					("gal/op-min", 6.30901964E-05),
					("gal/op-hr", 1.05150327333333E-06),
					("bbl/op-day", 1.84013072833333E-06),
					("cum/op-hr", 0.000277777777777778),
					("cuft/op-min", 0.0004719474432),
					("bbl/op-hr", 4.416313748E-05),
					("cuft/op-sec", 0.028316846592),
					("cum/op-day", 1.15740740740741E-05),
					("cum/op-year", 3.16880878140289E-08),
					("l/op-hr", 2.77777777777778E-07),
					("kbbl/op-day", 0.00184013072833333),
					("MMcuft/op-hr", 7.86579072)
				}
			},
			{
				PhysicalQuantities.EnthalpyOper,
				new List<(string, double)>
				{
					("Watt/cycle", 1.0),
					("Btu/op-hr", 0.293071070172222),
					("cal/op-sec", 4.1868),
					("J/op-sec", 1.0),
					("GJ/op-hr", 277777.777777778),
					("kcal/op-hr", 1.163),
					("MMkcal/op-hr", 1163000.0),
					("MMBtu/op-hr", 293071.070172222),
					("MMkcal/op-day", 48458.3333333333),
					("MMBtu/op-day", 12211.2945905093),
					("Pcu/op-hr", 0.527527949444444),
					("MMPcu/op-hr", 527527.949444445),
					("kJ/op-sec", 1000.0),
					("kW/cycle", 1000.0),
					("Gcal/op-hr", 1163000.0),
					("Gcal/op-day", 48458.3333333333),
					("MW/cycle", 1000000.0)
				}
			},
			{
				PhysicalQuantities.RhoV2,
				new List<(string, double)>
				{
					("kg/m-sqsec", 1.0),
					("lb/ft-sqsec", 1.48816394356955),
					("kg/m-sqsec", 1.0)
				}
			},
			{
				PhysicalQuantities.Sound,
				new List<(string, double)>
				{
					("decibels", 1.0),
					("decibels", 1.0),
					("decibels", 1.0)
				}
			},
			{
				PhysicalQuantities.MomentOfInertia,
				new List<(string, double)>
				{
					("kg-sqm", 1.0),
					("lb-sqft", 0.0421401100938048),
					("kg-sqm", 1.0),
					("gm-sqcm", 1E-07),
					("lb-sqin", 0.0002926396534292)
				}
			},
			{
				PhysicalQuantities.Voltage,
				new List<(string, double)>
				{
					("volt", 1.0),
					("kvolt", 1000.0),
					("volt", 1.0),
					("mvolt", 0.001)
				}
			},
			{
				PhysicalQuantities.Current,
				new List<(string, double)>
				{
					("amp", 1.0),
					("mamp", 0.001),
					("amp", 1.0),
					("kamp", 1000.0)
				}
			},
			{
				PhysicalQuantities.MassVolume,
				new List<(string, double)>
				{
					("cum/kg", 1.0),
					("cuft/lb", 0.0624279605761446),
					("cc/g", 0.001),
					("BPD/MLBPH", 1.46044577910338E-05),
					("cc/kg", 1E-06)
				}
			},
			{
				PhysicalQuantities.MassPerLength,
				new List<(string, double)>
				{
					("kg/m", 1.0),
					("lb/ft", 1.48816394356955),
					("kg/m", 1.0)
				}
			},
			{
				PhysicalQuantities.VolumePerEnergy,
				new List<(string, double)>
				{
					("cum/J", 1.0),
					("bbl/Btu", 0.000150690880045061),
					("bbl/MMBtu", 1.50690880045061E-10)
				}
			},
			{
				PhysicalQuantities.SiemensPerLength,
				new List<(string, double)>
				{
					("Siemens/m", 1.0),
					("Siemens/ft", 3.28083989501312),
					("Siemens/m", 1.0),
					("Siemens/cm", 100.0)
				}
			},
			{
				PhysicalQuantities.CurrencyRate,
				new List<(string, double)>
				{
					("$/sec", 1.0),
					("$/hr", 0.000277777777777778),
					("$/hr", 0.000277777777777778),
					("$/min", 0.0166666666666667),
					("$/day", 1.15740740740741E-05),
					("$/year", 3.16880878140289E-08),
					("k$/hr", 0.277777777777778),
					("k$/day", 0.0115740740740741),
					("k$/year", 3.16880878140289E-05),
					("MM$/day", 11.5740740740741),
					("MM$/year", 0.031688087814029),
					("$/week", 1.65343915343915E-06),
					("$/nsec", 1000000000.0),
					("$/oper-year", 3.16880878140289E-08),
					("k$/oper-year", 3.16880878140289E-05),
					("MM$/oper-year", 0.031688087814029)
				}
			},
			{
				PhysicalQuantities.FluxHeat,
				new List<(string, double)>
				{
					("Watt/sqm", 1.0),
					("Btu/hr-sqft", 3.15459074506305),
					("cal/sec-sqm", 4.1868),
					("J/sec-sqm", 1.0),
					("MMBtu/hr-sqft", 3154590.74506305),
					("kW/sqm", 1000.0),
					("MW/sqm", 1000000.0),
					("cal/hr-sqcm", 11.63)
				}
			},
			{
				PhysicalQuantities.FluxMole,
				new List<(string, double)>
				{
					("kmol/sqm-s", 1.0),
					("lbmol/sqft-hr", 0.00135622989899529),
					("kmol/sqm-hr", 0.000277777777777778),
					("lbmol/sqft-s", 4.88242763638305),
					("mol/sqcm-s", 10.0)
				}
			},
			{
				PhysicalQuantities.HeatRateV,
				new List<(string, double)>
				{
					("Watt/cum", 1.0),
					("Btu/hr-cuft", 10.349707168842),
					("cal/sec-cum", 4.1868),
					("J/sec-cum", 1.0),
					("MMBtu/hr-cuft", 10349707.168842),
					("GJ/hr-cum", 277777.777777778),
					("MW/cum", 1000000.0),
					("J/hr-cum", 0.000277777777777778)
				}
			},
			{
				PhysicalQuantities.RxnRate,
				new List<(string, double)>
				{
					("kmol/cum-s", 1.0),
					("lbmol/cuft-hr", 0.00444957315943337),
					("kmol/cum-hr", 0.000277777777777778),
					("mol/cc-s", 1000.0)
				}
			},
			{
				PhysicalQuantities.RxnRateW,
				new List<(string, double)>
				{
					("kmol/kg-s", 1.0),
					("lbmol/lb-hr", 0.000277777777777778),
					("kmol/kg-hr", 0.000277777777777778),
					("mol/gm-s", 1.0)
				}
			},
			{
				PhysicalQuantities.MolePrice,
				new List<(string, double)>
				{
					("$/kmol", 1.0),
					("$/lbmol", 2.20462262184878),
					("$/mol", 1000.0)
				}
			},
			{
				PhysicalQuantities.HeatTransCv,
				new List<(string, double)>
				{
					("Watt/cum-K", 1.0),
					("Btu/hr-cuft-R", 18.6294729039156),
					("cal/sec-cc-K", 4186800.0),
					("Watt/cum-C", 1.0),
					("Watt/cum-F", 1.8),
					("kW/cum-K", 1000.0),
					("kW/cum-C", 1000.0),
					("Btu/hr-cuft-F", 18.6294729039156),
					("MW/cum-K", 1000000.0),
					("MW/cum-C", 1000000.0)
				}
			},
			{
				PhysicalQuantities.PowerPerArea,
				new List<(string, double)>
				{
					("Watt/sqm", 1.0),
					("hp/sqft", 8026.6466154635),
					("kW/sqm", 1000.0),
					("W/sqcm", 10000.0),
					("kW/sqcm", 10000000.0)
				}
			},
			{
				PhysicalQuantities.PowerPerMass,
				new List<(string, double)>
				{
					("Watt/kg", 1.0),
					("hp/lb", 1643.986806),
					("kW/kg", 1000.0),
					("W/g", 1000.0),
					("kW/g", 1000000.0),
					("MW/kg", 1000000.0)
				}
			},
			{
				PhysicalQuantities.MassEmission,
				new List<(string, double)>
				{
					("kg/J", 1.0),
					("lb/Btu", 0.000429922613929493),
					("kg/cal", 0.238845896627496),
					("tonne/GJ", 1E-06),
					("tonne/MMBtu", 9.47817120313317E-07),
					("kg/kcal", 0.000238845896627496),
					("kg/GJ", 1E-09),
					("kg/kJ", 0.001),
					("kg/MJ", 1E-06),
					("kg/MMkcal", 2.38845896627496E-10),
					("tonne/MMkcal", 2.38845896627496E-07),
					("kg/MMBtu", 9.47817120313317E-10),
					("g/MJ", 1E-09),
					("lb/MMBtu", 4.29922613929493E-10),
					("tonne/TJ", 1E-09)
				}
			},
			{
				PhysicalQuantities.InvVelocity,
				new List<(string, double)>
				{
					("sec/m", 1.0),
					("sec/ft", 3.28083989501312),
					("sec/cm", 100.0),
					("sec/in", 39.3700787401575),
					("sec/mm", 1000.0)
				}
			},
			{
				PhysicalQuantities.Specmatres,
				new List<(string, double)>
				{
					("kg/J-m", 1.0),
					("lb/Btu-ft", 0.001410507264),
					("gm/cal-cm", 0.0238845896627496)
				}
			},
			{
				PhysicalQuantities.Acceleration,
				new List<(string, double)>
				{
					("m/sqsec", 1.0),
					("ft/sqsec", 0.3048),
					("m/sqsec", 1.0)
				}
			},
			{
				PhysicalQuantities.Masscontent,
				new List<(string, double)>
				{
					("kg/kg_dry", 1.0),
					("lb/lb_dry", 1.0),
					("kg/kg_dry", 1.0)
				}
			},
			{
				PhysicalQuantities.AreaSqTime,
				new List<(string, double)>
				{
					("sqm/sqsec", 1.0),
					("sqft/sqsec", 0.09290304),
					("sqm/sqsec", 1.0),
					("sqmm/sqsec", 1E-06),
					("sqin/sqsec", 0.00064516)
				}
			},
			{
				PhysicalQuantities.MoleArea,
				new List<(string, double)>
				{
					("sqm/kmol", 1.0),
					("sqft/lbmol", 0.204816143622522),
					("sqm/kmol", 1.0),
					("sqm/mol", 1000.0),
					("sqft/mol", 92.90304),
					("sqcm/mol", 0.1),
					("sqin/mol", 0.64516),
					("sqmm/mol", 0.001),
					("sqft/kmol", 0.09290304),
					("sqcm/kmol", 0.0001),
					("sqin/kmol", 0.00064516),
					("sqmm/kmol", 1E-06),
					("sqin/lbmol", 0.00142233433071196)
				}
			},
			{
				PhysicalQuantities.WeirLoad,
				new List<(string, double)>
				{
					("cum/sec-meter", 1.0),
					("gpm/ft", 0.0002069917),
					("cum/hr-meter", 0.000277778),
					("cuft/min-ft", 0.00154839),
					("l/hr-meter", 2.77777777777778E-07),
					("cc/sec-cm", 0.0001),
					("cuft/hr-ft", 2.58064E-05),
					("gpm/in", 0.002483881)
				}
			},
			{
				PhysicalQuantities.DowncomerLd,
				new List<(string, double)>
				{
					("cum/sec/sqm", 1.0),
					("gpm/sqft", 0.000679098),
					("cum/hr/sqm", 0.000277778),
					("l/min/sqm", 1.66667E-05),
					("cuft/sec/sqft", 0.3048),
					("cuft/min/sqft", 0.00508),
					("l/hr/sqm", 2.77778333333333E-07),
					("cc/s/sqcm", 0.01),
					("cuft/hr/sqft", 8.4666667E-05),
					("gpm/sqin", 0.0977905868)
				}
			},
			{
				PhysicalQuantities.ShortLength,
				new List<(string, double)>
				{
					("meter", 1.0),
					("ft", 0.3048),
					("meter", 1.0),
					("cm", 0.01),
					("in", 0.0254),
					("mu", 1E-06),
					("mm", 0.001),
					("mile", 1609.344),
					("km", 1000.0),
					("angstrom", 1E-10),
					("Mft", 304.8),
					("micron", 1E-06)
				}
			},
			{
				PhysicalQuantities.MoleWeight,
				new List<(string, double)>
				{
					("g/mol", 1.0),
					("lb/lbmol", 1.0),
					("kg/kmol", 1.0),
					("g/kmol", 0.001),
					("kg/mol", 1000.0)
				}
			},
			{
				PhysicalQuantities.SquareRootPressure,
				new List<(string, double)>
				{
					("sqrt(pa)", 1.0),
					("ft/s-sqrt(lb/cuft)", 1.21991),
					("sqrt(atm)", 318.3158808),
					("sqrt(N/sqm)", 1.0),
					("sqrt(psia)", 83.03467525)
				}
			},
			{
				PhysicalQuantities.MassFlowPerArea,
				new List<(string, double)>
				{
					("kg/sec-sqm", 1.0),
					("lb/hr-sqft", 0.00135622989899529),
					("kg/hr-sqm", 0.000277777777777778),
					("lb/sec-sqft", 4.88242763638305)
				}
			},
			{
				PhysicalQuantities.VolumeGFlow,
				new List<(string, double)>
				{
					("cum/sec", 1.0),
					("cuft/hr", 7.86579072E-06),
					("l/min", 1.66666666666667E-05),
					("gal/min", 6.30901964E-05),
					("gal/hr", 1.05150327333333E-06),
					("bbl/day", 1.84013072833333E-06),
					("cum/hr", 0.000277777777777778),
					("cuft/min", 0.0004719474432),
					("bbl/hr", 4.416313748E-05),
					("cuft/sec", 0.028316846592),
					("cum/day", 1.15740740740741E-05),
					("cum/year", 3.16880878140289E-08),
					("l/hr", 2.77777777777778E-07),
					("kbbl/day", 0.00184013072833333),
					("MMcuft/hr", 7.86579072),
					("MMcuft/day", 0.32774128),
					("Mcuft/day", 0.00032774128),
					("l/sec", 0.001),
					("l/day", 1.15740740740741E-08),
					("cum/min", 0.0166666666666667),
					("kcum/sec", 1000.0),
					("kcum/hr", 0.277777777777778),
					("kcum/day", 0.0115740740740741),
					("Mcum/sec", 1000000.0),
					("Mcum/hr", 277.777777777778),
					("Mcum/day", 11.5740740740741),
					("ACFM", 0.0004719474432),
					("cuft/day", 3.2774128E-07),
					("Mcuft/min", 0.4719474432),
					("Mcuft/hr", 0.00786579072),
					("MMcuft/hr", 7.86579072),
					("Mgal/min", 0.0630901964),
					("MMgal/min", 63.0901964),
					("Mgal/hr", 0.00105150327333333),
					("MMgal/hr", 1.05150327333333),
					("Mbbl/hr", 0.04416313748),
					("MMbbl/hr", 44.16313748),
					("Mbbl/day", 0.00184013072833333),
					("MMbbl/day", 1.84013072833333),
					("cum/oper-year", 3.16880878140289E-08)
				}
			},
			{
				PhysicalQuantities.Resistance,
				new List<(string, double)>
				{
					("ohm", 1.0),
					("ohm", 1.0),
					("ohm", 1.0),
					("kohm", 1000.0),
					("megaohm", 1000000.0),
					("mohm", 0.001),
					("microohm", 1E-06)
				}
			},
			{
				PhysicalQuantities.VelocityFlux,
				new List<(string, double)>
				{
					("m/sec", 1.0),
					("ft/sec", 0.3048),
					("m/sec", 1.0),
					("mile/hr", 0.44704),
					("km/hr", 0.277777777777778),
					("ft/min", 0.00508),
					("cum/sqm-sec", 1.0),
					("cuft/sqft-sec", 0.3048),
					("l/sqm-sec", 0.001),
					("gal/sqft-min", 0.000679097222222222)
				}
			},
			{
				PhysicalQuantities.MassContRate,
				new List<(string, double)>
				{
					("kg/kg_dry-sec", 1.0),
					("lb/lb_dry-sec", 1.0),
					("kg/kg_dry-sec", 1.0),
					("kg/kg_dry-min", 0.0166666666666667),
					("kg/kg_dry-hr", 0.000277777777777778),
					("lb/lb_dry-min", 0.0166666666666667),
					("lb/lb_dry-hr", 0.000277777777777778)
				}
			},
			{
				PhysicalQuantities.GrowthRate,
				new List<(string, double)>
				{
					("m/sec", 1.0),
					("in/sec", 0.0254),
					("m/sec", 1.0),
					("cm/sec", 0.01),
					("mm/sec", 0.001),
					("mu/sec", 1E-06),
					("m/min", 0.0166666666666667),
					("cm/min", 0.000166666666666667),
					("mm/min", 1.66666666666667E-05),
					("mu/min", 1.66666666666667E-08),
					("in/min", 0.000423333333333333),
					("m/hr", 0.000277777777777778),
					("cm/hr", 2.77777777777778E-06),
					("mm/hr", 2.77777777777778E-07),
					("mu/hr", 2.77777777777778E-10),
					("in/min", 7.05555555555556E-06)
				}
			}
		};

		public static double Offset(PhysicalQuantities physicalQuantity, int column)
		{
			if (physicalQuantity == PhysicalQuantities.Temperature)
			{
				if (column == 1)
				{
					return 255.372222222222;
				}
				if (column == 3)
				{
					return 273.15;
				}
			}
			return 0.0;
		}
	}
	public static class HollerithUtility
	{
		private static readonly ASCIIEncoding Encoding = new ASCIIEncoding();

		public static string ToString(RawInteger integer)
		{
			return ToString((int)(long)integer);
		}

		public static string ToString(params object[] list)
		{
			string text = string.Empty;
			for (int i = 0; i < list.Length; i++)
			{
				text += ToString((int)list[i]);
			}
			return text;
		}

		public static string ToString(int integer)
		{
			if (integer < 538976288 || integer > 2139062143)
			{
				return "";
			}
			char c = (char)(integer & 0xFF);
			char c2 = (char)((uint)(integer & 0xFF00) / 256u);
			char c3 = (char)((uint)(integer & 0xFF0000) / 65536u);
			char c4 = (char)((uint)(integer & -16777216) / 16777216u);
			return $"{c}{c2}{c3}{c4}";
		}

		public static string ToString(long integer)
		{
			return ToString((int)integer);
		}

		public static string ToString(IEnumerable<RawInteger> ints)
		{
			return string.Join("", ints.Select(ToString));
		}

		public static string ToString(IEnumerable<int> ints)
		{
			return string.Join("", ints.Select(ToString));
		}

		public static List<RawInteger> ToIntegers(string str, char pad, int? numWords = null)
		{
			int num;
			byte[] array;
			List<RawInteger> list;
			int k;
			num = numWords ?? ((str.Length + 3) / 4);
			array = new byte[num * 8];
			for (int i = 0; i < num; i++)
			{
				int num2 = i * 4;
				int num3 = Math.Min(4, Math.Abs(str.Length - num2));
				int num4 = i * 8;
				if (num2 < str.Length)
				{
					Encoding.GetBytes(str, num2, num3, array, num4);
				}
				else
				{
					num3 = 0;
				}
				num4 += num3;
				int num5 = (i + 1) * 8;
				for (int j = num4; j < num5; j++)
				{
					array[j] = (byte)pad;
				}
			}
			list = new List<RawInteger>(num);
			for (k = 0; k < array.Length; k += 8)
			{
				list.Add(BitConverter.ToInt64(array, k));
			}
			return list;
		}
	}
	public static class WordUtility
	{
		public static RawInteger FirstWord(string name)
		{
			return GetWord(name, 0);
		}

		public static RawInteger SecondWord(string name)
		{
			return GetWord(name, 1);
		}

		public static RawInteger GetWord(string name, int index, char pad = ' ')
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(name);
			while (stringBuilder.Length < 8)
			{
				stringBuilder.Append(" ");
			}
			return HollerithUtility.ToIntegers(stringBuilder.ToString(), pad)[index];
		}
	}
}
