# AspenTech.NGP.DataManagement.decompiled.cs

Source: editable/AspenTech.NGP.DataManagement.decompiled.cs

Source SHA-256: eb5c0796398508ab9965be2cd24a125cfbafa90b9e5ee702fabce9f94bf1b4f0
