using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;
using AspenTech.NGP.Infrastructure;
using Microsoft.CodeAnalysis;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: ComVisible(false)]
[assembly: Guid("f577cc32-7010-4dc5-9feb-d4fbd1412bf8")]
[assembly: AssemblyTitle("Database Management")]
[assembly: AssemblyFileVersion("41.0.0.39")]
[assembly: AssemblyProduct("Plex Data Management (NGP)")]
[assembly: AssemblyCopyright("Copyright © AspenTech Corporation 2025")]
[assembly: AssemblyTrademark("AspenTech is a registered trademark of AspenTech Corporation")]
[assembly: AssemblyCompany("AspenTech Corporation")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
[assembly: AssemblyVersion("41.0.0.0")]
[module: UnverifiableCode]

namespace Microsoft.CodeAnalysis
{
	[CompilerGenerated]
	[Microsoft.CodeAnalysis.Embedded]
	internal sealed class EmbeddedAttribute : Attribute
	{
	}
}
namespace System.Runtime.CompilerServices
{
	[CompilerGenerated]
	[Microsoft.CodeAnalysis.Embedded]
	[AttributeUsage(AttributeTargets.Module, AllowMultiple = false, Inherited = false)]
	internal sealed class RefSafetyRulesAttribute : Attribute
	{
		public readonly int Version;

		public RefSafetyRulesAttribute(int P_0)
		{
			Version = P_0;
		}
	}
}
namespace Aspentech.NGP.DataManagement
{
	internal static class Constants
	{
		public const int IntegerSizeInBytes = 8;

		public const int DoubleSizeInBytes = 8;

		public const int IntegersPerDouble = 1;

		public const int HundredMillion = 100000000;
	}
}
namespace AspenTech.NGP
{
	public class AssemblyInfo
	{
		public const string ProductName = "Plex Data Management (NGP)";

		public const string CompanyName = "AspenTech Corporation";

		public const string LegalTrademark = "AspenTech is a registered trademark of AspenTech Corporation";

		public const string LegalCopyright = "Copyright © AspenTech Corporation 2025";

		public const string DeveloperVersion = "41.0";

		public const string DllVersion = "41.0.0.39";

		public const string ReleaseVersion = "V15";

		public const string Name = "";

		public const string Title = "";

		public const string Description = "";

		public const string ProductNameAndVersion = "Plex Data Management (NGP) V15";

		public const short AssemblyCopyrightFrom = 2013;

		public const short AssemblyCopyrightTo = 2025;

		public const string AssemblyCopyrightFrom_string = "2013";

		public const string AssemblyCopyrightTo_string = "2025";
	}
}
namespace AspenTech.NGP.DataManagement
{
	internal class BeadData : IBeadData, IBeadRealData, IEquatable<IBeadData>
	{
		private readonly IPlexBead _plexBead;

		public IntPtr IntLocation => _plexBead.IntLocation;

		public IntPtr DoubleLocation => _plexBead.DoubleLocation;

		public BeadId Id => _plexBead.Id;

		public int IntSize => _plexBead.IntSize;

		public int DoubleSize => _plexBead.DoubleSize;

		public BeadType BeadType => _plexBead.BeadType;

		public RawInteger this[int index]
		{
			get
			{
				return GetInt(index);
			}
			set
			{
				SetInt(index, value);
			}
		}

		double IBeadRealData.this[int index]
		{
			get
			{
				return Helper.GetDoublePlexValueAtIndex(_plexBead.DoubleLocation, index);
			}
			set
			{
				Helper.SetDoublePlexValueAtIndex(_plexBead.DoubleLocation, index, value);
			}
		}

		internal BeadData(IPlexBead plexBead, int FileNumber)
		{
			_plexBead = plexBead;
		}

		public int[] GetInts(int index, int range)
		{
			if (index >= IntSize || index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (index + range > IntSize || range < 0)
			{
				throw new ArgumentOutOfRangeException("range");
			}
			int[] array = new int[range];
			IntPtr ptr = IntPtr.Add(_plexBead.IntLocation, index * 8);
			for (int i = 0; i < range; i++)
			{
				array[i] = (int)Marshal.ReadInt64(ptr, i * 8);
			}
			return array;
		}

		public double[] GetReals(int index, int range)
		{
			if (index >= DoubleSize || index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (index + range > DoubleSize || range < 0)
			{
				throw new ArgumentOutOfRangeException("range");
			}
			double[] array = new double[range];
			IntPtr.Add(_plexBead.DoubleLocation, index * 8);
			for (int i = 0; i < range; i++)
			{
				array[i] = ((IBeadRealData)this)[i];
			}
			return array;
		}

		public int GetInt(int index)
		{
			if (index >= IntSize || index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			return (int)Marshal.ReadInt64(_plexBead.IntLocation, index * 8);
		}

		public BeadId GetIntBead(int index)
		{
			if (index >= IntSize || index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			return new BeadId((int)Marshal.ReadInt64(_plexBead.IntLocation, index * 8), _plexBead.FileNumber);
		}

		public double[] GetDoubleArray(int index, int range)
		{
			if (index >= IntSize + DoubleSize || index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (index + range > IntSize + DoubleSize || range < 0)
			{
				throw new ArgumentOutOfRangeException("range");
			}
			double[] array = new double[range];
			IntPtr intPtr = IntPtr.Add(_plexBead.DoubleLocation, index * 8);
			for (int i = 0; i < range; i++)
			{
				array[i] = (double)Marshal.PtrToStructure(intPtr, typeof(double));
				intPtr = IntPtr.Add(intPtr, 8);
			}
			return array;
		}

		public string GetString(int index, int range = 1)
		{
			if (index >= IntSize || index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (index + range > IntSize || range < 0)
			{
				throw new ArgumentOutOfRangeException("range");
			}
			RawInteger[] array = new RawInteger[range];
			for (int i = 0; i < range; i++)
			{
				array[i] = Marshal.ReadInt64(_plexBead.IntLocation, (index + i) * 8);
			}
			return HollerithUtility.ToString(array);
		}

		public void SetInts(int index, IEnumerable<int> values)
		{
			if (index >= IntSize || index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			foreach (int value in values)
			{
				if (index == IntSize)
				{
					throw new ArgumentOutOfRangeException("values");
				}
				Marshal.WriteInt64(_plexBead.IntLocation, index * 8, value);
				index++;
			}
		}

		public void SetInt(int index, RawInteger value)
		{
			if (index >= IntSize || index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			Marshal.WriteInt64(_plexBead.IntLocation, index * 8, value);
		}

		public int SetString(int index, string value, int? numWords = null, char pad = ' ')
		{
			if (index >= IntSize || index < 0)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			if (numWords.HasValue && index + numWords > IntSize)
			{
				throw new ArgumentOutOfRangeException("numWords");
			}
			List<RawInteger> list = HollerithUtility.ToIntegers(value, pad, numWords);
			if (index + list.Count > IntSize)
			{
				throw new ArgumentOutOfRangeException("value");
			}
			int num = 0;
			IntPtr ptr = IntPtr.Add(_plexBead.IntLocation, index * 8);
			foreach (RawInteger item in list)
			{
				Marshal.WriteInt64(ptr, num * 8, item);
				num++;
			}
			return list.Count;
		}

		public bool Equals(IBeadData other)
		{
			if (other != null)
			{
				return Id == other.Id;
			}
			return false;
		}

		public override bool Equals(object obj)
		{
			IBeadData other = obj as IBeadData;
			return Equals(other);
		}

		public override int GetHashCode()
		{
			return Id.GetHashCode();
		}
	}
	public class DictionaryWithRecycledKeys<T>
	{
		private readonly Dictionary<int, T> _dictionary = new Dictionary<int, T>();

		private readonly Queue<int> _keysToReuse = new Queue<int>();

		protected IReadOnlyDictionary<int, T> Dictionary => _dictionary;

		protected IEnumerable<int> Keys => _dictionary.Keys;

		protected int PeekNewKey()
		{
			if (!_keysToReuse.Any())
			{
				return BrandNewKey();
			}
			return _keysToReuse.Peek();
		}

		protected int Add(T value)
		{
			int newKey = GetNewKey();
			_dictionary.Add(newKey, value);
			return newKey;
		}

		protected void Remove(int key)
		{
			_dictionary.Remove(key);
			_keysToReuse.Enqueue(key);
		}

		protected bool ContainsKey(int key)
		{
			return _dictionary.ContainsKey(key);
		}

		protected void Clear()
		{
			_keysToReuse.Clear();
			_dictionary.Clear();
		}

		private int GetNewKey()
		{
			if (!_keysToReuse.Any())
			{
				return BrandNewKey();
			}
			return _keysToReuse.Dequeue();
		}

		private int BrandNewKey()
		{
			return _dictionary.Count + 1;
		}
	}
	internal class PlexBead : IFreeablePlexBead, IPlexBead, IDisposable
	{
		private int _doubleOffset;

		private int _totalSize;

		private IntPtr _memoryLocation;

		private bool _alreadyDisposed;

		public int FileNumber { get; }

		public BeadId Id { get; }

		public IntPtr IntLocation => _memoryLocation;

		public IntPtr DoubleLocation => IntPtr.Add(_memoryLocation, _doubleOffset);

		public BeadType BeadType
		{
			get
			{
				if (DoubleSize > 0)
				{
					if (IntSize <= 0)
					{
						return BeadType.Double;
					}
					return BeadType.Mixed;
				}
				return BeadType.Int;
			}
		}

		public int DoubleSize { get; private set; }

		public int IntSize { get; private set; }

		[DllImport("AspenTech_NGP_Managed2Unmanaged")]
		private static extern void M2UnmBridgeAPI_ZeroMemory(IntPtr dst, UIntPtr length);

		internal PlexBead(BeadId id, int numberOfInts, int numberOfDoubles)
		{
			Id = id;
			FileNumber = id.FileNumber;
			AllocateMemory(numberOfInts, numberOfDoubles);
		}

		~PlexBead()
		{
			Dispose(disposing: false);
		}

		private void AllocateMemory(int numInts, int numDoubles, bool zeroInit = true)
		{
			IntSize = numInts;
			DoubleSize = numDoubles;
			int num = (1 - numInts % 1) % 1;
			_doubleOffset = 8 * (numInts + num);
			_totalSize = _doubleOffset + 8 * numDoubles;
			_memoryLocation = Marshal.AllocHGlobal(_totalSize);
			if (zeroInit)
			{
				M2UnmBridgeAPI_ZeroMemory(_memoryLocation, (UIntPtr)(ulong)_totalSize);
			}
		}

		public unsafe bool Resize(int numberOfInts, int numberOfDoubles, bool copyData = true)
		{
			IntPtr memoryLocation = _memoryLocation;
			int doubleOffset = _doubleOffset;
			int intSize = IntSize;
			int doubleSize = DoubleSize;
			AllocateMemory(numberOfInts, numberOfDoubles, !copyData);
			RawInteger* ptr = (RawInteger*)memoryLocation.ToPointer();
			RawInteger* ptr2 = (RawInteger*)_memoryLocation.ToPointer();
			for (int i = 0; i < IntSize; i++)
			{
				if (i < intSize && copyData)
				{
					ptr2[i] = ptr[i];
				}
				else
				{
					ptr2[i] = 0L;
				}
			}
			double* ptr3 = (double*)(ptr + doubleOffset);
			double* ptr4 = (double*)(ptr2 + _doubleOffset);
			for (int j = 0; j < DoubleSize; j++)
			{
				if (j < doubleSize && copyData)
				{
					ptr4[j] = ptr3[j];
				}
				else
				{
					ptr4[j] = 0.0;
				}
			}
			Marshal.FreeHGlobal(memoryLocation);
			if (copyData && IntSize >= intSize)
			{
				return DoubleSize >= doubleSize;
			}
			return false;
		}

		public IBeadData CreateBeadData()
		{
			return PlexFactory.Data(this, FileNumber);
		}

		public void Free()
		{
			_totalSize = 0;
			IntSize = 0;
			DoubleSize = 0;
			Marshal.FreeHGlobal(_memoryLocation);
			_memoryLocation = IntPtr.Zero;
		}

		public void Dispose()
		{
			Dispose(disposing: true);
			GC.SuppressFinalize(this);
		}

		protected virtual void Dispose(bool disposing)
		{
			if (_alreadyDisposed)
			{
				return;
			}
			_alreadyDisposed = true;
			ReleaseUnmanagedResources();
			if (disposing)
			{
				ReleaseManagedResources();
			}
		}

		private void ReleaseManagedResources()
		{
		}

		private void ReleaseUnmanagedResources()
		{
			if (_totalSize > 0)
			{
				_totalSize = 0;
				Marshal.FreeHGlobal(_memoryLocation);
				_memoryLocation = IntPtr.Zero;
			}
		}
	}
	public class PlexFactory : IPlexFactory
	{
		private static volatile IPlexFactory _instance;

		private static readonly object InstanceLock = new object();

		public static IPlexFactory Instance
		{
			get
			{
				lock (InstanceLock)
				{
					return _instance ?? (_instance = new PlexFactory());
				}
			}
		}

		private PlexFactory()
		{
		}

		public IPlexFileCollection CreatePlexFileCollection()
		{
			return new PlexFileCollection();
		}

		public ICloseablePlexFile CreatePlexFile(int fileNumber)
		{
			return new PlexFile(fileNumber);
		}

		public ICloseableBeadFile CreateBeadFile(int fileNumber)
		{
			return new PlexFile(fileNumber);
		}

		internal static IBeadData Data(IPlexBead plexBead, int fileNumber)
		{
			return new BeadData(plexBead, fileNumber);
		}

		public static void Reset()
		{
			lock (InstanceLock)
			{
				_instance = null;
			}
		}
	}
	internal class PlexFile : DictionaryWithRecycledKeys<IFreeablePlexBead>, ICloseablePlexFile, IPlexFile, ICloseableBeadFile, IBeadFile
	{
		internal PlexFile(int fileNumber)
		{
			FileNumber = fileNumber;
		}

		~PlexFile()
		{
		}

		public int FileNumber { get; }

		public IBeadData this[BeadId id] => base.Dictionary[id.BeadNumber].CreateBeadData();

		IBeadData IBeadFile.this[int beadnumber] => base.Dictionary[beadnumber].CreateBeadData();

		public IEnumerable<BeadId> BeadIds => base.Keys.Select((int key) => new BeadId(key, FileNumber));

		public IPlexBead this[int i] => base.Dictionary[i];

		public IPlexBead GetPlexBeadOrNull(int i)
		{
			if (!base.Dictionary.ContainsKey(i))
			{
				return null;
			}
			return base.Dictionary[i];
		}

		public void DeleteBead(BeadId id)
		{
			if (!Contains(id))
			{
				return;
			}
			base.Dictionary[id.BeadNumber].Free();
			Remove(id.BeadNumber);
		}

		public BeadId CreateNewBead(int intLength, int doubleLength)
		{
			if (base.Dictionary.Count == 100000000)
			{
				throw new InvalidOperationException("Too many beads in a file");
			}
			BeadId beadId = new BeadId(PeekNewKey(), FileNumber);
			Add(new PlexBead(beadId, intLength, doubleLength));
			return beadId;
		}

		public IBeadData CreateBead(int intLength, int doubleLength)
		{
			BeadId id = CreateNewBead(intLength, doubleLength);
			return this[id];
		}

		public void Close()
		{
			Clear();
		}

		public new void Clear()
		{
			foreach (IFreeablePlexBead value in base.Dictionary.Values)
			{
				value.Free();
			}
			base.Clear();
		}

		public bool Open(IOpenPlexFile parser, string path)
		{
			try
			{
				parser.Open(this, path);
			}
			catch
			{
				Close();
				return false;
			}
			return true;
		}

		public bool Contains(int i)
		{
			return base.Dictionary.ContainsKey(i);
		}

		public bool Contains(BeadId id)
		{
			if (ContainsKey(id.BeadNumber))
			{
				return id.FileNumber == FileNumber;
			}
			return false;
		}
	}
	internal class PlexFileCollection : DictionaryWithRecycledKeys<ICloseablePlexFile>, IPlexFileCollection
	{
		public IPlexFile this[int fileNumber] => base.Dictionary[fileNumber];

		public IPlexBead this[BeadId id] => base.Dictionary[id.FileNumber][id.BeadNumber];

		public IEnumerable<int> FileNumbers => base.Keys;

		public int CreateFile()
		{
			return Add(PlexFactory.Instance.CreatePlexFile(PeekNewKey()));
		}

		public void CloseFile(int fileNumber)
		{
			base.Dictionary[fileNumber].Close();
			Remove(fileNumber);
		}

		public void CloseAll()
		{
			foreach (int item in base.Dictionary.Keys.ToList())
			{
				CloseFile(item);
			}
			Clear();
		}
	}
}
