using System;
using System.Collections;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Runtime.Versioning;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("AspenTech")]
[assembly: AssemblyProduct("Aspen Properties Enterprise Database V15")]
[assembly: AssemblyCopyright("Copyright © 2025 Aspen Technology, Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("41.0.0.11")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("..\\..\\..\\..\\aped.snk")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyTitle("Aspen Properties APED Database Objects")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.1")]
namespace AspenTech.APED;

[Serializable]
[ClassInterface(ClassInterfaceType.None)]
public class InteractionParameterDatabankInformationObject : DatabaseObject, IDatabaseObject, IDatabaseObjectIdentity, ISerializable
{
	[Serializable]
	public struct GammaModelParameterInformation
	{
		public string ParameterName;

		public string VaporModelName;

		public string GammaModelName;
	}

	private ArrayList myParameterInfoList;

	public string DatabankName
	{
		get
		{
			return base.Identity;
		}
		set
		{
			base.Identity = value;
		}
	}

	public ArrayList ParameterInfoList
	{
		get
		{
			return myParameterInfoList;
		}
		set
		{
			myParameterInfoList = value;
		}
	}

	public override DatabaseObjectType ObjectType => DatabaseObjectType.InteractionParameterDatabankInformation;

	public InteractionParameterDatabankInformationObject()
	{
	}

	public InteractionParameterDatabankInformationObject(string DatabankName, GammaModelParameterInformation[] ParameterInfo)
		: base(DatabankName, null)
	{
		myParameterInfoList = new ArrayList();
		if (ParameterInfo != null)
		{
			myParameterInfoList.AddRange(ParameterInfo);
		}
	}

	protected InteractionParameterDatabankInformationObject(SerializationInfo info, StreamingContext context)
		: base(info, context)
	{
		myParameterInfoList = (ArrayList)info.GetValue("parameterInfoList", typeof(ArrayList));
	}

	public static IDatabaseObject ResolveMoniker(IDatabaseObjectMoniker moniker)
	{
		ISundryDataManager sundryDataManager;
		if (!(moniker.Database is ISupportsSundryData) || (sundryDataManager = (moniker.Database as ISupportsSundryData).SundryDataManager) == null)
		{
			throw new GatewayException("The database does not support sundry data or an error occurred referencing the sundry data manager");
		}
		return sundryDataManager.GetItem(moniker.Identity);
	}

	public override void GetObjectData(SerializationInfo info, StreamingContext context)
	{
		base.GetObjectData(info, context);
		info.AddValue("parameterInfoList", myParameterInfoList);
	}

	void IDatabaseObject.GetMoniker(out IDatabaseObjectMoniker Moniker)
	{
		IDatabaseObjectIdentity identity = this;
		Moniker = new DatabaseObjectMoniker(identity.Database, identity.ObjectType, identity.Identity, ResolveMoniker);
	}
}
[Serializable]
[ClassInterface(ClassInterfaceType.None)]
public class REGRESS_LIMITS : IApedIpRegressLimits
{
	public double upper;

	public double lower;

	public double Upper
	{
		get
		{
			return upper;
		}
		set
		{
			upper = value;
		}
	}

	public double Lower
	{
		get
		{
			return lower;
		}
		set
		{
			lower = value;
		}
	}

	public bool IsEqual(IApedIpRegressLimits rLim)
	{
		if (rLim.Upper == upper && rLim.Lower == lower)
		{
			return true;
		}
		return false;
	}
}
[Serializable]
[ClassInterface(ClassInterfaceType.None)]
public class REGRESS_ERRORS : IApedIpRegressDeviations
{
	public double npt;

	public double aard;

	public double aad;

	public double maxd;

	public double Npoints
	{
		get
		{
			return npt;
		}
		set
		{
			npt = value;
		}
	}

	public double Aard
	{
		get
		{
			return aard;
		}
		set
		{
			aard = value;
		}
	}

	public double Aad
	{
		get
		{
			return aad;
		}
		set
		{
			aad = value;
		}
	}

	public double MaxDeviation
	{
		get
		{
			return maxd;
		}
		set
		{
			maxd = value;
		}
	}

	public bool IsEqual(IApedIpRegressDeviations rDev)
	{
		if (rDev.Aard == aard && rDev.Aad == aad && rDev.Npoints == npt && rDev.MaxDeviation == maxd)
		{
			return true;
		}
		return false;
	}
}
[Serializable]
[ClassInterface(ClassInterfaceType.None)]
public abstract class ALL_Regparams
{
	public double sigma;

	public double valcon;

	public string tUnit;

	public string pUnit;

	protected void CopyDeviationInfoFromInterface(REGRESS_ERRORS err, IApedIpRegressDeviations interfaceDevs)
	{
		err.aad = interfaceDevs.Aad;
		err.aard = interfaceDevs.Aard;
		err.npt = interfaceDevs.Npoints;
		err.maxd = interfaceDevs.MaxDeviation;
	}

	protected void CopyLimitInfoFromInterface(REGRESS_LIMITS lim, IApedIpRegressLimits interfaceLims)
	{
		lim.lower = interfaceLims.Lower;
		lim.upper = interfaceLims.Upper;
	}
}
[Serializable]
[ClassInterface(ClassInterfaceType.None)]
public class NIST_Regparams : ALL_Regparams, IApedNistIpRegressHelpInfo
{
	public REGRESS_LIMITS temp_l;

	public REGRESS_LIMITS pres_l;

	public REGRESS_LIMITS x_l;

	public ArrayList regressErrorList;

	public ArrayList propertyNameList;

	public ArrayList citationNameList;

	public IApedIpRegressLimits Temp_Limits
	{
		get
		{
			return temp_l;
		}
		set
		{
			CopyLimitInfoFromInterface(temp_l, value);
		}
	}

	public IApedIpRegressLimits Pres_Limits
	{
		get
		{
			return pres_l;
		}
		set
		{
			CopyLimitInfoFromInterface(pres_l, value);
		}
	}

	public IApedIpRegressLimits X_Limits
	{
		get
		{
			return x_l;
		}
		set
		{
			CopyLimitInfoFromInterface(x_l, value);
		}
	}

	public double Sigma
	{
		get
		{
			return sigma;
		}
		set
		{
			sigma = value;
		}
	}

	public double Valcon
	{
		get
		{
			return valcon;
		}
		set
		{
			valcon = value;
		}
	}

	public string TUnit
	{
		get
		{
			return tUnit;
		}
		set
		{
			tUnit = value;
		}
	}

	public string PUnit
	{
		get
		{
			return pUnit;
		}
		set
		{
			pUnit = value;
		}
	}

	public NIST_Regparams()
	{
		temp_l = new REGRESS_LIMITS();
		pres_l = new REGRESS_LIMITS();
		x_l = new REGRESS_LIMITS();
		regressErrorList = new ArrayList();
		propertyNameList = new ArrayList();
		if (citationNameList == null)
		{
			citationNameList = new ArrayList();
		}
		tUnit = "C";
		pUnit = "kPa";
	}

	public void AddPropertyName(string propname)
	{
		propertyNameList.Add(propname);
	}

	public string GetPropertyName(int i)
	{
		return (string)propertyNameList[i];
	}

	public void AddRegressErrorItem(double npt, double aard, double aad, double maxd)
	{
		REGRESS_ERRORS rEGRESS_ERRORS = new REGRESS_ERRORS();
		rEGRESS_ERRORS.npt = npt;
		rEGRESS_ERRORS.aard = aard;
		rEGRESS_ERRORS.aad = aad;
		rEGRESS_ERRORS.maxd = maxd;
		regressErrorList.Add(rEGRESS_ERRORS);
	}

	public int Size()
	{
		return propertyNameList.Count;
	}

	public IApedIpRegressDeviations GetRegErrorAt(int i)
	{
		return (IApedIpRegressDeviations)regressErrorList[i];
	}

	public bool IsEqual(IApedNistIpRegressHelpInfo hInfo)
	{
		if (sigma == hInfo.Sigma && valcon == hInfo.Valcon && temp_l.IsEqual(hInfo.Temp_Limits) && pres_l.IsEqual(hInfo.Pres_Limits) && x_l.IsEqual(hInfo.X_Limits))
		{
			return true;
		}
		return false;
	}

	public void SetupCitation(IDatabank iDatabank, string strParaName, string strCompI, string strCompJ)
	{
		if (citationNameList != null && citationNameList.Count > 0)
		{
			citationNameList.Clear();
		}
		if (citationNameList == null)
		{
			citationNameList = new ArrayList();
		}
		Database database = (Database)iDatabank.Database;
		if (database == null)
		{
			return;
		}
		ICitationManager citationManager = database.CitationManager;
		ICompoundManager compoundManager = database.CompoundManager;
		IIdentifierValue identValue = null;
		if (citationManager == null || compoundManager == null)
		{
			return;
		}
		int num = 0;
		int num2 = 0;
		int duoId = -1;
		bool isReversed = false;
		compoundManager.GetCompoundIdentifier(strCompI, "NAME", "CompoundIndex", out identValue);
		if (identValue == null)
		{
			compoundManager.GetCompoundIdentifier(strCompI, "ALIAS", "CompoundIndex", out identValue);
			if (identValue == null)
			{
				return;
			}
		}
		num = identValue.Compound.Id;
		compoundManager.GetCompoundIdentifier(strCompJ, "NAME", "CompoundIndex", out identValue);
		if (identValue == null)
		{
			compoundManager.GetCompoundIdentifier(strCompJ, "ALIAS", "CompoundIndex", out identValue);
			if (identValue == null)
			{
				return;
			}
		}
		num2 = identValue.Compound.Id;
		compoundManager.GetCompoundDuoId(num, num2, addIfMissing: false, out duoId, out isReversed);
		ArrayList citObjLst = new ArrayList();
		citationManager.GetCitation(iDatabank, duoId.ToString(), "CompoundIndex", strParaName, out citObjLst);
		if (citObjLst != null)
		{
			int num3 = 0;
			foreach (ICitation item in citObjLst)
			{
				string value = "[" + (num3 + 1) + "]: " + item.Authors.ToString();
				num3++;
				citationNameList.Add(value);
			}
		}
	}

	public int CitationSize()
	{
		return citationNameList.Count;
	}

	public string GetCitation(int i)
	{
		if (i < citationNameList.Count)
		{
			return (string)citationNameList[i];
		}
		return null;
	}
}
[Serializable]
[ClassInterface(ClassInterfaceType.None)]
public class VLE_Regparams : ALL_Regparams, IApedVleIpRegressHelpInfo
{
	public REGRESS_LIMITS temp_l;

	public REGRESS_LIMITS pres_l;

	public REGRESS_LIMITS x_l;

	public REGRESS_ERRORS temp_e;

	public REGRESS_ERRORS pres_e;

	public REGRESS_ERRORS x_e;

	public double Sigma
	{
		get
		{
			return sigma;
		}
		set
		{
			sigma = value;
		}
	}

	public double Valcon
	{
		get
		{
			return valcon;
		}
		set
		{
			valcon = value;
		}
	}

	public IApedIpRegressLimits Temp_Limits
	{
		get
		{
			return temp_l;
		}
		set
		{
			CopyLimitInfoFromInterface(temp_l, value);
		}
	}

	public IApedIpRegressLimits Pres_Limits
	{
		get
		{
			return pres_l;
		}
		set
		{
			CopyLimitInfoFromInterface(pres_l, value);
		}
	}

	public IApedIpRegressLimits X_Limits
	{
		get
		{
			return x_l;
		}
		set
		{
			CopyLimitInfoFromInterface(x_l, value);
		}
	}

	public IApedIpRegressDeviations Temp_Deviation
	{
		get
		{
			return temp_e;
		}
		set
		{
			CopyDeviationInfoFromInterface(temp_e, value);
		}
	}

	public IApedIpRegressDeviations Pres_Deviation
	{
		get
		{
			return pres_e;
		}
		set
		{
			CopyDeviationInfoFromInterface(pres_e, value);
		}
	}

	public IApedIpRegressDeviations X_Deviation
	{
		get
		{
			return x_e;
		}
		set
		{
			CopyDeviationInfoFromInterface(x_e, value);
		}
	}

	public string TUnit
	{
		get
		{
			return tUnit;
		}
		set
		{
			tUnit = value;
		}
	}

	public string PUnit
	{
		get
		{
			return pUnit;
		}
		set
		{
			pUnit = value;
		}
	}

	public VLE_Regparams()
	{
		temp_l = new REGRESS_LIMITS();
		pres_l = new REGRESS_LIMITS();
		x_l = new REGRESS_LIMITS();
		temp_e = new REGRESS_ERRORS();
		pres_e = new REGRESS_ERRORS();
		x_e = new REGRESS_ERRORS();
		tUnit = "C";
		pUnit = "mmHg";
	}

	public bool IsEqual(IApedVleIpRegressHelpInfo hInfo)
	{
		if (sigma == hInfo.Sigma && valcon == hInfo.Valcon && temp_l.IsEqual(hInfo.Temp_Limits) && pres_l.IsEqual(hInfo.Pres_Limits) && x_l.IsEqual(hInfo.X_Limits) && temp_e.IsEqual(hInfo.Temp_Deviation) && pres_e.IsEqual(hInfo.Pres_Deviation) && x_e.IsEqual(hInfo.X_Deviation))
		{
			return true;
		}
		return false;
	}
}
[Serializable]
[ClassInterface(ClassInterfaceType.None)]
public class LLE_Regparams : ALL_Regparams, IApedLleIpRegressHelpInfo
{
	public REGRESS_LIMITS temp_l;

	public REGRESS_LIMITS x1_l;

	public REGRESS_LIMITS x2_l;

	public REGRESS_ERRORS x1_e;

	public REGRESS_ERRORS x2_e;

	public double Sigma
	{
		get
		{
			return sigma;
		}
		set
		{
			sigma = value;
		}
	}

	public double Valcon
	{
		get
		{
			return valcon;
		}
		set
		{
			valcon = value;
		}
	}

	public IApedIpRegressLimits Temp_Limits
	{
		get
		{
			return temp_l;
		}
		set
		{
			CopyLimitInfoFromInterface(temp_l, value);
		}
	}

	public IApedIpRegressLimits X1_Limits
	{
		get
		{
			return x1_l;
		}
		set
		{
			CopyLimitInfoFromInterface(x1_l, value);
		}
	}

	public IApedIpRegressLimits X2_Limits
	{
		get
		{
			return x2_l;
		}
		set
		{
			CopyLimitInfoFromInterface(x2_l, value);
		}
	}

	public IApedIpRegressDeviations X1_Deviation
	{
		get
		{
			return x1_e;
		}
		set
		{
			CopyDeviationInfoFromInterface(x1_e, value);
		}
	}

	public IApedIpRegressDeviations X2_Deviation
	{
		get
		{
			return x2_e;
		}
		set
		{
			CopyDeviationInfoFromInterface(x2_e, value);
		}
	}

	public string TUnit
	{
		get
		{
			return tUnit;
		}
		set
		{
			tUnit = value;
		}
	}

	public string PUnit
	{
		get
		{
			return pUnit;
		}
		set
		{
			pUnit = value;
		}
	}

	public LLE_Regparams()
	{
		temp_l = new REGRESS_LIMITS();
		x1_l = new REGRESS_LIMITS();
		x2_l = new REGRESS_LIMITS();
		x1_e = new REGRESS_ERRORS();
		x2_e = new REGRESS_ERRORS();
		tUnit = "C";
		pUnit = "mmHg";
	}

	public bool IsEqual(IApedLleIpRegressHelpInfo hInfo)
	{
		if (sigma == hInfo.Sigma && valcon == hInfo.Valcon && temp_l.IsEqual(hInfo.Temp_Limits) && x1_l.IsEqual(hInfo.X1_Limits) && x2_l.IsEqual(hInfo.X2_Limits) && x1_e.IsEqual(hInfo.X1_Deviation) && x2_e.IsEqual(hInfo.X2_Deviation))
		{
			return true;
		}
		return false;
	}
}
[Serializable]
[ClassInterface(ClassInterfaceType.None)]
public class HENRY_Regparams : ALL_Regparams, IApedHenryIpRegressHelpInfo
{
	public REGRESS_LIMITS temp_l;

	public REGRESS_LIMITS pres_l;

	public REGRESS_LIMITS x_l;

	public REGRESS_LIMITS henry_l;

	public REGRESS_ERRORS henry_e;

	public double Sigma
	{
		get
		{
			return sigma;
		}
		set
		{
			sigma = value;
		}
	}

	public double Valcon
	{
		get
		{
			return valcon;
		}
		set
		{
			valcon = value;
		}
	}

	public IApedIpRegressLimits Temp_Limits
	{
		get
		{
			return temp_l;
		}
		set
		{
			CopyLimitInfoFromInterface(temp_l, value);
		}
	}

	public IApedIpRegressLimits Pres_Limits
	{
		get
		{
			return pres_l;
		}
		set
		{
			CopyLimitInfoFromInterface(pres_l, value);
		}
	}

	public IApedIpRegressLimits X_Limits
	{
		get
		{
			return x_l;
		}
		set
		{
			CopyLimitInfoFromInterface(x_l, value);
		}
	}

	public IApedIpRegressLimits Henry_Limits
	{
		get
		{
			return henry_l;
		}
		set
		{
			CopyLimitInfoFromInterface(henry_l, value);
		}
	}

	public IApedIpRegressDeviations Henry_Deviation
	{
		get
		{
			return henry_e;
		}
		set
		{
			CopyDeviationInfoFromInterface(henry_e, value);
		}
	}

	public string TUnit
	{
		get
		{
			return tUnit;
		}
		set
		{
			tUnit = value;
		}
	}

	public string PUnit
	{
		get
		{
			return pUnit;
		}
		set
		{
			pUnit = value;
		}
	}

	public HENRY_Regparams()
	{
		temp_l = new REGRESS_LIMITS();
		pres_l = new REGRESS_LIMITS();
		x_l = new REGRESS_LIMITS();
		henry_l = new REGRESS_LIMITS();
		henry_e = new REGRESS_ERRORS();
		tUnit = "C";
		pUnit = "mmHg";
	}

	public bool IsEqual(IApedHenryIpRegressHelpInfo hInfo)
	{
		if (sigma == hInfo.Sigma && valcon == hInfo.Valcon && temp_l.IsEqual(hInfo.Temp_Limits) && pres_l.IsEqual(hInfo.Pres_Limits) && x_l.IsEqual(hInfo.X_Limits) && henry_l.IsEqual(hInfo.Henry_Limits) && henry_e.IsEqual(hInfo.Henry_Deviation))
		{
			return true;
		}
		return false;
	}
}
[Serializable]
[ClassInterface(ClassInterfaceType.None)]
public class IpHelpInfoObject : DatabaseObject, IDatabaseObject, IDatabaseObjectIdentity, ISerializable, IIpHelpInfoObject
{
	private IpHelpInfoType myHelpInfoType;

	private ALL_Regparams myHelpInfo;

	private string myFirstCompound;

	public override DatabaseObjectType ObjectType => DatabaseObjectType.IpHelpInfo;

	public IpHelpInfoType ParamType
	{
		get
		{
			return myHelpInfoType;
		}
		set
		{
			myHelpInfoType = value;
		}
	}

	public IApedHenryIpRegressHelpInfo HenryInfo
	{
		get
		{
			if (myHelpInfoType == IpHelpInfoType.Henry && myHelpInfo != null)
			{
				return (HENRY_Regparams)myHelpInfo;
			}
			return null;
		}
		set
		{
			if (myHelpInfoType == IpHelpInfoType.Henry)
			{
				myHelpInfo = (ALL_Regparams)value;
			}
		}
	}

	public IApedVleIpRegressHelpInfo VleInfo
	{
		get
		{
			if (myHelpInfoType == IpHelpInfoType.Vle && myHelpInfo != null)
			{
				return (VLE_Regparams)myHelpInfo;
			}
			return null;
		}
		set
		{
			if (myHelpInfoType == IpHelpInfoType.Vle)
			{
				myHelpInfo = (ALL_Regparams)value;
			}
		}
	}

	public IApedLleIpRegressHelpInfo LleInfo
	{
		get
		{
			if (myHelpInfoType == IpHelpInfoType.Lle && myHelpInfo != null)
			{
				return (LLE_Regparams)myHelpInfo;
			}
			return null;
		}
		set
		{
			if (myHelpInfoType == IpHelpInfoType.Lle)
			{
				myHelpInfo = (ALL_Regparams)value;
			}
		}
	}

	public IApedNistIpRegressHelpInfo NistInfo
	{
		get
		{
			if (myHelpInfoType == IpHelpInfoType.NIST && myHelpInfo != null)
			{
				return (NIST_Regparams)myHelpInfo;
			}
			return null;
		}
		set
		{
			if (myHelpInfoType == IpHelpInfoType.NIST)
			{
				myHelpInfo = (ALL_Regparams)value;
			}
		}
	}

	public string FirstCompound
	{
		get
		{
			return myFirstCompound;
		}
		set
		{
			myFirstCompound = value;
		}
	}

	public IpHelpInfoObject()
	{
	}

	public IpHelpInfoObject(IDatabase Dbase, IpHelpInfoType helpInfoType, string databankName, string parameterName, string compId1, string compId1Type, string compId2, string compId2Type)
	{
		base.Database = Dbase;
		myFirstCompound = compId1;
		base.Identity = CreateIdentifierFromNames(databankName, parameterName, compId1, compId1Type, compId2, compId2Type);
		myHelpInfoType = helpInfoType;
		switch (helpInfoType)
		{
		case IpHelpInfoType.Vle:
			myHelpInfo = new VLE_Regparams();
			break;
		case IpHelpInfoType.Lle:
			myHelpInfo = new LLE_Regparams();
			break;
		case IpHelpInfoType.Henry:
			myHelpInfo = new HENRY_Regparams();
			break;
		case IpHelpInfoType.NIST:
			myHelpInfo = new NIST_Regparams();
			break;
		}
	}

	protected IpHelpInfoObject(SerializationInfo info, StreamingContext context)
		: base(info, context)
	{
		myHelpInfoType = (IpHelpInfoType)info.GetValue("infoType", typeof(IpHelpInfoType));
		switch (myHelpInfoType)
		{
		case IpHelpInfoType.Vle:
			myHelpInfo = (ALL_Regparams)info.GetValue("helpInfo", typeof(VLE_Regparams));
			break;
		case IpHelpInfoType.Lle:
			myHelpInfo = (ALL_Regparams)info.GetValue("helpInfo", typeof(LLE_Regparams));
			break;
		case IpHelpInfoType.Henry:
			myHelpInfo = (ALL_Regparams)info.GetValue("helpInfo", typeof(HENRY_Regparams));
			break;
		case IpHelpInfoType.NIST:
			myHelpInfo = (ALL_Regparams)info.GetValue("helpInfo", typeof(NIST_Regparams));
			break;
		}
		myFirstCompound = (string)info.GetValue("firstComp", typeof(string));
	}

	private string CreateIdentifierFromNames(string databankName, string parameterName, string compId1, string compId1Type, string compId2, string compId2Type)
	{
		string result = "";
		if (databankName == "" || parameterName == "" || compId1 == "" || compId1Type == "" || compId2 == "" || compId2Type == "")
		{
			return result;
		}
		ICompoundManager compoundManager = (base.Database as ISupportsCompounds).CompoundManager;
		compoundManager.GetIdentifier(compId1Type, out var identifier);
		compoundManager.GetIdentifier(compId2Type, out var identifier2);
		if (identifier == null || identifier2 == null)
		{
			return result;
		}
		base.Database.EnumerateDatabanks(out var Databanks);
		try
		{
			IDatabank databank = Databanks[databankName];
		}
		catch
		{
			return result;
		}
		int num = 0;
		int num2 = 0;
		try
		{
			compoundManager.GetCompound(compId1, identifier, out var compound);
			compoundManager.GetCompound(compId2, identifier2, out var compound2);
			if (compound == null || compound2 == null || compound.Compound1Name == "" || compound2.Compound1Name == "")
			{
				return result;
			}
			num = compound.Id;
			num2 = compound2.Id;
			if (num == 0 || num2 == 0)
			{
				return result;
			}
		}
		catch
		{
			return result;
		}
		if (num > num2)
		{
			int num3 = num2;
			num2 = num;
			num = num3;
		}
		result = databankName + "_" + parameterName + "_" + num + "_" + num2;
		return result;
	}

	public static IDatabaseObject ResolveMoniker(IDatabaseObjectMoniker moniker)
	{
		ISundryDataManager sundryDataManager;
		if (!(moniker.Database is ISupportsSundryData) || (sundryDataManager = (moniker.Database as ISupportsSundryData).SundryDataManager) == null)
		{
			throw new GatewayException("The database does not support sundry data or an error occurred referencing the sundry data manager");
		}
		return sundryDataManager.GetItem(moniker.Identity);
	}

	public override void GetObjectData(SerializationInfo info, StreamingContext context)
	{
		base.GetObjectData(info, context);
		info.AddValue("infoType", myHelpInfoType, typeof(IpHelpInfoType));
		switch (myHelpInfoType)
		{
		case IpHelpInfoType.Vle:
			info.AddValue("helpInfo", (VLE_Regparams)myHelpInfo, typeof(VLE_Regparams));
			break;
		case IpHelpInfoType.Lle:
			info.AddValue("helpInfo", (LLE_Regparams)myHelpInfo, typeof(LLE_Regparams));
			break;
		case IpHelpInfoType.Henry:
			info.AddValue("helpInfo", (HENRY_Regparams)myHelpInfo, typeof(HENRY_Regparams));
			break;
		case IpHelpInfoType.NIST:
			info.AddValue("helpInfo", (NIST_Regparams)myHelpInfo, typeof(NIST_Regparams));
			break;
		}
		info.AddValue("firstComp", myFirstCompound, typeof(string));
	}

	void IDatabaseObject.GetMoniker(out IDatabaseObjectMoniker Moniker)
	{
		IDatabaseObjectIdentity identity = this;
		Moniker = new DatabaseObjectMoniker(identity.Database, identity.ObjectType, identity.Identity, ResolveMoniker);
	}

	public bool IsEqual(IIpHelpInfoObject hInfoObj)
	{
		if (myHelpInfoType == hInfoObj.ParamType)
		{
			if (myHelpInfo == null && hInfoObj.HenryInfo == null)
			{
				return true;
			}
			if (myHelpInfo == null || hInfoObj.HenryInfo == null)
			{
				return false;
			}
			if (myHelpInfoType == IpHelpInfoType.Henry)
			{
				IApedHenryIpRegressHelpInfo apedHenryIpRegressHelpInfo = (HENRY_Regparams)myHelpInfo;
				if (apedHenryIpRegressHelpInfo.IsEqual(hInfoObj.HenryInfo))
				{
					return true;
				}
				return false;
			}
			if (myHelpInfoType == IpHelpInfoType.Lle)
			{
				IApedLleIpRegressHelpInfo apedLleIpRegressHelpInfo = (LLE_Regparams)myHelpInfo;
				if (apedLleIpRegressHelpInfo.IsEqual(hInfoObj.LleInfo))
				{
					return true;
				}
				return false;
			}
			if (myHelpInfoType == IpHelpInfoType.Vle)
			{
				IApedVleIpRegressHelpInfo apedVleIpRegressHelpInfo = (VLE_Regparams)myHelpInfo;
				if (apedVleIpRegressHelpInfo.IsEqual(hInfoObj.VleInfo))
				{
					return true;
				}
				return false;
			}
			if (myHelpInfoType == IpHelpInfoType.NIST)
			{
				IApedNistIpRegressHelpInfo apedNistIpRegressHelpInfo = (NIST_Regparams)myHelpInfo;
				if (apedNistIpRegressHelpInfo.IsEqual(hInfoObj.NistInfo))
				{
					return true;
				}
				return false;
			}
		}
		return false;
	}

	public bool FetchExistingHelpInfo(string databankName, string parameterName, string compId1, string compId1Type, string compId2, string compId2Type, out string objIdentity)
	{
		objIdentity = CreateIdentifierFromNames(databankName, parameterName, compId1, compId1Type, compId2, compId2Type);
		if (objIdentity == "")
		{
			return false;
		}
		if (base.Database == null)
		{
			return false;
		}
		ISundryDataManager sundryDataManager;
		if ((sundryDataManager = (base.Database as ISupportsSundryData).SundryDataManager) == null)
		{
			return false;
		}
		IDatabaseObject item = sundryDataManager.GetItem(objIdentity);
		if (item != null)
		{
			IpHelpInfoObject ipHelpInfoObject = (IpHelpInfoObject)item;
			base.Identity = ipHelpInfoObject.Identity;
			myHelpInfoType = ipHelpInfoObject.ParamType;
			myFirstCompound = ipHelpInfoObject.FirstCompound;
			switch (myHelpInfoType)
			{
			case IpHelpInfoType.Vle:
				myHelpInfo = (VLE_Regparams)ipHelpInfoObject.VleInfo;
				break;
			case IpHelpInfoType.Lle:
				myHelpInfo = (LLE_Regparams)ipHelpInfoObject.LleInfo;
				break;
			case IpHelpInfoType.Henry:
				myHelpInfo = (HENRY_Regparams)ipHelpInfoObject.HenryInfo;
				break;
			case IpHelpInfoType.NIST:
				myHelpInfo = (NIST_Regparams)ipHelpInfoObject.NistInfo;
				break;
			default:
				return false;
			}
			return true;
		}
		return false;
	}

	public bool FetchExistingHelpInfo(IDatabank dbank, string parameterName, string compId1, string compId1Type, string compId2, string compId2Type, out string objIdentity)
	{
		string name = dbank.Name;
		objIdentity = CreateIdentifierFromNames(name, parameterName, compId1, compId1Type, compId2, compId2Type);
		if (objIdentity == "")
		{
			return false;
		}
		if (base.Database == null)
		{
			return false;
		}
		ISundryDataManager sundryDataManager;
		if ((sundryDataManager = (base.Database as ISupportsSundryData).SundryDataManager) == null)
		{
			return false;
		}
		IDatabaseObject item = sundryDataManager.GetItem(objIdentity);
		if (item != null)
		{
			IpHelpInfoObject ipHelpInfoObject = (IpHelpInfoObject)item;
			base.Identity = ipHelpInfoObject.Identity;
			myHelpInfoType = ipHelpInfoObject.ParamType;
			myFirstCompound = ipHelpInfoObject.FirstCompound;
			switch (myHelpInfoType)
			{
			case IpHelpInfoType.Vle:
				myHelpInfo = (VLE_Regparams)ipHelpInfoObject.VleInfo;
				break;
			case IpHelpInfoType.Lle:
				myHelpInfo = (LLE_Regparams)ipHelpInfoObject.LleInfo;
				break;
			case IpHelpInfoType.Henry:
				myHelpInfo = (HENRY_Regparams)ipHelpInfoObject.HenryInfo;
				break;
			case IpHelpInfoType.NIST:
				myHelpInfo = (NIST_Regparams)ipHelpInfoObject.NistInfo;
				ipHelpInfoObject.NistInfo.SetupCitation(dbank, parameterName, compId1, compId2);
				break;
			default:
				return false;
			}
			return true;
		}
		return false;
	}
}
public enum IpHelpInfoType
{
	Vle = 1,
	Lle,
	Henry,
	NIST
}
public interface IApedIpRegressLimits
{
	double Upper { get; set; }

	double Lower { get; set; }

	bool IsEqual(IApedIpRegressLimits rLim);
}
public interface IApedIpRegressDeviations
{
	double Npoints { get; set; }

	double Aard { get; set; }

	double Aad { get; set; }

	double MaxDeviation { get; set; }

	bool IsEqual(IApedIpRegressDeviations rDev);
}
public interface IApedNistIpRegressHelpInfo
{
	double Sigma { get; set; }

	double Valcon { get; set; }

	IApedIpRegressLimits Temp_Limits { get; set; }

	IApedIpRegressLimits Pres_Limits { get; set; }

	IApedIpRegressLimits X_Limits { get; set; }

	string TUnit { get; set; }

	string PUnit { get; set; }

	bool IsEqual(IApedNistIpRegressHelpInfo hInfo);

	string GetPropertyName(int i);

	int Size();

	IApedIpRegressDeviations GetRegErrorAt(int i);

	void SetupCitation(IDatabank iDatabank, string strParaName, string strCompI, string strCompJ);

	int CitationSize();

	string GetCitation(int i);
}
public interface IApedVleIpRegressHelpInfo
{
	double Sigma { get; set; }

	double Valcon { get; set; }

	IApedIpRegressLimits Temp_Limits { get; set; }

	IApedIpRegressLimits Pres_Limits { get; set; }

	IApedIpRegressLimits X_Limits { get; set; }

	IApedIpRegressDeviations Temp_Deviation { get; set; }

	IApedIpRegressDeviations Pres_Deviation { get; set; }

	IApedIpRegressDeviations X_Deviation { get; set; }

	string TUnit { get; set; }

	string PUnit { get; set; }

	bool IsEqual(IApedVleIpRegressHelpInfo hInfo);
}
public interface IApedLleIpRegressHelpInfo
{
	double Sigma { get; set; }

	double Valcon { get; set; }

	IApedIpRegressLimits Temp_Limits { get; set; }

	IApedIpRegressLimits X1_Limits { get; set; }

	IApedIpRegressLimits X2_Limits { get; set; }

	IApedIpRegressDeviations X1_Deviation { get; set; }

	IApedIpRegressDeviations X2_Deviation { get; set; }

	string TUnit { get; set; }

	string PUnit { get; set; }

	bool IsEqual(IApedLleIpRegressHelpInfo hInfo);
}
public interface IApedHenryIpRegressHelpInfo
{
	double Sigma { get; set; }

	double Valcon { get; set; }

	IApedIpRegressLimits Temp_Limits { get; set; }

	IApedIpRegressLimits Pres_Limits { get; set; }

	IApedIpRegressLimits X_Limits { get; set; }

	IApedIpRegressLimits Henry_Limits { get; set; }

	IApedIpRegressDeviations Henry_Deviation { get; set; }

	string TUnit { get; set; }

	string PUnit { get; set; }

	bool IsEqual(IApedHenryIpRegressHelpInfo hInfo);
}
public interface IIpHelpInfoObject
{
	IpHelpInfoType ParamType { get; set; }

	IApedHenryIpRegressHelpInfo HenryInfo { get; set; }

	IApedVleIpRegressHelpInfo VleInfo { get; set; }

	IApedLleIpRegressHelpInfo LleInfo { get; set; }

	IApedNistIpRegressHelpInfo NistInfo { get; set; }

	string FirstCompound { get; set; }

	bool IsEqual(IIpHelpInfoObject hInfoObj);

	bool FetchExistingHelpInfo(IDatabank dbank, string parameterName, string compId1, string compId1Type, string compId2, string compId2Type, out string objIdentity);

	bool FetchExistingHelpInfo(string dbankName, string parameterName, string compId1, string compId1Type, string compId2, string compId2Type, out string objIdentity);
}
[Serializable]
[ClassInterface(ClassInterfaceType.None)]
public class PureDatabankInfoObject : DatabaseObject, IDatabaseObject, IDatabaseObjectIdentity, ISerializable
{
	public string DisplayNameMM = "";

	public string Password = "";

	public string DatabankType = "";

	public string PromptMM = "";

	public string Product = "";

	public string HelpFileName = "";

	public int HelpCode;

	private string myDatabankName = "";

	public string DatabankName => myDatabankName;

	public override DatabaseObjectType ObjectType => DatabaseObjectType.PureDatabankInfo;

	public static string GetSundryDataTableEntryName(string databankName)
	{
		string name;
		if (databankName.Trim() == "")
		{
			name = "";
		}
		else
		{
			name = "Dbank-Pure-" + databankName;
		}
		return name;
	}

	public PureDatabankInfoObject()
	{
	}

	public PureDatabankInfoObject(string databankName)
		: base(GetSundryDataTableEntryName(databankName), null)
	{
		myDatabankName = databankName;
	}

	protected PureDatabankInfoObject(SerializationInfo info, StreamingContext context)
		: base(info, context)
	{
		DisplayNameMM = info.GetString("displayNameMM");
		Password = info.GetString("password");
		DatabankType = info.GetString("databankType");
		PromptMM = info.GetString("promptMM");
		Product = info.GetString("product");
		HelpFileName = info.GetString("helpFileName");
		HelpCode = info.GetInt32("helpCode");
		myDatabankName = info.GetString("databankName");
	}

	public static IDatabaseObject ResolveMoniker(IDatabaseObjectMoniker moniker)
	{
		ISundryDataManager sundryDataManager;
		if (!(moniker.Database is ISupportsSundryData) || (sundryDataManager = (moniker.Database as ISupportsSundryData).SundryDataManager) == null)
		{
			throw new GatewayException("The database does not support sundry data or an error occurred referencing the sundry data manager");
		}
		return sundryDataManager.GetItem(moniker.Identity);
	}

	public override void GetObjectData(SerializationInfo info, StreamingContext context)
	{
		base.GetObjectData(info, context);
		info.AddValue("displayNameMM", DisplayNameMM);
		info.AddValue("password", Password);
		info.AddValue("databankType", DatabankType);
		info.AddValue("promptMM", PromptMM);
		info.AddValue("product", Product);
		info.AddValue("helpFileName", HelpFileName);
		info.AddValue("helpCode", HelpCode);
		info.AddValue("databankName", myDatabankName);
	}

	void IDatabaseObject.GetMoniker(out IDatabaseObjectMoniker Moniker)
	{
		IDatabaseObjectIdentity identity = this;
		Moniker = new DatabaseObjectMoniker(identity.Database, identity.ObjectType, identity.Identity, ResolveMoniker);
	}
}
