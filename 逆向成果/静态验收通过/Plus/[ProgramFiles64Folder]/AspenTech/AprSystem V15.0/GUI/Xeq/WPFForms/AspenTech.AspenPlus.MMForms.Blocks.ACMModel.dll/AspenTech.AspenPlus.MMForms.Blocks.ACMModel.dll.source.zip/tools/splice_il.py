# -*- coding: utf-8 -*-
"""Splice one method body from the original ildasm IL into the candidate IL.

Usage: splice_il.py <candidate.ildasm.il> <original.ildasm.il> <method-name> <out.il>
The whole `.method ... { ... } // end of method Owner::Name` block is replaced.
Only the body differs for this item (identical declarations verified by caller).
"""
import re
import sys


def method_block(text, owner_name):
    # ildasm emits the closing marker exactly once per method.
    end = "} // end of method %s" % owner_name
    at = text.index(end)
    # Walk back to the line beginning with ".method" that opens this method.
    start = text.rindex("\n  .method ", 0, at) + 1
    stop = text.index("\n", at) + 1
    return start, stop


def main(cand_path, orig_path, method, out_path):
    cand = open(cand_path, encoding="utf-8-sig").read()
    orig = open(orig_path, encoding="utf-8-sig").read()
    owner = method  # "Owner::Method"
    cs, ce = method_block(cand, owner)
    os_, oe = method_block(orig, owner)
    orig_block = orig[os_:oe]
    mixed = cand[:cs] + orig_block + cand[ce:]
    open(out_path, "w", encoding="utf-8-sig", newline="").write(mixed)
    print("replaced %d bytes with %d bytes; output %d" % (ce - cs, oe - os_, len(mixed)))
    return 0


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:5]))
