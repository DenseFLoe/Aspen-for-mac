# CustomCheckBoxItem.cs

Source: editable/WpfPlotWizardsHelper/CustomCheckBoxItem.cs

Source SHA-256: b3f0fd0ba12e2602922c88b89cda452850f7d83df2fcd9dca8a6254264fa5a31
