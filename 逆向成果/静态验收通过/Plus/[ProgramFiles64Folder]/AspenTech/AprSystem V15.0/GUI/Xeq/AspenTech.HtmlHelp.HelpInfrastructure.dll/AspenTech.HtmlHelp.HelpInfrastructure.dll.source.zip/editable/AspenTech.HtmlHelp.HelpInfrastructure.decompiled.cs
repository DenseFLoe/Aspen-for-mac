using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using CefSharp;
using CefSharp.Wpf;
using Microsoft.Practices.Composite.Presentation.Events;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("2023.15.0.2")]
[assembly: AssemblyTitle("AspenTech.HtmlHelp.HelpInfrastructure")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, INC.")]
[assembly: AssemblyProduct("AspenTech.HtmlHelp.HelpInfrastructure")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2023")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("7649fa91-1cdb-450d-b419-9550227063e6")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("2023.15.0.2")]
namespace AspenTech.HtmlHelp.HelpInfrastructure;

public class AspenTechHelpConsts
{
	public const string strMS_TS_LangPtn = "help_language_ts|";

	public const int iMS_TS_LangPtnLen = 17;
}
public class HtmlHelpCefLibMgr
{
	private static string strRenderPath;

	private static HtmlHelpCefLibMgr helpCefLibMgr;

	private HtmlHelpCefLibMgr()
	{
		string location = GetType().Assembly.Location;
		FileInfo fileInfo = new FileInfo(location);
		if (fileInfo != null)
		{
			location = fileInfo.DirectoryName;
			if (!string.IsNullOrWhiteSpace(location))
			{
				strRenderPath = Path.Combine(location, "CefSharp.BrowserSubprocess.exe");
			}
			else
			{
				strRenderPath = "CefSharp.BrowserSubprocess.exe";
			}
		}
	}

	public static void InitLib()
	{
		if (helpCefLibMgr == null)
		{
			helpCefLibMgr = new HtmlHelpCefLibMgr();
		}
		string text = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData, Environment.SpecialFolderOption.Create) ?? "";
		string text2 = string.Empty;
		try
		{
			text2 = Directory.CreateDirectory(text + "\\HTMLHelp").FullName;
		}
		catch (Exception value)
		{
			Console.WriteLine(value);
		}
		try
		{
			CefSettings cefSettings = new CefSettings
			{
				LogSeverity = LogSeverity.Disable,
				BrowserSubprocessPath = strRenderPath,
				IgnoreCertificateErrors = true,
				CachePath = (text2 ?? "")
			};
			cefSettings.CefCommandLineArgs.Add("disable-gpu", "1");
			if (!Cef.IsInitialized)
			{
				Cef.Initialize((CefSettingsBase)cefSettings, performDependencyCheck: false, (IBrowserProcessHandler)null);
			}
		}
		catch (Exception)
		{
		}
	}

	public static void Shutdown()
	{
		Cef.Shutdown();
	}
}
public class HtmlHelpNavigateToEventArgs : EventArgs
{
	public HtmlHelpNavigateToEventArgs(string strUrl = null)
	{
		HelpTopicUrl = strUrl;
	}

	public string HelpTopicUrl { get; set; }

}
public class HtmlHelpNavigateToEvent : CompositePresentationEvent<HtmlHelpNavigateToEventArgs>
{
}
public class HtmlHelpShowHelpViewerEventArgs : EventArgs
{
	public HtmlHelpShowHelpViewerEventArgs(string strFileUrl = null)
	{
		HelpFileRelativeURL = strFileUrl;
	}

	public string HelpFileRelativeURL { get; set; }

}
public class HtmlHelpShowHelpViewerEvent : CompositePresentationEvent<HtmlHelpShowHelpViewerEventArgs>
{
}
public class HtmlHelpViewerNavigatingEventArgs : EventArgs
{
	public HtmlHelpViewerNavigatingEventArgs(string strUrl = null)
	{
		HelpFileRelativeURL = strUrl;
	}

	public string HelpFileRelativeURL { get; set; }

}
public class HtmlHelpViewerNavigatingEvent : CompositePresentationEvent<HtmlHelpViewerNavigatingEventArgs>
{
}
