#!/usr/bin/env python3
"""Compare the installed PE and the direct compiler output without loading either DLL."""
import argparse
from hashlib import sha256
from pathlib import Path
import json
import struct
import sys

sys.path.insert(0, str(Path(__file__).resolve().with_name("lib")))
import clr_meta
import pe_resources


def digest(data):
    return sha256(data).hexdigest()


def mapped(pe, rva, size):
    data = pe.get_data(rva, size)
    if len(data) != size:
        raise ValueError(f"Truncated PE payload at {rva:#x}")
    return data


def rows(root, table):
    layout = root["tables"]
    for index in range(1, layout["rows"].get(table, 0) + 1):
        yield clr_meta.read_row(root["bytes"], layout, table, index)


def string(pe, cli, root, index):
    return clr_meta.strings(pe, cli, root, index)


def normalized_metadata(root):
    data = bytearray(root["bytes"])
    module, = rows(root, 0)
    guid = root["streams"]["#GUID"]
    if not 0 < module[2] <= guid["size"] // 16 or module[2] in (module[3], module[4]):
        raise ValueError("Cannot isolate the MVID")
    at = guid["offset"] + (module[2] - 1) * 16
    mvid = bytes(data[at : at + 16]).hex()
    data[at : at + 16] = bytes(16)

    methods = root["tables"]["layout"][6]
    for index in range(methods["rows"]):
        at = methods["offset"] + index * methods["row_size"]
        data[at : at + 4] = bytes(4)
    return digest(data), mvid


def method_evidence(pe, cli, root):
    result = []
    for method in clr_meta.method_defs(pe, cli, root):
        row = {
            "token": f'{method["token"]:#010x}',
            "name": string(pe, cli, root, method["name_index"]),
            "rva": method["rva"],
            "method_flags": method["flags"],
            "implementation_flags": method["impl_flags"],
            "cil_bytes": method["code_size"],
            "body_bytes": method["body_bytes"],
            "body_sha256": None,
            "exception_clauses": 0,
        }
        if not method["rva"]:
            if not method["flags"] & 0x0400 or method["flags"] & 0x2000:
                raise ValueError(f'Unverified no-RVA declaration {row["token"]}')
        else:
            if method["impl_flags"] != 0 or method["flags"] & (0x0400 | 0x2000):
                raise ValueError(f'Unverified non-CIL implementation {row["token"]}')
            blob = mapped(pe, method["rva"], method["body_bytes"])
            if method["method_flags"] & 8:
                at = (method["header_bytes"] + method["code_size"] + 3) & ~3
                kind = blob[at]
                if kind not in (0x01, 0x41):
                    raise ValueError(f'Unsupported method data section {row["token"]}')
                width = 24 if kind & 0x40 else 12
                count, remainder = divmod(len(blob) - at - 4, width)
                if count < 1 or remainder:
                    raise ValueError(f'Malformed exception section {row["token"]}')
                row["exception_clauses"] = count
            row["body_sha256"] = digest(blob)
        result.append(row)
    return result


def managed_resources(pe, cli, root):
    content = mapped(pe, cli["resource_rva"], cli["resource_size"]) if cli["resource_size"] else b""
    resource_rows = []
    for offset, flags, name, implementation in (row.values() for row in rows(root, 0x28)):
        if implementation or offset + 4 > len(content):
            raise ValueError("Unverified external or malformed CLR resource")
        length = struct.unpack_from("<I", content, offset)[0]
        payload = content[offset + 4 : offset + 4 + length]
        if len(payload) != length:
            raise ValueError("Truncated CLR resource")
        resource_rows.append({
            "name": string(pe, cli, root, name),
            "flags": flags,
            "bytes": length,
            "sha256": digest(payload),
        })
    return {"directory_sha256": digest(content), "entries": resource_rows}


def native_context(pe):
    pe.parse_data_directories(directories=[1, 5, 6])
    imports = [
        [item.dll.decode("ascii"), [[symbol.name.decode("ascii") if symbol.name else None, symbol.ordinal]
                                    for symbol in item.imports]]
        for item in getattr(pe, "DIRECTORY_ENTRY_IMPORT", [])
    ]
    hdr = pe.OPTIONAL_HEADER
    entry = hdr.AddressOfEntryPoint
    clr = hdr.DATA_DIRECTORY[14]
    raw = struct.unpack("<IHH16I", mapped(pe, clr.VirtualAddress, 72))
    if raw[0] != 72 or not raw[5] & 1 or raw[5] & 16 or any(raw[11:]):
        raise ValueError("Unsupported non-IL CLR context")
    extra = [index for index, item in enumerate(hdr.DATA_DIRECTORY)
             if item.Size and index not in (1, 2, 4, 5, 6, 12, 14)]
    if extra:
        raise ValueError(f"Unverified PE directories: {extra}")
    security = hdr.DATA_DIRECTORY[4]
    return {
        "execution": {
            "machine": pe.FILE_HEADER.Machine,
            "characteristics": pe.FILE_HEADER.Characteristics,
            "pe_magic": hdr.Magic,
            "image_base": hdr.ImageBase,
            "subsystem": hdr.Subsystem,
            "subsystem_version": [hdr.MajorSubsystemVersion, hdr.MinorSubsystemVersion],
            "dll_characteristics": hdr.DllCharacteristics,
            "clr_version": list(raw[1:3]),
            "clr_flags": raw[5],
            "managed_entry": raw[6],
            "clr_other_directories": list(raw[11:]),
            "entry_stub": mapped(pe, entry, 6).hex(),
            "relocs": [[item.rva - entry, item.type]
                       for block in getattr(pe, "DIRECTORY_ENTRY_BASERELOC", [])
                       for item in block.entries if item.type != 0],
            "native_imports": imports,
        },
        "entry_rva": entry,
        "pe_timestamp": pe.FILE_HEADER.TimeDateStamp,
        "pe_checksum": hdr.CheckSum,
        "authenticode_bytes": security.Size,
        "strong_name_rva": raw[9],
        "strong_name_bytes": raw[10],
        "strong_name_nonzero": any(mapped(pe, raw[9], raw[10])) if raw[10] else False,
        "debug_entries": [[item.struct.Type, item.struct.SizeOfData]
                          for item in getattr(pe, "DIRECTORY_ENTRY_DEBUG", [])],
    }


def image(path):
    content = path.read_bytes()
    win32_resources = [
        {"path": key, "rva": rva, "bytes": length, "code_page": page, "sha256": sha}
        for key, (rva, length, page, sha, _) in sorted(pe_resources._rows(content).items())
    ]
    pe, cli, root = clr_meta.read_image(content)
    try:
        if set(root["streams"]) != {"#~", "#Strings", "#US", "#Blob", "#GUID"}:
            raise ValueError("Unverified CLR metadata stream")
        metadata, mvid = normalized_metadata(root)
        counters = root["tables"]["rows"]
        methods = method_evidence(pe, cli, root)
        return {
            "sha256": digest(content),
            "bytes": len(content),
            "normalized_metadata_sha256": metadata,
            "mvid_raw": mvid,
            "tables": {f"{table:#04x}": count for table, count in counters.items()},
            "impl_map": counters.get(0x1c, 0),
            "pinvoke_methods": sum(bool(row[2] & 0x2000) for row in rows(root, 6)),
            "assembly_refs": [
                {"name": string(pe, cli, root, row[6]),
                 "version": ".".join(str(row[index]) for index in range(4))}
                for row in rows(root, 0x23)
            ],
            "type_defs": [string(pe, cli, root, row[2]) + "." + string(pe, cli, root, row[1])
                          for row in rows(root, 0x02)],
            "wpf_type_refs": sorted(
                namespace + "." + string(pe, cli, root, row[1])
                for row in rows(root, 1)
                if (namespace := string(pe, cli, root, row[2])).startswith("System.Windows")
            ),
            "events": [string(pe, cli, root, row[1]) for row in rows(root, 0x14)],
            "managed_resources": managed_resources(pe, cli, root),
            "win32_resources": win32_resources,
            "pe": native_context(pe),
            "methods": methods,
        }
    finally:
        pe.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("report", type=Path)
    args = parser.parse_args()
    original, candidate = image(args.original), image(args.candidate)
    a = {item["token"]: item for item in original.pop("methods")}
    b = {item["token"]: item for item in candidate.pop("methods")}
    imports = ("impl_map", "pinvoke_methods")
    body_differences = [token for token in sorted(a.keys() | b.keys())
                        if token not in a or token not in b
                        or a[token]["body_sha256"] != b[token]["body_sha256"]]
    if not a or not b:
        raise ValueError("No MethodDef evidence")
    for side, methods in ((original, a), (candidate, b)):
        side["method_definitions"] = len(methods)
        side["methods_with_body"] = sum(item["body_sha256"] is not None for item in methods.values())
        side["exception_clauses"] = sum(item["exception_clauses"] for item in methods.values())
    checks = {
        "definitions_and_bindings": original["normalized_metadata_sha256"] == candidate["normalized_metadata_sha256"],
        "method_bodies": not body_differences,
        "pinvoke_counts": all(original[key] == candidate[key] for key in imports),
        "managed_resources": original["managed_resources"] == candidate["managed_resources"],
        "win32_resources": [{key: value for key, value in item.items() if key != "rva"}
                            for item in original["win32_resources"]]
                            == [{key: value for key, value in item.items() if key != "rva"}
                                for item in candidate["win32_resources"]],
        "execution_context": original["pe"]["execution"] == candidate["pe"]["execution"],
    }
    report = {
        "checks": checks,
        "original": original,
        "candidate": candidate,
        "body_differences": body_differences,
        "methods": [{"token": token, "original": a.get(token), "candidate": b.get(token)}
                    for token in sorted(a.keys() | b.keys())],
    }
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(checks, indent=2))
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
