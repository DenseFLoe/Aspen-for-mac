# OriginalTargetFramework.cs

Source: editable/OriginalTargetFramework.cs

Source SHA-256: 2ffe4355ff0952ee56c9782f53abd999ddf31982bf2a72939d27b55210ce065b
