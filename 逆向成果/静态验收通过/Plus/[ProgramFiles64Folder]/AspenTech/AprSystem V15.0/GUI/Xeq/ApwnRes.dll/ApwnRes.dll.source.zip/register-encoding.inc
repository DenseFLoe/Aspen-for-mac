; Original compiler uses the r <- r/m encoding of these Win64 operations.
; NASM normally prefers the other encoding for a register-only pair.

%macro map_gpr 5
    %assign gpr_index_%1 %5
    %assign gpr_index_%2 %5
    %assign gpr_index_%3 %5
    %assign gpr_index_%4 %5
    %assign gpr_width_%1 64
    %assign gpr_width_%2 32
    %assign gpr_width_%3 16
    %assign gpr_width_%4 8
%endmacro

map_gpr rax, eax, ax, al, 0
map_gpr rcx, ecx, cx, cl, 1
map_gpr rdx, edx, dx, dl, 2
map_gpr rbx, ebx, bx, bl, 3
map_gpr rsp, esp, sp, spl, 4
map_gpr rbp, ebp, bp, bpl, 5
map_gpr rsi, esi, si, sil, 6
map_gpr rdi, edi, di, dil, 7
map_gpr r8, r8d, r8w, r8b, 8
map_gpr r9, r9d, r9w, r9b, 9
map_gpr r10, r10d, r10w, r10b, 10
map_gpr r11, r11d, r11w, r11b, 11
map_gpr r12, r12d, r12w, r12b, 12
map_gpr r13, r13d, r13w, r13b, 13
map_gpr r14, r14d, r14w, r14b, 14
map_gpr r15, r15d, r15w, r15b, 15

%macro register_from_rm 3
    %assign %%dst gpr_index_%2
    %assign %%src gpr_index_%3
    %assign %%width gpr_width_%2
    %if gpr_width_%3 != %%width
        %error Register operand widths differ
    %endif
    %if %%width = 16
        db 0x66
    %endif
    %assign %%rex 0x40 | ((%%dst >> 3) << 2) | (%%src >> 3)
    %if %%width = 64
        %assign %%rex %%rex | 8
    %endif
    %if %%rex != 0x40 || (%%width = 8 && (%%dst >= 4 || %%src >= 4))
        db %%rex
    %endif
    %if %%width = 8
        db %1
    %else
        db %1 + 1
    %endif
    db 0xc0 | ((%%dst & 7) << 3) | (%%src & 7)
%endmacro

%define mov_r_rm(d,s) register_from_rm 0x8a, d, s
%define add_r_rm(d,s) register_from_rm 0x02, d, s
%define or_r_rm(d,s)  register_from_rm 0x0a, d, s
%define sbb_r_rm(d,s) register_from_rm 0x1a, d, s
%define and_r_rm(d,s) register_from_rm 0x22, d, s
%define sub_r_rm(d,s) register_from_rm 0x2a, d, s
%define xor_r_rm(d,s) register_from_rm 0x32, d, s
%define cmp_r_rm(d,s) register_from_rm 0x3a, d, s
