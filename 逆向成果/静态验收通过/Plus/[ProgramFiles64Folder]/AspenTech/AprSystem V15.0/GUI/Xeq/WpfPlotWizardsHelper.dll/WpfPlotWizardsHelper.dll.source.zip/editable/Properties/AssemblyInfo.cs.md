# AssemblyInfo.cs

Source: editable/Properties/AssemblyInfo.cs

Source SHA-256: d95f3e3677f417c1cd98efcc7378e1eee8e6937d89a2d96d49c2da709335ccc9
