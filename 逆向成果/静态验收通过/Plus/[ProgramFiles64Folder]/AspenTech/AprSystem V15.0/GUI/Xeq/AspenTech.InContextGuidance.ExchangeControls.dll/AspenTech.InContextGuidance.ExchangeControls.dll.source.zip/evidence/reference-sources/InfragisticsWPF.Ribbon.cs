using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Infragistics.Windows.Controls;

[assembly: AssemblyVersion("20.2.20202.38")]

namespace Infragistics.Windows.Ribbon
{
    public class ButtonTool : Control
    {
        public string Caption { get; set; }
        public ImageSource LargeImage { get; set; }
        protected virtual void OnClick() { }
    }

    public class XamRibbonScreenTip : XamScreenTip { }

    public enum RibbonToolSizingMode
    {
        ImageAndTextLarge = 2
    }

    public static class RibbonGroup
    {
        public static void SetMaximumSize(DependencyObject element, RibbonToolSizingMode maximumSize) { }
    }
}
