"""Build a layout recipe, allowing token-operand remaps on otherwise equal bodies.

Usage: recipe_remap.py <sha8>
Extends make_recipe_layout.generate: any source_form_gap whose bodies differ only
by metadata tokens is verified with token_replay.reemit_method and admitted as a
verified method with remapped_tokens (candidate token value -> original token
value, matched by semantic key from tokens.py).
"""
import json, sys
from hashlib import sha256
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
HOME = BASE / "managed-byte-recovery"
FIN = BASE / "router" / "work" / "finisher-2"
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")
sys.path.insert(0, str(BASE)); sys.path.insert(0, str(HOME)); sys.path.insert(0, str(FIN)); sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(BASE / "router" / "managed"))

import make_recipe_layout as make_recipe
import pe_layout
import clr_meta
from tokens import Image, body_diff_map

WORK = TOOLS.parent
LEDGER = {}
for line in open(BASE / "per-file.jsonl", encoding="utf-8"):
    r = json.loads(line)
    LEDGER[r["sha256"]] = r

def run(sha8):
    sha = next(s for s in LEDGER if s.startswith(sha8))
    r = LEDGER[sha]
    d = WORK / sha8
    orig = Path(r["installed_location"]).read_bytes()
    cand = (d / "out" / r["name"]).read_bytes()
    recipe, assets, report = make_recipe.generate(orig, cand, r["name"])
    oi, ci = Image(orig, "orig"), Image(cand, "cand")
    pe_o, _, _ = clr_meta.read_image(orig)
    pe_c, _, _ = clr_meta.read_image(cand)
    rows_o = clr_meta.method_defs(pe_o, *clr_meta.read_image(orig)[1:])
    rows_c = clr_meta.method_defs(pe_c, *clr_meta.read_image(cand)[1:])
    by_token_o = {x["token"]: x for x in rows_o}
    by_token_c = {x["token"]: x for x in rows_c}
    admitted = 0
    remaining = []
    for gap in report["gaps"]:
        if gap["kind"] != "source_form_gap":
            remaining.append(gap)
            continue
        token = int(gap["token"], 16)
        a, b = by_token_o[token], by_token_c[token]
        body_o = pe_o.get_data(a["rva"], a["body_bytes"])
        body_c = pe_c.get_data(b["rva"], b["body_bytes"])
        if len(body_o) != len(body_c):
            remaining.append(gap)
            continue
        remaps, leftover = body_diff_map(oi, ci, body_o, body_c)
        if leftover or not remaps:
            gap = dict(gap, leftover=leftover[:8])
            remaining.append(gap)
            continue
        pair = {"original_token": "0x%08X" % token, "candidate_token": "0x%08X" % b["token"],
                "original_rva": a["rva"], "candidate_rva": b["rva"], "bytes": len(body_o),
                "body_sha256": sha256(body_o).hexdigest(), "remapped_tokens": remaps}
        patched = pe_layout.reemit_method(body_c, pair)
        if patched != body_o:
            gap = dict(gap, reason="remap did not reproduce original body")
            remaining.append(gap)
            continue
        recipe["verified_methods"].append(pair)
        admitted += 1
    recipe["methods_matched"] = len(recipe["verified_methods"])
    recipe["methods_total"] = len(recipe["verified_methods"]) + len(remaining)
    recipe["replay_status"] = "ready" if not remaining else "blocked"
    report = {"name": r["name"], "original_sha256": recipe["original_sha256"],
              "compiler_output_sha256": recipe["compiler_output_sha256"],
              "methods_total": recipe["methods_total"], "methods_matched": recipe["methods_matched"],
              "remap_admitted": admitted, "gaps": remaining,
              "gap_kinds": sorted({g["kind"] for g in remaining})}
    (d / "recipe.json").write_text(json.dumps(recipe, ensure_ascii=False, indent=1), encoding="utf-8")
    (d / "recipe-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    adir = d / "assets"; adir.mkdir(exist_ok=True)
    for k, v in assets.items():
        (adir / k.replace("/", "__")).write_bytes(v)
    print("status", recipe["replay_status"], "matched", recipe["methods_matched"], "/", recipe["methods_total"],
          "remap_admitted", admitted, "gaps", report["gap_kinds"], len(remaining))
    for g in remaining[:12]:
        print("  GAP", g["kind"], g.get("token"), g.get("name"), g.get("detail"), g.get("leftover"))
    return 0 if not remaining else 2

if __name__ == "__main__":
    sys.exit(run(sys.argv[1]))
