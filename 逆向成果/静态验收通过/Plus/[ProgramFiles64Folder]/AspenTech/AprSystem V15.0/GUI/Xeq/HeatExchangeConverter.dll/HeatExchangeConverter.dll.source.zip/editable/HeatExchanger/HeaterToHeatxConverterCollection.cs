using System.Runtime.InteropServices;

namespace HeatExchanger;

[ComVisible(true)]
[Guid("76C43B9F-7917-4E46-A3D4-7011C4466294")]
[ProgId("HeatExchanger.HeaterToHeatxConverterCollection.41.0")]
[ClassInterface(ClassInterfaceType.None)]
public class HeaterToHeatxConverterCollection : ConverterCollection
{
	public HeaterToHeatxConverterCollection()
		: base("Heater")
	{
	}
}
