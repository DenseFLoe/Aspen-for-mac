using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace ColumnConverters;

[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
internal class Resource1
{
	private static ResourceManager resourceMan;

	private static CultureInfo resourceCulture;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager
	{
		get
		{
			if (resourceMan == null)
			{
				resourceMan = new ResourceManager("ColumnConverters.Resource1", typeof(Resource1).Assembly);
			}
			return resourceMan;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo Culture
	{
		get
		{
			return resourceCulture;
		}
		set
		{
			resourceCulture = value;
		}
	}

	internal static string Compositions => ResourceManager.GetString("Compositions", resourceCulture);

	internal static string ConvertModel => ResourceManager.GetString("ConvertModel", resourceCulture);

	internal static string Generate_estimates => ResourceManager.GetString("Generate_estimates", resourceCulture);

	internal static string OK => ResourceManager.GetString("OK", resourceCulture);

	internal static string Temperature => ResourceManager.GetString("Temperature", resourceCulture);

	internal Resource1()
	{
	}
}
