using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ColumnConverters;

public class Form1 : Form
{
	public bool gTemp;

	public bool gXY;

	private IContainer components;

	private CheckBox checkBox1;

	private CheckBox checkBox2;

	private Button button1;

	public Form1()
	{
		InitializeComponent();
	}

	private void button1_Click(object sender, EventArgs e)
	{
		gTemp = checkBox1.Checked;
		gXY = checkBox2.Checked;
		Hide();
	}

	private void Form1_Load(object sender, EventArgs e)
	{
		Text = Resource1.Generate_estimates;
		checkBox1.Text = Resource1.Temperature;
		checkBox2.Text = Resource1.Compositions;
		button1.Text = Resource1.OK;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.checkBox1 = new System.Windows.Forms.CheckBox();
		this.checkBox2 = new System.Windows.Forms.CheckBox();
		this.button1 = new System.Windows.Forms.Button();
		base.SuspendLayout();
		this.checkBox1.AutoSize = true;
		this.checkBox1.Checked = true;
		this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
		this.checkBox1.Location = new System.Drawing.Point(8, 8);
		this.checkBox1.Margin = new System.Windows.Forms.Padding(2);
		this.checkBox1.Name = "checkBox1";
		this.checkBox1.Size = new System.Drawing.Size(86, 17);
		this.checkBox1.TabIndex = 0;
		this.checkBox1.Text = "Temperature";
		this.checkBox1.UseVisualStyleBackColor = true;
		this.checkBox2.AutoSize = true;
		this.checkBox2.Checked = true;
		this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
		this.checkBox2.Location = new System.Drawing.Point(8, 29);
		this.checkBox2.Margin = new System.Windows.Forms.Padding(2);
		this.checkBox2.Name = "checkBox2";
		this.checkBox2.Size = new System.Drawing.Size(88, 17);
		this.checkBox2.TabIndex = 1;
		this.checkBox2.Text = "Compositions";
		this.checkBox2.UseVisualStyleBackColor = true;
		this.button1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
		this.button1.Location = new System.Drawing.Point(127, 54);
		this.button1.Margin = new System.Windows.Forms.Padding(2);
		this.button1.Name = "button1";
		this.button1.Size = new System.Drawing.Size(80, 20);
		this.button1.TabIndex = 2;
		this.button1.Text = "OK";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new System.EventHandler(button1_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(334, 81);
		base.Controls.Add(this.checkBox1);
		base.Controls.Add(this.checkBox2);
		base.Controls.Add(this.button1);
		base.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
		base.Margin = new System.Windows.Forms.Padding(2);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = "Form1";
		base.ShowIcon = false;
		base.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
		base.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
		this.Text = "Generate estimates";
		base.Load += new System.EventHandler(Form1_Load);
		base.ResumeLayout(false);
		base.PerformLayout();
	}
}
