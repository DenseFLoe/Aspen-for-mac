using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLFilter;

[RibbonPlotWizardMgr("WpfPLFILTER.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class FilterPlotWizardModule : PlotModuleBase
{
}
