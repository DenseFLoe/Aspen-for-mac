using System;
using AspenTech.AspenPlus.Infrastructure;
using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Unity;

namespace AspenTech.AspenPlus.EOVariableList;

public class EOVariableListModule : IModule
{
	private readonly IUnityContainer _unityContainer;

	public EOVariableListModule(IUnityContainer unityContainer)
	{
		if (unityContainer == null)
		{
			throw new ArgumentNullException("unityContainer");
		}
		_unityContainer = unityContainer;
	}

	public void Initialize()
	{
		_unityContainer.RegisterType<IEOVariableListPresenter, EOVariableListPresenter>(new ContainerControlledLifetimeManager(), Array.Empty<InjectionMember>());
	}
}
