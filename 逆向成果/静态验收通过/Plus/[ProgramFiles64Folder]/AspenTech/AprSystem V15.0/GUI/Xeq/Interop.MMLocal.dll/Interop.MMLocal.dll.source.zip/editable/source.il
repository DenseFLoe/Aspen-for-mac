﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  AspenTech.AspenPlus.MMLocal.IHStyleSheetManager
  AspenTech.AspenPlus.MMLocal.HSSCtrlMode
  AspenTech.AspenPlus.MMLocal.IHEnumStyleSheets
  AspenTech.AspenPlus.MMLocal.IHStyleSheet
  AspenTech.AspenPlus.MMLocal.IPropertyBag
  AspenTech.AspenPlus.MMLocal.SSPKPROP
  AspenTech.AspenPlus.MMLocal.IErrorLog
  AspenTech.AspenPlus.MMLocal.IHSelection_Drag_Drop
  AspenTech.AspenPlus.MMLocal.IDataObject
  AspenTech.AspenPlus.MMLocal.FORMATETC
  AspenTech.AspenPlus.MMLocal.userSTGMEDIUM
  AspenTech.AspenPlus.MMLocal.userFLAG_STGMEDIUM
  AspenTech.AspenPlus.MMLocal.IEnumFORMATETC
  AspenTech.AspenPlus.MMLocal.IAdviseSink
  AspenTech.AspenPlus.MMLocal.IEnumSTATDATA
  AspenTech.AspenPlus.MMLocal.userCLIPFORMAT
  AspenTech.AspenPlus.MMLocal.DVTARGETDEVICE
  AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0001
  AspenTech.AspenPlus.MMLocal._STGMEDIUM_UNION
  AspenTech.AspenPlus.MMLocal.__MIDL_IAdviseSink_0003
  AspenTech.AspenPlus.MMLocal.userHMETAFILEPICT
  AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0005
  AspenTech.AspenPlus.MMLocal.remoteMETAFILEPICT
  AspenTech.AspenPlus.MMLocal.userHMETAFILE
  AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0004
  AspenTech.AspenPlus.MMLocal.BYTE_BLOB
  AspenTech.AspenPlus.MMLocal.userHENHMETAFILE
  AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0006
  AspenTech.AspenPlus.MMLocal.GDI_OBJECT
  AspenTech.AspenPlus.MMLocal.__MIDL_IAdviseSink_0002
  AspenTech.AspenPlus.MMLocal.userHBITMAP
  AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0007
  AspenTech.AspenPlus.MMLocal.userBITMAP
  AspenTech.AspenPlus.MMLocal.userHPALETTE
  AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0008
  AspenTech.AspenPlus.MMLocal.LOGPALETTE
  AspenTech.AspenPlus.MMLocal.PALETTEENTRY
  AspenTech.AspenPlus.MMLocal.userHGLOBAL
  AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0003
  AspenTech.AspenPlus.MMLocal.FLAGGED_BYTE_BLOB
  AspenTech.AspenPlus.MMLocal.IMoniker
  AspenTech.AspenPlus.MMLocal.IBindCtx
  AspenTech.AspenPlus.MMLocal.IEnumMoniker
  AspenTech.AspenPlus.MMLocal.BIND_OPTS2
  AspenTech.AspenPlus.MMLocal.IRunningObjectTable
  AspenTech.AspenPlus.MMLocal.IEnumString
  AspenTech.AspenPlus.MMLocal.COSERVERINFO
  AspenTech.AspenPlus.MMLocal.COAUTHINFO
  AspenTech.AspenPlus.MMLocal.COAUTHIDENTITY
  AspenTech.AspenPlus.MMLocal.STATDATA
  AspenTech.AspenPlus.MMLocal.NonBeadSSheetHandles
  AspenTech.AspenPlus.MMLocal.SubstreamType
  AspenTech.AspenPlus.MMLocal.PhaseType
  AspenTech.AspenPlus.MMLocal.QualType
  AspenTech.AspenPlus.MMLocal.CollectionType
  AspenTech.AspenPlus.MMLocal.ObjectType
  AspenTech.AspenPlus.MMLocal.IASCObjectProvider
  AspenTech.AspenPlus.MMLocal.IHASCConfigObject
  AspenTech.AspenPlus.MMLocal.IHappInternalMessage
  AspenTech.AspenPlus.MMLocal.MMLocalEvent_DispID
  AspenTech.AspenPlus.MMLocal.IMMLocalEvents
  AspenTech.AspenPlus.MMLocal.IHFormFactory
  AspenTech.AspenPlus.MMLocal.HASymbol
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern Interop.Happ
{
  .publickeytoken = (B0 56 89 B3 9D EE FB CD )                         // .V......
  .ver 20:0:0:0
}
.assembly extern stdole
{
  .publickeytoken = (B0 3F 5F 7F 11 D5 0A 3A )                         // .?_....:
  .ver 7:0:3300:0
}
.assembly Interop.MMLocal
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibVersionAttribute::.ctor(int32,
                                                                                                int32) = ( 01 00 00 00 00 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 42 39 34 38 39 42 34 2D 35 46 30 30   // ..$FB9489B4-5F00
                                                                                                  2D 31 31 44 34 2D 38 45 37 42 2D 30 30 42 30 44   // -11D4-8E7B-00B0D
                                                                                                  30 35 33 38 43 34 36 00 00 )                      // 0538C46..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ImportedFromTypeLibAttribute::.ctor(string) = ( 01 00 07 4D 4D 4C 6F 63 61 6C 00 00 )             // ...MMLocal..
  .publickey = (00 24 00 00 04 80 00 00 94 00 00 00 06 02 00 00   // .$..............
                00 24 00 00 52 53 41 31 00 04 00 00 01 00 01 00   // .$..RSA1........
                31 CE F7 DF 85 4A 51 60 93 9C 58 8A 09 81 30 D8   // 1....JQ`..X...0.
                3B 58 C6 41 43 FE 98 DE 4F EA 84 44 85 EE C0 F8   // ;X.AC...O..D....
                BF 75 0A 6A 39 BA 8A 55 2E 37 20 73 B6 95 3A 09   // .u.j9..U.7 s..:.
                53 17 FB FB A3 6E B8 37 F2 D0 14 D6 2D 52 2D 2C   // S....n.7....-R-,
                B2 4F 39 B6 12 E0 DA 27 6D BF 15 4A 5D 0F 84 0D   // .O9....'m..J]...
                59 7F 81 E6 0E 83 1D 25 B6 EB C3 47 9D 69 C3 A6   // Y......%...G.i..
                6A 21 E7 D3 A8 62 09 D1 D3 50 BB 90 86 82 98 3C   // j!...b...P.....<
                80 C0 F7 D4 3B 60 C3 48 79 73 35 A7 33 B2 61 C8 ) // ....;`.Hys5.3.a.
  .hash algorithm 0x00008004
  .ver 0:0:0:0
}
.module Interop.MMLocal.dll
// MVID: {84118dcb-264b-4955-9e07-a4b9940310e4}
.imagebase 0x00400000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000009    //  ILONLY
// Image base: 0x000001FB7F7D0000


// =============== CLASS MEMBERS DECLARATION ===================

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IHStyleSheetManager
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 42 39 34 38 39 42 30 2D 35 46 30 30   // ..$FB9489B0-5F00
                                                                                                  2D 31 31 44 34 2D 38 45 37 42 2D 30 30 42 30 44   // -11D4-8E7B-00B0D
                                                                                                  30 35 33 38 43 34 36 00 00 )                      // 0538C46..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  CreateStyleSheet([out] int64& SSHandle,
                                          [in] valuetype AspenTech.AspenPlus.MMLocal.HSSCtrlMode dwCtrlMode,
                                          [in] int32 dwSheetMode,
                                          [in] string&  marshal( bstr) bSheetName,
                                          [in] class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode  marshal( interface ) pNode) runtime managed internalcall
  {
  } // end of method IHStyleSheetManager::CreateStyleSheet

  .method public hidebysig newslot abstract virtual 
          instance void  DeleteStyleSheet([in] int64 SSHandle) runtime managed internalcall
  {
  } // end of method IHStyleSheetManager::DeleteStyleSheet

  .method public hidebysig newslot abstract virtual 
          instance void  CopyStyleSheet([out] int64& SSHandle,
                                        [in] int64 SSSrcHandle,
                                        [in] valuetype AspenTech.AspenPlus.MMLocal.HSSCtrlMode dwCtrlMode,
                                        [in] int32 dwSheetMode,
                                        [in] string&  marshal( bstr) bSheetName,
                                        [in] class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode  marshal( interface ) pNode) runtime managed internalcall
  {
  } // end of method IHStyleSheetManager::CopyStyleSheet

  .method public hidebysig newslot abstract virtual 
          instance void  ConnectStyleSheet([in] int64 SSHandle,
                                           [in] class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode  marshal( interface ) pNode) runtime managed internalcall
  {
  } // end of method IHStyleSheetManager::ConnectStyleSheet

  .method public hidebysig newslot abstract virtual 
          instance void  DisconnectStyleSheet([in] int64 SSHandle,
                                              [in] class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode  marshal( interface ) pNode) runtime managed internalcall
  {
  } // end of method IHStyleSheetManager::DisconnectStyleSheet

  .method public hidebysig newslot abstract virtual 
          instance void  EnumStyleSheets([out] class AspenTech.AspenPlus.MMLocal.IHEnumStyleSheets&  marshal( interface ) ppEnumSheets,
                                         [in] valuetype AspenTech.AspenPlus.MMLocal.HSSCtrlMode dwCtrlMode,
                                         [in] int32 dwSheetMode,
                                         [in] class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode  marshal( interface ) pNode) runtime managed internalcall
  {
  } // end of method IHStyleSheetManager::EnumStyleSheets

  .method public hidebysig newslot abstract virtual 
          instance void  DefaultStyleSheet([out] int64& pSSHandle,
                                           [in] valuetype AspenTech.AspenPlus.MMLocal.HSSCtrlMode dwCtrlMode,
                                           [in] int32 dwSheetMode) runtime managed internalcall
  {
  } // end of method IHStyleSheetManager::DefaultStyleSheet

  .method public hidebysig newslot abstract virtual 
          instance void  StyleSheet([in] class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode  marshal( interface ) pNode,
                                    [in] int64 SSHandle,
                                    [in] valuetype AspenTech.AspenPlus.MMLocal.HSSCtrlMode dwCtrlMode,
                                    [out] class AspenTech.AspenPlus.MMLocal.IHStyleSheet&  marshal( interface ) ppSheet) runtime managed internalcall
  {
  } // end of method IHStyleSheetManager::StyleSheet

  .method public hidebysig newslot abstract virtual 
          instance void  AddModelStyleSheets(class [Interop.Happ]AspenTech.AspenPlus.Happ.IStream  marshal( interface ) pStream,
                                             class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode  marshal( interface ) pHNode) runtime managed internalcall
  {
  } // end of method IHStyleSheetManager::AddModelStyleSheets

  .method public hidebysig newslot abstract virtual 
          instance void  GetPropSetListInPropPack([out] object&  marshal( struct) pPropName,
                                                  [out] object&  marshal( struct) pPropAlias) runtime managed internalcall
  {
  } // end of method IHStyleSheetManager::GetPropSetListInPropPack

} // end of class AspenTech.AspenPlus.MMLocal.IHStyleSheetManager

.class public auto ansi sealed AspenTech.AspenPlus.MMLocal.HSSCtrlMode
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.HSSCtrlMode HSS_GRID = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.HSSCtrlMode HSS_LIST = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.HSSCtrlMode HSS_SSGRID = int32(0x00000002)
} // end of class AspenTech.AspenPlus.MMLocal.HSSCtrlMode

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IHEnumStyleSheets
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 42 39 34 38 39 42 31 2D 35 46 30 30   // ..$FB9489B1-5F00
                                                                                                  2D 31 31 44 34 2D 38 45 37 42 2D 30 30 42 30 44   // -11D4-8E7B-00B0D
                                                                                                  30 35 33 38 43 34 36 00 00 )                      // 0538C46..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  Next(uint32 celt,
                              int64& rgelt,
                              uint32& pceltFetched) runtime managed internalcall
  {
  } // end of method IHEnumStyleSheets::Next

  .method public hidebysig newslot abstract virtual 
          instance void  Skip(uint32 celt) runtime managed internalcall
  {
  } // end of method IHEnumStyleSheets::Skip

  .method public hidebysig newslot abstract virtual 
          instance void  Reset() runtime managed internalcall
  {
  } // end of method IHEnumStyleSheets::Reset

  .method public hidebysig newslot abstract virtual 
          instance void  Clone(class AspenTech.AspenPlus.MMLocal.IHEnumStyleSheets&  marshal( interface ) ppenum) runtime managed internalcall
  {
  } // end of method IHEnumStyleSheets::Clone

} // end of class AspenTech.AspenPlus.MMLocal.IHEnumStyleSheets

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IHStyleSheet
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 34 42 38 33 34 30 43 30 2D 36 43 36 34   // ..$4B8340C0-6C64
                                                                                                  2D 31 31 44 34 2D 38 45 37 45 2D 30 30 42 30 44   // -11D4-8E7E-00B0D
                                                                                                  30 35 33 38 43 34 36 00 00 )                      // 0538C46..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_StyleSheetName() runtime managed internalcall
  {
  } // end of method IHStyleSheet::get_StyleSheetName

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_StyleSheetName([in] string&  marshal( bstr) bName) runtime managed internalcall
  {
  } // end of method IHStyleSheet::set_StyleSheetName

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_StyleSheetMode() runtime managed internalcall
  {
  } // end of method IHStyleSheet::get_StyleSheetMode

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_StyleSheetType([in] class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode  marshal( interface ) pNode) runtime managed internalcall
  {
  } // end of method IHStyleSheet::get_StyleSheetType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_StyleSheetType([in] class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode  marshal( interface ) pNode,
                                            [in] int32 pVal) runtime managed internalcall
  {
  } // end of method IHStyleSheet::set_StyleSheetType

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_AutoSave() runtime managed internalcall
  {
  } // end of method IHStyleSheet::get_AutoSave

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_AutoSave([in] int32 pVal) runtime managed internalcall
  {
  } // end of method IHStyleSheet::set_AutoSave

  .method public hidebysig newslot abstract virtual 
          instance void  ClearPropertyBag() runtime managed internalcall
  {
  } // end of method IHStyleSheet::ClearPropertyBag

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.MMLocal.IPropertyBag 
          marshal( interface ) 
          get_PropertyBag() runtime managed internalcall
  {
  } // end of method IHStyleSheet::get_PropertyBag

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_StyleSheetView() runtime managed internalcall
  {
  } // end of method IHStyleSheet::get_StyleSheetView

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_StyleSheetView([in] int32 pVal) runtime managed internalcall
  {
  } // end of method IHStyleSheet::set_StyleSheetView

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_StyleSheetIsDef([in] int32 pVal) runtime managed internalcall
  {
  } // end of method IHStyleSheet::set_StyleSheetIsDef

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_StyleSheetIsDef() runtime managed internalcall
  {
  } // end of method IHStyleSheet::get_StyleSheetIsDef

  .method public hidebysig newslot abstract virtual 
          instance void  DisableSheet() runtime managed internalcall
  {
  } // end of method IHStyleSheet::DisableSheet

  .method public hidebysig newslot abstract virtual 
          instance void  GetAPStreamList(object&  marshal( struct) pVar) runtime managed internalcall
  {
  } // end of method IHStyleSheet::GetAPStreamList

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          UnitConversion([in] object  marshal( struct) vtRow,
                         [in] object  marshal( struct) vtSrcCol,
                         [in] object  marshal( struct) vtDestCol,
                         [in] object  marshal( struct) vtSrcVal) runtime managed internalcall
  {
  } // end of method IHStyleSheet::UnitConversion

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetCSVFileList() runtime managed internalcall
  {
  } // end of method IHStyleSheet::GetCSVFileList

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          FindCSVFile([in] object  marshal( struct) vtBaseName) runtime managed internalcall
  {
  } // end of method IHStyleSheet::FindCSVFile

  .method public hidebysig newslot abstract virtual 
          instance void  GetPropAttributes([in] object  marshal( struct) vtPropName,
                                           [out] valuetype AspenTech.AspenPlus.MMLocal.SSPKPROP& pPkProp) runtime managed internalcall
  {
  } // end of method IHStyleSheet::GetPropAttributes

  .property callconv(8) string StyleSheetName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 01 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.MMLocal.IHStyleSheet::get_StyleSheetName()
    .set instance void AspenTech.AspenPlus.MMLocal.IHStyleSheet::set_StyleSheetName(string&)
  } // end of property IHStyleSheet::StyleSheetName
  .property callconv(8) int32 StyleSheetMode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 01 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.MMLocal.IHStyleSheet::get_StyleSheetMode()
  } // end of property IHStyleSheet::StyleSheetMode
  .property callconv(8) int32 StyleSheetType(class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 01 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.MMLocal.IHStyleSheet::get_StyleSheetType(class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode)
    .set instance void AspenTech.AspenPlus.MMLocal.IHStyleSheet::set_StyleSheetType(class [Interop.Happ]AspenTech.AspenPlus.Happ.IHNode,
                                                                                    int32)
  } // end of property IHStyleSheet::StyleSheetType
  .property callconv(8) int32 AutoSave()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 01 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.MMLocal.IHStyleSheet::get_AutoSave()
    .set instance void AspenTech.AspenPlus.MMLocal.IHStyleSheet::set_AutoSave(int32)
  } // end of property IHStyleSheet::AutoSave
  .property callconv(8) class AspenTech.AspenPlus.MMLocal.IPropertyBag
          PropertyBag()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 01 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.MMLocal.IPropertyBag AspenTech.AspenPlus.MMLocal.IHStyleSheet::get_PropertyBag()
  } // end of property IHStyleSheet::PropertyBag
  .property callconv(8) int32 StyleSheetView()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 01 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.MMLocal.IHStyleSheet::set_StyleSheetView(int32)
    .get instance int32 AspenTech.AspenPlus.MMLocal.IHStyleSheet::get_StyleSheetView()
  } // end of property IHStyleSheet::StyleSheetView
  .property callconv(8) int32 StyleSheetIsDef()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 01 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.MMLocal.IHStyleSheet::get_StyleSheetIsDef()
    .set instance void AspenTech.AspenPlus.MMLocal.IHStyleSheet::set_StyleSheetIsDef(int32)
  } // end of property IHStyleSheet::StyleSheetIsDef
} // end of class AspenTech.AspenPlus.MMLocal.IHStyleSheet

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IPropertyBag
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 35 35 32 37 32 41 30 30 2D 34 32 43 42   // ..$55272A00-42CB
                                                                                                  2D 31 31 43 45 2D 38 31 33 35 2D 30 30 41 41 30   // -11CE-8135-00AA0
                                                                                                  30 34 42 42 38 35 31 00 00 )                      // 04BB851..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  RemoteRead([in] string  marshal( lpwstr) pszPropName,
                                    [out] object&  marshal( struct) pVar,
                                    [in] class AspenTech.AspenPlus.MMLocal.IErrorLog  marshal( interface ) pErrorLog,
                                    [in] uint32 varType,
                                    [in] object  marshal( iunknown ) pUnkObj) runtime managed internalcall
  {
  } // end of method IPropertyBag::RemoteRead

  .method public hidebysig newslot abstract virtual 
          instance void  Write([in] string  marshal( lpwstr) pszPropName,
                               [in] object&  marshal( struct) pVar) runtime managed internalcall
  {
  } // end of method IPropertyBag::Write

} // end of class AspenTech.AspenPlus.MMLocal.IPropertyBag

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.SSPKPROP
       extends [mscorlib]System.ValueType
{
  .pack 4
  .size 0
  .field public int32 lSubstream
  .field public int32 lBasis
  .field public int32 lQual
  .field public uint8 chPhase
  .field public  marshal( fixed array [3]) uint8[] chUnits
  .field public int32 iProptype
  .field public int32 lCurvflg
  .field public int32 lblenmeth
  .field public int32 lexpolflg
  .field public  marshal( fixed array [9]) uint8[] chDefProp
} // end of class AspenTech.AspenPlus.MMLocal.SSPKPROP

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IErrorLog
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 33 31 32 37 43 41 34 30 2D 34 34 36 45   // ..$3127CA40-446E
                                                                                                  2D 31 31 43 45 2D 38 31 33 35 2D 30 30 41 41 30   // -11CE-8135-00AA0
                                                                                                  30 34 42 42 38 35 31 00 00 )                      // 04BB851..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  AddError([in] string  marshal( lpwstr) pszPropName,
                                  [in] valuetype [stdole]stdole.EXCEPINFO& pExcepInfo) runtime managed internalcall
  {
  } // end of method IErrorLog::AddError

} // end of class AspenTech.AspenPlus.MMLocal.IErrorLog

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IHSelection_Drag_Drop
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 35 34 30 44 37 35 37 30 2D 46 33 39 31   // ..$540D7570-F391
                                                                                                  2D 31 31 44 33 2D 38 32 36 31 2D 30 30 43 30 34   // -11D3-8261-00C04
                                                                                                  46 37 33 36 30 36 39 00 00 )                      // F736069..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance bool  PasteOnDrop([in] class AspenTech.AspenPlus.MMLocal.IDataObject  marshal( interface ) pDataObject) runtime managed internalcall
  {
  } // end of method IHSelection_Drag_Drop::PasteOnDrop

} // end of class AspenTech.AspenPlus.MMLocal.IHSelection_Drag_Drop

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IDataObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 30 30 30 31 30 45 2D 30 30 30 30   // ..$0000010E-0000
                                                                                                  2D 30 30 30 30 2D 43 30 30 30 2D 30 30 30 30 30   // -0000-C000-00000
                                                                                                  30 30 30 30 30 34 36 00 00 )                      // 0000046..
  .method public hidebysig newslot abstract virtual 
          instance void  RemoteGetData([in] valuetype AspenTech.AspenPlus.MMLocal.FORMATETC& pformatetcIn,
                                       [out] native int pRemoteMedium) runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 29 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..)AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 4D 4D 4C 6F 63 61 6C 2E 77   // enPlus.MMLocal.w
                                                                                                            69 72 65 53 54 47 4D 45 44 49 55 4D 00 00 )       // ireSTGMEDIUM..
  } // end of method IDataObject::RemoteGetData

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteGetDataHere([in] valuetype AspenTech.AspenPlus.MMLocal.FORMATETC& pformatetc,
                                           [in][out] native int pRemoteMedium) runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 29 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..)AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 4D 4D 4C 6F 63 61 6C 2E 77   // enPlus.MMLocal.w
                                                                                                            69 72 65 53 54 47 4D 45 44 49 55 4D 00 00 )       // ireSTGMEDIUM..
  } // end of method IDataObject::RemoteGetDataHere

  .method public hidebysig newslot abstract virtual 
          instance void  QueryGetData([in] valuetype AspenTech.AspenPlus.MMLocal.FORMATETC& pformatetc) runtime managed internalcall
  {
  } // end of method IDataObject::QueryGetData

  .method public hidebysig newslot abstract virtual 
          instance void  GetCanonicalFormatEtc([in] valuetype AspenTech.AspenPlus.MMLocal.FORMATETC& pformatectIn,
                                               [out] valuetype AspenTech.AspenPlus.MMLocal.FORMATETC& pformatetcOut) runtime managed internalcall
  {
  } // end of method IDataObject::GetCanonicalFormatEtc

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteSetData([in] valuetype AspenTech.AspenPlus.MMLocal.FORMATETC& pformatetc,
                                       [in] native int pmedium,
                                       [in] int32 fRelease) runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2E 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ...AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 4D 4D 4C 6F 63 61 6C 2E 77   // enPlus.MMLocal.w
                                                                                                            69 72 65 46 4C 41 47 5F 53 54 47 4D 45 44 49 55   // ireFLAG_STGMEDIU
                                                                                                            4D 00 00 )                                        // M..
  } // end of method IDataObject::RemoteSetData

  .method public hidebysig newslot abstract virtual 
          instance void  EnumFormatEtc([in] uint32 dwDirection,
                                       [out] class AspenTech.AspenPlus.MMLocal.IEnumFORMATETC&  marshal( interface ) ppenumFormatEtc) runtime managed internalcall
  {
  } // end of method IDataObject::EnumFormatEtc

  .method public hidebysig newslot abstract virtual 
          instance void  DAdvise([in] valuetype AspenTech.AspenPlus.MMLocal.FORMATETC& pformatetc,
                                 [in] uint32 advf,
                                 [in] class AspenTech.AspenPlus.MMLocal.IAdviseSink  marshal( interface ) pAdvSink,
                                 [out] uint32& pdwConnection) runtime managed internalcall
  {
  } // end of method IDataObject::DAdvise

  .method public hidebysig newslot abstract virtual 
          instance void  DUnadvise([in] uint32 dwConnection) runtime managed internalcall
  {
  } // end of method IDataObject::DUnadvise

  .method public hidebysig newslot abstract virtual 
          instance void  EnumDAdvise([out] class AspenTech.AspenPlus.MMLocal.IEnumSTATDATA&  marshal( interface ) ppenumAdvise) runtime managed internalcall
  {
  } // end of method IDataObject::EnumDAdvise

} // end of class AspenTech.AspenPlus.MMLocal.IDataObject

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.FORMATETC
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public native int cfFormat
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..*AspenTech.Asp
                                                                                                          65 6E 50 6C 75 73 2E 4D 4D 4C 6F 63 61 6C 2E 77   // enPlus.MMLocal.w
                                                                                                          69 72 65 43 4C 49 50 46 4F 52 4D 41 54 00 00 )    // ireCLIPFORMAT..
  .field public native int ptd
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 dwAspect
  .field public int32 lindex
  .field public uint32 tymed
} // end of class AspenTech.AspenPlus.MMLocal.FORMATETC

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.userSTGMEDIUM
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public valuetype AspenTech.AspenPlus.MMLocal._STGMEDIUM_UNION DUMMYUNIONNAME
  .field public  marshal( iunknown ) object pUnkForRelease
} // end of class AspenTech.AspenPlus.MMLocal.userSTGMEDIUM

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.userFLAG_STGMEDIUM
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public int32 ContextFlags
  .field public int32 fPassOwnership
  .field public valuetype AspenTech.AspenPlus.MMLocal.userSTGMEDIUM Stgmed
} // end of class AspenTech.AspenPlus.MMLocal.userFLAG_STGMEDIUM

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IEnumFORMATETC
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 30 30 30 31 30 33 2D 30 30 30 30   // ..$00000103-0000
                                                                                                  2D 30 30 30 30 2D 43 30 30 30 2D 30 30 30 30 30   // -0000-C000-00000
                                                                                                  30 30 30 30 30 34 36 00 00 )                      // 0000046..
  .method public hidebysig newslot abstract virtual 
          instance void  RemoteNext([in] uint32 celt,
                                    [out] valuetype AspenTech.AspenPlus.MMLocal.FORMATETC& rgelt,
                                    [out] uint32& pceltFetched) runtime managed internalcall
  {
  } // end of method IEnumFORMATETC::RemoteNext

  .method public hidebysig newslot abstract virtual 
          instance void  Skip([in] uint32 celt) runtime managed internalcall
  {
  } // end of method IEnumFORMATETC::Skip

  .method public hidebysig newslot abstract virtual 
          instance void  Reset() runtime managed internalcall
  {
  } // end of method IEnumFORMATETC::Reset

  .method public hidebysig newslot abstract virtual 
          instance void  Clone([out] class AspenTech.AspenPlus.MMLocal.IEnumFORMATETC&  marshal( interface ) ppenum) runtime managed internalcall
  {
  } // end of method IEnumFORMATETC::Clone

} // end of class AspenTech.AspenPlus.MMLocal.IEnumFORMATETC

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IAdviseSink
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 30 30 30 31 30 46 2D 30 30 30 30   // ..$0000010F-0000
                                                                                                  2D 30 30 30 30 2D 43 30 30 30 2D 30 30 30 30 30   // -0000-C000-00000
                                                                                                  30 30 30 30 30 34 36 00 00 )                      // 0000046..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  RemoteOnDataChange([in] valuetype AspenTech.AspenPlus.MMLocal.FORMATETC& pformatetc,
                                            [in] native int pStgmed) runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2F 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ../AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 4D 4D 4C 6F 63 61 6C 2E 77   // enPlus.MMLocal.w
                                                                                                            69 72 65 41 53 59 4E 43 5F 53 54 47 4D 45 44 49   // ireASYNC_STGMEDI
                                                                                                            55 4D 00 00 )                                     // UM..
  } // end of method IAdviseSink::RemoteOnDataChange

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteOnViewChange([in] uint32 dwAspect,
                                            [in] int32 lindex) runtime managed internalcall
  {
  } // end of method IAdviseSink::RemoteOnViewChange

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteOnRename([in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmk) runtime managed internalcall
  {
  } // end of method IAdviseSink::RemoteOnRename

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteOnSave() runtime managed internalcall
  {
  } // end of method IAdviseSink::RemoteOnSave

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteOnClose() runtime managed internalcall
  {
  } // end of method IAdviseSink::RemoteOnClose

} // end of class AspenTech.AspenPlus.MMLocal.IAdviseSink

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IEnumSTATDATA
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 30 30 30 31 30 35 2D 30 30 30 30   // ..$00000105-0000
                                                                                                  2D 30 30 30 30 2D 43 30 30 30 2D 30 30 30 30 30   // -0000-C000-00000
                                                                                                  30 30 30 30 30 34 36 00 00 )                      // 0000046..
  .method public hidebysig newslot abstract virtual 
          instance void  RemoteNext([in] uint32 celt,
                                    [out] valuetype AspenTech.AspenPlus.MMLocal.STATDATA& rgelt,
                                    [out] uint32& pceltFetched) runtime managed internalcall
  {
  } // end of method IEnumSTATDATA::RemoteNext

  .method public hidebysig newslot abstract virtual 
          instance void  Skip([in] uint32 celt) runtime managed internalcall
  {
  } // end of method IEnumSTATDATA::Skip

  .method public hidebysig newslot abstract virtual 
          instance void  Reset() runtime managed internalcall
  {
  } // end of method IEnumSTATDATA::Reset

  .method public hidebysig newslot abstract virtual 
          instance void  Clone([out] class AspenTech.AspenPlus.MMLocal.IEnumSTATDATA&  marshal( interface ) ppenum) runtime managed internalcall
  {
  } // end of method IEnumSTATDATA::Clone

} // end of class AspenTech.AspenPlus.MMLocal.IEnumSTATDATA

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.userCLIPFORMAT
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public int32 fContext
  .field public valuetype AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0001 u
} // end of class AspenTech.AspenPlus.MMLocal.userCLIPFORMAT

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.DVTARGETDEVICE
       extends [mscorlib]System.ValueType
{
  .pack 4
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 tdSize
  .field public uint16 tdDriverNameOffset
  .field public uint16 tdDeviceNameOffset
  .field public uint16 tdPortNameOffset
  .field public uint16 tdExtDevmodeOffset
  .field public native int tdData
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.MMLocal.DVTARGETDEVICE

.class public explicit ansi sealed AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0001
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 8
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field [0] public uint32 dwValue
} // end of class AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0001

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal._STGMEDIUM_UNION
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public uint32 tymed
  .field public valuetype AspenTech.AspenPlus.MMLocal.__MIDL_IAdviseSink_0003 u
} // end of class AspenTech.AspenPlus.MMLocal._STGMEDIUM_UNION

.class public explicit ansi sealed AspenTech.AspenPlus.MMLocal.__MIDL_IAdviseSink_0003
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 8
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.MMLocal.__MIDL_IAdviseSink_0003

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.userHMETAFILEPICT
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public int32 fContext
  .field public valuetype AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0005 u
} // end of class AspenTech.AspenPlus.MMLocal.userHMETAFILEPICT

.class public explicit ansi sealed AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0005
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 8
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field [0] public int32 hInproc
  .field [0] public int64 hInproc64
} // end of class AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0005

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.remoteMETAFILEPICT
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public int32 mm
  .field public int32 xExt
  .field public int32 yExt
  .field public native int hMF
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.MMLocal.remoteMETAFILEPICT

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.userHMETAFILE
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public int32 fContext
  .field public valuetype AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0004 u
} // end of class AspenTech.AspenPlus.MMLocal.userHMETAFILE

.class public explicit ansi sealed AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0004
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 8
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field [0] public int32 hInproc
  .field [0] public int64 hInproc64
} // end of class AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0004

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.BYTE_BLOB
       extends [mscorlib]System.ValueType
{
  .pack 4
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 clSize
  .field public native int abData
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.MMLocal.BYTE_BLOB

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.userHENHMETAFILE
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public int32 fContext
  .field public valuetype AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0006 u
} // end of class AspenTech.AspenPlus.MMLocal.userHENHMETAFILE

.class public explicit ansi sealed AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0006
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 8
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field [0] public int32 hInproc
  .field [0] public int64 hInproc64
} // end of class AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0006

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.GDI_OBJECT
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public uint32 ObjectType
  .field public valuetype AspenTech.AspenPlus.MMLocal.__MIDL_IAdviseSink_0002 u
} // end of class AspenTech.AspenPlus.MMLocal.GDI_OBJECT

.class public explicit ansi sealed AspenTech.AspenPlus.MMLocal.__MIDL_IAdviseSink_0002
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 8
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.MMLocal.__MIDL_IAdviseSink_0002

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.userHBITMAP
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public int32 fContext
  .field public valuetype AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0007 u
} // end of class AspenTech.AspenPlus.MMLocal.userHBITMAP

.class public explicit ansi sealed AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0007
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 8
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field [0] public int32 hInproc
  .field [0] public int64 hInproc64
} // end of class AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0007

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.userBITMAP
       extends [mscorlib]System.ValueType
{
  .pack 4
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public int32 bmType
  .field public int32 bmWidth
  .field public int32 bmHeight
  .field public int32 bmWidthBytes
  .field public uint16 bmPlanes
  .field public uint16 bmBitsPixel
  .field public uint32 cbSize
  .field public native int pBuffer
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.MMLocal.userBITMAP

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.userHPALETTE
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public int32 fContext
  .field public valuetype AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0008 u
} // end of class AspenTech.AspenPlus.MMLocal.userHPALETTE

.class public explicit ansi sealed AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0008
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 8
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field [0] public int32 hInproc
  .field [0] public int64 hInproc64
} // end of class AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0008

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.LOGPALETTE
       extends [mscorlib]System.ValueType
{
  .pack 2
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint16 palVersion
  .field public uint16 palNumEntries
  .field public native int palPalEntry
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.MMLocal.LOGPALETTE

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.PALETTEENTRY
       extends [mscorlib]System.ValueType
{
  .pack 1
  .size 0
  .field public uint8 peRed
  .field public uint8 peGreen
  .field public uint8 peBlue
  .field public uint8 peFlags
} // end of class AspenTech.AspenPlus.MMLocal.PALETTEENTRY

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.userHGLOBAL
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public int32 fContext
  .field public valuetype AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0003 u
} // end of class AspenTech.AspenPlus.MMLocal.userHGLOBAL

.class public explicit ansi sealed AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0003
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 8
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field [0] public int32 hInproc
  .field [0] public int64 hInproc64
} // end of class AspenTech.AspenPlus.MMLocal.__MIDL_IWinTypes_0003

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.FLAGGED_BYTE_BLOB
       extends [mscorlib]System.ValueType
{
  .pack 4
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 fFlags
  .field public uint32 clSize
  .field public native int abData
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.MMLocal.FLAGGED_BYTE_BLOB

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IMoniker
       implements [Interop.Happ]AspenTech.AspenPlus.Happ.IPersistStream
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 30 30 30 30 30 46 2D 30 30 30 30   // ..$0000000F-0000
                                                                                                  2D 30 30 30 30 2D 43 30 30 30 2D 30 30 30 30 30   // -0000-C000-00000
                                                                                                  30 30 30 30 30 34 36 00 00 )                      // 0000046..
  .method public hidebysig newslot abstract virtual 
          instance void  GetClassID([out] valuetype [mscorlib]System.Guid& pClassID) runtime managed internalcall
  {
  } // end of method IMoniker::GetClassID

  .method public hidebysig newslot abstract virtual 
          instance void  IsDirty() runtime managed internalcall
  {
  } // end of method IMoniker::IsDirty

  .method public hidebysig newslot abstract virtual 
          instance void  Load([in] class [Interop.Happ]AspenTech.AspenPlus.Happ.IStream  marshal( interface ) pstm) runtime managed internalcall
  {
  } // end of method IMoniker::Load

  .method public hidebysig newslot abstract virtual 
          instance void  Save([in] class [Interop.Happ]AspenTech.AspenPlus.Happ.IStream  marshal( interface ) pstm,
                              [in] int32 fClearDirty) runtime managed internalcall
  {
  } // end of method IMoniker::Save

  .method public hidebysig newslot abstract virtual 
          instance void  GetSizeMax([out] valuetype [Interop.Happ]AspenTech.AspenPlus.Happ.ULARGE_INTEGER& pcbSize) runtime managed internalcall
  {
  } // end of method IMoniker::GetSizeMax

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteBindToObject([in] class AspenTech.AspenPlus.MMLocal.IBindCtx  marshal( interface ) pbc,
                                            [in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkToLeft,
                                            [in] valuetype [mscorlib]System.Guid& riidResult,
                                            [out] object&  marshal( iunknown ) ppvResult) runtime managed internalcall
  {
  } // end of method IMoniker::RemoteBindToObject

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteBindToStorage([in] class AspenTech.AspenPlus.MMLocal.IBindCtx  marshal( interface ) pbc,
                                             [in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkToLeft,
                                             [in] valuetype [mscorlib]System.Guid& riid,
                                             [out] object&  marshal( iunknown ) ppvObj) runtime managed internalcall
  {
  } // end of method IMoniker::RemoteBindToStorage

  .method public hidebysig newslot abstract virtual 
          instance void  Reduce([in] class AspenTech.AspenPlus.MMLocal.IBindCtx  marshal( interface ) pbc,
                                [in] uint32 dwReduceHowFar,
                                [in][out] class AspenTech.AspenPlus.MMLocal.IMoniker&  marshal( interface ) ppmkToLeft,
                                [out] class AspenTech.AspenPlus.MMLocal.IMoniker&  marshal( interface ) ppmkReduced) runtime managed internalcall
  {
  } // end of method IMoniker::Reduce

  .method public hidebysig newslot abstract virtual 
          instance void  ComposeWith([in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkRight,
                                     [in] int32 fOnlyIfNotGeneric,
                                     [out] class AspenTech.AspenPlus.MMLocal.IMoniker&  marshal( interface ) ppmkComposite) runtime managed internalcall
  {
  } // end of method IMoniker::ComposeWith

  .method public hidebysig newslot abstract virtual 
          instance void  Enum([in] int32 fForward,
                              [out] class AspenTech.AspenPlus.MMLocal.IEnumMoniker&  marshal( interface ) ppenumMoniker) runtime managed internalcall
  {
  } // end of method IMoniker::Enum

  .method public hidebysig newslot abstract virtual 
          instance void  IsEqual([in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkOtherMoniker) runtime managed internalcall
  {
  } // end of method IMoniker::IsEqual

  .method public hidebysig newslot abstract virtual 
          instance void  Hash([out] uint32& pdwHash) runtime managed internalcall
  {
  } // end of method IMoniker::Hash

  .method public hidebysig newslot abstract virtual 
          instance void  IsRunning([in] class AspenTech.AspenPlus.MMLocal.IBindCtx  marshal( interface ) pbc,
                                   [in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkToLeft,
                                   [in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkNewlyRunning) runtime managed internalcall
  {
  } // end of method IMoniker::IsRunning

  .method public hidebysig newslot abstract virtual 
          instance void  GetTimeOfLastChange([in] class AspenTech.AspenPlus.MMLocal.IBindCtx  marshal( interface ) pbc,
                                             [in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkToLeft,
                                             [out] valuetype [Interop.Happ]AspenTech.AspenPlus.Happ.FILETIME& pfiletime) runtime managed internalcall
  {
  } // end of method IMoniker::GetTimeOfLastChange

  .method public hidebysig newslot abstract virtual 
          instance void  Inverse([out] class AspenTech.AspenPlus.MMLocal.IMoniker&  marshal( interface ) ppmk) runtime managed internalcall
  {
  } // end of method IMoniker::Inverse

  .method public hidebysig newslot abstract virtual 
          instance void  CommonPrefixWith([in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkOther,
                                          [out] class AspenTech.AspenPlus.MMLocal.IMoniker&  marshal( interface ) ppmkPrefix) runtime managed internalcall
  {
  } // end of method IMoniker::CommonPrefixWith

  .method public hidebysig newslot abstract virtual 
          instance void  RelativePathTo([in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkOther,
                                        [out] class AspenTech.AspenPlus.MMLocal.IMoniker&  marshal( interface ) ppmkRelPath) runtime managed internalcall
  {
  } // end of method IMoniker::RelativePathTo

  .method public hidebysig newslot abstract virtual 
          instance void  GetDisplayName([in] class AspenTech.AspenPlus.MMLocal.IBindCtx  marshal( interface ) pbc,
                                        [in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkToLeft,
                                        [out] string&  marshal( lpwstr) ppszDisplayName) runtime managed internalcall
  {
  } // end of method IMoniker::GetDisplayName

  .method public hidebysig newslot abstract virtual 
          instance void  ParseDisplayName([in] class AspenTech.AspenPlus.MMLocal.IBindCtx  marshal( interface ) pbc,
                                          [in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkToLeft,
                                          [in] string  marshal( lpwstr) pszDisplayName,
                                          [out] uint32& pchEaten,
                                          [out] class AspenTech.AspenPlus.MMLocal.IMoniker&  marshal( interface ) ppmkOut) runtime managed internalcall
  {
  } // end of method IMoniker::ParseDisplayName

  .method public hidebysig newslot abstract virtual 
          instance void  IsSystemMoniker([out] uint32& pdwMksys) runtime managed internalcall
  {
  } // end of method IMoniker::IsSystemMoniker

} // end of class AspenTech.AspenPlus.MMLocal.IMoniker

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IBindCtx
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 30 30 30 30 30 45 2D 30 30 30 30   // ..$0000000E-0000
                                                                                                  2D 30 30 30 30 2D 43 30 30 30 2D 30 30 30 30 30   // -0000-C000-00000
                                                                                                  30 30 30 30 30 34 36 00 00 )                      // 0000046..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  RegisterObjectBound([in] object  marshal( iunknown ) punk) runtime managed internalcall
  {
  } // end of method IBindCtx::RegisterObjectBound

  .method public hidebysig newslot abstract virtual 
          instance void  RevokeObjectBound([in] object  marshal( iunknown ) punk) runtime managed internalcall
  {
  } // end of method IBindCtx::RevokeObjectBound

  .method public hidebysig newslot abstract virtual 
          instance void  ReleaseBoundObjects() runtime managed internalcall
  {
  } // end of method IBindCtx::ReleaseBoundObjects

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteSetBindOptions([in] valuetype AspenTech.AspenPlus.MMLocal.BIND_OPTS2& pbindopts) runtime managed internalcall
  {
  } // end of method IBindCtx::RemoteSetBindOptions

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteGetBindOptions([in][out] valuetype AspenTech.AspenPlus.MMLocal.BIND_OPTS2& pbindopts) runtime managed internalcall
  {
  } // end of method IBindCtx::RemoteGetBindOptions

  .method public hidebysig newslot abstract virtual 
          instance void  GetRunningObjectTable([out] class AspenTech.AspenPlus.MMLocal.IRunningObjectTable&  marshal( interface ) pprot) runtime managed internalcall
  {
  } // end of method IBindCtx::GetRunningObjectTable

  .method public hidebysig newslot abstract virtual 
          instance void  RegisterObjectParam([in] string  marshal( lpwstr) pszKey,
                                             [in] object  marshal( iunknown ) punk) runtime managed internalcall
  {
  } // end of method IBindCtx::RegisterObjectParam

  .method public hidebysig newslot abstract virtual 
          instance void  GetObjectParam([in] string  marshal( lpwstr) pszKey,
                                        [out] object&  marshal( iunknown ) ppunk) runtime managed internalcall
  {
  } // end of method IBindCtx::GetObjectParam

  .method public hidebysig newslot abstract virtual 
          instance void  EnumObjectParam([out] class AspenTech.AspenPlus.MMLocal.IEnumString&  marshal( interface ) ppenum) runtime managed internalcall
  {
  } // end of method IBindCtx::EnumObjectParam

  .method public hidebysig newslot abstract virtual 
          instance void  RevokeObjectParam([in] string  marshal( lpwstr) pszKey) runtime managed internalcall
  {
  } // end of method IBindCtx::RevokeObjectParam

} // end of class AspenTech.AspenPlus.MMLocal.IBindCtx

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IEnumMoniker
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 30 30 30 31 30 32 2D 30 30 30 30   // ..$00000102-0000
                                                                                                  2D 30 30 30 30 2D 43 30 30 30 2D 30 30 30 30 30   // -0000-C000-00000
                                                                                                  30 30 30 30 30 34 36 00 00 )                      // 0000046..
  .method public hidebysig newslot abstract virtual 
          instance void  RemoteNext([in] uint32 celt,
                                    [out] class AspenTech.AspenPlus.MMLocal.IMoniker&  marshal( interface ) rgelt,
                                    [out] uint32& pceltFetched) runtime managed internalcall
  {
  } // end of method IEnumMoniker::RemoteNext

  .method public hidebysig newslot abstract virtual 
          instance void  Skip([in] uint32 celt) runtime managed internalcall
  {
  } // end of method IEnumMoniker::Skip

  .method public hidebysig newslot abstract virtual 
          instance void  Reset() runtime managed internalcall
  {
  } // end of method IEnumMoniker::Reset

  .method public hidebysig newslot abstract virtual 
          instance void  Clone([out] class AspenTech.AspenPlus.MMLocal.IEnumMoniker&  marshal( interface ) ppenum) runtime managed internalcall
  {
  } // end of method IEnumMoniker::Clone

} // end of class AspenTech.AspenPlus.MMLocal.IEnumMoniker

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.BIND_OPTS2
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 cbStruct
  .field public uint32 grfFlags
  .field public uint32 grfMode
  .field public uint32 dwTickCountDeadline
  .field public uint32 dwTrackFlags
  .field public uint32 dwClassContext
  .field public uint32 locale
  .field public native int pServerInfo
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.MMLocal.BIND_OPTS2

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IRunningObjectTable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 30 30 30 30 31 30 2D 30 30 30 30   // ..$00000010-0000
                                                                                                  2D 30 30 30 30 2D 43 30 30 30 2D 30 30 30 30 30   // -0000-C000-00000
                                                                                                  30 30 30 30 30 34 36 00 00 )                      // 0000046..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  Register([in] uint32 grfFlags,
                                  [in] object  marshal( iunknown ) punkObject,
                                  [in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkObjectName,
                                  [out] uint32& pdwRegister) runtime managed internalcall
  {
  } // end of method IRunningObjectTable::Register

  .method public hidebysig newslot abstract virtual 
          instance void  Revoke([in] uint32 dwRegister) runtime managed internalcall
  {
  } // end of method IRunningObjectTable::Revoke

  .method public hidebysig newslot abstract virtual 
          instance void  IsRunning([in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkObjectName) runtime managed internalcall
  {
  } // end of method IRunningObjectTable::IsRunning

  .method public hidebysig newslot abstract virtual 
          instance void  GetObject([in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkObjectName,
                                   [out] object&  marshal( iunknown ) ppunkObject) runtime managed internalcall
  {
  } // end of method IRunningObjectTable::GetObject

  .method public hidebysig newslot abstract virtual 
          instance void  NoteChangeTime([in] uint32 dwRegister,
                                        [in] valuetype [Interop.Happ]AspenTech.AspenPlus.Happ.FILETIME& pfiletime) runtime managed internalcall
  {
  } // end of method IRunningObjectTable::NoteChangeTime

  .method public hidebysig newslot abstract virtual 
          instance void  GetTimeOfLastChange([in] class AspenTech.AspenPlus.MMLocal.IMoniker  marshal( interface ) pmkObjectName,
                                             [out] valuetype [Interop.Happ]AspenTech.AspenPlus.Happ.FILETIME& pfiletime) runtime managed internalcall
  {
  } // end of method IRunningObjectTable::GetTimeOfLastChange

  .method public hidebysig newslot abstract virtual 
          instance void  EnumRunning([out] class AspenTech.AspenPlus.MMLocal.IEnumMoniker&  marshal( interface ) ppenumMoniker) runtime managed internalcall
  {
  } // end of method IRunningObjectTable::EnumRunning

} // end of class AspenTech.AspenPlus.MMLocal.IRunningObjectTable

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IEnumString
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 30 30 30 31 30 31 2D 30 30 30 30   // ..$00000101-0000
                                                                                                  2D 30 30 30 30 2D 43 30 30 30 2D 30 30 30 30 30   // -0000-C000-00000
                                                                                                  30 30 30 30 30 34 36 00 00 )                      // 0000046..
  .method public hidebysig newslot abstract virtual 
          instance void  RemoteNext([in] uint32 celt,
                                    [out] string&  marshal( lpwstr) rgelt,
                                    [out] uint32& pceltFetched) runtime managed internalcall
  {
  } // end of method IEnumString::RemoteNext

  .method public hidebysig newslot abstract virtual 
          instance void  Skip([in] uint32 celt) runtime managed internalcall
  {
  } // end of method IEnumString::Skip

  .method public hidebysig newslot abstract virtual 
          instance void  Reset() runtime managed internalcall
  {
  } // end of method IEnumString::Reset

  .method public hidebysig newslot abstract virtual 
          instance void  Clone([out] class AspenTech.AspenPlus.MMLocal.IEnumString&  marshal( interface ) ppenum) runtime managed internalcall
  {
  } // end of method IEnumString::Clone

} // end of class AspenTech.AspenPlus.MMLocal.IEnumString

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.COSERVERINFO
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 dwReserved1
  .field public  marshal( lpwstr) string pwszName
  .field public native int pAuthInfo
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 dwReserved2
} // end of class AspenTech.AspenPlus.MMLocal.COSERVERINFO

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.COAUTHINFO
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 dwAuthnSvc
  .field public uint32 dwAuthzSvc
  .field public  marshal( lpwstr) string pwszServerPrincName
  .field public uint32 dwAuthnLevel
  .field public uint32 dwImpersonationLevel
  .field public native int pAuthIdentityData
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 dwCapabilities
} // end of class AspenTech.AspenPlus.MMLocal.COAUTHINFO

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.COAUTHIDENTITY
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public native int User
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 UserLength
  .field public native int Domain
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 DomainLength
  .field public native int Password
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public uint32 PasswordLength
  .field public uint32 Flags
} // end of class AspenTech.AspenPlus.MMLocal.COAUTHIDENTITY

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.STATDATA
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public valuetype AspenTech.AspenPlus.MMLocal.FORMATETC FORMATETC
  .field public uint32 advf
  .field public  marshal( interface ) class AspenTech.AspenPlus.MMLocal.IAdviseSink pAdvSink
  .field public uint32 dwConnection
} // end of class AspenTech.AspenPlus.MMLocal.STATDATA

.class public auto ansi sealed AspenTech.AspenPlus.MMLocal.NonBeadSSheetHandles
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.NonBeadSSheetHandles eDefaultSheetHandle = int32(0xFFFFD8F1)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.NonBeadSSheetHandles eXMLSheet_FirstHandle = int32(0xFFFFFFFF)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.NonBeadSSheetHandles eXMLSheet_LastHandle = int32(0xFFFFFE0C)
} // end of class AspenTech.AspenPlus.MMLocal.NonBeadSSheetHandles

.class public auto ansi sealed AspenTech.AspenPlus.MMLocal.SubstreamType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.SubstreamType ePKMIXED = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.SubstreamType ePKCISOLID = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.SubstreamType ePKNC = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.SubstreamType ePKALL = int32(0x00000008)
} // end of class AspenTech.AspenPlus.MMLocal.SubstreamType

.class public auto ansi sealed AspenTech.AspenPlus.MMLocal.PhaseType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.PhaseType ePKTOTAL = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.PhaseType ePKV = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.PhaseType ePKL = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.PhaseType ePKL1 = int32(0x00000008)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.PhaseType ePKL2 = int32(0x00000010)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.PhaseType ePKS = int32(0x00000020)
} // end of class AspenTech.AspenPlus.MMLocal.PhaseType

.class public auto ansi sealed AspenTech.AspenPlus.MMLocal.QualType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.QualType ePKCOMP = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.QualType ePKPHASE = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.QualType ePKTEMP = int32(0x00000010)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.QualType ePKPRES = int32(0x00000040)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.QualType ePKPCTLV = int32(0x00000100)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.QualType ePKBASECOMP = int32(0x00000400)
} // end of class AspenTech.AspenPlus.MMLocal.QualType

.class public auto ansi sealed AspenTech.AspenPlus.MMLocal.CollectionType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.CollectionType CT_Invalid = int32(0xFFFFFFFF)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.CollectionType CT_ASCBlocks = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.CollectionType CT_ASCVariables = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.CollectionType CT_ASCParameters = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.CollectionType CT_ASCPorts = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.CollectionType CT_ASCEquations = int32(0x00000004)
} // end of class AspenTech.AspenPlus.MMLocal.CollectionType

.class public auto ansi sealed AspenTech.AspenPlus.MMLocal.ObjectType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.ObjectType OT_Invalid = int32(0xFFFFFFFF)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.ObjectType OT_EO = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.ObjectType OT_ACM = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.ObjectType OT_CAPEOPEN = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.ObjectType OT_IDispatch = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.ObjectType OT_ACMCustomForm = int32(0x00000004)
} // end of class AspenTech.AspenPlus.MMLocal.ObjectType

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IASCObjectProvider
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 35 31 38 39 42 37 45 2D 37 37 45 42   // ..$F5189B7E-77EB
                                                                                                  2D 34 39 30 30 2D 42 45 32 33 2D 39 45 35 44 43   // -4900-BE23-9E5DC
                                                                                                  46 36 43 45 35 46 41 00 00 )                      // F6CE5FA..
  .method public hidebysig newslot abstract virtual 
          instance native int  GetObject([in] valuetype AspenTech.AspenPlus.MMLocal.ObjectType Type,
                                         [in] string  marshal( bstr) Name) runtime managed internalcall
  {
  } // end of method IASCObjectProvider::GetObject

  .method public hidebysig newslot abstract virtual 
          instance native int  GetObjectCollection([in] valuetype AspenTech.AspenPlus.MMLocal.ObjectType Type,
                                                   [in] valuetype AspenTech.AspenPlus.MMLocal.CollectionType ColType,
                                                   [in] string  marshal( bstr) Name) runtime managed internalcall
  {
  } // end of method IASCObjectProvider::GetObjectCollection

} // end of class AspenTech.AspenPlus.MMLocal.IASCObjectProvider

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IHASCConfigObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 37 35 38 44 39 39 33 44 2D 45 32 46 30   // ..$758D993D-E2F0
                                                                                                  2D 34 35 44 41 2D 41 37 45 41 2D 32 36 46 35 30   // -45DA-A7EA-26F50
                                                                                                  36 41 42 31 31 43 42 00 00 )                      // 6AB11CB..
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_ObjectName() runtime managed internalcall
  {
  } // end of method IHASCConfigObject::get_ObjectName

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_HierarchyName() runtime managed internalcall
  {
  } // end of method IHASCConfigObject::get_HierarchyName

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_ExcludePath() runtime managed internalcall
  {
  } // end of method IHASCConfigObject::get_ExcludePath

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.MMLocal.CollectionType 
          get_CollectionType() runtime managed internalcall
  {
  } // end of method IHASCConfigObject::get_CollectionType

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.MMLocal.ObjectType 
          get_ObjectType() runtime managed internalcall
  {
  } // end of method IHASCConfigObject::get_ObjectType

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Selection() runtime managed internalcall
  {
  } // end of method IHASCConfigObject::get_Selection

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Query() runtime managed internalcall
  {
  } // end of method IHASCConfigObject::get_Query

  .property callconv(8) string ObjectName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 01 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.MMLocal.IHASCConfigObject::get_ObjectName()
  } // end of property IHASCConfigObject::ObjectName
  .property callconv(8) string HierarchyName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 01 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.MMLocal.IHASCConfigObject::get_HierarchyName()
  } // end of property IHASCConfigObject::HierarchyName
  .property callconv(8) string ExcludePath()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 01 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.MMLocal.IHASCConfigObject::get_ExcludePath()
  } // end of property IHASCConfigObject::ExcludePath
  .property callconv(8) valuetype AspenTech.AspenPlus.MMLocal.CollectionType
          CollectionType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 01 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.MMLocal.CollectionType AspenTech.AspenPlus.MMLocal.IHASCConfigObject::get_CollectionType()
  } // end of property IHASCConfigObject::CollectionType
  .property callconv(8) valuetype AspenTech.AspenPlus.MMLocal.ObjectType
          ObjectType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 01 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.MMLocal.ObjectType AspenTech.AspenPlus.MMLocal.IHASCConfigObject::get_ObjectType()
  } // end of property IHASCConfigObject::ObjectType
  .property callconv(8) object Selection()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 01 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.MMLocal.IHASCConfigObject::get_Selection()
  } // end of property IHASCConfigObject::Selection
  .property callconv(8) string Query()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 01 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.MMLocal.IHASCConfigObject::get_Query()
  } // end of property IHASCConfigObject::Query
} // end of class AspenTech.AspenPlus.MMLocal.IHASCConfigObject

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IHappInternalMessage
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 42 43 39 30 46 36 32 42 2D 44 33 46 38   // ..$BC90F62B-D3F8
                                                                                                  2D 34 34 32 45 2D 38 45 31 45 2D 30 35 43 34 43   // -442E-8E1E-05C4C
                                                                                                  42 36 30 32 37 38 34 00 00 )                      // B602784..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance int64  SendMessage([in] uint32 message,
                                      [in] uint64 wParam,
                                      [in] int64 lParam) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 24 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..$AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 4D 4D 4C 6F 63 61 6C 2E 4C   // enPlus.MMLocal.L
                                                                                                            4F 4E 47 5F 50 54 52 00 00 )                      // ONG_PTR..
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 24 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..$AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 4D 4D 4C 6F 63 61 6C 2E 55   // enPlus.MMLocal.U
                                                                                                            49 4E 54 5F 50 54 52 00 00 )                      // INT_PTR..
    .param [3]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 24 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..$AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 4D 4D 4C 6F 63 61 6C 2E 4C   // enPlus.MMLocal.L
                                                                                                            4F 4E 47 5F 50 54 52 00 00 )                      // ONG_PTR..
  } // end of method IHappInternalMessage::SendMessage

  .method public hidebysig newslot abstract virtual 
          instance void  FireUpdateMessage([in] int32 lhint,
                                           [in] string  marshal( bstr) strHint,
                                           [in] native int objHint) runtime managed internalcall
  {
  } // end of method IHappInternalMessage::FireUpdateMessage

} // end of class AspenTech.AspenPlus.MMLocal.IHappInternalMessage

.class public auto ansi sealed AspenTech.AspenPlus.MMLocal.MMLocalEvent_DispID
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.MMLocalEvent_DispID DISPID_ENGINEDISCONNECT = int32(0x000000C8)
  .field public static literal valuetype AspenTech.AspenPlus.MMLocal.MMLocalEvent_DispID DISPID_ENGINERECONNECT = int32(0x000000C9)
} // end of class AspenTech.AspenPlus.MMLocal.MMLocalEvent_DispID

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IMMLocalEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 32 33 36 39 37 32 44 46 2D 35 38 44 31   // ..$236972DF-58D1
                                                                                                  2D 34 39 37 38 2D 39 34 39 32 2D 35 33 43 30 39   // -4978-9492-53C09
                                                                                                  46 45 43 32 43 33 33 00 00 )                      // FEC2C33..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 10 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  OnBeforeEngineDisconnect([in] object  marshal( struct) reserved) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 C8 00 00 00 00 00 ) 
  } // end of method IMMLocalEvents::OnBeforeEngineDisconnect

  .method public hidebysig newslot abstract virtual 
          instance void  OnAfterEngineReconnect([in] object  marshal( struct) reserved) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 C9 00 00 00 00 00 ) 
  } // end of method IMMLocalEvents::OnAfterEngineReconnect

} // end of class AspenTech.AspenPlus.MMLocal.IMMLocalEvents

.class interface public abstract auto ansi import AspenTech.AspenPlus.MMLocal.IHFormFactory
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 45 39 31 32 46 41 37 38 2D 45 41 38 32   // ..$E912FA78-EA82
                                                                                                  2D 34 37 36 31 2D 39 32 31 37 2D 46 46 30 34 38   // -4761-9217-FF048
                                                                                                  43 39 45 44 36 35 46 00 00 )                      // C9ED65F..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance bool  FormFactorySetNextForm([in] string  marshal( bstr) Name) runtime managed internalcall
  {
  } // end of method IHFormFactory::FormFactorySetNextForm

} // end of class AspenTech.AspenPlus.MMLocal.IHFormFactory

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.MMLocal.HASymbol
       extends [mscorlib]System.ValueType
{
  .pack 4
  .size 0
  .field public int32 ext
  .field public int32 val
} // end of class AspenTech.AspenPlus.MMLocal.HASymbol


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file C:\Users\Administrator\Desktop\Aspen 逆向\.local\batch-roundtrip-20261125\work-il\clr-1aygr1xu\editable\source.res
