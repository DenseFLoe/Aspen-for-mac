using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPLControls;
using WpfPlotwizard;

namespace WpfPLScreen;

[ProgId("WpfPLScreen.SepEff")]
public class SepEff : UserControl, IRibbonPlotWizardType, IPlotWizardTemplate, IComponentConnector
{
	private IHNode _context;

	private IHWizardPlot2 _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private string _uniqueId = WpfPLDiscurvesResources.SepEffID;

	private string _plotName;

	private object _nodeCxs;

	private string _currentLengthUnit = string.Empty;

	private System.Drawing.Image _imgBitmap;

	private bool _bHasInputDialog;

	private string _currentConfigValue = string.Empty;

	private static string _CancelValue = string.Empty;

	private readonly string _lengthUnitFieldId = WpfPLRPlugResources.Length;

	public static RoutedCommand OKCommand = new RoutedCommand();

	public static RoutedCommand CancelCommand = new RoutedCommand();

	private bool _bCheckDataOnly;

	internal CurvesSelectorControl SubStreamList;

	internal CurvesSelectorControl DeckList;

	private bool _contentLoaded;

	public string TooltipContentForRibbonItem => WpfPLDiscurvesResources.SepEff;

	public string TooltipHeaderForRibbonItem => WpfPLDiscurvesResources.SepEff;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot2;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _lengthUnitFieldId };

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public SepEff()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		InitializeComponent();
		_bHasInputDialog = true;
		if (_imgBitmap == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLScreen.Images.SepEff.ico");
			_imgBitmap = new Bitmap(manifestResourceStream);
		}
		_CancelValue = _currentConfigValue;
		CommandBinding commandBinding = new CommandBinding(OKCommand, ExecuteOKCommand, CanExecuteOKCommand);
		CommandBinding commandBinding2 = new CommandBinding(CancelCommand, ExecuteCancelCommand);
		base.CommandBindings.Add(commandBinding);
		base.CommandBindings.Add(commandBinding2);
	}

	public void SetCaption(ref string caption)
	{
		caption = WpfPLDiscurvesResources.SepEff;
		Window.GetWindow(this).Closing += RollBack;
	}

	public void SetDefaultHeight(ref double defaultHeight)
	{
		defaultHeight = 350.0;
	}

	public void SetDefaultWidth(ref double defaultWidth)
	{
		defaultWidth = 300.0;
	}

	public void SetMinHeight(ref double minHeight)
	{
		minHeight = 350.0;
	}

	public void SetMinWidth(ref double minWidth)
	{
		minWidth = 300.0;
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
		{
			List<string> list = new List<string>();
			_help.LoadXUnitsList(_context.Application.Tree, (IHWizardPlot)_wizardPlot, list);
			return list;
		}
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
		if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
		{
			sCurrentVal = _help.GetXUnitString(_context.Application.Tree, (IHWizardPlot)_wizardPlot);
		}
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
		if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
		{
			_currentLengthUnit = sValue;
		}
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		if (sField.CompareTo(_lengthUnitFieldId) == 0)
		{
			return (RibbonControlType)1;
		}
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
		sConfigValue = _currentConfigValue;
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
		_currentConfigValue = sValue;
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot2;
		List<string> list = new List<string>();
		IHNode iHNode = _context.FindNode("Output/SEP_EFF");
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		int count = iHNode.Elements.Count;
		for (int i = 0; i < count; i++)
		{
			string item = iHNode.Elements.get_Label(0, i, Type.Missing);
			list.Add(item);
		}
		SubStreamList.SetCurves(list.ToArray());
		SubStreamList.Header = WpfPLDiscurvesResources.PSDSubstream;
		List<string> list2 = new List<string>();
		if (string.IsNullOrEmpty(_currentConfigValue))
		{
			list2.Add(list[0].ToString());
			SubStreamList.SetSelectedCurves(list2.ToArray());
		}
		if (list.Count == 1)
		{
			SubStreamList.IsCheckAll = true;
		}
		iHNode = iHNode.Elements[list[0].ToString(), Type.Missing, Type.Missing, Type.Missing, Type.Missing];
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		List<string> list3 = new List<string>();
		int count2 = iHNode.Elements.Count;
		for (int j = 0; j < count2; j++)
		{
			string item2 = iHNode.Elements.get_Label(0, j, Type.Missing);
			list3.Add(item2);
		}
		DeckList.SetCurves(list3.ToArray());
		DeckList.Header = WpfPLDiscurvesResources.SepEff_Decks;
		if (list.Count == 1 && list3.Count == 1)
		{
			_bHasInputDialog = false;
		}
		if (!string.IsNullOrEmpty(_currentConfigValue))
		{
			DeckList.IsCheckAll = false;
			SubStreamList.IsCheckAll = false;
			RestoreConfigValue(_currentConfigValue);
		}
		_wizardPlot.SetIndependentVariable(_context, "Output/PART_DIAM");
	}

	public void UpdateWizardData()
	{
		_wizardPlot.RemoveAllDependentVariable();
		IHNode iHNode = _context.FindNode("Output/PART_DIAM");
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			return;
		}
		List<string> list = new List<string>(SubStreamList.GetSelectedCurves());
		List<string> list2;
		if (_bHasInputDialog)
		{
			list2 = new List<string>(DeckList.GetSelectedCurves());
		}
		else
		{
			list2 = DeckList.GetAllCurves()?.ToList();
		}
		if (list2 == null || list2.Count <= 0 || list.Count <= 0)
		{
			return;
		}
		_wizardPlot.RemoveAllIndependentVariable();
		string text = "Output/PART_DIAM/";
		string text2 = "Output/SEP_EFF/";
		try
		{
			int num = 0;
			for (int i = 0; i < list.Count; i++)
			{
				string indepvar = text + list[i];
				_wizardPlot.SetMultIndependentVariables(_context, indepvar);
				for (int j = 0; j < list2.Count; j++)
				{
					string depvar = text2 + list[i] + "/" + list2[j];
					_wizardPlot.AddDependentVariable(_context, depvar);
					string label = list[i] + " " + WpfPLDiscurvesResources.SepEff_Deck + " " + list2[j];
					((IHPlotVal)_wizardPlot.PlotVal).set_Label(num++, label);
				}
			}
			_help.SaveXUnitsComboText(_context.Application.Tree, (IHWizardPlot)_wizardPlot, _currentLengthUnit);
			string xUnitString = _help.GetXUnitString(_context.Application.Tree, (IHWizardPlot)_wizardPlot);
			string xAxisTitle = WpfPLDiscurvesResources.SepEff_XAxisTitle + " " + xUnitString;
			_wizardPlot.PlotVal.XAxisTitle = xAxisTitle;
		}
		catch
		{
		}
		_currentConfigValue = SaveConfigValue();
	}

	private void ExecuteOKCommand(object sender, ExecutedRoutedEventArgs e)
	{
		UpdateWizardData();
		DeckList.UpdateCurvesStatus();
		SubStreamList.UpdateCurvesStatus();
		_CancelValue = _currentConfigValue;
		_help.CloseForm((UserControl)this, (bool?)true);
	}

	private void CanExecuteOKCommand(object sender, CanExecuteRoutedEventArgs e)
	{
		int num = DeckList.GetSelectedCurves().Count();
		int num2 = SubStreamList.GetSelectedCurves().Count();
		_CancelValue = _currentConfigValue;
		e.CanExecute = num == 0 || num2 == 0 ? false : true;
	}

	private void ExecuteCancelCommand(object sender, ExecutedRoutedEventArgs e)
	{
		if (!string.IsNullOrEmpty(_currentConfigValue))
		{
			RestoreConfigValue(_currentConfigValue);
		}
		_help.CloseForm((UserControl)this, (bool?)false);
	}

	private string SaveConfigValue()
	{
		_ = string.Empty;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("SubStreamSelection=");
		List<string> list = new List<string>(SubStreamList.GetSelectedCurves());
		int count = list.Count;
		for (int i = 0; i < count; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(",");
			}
			stringBuilder.Append(list[i]);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("CheckAll=");
		stringBuilder.Append(SubStreamList.IsCheckAll);
		stringBuilder.Append(";");
		stringBuilder.Append("DeckSelection=");
		List<string> list2 = new List<string>(DeckList.GetSelectedCurves());
		count = list2.Count;
		for (int j = 0; j < count; j++)
		{
			if (j > 0)
			{
				stringBuilder.Append(",");
			}
			stringBuilder.Append(list2[j]);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("CheckAll=");
		stringBuilder.Append(DeckList.IsCheckAll);
		stringBuilder.Append(";");
		return stringBuilder.ToString();
	}

	private void RestoreConfigValue(string ConfigString)
	{
		string[] array = ConfigString.Split(';');
		int num = 0;
		string text = array[num].Substring(array[num].IndexOf('=') + 1);
		string[] array2 = text.Split(',');
		List<string> list = new List<string>();
		string[] array3 = array2;
		foreach (string item in array3)
		{
			list.Add(item);
		}
		SubStreamList.SetSelectedCurves(list.ToArray());
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		SubStreamList.IsCheckAll = Convert.ToBoolean(text);
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		string[] array4 = text.Split(',');
		List<string> list2 = new List<string>();
		array3 = array4;
		foreach (string item2 in array3)
		{
			list2.Add(item2);
		}
		DeckList.SetSelectedCurves(list2.ToArray());
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		DeckList.IsCheckAll = Convert.ToBoolean(text);
	}

	public void RollBack(object sender, CancelEventArgs e)
	{
		SubStreamList.CancelCurvesSelection();
		DeckList.CancelCurvesSelection();
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	public void InitializeComponent()
	{
		if (_contentLoaded)
		{
			return;
		}
		_contentLoaded = true;
		Uri resourceLocator = new Uri("/WpfPLScreen;component/sepeff.xaml", UriKind.Relative);
		Application.LoadComponent(this, resourceLocator);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			SubStreamList = (CurvesSelectorControl)target;
			break;
		case 2:
			DeckList = (CurvesSelectorControl)target;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}
