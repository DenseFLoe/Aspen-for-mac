#!/usr/bin/env python3
"""Rebuild the reviewed WpfPLData IL, then place fresh bodies in the original layout."""
import argparse
from collections import defaultdict
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
TOOLS = HERE / "tools"
NAME = "WpfPLData.dll"
ORIGINAL_SHA = "bf01baee83399cfdd4c3e67e965c4fced8bbb17ae83b892abcf14648a64996f7"
ILASM_SHA = "486be223bcf745332cb86a2b0bb3399e5bc89fc2c31c4b3ac6a9ea13cf82fb3f"
CECIL_SHA = "831dca77470d85cb6ffbea3072daa7a3df5b7c9fcfd9c3f43674a9be99d4bfcf"
HISTORICAL_PATCHED_SHA = "db3c3fca0ef8a530ddbf94b97858c3980c626dcbf47d81f7cf99d4470044fa36"

sys.dont_write_bytecode = True
sys.path.insert(0, str(TOOLS))
import clr_meta
import pefile


def digest(value):
    return sha256(value).hexdigest()


def file_digest(path):
    return digest(path.read_bytes())


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def verify_manifest():
    manifest_path = HERE / "SHA256SUMS.json"
    if not manifest_path.exists():
        raise ValueError("missing source archive fingerprint manifest")
    manifest = read_json(manifest_path)
    actual = {p.relative_to(HERE).as_posix(): file_digest(p) for p in HERE.rglob("*")
              if p.is_file() and p != manifest_path}
    if actual != manifest:
        changed = sorted(name for name in manifest.keys() | actual.keys()
                         if manifest.get(name) != actual.get(name))
        raise ValueError("source archive member fingerprint mismatch: " + ", ".join(changed))
    return file_digest(manifest_path)


def run(command, cwd, extra_env=None):
    env = {key: value for key, value in os.environ.items()
           if key.upper() != "PYTHONPATH"}
    env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8")
    if extra_env:
        env.update(extra_env)
    result = subprocess.run([str(arg) for arg in command], cwd=cwd, env=env,
                            capture_output=True, text=True, encoding="utf-8",
                            errors="replace", check=False)
    if result.returncode:
        raise ValueError(f"{command[0]} failed ({result.returncode})\n{result.stdout}{result.stderr}")
    return result.stdout.rstrip()


def build_operand_dump(dotnet, cecil, out):
    dotnet_root = out / "dotnet-work"
    temporary = dotnet_root / "temp"
    temporary.mkdir(parents=True)
    env = {
        "DOTNET_CLI_HOME": str(dotnet_root),
        "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
        "DOTNET_NOLOGO": "1",
        "DOTNET_SKIP_FIRST_TIME_EXPERIENCE": "1",
        "DOTNET_ADD_GLOBAL_TOOLS_TO_PATH": "0",
        "NUGET_PACKAGES": str(dotnet_root / "packages"),
        "NUGET_HTTP_CACHE_PATH": str(dotnet_root / "http-cache"),
        "NUGET_PLUGINS_CACHE_PATH": str(dotnet_root / "plugins-cache"),
        "NUGET_SCRATCH": str(dotnet_root / "scratch"),
        "NUGET_XMLDOC_MODE": "skip",
        "TEMP": str(temporary),
        "TMP": str(temporary),
    }
    stage = out / "operand-dump-src"
    shutil.copytree(TOOLS / "OperandDump", stage)
    build_dir = out / "operand-dump"
    project = stage / "OperandDump.csproj"
    cecil_reference = f"-p:CecilPath={cecil}"
    sdk = run([dotnet, "--version"], stage, env)
    runtimes = run([dotnet, "--list-runtimes"], stage, env)
    restore_log = run([dotnet, "restore", project, "--configfile", stage / "NuGet.Config",
                       cecil_reference], stage, env)
    build_log = run([dotnet, "build", project, "--no-restore", "--disable-build-servers",
                     "-c", "Release", "-o", build_dir, cecil_reference], stage, env)
    assembly = build_dir / "OperandDump.dll"
    return assembly, env, {
        "source_sha256": file_digest(stage / "OperandDump.cs"),
        "project_sha256": file_digest(project),
        "cecil_sha256": file_digest(cecil),
        "operand_dump_sha256": file_digest(assembly),
        "dotnet_sdk": sdk,
        "dotnet_runtimes": runtimes.splitlines(),
        "restore": restore_log,
        "build": build_log,
    }


def method_rows(image):
    pe, cli, root = clr_meta.read_image(image)
    rows = clr_meta.method_defs(pe, cli, root)
    for row in rows:
        row["name"] = clr_meta.strings(pe, cli, root, row["name_index"])
    return pe, rows


def managed_resources(image):
    pe, cli, root = clr_meta.read_image(image)
    tables = root["tables"]
    resources = {}
    for rid in range(1, tables["rows"].get(0x28, 0) + 1):
        offset, flag, name_idx, implementation = clr_meta.read_row(
            root["bytes"], tables, 0x28, rid).values()
        name = clr_meta.strings(pe, cli, root, name_idx)
        if implementation or offset + 4 > cli["resource_size"] or name in resources:
            raise ValueError(f"unexpected managed resource kind or extent: {name}")
        at = pe.get_offset_from_rva(cli["resource_rva"]) + offset
        size = struct.unpack_from("<I", image, at)[0]
        if offset + 4 + size > cli["resource_size"]:
            raise ValueError(f"managed resource payload leaves directory: {name}")
        resources[name] = (at, flag, image[at + 4:at + 4 + size])
    return resources


def native_resources(image):
    pe = pefile.PE(data=image, fast_load=True)
    pe.parse_data_directories(directories=[pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_RESOURCE"]])

    def read_leaves(directory, parents=()):
        for entry in directory.entries:
            key = parents + (str(entry.name) if entry.name is not None else entry.id,)
            if hasattr(entry, "directory"):
                yield from read_leaves(entry.directory, key)
            else:
                data = entry.data.struct
                payload = pe.get_data(data.OffsetToData, data.Size)
                if len(payload) != data.Size:
                    raise ValueError("unreadable Win32 resource")
                yield {"key": key, "code_page": data.CodePage, "size": data.Size,
                       "sha256": digest(payload)}

    return list(read_leaves(pe.DIRECTORY_ENTRY_RESOURCE))


def audit_operands(original_rows, assembled_rows):
    def by_position(rows):
        result = {(r["method"], r["offset"]): (r["opcode_size"], r["kind"], r["key"]) for r in rows}
        if len(result) != len(rows):
            raise ValueError("duplicate metadata operand positions")
        return result
    original = by_position(original_rows)
    assembled = by_position(assembled_rows)
    changes = [
        {"method": f"0x{method:08X}", "offset": offset,
         "original": original.get((method, offset)), "assembled": assembled.get((method, offset))}
        for method, offset in sorted(original.keys() | assembled.keys())
        if original.get((method, offset)) != assembled.get((method, offset))]
    return {"original_count": len(original), "assembled_count": len(assembled),
            "different_count": len(changes), "differences": changes}


def place_at_original_offsets(original, patched, assembled):
    orig_pe, original_rows = method_rows(original)
    patch_pe, patched_rows = method_rows(patched)
    if len(original_rows) != len(patched_rows):
        raise ValueError("MethodDef count differs")
    replacements = {}
    aliases = defaultdict(list)
    method_report = []
    for left, right in zip(original_rows, patched_rows):
        identity = ["token", "name", "body_bytes"]
        if any(left[key] != right[key] for key in identity):
            raise ValueError(f"mismatched MethodDef row {left['token']:08X}")
        if not left["rva"]:
            continue
        at = orig_pe.get_offset_from_rva(left["rva"])
        width = left["body_bytes"]
        candidate_at = patch_pe.get_offset_from_rva(right["rva"])
        fresh = patched[candidate_at:candidate_at + width]
        if fresh != original[at:at + width]:
            raise ValueError(f"body differs at token {left['token']:08X}")
        if at in replacements and replacements[at] != fresh:
            raise ValueError(f"alias has divergent code at 0x{left['rva']:X}")
        replacements[at] = fresh
        token = f"0x{left['token']:08X}"
        aliases[left["rva"]].append(token)
        method_report.append({"token": token, "original_rva": left["rva"],
                              "assembled_rva": right["rva"], "bytes": width,
                              "sha256": digest(fresh), "name": left["name"]})
    managed = []
    original_resources = managed_resources(original)
    assembled_resources = managed_resources(assembled)
    if original_resources.keys() != assembled_resources.keys():
        raise ValueError("managed resource names differ")
    for name, (at, flags, oracle) in original_resources.items():
        _, candidate_flags, payload = assembled_resources[name]
        if flags != candidate_flags or payload != oracle:
            raise ValueError(f"managed resource differs: {name}")
        replacements[at] = struct.pack("<I", len(payload)) + payload
        managed.append({"name": name, "flags": flags, "bytes": len(payload), "sha256": digest(payload)})
    # Read the complement of all CIL and embedded resource spans from the
    # original. The actual spans are made solely from this run's ILAsm files,
    # with the explicit method header/token repair performed before this step.
    blocks = []
    end = 0
    for at, payload in sorted(replacements.items()):
        if not end <= at <= len(original) - len(payload):
            raise ValueError("overlapping or invalid source-built range")
        blocks += [original[end:at], payload]
        end = at + len(payload)
    blocks.append(original[end:])
    output = b"".join(blocks)
    alias_groups = [{"rva": rva, "tokens": tokens,
                     "bytes": len(replacements[orig_pe.get_offset_from_rva(rva)])}
                    for rva, tokens in sorted(aliases.items()) if len(tokens) > 1]
    return output, {"method_def_rows": len(original_rows), "with_body": len(method_report),
                    "without_body": len(original_rows) - len(method_report),
                    "distinct_method_rvas": len(aliases), "alias_groups": alias_groups,
                    "alias_redundant_rows": sum(len(group["tokens"]) - 1 for group in alias_groups),
                    "alias_redundant_bytes": sum((len(group["tokens"]) - 1) * group["bytes"]
                                                 for group in alias_groups),
                    "source_method_bytes": sum(len(replacements[orig_pe.get_offset_from_rva(rva)])
                                               for rva in aliases),
                    "source_resource_bytes_including_lengths": sum(4 + row["bytes"] for row in managed),
                    "original_layout_and_other_bytes": len(original) - sum(map(len, replacements.values())),
                    "methods": method_report, "managed_resources": managed}


def historical_intermediate(original, patched):
    """Report the older intermediate independently of current build validity."""
    expected = HISTORICAL_PATCHED_SHA
    try:
        original_pe = pefile.PE(data=original, fast_load=True)
        candidate_pe = pefile.PE(data=patched, fast_load=True)
        osrc = next(s for s in original_pe.sections if s.Name.rstrip(b"\0") == b".rsrc")
        csrc = next(s for s in candidate_pe.sections if s.Name.rstrip(b"\0") == b".rsrc")
        compare = bytearray(patched)
        compare[csrc.PointerToRawData:csrc.PointerToRawData + csrc.SizeOfRawData] = original[
            osrc.PointerToRawData:osrc.PointerToRawData + osrc.SizeOfRawData]
        struct.pack_into("<I", compare, csrc.get_field_absolute_offset("Misc_VirtualSize"), osrc.Misc_VirtualSize)
        actual = digest(compare)
    except Exception as error:
        return {"status": "unavailable", "expected_sha256": expected, "actual_sha256": None,
                "matches": None, "reason": str(error)}
    return {"status": "computed", "expected_sha256": expected,
            "actual_sha256": actual, "matches": actual == expected}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", required=True, type=Path, help="read-only installed original WpfPLData.dll")
    parser.add_argument("--ilasm", required=True, type=Path, help="64-bit .NET Framework ILAsm executable")
    parser.add_argument("--dotnet", required=True, type=Path, help="dotnet executable with .NET 9 SDK and runtime")
    parser.add_argument("--cecil", required=True, type=Path, help="Mono.Cecil 0.11.6 netstandard2.0 DLL from NuGet")
    parser.add_argument("--out-dir", required=True, type=Path, help="new or empty directory outside the extracted archive")
    args = parser.parse_args()
    source = args.original.resolve(strict=True)
    ilasm = args.ilasm.resolve(strict=True)
    dotnet = args.dotnet.resolve(strict=True)
    cecil = args.cecil.resolve(strict=True)
    out = args.out_dir.resolve()
    if out == HERE or HERE in out.parents:
        raise ValueError("output directory must be outside the extracted archive")
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise ValueError("output directory must be new or empty")
    original = source.read_bytes()
    if digest(original) != ORIGINAL_SHA:
        raise ValueError("original SHA-256 differs from the reviewed assembly")
    if file_digest(ilasm) != ILASM_SHA:
        raise ValueError("ILAsm SHA-256 differs from the pinned compiler")
    if file_digest(cecil) != CECIL_SHA:
        raise ValueError("Cecil SHA-256 differs from the published Mono.Cecil 0.11.6 netstandard2.0 asset")
    manifest_sha = verify_manifest()
    out.mkdir(parents=True, exist_ok=True)
    operand_dump, dotnet_env, operand_build = build_operand_dump(dotnet, cecil, out)
    assembly_dir = out / "ilasm-inputs"
    assembly_dir.mkdir()
    for path in [HERE / "editable" / (NAME + ".il"), HERE / "resources" / "original.res",
                 *sorted((HERE / "resources" / "managed").iterdir())]:
        shutil.copyfile(path, assembly_dir / path.name)
    compiler_log = run([ilasm, *(HERE / "compile.rsp").read_text(encoding="utf-8").split()], assembly_dir)
    emitted = assembly_dir / "cand-asm.dll"
    normalized = out / "source-normalized.dll"
    pinned = json.loads(run([sys.executable, TOOLS / "pin_mvid.py", emitted, normalized], out))
    timings = json.loads(run([sys.executable, TOOLS / "patch_initlocals.py", source, normalized,
                              out / "source-initlocals.dll"], out))
    original_operands = out / "original-operands.json"
    candidate_operands = out / "source-operands.json"
    for image, report in [(source, original_operands), (normalized, candidate_operands)]:
        run([dotnet, "exec", operand_dump, image, report], out, dotnet_env)
    operand_audit = audit_operands(read_json(original_operands), read_json(candidate_operands))
    write_json(out / "operand-audit.json", operand_audit)
    if operand_audit["different_count"]:
        raise ValueError("source-built symbolic IL operand differs from the original")
    normalized_image = normalized.read_bytes()
    native_leaves = native_resources(original)
    if native_resources(normalized_image) != native_leaves:
        raise ValueError("source-built Win32 resource differs from the original")
    patched_path = out / "layout-token-input.dll"
    position = json.loads(run([sys.executable, TOOLS / "patch_by_position.py", source,
                               out / "source-initlocals.dll", original_operands, patched_path,
                               out / "position-report.json"], out))
    if position["body_mismatch_count"]:
        raise ValueError("post-processed CIL body differs from the original")
    patched = patched_path.read_bytes()
    output, coverage = place_at_original_offsets(original, patched, normalized_image)
    final_sha = digest(output)
    if final_sha != ORIGINAL_SHA:
        raise ValueError("final replay differs from original file fingerprint")
    (out / NAME).write_bytes(output)
    original_pe = pefile.PE(data=original, fast_load=True)
    write_json(out / "build-report.json", {
        "source_manifest_sha256": manifest_sha, "original_sha256": digest(original),
        "ilasm_sha256": file_digest(ilasm), "dotnet_sha256": file_digest(dotnet),
        "ilasm_log": compiler_log, "ilasm_emitted_sha256": file_digest(emitted),
        "source_normalized_sha256": file_digest(normalized), "normalized_fields": pinned,
        "initlocals": timings, "position_token_patch": position,
        "unpatched_token_audit_counts": {key: value for key, value in operand_audit.items()
                                         if key != "differences"},
        "patch_intermediate_sha256": digest(patched),
        "historical": historical_intermediate(original, patched), "final_sha256": final_sha,
        "operand_dump_build": operand_build,
        "final_bytes": len(output), "authenticode_table_bytes": original_pe.OPTIONAL_HEADER.DATA_DIRECTORY[4].Size,
        "coverage": coverage, "native_resource_leaves": native_leaves,
    })
    print(json.dumps({"final": NAME, "sha256": final_sha, "method_defs": coverage["method_def_rows"],
                      "with_body": coverage["with_body"], "alias_groups": len(coverage["alias_groups"]),
                      "managed_resources": len(coverage["managed_resources"]),
                      "operand_audit": "operand-audit.json", "build_report": "build-report.json"},
                     ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError) as error:
        raise SystemExit(str(error))
