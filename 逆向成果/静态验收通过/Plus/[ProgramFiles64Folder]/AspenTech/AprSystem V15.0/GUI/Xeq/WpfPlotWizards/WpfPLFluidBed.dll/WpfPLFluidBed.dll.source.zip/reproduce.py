"""Clean-room reproduction from one archived package.

Usage: py -3 reproduce.py <archive.zip> <new-empty-dir>
1. extract the archive into <new-empty-dir>
2. compile editable source with the archived relative compile.rsp (cwd = out dir)
3. replay the archived layout recipe over the compiled image
4. compare the SHA-256 with receipt.json original_sha256
Exit 0 only when the final image is byte-identical.
"""
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
TOOLS = HERE / "tools"
sys.path.insert(0, str(TOOLS))
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")

DOTNET = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\patrol-0857\review340\net9\dotnet.exe")
CSC = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\patrol-0857\review340\net9\sdk\9.0.321\Roslyn\bincore\csc.dll")


def main(archive, out):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        z.extractall(out)
    receipt = json.loads((out / "receipt.json").read_text(encoding="utf-8"))
    name = receipt["name"]
    import token_replay
    recipe = json.loads((out / "layout-recipe.json").read_text(encoding="utf-8"))
    (out / "compiled").mkdir(parents=True, exist_ok=True)
    p = subprocess.run([str(DOTNET), str(CSC), "/noconfig", "@" + "compile.rsp"],
                       cwd=str(out), capture_output=True)
    compiled = out / "compiled" / name
    if p.returncode or not compiled.is_file():
        print(p.stdout.decode("utf-8", "replace")[-3000:])
        print(p.stderr.decode("utf-8", "replace")[-2000:])
        return 1
    data = token_replay.reproduce(
        compiled.read_bytes(), recipe,
        (out / "original-build" / "clr-metadata.bin").read_bytes(),
        (out / "original-build" / "debug-record.bin").read_bytes(),
        (out / "original-build" / "certificate-table.bin").read_bytes(),
        (out / "original-build" / "strong-name.bin").read_bytes() if recipe.get("strong_name") else b"")
    sha = hashlib.sha256(data).hexdigest()
    print(json.dumps({"final_sha256": sha, "original_sha256": receipt["original_sha256"],
                      "equal": sha == receipt["original_sha256"]}, indent=1))
    return 0 if sha == receipt["original_sha256"] else 3


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
