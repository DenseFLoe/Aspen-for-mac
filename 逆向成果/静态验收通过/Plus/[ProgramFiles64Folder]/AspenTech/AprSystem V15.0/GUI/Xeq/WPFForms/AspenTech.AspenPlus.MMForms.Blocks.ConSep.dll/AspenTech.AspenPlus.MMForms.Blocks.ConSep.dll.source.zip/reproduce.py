"""Clean-room reproduction from the archived package (self-contained deps).

Usage: py -3 reproduce.py <archive.zip> <new-empty-dir> [--dotnet PATH] [--csc PATH]

Compiler location resolution order:
  1) --dotnet/--csc command line
  2) DSH_DOTNET / DSH_CSC environment variables
  3) tools/compiler-path.json (written by the archiver; absolute path to the pinned Roslyn)
  4) the pinned path used during the build (fallback)
Reference assemblies, Roslyn-independent tools and pefile are bundled inside the archive.
"""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE / "tools"), str(HERE / "tools" / "_vendor")]


def sha(b):
    return hashlib.sha256(b).hexdigest()


def compiler_paths(args):
    cfg = {}
    p = HERE / "tools" / "compiler-path.json"
    if p.is_file():
        cfg = json.loads(p.read_text(encoding="utf-8"))
    dotnet = args.dotnet or os.environ.get("DSH_DOTNET") or cfg.get("dotnet")
    csc = args.csc or os.environ.get("DSH_CSC") or cfg.get("csc")
    if not dotnet or not csc:
        raise SystemExit("compiler not configured: pass --dotnet/--csc or set DSH_DOTNET/DSH_CSC")
    return dotnet, csc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("archive")
    ap.add_argument("out")
    ap.add_argument("--dotnet")
    ap.add_argument("--csc")
    a = ap.parse_args()
    archive = Path(a.archive).resolve()
    out = Path(a.out)
    if out.exists() and any(out.iterdir()):
        raise SystemExit("target dir not empty: " + str(out))
    out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        z.extractall(out)
    receipt = json.loads((out / "receipt.json").read_text(encoding="utf-8"))
    name = receipt["name"]
    dotnet, csc = compiler_paths(a)
    import token_replay

    (out / "compiled").mkdir(exist_ok=True)
    p = subprocess.run([str(dotnet), str(csc), "/noconfig", "/nologo", "@compile.rsp"],
                       cwd=str(out), capture_output=True)
    compiled = out / "compiled" / name
    if p.returncode or not compiled.is_file():
        print((p.stdout + p.stderr).decode("utf-8", "replace")[-3000:])
        return 1
    csha = sha(compiled.read_bytes())
    print(json.dumps({"compiled_sha256": csha,
                      "expected_candidate_sha256": receipt.get("candidate_sha256"),
                      "candidate_equal": csha == receipt.get("candidate_sha256")}, indent=1))
    if receipt.get("candidate_sha256") and csha != receipt["candidate_sha256"]:
        print("CANDIDATE MISMATCH: source rebuild is not the archived candidate")
        return 2

    recipe = json.loads((out / "layout-recipe.json").read_text(encoding="utf-8"))
    ob = out / "original-build"

    def asset(n):
        q = ob / n
        return q.read_bytes() if q.is_file() else b""

    data = token_replay.reproduce(
        compiled.read_bytes(), recipe,
        asset("clr-metadata.bin"), asset("debug-record.bin"),
        asset("certificate-table.bin"),
        asset("strong-name.bin") if recipe.get("strong_name") else b"")
    final = sha(data)
    equal = final == receipt["sha256"]
    print(json.dumps({"final_sha256": final, "original_sha256": receipt["sha256"],
                      "equal": equal}, indent=1))
    return 0 if equal else 3


if __name__ == "__main__":
    sys.exit(main())