"""Extract one method's IL body text from an ilspycmd -il listing and diff two listings.

Usage: ildiff.py <orig.il> <cand.il> <method-substring> [index]
Instruction addresses are normalized away so shifts do not drown the diff.
"""
import difflib
import re
import sys
from pathlib import Path


def extract(path, needle, occurrence=0):
    lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    starts = [i for i, line in enumerate(lines) if needle in line and "end of method" not in line]
    if len(starts) <= occurrence:
        raise SystemExit("method %r #%d not found in %s" % (needle, occurrence, path))
    at = starts[occurrence]
    out = []
    depth = 0
    for line in lines[at:]:
        out.append(line)
        depth += line.count("{") - line.count("}")
        if "end of method" in line:
            break
    return out


def norm(lines):
    result = []
    for line in lines:
        s = line.strip()
        s = re.sub(r"^IL_[0-9a-f]+:\s*", "", s)
        result.append(s)
    return result


def main():
    a = norm(extract(sys.argv[1], sys.argv[3], int(sys.argv[4]) if len(sys.argv) > 4 else 0))
    b = norm(extract(sys.argv[2], sys.argv[3], int(sys.argv[4]) if len(sys.argv) > 4 else 0))
    diff = list(difflib.unified_diff(a, b, "orig", "cand", lineterm="", n=4))
    print("\n".join(diff) if diff else "IDENTICAL")


if __name__ == "__main__":
    main()
