# -*- coding: utf-8 -*-
"""Build a managed layout recipe for d70c1acd using the IL-spliced candidate.

Reads the original from m-aprsys-1/items.json and the candidate at
work/mixed4.dll (ilasm 4.0.30319 output of cand.ildasm.il with OnViewChanged's
body replaced by the original IL body).  Writes recipe.json / recipe-report.json
and assets/ into this directory.
"""
import json
import sys
from hashlib import sha256
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
W = BASE / "router" / "work" / "m-close-2byte" / "d70c1acd"
TOOLS = BASE / "router" / "work" / "managed-srcfix-1" / "tools"
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")
sys.path.insert(0, str(BASE / "router" / "managed"))
sys.path.insert(0, str(BASE / "managed-byte-recovery"))
sys.path.insert(0, str(TOOLS))
import clr_meta
import make_recipe_layout as make_recipe
import pe_layout  # noqa: F401 (imported by generated recipe assets checks)
from tokens import Image, body_diff_map

ITEMS = {i["sha8"]: i
         for i in json.loads((BASE / "router" / "work" / "m-aprsys-1" / "items.json")
                             .read_text(encoding="utf-8"))}


def main(sha8, cand_path=None):
    it = ITEMS[sha8]
    orig = Path(it["original"]).read_bytes()
    cand = Path(cand_path).read_bytes() if cand_path else (W / "work" / "mixed.dll").read_bytes()
    recipe, assets, report = make_recipe.generate(orig, cand, it["name"])
    pe_o_sec, _ = pe_layout.identified_image(orig)
    for name, section in recipe["sections"].items():
        section["virtual_address"] = pe_layout.names(pe_o_sec)[name].VirtualAddress
    oi, ci = Image(orig, "orig"), Image(cand, "cand")
    pe_o, cli_o, root_o = clr_meta.read_image(orig)
    pe_c, cli_c, root_c = clr_meta.read_image(cand)
    rows_o = clr_meta.method_defs(pe_o, cli_o, root_o)
    rows_c = clr_meta.method_defs(pe_c, cli_c, root_c)
    by_o = {x["token"]: x for x in rows_o}
    by_c = {x["token"]: x for x in rows_c}
    admitted = 0
    remaining = []
    for gap in report["gaps"]:
        if gap["kind"] != "source_form_gap":
            remaining.append(gap)
            continue
        token = int(gap["token"], 16)
        a, b = by_o[token], by_c[token]
        body_o = pe_o.get_data(a["rva"], a["body_bytes"])
        body_c = pe_c.get_data(b["rva"], b["body_bytes"])
        if len(body_o) != len(body_c):
            remaining.append(gap)
            continue
        remaps, leftover = body_diff_map(oi, ci, body_o, body_c)
        if leftover or not remaps:
            gap = dict(gap, leftover=leftover[:8])
            remaining.append(gap)
            continue
        pair = {"original_token": "0x%08X" % token, "candidate_token": "0x%08X" % b["token"],
                "original_rva": a["rva"], "candidate_rva": b["rva"], "bytes": len(body_o),
                "body_sha256": sha256(body_o).hexdigest(), "remapped_tokens": remaps}
        if pe_layout.reemit_method(body_c, pair) != body_o:
            gap = dict(gap, reason="remap did not reproduce original body")
            remaining.append(gap)
            continue
        recipe["verified_methods"].append(pair)
        admitted += 1
    recipe["methods_matched"] = len(recipe["verified_methods"])
    recipe["methods_total"] = len(recipe["verified_methods"]) + len(remaining)
    recipe["replay_status"] = "ready" if not remaining else "blocked"
    suffix = "" if not cand_path else "-alt"
    (W / ("recipe%s.json" % suffix)).write_text(json.dumps(recipe, ensure_ascii=False, indent=1), encoding="utf-8")
    rep = {"name": it["name"], "original_sha256": it["sha256"],
           "compiler_output_sha256": recipe["compiler_output_sha256"],
           "methods_total": recipe["methods_total"], "methods_matched": recipe["methods_matched"],
           "remap_admitted": admitted, "gaps": remaining,
           "gap_kinds": sorted({g["kind"] for g in remaining})}
    (W / ("recipe-report%s.json" % suffix)).write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    adir = W / "assets"
    adir.mkdir(exist_ok=True)
    for k, v in assets.items():
        (adir / k.replace("/", "__")).write_bytes(v)
    print(json.dumps({"status": recipe["replay_status"], "matched": recipe["methods_matched"],
                      "total": recipe["methods_total"], "remap": admitted,
                      "gaps": rep["gap_kinds"], "remaining": len(remaining)}, ensure_ascii=False))
    for g in remaining[:25]:
        print(json.dumps(g, ensure_ascii=False))
    return 0 if not remaining else 1


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:3]))
