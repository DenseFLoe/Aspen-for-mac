using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using Interop.SECSERVEROBJECTLib;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("2023.15.0.1")]
[assembly: AssemblyTitle("AspenTech.HtmlHelp.Logging")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, INC.")]
[assembly: AssemblyProduct("AspenTech.HtmlHelp.Logging")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2022")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("edb14b08-3271-46a1-b0c0-13f7669a6f02")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("2023.15.0.1")]
namespace AspenTech.HtmlHelp.Logging
{
	public class CHtmlHelpLogging
	{
		private string licKeyString = "SLM_TR_ALL_ProdHelp";

		private string licKeyVer = string.Empty;

		private int licCookie;

		private string licKeyLgString = "SLM_TR_ALL_TRANSLATE";

		private string licKeyLgVer = string.Empty;

		private int licLgCookie;

		private SecServer licSecSrv;

		public void PauseLogging()
		{
			if (licSecSrv != null)
			{
				if (licLgCookie != 0)
				{
					licSecSrv.ReleaseLicense(licLgCookie);
				}
				licLgCookie = 0;
				if (licCookie != 0)
				{
					licSecSrv.ReleaseLicense(licCookie);
				}
				licCookie = 0;
			}
		}

		public string GetLCIDForLog(string strLanguage)
		{
			string empty = string.Empty;
			switch (strLanguage)
			{
			case "fr":
				empty = "fr-FR";
				break;
			case "it":
				empty = "it-IT";
				break;
			case "de":
				empty = "de-DE";
				break;
			case "es":
				empty = "es-ES";
				break;
			case "ja":
				empty = "ja-JP";
				break;
			case "zh-CHS":
			case "zh-CHT":
				empty = "zh-HANS";
				break;
			case "ko":
				empty = "ko-KR";
				break;
			case "ru":
				empty = "ru-RU";
				break;
			case "pt":
				empty = "pt-BR";
				break;
			default:
				empty = "en-US";
				break;
			}
			return empty;
		}

		public void HelpDisplayLangHandle(string strHelpDisplayLang)
		{
			try
			{
				ISLMUsageLog2 iSLMUsageLog = licSecSrv as ISLMUsageLog2;
				if (iSLMUsageLog == null)
				{
					return;
				}
				string lCIDForLog = GetLCIDForLog(strHelpDisplayLang);
				iSLMUsageLog.SetLanguage(lCIDForLog);
				licSecSrv.CheckoutLicenseDeferred(licKeyLgString, licKeyLgVer, out licLgCookie, null, LicenseImportance_enum.liNotCritical);
			}
			catch (Exception)
			{
			}
		}

		public void StopLogging()
		{
			licSecSrv = null;
		}

		public bool InitLogging()
		{
			if (licSecSrv == null)
			{
				licSecSrv = (SecServer)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("1460FDB4-752B-11D4-B067-0090271CF383")));
			}
			if (licSecSrv == null)
			{
				return false;
			}
			licSecSrv.CheckoutLicenseDeferred(licKeyString, licKeyVer, out licCookie, null, LicenseImportance_enum.liNotCritical);
			return true;
		}
	}
}
namespace Interop.SECSERVEROBJECTLib
{
	[ComImport]
	[CompilerGenerated]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("F7FE9DD9-33C2-4C84-9BDA-C084DC25E1D3")]
	[TypeIdentifier]
	public interface ISLMUsageLog2
	{
		[MethodImpl(MethodCodeType = MethodCodeType.Runtime)]
		void _VtblGap1_3();

		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		void SetLanguage([In][MarshalAs(UnmanagedType.BStr)] string langName);
	}
	[ComImport]
	[CompilerGenerated]
	[Guid("1460FDB6-752B-11D4-B067-0090271CF383")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface ISecCallback
	{
	}
	[ComImport]
	[CompilerGenerated]
	[Guid("A61D34E7-943C-4B91-A7CB-EFEC599ED919")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface ISecServer : ISecServer4
	{
		[MethodImpl(MethodCodeType = MethodCodeType.Runtime)]
		void _VtblGap1_1();

		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		void CheckoutLicenseDeferred([In][MarshalAs(UnmanagedType.BStr)] string license, [In][MarshalAs(UnmanagedType.BStr)] string licversion, out int cookie, [Optional][In][MarshalAs(UnmanagedType.Interface)] ISecCallback lostLicenseCallback, [Optional][In] LicenseImportance_enum importance);

		[MethodImpl(MethodCodeType = MethodCodeType.Runtime)]
		void _VtblGap2_1();

		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		void ReleaseLicense([In] int cookie);
	}
	[ComImport]
	[CompilerGenerated]
	[Guid("69C4BC11-E968-4190-A674-F1E0928C63F0")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface ISecServer2 : _ISecServer
	{
	}
	[ComImport]
	[CompilerGenerated]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("A09377DA-340B-4BBC-8DF5-F8A100055DD9")]
	[TypeIdentifier]
	public interface ISecServer3 : ISecServer2
	{
	}
	[ComImport]
	[CompilerGenerated]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("AE942D5A-12E1-42F9-AA95-B77631A4F6DE")]
	[TypeIdentifier]
	public interface ISecServer4 : ISecServer3
	{
	}
	[CompilerGenerated]
	[TypeIdentifier("1460FDB3-752B-11D4-B067-0090271CF383", "Interop.SECSERVEROBJECTLib.LicenseImportance_enum")]
	public enum LicenseImportance_enum
	{
		liNotCritical,
		liCritical
	}
	[ComImport]
	[CompilerGenerated]
	[CoClass(typeof(object))]
	[Guid("A61D34E7-943C-4B91-A7CB-EFEC599ED919")]
	[TypeIdentifier]
	public interface SecServer : ISecServer
	{
	}
	[ComImport]
	[CompilerGenerated]
	[Guid("1460FDB5-752B-11D4-B067-0090271CF383")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface _ISecServer
	{
	}
}
