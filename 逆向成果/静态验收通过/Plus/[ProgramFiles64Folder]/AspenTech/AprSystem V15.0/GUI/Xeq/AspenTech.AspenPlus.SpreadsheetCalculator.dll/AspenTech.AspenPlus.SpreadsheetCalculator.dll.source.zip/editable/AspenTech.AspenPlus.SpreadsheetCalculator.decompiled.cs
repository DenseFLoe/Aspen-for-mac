using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Xml;
using DevExpress.Spreadsheet;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.68")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.SpreadsheetCalculator")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.SpreadsheetCalculator")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2024, All Rights Reserved")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("bace9cff-30cf-4701-a480-1fdf3a63732c")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.68")]
namespace AspenTech.AspenPlus.SpreadsheetCalculator;

[ComVisible(true)]
[Guid("FB6E726A-7F01-4927-B8E9-FCB978EF83E4")]
[InterfaceType(ComInterfaceType.InterfaceIsDual)]
public interface ISpreadSheetCalculator
{
	[DispId(1)]
	void AddSpreadsheet(int handle, object sheet);

	[DispId(2)]
	void DeleteSpreadsheet(int handle);

	[DispId(3)]
	void DoSpreadsheetCalculate(int handle, string[] readVariables, object[] readVariableValues, string[] writeVariables, ref object[] writeVariableValues);

	[DispId(4)]
	object GetSpreadsheet(ref int handle);

	[DispId(5)]
	string XMLStringForSave();

	[DispId(6)]
	void RestoreSpreadsheetFromXml(string xmlStr);

	[DispId(7)]
	int DuplicateSpreadsheet(int handle);

	[DispId(8)]
	int ConvertToSpreadsheet(string calculatorName, int handle, string excelFile);
}
[ComVisible(true)]
[Guid("56E148CC-7D3A-46A9-B005-7DD1BA40A777")]
[ProgId("AspenTech.AspenPlus.SpreadsheetCalculator.410")]
[ClassInterface(ClassInterfaceType.AutoDual)]
public class SpreadSheetCalculator : ISpreadSheetCalculator
{
	private static Dictionary<int, Workbook> _spreadsheets = new Dictionary<int, Workbook>();

	public void DoSpreadsheetCalculate(int handle, string[] readVariables, object[] readVariableValues, string[] writeVariables, ref object[] writeVariableValues)
	{
		if (_spreadsheets.ContainsKey(handle))
		{
			Workbook workbook = _spreadsheets[handle];
			SetReadVariableValues(workbook, readVariables, readVariableValues);
			workbook.Calculate();
			GetWriteVariableValues(workbook, writeVariables, ref writeVariableValues);
		}
	}

	public void AddSpreadsheet(int handle, object sheet)
	{
		if (handle > 0 && sheet is Workbook value)
		{
			if (_spreadsheets.ContainsKey(handle))
			{
				_spreadsheets[handle].Dispose();
			}
			_spreadsheets[handle] = value;
		}
	}

	public void DeleteSpreadsheet(int handle)
	{
		if (_spreadsheets.ContainsKey(handle))
		{
			_spreadsheets[handle].Dispose();
			_spreadsheets.Remove(handle);
		}
	}

	public object GetSpreadsheet(ref int handle)
	{
		if (handle > 0 && _spreadsheets.ContainsKey(handle))
		{
			return _spreadsheets[handle];
		}
		int num = 1;
		if (_spreadsheets.Count > 0)
		{
			num = _spreadsheets.Max((KeyValuePair<int, Workbook> kvp) => kvp.Key) + 1;
		}
		Workbook workbook = new Workbook();
		AddSpreadsheet(num, workbook);
		handle = num;
		return workbook;
	}

	public string XMLStringForSave()
	{
		if (_spreadsheets.Count == 0)
		{
			return null;
		}
		XmlDocument xmlDocument = new XmlDocument();
		XmlElement xmlElement = xmlDocument.CreateElement("Spreadsheets");
		foreach (KeyValuePair<int, Workbook> spreadsheet in _spreadsheets)
		{
			XmlElement xmlElement2 = xmlDocument.CreateElement("Spreadsheet");
			xmlElement2.SetAttribute("SHEET", spreadsheet.Key.ToString(CultureInfo.InvariantCulture));
			xmlElement2.InnerText = SpreadsheetToString(spreadsheet.Value);
			xmlElement.AppendChild(xmlElement2);
		}
		xmlDocument.AppendChild(xmlElement);
		return xmlDocument.InnerXml;
	}

	public void RestoreSpreadsheetFromXml(string fileName)
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.Load(fileName);
			XmlNodeList xmlNodeList = xmlDocument.SelectNodes("Spreadsheets");
			if (xmlNodeList != null && xmlNodeList.Count > 0)
			{
				_spreadsheets.Clear();
				foreach (XmlNode childNode in xmlNodeList[0].ChildNodes)
				{
					if (int.TryParse(childNode.Attributes["SHEET"].Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
					{
						byte[] buffer = Convert.FromBase64String(childNode.InnerText);
						Workbook workbook = new Workbook();
						workbook.LoadDocument(buffer);
						AddSpreadsheet(result, workbook);
					}
				}
			}
		}
		catch (Exception)
		{
		}
	}

	public int DuplicateSpreadsheet(int handle)
	{
		try
		{
			if (handle > 0 && _spreadsheets.ContainsKey(handle))
			{
				Workbook workbook = _spreadsheets[handle];
				MemoryStream stream = new MemoryStream();
				workbook.SaveDocument(stream, DocumentFormat.Xlsx);
				Workbook workbook2 = new Workbook();
				workbook2.LoadDocument(stream);
				int num = _spreadsheets.Max((KeyValuePair<int, Workbook> kvp) => kvp.Key) + 1;
				AddSpreadsheet(num, workbook2);
				return num;
			}
		}
		catch (Exception)
		{
		}
		return 0;
	}

	public int ConvertToSpreadsheet(string calculatorName, int handle, string excelFile)
	{
		try
		{
			Workbook workbook = new Workbook();
			if (workbook.LoadDocument(excelFile))
			{
				int handle2 = 0;
				GetSpreadsheet(ref handle2);
				AddSpreadsheet(handle2, workbook);
				return handle2;
			}
		}
		catch (Exception)
		{
		}
		return 0;
	}

	public static void DeleteAllSpreadsheets()
	{
		foreach (int item in _spreadsheets.Keys.ToList())
		{
			_spreadsheets[item].Dispose();
			_spreadsheets.Remove(item);
		}
	}

	private void SetReadVariableValues(Workbook wb, string[] readVariables, object[] readVariableValues)
	{
		if (wb == null || readVariables == null || readVariableValues == null)
		{
			return;
		}
		for (int i = 0; i < readVariables.Length; i++)
		{
			if (wb.DefinedNames.Contains(readVariables[i]))
			{
				DefinedName definedName = wb.DefinedNames.GetDefinedName(readVariables[i]);
				if (definedName == null || readVariableValues.Length <= i)
				{
					continue;
				}
				int cellValue = 0;
				Cell cell = definedName.Range[0];
				if (readVariableValues[i] is double[] array)
				{
					int rowIndex = cell.RowIndex;
					int columnIndex = cell.ColumnIndex;
					for (int j = 0; j < array.Length; j++)
					{
						Cell cell2 = cell.Worksheet.Cells[rowIndex + j, columnIndex];
						if (cell2 != null)
						{
							cell2.Value = array[j];
						}
					}
					cellValue = array.Length;
				}
				else if (readVariableValues[i] is double num)
				{
					cell.Value = num;
					cellValue = 1;
				}
				SetLVectorVariableValue(wb, readVariables[i], cellValue);
			}
			else if (wb.DefinedNames.Contains("L" + readVariables[i]) && !readVariables.Contains("L" + readVariables[i]))
			{
				int cellValue2 = 0;
				if (readVariableValues[i] is double[] array2)
				{
					cellValue2 = array2.Length;
				}
				else if (readVariableValues[i] is double)
				{
					cellValue2 = 1;
				}
				SetLVectorVariableValue(wb, readVariables[i], cellValue2);
			}
		}
	}

	private void GetWriteVariableValues(Workbook wb, string[] writeVariables, ref object[] writeVariableValues)
	{
		if (wb == null || writeVariables == null || writeVariableValues == null)
		{
			return;
		}
		for (int i = 0; i < writeVariables.Length; i++)
		{
			if (wb.DefinedNames.Contains(writeVariables[i]))
			{
				DefinedName definedName = wb.DefinedNames.GetDefinedName(writeVariables[i]);
				if (definedName.Range == null || !(definedName.Range[0].Value != null) || writeVariableValues.Length <= i)
				{
					continue;
				}
				Cell cell = definedName.Range[0];
				int cellValue = 0;
				if (writeVariableValues[i] is double[] array)
				{
					int rowIndex = cell.RowIndex;
					int columnIndex = cell.ColumnIndex;
					for (int j = 0; j < array.Length; j++)
					{
						Cell cell2 = cell.Worksheet.Cells[rowIndex + j, columnIndex];
						if (cell2 != null && cell2.Value != null && double.TryParse(cell2.Value.ToString(), out var result))
						{
							array[j] = result;
						}
					}
					cellValue = array.Length;
				}
				else if (double.TryParse(cell.Value.ToString(), out var result2))
				{
					writeVariableValues[i] = result2;
					cellValue = 1;
				}
				SetLVectorVariableValue(wb, writeVariables[i], cellValue);
			}
			else if (wb.DefinedNames.Contains("L" + writeVariables[i]) && !writeVariables.Contains("L" + writeVariables[i]))
			{
				int cellValue2 = 0;
				if (writeVariableValues[i] is double[] array2)
				{
					cellValue2 = array2.Length;
				}
				else if (writeVariableValues[i] is double)
				{
					cellValue2 = 1;
				}
				SetLVectorVariableValue(wb, writeVariables[i], cellValue2);
			}
		}
	}

	private string SpreadsheetToString(Workbook wb)
	{
		return Convert.ToBase64String(wb.SaveDocument(DocumentFormat.Xlsx));
	}

	private void SetLVectorVariableValue(Workbook wb, string vectorVariable, int cellValue)
	{
		string name = "L" + vectorVariable;
		DefinedName definedName = wb.DefinedNames.GetDefinedName(name);
		if (definedName != null && definedName.Range != null && definedName.Range.Any())
		{
			definedName.Range[0].Value = cellValue;
		}
	}
}
