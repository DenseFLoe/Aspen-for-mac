# DevExpress.TreeMap.v23.2.Core.dll

本包是 Aspen Plus V15.0 随装 DevExpress TreeMap 23.2.4.0 的可编辑 C# 交付。制作侧已从空输出目录直接回编并完成原件静态比较，独立复核由任务负责人另行登记。固定主干将本对象列为「待静态验收」。[固定主干中的对象目录](https://github.com/DenseFLoe/Aspen-for-mac/tree/adbe73b517acac25da87598cce46de033f630ccb/%E9%80%86%E5%90%91%E6%88%90%E6%9E%9C/%E5%BE%85%E9%9D%99%E6%80%81%E9%AA%8C%E6%94%B6/Plus/%5BProgramFiles64Folder%5D/AspenTech/AprSystem%20V15.0/GUI/Xeq/DevExpress.TreeMap.v23.2.Core.dll) · [固定主干验收标准](https://github.com/DenseFLoe/Aspen-for-mac/blob/adbe73b517acac25da87598cce46de033f630ccb/docs/static-acceptance.md)

## 原件与源码来源

| 项目 | 实测 |
| --- | --- |
| 安装路径 | C:\Program Files\AspenTech\AprSystem V15.0\GUI\Xeq\DevExpress.TreeMap.v23.2.Core.dll |
| 原相对路径 | [ProgramFiles64Folder]/AspenTech/AprSystem V15.0/GUI/Xeq/DevExpress.TreeMap.v23.2.Core.dll |
| 文件和程序集版本 | 23.2.4.0 |
| 原件长度、SHA-256 | 41,576 B · 6b2379f21a1c6f408893b9a94e52ca44fa2546024fc35c6cb6e6d56a8dea46c5 |
| 程序集公开身份 | DevExpress.TreeMap.v23.2.Core, Version=23.2.4.0, Culture=neutral, PublicKeyToken=b88d1754d700e49a |
| 复用输入 | 夜班 DevExpress.TreeMap.v23.2.Core.dll.v2.zip，SHA-256 8d7e627d358d808c6354716776dd60cbdb248ae8e0e0fa86643c57f29fa9f970 |
| 直接回编产物 | 31,232 B · 77087b847b6964e530136ca1b47090dadc7bb509f9f93790a933ba68eae08ccf |

复用夜班包的可编辑 C#、Win32 版本资源和程序集公钥。源码只按原全名更名，内容字节保持一致。版本资源是可直接送给 Roslyn 的 1,140 B Win32 RES 输入，包内 160 B SNK 只保存原件 Assembly 元数据中的公钥。新回编使用 Roslyn 的 public-sign 模式保留程序集身份与 CLR 标志。入口直接调用编译器并交付其 DLL，编译结束后只读取 DLL 做比较。

## 静态覆盖

- MethodDef 边界按实际原件核对。历史任务卡的「185 个方法体」对应 185 个方法定义，其中 146 个含 CIL 方法体、39 个是原本无体的抽象或接口方法。146 个方法的 7,908 B 指令、16 个异常区、局部签名、最大栈和初始化标志一致。签名、实现标志和声明逐项一致。
- 原件与候选的整个 CLR 元数据映像在分别归一化 MethodDef RVA 和唯一 MVID 后一致。两侧的 CIL 原始操作数及其令牌引用到相同的元数据内容，因此分支、调用、字符串、类型及成员绑定一起核对。覆盖原件 45 条 TypeDef（含模块伪类型）、59 条 FieldDef、40 条 Property、0 条 Event、4 条 AssemblyRef、0 条 ManifestResource 和 0 条 FieldRVA。
- Win32 资源按带类型的层级 ID 列出并比较全部叶项的长度、代码页和数据 SHA-256。唯一版本资源 RT_VERSION 16/1/0，代码页 0，1,074 B，SHA-256 为 54fb76efd5949b46d326811842ee1901ef7dca7f0058babb2b8c57e21fc4b079，RVA 也相同。
- PE32/I386、AnyCPU CLR 语义、主机 ABI 头和唯一原生导入 mscoree.dll!_CorDllMain 一致。x86 DLL 入口均经 FF 25 间接跳转该导入，HIGHLOW 重定位均位于入口后两个字节。
- 每个方法的令牌、签名与匹配结果详见 evidence/comparison.json。附带的 CLR 和资源工具源码复制自现有项目工具。入口在临时目录用 .NET 6 可用的 ComputeHash(Stream) 和等价的完整读取循环适配共享 CLR 工具的 .NET 7 Stream API。资源对照及 PE 报告使用 pefile 2024.8.26。可用新输出目录重跑工具核验 JSON。

## 构建和比较

环境使用 Windows、Python 3.12、Roslyn 3.11.0-4.21403.6 (ae1fff34) 的 csc.exe 和其同目录运行组件，以及 .NET Framework 4.5.2 的 mscorlib.dll、System.dll、System.Core.dll 引用程序集。应用依赖 DevExpress.Data.v23.2.dll 版本 23.2.4.0、公钥令牌 b88d1754d700e49a、SHA-256 9f7d7c47cc11685e59b76b18a75a5da0ada9bcd8bc2e4a5bc105f5eded1b6493。build-plan.json 列出并校验编译器、侧文件、外部引用和公钥。编译仅需这四个引用，使用 C# 7.3、优化、deterministic、debug:full、AnyCPU 与显式路径映射。

以下命令从项目根执行。work 指向本次任务根，输入 ZIP 解到全新目录。若已准备独立提取目录，给 pkg 和 out 传入该目录及全新输出路径即可。

~~~powershell
$work = '.local/codex-router/work/6b2379f21a1c6f408893b9a94e52ca44fa2546024fc35c6cb6e6d56a8dea46c5/20261128-b02'
$archive = "$work/producer/DevExpress.TreeMap.v23.2.Core.dll.source-v3.zip"
$pkg = "$work/repro-package"
$out = "$work/repro-output"
$csc = '.local/n-8c559fd3-tools/roslyn-3.11.0/tools/csc.exe'
$refs = '.local/batch-roundtrip-20261125/tooling/csharp-reference-packs/references/framework-4.5.2'
$xeq = 'C:/Program Files/AspenTech/AprSystem V15.0/GUI/Xeq'
$original = "$xeq/DevExpress.TreeMap.v23.2.Core.dll"
$pefileDir = '.local/patrol-1329/review337/deps'

Expand-Archive -LiteralPath $archive -DestinationPath $pkg
Get-FileHash -LiteralPath $original -Algorithm SHA256
python -B "$pkg/reproduce.py" --csc $csc --framework-refs $refs --devexpress-data "$xeq/DevExpress.Data.v23.2.dll" --out $out --original $original --pefile-dir $pefileDir
~~~

只回编可去掉 --original 和 --pefile-dir。比对环节要求 Windows PowerShell Core（实测 pwsh 7.2.2）、pefile 2024.8.26 与指纹表中的现役原件。如果 Python 已安装该版本 pefile，可省略 --pefile-dir。构建无需安装 .NET SDK 或原件 DLL，仅使用 Roslyn、引用程序集、源码和包内资源、公钥。产物及中间材料生成在 out，其中 build.json 记录本次输入、命令与产物指纹，comparison.json 记录原件比较，compile.rsp 记录传给编译器的参数。执行成功预期返回 0，候选 SHA-256 与表中回编指纹一致，comparison.json 的 status 为 pass。

## 构建差异及待验证范围

原件有 10,344 B Authenticode 证书表与 128 B 非零强名签名区。回编产物的强名槽为 128 B 全零，保留公钥和 CLI 标志，无 Authenticode 表。候选不能用于要求原厂有效强名或 Authenticode 签名的部署。构建差异还包括 MVID、PE 时间戳、PDB 路径及调试目录记录、入口和重定位的 RVA、.text 虚拟长度，详见证据中的两侧 PE 记录。已核对的入口 ABI 与 CIL 实现一致。Windows 运行、私钥签名验证、宿主装载和交互行为留待项目对应的重建对照阶段。
