# HeatExchangeConverter.cs

Source: editable/HeatExchanger/HeatExchangeConverter.cs

Source SHA-256: fc00208802befbeabd64b4a2c47a62d4398d115bbcd8942ce523dfcf8d7a1244
