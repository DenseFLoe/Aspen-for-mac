using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLMCompr;

[RibbonPlotWizardMgr("WpfPLMCOMPR.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class MComprPlotWizardModule : PlotModuleBase
{
}
