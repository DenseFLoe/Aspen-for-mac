using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using AspenTech.InContextGuidance.ExchangeIntegration.Images;
using AspenTech.InContextGuidance.Localization;
using ExchangeAgent;
using Microsoft.Win32;
using WebSearchObjects;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology 2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("15.0.0.0")]
[assembly: AssemblyTitle("AspenTech.InContextGuidance.ExchangeIntegration")]
[assembly: AssemblyDescription("InContextGuidance library for communicating with exchange agent.")]
[assembly: AssemblyProduct("AspenTech.InContextGuidance.ExchangeIntegration")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("15.0.0.0")]
namespace AspenTech.InContextGuidance.ExchangeIntegration
{
	public enum ProductName
	{
		Hysys,
		AspenPlus,
		EDR,
		Fidelis,
		DMC3,
		ACCE,
		AIMB,
		eLauncher,
		UNKNOWN,
		OptiPlant,
		AES_eLearning,
		MSC_eLearning,
		SSE_eLearning,
		ABE
	}
	public enum ProductVersion
	{
		AES12 = 38,
		AES12_1 = 39,
		AES12_2 = 39,
		AES14 = 40,
		AES14_5 = 41,
		AES15 = 42,
		MSC12 = 20,
		MSC12_1 = 21,
		MSC12_2 = 21,
		MSC14 = 22,
		MSC15 = 24,
		HOSTED = 23,
		AES_HOSTED = 23,
		MSC_HOSTED = 25,
		SSE_HOSTED = 26,
		UNKNOWN = 0
	}
	public sealed class ExchangeAdapter : INotifyPropertyChanged
	{
		private static ExchangeAdapter _default;

		private ProductName _productName;

		private ProductVersion _productVersion;

		private Action<ExchangeErrorInfo> _errorHandler;

		private bool _successfullyInitialized;

		private bool? _useELearningContent;

		private string _selectedLanguage;

		public static ExchangeAdapter Default => _default ?? (_default = new ExchangeAdapter());

		public bool SuccessfullyInitialized
		{
			get
			{
				return _successfullyInitialized;
			}
			private set
			{
				if (_successfullyInitialized != value)
				{
					_successfullyInitialized = value;
					OnPropertyChanged("SuccessfullyInitialized");
				}
			}
		}

		private WebSearchObjects.ProductName ExchangeProductName => ConvertEnum<ProductName, WebSearchObjects.ProductName>(_productName);

		private WebSearchObjects.ProductVersion ExchangeProductVersion => ConvertEnum<ProductVersion, WebSearchObjects.ProductVersion>(_productVersion);

		public event PropertyChangedEventHandler PropertyChanged;

		private ExchangeAdapter()
		{
		}

		public void Initialize(ProductName productName, ProductVersion productVersion, Action<ExchangeErrorInfo> errorHandler, int tryingTimes = 10)
		{
			_productName = productName;
			_productVersion = productVersion;
			_errorHandler = errorHandler;
			if (!IsIcgConfiguredDisabled())
			{
				InitializeExchangeAsync(tryingTimes);
			}
		}

		private bool IsIcgConfiguredDisabled()
		{
			try
			{
				return File.Exists(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AspenTech", "Aspen Knowledge In-Context", ".aticg.disabled"));
			}
			catch
			{
				return false;
			}
		}

		private void OnPropertyChanged(string propertyName)
		{
			this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}

		public async void OpenBrowserAsync(string url)
		{
			await Task.CompletedTask.ContinueWith(delegate(Task t)
			{
				if (SuccessfullyInitialized)
				{
					CheckELearningContent();
					if (!DoExchangeOpenUrl(url, out var errorInfo))
					{
						ProcessExchangeError(errorInfo);
					}
				}
			});
		}

		public void OpenBrowser(string url)
		{
			if (SuccessfullyInitialized)
			{
				CheckELearningContent();
				Cursor overrideCursor = Mouse.OverrideCursor;
				Mouse.OverrideCursor = Cursors.Wait;
				ExchangeErrorInfo errorInfo;
				bool num = DoExchangeOpenUrl(url, out errorInfo);
				Mouse.OverrideCursor = overrideCursor;
				if (!num)
				{
					ProcessExchangeError(errorInfo);
				}
			}
		}

		public async void SearchExchangeAsync(string searchText = "")
		{
			await Task.CompletedTask.ContinueWith(delegate(Task t)
			{
				if (SuccessfullyInitialized)
				{
					CheckELearningContent();
					if (!DoExchangeSearch(searchText, out var errorInfo))
					{
						ProcessExchangeError(errorInfo);
					}
				}
			});
		}

		public void SearchExchange(string searchText = "")
		{
			if (SuccessfullyInitialized)
			{
				CheckELearningContent();
				Cursor overrideCursor = Mouse.OverrideCursor;
				Mouse.OverrideCursor = Cursors.Wait;
				ExchangeErrorInfo errorInfo;
				bool num = DoExchangeSearch(searchText, out errorInfo);
				Mouse.OverrideCursor = overrideCursor;
				if (!num)
				{
					ProcessExchangeError(errorInfo);
				}
			}
		}

		public void OpenElearning()
		{
			if (SuccessfullyInitialized)
			{
				CheckELearningContent();
				Cursor overrideCursor = Mouse.OverrideCursor;
				Mouse.OverrideCursor = Cursors.Wait;
				ExchangeErrorInfo errorInfo;
				bool num = DoElearningCatelog(out errorInfo);
				Mouse.OverrideCursor = overrideCursor;
				if (!num)
				{
					ProcessExchangeError(errorInfo);
				}
			}
		}

		public void Shutdown()
		{
			if (SuccessfullyInitialized)
			{
				Cursor overrideCursor = Mouse.OverrideCursor;
				Mouse.OverrideCursor = Cursors.Wait;
				ExchangeAgentImpl.OnShutdown();
				Mouse.OverrideCursor = overrideCursor;
			}
		}

		private void CheckELearningContent()
		{
			if (!SuccessfullyInitialized)
			{
				return;
			}
			if (_productName != ProductName.AspenPlus && _productName != ProductName.Hysys
			    && _productName != ProductName.EDR && _productName != ProductName.ACCE && _productName != ProductName.Fidelis)
			{
				return;
			}
			if (_useELearningContent.HasValue)
			{
				return;
			}
			MessageBoxResult messageBoxResult = MessageBox.Show(InContextGuidanceResources.ExchangeIntegration_ELearningChekingDialog_Question, InContextGuidanceResources.ExchangeIntegration_ELearningChekingDialog_Title, MessageBoxButton.YesNo, MessageBoxImage.Question);
			_useELearningContent = messageBoxResult == MessageBoxResult.Yes;
		}

		private async void InitializeExchangeAsync(int tryingTimes)
		{
			await Task.Run(delegate
			{
				int num = Math.Max(1, tryingTimes);
				bool successfullyInitialized = false;
				ExchangeErrorInfo errorInfo = null;
				for (int i = 0; i < num; i++)
				{
					if (DoExchangeInitialize(out errorInfo))
					{
						successfullyInitialized = true;
						break;
					}
				}
				SuccessfullyInitialized = successfullyInitialized;
				if (!SuccessfullyInitialized)
				{
					ProcessExchangeError(errorInfo);
				}
			});
		}

		private bool DoExchangeInitialize(out ExchangeErrorInfo errorInfo)
		{
			try
			{
				bool flag;
				ExchangeError er;
				flag = ExchangeAgentImpl.Initialize(out er, GetSupportedLanguage());
				errorInfo = !flag ? new ExchangeErrorInfo(er, isInitializationError: true, null, null) : null;
				return flag;
			}
			catch (Exception ex)
			{
				errorInfo = new ExchangeErrorInfo(ex, isInitializationError: true, null, null);
				return false;
			}
		}

		private bool DoExchangeSearch(string searchText, out ExchangeErrorInfo errorInfo)
		{
			try
			{
				bool flag;
				ExchangeError er;
				flag = ExchangeAgentImpl.StartBrowserUrl(ExchangeProductName, ExchangeProductVersion, string.Empty, _useELearningContent == true, out er, GetSupportedLanguage(), searchText);
				errorInfo = !flag ? new ExchangeErrorInfo(er, isInitializationError: false, searchText, null) : null;
				return flag;
			}
			catch (Exception ex)
			{
				errorInfo = new ExchangeErrorInfo(ex, isInitializationError: false, searchText, null);
				return false;
			}
		}

		private bool DoElearningCatelog(out ExchangeErrorInfo errorInfo)
		{
			try
			{
				bool flag;
				ExchangeError err;
				flag = ExchangeAgentImpl.GetExchangeAgent().StartELearningCatalog(ExchangeProductName, ExchangeProductVersion, _useELearningContent == true, out err, isTab: true, GetSupportedLanguage());
				errorInfo = !flag ? new ExchangeErrorInfo(err, isInitializationError: false, null, null) : null;
				return flag;
			}
			catch (Exception ex)
			{
				errorInfo = new ExchangeErrorInfo(ex, isInitializationError: false, null, null);
				return false;
			}
		}

		private bool DoExchangeOpenUrl(string url, out ExchangeErrorInfo errorInfo)
		{
			try
			{
				bool flag;
				ExchangeError er;
				flag = ExchangeAgentImpl.StartBrowserUrl(ExchangeProductName, ExchangeProductVersion, url, _useELearningContent == true, out er, GetSupportedLanguage());
				errorInfo = !flag ? new ExchangeErrorInfo(er, isInitializationError: false, null, url) : null;
				return flag;
			}
			catch (Exception ex)
			{
				errorInfo = new ExchangeErrorInfo(ex, isInitializationError: false, null, url);
				return false;
			}
		}

		private void ProcessExchangeError(ExchangeErrorInfo errorInfo)
		{
			if (errorInfo != null)
			{
				_errorHandler?.Invoke(errorInfo);
			}
		}

		private SupportedLanguage GetSupportedLanguage()
		{
			if (string.IsNullOrWhiteSpace(_selectedLanguage))
			{
				string text = Registry.GetValue("HKEY_CURRENT_USER\\Software\\AspenTech\\Engineering\\Language", null, string.Empty) as string;
				_selectedLanguage = (string.IsNullOrWhiteSpace(text) ? "eng" : text.Trim().ToLowerInvariant());
			}
			return GetSupportedLanguage(_selectedLanguage);
		}

		private static SupportedLanguage GetSupportedLanguage(string threeLettersLanguage)
		{
			switch (threeLettersLanguage)
			{
				case "eng":
					return SupportedLanguage.en;
				case "chs":
					return SupportedLanguage.zh;
				case "zho":
					return SupportedLanguage.zh;
				case "jpn":
					return SupportedLanguage.ja;
				default:
					return SupportedLanguage.ot;
			}
		}

		private static TTo ConvertEnum<TFrom, TTo>(TFrom value) where TFrom : Enum where TTo : Enum
		{
			return (TTo)Enum.Parse(typeof(TTo), value.ToString());
		}
	}
	public class ExchangeErrorInfo
	{
		public bool IsInitializationError { get; }

		public string SearchText { get; }

		public string NavigationUrl { get; }

		public string ExceptionMessage { get; }

		public string StackTrace { get; }

		public string TranslatedDescription { get; }

		internal ExchangeErrorInfo(ExchangeError error, bool isInitializationError, string searchText, string navigationUrl)
			: this(isInitializationError, searchText, navigationUrl, error?.description, error?.stackTrace, error?.ToDescriptionString())
		{
		}

		internal ExchangeErrorInfo(Exception ex, bool isInitializationError, string searchText, string navigationUrl)
			: this(isInitializationError, searchText, navigationUrl, ex?.ToString(), ex?.StackTrace, ex?.Message)
		{
		}

		internal ExchangeErrorInfo(bool isInitializationError, string searchText, string navigationUrl, string exceptionMessage, string stackTrace, string translatedDescription)
		{
			IsInitializationError = isInitializationError;
			SearchText = searchText;
			NavigationUrl = navigationUrl;
			ExceptionMessage = exceptionMessage;
			StackTrace = stackTrace;
			TranslatedDescription = translatedDescription;
		}
	}
}
namespace AspenTech.InContextGuidance.ExchangeIntegration.Tools
{
	public static class AspenKnowledgeButtonProperties
	{
		public static readonly DependencyProperty UseDefaultCommandProperty = DependencyProperty.RegisterAttached("UseDefaultCommand", typeof(bool), typeof(AspenKnowledgeButtonProperties), new PropertyMetadata(OnUseDefaultCommandPropertyChanged));

		public static readonly DependencyProperty UseTooltipBindingProperty = DependencyProperty.RegisterAttached("UseTooltipBinding", typeof(bool), typeof(AspenKnowledgeButtonProperties), new PropertyMetadata(OnUseTooltipBindingPropertyChanged));

		public static string Caption => InContextGuidanceResources.ExchangeTools_AspenKnowledgeRibbon_Caption;

		public static ImageSource Image => ImageResources.AspenONEExchangeButtonImg;

		public static string TooltipHeader => InContextGuidanceResources.ExchangeTools_AspenKnowledgeRibbon_Caption;

		public static bool GetUseDefaultCommand(ButtonBase element)
		{
			return (bool)element.GetValue(UseDefaultCommandProperty);
		}

		public static void SetUseDefaultCommand(ButtonBase element, bool value)
		{
			element.SetValue(UseDefaultCommandProperty, value);
		}

		private static void OnUseDefaultCommandPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			ButtonBase buttonBase = d as ButtonBase;
			if ((bool)e.NewValue)
			{
				BindingOperations.SetBinding(buttonBase, UIElement.IsEnabledProperty, new Binding("SuccessfullyInitialized")
				{
					Source = ExchangeAdapter.Default,
					Mode = BindingMode.OneWay
				});
				buttonBase.Click += Button_Click;
			}
			else
			{
				BindingOperations.ClearBinding(buttonBase, UIElement.IsEnabledProperty);
				buttonBase.Click -= Button_Click;
			}
		}

		private static void Button_Click(object sender, RoutedEventArgs e)
		{
			ExchangeAdapter.Default.SearchExchange();
		}

		public static bool GetUseTooltipBinding(ContentControl element)
		{
			return (bool)element.GetValue(UseTooltipBindingProperty);
		}

		public static void SetUseTooltipBinding(ContentControl element, bool value)
		{
			element.SetValue(UseTooltipBindingProperty, value);
		}

		private static void OnUseTooltipBindingPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			ContentControl target = d as ContentControl;
			if ((bool)e.NewValue)
			{
				BindingOperations.SetBinding(target, ContentControl.ContentProperty, new Binding("SuccessfullyInitialized")
				{
					Source = ExchangeAdapter.Default,
					Converter = new ToolTipContentConverter
					{
						EnabledTooltip = InContextGuidanceResources.ExchangeTools_AspenKnowledgeRibbon_Tooltip_Enabled,
						DisabledTooltip = InContextGuidanceResources.ExchangeTools_AspenKnowledgeRibbon_Tooltip_Disabled
					}
				});
			}
			else
			{
				BindingOperations.ClearBinding(target, ContentControl.ContentProperty);
			}
		}
	}
	public static class ElearningButtonProperties
	{
		public static readonly DependencyProperty UseDefaultCommandProperty = DependencyProperty.RegisterAttached("UseDefaultCommand", typeof(bool), typeof(ElearningButtonProperties), new PropertyMetadata(OnUseDefaultCommandPropertyChanged));

		public static readonly DependencyProperty UseTooltipBindingProperty = DependencyProperty.RegisterAttached("UseTooltipBinding", typeof(bool), typeof(ElearningButtonProperties), new PropertyMetadata(OnUseTooltipBindingPropertyChanged));

		public static string Caption => InContextGuidanceResources.ExchangeTools_ELearningRibbon_Caption;

		public static ImageSource Image => ImageResources.ELearningButtonImg;

		public static string TooltipHeader => InContextGuidanceResources.ExchangeTools_ELearningRibbon_Caption;

		public static bool GetUseDefaultCommand(ButtonBase element)
		{
			return (bool)element.GetValue(UseDefaultCommandProperty);
		}

		public static void SetUseDefaultCommand(ButtonBase element, bool value)
		{
			element.SetValue(UseDefaultCommandProperty, value);
		}

		private static void OnUseDefaultCommandPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			ButtonBase buttonBase = d as ButtonBase;
			if ((bool)e.NewValue)
			{
				BindingOperations.SetBinding(buttonBase, UIElement.IsEnabledProperty, new Binding("SuccessfullyInitialized")
				{
					Source = ExchangeAdapter.Default,
					Mode = BindingMode.OneWay
				});
				buttonBase.Click += Button_Click;
			}
			else
			{
				BindingOperations.ClearBinding(buttonBase, UIElement.IsEnabledProperty);
				buttonBase.Click -= Button_Click;
			}
		}

		private static void Button_Click(object sender, RoutedEventArgs e)
		{
			ExchangeAdapter.Default.OpenElearning();
		}

		public static bool GetUseTooltipBinding(ContentControl element)
		{
			return (bool)element.GetValue(UseTooltipBindingProperty);
		}

		public static void SetUseTooltipBinding(ContentControl element, bool value)
		{
			element.SetValue(UseTooltipBindingProperty, value);
		}

		private static void OnUseTooltipBindingPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			ContentControl target = d as ContentControl;
			if ((bool)e.NewValue)
			{
				BindingOperations.SetBinding(target, ContentControl.ContentProperty, new Binding("SuccessfullyInitialized")
				{
					Source = ExchangeAdapter.Default,
					Converter = new ToolTipContentConverter
					{
						EnabledTooltip = InContextGuidanceResources.ExchangeTools_ELearningRibbon_Tooltip_Enabled,
						DisabledTooltip = InContextGuidanceResources.ExchangeTools_ELearningRibbon_Tooltip_Disabled
					}
				});
			}
			else
			{
				BindingOperations.ClearBinding(target, ContentControl.ContentProperty);
			}
		}
	}
	internal class ToolTipContentConverter : IValueConverter
	{
		public string EnabledTooltip { get; set; }

		public string DisabledTooltip { get; set; }

		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (!(bool)value)
			{
				return DisabledTooltip;
			}
			return EnabledTooltip;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			throw new NotImplementedException();
		}
	}
}
namespace AspenTech.InContextGuidance.ExchangeIntegration.Properties
{
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

		public static Settings Default => defaultInstance;
	}
}
namespace AspenTech.InContextGuidance.ExchangeIntegration.Images
{
	internal static class ImageResources
	{
		private static readonly Dictionary<string, ImageSource> _imageSources = new Dictionary<string, ImageSource>();

		public static ImageSource AspenONEExchangeButtonImg => GetImageSource("InContextGuidance.png");

		public static ImageSource ELearningButtonImg => GetImageSource("eLearning.png");

		private static ImageSource GetImageSource(string imageFileName)
		{
			if (!_imageSources.ContainsKey(imageFileName))
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append("pack://application:,,,/");
				stringBuilder.Append(typeof(ImageResources).Assembly.FullName);
				stringBuilder.Append(";component/Images/");
				stringBuilder.Append(imageFileName);
				_imageSources.Add(imageFileName, new BitmapImage(new Uri(stringBuilder.ToString(), UriKind.RelativeOrAbsolute)));
			}
			return _imageSources[imageFileName];
		}
	}
}
