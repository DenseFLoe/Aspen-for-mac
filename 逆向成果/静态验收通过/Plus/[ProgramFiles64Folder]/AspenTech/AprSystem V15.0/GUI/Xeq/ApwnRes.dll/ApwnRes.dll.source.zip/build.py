"""Assemble ApwnRes.dll from assembly and resource sources into an unsigned PE."""

import argparse
import json
from pathlib import Path
import struct
import subprocess
from tempfile import TemporaryDirectory


ROOT = Path(__file__).resolve().parent
ASSEMBLY = {'.text': 'ApwnRes.dll.x64.asm', '.rdata': 'rdata.asm', '.data': 'data.asm',
            '.pdata': 'pdata.asm', '.reloc': 'reloc.asm'}


def assemble(nasm, source, temporary):
    target = temporary / (source + '.bin')
    subprocess.run([str(nasm), '-f', 'bin', '-Werror', source, '-o', str(target)], cwd=ROOT, check=True)
    return target.read_bytes()


def resource_section():
    source = json.loads((ROOT / 'resources.json').read_text(encoding='utf-8'))
    writes = []
    for offset, header, entries in source['directories']:
        table = struct.pack('<IIHHHH', *header, 0, len(entries))
        table += b''.join(struct.pack('<II', identifier, target) for identifier, target in entries)
        writes.append((offset, table))
    for entry in source['leaves']:
        path = (ROOT / entry['file']).resolve()
        if not path.is_relative_to(ROOT / 'payload'):
            raise ValueError('A resource path leaves the source payload directory')
        payload = path.read_bytes()
        offset = entry['payload_offset']
        header = struct.pack('<IIII', source['rva'] + offset, len(payload), entry['code_page'], entry['reserved'])
        writes.extend(((entry['entry_offset'], header), (offset, payload)))
    data = bytearray(source['size'])
    end = 0
    for offset, raw in sorted(writes):
        if offset < end or offset + len(raw) > len(data):
            raise ValueError(f'Resource record outside its layout or overlapping at {offset:#x}')
        data[offset:offset + len(raw)] = raw
        end = offset + len(raw)
    return data


def pe_checksum(data):
    pad = b'\x00' if len(data) % 2 else b''
    value = sum(word for (word,) in struct.iter_unpack('<H', data + pad))
    while value > 0xffff:
        value = (value & 0xffff) + (value >> 16)
    return value + len(data)


def build(nasm):
    with TemporaryDirectory(prefix='apwnres-source-') as directory:
        temporary = Path(directory)
        header = assemble(nasm, 'pe-header.asm', temporary)
        pe_offset, = struct.unpack_from('<I', header, 0x3c)
        machine, count = struct.unpack_from('<HH', header, pe_offset + 4)
        optional_size, = struct.unpack_from('<H', header, pe_offset + 20)
        optional = pe_offset + 24
        if header[pe_offset:pe_offset + 4] != b'PE\0\0' or machine != 0x8664 or header[optional:optional + 2] != b'\x0b\x02':
            raise ValueError('The source header must describe an AMD64 PE32+ image')
        if any(header[optional + 144:optional + 152]):
            raise ValueError('The unsigned source header contains an unexpected certificate directory')
        data = bytearray(header)
        for index in range(count):
            offset = optional + optional_size + index * 40
            raw_name, _, _, size, begin = struct.unpack_from('<8sIIII', header, offset)
            section = raw_name.rstrip(b'\0').decode('ascii')
            content = resource_section() if section == '.rsrc' else assemble(nasm, ASSEMBLY[section], temporary)
            if len(content) != size or begin != len(data):
                raise ValueError(f'{section} assembled size or file offset differs from the source header')
            data.extend(content)
    checksum = optional + 64
    if any(data[checksum:checksum + 4]):
        raise ValueError('The checksum field must be zero before the image is assembled')
    struct.pack_into('<I', data, checksum, pe_checksum(data))
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('nasm', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    data = build(args.nasm.resolve())
    with args.output.open('xb') as file:
        file.write(data)


if __name__ == '__main__':
    main()
