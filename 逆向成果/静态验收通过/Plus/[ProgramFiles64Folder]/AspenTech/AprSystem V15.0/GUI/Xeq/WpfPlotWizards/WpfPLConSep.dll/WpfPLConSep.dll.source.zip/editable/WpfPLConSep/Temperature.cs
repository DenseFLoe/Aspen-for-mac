using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPlotwizard;

namespace WpfPLConSep;

[ProgId("WpfPLConSep.Temperature")]
public class Temperature : IRibbonPlotWizardType
{
	private IHNode _context;

	private IHWizardPlot _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private string _currentPresUnit = string.Empty;

	private string _uniqueId = "ConSep_Temperature";

	private string _plotName;

	private object _nodeCxs;

	private Image _imgBitmap;

	private bool _bHasInputDialog;

	private string _varName;

	private string _tempUnitsFieldId = WpfPLConSepResources.TempUnits;

	private string _currentTempUnit = "R";

	private bool _bCheckDataOnly;

	public string TooltipContentForRibbonItem => WpfPLConSepResources.TooltipContentForRibbonItem_Temp;

	public string TooltipHeaderForRibbonItem => WpfPLConSepResources.TooltipHeaderForRibbonItem_Temp;

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public object CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	public bool HasInputDialog => _bHasInputDialog;

	public string HelpFile => _help.GetHelpFileName();

	public long HelpID => _help.GetHelpID();

	public Image ImageIcon => _imgBitmap;

	public string Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	public List<string> SupportedDataFields => new List<string> { _tempUnitsFieldId };

	public List<string> SupportedStyleFields => new List<string>();

	public string TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	public object WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot;
		}
	}

	public Temperature()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		_varName = "Output\\B_TEMP4";
		_bHasInputDialog = false;
		if (_imgBitmap == null)
		{
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLConSep.Images.temp.ico");
			_imgBitmap = new Bitmap(manifestResourceStream);
		}
	}

	public void Context(object oNode, ref object oPlotWizardComponent, ref int ierror)
	{
		if (oPlotWizardComponent == null || oNode == null)
		{
			ierror = 1;
			return;
		}
		_context = oNode as IHNode;
		_wizardPlot = oPlotWizardComponent as IHWizardPlot;
		IHNode iHNode = _context.FindNode(_varName);
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		_wizardPlot.RemoveAllDependentVariable();
		_wizardPlot.SetIndependentVariable(_context, _varName + "!Label");
		_wizardPlot.AddDependentVariable(_context, _varName);
	}

	public void UpdateWizardData()
	{
		_wizardPlot.RemoveAllDependentVariable();
		_wizardPlot.SetIndependentVariable(_context, _varName + "!Label");
		_wizardPlot.AddDependentVariable(_context, _varName);
		_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currentTempUnit);
	}

	public List<string> FieldDataOptionList(string sFieldName)
	{
		if (sFieldName.Equals(_tempUnitsFieldId))
		{
			return new List<string> { "R", "F", "C", "K" };
		}
		return new List<string>();
	}

	public void GetConfigData(ref string sConfigValue)
	{
	}

	public RibbonControlType GetFieldCtrlType(string sFieldName)
	{
		if (sFieldName.Equals(_tempUnitsFieldId))
		{
			return (RibbonControlType)1;
		}
		return (RibbonControlType)0;
	}

	public void GetFieldData(string sFieldName, ref string sCurrentVal)
	{
		if (sFieldName.Equals(_tempUnitsFieldId))
		{
			sCurrentVal = (_currentTempUnit = _help.GetUnitString(_context.Application.Tree, _wizardPlot));
		}
	}

	public void GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	public void SetConfigData(string sValue)
	{
	}

	public void SetFieldData(string sFieldName, string sValue)
	{
		if (sFieldName.Equals(_tempUnitsFieldId))
		{
			_currentTempUnit = sValue;
		}
	}

	public void SetFieldStyle(string sFieldName, string sValue)
	{
	}

	public void ShowInputDialog()
	{
	}
}
