﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  XamlGeneratedNamespace.GeneratedInternalTypeHelper
  AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper
  AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior
  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_ViewModel
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm
  AspenTech.AspenPlus.MMForms.SummaryGrid.SummaryGridModule
  AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings
  AspenTech.AspenPlus.Happ.HappLS
  AspenTech.AspenPlus.Happ.IAPHappEvents
  AspenTech.AspenPlus.Happ.IAPHappEvents_Event
  AspenTech.AspenPlus.Happ.IHNode
  AspenTech.AspenPlus.Happ.IHapp
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__122'
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__131'
  AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern PresentationFramework
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern System
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern WindowsBase
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern System.Xml.Linq
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern AdbComInterfaces
{
  .ver 41:0:0:0
}
.assembly extern AspenDataShareCS
{
  .ver 41:0:0:0
}
.assembly extern PresentationCore
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern AspenTech.AspenCxs
{
  .publickeytoken = (5D 73 34 E0 D1 73 8A D6 )                         // ]s4..s..
  .ver 41:0:0:57
}
.assembly extern AspenTech.AspenPlus.MMControls
{
  .ver 41:0:0:614
}
.assembly extern System.Xaml
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern AspenTech.AspenCxs.CxsViewModel
{
  .ver 41:0:0:0
}
.assembly extern AspenTech.AspenCxs.SummaryGrid
{
  .publickeytoken = (5D 73 34 E0 D1 73 8A D6 )                         // ]s4..s..
  .ver 41:0:0:57
}
.assembly extern System.Core
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern Microsoft.Practices.Composite
{
  .publickeytoken = (8A F4 53 88 06 95 A9 B8 )                         // ..S.....
  .ver 2:0:1:0
}
.assembly extern Microsoft.Practices.Unity
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 3:5:0:0
}
.assembly extern AspenTech.AspenPlus.Infrastructure
{
  .ver 41:0:0:614
}
.assembly extern AspenTech.AspenPlus.UnmanagedWrapper
{
  .ver 1:0:9235:15398
}
.assembly extern AspenTech.AspenPlus.Localization
{
  .ver 41:0:0:614
}
.assembly extern Microsoft.Practices.Composite.Presentation
{
  .publickeytoken = (8A F4 53 88 06 95 A9 B8 )                         // ..S.....
  .ver 2:0:1:0
}
.assembly extern Microsoft.CSharp
{
  .publickeytoken = (B0 3F 5F 7F 11 D5 0A 3A )                         // .?_....:
  .ver 4:0:0:0
}
.assembly AspenTech.AspenPlus.MMForms.SummaryGrid
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.

  // --- The following custom attribute is added automatically, do not uncomment -------
  .custom instance void [mscorlib]System.Diagnostics.DebuggableAttribute::.ctor(valuetype [mscorlib]System.Diagnostics.DebuggableAttribute/DebuggingModes) = ( 01 00 02 00 00 00 00 00 ) 

  .custom instance void [mscorlib]System.Reflection.AssemblyFileVersionAttribute::.ctor(string) = ( 01 00 0A 34 31 2E 30 2E 30 2E 36 31 34 00 00 )    // ...41.0.0.614..
  .custom instance void [mscorlib]System.Reflection.AssemblyTitleAttribute::.ctor(string) = ( 01 00 27 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..'AspenTech.Asp
                                                                                              65 6E 50 6C 75 73 2E 4D 4D 46 6F 72 6D 73 2E 53   // enPlus.MMForms.S
                                                                                              75 6D 6D 61 72 79 47 72 69 64 00 00 )             // ummaryGrid..
  .custom instance void [mscorlib]System.Reflection.AssemblyDescriptionAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyConfigurationAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyCompanyAttribute::.ctor(string) = ( 01 00 16 41 73 70 65 6E 20 54 65 63 68 6E 6F 6C   // ...Aspen Technol
                                                                                                6F 67 79 2C 20 49 6E 63 2E 00 00 )                // ogy, Inc...
  .custom instance void [mscorlib]System.Reflection.AssemblyProductAttribute::.ctor(string) = ( 01 00 27 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..'AspenTech.Asp
                                                                                                65 6E 50 6C 75 73 2E 4D 4D 46 6F 72 6D 73 2E 53   // enPlus.MMForms.S
                                                                                                75 6D 6D 61 72 79 47 72 69 64 00 00 )             // ummaryGrid..
  .custom instance void [mscorlib]System.Reflection.AssemblyCopyrightAttribute::.ctor(string) = ( 01 00 29 43 6F 70 79 72 69 67 68 74 20 C2 A9 20   // ..)Copyright .. 
                                                                                                  41 73 70 65 6E 20 54 65 63 68 6E 6F 6C 6F 67 79   // Aspen Technology
                                                                                                  20 32 30 31 31 20 2D 20 32 30 32 34 00 00 )       //  2011 - 2024..
  .custom instance void [mscorlib]System.Reflection.AssemblyTrademarkAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Resources.NeutralResourcesLanguageAttribute::.ctor(string,
                                                                                            valuetype [mscorlib]System.Resources.UltimateResourceFallbackLocation) = ( 01 00 05 65 6E 2D 55 53 01 00 00 00 00 00 )       // ...en-US......
  .custom instance void [PresentationFramework]System.Windows.ThemeInfoAttribute::.ctor(valuetype [PresentationFramework]System.Windows.ResourceDictionaryLocation,
                                                                                        valuetype [PresentationFramework]System.Windows.ResourceDictionaryLocation) = ( 01 00 00 00 00 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.Versioning.TargetFrameworkAttribute::.ctor(string) = ( 01 00 1A 2E 4E 45 54 46 72 61 6D 65 77 6F 72 6B   // ....NETFramework
                                                                                                        2C 56 65 72 73 69 6F 6E 3D 76 34 2E 38 01 00 54   // ,Version=v4.8..T
                                                                                                        0E 14 46 72 61 6D 65 77 6F 72 6B 44 69 73 70 6C   // ..FrameworkDispl
                                                                                                        61 79 4E 61 6D 65 12 2E 4E 45 54 20 46 72 61 6D   // ayName..NET Fram
                                                                                                        65 77 6F 72 6B 20 34 2E 38 )                      // ework 4.8
  .hash algorithm 0x00008004
  .ver 41:0:0:614
}
.module AspenTech.AspenPlus.MMForms.SummaryGrid.dll
// MVID: {e6ace148-46ad-4dc8-af52-f7dcded80fba}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000001    //  ILONLY
// Image base: 0x0000025825F60000


// =============== CLASS MEMBERS DECLARATION ===================

.class public auto ansi sealed beforefieldinit XamlGeneratedNamespace.GeneratedInternalTypeHelper
       extends [WindowsBase]System.Windows.Markup.InternalTypeHelper
{
  .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                  75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                  30 00 00 )                                        // 0..
  .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
  .method family hidebysig virtual instance object 
          CreateInstance(class [mscorlib]System.Type 'type',
                         class [mscorlib]System.Globalization.CultureInfo culture) cil managed
  {
    // Code size       15 (0xf)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4     0x234
    IL_0006:  ldnull
    IL_0007:  ldnull
    IL_0008:  ldarg.2
    IL_0009:  call       object [mscorlib]System.Activator::CreateInstance(class [mscorlib]System.Type,
                                                                           valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                           class [mscorlib]System.Reflection.Binder,
                                                                           object[],
                                                                           class [mscorlib]System.Globalization.CultureInfo)
    IL_000e:  ret
  } // end of method GeneratedInternalTypeHelper::CreateInstance

  .method family hidebysig virtual instance object 
          GetPropertyValue(class [mscorlib]System.Reflection.PropertyInfo propertyInfo,
                           object target,
                           class [mscorlib]System.Globalization.CultureInfo culture) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldc.i4.0
    IL_0003:  ldnull
    IL_0004:  ldnull
    IL_0005:  ldarg.3
    IL_0006:  callvirt   instance object [mscorlib]System.Reflection.PropertyInfo::GetValue(object,
                                                                                            valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                                            class [mscorlib]System.Reflection.Binder,
                                                                                            object[],
                                                                                            class [mscorlib]System.Globalization.CultureInfo)
    IL_000b:  ret
  } // end of method GeneratedInternalTypeHelper::GetPropertyValue

  .method family hidebysig virtual instance void 
          SetPropertyValue(class [mscorlib]System.Reflection.PropertyInfo propertyInfo,
                           object target,
                           object 'value',
                           class [mscorlib]System.Globalization.CultureInfo culture) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  ldc.i4.0
    IL_0004:  ldnull
    IL_0005:  ldnull
    IL_0006:  ldarg.s    culture
    IL_0008:  callvirt   instance void [mscorlib]System.Reflection.PropertyInfo::SetValue(object,
                                                                                          object,
                                                                                          valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                                          class [mscorlib]System.Reflection.Binder,
                                                                                          object[],
                                                                                          class [mscorlib]System.Globalization.CultureInfo)
    IL_000d:  ret
  } // end of method GeneratedInternalTypeHelper::SetPropertyValue

  .method family hidebysig virtual instance class [mscorlib]System.Delegate 
          CreateDelegate(class [mscorlib]System.Type delegateType,
                         object target,
                         string 'handler') cil managed
  {
    // Code size       44 (0x2c)
    .maxstack  9
    .locals init ()
    IL_0000:  ldarg.2
    IL_0001:  callvirt   instance class [mscorlib]System.Type [mscorlib]System.Object::GetType()
    IL_0006:  ldstr      "_CreateDelegate"
    IL_000b:  ldc.i4     0x124
    IL_0010:  ldnull
    IL_0011:  ldarg.2
    IL_0012:  ldc.i4.2
    IL_0013:  newarr     [mscorlib]System.Object
    IL_0018:  dup
    IL_0019:  ldc.i4.0
    IL_001a:  ldarg.1
    IL_001b:  stelem.ref
    IL_001c:  dup
    IL_001d:  ldc.i4.1
    IL_001e:  ldarg.3
    IL_001f:  stelem.ref
    IL_0020:  ldnull
    IL_0021:  callvirt   instance object [mscorlib]System.Type::InvokeMember(string,
                                                                             valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                             class [mscorlib]System.Reflection.Binder,
                                                                             object,
                                                                             object[],
                                                                             class [mscorlib]System.Globalization.CultureInfo)
    IL_0026:  castclass  [mscorlib]System.Delegate
    IL_002b:  ret
  } // end of method GeneratedInternalTypeHelper::CreateDelegate

  .method family hidebysig virtual instance void 
          AddEventHandler(class [mscorlib]System.Reflection.EventInfo eventInfo,
                          object target,
                          class [mscorlib]System.Delegate 'handler') cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  callvirt   instance void [mscorlib]System.Reflection.EventInfo::AddEventHandler(object,
                                                                                              class [mscorlib]System.Delegate)
    IL_0008:  ret
  } // end of method GeneratedInternalTypeHelper::AddEventHandler

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [WindowsBase]System.Windows.Markup.InternalTypeHelper::.ctor()
    IL_0006:  ret
  } // end of method GeneratedInternalTypeHelper::.ctor

} // end of class XamlGeneratedNamespace.GeneratedInternalTypeHelper

.class public abstract auto ansi sealed beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper
       extends [mscorlib]System.Object
{
  .field private static class [System.Xml.Linq]System.Xml.Linq.XElement _xElement
  .field private static literal string BlockSummaryDefinitionFile = "Aplus-BlockSummaryDefinition.sgxml"
  .field private static literal string DesignSpecBlockType = "DESIGN-SPEC"
  .field private static literal string UtilityBlockType = "Utilities"
  .field private static literal string UtilityBlockType2 = "Utility"
  .field private static literal string DataBlockType = "Data"
  .field private static literal string StreamPriceBlockType = "STREAM-PRICE"
  .field private static literal string EmptyTabbedSummaryGridXml = "<\?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"y"
  + "es\"\?><TabbedSummaryGrid><Tabs></Tabs></TabbedSummaryGrid>"
  .field public static literal string DataPathTopAppModel = "Top.appModelV8"
  .field private static literal string DataPathBlocks = "Blocks"
  .field public static literal string DataPathDesignSpec = "Flowsheeting Options.Design-Spec"
  .field public static literal string NavigatorPathDesignSpec = "Flowsheeting Options.Design Specs"
  .field private static literal string DataPathUtilities = "Utilities"
  .field private static literal string DataPathStreams = "Streams"
  .field private static literal string DataPathData = "Data"
  .field private static string _sFolderPath
  .method public hidebysig specialname static 
          string  get_FolderPath() cil managed
  {
    // Code size       135 (0x87)
    .maxstack  3
    .locals init ()
    IL_0000:  ldsfld     string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_sFolderPath
    IL_0005:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_000a:  brfalse.s  IL_0081

    IL_000c:  ldstr      "HKEY_CURRENT_USER\\Software\\AspenTech\\Engineering\\L"
    + "anguage"
    IL_0011:  ldnull
    IL_0012:  ldsfld     string [mscorlib]System.String::Empty
    IL_0017:  call       object [mscorlib]Microsoft.Win32.Registry::GetValue(string,
                                                                             string,
                                                                             object)
    IL_001c:  isinst     [mscorlib]System.String
    IL_0021:  stsfld     string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_sFolderPath
    IL_0026:  ldsfld     string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_sFolderPath
    IL_002b:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0030:  brtrue.s   IL_0077

    IL_0032:  ldstr      "SGXML\\"
    IL_0037:  ldsfld     string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_sFolderPath
    IL_003c:  callvirt   instance string [mscorlib]System.String::ToUpperInvariant()
    IL_0041:  ldstr      "\\"
    IL_0046:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_004b:  stsfld     string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_sFolderPath
    IL_0050:  call       string [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.SystemEnvironment::get_EntryDir()
    IL_0055:  ldstr      "\\"
    IL_005a:  ldsfld     string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_sFolderPath
    IL_005f:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0064:  call       bool [mscorlib]System.IO.Directory::Exists(string)
    IL_0069:  brtrue.s   IL_0081

    IL_006b:  ldstr      "SGXML\\ENG\\"
    IL_0070:  stsfld     string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_sFolderPath
    IL_0075:  br.s       IL_0081

    IL_0077:  ldstr      "SGXML\\ENG\\"
    IL_007c:  stsfld     string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_sFolderPath
    IL_0081:  ldsfld     string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_sFolderPath
    IL_0086:  ret
  } // end of method BlockSummaryHelper::get_FolderPath

  .method public hidebysig specialname static 
          class [System.Xml.Linq]System.Xml.Linq.XElement 
          get_GridSummaryXmlElement() cil managed
  {
    // Code size       179 (0xb3)
    .maxstack  3
    .locals init (string V_0,
             class [System.Xml.Linq]System.Xml.Linq.XDocument V_1,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_2,
             class [System.Xml.Linq]System.Xml.Linq.XAttribute V_3,
             string V_4)
    IL_0000:  ldsfld     class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_xElement
    IL_0005:  brtrue     IL_00ad

    IL_000a:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::get_FolderPath()
    IL_000f:  ldstr      "Aplus-BlockSummaryDefinition.sgxml"
    IL_0014:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0019:  call       string [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.SystemEnvironment::FindFileInContextFolder(string)
    IL_001e:  stloc.0
    IL_001f:  ldloc.0
    IL_0020:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0025:  brtrue     IL_00ad

    IL_002a:  ldloc.0
    IL_002b:  call       string [mscorlib]System.IO.File::ReadAllText(string)
    IL_0030:  call       class [System.Xml.Linq]System.Xml.Linq.XDocument [System.Xml.Linq]System.Xml.Linq.XDocument::Parse(string)
    IL_0035:  stloc.1
    IL_0036:  ldloc.1
    IL_0037:  brfalse.s  IL_00ad

    IL_0039:  ldloc.1
    IL_003a:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XDocument::get_Root()
    IL_003f:  ldstr      "Grid"
    IL_0044:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0049:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.Linq.XContainer::Elements(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_004e:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::GetEnumerator()
    IL_0053:  stloc.2
    .try
    {
      IL_0054:  br.s       IL_008e

      IL_0056:  ldloc.2
      IL_0057:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::get_Current()
      IL_005c:  ldstr      "File"
      IL_0061:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_0066:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XAttribute [System.Xml.Linq]System.Xml.Linq.XElement::Attribute(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_006b:  stloc.3
      IL_006c:  ldloc.3
      IL_006d:  brfalse.s  IL_008e

      IL_006f:  ldloc.3
      IL_0070:  call       string [System.Xml.Linq]System.Xml.Linq.XAttribute::op_Explicit(class [System.Xml.Linq]System.Xml.Linq.XAttribute)
      IL_0075:  stloc.s    V_4
      IL_0077:  ldloc.3
      IL_0078:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::get_FolderPath()
      IL_007d:  ldloc.s    V_4
      IL_007f:  call       string [mscorlib]System.String::Concat(string,
                                                                  string)
      IL_0084:  call       string [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.SystemEnvironment::FindFileInContextFolder(string)
      IL_0089:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XAttribute::set_Value(string)
      IL_008e:  ldloc.2
      IL_008f:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_0094:  brtrue.s   IL_0056

      IL_0096:  leave.s    IL_00a2

    }  // end .try
    finally
    {
      IL_0098:  ldloc.2
      IL_0099:  brfalse.s  IL_00a1

      IL_009b:  ldloc.2
      IL_009c:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_00a1:  endfinally
    }  // end handler
    IL_00a2:  ldloc.1
    IL_00a3:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XDocument::get_Root()
    IL_00a8:  stsfld     class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_xElement
    IL_00ad:  ldsfld     class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::_xElement
    IL_00b2:  ret
  } // end of method BlockSummaryHelper::get_GridSummaryXmlElement

  .method public hidebysig static bool  InvariantEquals(string x,
                                                        string y) cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldc.i4.3
    IL_0003:  call       bool [mscorlib]System.String::Equals(string,
                                                              string,
                                                              valuetype [mscorlib]System.StringComparison)
    IL_0008:  ret
  } // end of method BlockSummaryHelper::InvariantEquals

  .method public hidebysig static string 
          DoBlockSummary() cil managed
  {
    // Code size       46 (0x2e)
    .maxstack  5
    .locals init (class [mscorlib]System.Collections.Generic.IList`1<string> V_0,
             class [mscorlib]System.Collections.Generic.IList`1<string> V_1,
             class [mscorlib]System.Collections.Generic.IList`1<string> V_2)
    IL_0000:  call       class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::get_GridSummaryXmlElement()
    IL_0005:  brfalse.s  IL_002c

    IL_0007:  call       class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>> [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::MDFindBlocks()
    IL_000c:  call       class [mscorlib]System.Collections.Generic.IList`1<string> [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::MDFindDesignSpecs()
    IL_0011:  stloc.0
    IL_0012:  call       class [mscorlib]System.Collections.Generic.IList`1<string> [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::MDFindUtilities()
    IL_0017:  stloc.1
    IL_0018:  call       class [mscorlib]System.Collections.Generic.IList`1<string> [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::MDFindStreamsWithPricing()
    IL_001d:  stloc.2
    IL_001e:  ldloc.0
    IL_001f:  ldloc.1
    IL_0020:  ldloc.2
    IL_0021:  call       class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::get_GridSummaryXmlElement()
    IL_0026:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::BuildBlockSummaryString(class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>,
                                                                                                                    class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                    class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                    class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                    class [System.Xml.Linq]System.Xml.Linq.XElement)
    IL_002b:  ret

    IL_002c:  ldnull
    IL_002d:  ret
  } // end of method BlockSummaryHelper::DoBlockSummary

  .method public hidebysig static string 
          DoBlockSummary2(string blockId,
                          string blockType) cil managed
  {
    // Code size       142 (0x8e)
    .maxstack  5
    .locals init (class [mscorlib]System.Collections.Generic.List`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>> V_0,
             class [mscorlib]System.Collections.Generic.List`1<string> V_1,
             class [mscorlib]System.Collections.Generic.List`1<string> V_2,
             class [mscorlib]System.Collections.Generic.List`1<string> V_3)
    IL_0000:  call       class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::get_GridSummaryXmlElement()
    IL_0005:  brfalse    IL_008c

    IL_000a:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::.ctor()
    IL_000f:  stloc.0
    IL_0010:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0015:  stloc.1
    IL_0016:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_001b:  stloc.2
    IL_001c:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0021:  stloc.3
    IL_0022:  ldarg.1
    IL_0023:  ldstr      "DESIGN-SPEC"
    IL_0028:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_002d:  brfalse.s  IL_0038

    IL_002f:  ldloc.1
    IL_0030:  ldarg.0
    IL_0031:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0036:  br.s       IL_007d

    IL_0038:  ldarg.1
    IL_0039:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::IsUtilityBlockType(string)
    IL_003e:  brfalse.s  IL_0049

    IL_0040:  ldloc.2
    IL_0041:  ldarg.0
    IL_0042:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0047:  br.s       IL_007d

    IL_0049:  ldarg.1
    IL_004a:  ldstr      "Data"
    IL_004f:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0054:  brfalse.s  IL_0070

    IL_0056:  ldarg.0
    IL_0057:  ldstr      "STREAM-PRICE"
    IL_005c:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0061:  brfalse.s  IL_007d

    IL_0063:  ldloc.3
    IL_0064:  call       class [mscorlib]System.Collections.Generic.IList`1<string> [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::MDFindStreamsWithPricing()
    IL_0069:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::AddRange(class [mscorlib]System.Collections.Generic.IEnumerable`1<!0>)
    IL_006e:  br.s       IL_007d

    IL_0070:  ldloc.0
    IL_0071:  ldarg.0
    IL_0072:  ldarg.1
    IL_0073:  newobj     instance void valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>::.ctor(!0,
                                                                                                                           !1)
    IL_0078:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::Add(!0)
    IL_007d:  ldloc.0
    IL_007e:  ldloc.1
    IL_007f:  ldloc.2
    IL_0080:  ldloc.3
    IL_0081:  call       class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::get_GridSummaryXmlElement()
    IL_0086:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::BuildBlockSummaryString(class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>,
                                                                                                                    class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                    class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                    class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                    class [System.Xml.Linq]System.Xml.Linq.XElement)
    IL_008b:  ret

    IL_008c:  ldnull
    IL_008d:  ret
  } // end of method BlockSummaryHelper::DoBlockSummary2

  .method public hidebysig static string 
          GetFullBlockPath(string blockId,
                           string blockType) cil managed
  {
    // Code size       180 (0xb4)
    .maxstack  9
    .locals init (class [mscorlib]System.Collections.Generic.List`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>> V_0,
             class [mscorlib]System.Collections.Generic.List`1<string> V_1,
             class [mscorlib]System.Collections.Generic.List`1<string> V_2,
             class [mscorlib]System.Collections.Generic.List`1<string> V_3,
             bool V_4,
             bool V_5,
             bool V_6,
             bool V_7)
    IL_0000:  call       class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::get_GridSummaryXmlElement()
    IL_0005:  brfalse    IL_00b2

    IL_000a:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::.ctor()
    IL_000f:  stloc.0
    IL_0010:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0015:  stloc.1
    IL_0016:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_001b:  stloc.2
    IL_001c:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0021:  stloc.3
    IL_0022:  ldarg.1
    IL_0023:  ldstr      "DESIGN-SPEC"
    IL_0028:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_002d:  brtrue.s   IL_003c

    IL_002f:  ldarg.1
    IL_0030:  ldstr      "Design Specs"
    IL_0035:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_003a:  brfalse.s  IL_0045

    IL_003c:  ldloc.1
    IL_003d:  ldarg.0
    IL_003e:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0043:  br.s       IL_0080

    IL_0045:  ldarg.1
    IL_0046:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::IsUtilityBlockType(string)
    IL_004b:  brfalse.s  IL_0056

    IL_004d:  ldloc.2
    IL_004e:  ldarg.0
    IL_004f:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0054:  br.s       IL_0080

    IL_0056:  ldarg.1
    IL_0057:  ldstr      "STREAM-PRICE"
    IL_005c:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0061:  brfalse.s  IL_0073

    IL_0063:  ldstr      "Top.appModelV8"
    IL_0068:  ldstr      "Setup.Stream Price"
    IL_006d:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(string,
                                                                                                            string)
    IL_0072:  ret

    IL_0073:  ldloc.0
    IL_0074:  ldarg.0
    IL_0075:  ldarg.1
    IL_0076:  newobj     instance void valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>::.ctor(!0,
                                                                                                                           !1)
    IL_007b:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::Add(!0)
    IL_0080:  ldc.i4.0
    IL_0081:  stloc.s    V_4
    IL_0083:  ldc.i4.0
    IL_0084:  stloc.s    V_5
    IL_0086:  ldc.i4.0
    IL_0087:  stloc.s    V_6
    IL_0089:  ldc.i4.0
    IL_008a:  stloc.s    V_7
    IL_008c:  ldloc.0
    IL_008d:  ldloc.1
    IL_008e:  ldloc.2
    IL_008f:  ldloc.3
    IL_0090:  call       class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::get_GridSummaryXmlElement()
    IL_0095:  ldloca.s   V_4
    IL_0097:  ldloca.s   V_5
    IL_0099:  ldloca.s   V_6
    IL_009b:  ldloca.s   V_7
    IL_009d:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CheckBlockTypes(class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>,
                                                                                                          class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                          class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                          class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                          class [System.Xml.Linq]System.Xml.Linq.XElement,
                                                                                                          bool&,
                                                                                                          bool&,
                                                                                                          bool&,
                                                                                                          bool&)
    IL_00a2:  ldarg.0
    IL_00a3:  ldloc.s    V_4
    IL_00a5:  ldloc.s    V_5
    IL_00a7:  ldloc.s    V_6
    IL_00a9:  ldloc.s    V_7
    IL_00ab:  ldc.i4.1
    IL_00ac:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::GetFullDataPath(string,
                                                                                                            bool,
                                                                                                            bool,
                                                                                                            bool,
                                                                                                            bool,
                                                                                                            bool)
    IL_00b1:  ret

    IL_00b2:  ldnull
    IL_00b3:  ret
  } // end of method BlockSummaryHelper::GetFullBlockPath

  .method private hidebysig static string 
          BuildBlockSummaryString(class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>> blocks,
                                  class [mscorlib]System.Collections.Generic.IList`1<string> designSpecs,
                                  class [mscorlib]System.Collections.Generic.IList`1<string> utilities,
                                  class [mscorlib]System.Collections.Generic.IList`1<string> streamsWithPricing,
                                  class [System.Xml.Linq]System.Xml.Linq.XElement definitionRootElement) cil managed
  {
    // Code size       664 (0x298)
    .maxstack  8
    .locals init (class [System.Xml.Linq]System.Xml.Linq.XDocument V_0,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_1,
             int32 V_2,
             int32 V_3,
             int32 V_4,
             int32 V_5,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_6,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_7,
             string V_8,
             string V_9,
             class [System.Xml.Linq]System.Xml.Linq.XDocument V_10,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_11,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_12,
             string V_13,
             int32 V_14,
             bool V_15,
             int32 V_16,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string> V_17)
    IL_0000:  ldstr      "<\?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"y"
    + "es\"\?><TabbedSummaryGrid><Tabs></Tabs></TabbedSummaryGrid>"
    IL_0005:  call       class [System.Xml.Linq]System.Xml.Linq.XDocument [System.Xml.Linq]System.Xml.Linq.XDocument::Parse(string)
    IL_000a:  stloc.0
    IL_000b:  ldloc.0
    IL_000c:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XDocument::get_Root()
    IL_0011:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XNode [System.Xml.Linq]System.Xml.Linq.XContainer::get_FirstNode()
    IL_0016:  isinst     [System.Xml.Linq]System.Xml.Linq.XElement
    IL_001b:  stloc.1
    IL_001c:  ldarg.0
    IL_001d:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.ICollection`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::get_Count()
    IL_0022:  stloc.2
    IL_0023:  ldarg.1
    IL_0024:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.ICollection`1<string>::get_Count()
    IL_0029:  stloc.3
    IL_002a:  ldarg.2
    IL_002b:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.ICollection`1<string>::get_Count()
    IL_0030:  stloc.s    V_4
    IL_0032:  ldarg.3
    IL_0033:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.ICollection`1<string>::get_Count()
    IL_0038:  stloc.s    V_5
    IL_003a:  ldarg.s    definitionRootElement
    IL_003c:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.Linq.XContainer::Elements()
    IL_0041:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::GetEnumerator()
    IL_0046:  stloc.s    V_6
    .try
    {
      IL_0048:  br         IL_0277

      IL_004d:  ldloc.s    V_6
      IL_004f:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::get_Current()
      IL_0054:  stloc.s    V_7
      IL_0056:  ldloc.s    V_7
      IL_0058:  ldstr      "File"
      IL_005d:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_0062:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XAttribute [System.Xml.Linq]System.Xml.Linq.XElement::Attribute(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_0067:  call       string [System.Xml.Linq]System.Xml.Linq.XAttribute::op_Explicit(class [System.Xml.Linq]System.Xml.Linq.XAttribute)
      IL_006c:  stloc.s    V_8
      IL_006e:  ldloc.s    V_8
      IL_0070:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
      IL_0075:  brtrue     IL_0277

      IL_007a:  ldloc.s    V_7
      IL_007c:  ldstr      "Type"
      IL_0081:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_0086:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XAttribute [System.Xml.Linq]System.Xml.Linq.XElement::Attribute(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_008b:  call       string [System.Xml.Linq]System.Xml.Linq.XAttribute::op_Explicit(class [System.Xml.Linq]System.Xml.Linq.XAttribute)
      IL_0090:  stloc.s    V_9
      IL_0092:  ldloc.s    V_7
      IL_0094:  ldstr      "ids/id"
      IL_0099:  call       class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.XPath.Extensions::XPathSelectElements(class [System.Xml.Linq]System.Xml.Linq.XNode,
                                                                                                                                                                                                       string)
      IL_009e:  ldloc.s    V_8
      IL_00a0:  call       string [mscorlib]System.IO.File::ReadAllText(string)
      IL_00a5:  call       class [System.Xml.Linq]System.Xml.Linq.XDocument [System.Xml.Linq]System.Xml.Linq.XDocument::Parse(string)
      IL_00aa:  stloc.s    V_10
      IL_00ac:  ldnull
      IL_00ad:  stloc.s    V_11
      IL_00af:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::GetEnumerator()
      IL_00b4:  stloc.s    V_12
      .try
      {
        IL_00b6:  br         IL_025d

        IL_00bb:  ldloc.s    V_12
        IL_00bd:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::get_Current()
        IL_00c2:  ldstr      "Name"
        IL_00c7:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
        IL_00cc:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XAttribute [System.Xml.Linq]System.Xml.Linq.XElement::Attribute(class [System.Xml.Linq]System.Xml.Linq.XName)
        IL_00d1:  call       string [System.Xml.Linq]System.Xml.Linq.XAttribute::op_Explicit(class [System.Xml.Linq]System.Xml.Linq.XAttribute)
        IL_00d6:  stloc.s    V_13
        IL_00d8:  ldc.i4.0
        IL_00d9:  stloc.s    V_14
        IL_00db:  br         IL_024d

        IL_00e0:  ldc.i4.0
        IL_00e1:  stloc.s    V_15
        IL_00e3:  ldc.i4.0
        IL_00e4:  stloc.s    V_16
        IL_00e6:  ldloc.s    V_14
        IL_00e8:  ldloc.2
        IL_00e9:  bge.s      IL_010d

        IL_00eb:  ldarg.0
        IL_00ec:  ldloc.s    V_14
        IL_00ee:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::get_Item(int32)
        IL_00f3:  stloc.s    V_17
        IL_00f5:  ldloca.s   V_17
        IL_00f7:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>::get_Value()
        IL_00fc:  ldloc.s    V_13
        IL_00fe:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_0103:  brfalse.s  IL_010d

        IL_0105:  ldc.i4.1
        IL_0106:  stloc.s    V_15
        IL_0108:  ldc.i4.1
        IL_0109:  stloc.s    V_16
        IL_010b:  br.s       IL_017c

        IL_010d:  ldloc.s    V_14
        IL_010f:  ldloc.2
        IL_0110:  blt.s      IL_012f

        IL_0112:  ldloc.s    V_14
        IL_0114:  ldloc.2
        IL_0115:  ldloc.3
        IL_0116:  add
        IL_0117:  bge.s      IL_012f

        IL_0119:  ldstr      "DESIGN-SPEC"
        IL_011e:  ldloc.s    V_13
        IL_0120:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_0125:  brfalse.s  IL_012f

        IL_0127:  ldc.i4.1
        IL_0128:  stloc.s    V_15
        IL_012a:  ldc.i4.2
        IL_012b:  stloc.s    V_16
        IL_012d:  br.s       IL_017c

        IL_012f:  ldloc.s    V_14
        IL_0131:  ldloc.2
        IL_0132:  ldloc.3
        IL_0133:  add
        IL_0134:  blt.s      IL_0151

        IL_0136:  ldloc.s    V_14
        IL_0138:  ldloc.2
        IL_0139:  ldloc.3
        IL_013a:  add
        IL_013b:  ldloc.s    V_4
        IL_013d:  add
        IL_013e:  bge.s      IL_0151

        IL_0140:  ldloc.s    V_13
        IL_0142:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::IsUtilityBlockType(string)
        IL_0147:  brfalse.s  IL_0151

        IL_0149:  ldc.i4.1
        IL_014a:  stloc.s    V_15
        IL_014c:  ldc.i4.3
        IL_014d:  stloc.s    V_16
        IL_014f:  br.s       IL_017c

        IL_0151:  ldloc.s    V_14
        IL_0153:  ldloc.2
        IL_0154:  ldloc.3
        IL_0155:  add
        IL_0156:  ldloc.s    V_4
        IL_0158:  add
        IL_0159:  blt.s      IL_017c

        IL_015b:  ldloc.s    V_14
        IL_015d:  ldloc.2
        IL_015e:  ldloc.3
        IL_015f:  add
        IL_0160:  ldloc.s    V_4
        IL_0162:  add
        IL_0163:  ldloc.s    V_5
        IL_0165:  add
        IL_0166:  bge.s      IL_017c

        IL_0168:  ldstr      "STREAM-PRICE"
        IL_016d:  ldloc.s    V_13
        IL_016f:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_0174:  brfalse.s  IL_017c

        IL_0176:  ldc.i4.1
        IL_0177:  stloc.s    V_15
        IL_0179:  ldc.i4.4
        IL_017a:  stloc.s    V_16
        IL_017c:  ldloc.s    V_15
        IL_017e:  brfalse    IL_0247

        IL_0183:  ldloc.s    V_11
        IL_0185:  brtrue.s   IL_0198

        IL_0187:  ldloc.s    V_10
        IL_0189:  call       class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CreateTabElement(class [System.Xml.Linq]System.Xml.Linq.XDocument)
        IL_018e:  stloc.s    V_11
        IL_0190:  ldloc.1
        IL_0191:  ldloc.s    V_11
        IL_0193:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
        IL_0198:  ldloc.s    V_16
        IL_019a:  ldc.i4.1
        IL_019b:  bne.un.s   IL_01d9

        IL_019d:  ldloc.s    V_11
        IL_019f:  ldloc.s    V_10
        IL_01a1:  ldarg.0
        IL_01a2:  ldloc.s    V_14
        IL_01a4:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::get_Item(int32)
        IL_01a9:  stloc.s    V_17
        IL_01ab:  ldloca.s   V_17
        IL_01ad:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>::get_Key()
        IL_01b2:  ldarg.0
        IL_01b3:  ldloc.s    V_14
        IL_01b5:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::get_Item(int32)
        IL_01ba:  stloc.s    V_17
        IL_01bc:  ldloca.s   V_17
        IL_01be:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>::get_Value()
        IL_01c3:  ldloc.s    V_9
        IL_01c5:  ldstr      "Block"
        IL_01ca:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_01cf:  ldc.i4.0
        IL_01d0:  ldc.i4.0
        IL_01d1:  ldc.i4.0
        IL_01d2:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::AppendRowInformation(class [System.Xml.Linq]System.Xml.Linq.XElement,
                                                                                                                   class [System.Xml.Linq]System.Xml.Linq.XDocument,
                                                                                                                   string,
                                                                                                                   string,
                                                                                                                   bool,
                                                                                                                   bool,
                                                                                                                   bool,
                                                                                                                   bool)
        IL_01d7:  br.s       IL_0247

        IL_01d9:  ldloc.s    V_16
        IL_01db:  ldc.i4.2
        IL_01dc:  bne.un.s   IL_01fc

        IL_01de:  ldloc.s    V_11
        IL_01e0:  ldloc.s    V_10
        IL_01e2:  ldarg.1
        IL_01e3:  ldloc.s    V_14
        IL_01e5:  ldloc.2
        IL_01e6:  sub
        IL_01e7:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IList`1<string>::get_Item(int32)
        IL_01ec:  ldstr      "DESIGN-SPEC"
        IL_01f1:  ldc.i4.1
        IL_01f2:  ldc.i4.1
        IL_01f3:  ldc.i4.0
        IL_01f4:  ldc.i4.0
        IL_01f5:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::AppendRowInformation(class [System.Xml.Linq]System.Xml.Linq.XElement,
                                                                                                                   class [System.Xml.Linq]System.Xml.Linq.XDocument,
                                                                                                                   string,
                                                                                                                   string,
                                                                                                                   bool,
                                                                                                                   bool,
                                                                                                                   bool,
                                                                                                                   bool)
        IL_01fa:  br.s       IL_0247

        IL_01fc:  ldloc.s    V_16
        IL_01fe:  ldc.i4.3
        IL_01ff:  bne.un.s   IL_0221

        IL_0201:  ldloc.s    V_11
        IL_0203:  ldloc.s    V_10
        IL_0205:  ldarg.2
        IL_0206:  ldloc.s    V_14
        IL_0208:  ldloc.2
        IL_0209:  sub
        IL_020a:  ldloc.3
        IL_020b:  sub
        IL_020c:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IList`1<string>::get_Item(int32)
        IL_0211:  ldstr      "Utilities"
        IL_0216:  ldc.i4.1
        IL_0217:  ldc.i4.0
        IL_0218:  ldc.i4.1
        IL_0219:  ldc.i4.0
        IL_021a:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::AppendRowInformation(class [System.Xml.Linq]System.Xml.Linq.XElement,
                                                                                                                   class [System.Xml.Linq]System.Xml.Linq.XDocument,
                                                                                                                   string,
                                                                                                                   string,
                                                                                                                   bool,
                                                                                                                   bool,
                                                                                                                   bool,
                                                                                                                   bool)
        IL_021f:  br.s       IL_0247

        IL_0221:  ldloc.s    V_16
        IL_0223:  ldc.i4.4
        IL_0224:  bne.un.s   IL_0247

        IL_0226:  ldloc.s    V_11
        IL_0228:  ldloc.s    V_10
        IL_022a:  ldarg.3
        IL_022b:  ldloc.s    V_14
        IL_022d:  ldloc.2
        IL_022e:  sub
        IL_022f:  ldloc.3
        IL_0230:  sub
        IL_0231:  ldloc.s    V_4
        IL_0233:  sub
        IL_0234:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IList`1<string>::get_Item(int32)
        IL_0239:  ldstr      "STREAM-PRICE"
        IL_023e:  ldc.i4.1
        IL_023f:  ldc.i4.0
        IL_0240:  ldc.i4.0
        IL_0241:  ldc.i4.1
        IL_0242:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::AppendRowInformation(class [System.Xml.Linq]System.Xml.Linq.XElement,
                                                                                                                   class [System.Xml.Linq]System.Xml.Linq.XDocument,
                                                                                                                   string,
                                                                                                                   string,
                                                                                                                   bool,
                                                                                                                   bool,
                                                                                                                   bool,
                                                                                                                   bool)
        IL_0247:  ldloc.s    V_14
        IL_0249:  ldc.i4.1
        IL_024a:  add
        IL_024b:  stloc.s    V_14
        IL_024d:  ldloc.s    V_14
        IL_024f:  ldloc.2
        IL_0250:  ldloc.3
        IL_0251:  add
        IL_0252:  ldloc.s    V_4
        IL_0254:  add
        IL_0255:  ldloc.s    V_5
        IL_0257:  add
        IL_0258:  blt        IL_00e0

        IL_025d:  ldloc.s    V_12
        IL_025f:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
        IL_0264:  brtrue     IL_00bb

        IL_0269:  leave.s    IL_0277

      }  // end .try
      finally
      {
        IL_026b:  ldloc.s    V_12
        IL_026d:  brfalse.s  IL_0276

        IL_026f:  ldloc.s    V_12
        IL_0271:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
        IL_0276:  endfinally
      }  // end handler
      IL_0277:  ldloc.s    V_6
      IL_0279:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_027e:  brtrue     IL_004d

      IL_0283:  leave.s    IL_0291

    }  // end .try
    finally
    {
      IL_0285:  ldloc.s    V_6
      IL_0287:  brfalse.s  IL_0290

      IL_0289:  ldloc.s    V_6
      IL_028b:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0290:  endfinally
    }  // end handler
    IL_0291:  ldloc.0
    IL_0292:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_0297:  ret
  } // end of method BlockSummaryHelper::BuildBlockSummaryString

  .method private hidebysig static void  CreateEEUnitOpTab(class [System.Xml.Linq]System.Xml.Linq.XElement parent) cil managed
  {
    // Code size       912 (0x390)
    .maxstack  6
    .locals init (class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop V_0,
             class [AspenDataShareCS]AspenTech.Adb.Acs.AcsTopRecord V_1,
             string V_2,
             string V_3,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_4,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_5,
             string[] V_6,
             string[] V_7,
             int32 V_8,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_9,
             class [AspenDataShareCS]AspenTech.Adb.Acs.AcsFlowsheet V_10,
             int32 V_11,
             int32 V_12,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_13,
             int32 V_14,
             class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock V_15,
             string V_16,
             class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock V_17,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_18,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_19,
             string V_20,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_21)
    IL_0000:  call       class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.MmgSor::GetActiveDocAdbTop()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  brtrue.s   IL_000a

    IL_0009:  ret

    IL_000a:  ldloc.0
    IL_000b:  newobj     instance void [AspenDataShareCS]AspenTech.Adb.Acs.AcsTopRecord::.ctor(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_0010:  stloc.1
    IL_0011:  ldloc.1
    IL_0012:  brtrue.s   IL_0015

    IL_0014:  ret

    IL_0015:  ldloc.1
    IL_0016:  callvirt   instance string [AspenDataShareCS]AspenTech.Adb.Acs.AcsTopRecord::get_EEProjectCurrency()
    IL_001b:  stloc.2
    IL_001c:  ldloc.1
    IL_001d:  callvirt   instance string [AspenDataShareCS]AspenTech.Adb.Acs.AcsTopRecord::get_EEWeightUnits()
    IL_0022:  stloc.3
    IL_0023:  ldstr      "Tab"
    IL_0028:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_002d:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_0032:  stloc.s    V_4
    IL_0034:  ldarg.0
    IL_0035:  ldloc.s    V_4
    IL_0037:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_003c:  ldloc.s    V_4
    IL_003e:  ldstr      "UseProvidedRowInfo"
    IL_0043:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0048:  ldstr      "True"
    IL_004d:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0052:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0057:  ldloc.s    V_4
    IL_0059:  ldstr      "Caption"
    IL_005e:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0063:  ldstr      "UnitOps Chart"
    IL_0068:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_006d:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0072:  ldloc.s    V_4
    IL_0074:  ldstr      "Horizontal"
    IL_0079:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_007e:  ldstr      "False"
    IL_0083:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0088:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_008d:  ldstr      "Columns"
    IL_0092:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0097:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_009c:  stloc.s    V_5
    IL_009e:  ldloc.s    V_4
    IL_00a0:  ldloc.s    V_5
    IL_00a2:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_00a7:  ldc.i4.5
    IL_00a8:  newarr     [mscorlib]System.String
    IL_00ad:  dup
    IL_00ae:  ldc.i4.0
    IL_00af:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_EquipmentCost()
    IL_00b4:  stelem.ref
    IL_00b5:  dup
    IL_00b6:  ldc.i4.1
    IL_00b7:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_InstalledCost()
    IL_00bc:  stelem.ref
    IL_00bd:  dup
    IL_00be:  ldc.i4.2
    IL_00bf:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_Weight()
    IL_00c4:  stelem.ref
    IL_00c5:  dup
    IL_00c6:  ldc.i4.3
    IL_00c7:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_InstalledWeight()
    IL_00cc:  stelem.ref
    IL_00cd:  dup
    IL_00ce:  ldc.i4.4
    IL_00cf:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_UtilityCost()
    IL_00d4:  stelem.ref
    IL_00d5:  stloc.s    V_6
    IL_00d7:  ldc.i4.5
    IL_00d8:  newarr     [mscorlib]System.String
    IL_00dd:  dup
    IL_00de:  ldc.i4.0
    IL_00df:  ldstr      "EquipmentCost"
    IL_00e4:  stelem.ref
    IL_00e5:  dup
    IL_00e6:  ldc.i4.1
    IL_00e7:  ldstr      "InstalledCost"
    IL_00ec:  stelem.ref
    IL_00ed:  dup
    IL_00ee:  ldc.i4.2
    IL_00ef:  ldstr      "Weight"
    IL_00f4:  stelem.ref
    IL_00f5:  dup
    IL_00f6:  ldc.i4.3
    IL_00f7:  ldstr      "InstalledWeight"
    IL_00fc:  stelem.ref
    IL_00fd:  dup
    IL_00fe:  ldc.i4.4
    IL_00ff:  ldstr      "UtilityCost"
    IL_0104:  stelem.ref
    IL_0105:  stloc.s    V_7
    IL_0107:  ldloc.s    V_6
    IL_0109:  ldlen
    IL_010a:  conv.i4
    IL_010b:  stloc.s    V_8
    IL_010d:  ldc.i4.0
    IL_010e:  stloc.s    V_12
    IL_0110:  br         IL_0295

    IL_0115:  ldstr      "Column"
    IL_011a:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_011f:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_0124:  stloc.s    V_13
    IL_0126:  ldloc.s    V_13
    IL_0128:  ldstr      "Attribute"
    IL_012d:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0132:  ldstr      "Value"
    IL_0137:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_013c:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0141:  ldloc.s    V_13
    IL_0143:  ldstr      "ReadOnly"
    IL_0148:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_014d:  ldstr      "True"
    IL_0152:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0157:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_015c:  ldloc.s    V_13
    IL_015e:  ldstr      "DataType"
    IL_0163:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0168:  ldstr      "String"
    IL_016d:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0172:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0177:  ldloc.s    V_13
    IL_0179:  ldstr      "Name"
    IL_017e:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0183:  ldstr      "Column{0}"
    IL_0188:  ldloca.s   V_12
    IL_018a:  call       instance string [mscorlib]System.Int32::ToString()
    IL_018f:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_0194:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0199:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_019e:  ldloc.2
    IL_019f:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_01a4:  brfalse.s  IL_01c6

    IL_01a6:  ldloc.s    V_13
    IL_01a8:  ldstr      "Caption"
    IL_01ad:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_01b2:  ldloc.s    V_6
    IL_01b4:  ldloc.s    V_12
    IL_01b6:  ldelem.ref
    IL_01b7:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_01bc:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_01c1:  br         IL_026b

    IL_01c6:  ldloc.s    V_12
    IL_01c8:  switch     ( 
                          IL_01e6,
                          IL_01e6,
                          IL_0213,
                          IL_0213,
                          IL_0240)
    IL_01e1:  br         IL_026b

    IL_01e6:  ldloc.s    V_13
    IL_01e8:  ldstr      "Caption"
    IL_01ed:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_01f2:  ldloc.s    V_6
    IL_01f4:  ldloc.s    V_12
    IL_01f6:  ldelem.ref
    IL_01f7:  ldstr      " ["
    IL_01fc:  ldloc.2
    IL_01fd:  ldstr      " ]"
    IL_0202:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string,
                                                                string)
    IL_0207:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_020c:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0211:  br.s       IL_026b

    IL_0213:  ldloc.s    V_13
    IL_0215:  ldstr      "Caption"
    IL_021a:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_021f:  ldloc.s    V_6
    IL_0221:  ldloc.s    V_12
    IL_0223:  ldelem.ref
    IL_0224:  ldstr      " ["
    IL_0229:  ldloc.3
    IL_022a:  ldstr      " ]"
    IL_022f:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string,
                                                                string)
    IL_0234:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0239:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_023e:  br.s       IL_026b

    IL_0240:  ldloc.s    V_13
    IL_0242:  ldstr      "Caption"
    IL_0247:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_024c:  ldloc.s    V_6
    IL_024e:  ldloc.s    V_12
    IL_0250:  ldelem.ref
    IL_0251:  ldstr      " ["
    IL_0256:  ldloc.2
    IL_0257:  ldstr      "/HR ]"
    IL_025c:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string,
                                                                string)
    IL_0261:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0266:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_026b:  ldloc.s    V_13
    IL_026d:  ldstr      "Path"
    IL_0272:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0277:  ldloc.s    V_7
    IL_0279:  ldloc.s    V_12
    IL_027b:  ldelem.ref
    IL_027c:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0281:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0286:  ldloc.s    V_5
    IL_0288:  ldloc.s    V_13
    IL_028a:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_028f:  ldloc.s    V_12
    IL_0291:  ldc.i4.1
    IL_0292:  add
    IL_0293:  stloc.s    V_12
    IL_0295:  ldloc.s    V_12
    IL_0297:  ldloc.s    V_8
    IL_0299:  blt        IL_0115

    IL_029e:  ldstr      "Rows"
    IL_02a3:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_02a8:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_02ad:  stloc.s    V_9
    IL_02af:  ldloc.s    V_4
    IL_02b1:  ldloc.s    V_9
    IL_02b3:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_02b8:  ldloc.1
    IL_02b9:  callvirt   instance class [AspenDataShareCS]AspenTech.Adb.Acs.AcsFlowsheet [AspenDataShareCS]AspenTech.Adb.Acs.AcsTopRecord::get_Flowsheet()
    IL_02be:  stloc.s    V_10
    IL_02c0:  ldloc.s    V_10
    IL_02c2:  ldfld      class [AspenDataShareCS]AspenTech.Adb.Acs.ReferenceArray`2<string,class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock> [AspenDataShareCS]AspenTech.Adb.Acs.AcsFlowsheet::Blocks
    IL_02c7:  callvirt   instance int32 [AspenDataShareCS]AspenTech.Adb.Acs.AcsArrayBase::get_Length()
    IL_02cc:  stloc.s    V_11
    IL_02ce:  ldc.i4.0
    IL_02cf:  stloc.s    V_14
    IL_02d1:  br         IL_0386

    IL_02d6:  ldloc.s    V_10
    IL_02d8:  ldfld      class [AspenDataShareCS]AspenTech.Adb.Acs.ReferenceArray`2<string,class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock> [AspenDataShareCS]AspenTech.Adb.Acs.AcsFlowsheet::Blocks
    IL_02dd:  ldloc.s    V_14
    IL_02df:  callvirt   instance !1 class [AspenDataShareCS]AspenTech.Adb.Acs.ReferenceArray`2<string,class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock>::ValueAtLocation(int32)
    IL_02e4:  stloc.s    V_15
    IL_02e6:  ldloc.s    V_15
    IL_02e8:  callvirt   instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbRecord [AspenDataShareCS]AspenTech.Adb.Acs.AcsBaseRecord::get_Record()
    IL_02ed:  brfalse    IL_0380

    IL_02f2:  ldstr      "Top.appModel.SharedData.Flowsheet.Blocks"
    IL_02f7:  stloc.s    V_16
    IL_02f9:  ldloc.s    V_15
    IL_02fb:  callvirt   instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbRecord [AspenDataShareCS]AspenTech.Adb.Acs.AcsBaseRecord::get_Record()
    IL_0300:  newobj     instance void [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock::.ctor(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbRecord)
    IL_0305:  stloc.s    V_17
    IL_0307:  ldloc.s    V_9
    IL_0309:  ldloc.s    V_17
    IL_030b:  ldloc.s    V_16
    IL_030d:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::ReadEEHierarchyData(class [System.Xml.Linq]System.Xml.Linq.XElement,
                                                                                                              class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBaseRecord,
                                                                                                              string)
    IL_0312:  brtrue.s   IL_0380

    IL_0314:  ldstr      "Row"
    IL_0319:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_031e:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_0323:  stloc.s    V_18
    IL_0325:  ldstr      "Name"
    IL_032a:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_032f:  ldloc.s    V_15
    IL_0331:  callvirt   instance string [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock::get_ID()
    IL_0336:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_033b:  stloc.s    V_19
    IL_033d:  ldstr      "{0}.{1}"
    IL_0342:  ldloc.s    V_16
    IL_0344:  ldloc.s    V_15
    IL_0346:  callvirt   instance string [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock::get_ID()
    IL_034b:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_0350:  stloc.s    V_20
    IL_0352:  ldstr      "Path"
    IL_0357:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_035c:  ldloc.s    V_20
    IL_035e:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0363:  stloc.s    V_21
    IL_0365:  ldloc.s    V_18
    IL_0367:  ldloc.s    V_19
    IL_0369:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_036e:  ldloc.s    V_18
    IL_0370:  ldloc.s    V_21
    IL_0372:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0377:  ldloc.s    V_9
    IL_0379:  ldloc.s    V_18
    IL_037b:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0380:  ldloc.s    V_14
    IL_0382:  ldc.i4.1
    IL_0383:  add
    IL_0384:  stloc.s    V_14
    IL_0386:  ldloc.s    V_14
    IL_0388:  ldloc.s    V_11
    IL_038a:  blt        IL_02d6

    IL_038f:  ret
  } // end of method BlockSummaryHelper::CreateEEUnitOpTab

  .method private hidebysig static bool  ReadEEHierarchyData(class [System.Xml.Linq]System.Xml.Linq.XElement parentElement,
                                                             class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBaseRecord acsrecord,
                                                             string sParentPath) cil managed
  {
    // Code size       286 (0x11e)
    .maxstack  3
    .locals init (class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock V_0,
             class [AspenDataShareCS]AspenTech.Adb.Acs.AcsFlowsheet V_1,
             int32 V_2,
             string V_3,
             string V_4,
             int32 V_5,
             class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock V_6,
             class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock V_7,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_8,
             string V_9,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_10,
             string V_11,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_12)
    IL_0000:  ldarg.1
    IL_0001:  isinst     [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  ldfld      class [AspenDataShareCS]AspenTech.Adb.Acs.ReferenceArray`2<string,class [AspenDataShareCS]AspenTech.Adb.Acs.AcsFlowsheet> [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock::SubFlowsheets
    IL_000d:  ldstr      "Simulation"
    IL_0012:  callvirt   instance !1 class [AspenDataShareCS]AspenTech.Adb.Acs.ReferenceArray`2<string,class [AspenDataShareCS]AspenTech.Adb.Acs.AcsFlowsheet>::ValueAt(!0)
    IL_0017:  stloc.1
    IL_0018:  ldloc.1
    IL_0019:  callvirt   instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbRecord [AspenDataShareCS]AspenTech.Adb.Acs.AcsBaseRecord::get_Record()
    IL_001e:  brtrue.s   IL_0022

    IL_0020:  ldc.i4.0
    IL_0021:  ret

    IL_0022:  ldloc.1
    IL_0023:  ldfld      class [AspenDataShareCS]AspenTech.Adb.Acs.ReferenceArray`2<string,class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock> [AspenDataShareCS]AspenTech.Adb.Acs.AcsFlowsheet::Blocks
    IL_0028:  callvirt   instance int32 [AspenDataShareCS]AspenTech.Adb.Acs.AcsArrayBase::get_Length()
    IL_002d:  stloc.2
    IL_002e:  ldloc.2
    IL_002f:  brtrue.s   IL_0033

    IL_0031:  ldc.i4.0
    IL_0032:  ret

    IL_0033:  ldloc.0
    IL_0034:  callvirt   instance string [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock::get_ID()
    IL_0039:  stloc.3
    IL_003a:  ldstr      "{0}.{1}.Subflowsheets.Simulation.Blocks"
    IL_003f:  ldarg.2
    IL_0040:  ldloc.3
    IL_0041:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_0046:  stloc.s    V_4
    IL_0048:  ldc.i4.0
    IL_0049:  stloc.s    V_5
    IL_004b:  br         IL_0114

    IL_0050:  ldloc.1
    IL_0051:  ldfld      class [AspenDataShareCS]AspenTech.Adb.Acs.ReferenceArray`2<string,class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock> [AspenDataShareCS]AspenTech.Adb.Acs.AcsFlowsheet::Blocks
    IL_0056:  ldloc.s    V_5
    IL_0058:  callvirt   instance !1 class [AspenDataShareCS]AspenTech.Adb.Acs.ReferenceArray`2<string,class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock>::ValueAtLocation(int32)
    IL_005d:  stloc.s    V_6
    IL_005f:  ldloc.s    V_6
    IL_0061:  callvirt   instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbRecord [AspenDataShareCS]AspenTech.Adb.Acs.AcsBaseRecord::get_Record()
    IL_0066:  brfalse    IL_010e

    IL_006b:  ldloc.s    V_6
    IL_006d:  callvirt   instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbRecord [AspenDataShareCS]AspenTech.Adb.Acs.AcsBaseRecord::get_Record()
    IL_0072:  newobj     instance void [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock::.ctor(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbRecord)
    IL_0077:  stloc.s    V_7
    IL_0079:  ldarg.0
    IL_007a:  ldloc.s    V_7
    IL_007c:  ldloc.s    V_4
    IL_007e:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::ReadEEHierarchyData(class [System.Xml.Linq]System.Xml.Linq.XElement,
                                                                                                              class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBaseRecord,
                                                                                                              string)
    IL_0083:  brtrue     IL_010e

    IL_0088:  ldstr      "Row"
    IL_008d:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0092:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_0097:  stloc.s    V_8
    IL_0099:  ldloc.s    V_6
    IL_009b:  callvirt   instance string [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock::get_ID()
    IL_00a0:  stloc.s    V_9
    IL_00a2:  ldloc.3
    IL_00a3:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_00a8:  brtrue.s   IL_00b9

    IL_00aa:  ldloc.3
    IL_00ab:  ldstr      "."
    IL_00b0:  ldloc.s    V_9
    IL_00b2:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_00b7:  stloc.s    V_9
    IL_00b9:  ldstr      "Name"
    IL_00be:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_00c3:  ldloc.s    V_9
    IL_00c5:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_00ca:  stloc.s    V_10
    IL_00cc:  ldstr      "{0}.{1}"
    IL_00d1:  ldloc.s    V_4
    IL_00d3:  ldloc.s    V_6
    IL_00d5:  callvirt   instance string [AspenDataShareCS]AspenTech.Adb.Acs.AcsBlock::get_ID()
    IL_00da:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_00df:  stloc.s    V_11
    IL_00e1:  ldstr      "Path"
    IL_00e6:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_00eb:  ldloc.s    V_11
    IL_00ed:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_00f2:  stloc.s    V_12
    IL_00f4:  ldloc.s    V_8
    IL_00f6:  ldloc.s    V_10
    IL_00f8:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_00fd:  ldloc.s    V_8
    IL_00ff:  ldloc.s    V_12
    IL_0101:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0106:  ldarg.0
    IL_0107:  ldloc.s    V_8
    IL_0109:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_010e:  ldloc.s    V_5
    IL_0110:  ldc.i4.1
    IL_0111:  add
    IL_0112:  stloc.s    V_5
    IL_0114:  ldloc.s    V_5
    IL_0116:  ldloc.2
    IL_0117:  blt        IL_0050

    IL_011c:  ldc.i4.1
    IL_011d:  ret
  } // end of method BlockSummaryHelper::ReadEEHierarchyData

  .method private hidebysig static void  CheckBlockTypes(class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>> blocks,
                                                         class [mscorlib]System.Collections.Generic.IList`1<string> designSpecs,
                                                         class [mscorlib]System.Collections.Generic.IList`1<string> utilities,
                                                         class [mscorlib]System.Collections.Generic.IList`1<string> streamsWithPricing,
                                                         class [System.Xml.Linq]System.Xml.Linq.XElement definitionRootElement,
                                                         [out] bool& isBlock,
                                                         [out] bool& isDesignSpec,
                                                         [out] bool& isUtility,
                                                         [out] bool& isStreamWithPricing) cil managed
  {
    // Code size       550 (0x226)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             int32 V_2,
             int32 V_3,
             bool V_4,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_5,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_6,
             string V_7,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_8,
             string V_9,
             int32 V_10,
             bool V_11,
             int32 V_12,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string> V_13)
    IL_0000:  ldarg.s    isBlock
    IL_0002:  ldarg.s    isDesignSpec
    IL_0004:  ldarg.s    isUtility
    IL_0006:  ldarg.s    isStreamWithPricing
    IL_0008:  ldc.i4.0
    IL_0009:  dup
    IL_000a:  stloc.s    V_4
    IL_000c:  stind.i1
    IL_000d:  ldloc.s    V_4
    IL_000f:  dup
    IL_0010:  stloc.s    V_4
    IL_0012:  stind.i1
    IL_0013:  ldloc.s    V_4
    IL_0015:  dup
    IL_0016:  stloc.s    V_4
    IL_0018:  stind.i1
    IL_0019:  ldloc.s    V_4
    IL_001b:  stind.i1
    IL_001c:  ldarg.0
    IL_001d:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.ICollection`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::get_Count()
    IL_0022:  stloc.0
    IL_0023:  ldarg.1
    IL_0024:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.ICollection`1<string>::get_Count()
    IL_0029:  stloc.1
    IL_002a:  ldarg.2
    IL_002b:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.ICollection`1<string>::get_Count()
    IL_0030:  stloc.2
    IL_0031:  ldarg.3
    IL_0032:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.ICollection`1<string>::get_Count()
    IL_0037:  stloc.3
    IL_0038:  ldarg.s    definitionRootElement
    IL_003a:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.Linq.XContainer::Elements()
    IL_003f:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::GetEnumerator()
    IL_0044:  stloc.s    V_5
    .try
    {
      IL_0046:  br         IL_020b

      IL_004b:  ldloc.s    V_5
      IL_004d:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::get_Current()
      IL_0052:  stloc.s    V_6
      IL_0054:  ldloc.s    V_6
      IL_0056:  ldstr      "File"
      IL_005b:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_0060:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XAttribute [System.Xml.Linq]System.Xml.Linq.XElement::Attribute(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_0065:  call       string [System.Xml.Linq]System.Xml.Linq.XAttribute::op_Explicit(class [System.Xml.Linq]System.Xml.Linq.XAttribute)
      IL_006a:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
      IL_006f:  brtrue     IL_020b

      IL_0074:  ldloc.s    V_6
      IL_0076:  ldstr      "Type"
      IL_007b:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_0080:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XAttribute [System.Xml.Linq]System.Xml.Linq.XElement::Attribute(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_0085:  call       string [System.Xml.Linq]System.Xml.Linq.XAttribute::op_Explicit(class [System.Xml.Linq]System.Xml.Linq.XAttribute)
      IL_008a:  stloc.s    V_7
      IL_008c:  ldloc.s    V_6
      IL_008e:  ldstr      "ids/id"
      IL_0093:  call       class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.XPath.Extensions::XPathSelectElements(class [System.Xml.Linq]System.Xml.Linq.XNode,
                                                                                                                                                                                                       string)
      IL_0098:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::GetEnumerator()
      IL_009d:  stloc.s    V_8
      .try
      {
        IL_009f:  br         IL_01f1

        IL_00a4:  ldloc.s    V_8
        IL_00a6:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::get_Current()
        IL_00ab:  ldstr      "Name"
        IL_00b0:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
        IL_00b5:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XAttribute [System.Xml.Linq]System.Xml.Linq.XElement::Attribute(class [System.Xml.Linq]System.Xml.Linq.XName)
        IL_00ba:  call       string [System.Xml.Linq]System.Xml.Linq.XAttribute::op_Explicit(class [System.Xml.Linq]System.Xml.Linq.XAttribute)
        IL_00bf:  stloc.s    V_9
        IL_00c1:  ldc.i4.0
        IL_00c2:  stloc.s    V_10
        IL_00c4:  br         IL_01e3

        IL_00c9:  ldc.i4.0
        IL_00ca:  stloc.s    V_11
        IL_00cc:  ldc.i4.0
        IL_00cd:  stloc.s    V_12
        IL_00cf:  ldloc.s    V_10
        IL_00d1:  ldloc.0
        IL_00d2:  bge.s      IL_00f6

        IL_00d4:  ldarg.0
        IL_00d5:  ldloc.s    V_10
        IL_00d7:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::get_Item(int32)
        IL_00dc:  stloc.s    V_13
        IL_00de:  ldloca.s   V_13
        IL_00e0:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>::get_Value()
        IL_00e5:  ldloc.s    V_9
        IL_00e7:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_00ec:  brfalse.s  IL_00f6

        IL_00ee:  ldc.i4.1
        IL_00ef:  stloc.s    V_11
        IL_00f1:  ldc.i4.1
        IL_00f2:  stloc.s    V_12
        IL_00f4:  br.s       IL_016f

        IL_00f6:  ldloc.s    V_10
        IL_00f8:  ldloc.0
        IL_00f9:  blt.s      IL_0126

        IL_00fb:  ldloc.s    V_10
        IL_00fd:  ldloc.0
        IL_00fe:  ldloc.1
        IL_00ff:  add
        IL_0100:  bge.s      IL_0126

        IL_0102:  ldstr      "DESIGN-SPEC"
        IL_0107:  ldloc.s    V_9
        IL_0109:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_010e:  brtrue.s   IL_011e

        IL_0110:  ldstr      "Design Specs"
        IL_0115:  ldloc.s    V_9
        IL_0117:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_011c:  brfalse.s  IL_0126

        IL_011e:  ldc.i4.1
        IL_011f:  stloc.s    V_11
        IL_0121:  ldc.i4.2
        IL_0122:  stloc.s    V_12
        IL_0124:  br.s       IL_016f

        IL_0126:  ldloc.s    V_10
        IL_0128:  ldloc.0
        IL_0129:  ldloc.1
        IL_012a:  add
        IL_012b:  blt.s      IL_0147

        IL_012d:  ldloc.s    V_10
        IL_012f:  ldloc.0
        IL_0130:  ldloc.1
        IL_0131:  add
        IL_0132:  ldloc.2
        IL_0133:  add
        IL_0134:  bge.s      IL_0147

        IL_0136:  ldloc.s    V_9
        IL_0138:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::IsUtilityBlockType(string)
        IL_013d:  brfalse.s  IL_0147

        IL_013f:  ldc.i4.1
        IL_0140:  stloc.s    V_11
        IL_0142:  ldc.i4.3
        IL_0143:  stloc.s    V_12
        IL_0145:  br.s       IL_016f

        IL_0147:  ldloc.s    V_10
        IL_0149:  ldloc.0
        IL_014a:  ldloc.1
        IL_014b:  add
        IL_014c:  ldloc.2
        IL_014d:  add
        IL_014e:  blt.s      IL_016f

        IL_0150:  ldloc.s    V_10
        IL_0152:  ldloc.0
        IL_0153:  ldloc.1
        IL_0154:  add
        IL_0155:  ldloc.2
        IL_0156:  add
        IL_0157:  ldloc.3
        IL_0158:  add
        IL_0159:  bge.s      IL_016f

        IL_015b:  ldstr      "STREAM-PRICE"
        IL_0160:  ldloc.s    V_9
        IL_0162:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_0167:  brfalse.s  IL_016f

        IL_0169:  ldc.i4.1
        IL_016a:  stloc.s    V_11
        IL_016c:  ldc.i4.4
        IL_016d:  stloc.s    V_12
        IL_016f:  ldloc.s    V_11
        IL_0171:  brfalse.s  IL_01dd

        IL_0173:  ldloc.s    V_12
        IL_0175:  ldc.i4.1
        IL_0176:  bne.un.s   IL_0198

        IL_0178:  ldarg.s    isBlock
        IL_017a:  ldloc.s    V_7
        IL_017c:  ldstr      "Block"
        IL_0181:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_0186:  stind.i1
        IL_0187:  ldarg.s    isDesignSpec
        IL_0189:  ldc.i4.0
        IL_018a:  stind.i1
        IL_018b:  ldarg.s    isUtility
        IL_018d:  ldc.i4.0
        IL_018e:  stind.i1
        IL_018f:  ldarg.s    isStreamWithPricing
        IL_0191:  ldc.i4.0
        IL_0192:  stind.i1
        IL_0193:  leave      IL_0225

        IL_0198:  ldloc.s    V_12
        IL_019a:  ldc.i4.2
        IL_019b:  bne.un.s   IL_01af

        IL_019d:  ldarg.s    isBlock
        IL_019f:  ldc.i4.1
        IL_01a0:  stind.i1
        IL_01a1:  ldarg.s    isDesignSpec
        IL_01a3:  ldc.i4.1
        IL_01a4:  stind.i1
        IL_01a5:  ldarg.s    isUtility
        IL_01a7:  ldc.i4.0
        IL_01a8:  stind.i1
        IL_01a9:  ldarg.s    isStreamWithPricing
        IL_01ab:  ldc.i4.0
        IL_01ac:  stind.i1
        IL_01ad:  leave.s    IL_0225

        IL_01af:  ldloc.s    V_12
        IL_01b1:  ldc.i4.3
        IL_01b2:  bne.un.s   IL_01c6

        IL_01b4:  ldarg.s    isBlock
        IL_01b6:  ldc.i4.1
        IL_01b7:  stind.i1
        IL_01b8:  ldarg.s    isDesignSpec
        IL_01ba:  ldc.i4.0
        IL_01bb:  stind.i1
        IL_01bc:  ldarg.s    isUtility
        IL_01be:  ldc.i4.1
        IL_01bf:  stind.i1
        IL_01c0:  ldarg.s    isStreamWithPricing
        IL_01c2:  ldc.i4.0
        IL_01c3:  stind.i1
        IL_01c4:  leave.s    IL_0225

        IL_01c6:  ldloc.s    V_12
        IL_01c8:  ldc.i4.4
        IL_01c9:  bne.un.s   IL_01dd

        IL_01cb:  ldarg.s    isBlock
        IL_01cd:  ldc.i4.1
        IL_01ce:  stind.i1
        IL_01cf:  ldarg.s    isDesignSpec
        IL_01d1:  ldc.i4.0
        IL_01d2:  stind.i1
        IL_01d3:  ldarg.s    isUtility
        IL_01d5:  ldc.i4.0
        IL_01d6:  stind.i1
        IL_01d7:  ldarg.s    isStreamWithPricing
        IL_01d9:  ldc.i4.1
        IL_01da:  stind.i1
        IL_01db:  leave.s    IL_0225

        IL_01dd:  ldloc.s    V_10
        IL_01df:  ldc.i4.1
        IL_01e0:  add
        IL_01e1:  stloc.s    V_10
        IL_01e3:  ldloc.s    V_10
        IL_01e5:  ldloc.0
        IL_01e6:  ldloc.1
        IL_01e7:  add
        IL_01e8:  ldloc.2
        IL_01e9:  add
        IL_01ea:  ldloc.3
        IL_01eb:  add
        IL_01ec:  blt        IL_00c9

        IL_01f1:  ldloc.s    V_8
        IL_01f3:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
        IL_01f8:  brtrue     IL_00a4

        IL_01fd:  leave.s    IL_020b

      }  // end .try
      finally
      {
        IL_01ff:  ldloc.s    V_8
        IL_0201:  brfalse.s  IL_020a

        IL_0203:  ldloc.s    V_8
        IL_0205:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
        IL_020a:  endfinally
      }  // end handler
      IL_020b:  ldloc.s    V_5
      IL_020d:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_0212:  brtrue     IL_004b

      IL_0217:  leave.s    IL_0225

    }  // end .try
    finally
    {
      IL_0219:  ldloc.s    V_5
      IL_021b:  brfalse.s  IL_0224

      IL_021d:  ldloc.s    V_5
      IL_021f:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0224:  endfinally
    }  // end handler
    IL_0225:  ret
  } // end of method BlockSummaryHelper::CheckBlockTypes

  .method private hidebysig static class [System.Xml.Linq]System.Xml.Linq.XElement 
          CreateTabElement(class [System.Xml.Linq]System.Xml.Linq.XDocument gsDoc) cil managed
  {
    // Code size       589 (0x24d)
    .maxstack  4
    .locals init (class [System.Xml.Linq]System.Xml.Linq.XElement V_0,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_1,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_2,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_3,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_4,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_5,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_6,
             string V_7,
             string V_8)
    IL_0000:  ldstr      "Tab"
    IL_0005:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_000a:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_000f:  stloc.0
    IL_0010:  ldarg.0
    IL_0011:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XDocument::get_Root()
    IL_0016:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XNode [System.Xml.Linq]System.Xml.Linq.XContainer::get_FirstNode()
    IL_001b:  isinst     [System.Xml.Linq]System.Xml.Linq.XElement
    IL_0020:  stloc.1
    IL_0021:  ldloc.0
    IL_0022:  ldstr      "Caption"
    IL_0027:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_002c:  ldloc.1
    IL_002d:  ldstr      "Caption"
    IL_0032:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0037:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XAttribute [System.Xml.Linq]System.Xml.Linq.XElement::Attribute(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_003c:  call       string [System.Xml.Linq]System.Xml.Linq.XAttribute::op_Explicit(class [System.Xml.Linq]System.Xml.Linq.XAttribute)
    IL_0041:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0046:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_004b:  ldstr      "Columns"
    IL_0050:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0055:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_005a:  stloc.2
    IL_005b:  ldloc.0
    IL_005c:  ldloc.2
    IL_005d:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0062:  ldloc.1
    IL_0063:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XNode [System.Xml.Linq]System.Xml.Linq.XContainer::get_FirstNode()
    IL_0068:  isinst     [System.Xml.Linq]System.Xml.Linq.XElement
    IL_006d:  stloc.3
    IL_006e:  ldloc.3
    IL_006f:  brfalse    IL_0236

    IL_0074:  ldloc.3
    IL_0075:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.Linq.XContainer::Elements()
    IL_007a:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::GetEnumerator()
    IL_007f:  stloc.s    V_4
    .try
    {
      IL_0081:  br         IL_021c

      IL_0086:  ldloc.s    V_4
      IL_0088:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::get_Current()
      IL_008d:  ldstr      "Column"
      IL_0092:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_0097:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_009c:  stloc.s    V_5
      IL_009e:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.Linq.XContainer::Elements()
      IL_00a3:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::GetEnumerator()
      IL_00a8:  stloc.s    V_6
      .try
      {
        IL_00aa:  br         IL_01fa

        IL_00af:  ldloc.s    V_6
        IL_00b1:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::get_Current()
        IL_00b6:  dup
        IL_00b7:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XElement::get_Name()
        IL_00bc:  callvirt   instance string [System.Xml.Linq]System.Xml.Linq.XName::get_LocalName()
        IL_00c1:  stloc.s    V_7
        IL_00c3:  callvirt   instance string [System.Xml.Linq]System.Xml.Linq.XElement::get_Value()
        IL_00c8:  stloc.s    V_8
        IL_00ca:  ldloc.s    V_7
        IL_00cc:  ldstr      "Attribute"
        IL_00d1:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_00d6:  brfalse.s  IL_0106

        IL_00d8:  ldloc.s    V_8
        IL_00da:  ldstr      "Value"
        IL_00df:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_00e4:  brtrue     IL_01fa

        IL_00e9:  ldloc.s    V_5
        IL_00eb:  ldstr      "Attribute"
        IL_00f0:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
        IL_00f5:  ldloc.s    V_8
        IL_00f7:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                            object)
        IL_00fc:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
        IL_0101:  br         IL_01fa

        IL_0106:  ldloc.s    V_7
        IL_0108:  ldstr      "DisplayName"
        IL_010d:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_0112:  brfalse.s  IL_0131

        IL_0114:  ldloc.s    V_5
        IL_0116:  ldstr      "Caption"
        IL_011b:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
        IL_0120:  ldloc.s    V_8
        IL_0122:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                            object)
        IL_0127:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
        IL_012c:  br         IL_01fa

        IL_0131:  ldloc.s    V_7
        IL_0133:  ldstr      "DataType"
        IL_0138:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_013d:  brfalse.s  IL_015c

        IL_013f:  ldloc.s    V_5
        IL_0141:  ldstr      "DataType"
        IL_0146:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
        IL_014b:  ldloc.s    V_8
        IL_014d:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                            object)
        IL_0152:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
        IL_0157:  br         IL_01fa

        IL_015c:  ldloc.s    V_7
        IL_015e:  ldstr      "ReadOnly"
        IL_0163:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_0168:  brfalse.s  IL_0184

        IL_016a:  ldloc.s    V_5
        IL_016c:  ldstr      "ReadOnly"
        IL_0171:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
        IL_0176:  ldloc.s    V_8
        IL_0178:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                            object)
        IL_017d:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
        IL_0182:  br.s       IL_01fa

        IL_0184:  ldloc.s    V_7
        IL_0186:  ldstr      "InternalName"
        IL_018b:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_0190:  brfalse.s  IL_01ac

        IL_0192:  ldloc.s    V_5
        IL_0194:  ldstr      "Name"
        IL_0199:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
        IL_019e:  ldloc.s    V_8
        IL_01a0:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                            object)
        IL_01a5:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
        IL_01aa:  br.s       IL_01fa

        IL_01ac:  ldloc.s    V_7
        IL_01ae:  ldstr      "ASIPath"
        IL_01b3:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_01b8:  brfalse.s  IL_01d4

        IL_01ba:  ldloc.s    V_5
        IL_01bc:  ldstr      "Path"
        IL_01c1:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
        IL_01c6:  ldloc.s    V_8
        IL_01c8:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                            object)
        IL_01cd:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
        IL_01d2:  br.s       IL_01fa

        IL_01d4:  ldloc.s    V_7
        IL_01d6:  ldstr      "Path"
        IL_01db:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                              string)
        IL_01e0:  brfalse.s  IL_01fa

        IL_01e2:  ldloc.s    V_5
        IL_01e4:  ldstr      "Path"
        IL_01e9:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
        IL_01ee:  ldloc.s    V_8
        IL_01f0:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                            object)
        IL_01f5:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
        IL_01fa:  ldloc.s    V_6
        IL_01fc:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
        IL_0201:  brtrue     IL_00af

        IL_0206:  leave.s    IL_0214

      }  // end .try
      finally
      {
        IL_0208:  ldloc.s    V_6
        IL_020a:  brfalse.s  IL_0213

        IL_020c:  ldloc.s    V_6
        IL_020e:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
        IL_0213:  endfinally
      }  // end handler
      IL_0214:  ldloc.2
      IL_0215:  ldloc.s    V_5
      IL_0217:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
      IL_021c:  ldloc.s    V_4
      IL_021e:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_0223:  brtrue     IL_0086

      IL_0228:  leave.s    IL_0236

    }  // end .try
    finally
    {
      IL_022a:  ldloc.s    V_4
      IL_022c:  brfalse.s  IL_0235

      IL_022e:  ldloc.s    V_4
      IL_0230:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0235:  endfinally
    }  // end handler
    IL_0236:  ldloc.0
    IL_0237:  ldstr      "Rows"
    IL_023c:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0241:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_0246:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_024b:  ldloc.0
    IL_024c:  ret
  } // end of method BlockSummaryHelper::CreateTabElement

  .method private hidebysig static void  AppendRowInformation(class [System.Xml.Linq]System.Xml.Linq.XElement tabElement,
                                                              class [System.Xml.Linq]System.Xml.Linq.XDocument gsDoc,
                                                              string blockId,
                                                              string blockType,
                                                              bool isBlock,
                                                              bool isDesignSpec,
                                                              bool isUtility,
                                                              bool isStreamWithPricing) cil managed
  {
    // Code size       411 (0x19b)
    .maxstack  8
    .locals init (class [System.Xml.Linq]System.Xml.Linq.XElement V_0,
             string V_1,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_2,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_3,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_4,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_5,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_6,
             string V_7,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_8,
             string V_9)
    IL_0000:  ldstr      "Row"
    IL_0005:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_000a:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_000f:  stloc.0
    IL_0010:  ldarg.0
    IL_0011:  ldstr      "Rows"
    IL_0016:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_001b:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XContainer::Element(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_0020:  ldloc.0
    IL_0021:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0026:  ldloc.0
    IL_0027:  ldstr      "Name"
    IL_002c:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0031:  ldarg.2
    IL_0032:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_0037:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_003c:  ldarg.2
    IL_003d:  ldarg.s    isBlock
    IL_003f:  ldarg.s    isDesignSpec
    IL_0041:  ldarg.s    isUtility
    IL_0043:  ldarg.s    isStreamWithPricing
    IL_0045:  ldc.i4.0
    IL_0046:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::GetFullDataPath(string,
                                                                                                            bool,
                                                                                                            bool,
                                                                                                            bool,
                                                                                                            bool,
                                                                                                            bool)
    IL_004b:  stloc.1
    IL_004c:  ldloc.0
    IL_004d:  ldstr      "Path"
    IL_0052:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0057:  ldloc.1
    IL_0058:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                        object)
    IL_005d:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0062:  ldarg.s    isBlock
    IL_0064:  brtrue     IL_019a

    IL_0069:  ldstr      "ColumnOverrides"
    IL_006e:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
    IL_0073:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName)
    IL_0078:  stloc.2
    IL_0079:  ldloc.0
    IL_007a:  ldloc.2
    IL_007b:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
    IL_0080:  ldarg.1
    IL_0081:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XDocument::get_Root()
    IL_0086:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XNode [System.Xml.Linq]System.Xml.Linq.XContainer::get_FirstNode()
    IL_008b:  castclass  [System.Xml.Linq]System.Xml.Linq.XElement
    IL_0090:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XNode [System.Xml.Linq]System.Xml.Linq.XContainer::get_FirstNode()
    IL_0095:  isinst     [System.Xml.Linq]System.Xml.Linq.XElement
    IL_009a:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.Linq.XContainer::Elements()
    IL_009f:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::GetEnumerator()
    IL_00a4:  stloc.3
    .try
    {
      IL_00a5:  br         IL_0183

      IL_00aa:  ldloc.3
      IL_00ab:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::get_Current()
      IL_00b0:  stloc.s    V_4
      IL_00b2:  ldloc.s    V_4
      IL_00b4:  ldstr      "Block"
      IL_00b9:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_00be:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XContainer::Element(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_00c3:  stloc.s    V_5
      IL_00c5:  ldloc.s    V_5
      IL_00c7:  brfalse    IL_0183

      IL_00cc:  ldloc.s    V_5
      IL_00ce:  ldstr      "Type"
      IL_00d3:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_00d8:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XAttribute [System.Xml.Linq]System.Xml.Linq.XElement::Attribute(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_00dd:  call       string [System.Xml.Linq]System.Xml.Linq.XAttribute::op_Explicit(class [System.Xml.Linq]System.Xml.Linq.XAttribute)
      IL_00e2:  ldarg.3
      IL_00e3:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                            string)
      IL_00e8:  brfalse    IL_0183

      IL_00ed:  ldloc.s    V_4
      IL_00ef:  ldstr      "InternalName"
      IL_00f4:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_00f9:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XContainer::Element(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_00fe:  stloc.s    V_6
      IL_0100:  ldloc.s    V_6
      IL_0102:  brfalse.s  IL_0183

      IL_0104:  ldloc.s    V_6
      IL_0106:  callvirt   instance string [System.Xml.Linq]System.Xml.Linq.XElement::get_Value()
      IL_010b:  stloc.s    V_7
      IL_010d:  ldloc.s    V_7
      IL_010f:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
      IL_0114:  brtrue.s   IL_0183

      IL_0116:  ldloc.s    V_4
      IL_0118:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.Linq.XContainer::Elements()
      IL_011d:  call       !!0 [System.Core]System.Linq.Enumerable::FirstOrDefault<class [System.Xml.Linq]System.Xml.Linq.XElement>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
      IL_0122:  stloc.s    V_8
      IL_0124:  ldloc.s    V_8
      IL_0126:  brfalse.s  IL_0183

      IL_0128:  ldloc.s    V_8
      IL_012a:  callvirt   instance string [System.Xml.Linq]System.Xml.Linq.XElement::get_Value()
      IL_012f:  stloc.s    V_9
      IL_0131:  ldloc.s    V_9
      IL_0133:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
      IL_0138:  brtrue.s   IL_0183

      IL_013a:  ldloc.2
      IL_013b:  ldstr      "Entry"
      IL_0140:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_0145:  ldc.i4.2
      IL_0146:  newarr     [mscorlib]System.Object
      IL_014b:  dup
      IL_014c:  ldc.i4.0
      IL_014d:  ldstr      "Key"
      IL_0152:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_0157:  ldloc.s    V_7
      IL_0159:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                          object)
      IL_015e:  stelem.ref
      IL_015f:  dup
      IL_0160:  ldc.i4.1
      IL_0161:  ldstr      "Value"
      IL_0166:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_016b:  ldloc.1
      IL_016c:  ldloc.s    V_9
      IL_016e:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(string,
                                                                                                              string)
      IL_0173:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                          object)
      IL_0178:  stelem.ref
      IL_0179:  newobj     instance void [System.Xml.Linq]System.Xml.Linq.XElement::.ctor(class [System.Xml.Linq]System.Xml.Linq.XName,
                                                                                          object[])
      IL_017e:  callvirt   instance void [System.Xml.Linq]System.Xml.Linq.XContainer::Add(object)
      IL_0183:  ldloc.3
      IL_0184:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_0189:  brtrue     IL_00aa

      IL_018e:  leave.s    IL_019a

    }  // end .try
    finally
    {
      IL_0190:  ldloc.3
      IL_0191:  brfalse.s  IL_0199

      IL_0193:  ldloc.3
      IL_0194:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0199:  endfinally
    }  // end handler
    IL_019a:  ret
  } // end of method BlockSummaryHelper::AppendRowInformation

  .method private hidebysig static string 
          GetFullDataPath(string blockId,
                          bool isBlock,
                          bool isDesignSpec,
                          bool isUtility,
                          bool isStreamWithPricing,
                          [opt] bool ignoreDataSegment) cil managed
  {
    .param [6] = bool(false)
    // Code size       286 (0x11e)
    .maxstack  5
    .locals init (class [mscorlib]System.Text.StringBuilder V_0,
             string[] V_1,
             int32 V_2,
             string V_3,
             string V_4)
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.s   46
    IL_0003:  call       bool [System.Core]System.Linq.Enumerable::Contains<char>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                  !!0)
    IL_0008:  brfalse    IL_00c6

    IL_000d:  ldstr      "Top.appModelV8"
    IL_0012:  newobj     instance void [mscorlib]System.Text.StringBuilder::.ctor(string)
    IL_0017:  stloc.0
    IL_0018:  ldarg.0
    IL_0019:  callvirt   instance string [mscorlib]System.String::Trim()
    IL_001e:  ldc.i4.1
    IL_001f:  newarr     [mscorlib]System.Char
    IL_0024:  dup
    IL_0025:  ldc.i4.0
    IL_0026:  ldc.i4.s   46
    IL_0028:  stelem.i2
    IL_0029:  callvirt   instance string[] [mscorlib]System.String::Split(char[])
    IL_002e:  stloc.1
    IL_002f:  ldc.i4.0
    IL_0030:  stloc.2
    IL_0031:  br.s       IL_0060

    IL_0033:  ldloc.1
    IL_0034:  ldloc.2
    IL_0035:  ldelem.ref
    IL_0036:  stloc.3
    IL_0037:  ldloc.2
    IL_0038:  ldc.i4.0
    IL_0039:  ble.s      IL_004a

    IL_003b:  ldarg.s    ignoreDataSegment
    IL_003d:  brtrue.s   IL_004a

    IL_003f:  ldloc.0
    IL_0040:  ldstr      "Data"
    IL_0045:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(class [mscorlib]System.Text.StringBuilder,
                                                                                                          string)
    IL_004a:  ldloc.0
    IL_004b:  ldstr      "Blocks"
    IL_0050:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(class [mscorlib]System.Text.StringBuilder,
                                                                                                          string)
    IL_0055:  ldloc.0
    IL_0056:  ldloc.3
    IL_0057:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(class [mscorlib]System.Text.StringBuilder,
                                                                                                          string)
    IL_005c:  ldloc.2
    IL_005d:  ldc.i4.1
    IL_005e:  add
    IL_005f:  stloc.2
    IL_0060:  ldloc.2
    IL_0061:  ldloc.1
    IL_0062:  ldlen
    IL_0063:  conv.i4
    IL_0064:  ldc.i4.1
    IL_0065:  sub
    IL_0066:  blt.s      IL_0033

    IL_0068:  ldarg.s    ignoreDataSegment
    IL_006a:  brtrue.s   IL_0077

    IL_006c:  ldloc.0
    IL_006d:  ldstr      "Data"
    IL_0072:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(class [mscorlib]System.Text.StringBuilder,
                                                                                                          string)
    IL_0077:  ldarg.2
    IL_0078:  brfalse.s  IL_0087

    IL_007a:  ldloc.0
    IL_007b:  ldstr      "Flowsheeting Options.Design-Spec"
    IL_0080:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(class [mscorlib]System.Text.StringBuilder,
                                                                                                          string)
    IL_0085:  br.s       IL_00b3

    IL_0087:  ldarg.3
    IL_0088:  brfalse.s  IL_0097

    IL_008a:  ldloc.0
    IL_008b:  ldstr      "Utilities"
    IL_0090:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(class [mscorlib]System.Text.StringBuilder,
                                                                                                          string)
    IL_0095:  br.s       IL_00b3

    IL_0097:  ldarg.s    isStreamWithPricing
    IL_0099:  brfalse.s  IL_00a8

    IL_009b:  ldloc.0
    IL_009c:  ldstr      "Streams"
    IL_00a1:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(class [mscorlib]System.Text.StringBuilder,
                                                                                                          string)
    IL_00a6:  br.s       IL_00b3

    IL_00a8:  ldloc.0
    IL_00a9:  ldstr      "Blocks"
    IL_00ae:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(class [mscorlib]System.Text.StringBuilder,
                                                                                                          string)
    IL_00b3:  ldloc.0
    IL_00b4:  ldloc.1
    IL_00b5:  call       !!0 [System.Core]System.Linq.Enumerable::Last<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_00ba:  call       void AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(class [mscorlib]System.Text.StringBuilder,
                                                                                                          string)
    IL_00bf:  ldloc.0
    IL_00c0:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_00c5:  ret

    IL_00c6:  ldstr      "Top.appModelV8"
    IL_00cb:  stloc.s    V_4
    IL_00cd:  ldarg.2
    IL_00ce:  brfalse.s  IL_00e0

    IL_00d0:  ldloc.s    V_4
    IL_00d2:  ldstr      "Flowsheeting Options.Design-Spec"
    IL_00d7:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(string,
                                                                                                            string)
    IL_00dc:  stloc.s    V_4
    IL_00de:  br.s       IL_0115

    IL_00e0:  ldarg.3
    IL_00e1:  brfalse.s  IL_00f3

    IL_00e3:  ldloc.s    V_4
    IL_00e5:  ldstr      "Utilities"
    IL_00ea:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(string,
                                                                                                            string)
    IL_00ef:  stloc.s    V_4
    IL_00f1:  br.s       IL_0115

    IL_00f3:  ldarg.s    isStreamWithPricing
    IL_00f5:  brfalse.s  IL_0107

    IL_00f7:  ldloc.s    V_4
    IL_00f9:  ldstr      "Streams"
    IL_00fe:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(string,
                                                                                                            string)
    IL_0103:  stloc.s    V_4
    IL_0105:  br.s       IL_0115

    IL_0107:  ldloc.s    V_4
    IL_0109:  ldstr      "Blocks"
    IL_010e:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(string,
                                                                                                            string)
    IL_0113:  stloc.s    V_4
    IL_0115:  ldloc.s    V_4
    IL_0117:  ldarg.0
    IL_0118:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::CombineDataPath(string,
                                                                                                            string)
    IL_011d:  ret
  } // end of method BlockSummaryHelper::GetFullDataPath

  .method private hidebysig static bool  IsUtilityBlockType(string blockType) cil managed
  {
    // Code size       27 (0x1b)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "Utilities"
    IL_0006:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_000b:  brtrue.s   IL_0019

    IL_000d:  ldarg.0
    IL_000e:  ldstr      "Utility"
    IL_0013:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0018:  ret

    IL_0019:  ldc.i4.1
    IL_001a:  ret
  } // end of method BlockSummaryHelper::IsUtilityBlockType

  .method private hidebysig static void  CombineDataPath(class [mscorlib]System.Text.StringBuilder sb,
                                                         string path) cil managed
  {
    // Code size       16 (0x10)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.s   46
    IL_0003:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(char)
    IL_0008:  ldarg.1
    IL_0009:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_000e:  pop
    IL_000f:  ret
  } // end of method BlockSummaryHelper::CombineDataPath

  .method private hidebysig static string 
          CombineDataPath(string path1,
                          string path2) cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "."
    IL_0006:  ldarg.1
    IL_0007:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_000c:  ret
  } // end of method BlockSummaryHelper::CombineDataPath

  .property callconv(8) string FolderPath()
  {
    .get string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::get_FolderPath()
  } // end of property BlockSummaryHelper::FolderPath
  .property callconv(8) class [System.Xml.Linq]System.Xml.Linq.XElement
          GridSummaryXmlElement()
  {
    .get class [System.Xml.Linq]System.Xml.Linq.XElement AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::get_GridSummaryXmlElement()
  } // end of property BlockSummaryHelper::GridSummaryXmlElement
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior
       extends [WindowsBase]System.Windows.DependencyObject
{
  .field private initonly class [System]System.Windows.Input.ICommand _command
  .field public static initonly class [WindowsBase]System.Windows.DependencyProperty VisibilityProperty
  .method public hidebysig specialname instance valuetype [PresentationCore]System.Windows.Visibility 
          get_Visibility() cil managed
  {
    // Code size       17 (0x11)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [WindowsBase]System.Windows.DependencyProperty AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::VisibilityProperty
    IL_0006:  call       instance object [WindowsBase]System.Windows.DependencyObject::GetValue(class [WindowsBase]System.Windows.DependencyProperty)
    IL_000b:  unbox.any  [PresentationCore]System.Windows.Visibility
    IL_0010:  ret
  } // end of method ButtonBehavior::get_Visibility

  .method public hidebysig specialname instance void 
          set_Visibility(valuetype [PresentationCore]System.Windows.Visibility 'value') cil managed
  {
    // Code size       18 (0x12)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [WindowsBase]System.Windows.DependencyProperty AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::VisibilityProperty
    IL_0006:  ldarg.1
    IL_0007:  box        [PresentationCore]System.Windows.Visibility
    IL_000c:  call       instance void [WindowsBase]System.Windows.DependencyObject::SetValue(class [WindowsBase]System.Windows.DependencyProperty,
                                                                                              object)
    IL_0011:  ret
  } // end of method ButtonBehavior::set_Visibility

  .method public hidebysig specialname instance class [System]System.Windows.Input.ICommand 
          get_Command() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::_command
    IL_0006:  ret
  } // end of method ButtonBehavior::get_Command

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class [mscorlib]System.Action clickAction,
                               class [mscorlib]System.Func`1<bool> isEnabledFunc) cil managed
  {
    // Code size       48 (0x30)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [WindowsBase]System.Windows.DependencyObject::.ctor()
    IL_0006:  ldarg.1
    IL_0007:  brtrue.s   IL_0014

    IL_0009:  ldstr      "clickAction"
    IL_000e:  newobj     instance void [mscorlib]System.ArgumentNullException::.ctor(string)
    IL_0013:  throw

    IL_0014:  ldarg.2
    IL_0015:  brtrue.s   IL_0022

    IL_0017:  ldstr      "isEnabledFunc"
    IL_001c:  newobj     instance void [mscorlib]System.ArgumentNullException::.ctor(string)
    IL_0021:  throw

    IL_0022:  ldarg.0
    IL_0023:  ldarg.1
    IL_0024:  ldarg.2
    IL_0025:  newobj     instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.ApwnCommand::.ctor(class [mscorlib]System.Action,
                                                                                                                                 class [mscorlib]System.Func`1<bool>)
    IL_002a:  stfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::_command
    IL_002f:  ret
  } // end of method ButtonBehavior::.ctor

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       47 (0x2f)
    .maxstack  8
    IL_0000:  ldstr      "Visibility"
    IL_0005:  ldtoken    [PresentationCore]System.Windows.Visibility
    IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_000f:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior
    IL_0014:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0019:  ldc.i4.0
    IL_001a:  box        [PresentationCore]System.Windows.Visibility
    IL_001f:  newobj     instance void [WindowsBase]System.Windows.PropertyMetadata::.ctor(object)
    IL_0024:  call       class [WindowsBase]System.Windows.DependencyProperty [WindowsBase]System.Windows.DependencyProperty::Register(string,
                                                                                                                                       class [mscorlib]System.Type,
                                                                                                                                       class [mscorlib]System.Type,
                                                                                                                                       class [WindowsBase]System.Windows.PropertyMetadata)
    IL_0029:  stsfld     class [WindowsBase]System.Windows.DependencyProperty AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::VisibilityProperty
    IL_002e:  ret
  } // end of method ButtonBehavior::.cctor

  .property instance callconv(8) valuetype [PresentationCore]System.Windows.Visibility
          Visibility()
  {
    .get instance valuetype [PresentationCore]System.Windows.Visibility AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::get_Visibility()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
  } // end of property ButtonBehavior::Visibility
  .property instance callconv(8) class [System]System.Windows.Input.ICommand
          Command()
  {
    .get instance class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::get_Command()
  } // end of property ButtonBehavior::Command
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior

.class interface public abstract auto ansi AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView
{
  .method public hidebysig newslot specialname abstract virtual 
          instance string[]  get_SelectedRows() cil managed
  {
  } // end of method ISummaryGridView::get_SelectedRows

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_SelectedTab() cil managed
  {
  } // end of method ISummaryGridView::get_SelectedTab

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_SelectedTab(string 'value') cil managed
  {
  } // end of method ISummaryGridView::set_SelectedTab

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsVisible() cil managed
  {
  } // end of method ISummaryGridView::get_IsVisible

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_IsVisible(bool 'value') cil managed
  {
  } // end of method ISummaryGridView::set_IsVisible

  .method public hidebysig newslot abstract virtual 
          instance void  Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase cxsCase,
                                    string configurationXml) cil managed
  {
  } // end of method ISummaryGridView::Initialize

  .method public hidebysig newslot abstract virtual 
          instance void  RefreshData() cil managed
  {
  } // end of method ISummaryGridView::RefreshData

  .method public hidebysig newslot abstract virtual 
          instance void  CopyToClipboard() cil managed
  {
  } // end of method ISummaryGridView::CopyToClipboard

  .property instance callconv(8) string[]
          SelectedRows()
  {
    .get instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows()
  } // end of property ISummaryGridView::SelectedRows
  .property instance callconv(8) string SelectedTab()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::set_SelectedTab(string)
  } // end of property ISummaryGridView::SelectedTab
  .property instance callconv(8) bool IsVisible()
  {
    .get instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_IsVisible()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::set_IsVisible(bool)
  } // end of property ISummaryGridView::IsVisible
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .field private string '<SelectedScope>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly class [mscorlib]System.Collections.Generic.IEnumerable`1<string> _scopes
  .method public hidebysig specialname instance string 
          get_SelectedScope() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel::'<SelectedScope>k__BackingField'
    IL_0006:  ret
  } // end of method MMCapitalCost_Summary_ViewModel::get_SelectedScope

  .method public hidebysig specialname instance void 
          set_SelectedScope(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel::'<SelectedScope>k__BackingField'
    IL_0007:  ret
  } // end of method MMCapitalCost_Summary_ViewModel::set_SelectedScope

  .method public hidebysig specialname instance class [mscorlib]System.Collections.Generic.IEnumerable`1<string> 
          get_Scopes() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.IEnumerable`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel::_scopes
    IL_0006:  ret
  } // end of method MMCapitalCost_Summary_ViewModel::get_Scopes

  .method private hidebysig static class [mscorlib]System.Collections.Generic.IEnumerable`1<string> 
          GetScopes() cil managed
  {
    // Code size       97 (0x61)
    .maxstack  3
    .locals init (class [mscorlib]System.Collections.Generic.List`1<string> V_0,
             class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>> V_1,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>> V_2,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string> V_3)
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldstr      "Flowsheet"
    IL_000c:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0011:  call       class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>> [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::MDFindBlocks()
    IL_0016:  stloc.1
    IL_0017:  ldloc.1
    IL_0018:  brfalse.s  IL_005f

    IL_001a:  ldloc.1
    IL_001b:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::GetEnumerator()
    IL_0020:  stloc.2
    .try
    {
      IL_0021:  br.s       IL_004b

      IL_0023:  ldloc.2
      IL_0024:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::get_Current()
      IL_0029:  stloc.3
      IL_002a:  ldloca.s   V_3
      IL_002c:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>::get_Value()
      IL_0031:  ldstr      "HIERARCHY"
      IL_0036:  ldc.i4.2
      IL_0037:  call       bool [mscorlib]System.String::Equals(string,
                                                                string,
                                                                valuetype [mscorlib]System.StringComparison)
      IL_003c:  brfalse.s  IL_004b

      IL_003e:  ldloc.0
      IL_003f:  ldloca.s   V_3
      IL_0041:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>::get_Key()
      IL_0046:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
      IL_004b:  ldloc.2
      IL_004c:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_0051:  brtrue.s   IL_0023

      IL_0053:  leave.s    IL_005f

    }  // end .try
    finally
    {
      IL_0055:  ldloc.2
      IL_0056:  brfalse.s  IL_005e

      IL_0058:  ldloc.2
      IL_0059:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_005e:  endfinally
    }  // end handler
    IL_005f:  ldloc.0
    IL_0060:  ret
  } // end of method MMCapitalCost_Summary_ViewModel::GetScopes

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       18 (0x12)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       class [mscorlib]System.Collections.Generic.IEnumerable`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel::GetScopes()
    IL_0006:  stfld      class [mscorlib]System.Collections.Generic.IEnumerable`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel::_scopes
    IL_000b:  ldarg.0
    IL_000c:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0011:  ret
  } // end of method MMCapitalCost_Summary_ViewModel::.ctor

  .property instance callconv(8) string SelectedScope()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel::get_SelectedScope()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel::set_SelectedScope(string)
  } // end of property MMCapitalCost_Summary_ViewModel::SelectedScope
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.IEnumerable`1<string>
          Scopes()
  {
    .get instance class [mscorlib]System.Collections.Generic.IEnumerable`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel::get_Scopes()
  } // end of property MMCapitalCost_Summary_ViewModel::Scopes
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 23 4D 4D 53 75 6D 6D 61 72 79 47 72 69 64   // ..#MMSummaryGrid
                                                                                                    2E 4D 4D 43 61 70 69 74 61 6C 43 6F 73 74 5F 53   // .MMCapitalCost_S
                                                                                                    75 6D 6D 61 72 79 00 00 )                         // ummary..
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary::InitializeComponent()
    IL_001c:  ret
  } // end of method MMCapitalCost_Summary::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.SummaryGrid;component"
    + "/mmcapitalcost_summary.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMCapitalCost_Summary::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.1
    IL_0002:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary::_contentLoaded
    IL_0007:  ret
  } // end of method MMCapitalCost_Summary::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.MMCapitalCost_Summary

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMEquipment_ViewModel::.ctor

} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 19 4D 4D 53 75 6D 6D 61 72 79 47 72 69 64   // ...MMSummaryGrid
                                                                                                    2E 4D 4D 45 71 75 69 70 6D 65 6E 74 00 00 )       // .MMEquipment..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip MMTabStrip1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab0
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab1
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment::InitializeComponent()
    IL_001c:  ret
  } // end of method MMEquipment::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.SummaryGrid;component"
    + "/mmequipment.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMEquipment::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       69 (0x45)
    .maxstack  2
    .locals init ()
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_0016,
                          IL_0023,
                          IL_0030)
    IL_0014:  br.s       IL_003d

    IL_0016:  ldarg.0
    IL_0017:  ldarg.2
    IL_0018:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip
    IL_001d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment::MMTabStrip1
    IL_0022:  ret

    IL_0023:  ldarg.0
    IL_0024:  ldarg.2
    IL_0025:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_002a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment::tab0
    IL_002f:  ret

    IL_0030:  ldarg.0
    IL_0031:  ldarg.2
    IL_0032:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_0037:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment::tab1
    IL_003c:  ret

    IL_003d:  ldarg.0
    IL_003e:  ldc.i4.1
    IL_003f:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment::_contentLoaded
    IL_0044:  ret
  } // end of method MMEquipment::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .field private static literal string ParameterNameXmlFilter = "XMLObjFilter"
  .field private static literal string XmlFilterOfEquipment = "Equipment"
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration txtStatus_Status_Property
  .field private string '<XmlConfiguration>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<CurrentUnits>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string _hierarchyScope
  .field private class AspenTech.AspenPlus.Happ.IHNode _mainNode
  .field private class [System]System.Windows.Input.ICommand _evalCheckCommand
  .field private class [System]System.Windows.Input.ICommand _changeMappingCommand
  .field private class [mscorlib]System.Action _equipmentCallbackDelegate
  .field private class [System]System.Windows.Input.ICommand _evaluateCommand
  .method public hidebysig specialname instance object 
          get_txtStatus_Status() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::txtStatus_Status_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_txtStatus_Status

  .method family hidebysig specialname instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView 
          get_SummaryGridView() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance object [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::get_View()
    IL_0006:  isinst     AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView
    IL_000b:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_SummaryGridView

  .method family hidebysig specialname instance string 
          get_XmlConfiguration() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::'<XmlConfiguration>k__BackingField'
    IL_0006:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_XmlConfiguration

  .method private hidebysig specialname instance void 
          set_XmlConfiguration(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::'<XmlConfiguration>k__BackingField'
    IL_0007:  ret
  } // end of method MMEquipment_Mapping_ViewModel::set_XmlConfiguration

  .method family hidebysig specialname instance string 
          get_CurrentUnits() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::'<CurrentUnits>k__BackingField'
    IL_0006:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_CurrentUnits

  .method private hidebysig specialname instance void 
          set_CurrentUnits(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::'<CurrentUnits>k__BackingField'
    IL_0007:  ret
  } // end of method MMEquipment_Mapping_ViewModel::set_CurrentUnits

  .method public hidebysig specialname instance string 
          get_HierarchyScope() cil managed
  {
    // Code size       54 (0x36)
    .maxstack  3
    .locals init (object V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_hierarchyScope
    IL_0006:  brtrue.s   IL_002f

    IL_0008:  ldarg.0
    IL_0009:  call       instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_MainNode()
    IL_000e:  brfalse.s  IL_002f

    IL_0010:  ldarg.0
    IL_0011:  call       instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_MainNode()
    IL_0016:  ldc.i4.s   76
    IL_0018:  ldsfld     object [mscorlib]System.Type::Missing
    IL_001d:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_AttributeValue(int16,
                                                                                             object)
    IL_0022:  stloc.0
    IL_0023:  ldarg.0
    IL_0024:  ldloc.0
    IL_0025:  isinst     [mscorlib]System.String
    IL_002a:  stfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_hierarchyScope
    IL_002f:  ldarg.0
    IL_0030:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_hierarchyScope
    IL_0035:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_HierarchyScope

  .method public hidebysig specialname instance class AspenTech.AspenPlus.Happ.IHNode 
          get_MainNode() cil managed
  {
    // Code size       82 (0x52)
    .maxstack  8
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_mainNode
    IL_0006:  brtrue.s   IL_004b

    IL_0008:  ldarg.0
    IL_0009:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_000e:  brfalse.s  IL_004b

    IL_0010:  ldarg.0
    IL_0011:  ldstr      "@main"
    IL_0016:  call       instance string [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ExpandDataPath(string)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldarg.0
    IL_001e:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0023:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_0028:  ldstr      "Top.appModelV8.Custom Actions"
    IL_002d:  ldstr      "HappNode"
    IL_0032:  ldc.i4.1
    IL_0033:  newarr     [mscorlib]System.Object
    IL_0038:  dup
    IL_0039:  ldc.i4.0
    IL_003a:  ldloc.0
    IL_003b:  stelem.ref
    IL_003c:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::InvokeAction(string,
                                                                                                      string,
                                                                                                      object[])
    IL_0041:  isinst     AspenTech.AspenPlus.Happ.IHNode
    IL_0046:  stfld      class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_mainNode
    IL_004b:  ldarg.0
    IL_004c:  ldfld      class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_mainNode
    IL_0051:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_MainNode

  .method public hidebysig specialname instance string 
          get_ScopedId() cil managed
  {
    // Code size       52 (0x34)
    .maxstack  3
    .locals init (string V_0,
             string V_1)
    IL_0000:  ldarg.0
    IL_0001:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_HierarchyScope()
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldstr      "@main"
    IL_000d:  ldstr      "id"
    IL_0012:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ExpandDataPathAndGet(string,
                                                                                                                                             string)
    IL_0017:  isinst     [mscorlib]System.String
    IL_001c:  stloc.1
    IL_001d:  ldloc.0
    IL_001e:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0023:  brfalse.s  IL_0027

    IL_0025:  ldloc.1
    IL_0026:  ret

    IL_0027:  ldloc.0
    IL_0028:  ldstr      "."
    IL_002d:  ldloc.1
    IL_002e:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0033:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_ScopedId

  .method public hidebysig specialname instance class [System]System.Windows.Input.ICommand 
          get_EvalCheckCommand() cil managed
  {
    // Code size       38 (0x26)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_evalCheckCommand
    IL_0006:  brtrue.s   IL_001f

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::EvalCheck_CommandExecute(object)
    IL_0010:  newobj     instance void class [mscorlib]System.Action`1<object>::.ctor(object,
                                                                                      native int)
    IL_0015:  newobj     instance void class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvDelegateCommand`1<object>::.ctor(class [mscorlib]System.Action`1<!0>)
    IL_001a:  stfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_evalCheckCommand
    IL_001f:  ldarg.0
    IL_0020:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_evalCheckCommand
    IL_0025:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_EvalCheckCommand

  .method private hidebysig instance void 
          EvalCheck_CommandExecute(object parameter) cil managed
  {
    // Code size       56 (0x38)
    .maxstack  3
    .locals init (bool V_0,
             string[] V_1,
             string V_2)
    IL_0000:  ldarg.1
    IL_0001:  brtrue.s   IL_0004

    IL_0003:  ret

    IL_0004:  ldarg.1
    IL_0005:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_000a:  ldloca.s   V_0
    IL_000c:  call       bool [mscorlib]System.Boolean::TryParse(string,
                                                                 bool&)
    IL_0011:  ldloc.0
    IL_0012:  and
    IL_0013:  brfalse.s  IL_0037

    IL_0015:  ldc.i4.1
    IL_0016:  newarr     [mscorlib]System.String
    IL_001b:  stloc.1
    IL_001c:  ldarg.0
    IL_001d:  ldstr      "@main"
    IL_0022:  call       instance string [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ExpandDataPath(string)
    IL_0027:  stloc.2
    IL_0028:  ldloc.1
    IL_0029:  ldloc.2
    IL_002a:  ldc.i4.0
    IL_002b:  callvirt   instance void [mscorlib]System.Array::SetValue(object,
                                                                        int32)
    IL_0030:  ldarg.0
    IL_0031:  ldloc.1
    IL_0032:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::LoadBlockResults(string[])
    IL_0037:  ret
  } // end of method MMEquipment_Mapping_ViewModel::EvalCheck_CommandExecute

  .method public hidebysig specialname instance class [System]System.Windows.Input.ICommand 
          get_ChangeMappingCommand() cil managed
  {
    // Code size       38 (0x26)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_changeMappingCommand
    IL_0006:  brtrue.s   IL_001f

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::ChangeMappingCommand_Executed(object)
    IL_0010:  newobj     instance void class [mscorlib]System.Action`1<object>::.ctor(object,
                                                                                      native int)
    IL_0015:  newobj     instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object>::.ctor(class [mscorlib]System.Action`1<!0>)
    IL_001a:  stfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_changeMappingCommand
    IL_001f:  ldarg.0
    IL_0020:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_changeMappingCommand
    IL_0025:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_ChangeMappingCommand

  .method private hidebysig instance void 
          ChangeMappingCommand_Executed(object parameter) cil managed
  {
    // Code size       144 (0x90)
    .maxstack  9
    .locals init (string[] V_0,
             string V_1)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_0006:  brfalse    IL_008f

    IL_000b:  ldarg.0
    IL_000c:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_0011:  callvirt   instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows()
    IL_0016:  stloc.0
    IL_0017:  ldloc.0
    IL_0018:  brfalse.s  IL_001e

    IL_001a:  ldloc.0
    IL_001b:  ldlen
    IL_001c:  brtrue.s   IL_0049

    IL_001e:  ldarg.0
    IL_001f:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_0024:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_0029:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_002e:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_Map()
    IL_0033:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_0038:  ldc.i4.0
    IL_0039:  ldc.i4.0
    IL_003a:  ldc.i4.0
    IL_003b:  ldc.i4.1
    IL_003c:  ldstr      "apwn.chm"
    IL_0041:  ldc.i4.m1
    IL_0042:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_0047:  pop
    IL_0048:  ret

    IL_0049:  ldnull
    IL_004a:  stloc.1
    IL_004b:  ldloc.0
    IL_004c:  ldarg.0
    IL_004d:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::GetEquipmentCallbackPointer()
    IL_0052:  ldarg.0
    IL_0053:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_CurrentWindowPointer()
    IL_0058:  ldloca.s   V_1
    IL_005a:  call       bool [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::MapUnitOps(class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                                        native int,
                                                                                                                                        native int,
                                                                                                                                        string&)
    IL_005f:  brtrue.s   IL_008f

    IL_0061:  ldloc.1
    IL_0062:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0067:  brtrue.s   IL_008f

    IL_0069:  ldarg.0
    IL_006a:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_006f:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_0074:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_0079:  ldloc.1
    IL_007a:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_007f:  ldc.i4.0
    IL_0080:  ldc.i4.0
    IL_0081:  ldc.i4.0
    IL_0082:  ldc.i4.1
    IL_0083:  ldstr      "apwn.chm"
    IL_0088:  ldc.i4.m1
    IL_0089:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_008e:  pop
    IL_008f:  ret
  } // end of method MMEquipment_Mapping_ViewModel::ChangeMappingCommand_Executed

  .method private hidebysig instance native int 
          GetEquipmentCallbackPointer() cil managed
  {
    // Code size       38 (0x26)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Action AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_equipmentCallbackDelegate
    IL_0006:  brtrue.s   IL_001a

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::EquipmentCallback()
    IL_0010:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_0015:  stfld      class [mscorlib]System.Action AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_equipmentCallbackDelegate
    IL_001a:  ldarg.0
    IL_001b:  ldfld      class [mscorlib]System.Action AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_equipmentCallbackDelegate
    IL_0020:  call       native int [mscorlib]System.Runtime.InteropServices.Marshal::GetFunctionPointerForDelegate<class [mscorlib]System.Action>(!!0)
    IL_0025:  ret
  } // end of method MMEquipment_Mapping_ViewModel::GetEquipmentCallbackPointer

  .method public hidebysig specialname instance native int 
          get_CurrentWindowPointer() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldc.i4.0
    IL_0001:  newobj     instance void [mscorlib]System.IntPtr::.ctor(int32)
    IL_0006:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_CurrentWindowPointer

  .method private hidebysig instance void 
          EquipmentCallback() cil managed
  {
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method MMEquipment_Mapping_ViewModel::EquipmentCallback

  .method public hidebysig specialname instance class [System]System.Windows.Input.ICommand 
          get_EvaluateCommand() cil managed
  {
    // Code size       38 (0x26)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_evaluateCommand
    IL_0006:  brtrue.s   IL_001f

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::EvaluateCommand_Executed(object)
    IL_0010:  newobj     instance void class [mscorlib]System.Action`1<object>::.ctor(object,
                                                                                      native int)
    IL_0015:  newobj     instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object>::.ctor(class [mscorlib]System.Action`1<!0>)
    IL_001a:  stfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_evaluateCommand
    IL_001f:  ldarg.0
    IL_0020:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::_evaluateCommand
    IL_0025:  ret
  } // end of method MMEquipment_Mapping_ViewModel::get_EvaluateCommand

  .method private hidebysig instance void 
          EvaluateCommand_Executed(object parameter) cil managed
  {
    // Code size       144 (0x90)
    .maxstack  9
    .locals init (string[] V_0,
             string V_1)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_0006:  brfalse    IL_008f

    IL_000b:  ldarg.0
    IL_000c:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_0011:  callvirt   instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows()
    IL_0016:  stloc.0
    IL_0017:  ldloc.0
    IL_0018:  brfalse.s  IL_001e

    IL_001a:  ldloc.0
    IL_001b:  ldlen
    IL_001c:  brtrue.s   IL_0049

    IL_001e:  ldarg.0
    IL_001f:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_0024:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_0029:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_002e:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_Evaluate()
    IL_0033:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_0038:  ldc.i4.0
    IL_0039:  ldc.i4.0
    IL_003a:  ldc.i4.0
    IL_003b:  ldc.i4.1
    IL_003c:  ldstr      "apwn.chm"
    IL_0041:  ldc.i4.m1
    IL_0042:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_0047:  pop
    IL_0048:  ret

    IL_0049:  ldnull
    IL_004a:  stloc.1
    IL_004b:  ldloc.0
    IL_004c:  ldarg.0
    IL_004d:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::GetEquipmentCallbackPointer()
    IL_0052:  ldarg.0
    IL_0053:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_CurrentWindowPointer()
    IL_0058:  ldloca.s   V_1
    IL_005a:  call       bool [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::EvaluateUnitOps(class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                                             native int,
                                                                                                                                             native int,
                                                                                                                                             string&)
    IL_005f:  brtrue.s   IL_008f

    IL_0061:  ldloc.1
    IL_0062:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0067:  brtrue.s   IL_008f

    IL_0069:  ldarg.0
    IL_006a:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_006f:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_0074:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_0079:  ldloc.1
    IL_007a:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_007f:  ldc.i4.0
    IL_0080:  ldc.i4.0
    IL_0081:  ldc.i4.0
    IL_0082:  ldc.i4.1
    IL_0083:  ldstr      "apwn.chm"
    IL_0088:  ldc.i4.m1
    IL_0089:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_008e:  pop
    IL_008f:  ret
  } // end of method MMEquipment_Mapping_ViewModel::EvaluateCommand_Executed

  .method private hidebysig instance string 
          GetCurrentUnits() cil managed
  {
    // Code size       46 (0x2e)
    .maxstack  4
    .locals init (string V_0)
    IL_0000:  ldsfld     string [mscorlib]System.String::Empty
    IL_0005:  stloc.0
    .try
    {
      IL_0006:  ldarg.0
      IL_0007:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
      IL_000c:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
      IL_0011:  ldstr      "Top.appModelV8.Setup.Global.Input.INSET"
      IL_0016:  ldstr      "value"
      IL_001b:  ldnull
      IL_001c:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                    string,
                                                                                                    string)
      IL_0021:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
      IL_0026:  stloc.0
      IL_0027:  leave.s    IL_002c

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_0029:  pop
      IL_002a:  leave.s    IL_002c

    }  // end handler
    IL_002c:  ldloc.0
    IL_002d:  ret
  } // end of method MMEquipment_Mapping_ViewModel::GetCurrentUnits

  .method private hidebysig instance void 
          RunInUIThread(class [mscorlib]System.Action action) cil managed
  {
    // Code size       46 (0x2e)
    .maxstack  3
    .locals init (class [WindowsBase]System.Windows.Threading.Dispatcher V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_0006:  isinst     [PresentationCore]System.Windows.UIElement
    IL_000b:  callvirt   instance class [WindowsBase]System.Windows.Threading.Dispatcher [WindowsBase]System.Windows.Threading.DispatcherObject::get_Dispatcher()
    IL_0010:  stloc.0
    IL_0011:  ldloc.0
    IL_0012:  call       class [WindowsBase]System.Windows.Threading.Dispatcher [WindowsBase]System.Windows.Threading.Dispatcher::get_CurrentDispatcher()
    IL_0017:  bne.un.s   IL_0020

    IL_0019:  ldarg.1
    IL_001a:  callvirt   instance void [mscorlib]System.Action::Invoke()
    IL_001f:  ret

    IL_0020:  ldloc.0
    IL_0021:  ldarg.1
    IL_0022:  call       !!0[] [mscorlib]System.Array::Empty<object>()
    IL_0027:  callvirt   instance class [WindowsBase]System.Windows.Threading.DispatcherOperation [WindowsBase]System.Windows.Threading.Dispatcher::BeginInvoke(class [mscorlib]System.Delegate,
                                                                                                                                                                object[])
    IL_002c:  pop
    IL_002d:  ret
  } // end of method MMEquipment_Mapping_ViewModel::RunInUIThread

  .method family hidebysig virtual instance void 
          OnUpdateData() cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0006:  brfalse.s  IL_000e

    IL_0008:  ldarg.0
    IL_0009:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::TryInitializeViewData()
    IL_000e:  ldarg.0
    IL_000f:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::OnUpdateData()
    IL_0014:  ret
  } // end of method MMEquipment_Mapping_ViewModel::OnUpdateData

  .method family hidebysig virtual instance void 
          OnViewChanged() cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::TryInitializeViewData()
    IL_0006:  ldarg.0
    IL_0007:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::OnViewChanged()
    IL_000c:  ret
  } // end of method MMEquipment_Mapping_ViewModel::OnViewChanged

  .method private hidebysig instance void 
          TryInitializeViewData() cil managed
  {
    // Code size       238 (0xee)
    .maxstack  3
    .locals init (string V_0,
             string V_1,
             string V_2,
             bool V_3)
    IL_0000:  ldarg.0
    IL_0001:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_CurrentUnits()
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_000d:  brfalse    IL_00ed

    IL_0012:  ldarg.0
    IL_0013:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_0018:  brfalse    IL_00ed

    IL_001d:  ldarg.0
    IL_001e:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_XmlConfiguration()
    IL_0023:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0028:  brfalse.s  IL_0063

    IL_002a:  ldarg.0
    IL_002b:  ldarg.0
    IL_002c:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::BuildXmlConfiguration()
    IL_0031:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::set_XmlConfiguration(string)
    IL_0036:  ldarg.0
    IL_0037:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_XmlConfiguration()
    IL_003c:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0041:  brtrue     IL_00ed

    IL_0046:  ldarg.0
    IL_0047:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_004c:  ldarg.0
    IL_004d:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0052:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_0057:  ldarg.0
    IL_0058:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_XmlConfiguration()
    IL_005d:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                            string)
    IL_0062:  ret

    IL_0063:  ldarg.0
    IL_0064:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::BuildXmlConfiguration()
    IL_0069:  stloc.1
    IL_006a:  ldarg.0
    IL_006b:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::GetCurrentUnits()
    IL_0070:  stloc.2
    IL_0071:  ldc.i4.0
    IL_0072:  stloc.3
    IL_0073:  ldloc.2
    IL_0074:  ldloc.0
    IL_0075:  ldc.i4.4
    IL_0076:  call       int32 [mscorlib]System.String::Compare(string,
                                                                string,
                                                                valuetype [mscorlib]System.StringComparison)
    IL_007b:  brfalse.s  IL_0086

    IL_007d:  ldc.i4.1
    IL_007e:  stloc.3
    IL_007f:  ldarg.0
    IL_0080:  ldloc.2
    IL_0081:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::set_CurrentUnits(string)
    IL_0086:  ldloc.1
    IL_0087:  ldarg.0
    IL_0088:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_XmlConfiguration()
    IL_008d:  call       int32 [mscorlib]System.String::CompareOrdinal(string,
                                                                       string)
    IL_0092:  ldc.i4.0
    IL_0093:  cgt.un
    IL_0095:  ldloc.3
    IL_0096:  or
    IL_0097:  brfalse.s  IL_00e2

    IL_0099:  ldarg.0
    IL_009a:  ldloc.1
    IL_009b:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::set_XmlConfiguration(string)
    IL_00a0:  ldarg.0
    IL_00a1:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_00a6:  ldarg.0
    IL_00a7:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_00ac:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_00b1:  ldsfld     string [mscorlib]System.String::Empty
    IL_00b6:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                            string)
    IL_00bb:  ldarg.0
    IL_00bc:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_00c1:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::RefreshData()
    IL_00c6:  ldarg.0
    IL_00c7:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_00cc:  ldarg.0
    IL_00cd:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_00d2:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_00d7:  ldarg.0
    IL_00d8:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_XmlConfiguration()
    IL_00dd:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                            string)
    IL_00e2:  ldarg.0
    IL_00e3:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_00e8:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::RefreshData()
    IL_00ed:  ret
  } // end of method MMEquipment_Mapping_ViewModel::TryInitializeViewData

  .method private hidebysig instance string 
          BuildXmlConfiguration() cil managed
  {
    // Code size       133 (0x85)
    .maxstack  9
    .locals init (string V_0,
             string V_1,
             string V_2)
    IL_0000:  ldsfld     string [mscorlib]System.String::Empty
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldstr      "XMLObjFilter"
    IL_000c:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveParameter(string)
    IL_0011:  isinst     [mscorlib]System.String
    IL_0016:  ldstr      "Equipment"
    IL_001b:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0020:  brfalse.s  IL_006d

    IL_0022:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0027:  dup
    IL_0028:  ldarg.0
    IL_0029:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_ScopedId()
    IL_002e:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0033:  ldloca.s   V_1
    IL_0035:  call       string [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::GetBlockGridXML(class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                                               string&)
    IL_003a:  stloc.2
    IL_003b:  ldloc.1
    IL_003c:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0041:  brtrue.s   IL_006b

    IL_0043:  ldarg.0
    IL_0044:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
    IL_0049:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_004e:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_0053:  ldloc.1
    IL_0054:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_0059:  ldc.i4.0
    IL_005a:  ldc.i4.0
    IL_005b:  ldc.i4.0
    IL_005c:  ldc.i4.1
    IL_005d:  ldstr      "apwn.chm"
    IL_0062:  ldc.i4.m1
    IL_0063:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_0068:  pop
    IL_0069:  br.s       IL_006d

    IL_006b:  ldloc.2
    IL_006c:  stloc.0
    IL_006d:  ldloc.0
    IL_006e:  call       bool [mscorlib]System.String::IsNullOrWhiteSpace(string)
    IL_0073:  brtrue.s   IL_0083

    IL_0075:  ldarg.0
    IL_0076:  ldarg.0
    IL_0077:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::GetCurrentUnits()
    IL_007c:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::set_CurrentUnits(string)
    IL_0081:  ldloc.0
    IL_0082:  ret

    IL_0083:  ldnull
    IL_0084:  ret
  } // end of method MMEquipment_Mapping_ViewModel::BuildXmlConfiguration

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMEquipment_Mapping_ViewModel::.ctor

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       84 (0x54)
    .maxstack  5
    .locals init ()
    IL_0000:  ldstr      "txtStatus_Status"
    IL_0005:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel
    IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_000f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0014:  dup
    IL_0015:  ldc.i4.2
    IL_0016:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
    IL_001b:  dup
    IL_001c:  ldstr      "@main"
    IL_0021:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0026:  dup
    IL_0027:  ldstr      "status"
    IL_002c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataAttribute(string)
    IL_0031:  dup
    IL_0032:  ldc.i4.1
    IL_0033:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_0038:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_IsReadOnly(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_003d:  dup
    IL_003e:  ldc.i4.0
    IL_003f:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_0044:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_IsCalculated(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_0049:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_004e:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::txtStatus_Status_Property
    IL_0053:  ret
  } // end of method MMEquipment_Mapping_ViewModel::.cctor

  .property instance callconv(8) object txtStatus_Status()
  {
    .get instance object AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_txtStatus_Status()
  } // end of property MMEquipment_Mapping_ViewModel::txtStatus_Status
  .property instance callconv(8) class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView
          SummaryGridView()
  {
    .get instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_SummaryGridView()
  } // end of property MMEquipment_Mapping_ViewModel::SummaryGridView
  .property instance callconv(8) string XmlConfiguration()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_XmlConfiguration()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::set_XmlConfiguration(string)
  } // end of property MMEquipment_Mapping_ViewModel::XmlConfiguration
  .property instance callconv(8) string CurrentUnits()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_CurrentUnits()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::set_CurrentUnits(string)
  } // end of property MMEquipment_Mapping_ViewModel::CurrentUnits
  .property instance callconv(8) string HierarchyScope()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_HierarchyScope()
  } // end of property MMEquipment_Mapping_ViewModel::HierarchyScope
  .property instance callconv(8) class AspenTech.AspenPlus.Happ.IHNode
          MainNode()
  {
    .get instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_MainNode()
  } // end of property MMEquipment_Mapping_ViewModel::MainNode
  .property instance callconv(8) string ScopedId()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_ScopedId()
  } // end of property MMEquipment_Mapping_ViewModel::ScopedId
  .property instance callconv(8) class [System]System.Windows.Input.ICommand
          EvalCheckCommand()
  {
    .get instance class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_EvalCheckCommand()
  } // end of property MMEquipment_Mapping_ViewModel::EvalCheckCommand
  .property instance callconv(8) class [System]System.Windows.Input.ICommand
          ChangeMappingCommand()
  {
    .get instance class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_ChangeMappingCommand()
  } // end of property MMEquipment_Mapping_ViewModel::ChangeMappingCommand
  .property instance callconv(8) native int
          CurrentWindowPointer()
  {
    .get instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_CurrentWindowPointer()
  } // end of property MMEquipment_Mapping_ViewModel::CurrentWindowPointer
  .property instance callconv(8) class [System]System.Windows.Input.ICommand
          EvaluateCommand()
  {
    .get instance class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel::get_EvaluateCommand()
  } // end of property MMEquipment_Mapping_ViewModel::EvaluateCommand
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView,
                  [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 21 4D 4D 53 75 6D 6D 61 72 79 47 72 69 64   // ..!MMSummaryGrid
                                                                                                    2E 4D 4D 45 71 75 69 70 6D 65 6E 74 5F 4D 61 70   // .MMEquipment_Map
                                                                                                    70 69 6E 67 00 00 )                               // ping..
  .field private initonly class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid _summaryGrid
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit txtStatus
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox chkBoxEvalCheck
  .field assembly class [PresentationFramework]System.Windows.Controls.Border Border1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMScrollAreaManualLayout grdCost
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       69 (0x45)
    .maxstack  2
    .locals init ()
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::InitializeComponent()
    IL_001c:  ldarg.0
    IL_001d:  newobj     instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::.ctor()
    IL_0022:  stfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0027:  ldarg.0
    IL_0028:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_002d:  ldc.i4.1
    IL_002e:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_UseProvidedRowInfo(bool)
    IL_0033:  ldarg.0
    IL_0034:  ldfld      class [PresentationFramework]System.Windows.Controls.Border AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::Border1
    IL_0039:  ldarg.0
    IL_003a:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_003f:  callvirt   instance void [PresentationFramework]System.Windows.Controls.Decorator::set_Child(class [PresentationCore]System.Windows.UIElement)
    IL_0044:  ret
  } // end of method MMEquipment_Mapping::.ctor

  .method private hidebysig newslot specialname virtual final 
          instance string[]  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedRows() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0006:  callvirt   instance string[] [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::get_SelectedRows()
    IL_000b:  ret
  } // end of method MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedRows

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedTab() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0006:  callvirt   instance string [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::get_SelectedTab()
    IL_000b:  ret
  } // end of method MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedTab

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_SelectedTab(string 'value') cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::set_SelectedTab
    // Code size       18 (0x12)
    .maxstack  2
    .locals init ()
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
      IL_0006:  ldarg.1
      IL_0007:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_SelectedTab(string)
      IL_000c:  leave.s    IL_0011

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_000e:  pop
      IL_000f:  leave.s    IL_0011

    }  // end handler
    IL_0011:  ret
  } // end of method MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_SelectedTab

  .method private hidebysig newslot specialname virtual final 
          instance bool  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_IsVisible() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_IsVisible
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0006:  callvirt   instance bool [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::get_Visible()
    IL_000b:  ret
  } // end of method MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_IsVisible

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_IsVisible(bool 'value') cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::set_IsVisible
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_Visible(bool)
    IL_000c:  ret
  } // end of method MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_IsVisible

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase cxsCase,
                                                                                             string configurationXml) cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize
    // Code size       82 (0x52)
    .maxstack  3
    .locals init ()
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::get_ApplicationName()
    IL_000c:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_ApplicationName(string)
    IL_0011:  ldarg.0
    IL_0012:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0017:  ldarg.1
    IL_0018:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_Case(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_001d:  ldarg.0
    IL_001e:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0023:  ldarg.1
    IL_0024:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::get_CaseFullFilePath()
    IL_0029:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_CasePath(string)
    IL_002e:  ldarg.0
    IL_002f:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0034:  ldarg.2
    IL_0035:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_Configuration(string)
    IL_003a:  ldarg.0
    IL_003b:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0040:  ldarg.0
    IL_0041:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid_OnBatchSet(object,
                                                                                                                            class [mscorlib]System.EventArgs)
    IL_0047:  newobj     instance void [mscorlib]System.EventHandler::.ctor(object,
                                                                            native int)
    IL_004c:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::add_OnBatchSet(class [mscorlib]System.EventHandler)
    IL_0051:  ret
  } // end of method MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.Initialize

  .method private hidebysig instance void 
          _summaryGrid_OnBatchSet(object sender,
                                  class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::OnUpdateAll()
    IL_0006:  ret
  } // end of method MMEquipment_Mapping::_summaryGrid_OnBatchSet

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.RefreshData() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::RefreshData
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0006:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::RefreshData()
    IL_000b:  ret
  } // end of method MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.RefreshData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.CopyToClipboard() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::CopyToClipboard
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_summaryGrid
    IL_0006:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::CopyToClipboard()
    IL_000b:  ret
  } // end of method MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.CopyToClipboard

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.SummaryGrid;component"
    + "/mmequipment_mapping.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMEquipment_Mapping::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       86 (0x56)
    .maxstack  2
    .locals init ()
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_001a,
                          IL_0027,
                          IL_0034,
                          IL_0041)
    IL_0018:  br.s       IL_004e

    IL_001a:  ldarg.0
    IL_001b:  ldarg.2
    IL_001c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0021:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::txtStatus
    IL_0026:  ret

    IL_0027:  ldarg.0
    IL_0028:  ldarg.2
    IL_0029:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox
    IL_002e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::chkBoxEvalCheck
    IL_0033:  ret

    IL_0034:  ldarg.0
    IL_0035:  ldarg.2
    IL_0036:  castclass  [PresentationFramework]System.Windows.Controls.Border
    IL_003b:  stfld      class [PresentationFramework]System.Windows.Controls.Border AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::Border1
    IL_0040:  ret

    IL_0041:  ldarg.0
    IL_0042:  ldarg.2
    IL_0043:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMScrollAreaManualLayout
    IL_0048:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMScrollAreaManualLayout AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::grdCost
    IL_004d:  ret

    IL_004e:  ldarg.0
    IL_004f:  ldc.i4.1
    IL_0050:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::_contentLoaded
    IL_0055:  ret
  } // end of method MMEquipment_Mapping::System.Windows.Markup.IComponentConnector.Connect

  .property instance callconv(8) string[]
          AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedRows()
  {
    .get instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedRows()
  } // end of property MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedRows
  .property instance callconv(8) string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedTab()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedTab()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_SelectedTab(string)
  } // end of property MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedTab
  .property instance callconv(8) bool AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.IsVisible()
  {
    .get instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_IsVisible()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_IsVisible(bool)
  } // end of property MMEquipment_Mapping::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.IsVisible
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Mapping

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .field private static literal string ParameterNameXmlFilter = "XMLObjFilter"
  .field private static literal string XmlFilterOfEquipment = "Equipment"
  .field private initonly class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<string>> _tabEquipmentsPair
  .field private initonly class [mscorlib]System.Collections.Generic.List`1<string> _allEquipments
  .field private string '<XmlConfiguration>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<CurrentUnits>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string _hierarchyScope
  .field private class AspenTech.AspenPlus.Happ.IHNode _mainNode
  .field private class [System]System.Windows.Input.ICommand _sizeCommand
  .field private class [System]System.Windows.Input.ICommand _evaluateCommand
  .method family hidebysig specialname instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView 
          get_SummaryGridView() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance object [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::get_View()
    IL_0006:  isinst     AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView
    IL_000b:  ret
  } // end of method MMEquipment_Specifications_ViewModel::get_SummaryGridView

  .method family hidebysig specialname instance string 
          get_XmlConfiguration() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::'<XmlConfiguration>k__BackingField'
    IL_0006:  ret
  } // end of method MMEquipment_Specifications_ViewModel::get_XmlConfiguration

  .method private hidebysig specialname instance void 
          set_XmlConfiguration(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::'<XmlConfiguration>k__BackingField'
    IL_0007:  ret
  } // end of method MMEquipment_Specifications_ViewModel::set_XmlConfiguration

  .method family hidebysig specialname instance string 
          get_CurrentUnits() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::'<CurrentUnits>k__BackingField'
    IL_0006:  ret
  } // end of method MMEquipment_Specifications_ViewModel::get_CurrentUnits

  .method private hidebysig specialname instance void 
          set_CurrentUnits(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::'<CurrentUnits>k__BackingField'
    IL_0007:  ret
  } // end of method MMEquipment_Specifications_ViewModel::set_CurrentUnits

  .method public hidebysig specialname instance string 
          get_HierarchyScope() cil managed
  {
    // Code size       54 (0x36)
    .maxstack  3
    .locals init (object V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_hierarchyScope
    IL_0006:  brtrue.s   IL_002f

    IL_0008:  ldarg.0
    IL_0009:  call       instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_MainNode()
    IL_000e:  brfalse.s  IL_002f

    IL_0010:  ldarg.0
    IL_0011:  call       instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_MainNode()
    IL_0016:  ldc.i4.s   76
    IL_0018:  ldsfld     object [mscorlib]System.Type::Missing
    IL_001d:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_AttributeValue(int16,
                                                                                             object)
    IL_0022:  stloc.0
    IL_0023:  ldarg.0
    IL_0024:  ldloc.0
    IL_0025:  isinst     [mscorlib]System.String
    IL_002a:  stfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_hierarchyScope
    IL_002f:  ldarg.0
    IL_0030:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_hierarchyScope
    IL_0035:  ret
  } // end of method MMEquipment_Specifications_ViewModel::get_HierarchyScope

  .method public hidebysig specialname instance class AspenTech.AspenPlus.Happ.IHNode 
          get_MainNode() cil managed
  {
    // Code size       82 (0x52)
    .maxstack  8
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_mainNode
    IL_0006:  brtrue.s   IL_004b

    IL_0008:  ldarg.0
    IL_0009:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_000e:  brfalse.s  IL_004b

    IL_0010:  ldarg.0
    IL_0011:  ldstr      "@main"
    IL_0016:  call       instance string [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ExpandDataPath(string)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldarg.0
    IL_001e:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0023:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_0028:  ldstr      "Top.appModelV8.Custom Actions"
    IL_002d:  ldstr      "HappNode"
    IL_0032:  ldc.i4.1
    IL_0033:  newarr     [mscorlib]System.Object
    IL_0038:  dup
    IL_0039:  ldc.i4.0
    IL_003a:  ldloc.0
    IL_003b:  stelem.ref
    IL_003c:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::InvokeAction(string,
                                                                                                      string,
                                                                                                      object[])
    IL_0041:  isinst     AspenTech.AspenPlus.Happ.IHNode
    IL_0046:  stfld      class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_mainNode
    IL_004b:  ldarg.0
    IL_004c:  ldfld      class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_mainNode
    IL_0051:  ret
  } // end of method MMEquipment_Specifications_ViewModel::get_MainNode

  .method public hidebysig specialname instance string 
          get_ScopedId() cil managed
  {
    // Code size       52 (0x34)
    .maxstack  3
    .locals init (string V_0,
             string V_1)
    IL_0000:  ldarg.0
    IL_0001:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_HierarchyScope()
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldstr      "@main"
    IL_000d:  ldstr      "id"
    IL_0012:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ExpandDataPathAndGet(string,
                                                                                                                                             string)
    IL_0017:  isinst     [mscorlib]System.String
    IL_001c:  stloc.1
    IL_001d:  ldloc.0
    IL_001e:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0023:  brfalse.s  IL_0027

    IL_0025:  ldloc.1
    IL_0026:  ret

    IL_0027:  ldloc.0
    IL_0028:  ldstr      "."
    IL_002d:  ldloc.1
    IL_002e:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0033:  ret
  } // end of method MMEquipment_Specifications_ViewModel::get_ScopedId

  .method public hidebysig specialname instance class [System]System.Windows.Input.ICommand 
          get_SizeCommand() cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_sizeCommand
    IL_0006:  brtrue.s   IL_002b

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::SizeCommand_Executed(object)
    IL_0010:  newobj     instance void class [mscorlib]System.Action`1<object>::.ctor(object,
                                                                                      native int)
    IL_0015:  ldarg.0
    IL_0016:  ldftn      instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::SizeCommand_CanExecuted(object)
    IL_001c:  newobj     instance void class [mscorlib]System.Func`2<object,bool>::.ctor(object,
                                                                                         native int)
    IL_0021:  newobj     instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object>::.ctor(class [mscorlib]System.Action`1<!0>,
                                                                                                                                                                              class [mscorlib]System.Func`2<!0,bool>)
    IL_0026:  stfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_sizeCommand
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_sizeCommand
    IL_0031:  ret
  } // end of method MMEquipment_Specifications_ViewModel::get_SizeCommand

  .method private hidebysig instance void 
          SizeCommand_Executed(object parameter) cil managed
  {
    // Code size       84 (0x54)
    .maxstack  5
    .locals init ()
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_UnityContainer()
    IL_0006:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
    IL_000b:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0010:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.SizeScopeEvent>()
    IL_0015:  newobj     instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.SizeScopeEventArgs::.ctor()
    IL_001a:  dup
    IL_001b:  ldarg.0
    IL_001c:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_allEquipments
    IL_0021:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.SizeScopeEventArgs::set_AllEquipments(class [mscorlib]System.Collections.Generic.IEnumerable`1<string>)
    IL_0026:  dup
    IL_0027:  ldarg.0
    IL_0028:  ldarg.0
    IL_0029:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_002e:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab()
    IL_0033:  call       instance class [mscorlib]System.Collections.Generic.IEnumerable`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::GetEquipmentsOnCurrentTab(string)
    IL_0038:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.SizeScopeEventArgs::set_AllEquipmentsOnCurrentTab(class [mscorlib]System.Collections.Generic.IEnumerable`1<string>)
    IL_003d:  dup
    IL_003e:  ldarg.0
    IL_003f:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_0044:  callvirt   instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows()
    IL_0049:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.SizeScopeEventArgs::set_SelectedEquipments(class [mscorlib]System.Collections.Generic.IEnumerable`1<string>)
    IL_004e:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.SizeScopeEventArgs>::Publish(!0)
    IL_0053:  ret
  } // end of method MMEquipment_Specifications_ViewModel::SizeCommand_Executed

  .method private hidebysig instance bool 
          SizeCommand_CanExecuted(object parameter) cil managed
  {
    // Code size       2 (0x2)
    .maxstack  8
    IL_0000:  ldc.i4.1
    IL_0001:  ret
  } // end of method MMEquipment_Specifications_ViewModel::SizeCommand_CanExecuted

  .method public hidebysig specialname instance class [System]System.Windows.Input.ICommand 
          get_EvaluateCommand() cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_evaluateCommand
    IL_0006:  brtrue.s   IL_002b

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::EvaluateCommand_Executed(object)
    IL_0010:  newobj     instance void class [mscorlib]System.Action`1<object>::.ctor(object,
                                                                                      native int)
    IL_0015:  ldarg.0
    IL_0016:  ldftn      instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::EvaluateCommand_CanExecuted(object)
    IL_001c:  newobj     instance void class [mscorlib]System.Func`2<object,bool>::.ctor(object,
                                                                                         native int)
    IL_0021:  newobj     instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object>::.ctor(class [mscorlib]System.Action`1<!0>,
                                                                                                                                                                              class [mscorlib]System.Func`2<!0,bool>)
    IL_0026:  stfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_evaluateCommand
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_evaluateCommand
    IL_0031:  ret
  } // end of method MMEquipment_Specifications_ViewModel::get_EvaluateCommand

  .method private hidebysig instance void 
          EvaluateCommand_Executed(object parameter) cil managed
  {
    // Code size       84 (0x54)
    .maxstack  5
    .locals init ()
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_UnityContainer()
    IL_0006:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
    IL_000b:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0010:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.EvaluateScopeEvent>()
    IL_0015:  newobj     instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.EvaluateScopeEventArgs::.ctor()
    IL_001a:  dup
    IL_001b:  ldarg.0
    IL_001c:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_allEquipments
    IL_0021:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.EvaluateScopeEventArgs::set_AllEquipments(class [mscorlib]System.Collections.Generic.IEnumerable`1<string>)
    IL_0026:  dup
    IL_0027:  ldarg.0
    IL_0028:  ldarg.0
    IL_0029:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_002e:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab()
    IL_0033:  call       instance class [mscorlib]System.Collections.Generic.IEnumerable`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::GetEquipmentsOnCurrentTab(string)
    IL_0038:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.EvaluateScopeEventArgs::set_AllEquipmentsOnCurrentTab(class [mscorlib]System.Collections.Generic.IEnumerable`1<string>)
    IL_003d:  dup
    IL_003e:  ldarg.0
    IL_003f:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_0044:  callvirt   instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows()
    IL_0049:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.EvaluateScopeEventArgs::set_SelectedEquipments(class [mscorlib]System.Collections.Generic.IEnumerable`1<string>)
    IL_004e:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.EvaluateScopeEventArgs>::Publish(!0)
    IL_0053:  ret
  } // end of method MMEquipment_Specifications_ViewModel::EvaluateCommand_Executed

  .method private hidebysig instance bool 
          EvaluateCommand_CanExecuted(object parameter) cil managed
  {
    // Code size       2 (0x2)
    .maxstack  8
    IL_0000:  ldc.i4.1
    IL_0001:  ret
  } // end of method MMEquipment_Specifications_ViewModel::EvaluateCommand_CanExecuted

  .method private hidebysig instance string 
          GetCurrentUnits() cil managed
  {
    // Code size       46 (0x2e)
    .maxstack  4
    .locals init (string V_0)
    IL_0000:  ldsfld     string [mscorlib]System.String::Empty
    IL_0005:  stloc.0
    .try
    {
      IL_0006:  ldarg.0
      IL_0007:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
      IL_000c:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
      IL_0011:  ldstr      "Top.appModelV8.Setup.Global.Input.INSET"
      IL_0016:  ldstr      "value"
      IL_001b:  ldnull
      IL_001c:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                    string,
                                                                                                    string)
      IL_0021:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
      IL_0026:  stloc.0
      IL_0027:  leave.s    IL_002c

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_0029:  pop
      IL_002a:  leave.s    IL_002c

    }  // end handler
    IL_002c:  ldloc.0
    IL_002d:  ret
  } // end of method MMEquipment_Specifications_ViewModel::GetCurrentUnits

  .method private hidebysig instance void 
          RunInUIThread(class [mscorlib]System.Action action) cil managed
  {
    // Code size       46 (0x2e)
    .maxstack  3
    .locals init (class [WindowsBase]System.Windows.Threading.Dispatcher V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_0006:  isinst     [PresentationCore]System.Windows.UIElement
    IL_000b:  callvirt   instance class [WindowsBase]System.Windows.Threading.Dispatcher [WindowsBase]System.Windows.Threading.DispatcherObject::get_Dispatcher()
    IL_0010:  stloc.0
    IL_0011:  ldloc.0
    IL_0012:  call       class [WindowsBase]System.Windows.Threading.Dispatcher [WindowsBase]System.Windows.Threading.Dispatcher::get_CurrentDispatcher()
    IL_0017:  bne.un.s   IL_0020

    IL_0019:  ldarg.1
    IL_001a:  callvirt   instance void [mscorlib]System.Action::Invoke()
    IL_001f:  ret

    IL_0020:  ldloc.0
    IL_0021:  ldarg.1
    IL_0022:  call       !!0[] [mscorlib]System.Array::Empty<object>()
    IL_0027:  callvirt   instance class [WindowsBase]System.Windows.Threading.DispatcherOperation [WindowsBase]System.Windows.Threading.Dispatcher::BeginInvoke(class [mscorlib]System.Delegate,
                                                                                                                                                                object[])
    IL_002c:  pop
    IL_002d:  ret
  } // end of method MMEquipment_Specifications_ViewModel::RunInUIThread

  .method family hidebysig virtual instance void 
          OnUpdateData() cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0006:  brfalse.s  IL_000e

    IL_0008:  ldarg.0
    IL_0009:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::TryInitializeViewData()
    IL_000e:  ldarg.0
    IL_000f:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::OnUpdateData()
    IL_0014:  ret
  } // end of method MMEquipment_Specifications_ViewModel::OnUpdateData

  .method family hidebysig virtual instance void 
          OnViewChanged() cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::TryInitializeViewData()
    IL_0006:  ldarg.0
    IL_0007:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::OnViewChanged()
    IL_000c:  ret
  } // end of method MMEquipment_Specifications_ViewModel::OnViewChanged

  .method private hidebysig instance void 
          TryInitializeViewData() cil managed
  {
    // Code size       238 (0xee)
    .maxstack  3
    .locals init (string V_0,
             string V_1,
             string V_2,
             bool V_3)
    IL_0000:  ldarg.0
    IL_0001:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_CurrentUnits()
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_000d:  brfalse    IL_00ed

    IL_0012:  ldarg.0
    IL_0013:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_0018:  brfalse    IL_00ed

    IL_001d:  ldarg.0
    IL_001e:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_XmlConfiguration()
    IL_0023:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0028:  brfalse.s  IL_0063

    IL_002a:  ldarg.0
    IL_002b:  ldarg.0
    IL_002c:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::BuildXmlConfiguration()
    IL_0031:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::set_XmlConfiguration(string)
    IL_0036:  ldarg.0
    IL_0037:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_XmlConfiguration()
    IL_003c:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0041:  brtrue     IL_00ed

    IL_0046:  ldarg.0
    IL_0047:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_004c:  ldarg.0
    IL_004d:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0052:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_0057:  ldarg.0
    IL_0058:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_XmlConfiguration()
    IL_005d:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                            string)
    IL_0062:  ret

    IL_0063:  ldarg.0
    IL_0064:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::BuildXmlConfiguration()
    IL_0069:  stloc.1
    IL_006a:  ldarg.0
    IL_006b:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::GetCurrentUnits()
    IL_0070:  stloc.2
    IL_0071:  ldc.i4.0
    IL_0072:  stloc.3
    IL_0073:  ldloc.2
    IL_0074:  ldloc.0
    IL_0075:  ldc.i4.4
    IL_0076:  call       int32 [mscorlib]System.String::Compare(string,
                                                                string,
                                                                valuetype [mscorlib]System.StringComparison)
    IL_007b:  brfalse.s  IL_0086

    IL_007d:  ldc.i4.1
    IL_007e:  stloc.3
    IL_007f:  ldarg.0
    IL_0080:  ldloc.2
    IL_0081:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::set_CurrentUnits(string)
    IL_0086:  ldloc.1
    IL_0087:  ldarg.0
    IL_0088:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_XmlConfiguration()
    IL_008d:  call       int32 [mscorlib]System.String::CompareOrdinal(string,
                                                                       string)
    IL_0092:  ldc.i4.0
    IL_0093:  cgt.un
    IL_0095:  ldloc.3
    IL_0096:  or
    IL_0097:  brfalse.s  IL_00e2

    IL_0099:  ldarg.0
    IL_009a:  ldloc.1
    IL_009b:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::set_XmlConfiguration(string)
    IL_00a0:  ldarg.0
    IL_00a1:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_00a6:  ldarg.0
    IL_00a7:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_00ac:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_00b1:  ldsfld     string [mscorlib]System.String::Empty
    IL_00b6:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                            string)
    IL_00bb:  ldarg.0
    IL_00bc:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_00c1:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::RefreshData()
    IL_00c6:  ldarg.0
    IL_00c7:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_00cc:  ldarg.0
    IL_00cd:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_00d2:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_00d7:  ldarg.0
    IL_00d8:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_XmlConfiguration()
    IL_00dd:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                            string)
    IL_00e2:  ldarg.0
    IL_00e3:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_00e8:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::RefreshData()
    IL_00ed:  ret
  } // end of method MMEquipment_Specifications_ViewModel::TryInitializeViewData

  .method private hidebysig instance string 
          BuildXmlConfiguration() cil managed
  {
    // Code size       140 (0x8c)
    .maxstack  9
    .locals init (string V_0,
             string V_1,
             string V_2)
    IL_0000:  ldsfld     string [mscorlib]System.String::Empty
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldstr      "XMLObjFilter"
    IL_000c:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveParameter(string)
    IL_0011:  isinst     [mscorlib]System.String
    IL_0016:  ldstr      "Equipment"
    IL_001b:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0020:  brfalse.s  IL_0074

    IL_0022:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0027:  dup
    IL_0028:  ldarg.0
    IL_0029:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_ScopedId()
    IL_002e:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0033:  ldloca.s   V_1
    IL_0035:  call       string [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::GetBlockGridXML(class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                                               string&)
    IL_003a:  stloc.2
    IL_003b:  ldloc.1
    IL_003c:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0041:  brtrue.s   IL_006b

    IL_0043:  ldarg.0
    IL_0044:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
    IL_0049:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_004e:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_0053:  ldloc.1
    IL_0054:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_0059:  ldc.i4.0
    IL_005a:  ldc.i4.0
    IL_005b:  ldc.i4.0
    IL_005c:  ldc.i4.1
    IL_005d:  ldstr      "apwn.chm"
    IL_0062:  ldc.i4.m1
    IL_0063:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_0068:  pop
    IL_0069:  br.s       IL_0074

    IL_006b:  ldarg.0
    IL_006c:  ldloc.2
    IL_006d:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::AnalyzeEquipmentXml(string)
    IL_0072:  ldloc.2
    IL_0073:  stloc.0
    IL_0074:  ldloc.0
    IL_0075:  call       bool [mscorlib]System.String::IsNullOrWhiteSpace(string)
    IL_007a:  brtrue.s   IL_008a

    IL_007c:  ldarg.0
    IL_007d:  ldarg.0
    IL_007e:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::GetCurrentUnits()
    IL_0083:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::set_CurrentUnits(string)
    IL_0088:  ldloc.0
    IL_0089:  ret

    IL_008a:  ldnull
    IL_008b:  ret
  } // end of method MMEquipment_Specifications_ViewModel::BuildXmlConfiguration

  .method private hidebysig instance class [mscorlib]System.Collections.Generic.IEnumerable`1<string> 
          GetEquipmentsOnCurrentTab(string tabName) cil managed
  {
    // Code size       20 (0x14)
    .maxstack  3
    .locals init (class [mscorlib]System.Collections.Generic.List`1<string> V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<string>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_tabEquipmentsPair
    IL_0006:  ldarg.1
    IL_0007:  ldloca.s   V_0
    IL_0009:  callvirt   instance bool class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<string>>::TryGetValue(!0,
                                                                                                                                                                              !1&)
    IL_000e:  brfalse.s  IL_0012

    IL_0010:  ldloc.0
    IL_0011:  ret

    IL_0012:  ldnull
    IL_0013:  ret
  } // end of method MMEquipment_Specifications_ViewModel::GetEquipmentsOnCurrentTab

  .method private hidebysig instance void 
          AnalyzeEquipmentXml(string xml) cil managed
  {
    // Code size       328 (0x148)
    .maxstack  3
    .locals init (class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_0,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_1,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_2,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_3,
             class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_4,
             class [mscorlib]System.Collections.Generic.List`1<string> V_5,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement> V_6,
             class [System.Xml.Linq]System.Xml.Linq.XElement V_7)
    IL_0000:  ldarg.1
    IL_0001:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_allEquipments
    IL_000f:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Clear()
    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<string>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_tabEquipmentsPair
    IL_001a:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<string>>::Clear()
    IL_001f:  ldarg.1
    IL_0020:  call       class [System.Xml.Linq]System.Xml.Linq.XDocument [System.Xml.Linq]System.Xml.Linq.XDocument::Parse(string)
    IL_0025:  ldstr      ".//Tab"
    IL_002a:  call       class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.XPath.Extensions::XPathSelectElements(class [System.Xml.Linq]System.Xml.Linq.XNode,
                                                                                                                                                                                                     string)
    IL_002f:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::GetEnumerator()
    IL_0034:  stloc.0
    .try
    {
      IL_0035:  br         IL_0130

      IL_003a:  ldloc.0
      IL_003b:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::get_Current()
      IL_0040:  stloc.1
      IL_0041:  ldloc.1
      IL_0042:  ldstr      "Caption"
      IL_0047:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_004c:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XContainer::Element(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_0051:  stloc.2
      IL_0052:  ldloc.2
      IL_0053:  brfalse    IL_0130

      IL_0058:  ldloc.2
      IL_0059:  callvirt   instance string [System.Xml.Linq]System.Xml.Linq.XElement::get_Value()
      IL_005e:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
      IL_0063:  brtrue     IL_0130

      IL_0068:  ldloc.1
      IL_0069:  ldstr      "Rows"
      IL_006e:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
      IL_0073:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XContainer::Element(class [System.Xml.Linq]System.Xml.Linq.XName)
      IL_0078:  stloc.3
      IL_0079:  ldloc.3
      IL_007a:  brfalse    IL_0130

      IL_007f:  ldloc.3
      IL_0080:  ldstr      "./Row"
      IL_0085:  call       class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement> [System.Xml.Linq]System.Xml.XPath.Extensions::XPathSelectElements(class [System.Xml.Linq]System.Xml.Linq.XNode,
                                                                                                                                                                                                       string)
      IL_008a:  stloc.s    V_4
      IL_008c:  ldloc.s    V_4
      IL_008e:  brfalse    IL_0130

      IL_0093:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
      IL_0098:  stloc.s    V_5
      IL_009a:  ldloc.s    V_4
      IL_009c:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::GetEnumerator()
      IL_00a1:  stloc.s    V_6
      .try
      {
        IL_00a3:  br.s       IL_00dd

        IL_00a5:  ldloc.s    V_6
        IL_00a7:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [System.Xml.Linq]System.Xml.Linq.XElement>::get_Current()
        IL_00ac:  ldstr      "Name"
        IL_00b1:  call       class [System.Xml.Linq]System.Xml.Linq.XName [System.Xml.Linq]System.Xml.Linq.XName::op_Implicit(string)
        IL_00b6:  callvirt   instance class [System.Xml.Linq]System.Xml.Linq.XElement [System.Xml.Linq]System.Xml.Linq.XContainer::Element(class [System.Xml.Linq]System.Xml.Linq.XName)
        IL_00bb:  stloc.s    V_7
        IL_00bd:  ldloc.s    V_7
        IL_00bf:  brfalse.s  IL_00dd

        IL_00c1:  ldloc.s    V_7
        IL_00c3:  callvirt   instance string [System.Xml.Linq]System.Xml.Linq.XElement::get_Value()
        IL_00c8:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
        IL_00cd:  brtrue.s   IL_00dd

        IL_00cf:  ldloc.s    V_5
        IL_00d1:  ldloc.s    V_7
        IL_00d3:  callvirt   instance string [System.Xml.Linq]System.Xml.Linq.XElement::get_Value()
        IL_00d8:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
        IL_00dd:  ldloc.s    V_6
        IL_00df:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
        IL_00e4:  brtrue.s   IL_00a5

        IL_00e6:  leave.s    IL_00f4

      }  // end .try
      finally
      {
        IL_00e8:  ldloc.s    V_6
        IL_00ea:  brfalse.s  IL_00f3

        IL_00ec:  ldloc.s    V_6
        IL_00ee:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
        IL_00f3:  endfinally
      }  // end handler
      IL_00f4:  ldloc.s    V_5
      IL_00f6:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
      IL_00fb:  ldc.i4.0
      IL_00fc:  ble.s      IL_0130

      IL_00fe:  ldstr      "Equipment"
      IL_0103:  ldloc.2
      IL_0104:  callvirt   instance string [System.Xml.Linq]System.Xml.Linq.XElement::get_Value()
      IL_0109:  call       bool [mscorlib]System.String::Equals(string,
                                                                string)
      IL_010e:  brfalse.s  IL_011d

      IL_0110:  ldarg.0
      IL_0111:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_allEquipments
      IL_0116:  ldloc.s    V_5
      IL_0118:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::AddRange(class [mscorlib]System.Collections.Generic.IEnumerable`1<!0>)
      IL_011d:  ldarg.0
      IL_011e:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<string>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_tabEquipmentsPair
      IL_0123:  ldloc.2
      IL_0124:  callvirt   instance string [System.Xml.Linq]System.Xml.Linq.XElement::get_Value()
      IL_0129:  ldloc.s    V_5
      IL_012b:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<string>>::set_Item(!0,
                                                                                                                                                                             !1)
      IL_0130:  ldloc.0
      IL_0131:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_0136:  brtrue     IL_003a

      IL_013b:  leave.s    IL_0147

    }  // end .try
    finally
    {
      IL_013d:  ldloc.0
      IL_013e:  brfalse.s  IL_0146

      IL_0140:  ldloc.0
      IL_0141:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0146:  endfinally
    }  // end handler
    IL_0147:  ret
  } // end of method MMEquipment_Specifications_ViewModel::AnalyzeEquipmentXml

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<string>>::.ctor()
    IL_0006:  stfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<string>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_tabEquipmentsPair
    IL_000b:  ldarg.0
    IL_000c:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0011:  stfld      class [mscorlib]System.Collections.Generic.List`1<string> AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::_allEquipments
    IL_0016:  ldarg.0
    IL_0017:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_001c:  ret
  } // end of method MMEquipment_Specifications_ViewModel::.ctor

  .property instance callconv(8) class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView
          SummaryGridView()
  {
    .get instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SummaryGridView()
  } // end of property MMEquipment_Specifications_ViewModel::SummaryGridView
  .property instance callconv(8) string XmlConfiguration()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_XmlConfiguration()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::set_XmlConfiguration(string)
  } // end of property MMEquipment_Specifications_ViewModel::XmlConfiguration
  .property instance callconv(8) string CurrentUnits()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_CurrentUnits()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::set_CurrentUnits(string)
  } // end of property MMEquipment_Specifications_ViewModel::CurrentUnits
  .property instance callconv(8) string HierarchyScope()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_HierarchyScope()
  } // end of property MMEquipment_Specifications_ViewModel::HierarchyScope
  .property instance callconv(8) class AspenTech.AspenPlus.Happ.IHNode
          MainNode()
  {
    .get instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_MainNode()
  } // end of property MMEquipment_Specifications_ViewModel::MainNode
  .property instance callconv(8) string ScopedId()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_ScopedId()
  } // end of property MMEquipment_Specifications_ViewModel::ScopedId
  .property instance callconv(8) class [System]System.Windows.Input.ICommand
          SizeCommand()
  {
    .get instance class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_SizeCommand()
  } // end of property MMEquipment_Specifications_ViewModel::SizeCommand
  .property instance callconv(8) class [System]System.Windows.Input.ICommand
          EvaluateCommand()
  {
    .get instance class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel::get_EvaluateCommand()
  } // end of property MMEquipment_Specifications_ViewModel::EvaluateCommand
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView,
                  [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 28 4D 4D 53 75 6D 6D 61 72 79 47 72 69 64   // ..(MMSummaryGrid
                                                                                                    2E 4D 4D 45 71 75 69 70 6D 65 6E 74 5F 53 70 65   // .MMEquipment_Spe
                                                                                                    63 69 66 69 63 61 74 69 6F 6E 73 00 00 )          // cifications..
  .field private initonly class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid _summaryGrid
  .field private static literal string _CEconAnalysisGrid = "Econ"
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton buttonSize
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton buttonEvaluate
  .field assembly class [PresentationFramework]System.Windows.Controls.Border Border1
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       92 (0x5c)
    .maxstack  3
    .locals init ()
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::InitializeComponent()
    IL_001c:  ldarg.0
    IL_001d:  newobj     instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::.ctor()
    IL_0022:  stfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0027:  ldarg.0
    IL_0028:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_002d:  ldarg.0
    IL_002e:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid_OnSummaryGridTplColChange(object,
                                                                                                                                                  class [mscorlib]System.EventArgs)
    IL_0034:  newobj     instance void [mscorlib]System.EventHandler::.ctor(object,
                                                                            native int)
    IL_0039:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::add_OnSummaryGridTplColChange(class [mscorlib]System.EventHandler)
    IL_003e:  ldarg.0
    IL_003f:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0044:  ldc.i4.1
    IL_0045:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_UseProvidedRowInfo(bool)
    IL_004a:  ldarg.0
    IL_004b:  ldfld      class [PresentationFramework]System.Windows.Controls.Border AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::Border1
    IL_0050:  ldarg.0
    IL_0051:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0056:  callvirt   instance void [PresentationFramework]System.Windows.Controls.Decorator::set_Child(class [PresentationCore]System.Windows.UIElement)
    IL_005b:  ret
  } // end of method MMEquipment_Specifications::.ctor

  .method private hidebysig instance void 
          _summaryGrid_OnSummaryGridTplColChange(object sender,
                                                 class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       17 (0x11)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0006:  ldstr      "Econ"
    IL_000b:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::SaveTemplatesToCase(string)
    IL_0010:  ret
  } // end of method MMEquipment_Specifications::_summaryGrid_OnSummaryGridTplColChange

  .method private hidebysig newslot specialname virtual final 
          instance string[]  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedRows() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0006:  callvirt   instance string[] [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::get_SelectedRows()
    IL_000b:  ret
  } // end of method MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedRows

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedTab() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0006:  callvirt   instance string [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::get_SelectedTab()
    IL_000b:  ret
  } // end of method MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedTab

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_SelectedTab(string 'value') cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::set_SelectedTab
    // Code size       18 (0x12)
    .maxstack  2
    .locals init ()
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
      IL_0006:  ldarg.1
      IL_0007:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_SelectedTab(string)
      IL_000c:  leave.s    IL_0011

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_000e:  pop
      IL_000f:  leave.s    IL_0011

    }  // end handler
    IL_0011:  ret
  } // end of method MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_SelectedTab

  .method private hidebysig newslot specialname virtual final 
          instance bool  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_IsVisible() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_IsVisible
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0006:  callvirt   instance bool [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::get_Visible()
    IL_000b:  ret
  } // end of method MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_IsVisible

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_IsVisible(bool 'value') cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::set_IsVisible
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_Visible(bool)
    IL_000c:  ret
  } // end of method MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_IsVisible

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase cxsCase,
                                                                                             string configurationXml) cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize
    // Code size       98 (0x62)
    .maxstack  3
    .locals init ()
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::get_ApplicationName()
    IL_000c:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_ApplicationName(string)
    IL_0011:  ldarg.0
    IL_0012:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0017:  ldarg.1
    IL_0018:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_Case(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_001d:  ldarg.0
    IL_001e:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0023:  ldstr      "Econ"
    IL_0028:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::SetTemplatesFromCase(string)
    IL_002d:  ldarg.0
    IL_002e:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0033:  ldarg.1
    IL_0034:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::get_CaseFullFilePath()
    IL_0039:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_CasePath(string)
    IL_003e:  ldarg.0
    IL_003f:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0044:  ldarg.2
    IL_0045:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_Configuration(string)
    IL_004a:  ldarg.0
    IL_004b:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0050:  ldarg.0
    IL_0051:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid_OnBatchSet(object,
                                                                                                                                   class [mscorlib]System.EventArgs)
    IL_0057:  newobj     instance void [mscorlib]System.EventHandler::.ctor(object,
                                                                            native int)
    IL_005c:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::add_OnBatchSet(class [mscorlib]System.EventHandler)
    IL_0061:  ret
  } // end of method MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.Initialize

  .method private hidebysig instance void 
          _summaryGrid_OnBatchSet(object sender,
                                  class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::OnUpdateAll()
    IL_0006:  ret
  } // end of method MMEquipment_Specifications::_summaryGrid_OnBatchSet

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.RefreshData() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::RefreshData
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0006:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::RefreshData()
    IL_000b:  ret
  } // end of method MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.RefreshData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.CopyToClipboard() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::CopyToClipboard
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_summaryGrid
    IL_0006:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::CopyToClipboard()
    IL_000b:  ret
  } // end of method MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.CopyToClipboard

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.SummaryGrid;component"
    + "/mmequipment_specifications.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMEquipment_Specifications::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       69 (0x45)
    .maxstack  2
    .locals init ()
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_0016,
                          IL_0023,
                          IL_0030)
    IL_0014:  br.s       IL_003d

    IL_0016:  ldarg.0
    IL_0017:  ldarg.2
    IL_0018:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_001d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::buttonSize
    IL_0022:  ret

    IL_0023:  ldarg.0
    IL_0024:  ldarg.2
    IL_0025:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_002a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::buttonEvaluate
    IL_002f:  ret

    IL_0030:  ldarg.0
    IL_0031:  ldarg.2
    IL_0032:  castclass  [PresentationFramework]System.Windows.Controls.Border
    IL_0037:  stfld      class [PresentationFramework]System.Windows.Controls.Border AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::Border1
    IL_003c:  ret

    IL_003d:  ldarg.0
    IL_003e:  ldc.i4.1
    IL_003f:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::_contentLoaded
    IL_0044:  ret
  } // end of method MMEquipment_Specifications::System.Windows.Markup.IComponentConnector.Connect

  .property instance callconv(8) string[]
          AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedRows()
  {
    .get instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedRows()
  } // end of property MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedRows
  .property instance callconv(8) string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedTab()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedTab()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_SelectedTab(string)
  } // end of property MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedTab
  .property instance callconv(8) bool AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.IsVisible()
  {
    .get instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_IsVisible()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_IsVisible(bool)
  } // end of property MMEquipment_Specifications::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.IsVisible
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.MMEquipment_Specifications

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .class auto ansi sealed nested public ConstString
         extends [mscorlib]System.Enum
  {
    .field public specialname rtspecialname int32 value__
    .field public static literal valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString TabNameDesignSpec = int32(0x00000000)
    .field public static literal valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString TabNameUtilities = int32(0x00000001)
    .field public static literal valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString ParameterNameXmlContext = int32(0x00000002)
    .field public static literal valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString ParameterNameSgType = int32(0x00000003)
    .field public static literal valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString ParameterNameSgModelType = int32(0x00000004)
    .field public static literal valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString ParameterNameXmlFilter = int32(0x00000005)
    .field public static literal valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString SgTypeOfBlock = int32(0x00000006)
    .field public static literal valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString XmlFilterOfUnitOperation = int32(0x00000007)
    .field public static literal valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString XmlFilterOfEquipment = int32(0x00000008)
  } // end of class ConstString

  .class abstract auto ansi sealed nested private beforefieldinit '<>o__122'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> '<>p__0'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> '<>p__1'
  } // end of class '<>o__122'

  .class abstract auto ansi sealed nested private beforefieldinit '<>o__123'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> '<>p__0'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> '<>p__1'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> '<>p__2'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> '<>p__3'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> '<>p__4'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> '<>p__5'
  } // end of class '<>o__123'

  .class abstract auto ansi sealed nested private beforefieldinit '<>o__131'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> '<>p__0'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> '<>p__1'
  } // end of class '<>o__131'

  .class abstract auto ansi sealed nested private beforefieldinit '<>o__132'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> '<>p__0'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> '<>p__1'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> '<>p__2'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> '<>p__3'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> '<>p__4'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> '<>p__5'
  } // end of class '<>o__132'

  .field private static literal string TabNameDesignSpec = "Design-Spec"
  .field private static literal string TabNameUtilities = "Utilities"
  .field private static literal string ParameterNameXmlContext = "XMLContext"
  .field private static literal string ParameterNameSgType = "SGType"
  .field private static literal string ParameterNameSgModelType = "SGModelType"
  .field private static literal string ParameterNameXmlFilter = "XMLObjFilter"
  .field private static literal string SgTypeOfBlock = "Block"
  .field private static literal string XmlFilterOfUnitOperation = "UnitOpt"
  .field private static literal string XmlFilterOfEquipment = "Equipment"
  .field private static literal int32 HINT_UPDATE_FORMS_ONLY = int32(0x000000C9)
  .field private static literal int32 HINT_UPDATE_BROWSER = int32(0x000000CA)
  .field private static literal int32 HINT_UPDATE_STATUS = int32(0x000000CB)
  .field private static literal int32 HINT_UPDATE_STORE = int32(0x000000CC)
  .field private static literal int32 HINT_UPDATE_DELETEBLOCK = int32(0x000000CD)
  .field private static literal int32 HINT_UPDATE_DELETESTREAM = int32(0x000000CE)
  .field private static literal int32 HINT_UPDATE_RENAMEBLOCK = int32(0x000000CF)
  .field private static literal int32 HINT_UPDATE_RENAMESTREAM = int32(0x000000D0)
  .field private static literal int32 HINT_UPDATE_RUN_OPERATION = int32(0x000000D3)
  .field private static literal int32 HINT_UPDATE_RUNSTEP = int32(0x000000D4)
  .field private static literal int32 HINT_UPDATE_COMPLETION = int32(0x000000D5)
  .field private static literal int32 HINT_UPDATE_REINIT = int32(0x000000D6)
  .field private static literal int32 HINT_UPDATE_PFD_INDICATOR = int32(0x000000D7)
  .field private static literal int32 HINT_UPDATE_TREE = int32(0x000000D8)
  .field private static literal int32 HINT_HOLD_INIT = int32(0x000000D9)
  .field private static literal int32 HINT_HOLD_FINISH = int32(0x000000DA)
  .field private static literal int32 HINT_UPDATE_HIDEDELETE = int32(0x000000DB)
  .field private static literal int32 HINT_UPDATE_ROWREMOVED = int32(0x000000DC)
  .field private static literal int32 HINT_UPDATE_LIBRARY = int32(0x000000DD)
  .field private static literal int32 HINT_UPDATE_CATEGORY = int32(0x000000DE)
  .field private static literal int32 HINT_UPDATE_CHILDCHANGED = int32(0x000000DF)
  .field private static literal int32 HINT_UPDATE_STORE_VALUE = int32(0x000000E0)
  .field private static literal int32 HINT_PFS_DEACTIVATE = int32(0x000000E1)
  .field private static literal int32 HINT_PFS_REMOVEALLSTOPS = int32(0x000000E2)
  .field private static literal int32 HINT_PFS_REMOVEBIRDCAGE = int32(0x000000E3)
  .field private static literal int32 HINT_PFS_SELECTMODE = int32(0x000000E4)
  .field private static literal int32 HINT_PFS_BKPREADER = int32(0x000000E5)
  .field private static literal int32 HINT_PFS_ANIMATEBLOCK = int32(0x000000E6)
  .field private static literal int32 HINT_TITLE_CHANGED = int32(0x000000E7)
  .field private static literal int32 HINT_PFS_CLEARSELECTION = int32(0x000000E8)
  .field private static literal int32 HINT_PFS_ADDSELECTION = int32(0x000000E9)
  .field private static literal int32 HINT_UPDATE_RUNCLASS = int32(0x000000EA)
  .field private static literal int32 HINT_THREADMODAL_BEGIN = int32(0x000000EB)
  .field private static literal int32 HINT_THREADMODAL_ENDED = int32(0x000000EC)
  .field private static literal int32 HINT_UPDATE_PATHNAME = int32(0x000000ED)
  .field private static literal int32 HINT_COMPONENT_CHANGED = int32(0x000000FA)
  .field private static literal int32 HINT_PROPERTY_CHANGED = int32(0x000000FB)
  .field private static literal int32 HINT_PARAM_CHANGED = int32(0x000000FC)
  .field private static literal int32 HINT_SIMULATION_ENDED = int32(0x000000FD)
  .field private static literal int32 HINT_KERNEL_UPDATE = int32(0x0000012D)
  .field private static literal int32 HINT_EO_REFRESH = int32(0x0000012E)
  .field private static literal int32 HINT_ASC_NEWEVENT = int32(0x0000012F)
  .field private static literal int32 HINT_RELEASE_POINTERS = int32(0x00000130)
  .field private static literal int32 HINT_STYLESHEET_UPDATE = int32(0x00000131)
  .field private static literal int32 HINT_REFRESH_POINTERS = int32(0x00000132)
  .field private class AspenTech.AspenPlus.Happ.HappLS '<EventAttachedHappLS>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase '<EventAttachedCase>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<XmlConfiguration>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<CurrentUnits>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string _hierarchyScope
  .field private class AspenTech.AspenPlus.Happ.IHNode _mainNode
  .field private bool '<HasFlagForLoading>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class [mscorlib]System.Action _equipmentCallbackDelegate
  .field private class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior _copyBehavior
  .field private class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior _mapBehavior
  .field private class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior _unmapBehavior
  .field private class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior _openFormBehavior
  .field private class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior _sizeBehavior
  .field private class [WindowsBase]System.Windows.Threading.DispatcherTimer _dispatcherTimer
  .field private class [WindowsBase]System.Windows.Threading.DispatcherTimer _dispatcherTimer_evaluate
  .field private class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior _evaluateBehavior
  .field private valuetype [PresentationCore]System.Windows.Visibility '<APEABannerVisibility>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method family hidebysig specialname instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView 
          get_SummaryGridView() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance object [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::get_View()
    IL_0006:  isinst     AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView
    IL_000b:  ret
  } // end of method MMSummaryGridFormViewModel::get_SummaryGridView

  .method family hidebysig specialname instance class AspenTech.AspenPlus.Happ.HappLS 
          get_EventAttachedHappLS() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.HappLS AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<EventAttachedHappLS>k__BackingField'
    IL_0006:  ret
  } // end of method MMSummaryGridFormViewModel::get_EventAttachedHappLS

  .method private hidebysig specialname instance void 
          set_EventAttachedHappLS(class AspenTech.AspenPlus.Happ.HappLS 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.AspenPlus.Happ.HappLS AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<EventAttachedHappLS>k__BackingField'
    IL_0007:  ret
  } // end of method MMSummaryGridFormViewModel::set_EventAttachedHappLS

  .method family hidebysig specialname instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase 
          get_EventAttachedCase() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<EventAttachedCase>k__BackingField'
    IL_0006:  ret
  } // end of method MMSummaryGridFormViewModel::get_EventAttachedCase

  .method private hidebysig specialname instance void 
          set_EventAttachedCase(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<EventAttachedCase>k__BackingField'
    IL_0007:  ret
  } // end of method MMSummaryGridFormViewModel::set_EventAttachedCase

  .method family hidebysig specialname instance string 
          get_XmlConfiguration() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<XmlConfiguration>k__BackingField'
    IL_0006:  ret
  } // end of method MMSummaryGridFormViewModel::get_XmlConfiguration

  .method private hidebysig specialname instance void 
          set_XmlConfiguration(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<XmlConfiguration>k__BackingField'
    IL_0007:  ret
  } // end of method MMSummaryGridFormViewModel::set_XmlConfiguration

  .method family hidebysig specialname instance string 
          get_CurrentUnits() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<CurrentUnits>k__BackingField'
    IL_0006:  ret
  } // end of method MMSummaryGridFormViewModel::get_CurrentUnits

  .method private hidebysig specialname instance void 
          set_CurrentUnits(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<CurrentUnits>k__BackingField'
    IL_0007:  ret
  } // end of method MMSummaryGridFormViewModel::set_CurrentUnits

  .method public hidebysig specialname instance native int 
          get_CurrentWindowPointer() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldc.i4.0
    IL_0001:  newobj     instance void [mscorlib]System.IntPtr::.ctor(int32)
    IL_0006:  ret
  } // end of method MMSummaryGridFormViewModel::get_CurrentWindowPointer

  .method public hidebysig specialname instance string 
          get_HierarchyScope() cil managed
  {
    // Code size       54 (0x36)
    .maxstack  3
    .locals init (object V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_hierarchyScope
    IL_0006:  brtrue.s   IL_002f

    IL_0008:  ldarg.0
    IL_0009:  call       instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_MainNode()
    IL_000e:  brfalse.s  IL_002f

    IL_0010:  ldarg.0
    IL_0011:  call       instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_MainNode()
    IL_0016:  ldc.i4.s   76
    IL_0018:  ldsfld     object [mscorlib]System.Type::Missing
    IL_001d:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_AttributeValue(int16,
                                                                                             object)
    IL_0022:  stloc.0
    IL_0023:  ldarg.0
    IL_0024:  ldloc.0
    IL_0025:  isinst     [mscorlib]System.String
    IL_002a:  stfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_hierarchyScope
    IL_002f:  ldarg.0
    IL_0030:  ldfld      string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_hierarchyScope
    IL_0035:  ret
  } // end of method MMSummaryGridFormViewModel::get_HierarchyScope

  .method public hidebysig specialname instance class AspenTech.AspenPlus.Happ.IHNode 
          get_MainNode() cil managed
  {
    // Code size       82 (0x52)
    .maxstack  8
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_mainNode
    IL_0006:  brtrue.s   IL_004b

    IL_0008:  ldarg.0
    IL_0009:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_000e:  brfalse.s  IL_004b

    IL_0010:  ldarg.0
    IL_0011:  ldstr      "@main"
    IL_0016:  call       instance string [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ExpandDataPath(string)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldarg.0
    IL_001e:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0023:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_0028:  ldstr      "Top.appModelV8.Custom Actions"
    IL_002d:  ldstr      "HappNode"
    IL_0032:  ldc.i4.1
    IL_0033:  newarr     [mscorlib]System.Object
    IL_0038:  dup
    IL_0039:  ldc.i4.0
    IL_003a:  ldloc.0
    IL_003b:  stelem.ref
    IL_003c:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::InvokeAction(string,
                                                                                                      string,
                                                                                                      object[])
    IL_0041:  isinst     AspenTech.AspenPlus.Happ.IHNode
    IL_0046:  stfld      class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_mainNode
    IL_004b:  ldarg.0
    IL_004c:  ldfld      class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_mainNode
    IL_0051:  ret
  } // end of method MMSummaryGridFormViewModel::get_MainNode

  .method public hidebysig specialname instance string 
          get_ScopedId() cil managed
  {
    // Code size       52 (0x34)
    .maxstack  3
    .locals init (string V_0,
             string V_1)
    IL_0000:  ldarg.0
    IL_0001:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_HierarchyScope()
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldstr      "@main"
    IL_000d:  ldstr      "id"
    IL_0012:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ExpandDataPathAndGet(string,
                                                                                                                                             string)
    IL_0017:  isinst     [mscorlib]System.String
    IL_001c:  stloc.1
    IL_001d:  ldloc.0
    IL_001e:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0023:  brfalse.s  IL_0027

    IL_0025:  ldloc.1
    IL_0026:  ret

    IL_0027:  ldloc.0
    IL_0028:  ldstr      "."
    IL_002d:  ldloc.1
    IL_002e:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0033:  ret
  } // end of method MMSummaryGridFormViewModel::get_ScopedId

  .method assembly hidebysig instance string 
          GetSingleObjectToDisplay() cil managed
  {
    // Code size       56 (0x38)
    .maxstack  2
    .locals init (string V_0,
             string V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "SGType"
    IL_0006:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveParameter(string)
    IL_000b:  isinst     [mscorlib]System.String
    IL_0010:  stloc.0
    IL_0011:  ldstr      "Block"
    IL_0016:  ldloc.0
    IL_0017:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_001c:  brfalse.s  IL_0036

    IL_001e:  ldarg.0
    IL_001f:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_ScopedId()
    IL_0024:  stloc.1
    IL_0025:  ldloc.1
    IL_0026:  ldstr      "Results Summary"
    IL_002b:  call       bool [mscorlib]System.String::Equals(string,
                                                              string)
    IL_0030:  brtrue.s   IL_0034

    IL_0032:  ldloc.1
    IL_0033:  ret

    IL_0034:  ldnull
    IL_0035:  ret

    IL_0036:  ldnull
    IL_0037:  ret
  } // end of method MMSummaryGridFormViewModel::GetSingleObjectToDisplay

  .method private hidebysig instance void 
          UpdateVisibilities() cil managed
  {
    // Code size       312 (0x138)
    .maxstack  2
    .locals init (string V_0,
             string V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "SGType"
    IL_0006:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveParameter(string)
    IL_000b:  isinst     [mscorlib]System.String
    IL_0010:  stloc.0
    IL_0011:  ldstr      "Block"
    IL_0016:  ldloc.0
    IL_0017:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_001c:  brfalse.s  IL_006e

    IL_001e:  ldarg.0
    IL_001f:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SizeBehavior()
    IL_0024:  ldc.i4.2
    IL_0025:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_002a:  ldarg.0
    IL_002b:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_EvaluateBehavior()
    IL_0030:  ldc.i4.2
    IL_0031:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_0036:  ldarg.0
    IL_0037:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_CopyBehavior()
    IL_003c:  ldc.i4.0
    IL_003d:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_0042:  ldarg.0
    IL_0043:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_MapBehavior()
    IL_0048:  ldc.i4.2
    IL_0049:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_004e:  ldarg.0
    IL_004f:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_UnmapBehavior()
    IL_0054:  ldc.i4.2
    IL_0055:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_005a:  ldarg.0
    IL_005b:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_OpenFormBehavior()
    IL_0060:  ldc.i4.0
    IL_0061:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_0066:  ldarg.0
    IL_0067:  ldc.i4.2
    IL_0068:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_APEABannerVisibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_006d:  ret

    IL_006e:  ldstr      ""
    IL_0073:  stloc.1
    IL_0074:  ldarg.0
    IL_0075:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_007a:  brfalse.s  IL_008d

    IL_007c:  ldarg.0
    IL_007d:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0082:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab()
    IL_0087:  callvirt   instance string [mscorlib]System.String::ToUpper()
    IL_008c:  stloc.1
    IL_008d:  ldloc.1
    IL_008e:  ldstr      "SUMMARY"
    IL_0093:  callvirt   instance bool [mscorlib]System.String::Equals(string)
    IL_0098:  brtrue.s   IL_00ce

    IL_009a:  ldloc.1
    IL_009b:  ldstr      "UTILITIES"
    IL_00a0:  callvirt   instance bool [mscorlib]System.String::Equals(string)
    IL_00a5:  brtrue.s   IL_00ce

    IL_00a7:  ldloc.1
    IL_00a8:  ldstr      "UNIT OPERATION"
    IL_00ad:  callvirt   instance bool [mscorlib]System.String::Equals(string)
    IL_00b2:  brtrue.s   IL_00ce

    IL_00b4:  ldloc.1
    IL_00b5:  ldstr      "EQUIPMENT"
    IL_00ba:  callvirt   instance bool [mscorlib]System.String::Equals(string)
    IL_00bf:  brtrue.s   IL_00ce

    IL_00c1:  ldloc.1
    IL_00c2:  ldstr      ""
    IL_00c7:  callvirt   instance bool [mscorlib]System.String::Equals(string)
    IL_00cc:  brfalse.s  IL_00e8

    IL_00ce:  ldarg.0
    IL_00cf:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SizeBehavior()
    IL_00d4:  ldc.i4.2
    IL_00d5:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_00da:  ldarg.0
    IL_00db:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_EvaluateBehavior()
    IL_00e0:  ldc.i4.2
    IL_00e1:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_00e6:  br.s       IL_0100

    IL_00e8:  ldarg.0
    IL_00e9:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SizeBehavior()
    IL_00ee:  ldc.i4.0
    IL_00ef:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_00f4:  ldarg.0
    IL_00f5:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_EvaluateBehavior()
    IL_00fa:  ldc.i4.0
    IL_00fb:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_0100:  ldarg.0
    IL_0101:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_CopyBehavior()
    IL_0106:  ldc.i4.2
    IL_0107:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_010c:  ldarg.0
    IL_010d:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_MapBehavior()
    IL_0112:  ldc.i4.2
    IL_0113:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_0118:  ldarg.0
    IL_0119:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_UnmapBehavior()
    IL_011e:  ldc.i4.2
    IL_011f:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_0124:  ldarg.0
    IL_0125:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_OpenFormBehavior()
    IL_012a:  ldc.i4.2
    IL_012b:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::set_Visibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_0130:  ldarg.0
    IL_0131:  ldc.i4.0
    IL_0132:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_APEABannerVisibility(valuetype [PresentationCore]System.Windows.Visibility)
    IL_0137:  ret
  } // end of method MMSummaryGridFormViewModel::UpdateVisibilities

  .method family hidebysig virtual instance void 
          OnUpdateData() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  call       bool [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.MmgSor::SolverThreadIsActive()
    IL_0005:  brtrue.s   IL_001b

    IL_0007:  ldarg.0
    IL_0008:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_000d:  brfalse.s  IL_001b

    IL_000f:  ldarg.0
    IL_0010:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::UpdateVisibilities()
    IL_0015:  ldarg.0
    IL_0016:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::TryInitializeViewData()
    IL_001b:  ldarg.0
    IL_001c:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::OnUpdateData()
    IL_0021:  ret
  } // end of method MMSummaryGridFormViewModel::OnUpdateData

  .method family hidebysig virtual instance void 
          OnViewChanged() cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::TryInitializeViewData()
    IL_0006:  ldarg.0
    IL_0007:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::OnViewChanged()
    IL_000c:  ret
  } // end of method MMSummaryGridFormViewModel::OnViewChanged

  .method public hidebysig specialname instance bool 
          get_HasFlagForLoading() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<HasFlagForLoading>k__BackingField'
    IL_0006:  ret
  } // end of method MMSummaryGridFormViewModel::get_HasFlagForLoading

  .method private hidebysig specialname instance void 
          set_HasFlagForLoading(bool 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<HasFlagForLoading>k__BackingField'
    IL_0007:  ret
  } // end of method MMSummaryGridFormViewModel::set_HasFlagForLoading

  .method public hidebysig instance void 
          TryInitializeViewData() cil managed
  {
    // Code size       314 (0x13a)
    .maxstack  3
    .locals init (class AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm V_0,
             string V_1,
             string V_2,
             string V_3,
             bool V_4,
             string V_5)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0006:  isinst     AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm
    IL_000b:  stloc.0
    IL_000c:  ldloc.0
    IL_000d:  brfalse.s  IL_0026

    IL_000f:  ldloc.0
    IL_0010:  callvirt   instance bool [PresentationFramework]System.Windows.FrameworkElement::get_IsLoaded()
    IL_0015:  brtrue.s   IL_001f

    IL_0017:  ldarg.0
    IL_0018:  ldc.i4.1
    IL_0019:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_HasFlagForLoading(bool)
    IL_001e:  ret

    IL_001f:  ldarg.0
    IL_0020:  ldc.i4.0
    IL_0021:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_HasFlagForLoading(bool)
    IL_0026:  ldarg.0
    IL_0027:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_CurrentUnits()
    IL_002c:  stloc.1
    IL_002d:  ldarg.0
    IL_002e:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0033:  brfalse    IL_0139

    IL_0038:  ldarg.0
    IL_0039:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_003e:  brfalse    IL_0139

    IL_0043:  ldarg.0
    IL_0044:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_XmlConfiguration()
    IL_0049:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_004e:  brfalse.s  IL_0089

    IL_0050:  ldarg.0
    IL_0051:  ldarg.0
    IL_0052:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::BuildXmlConfiguration()
    IL_0057:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_XmlConfiguration(string)
    IL_005c:  ldarg.0
    IL_005d:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_XmlConfiguration()
    IL_0062:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0067:  brtrue     IL_0139

    IL_006c:  ldarg.0
    IL_006d:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0072:  ldarg.0
    IL_0073:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0078:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_007d:  ldarg.0
    IL_007e:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_XmlConfiguration()
    IL_0083:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                            string)
    IL_0088:  ret

    IL_0089:  ldarg.0
    IL_008a:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::BuildXmlConfiguration()
    IL_008f:  stloc.2
    IL_0090:  ldarg.0
    IL_0091:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::GetCurrentUnits()
    IL_0096:  stloc.3
    IL_0097:  ldc.i4.0
    IL_0098:  stloc.s    V_4
    IL_009a:  ldloc.3
    IL_009b:  ldloc.1
    IL_009c:  ldc.i4.4
    IL_009d:  call       int32 [mscorlib]System.String::Compare(string,
                                                                string,
                                                                valuetype [mscorlib]System.StringComparison)
    IL_00a2:  brfalse.s  IL_00ae

    IL_00a4:  ldc.i4.1
    IL_00a5:  stloc.s    V_4
    IL_00a7:  ldarg.0
    IL_00a8:  ldloc.3
    IL_00a9:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_CurrentUnits(string)
    IL_00ae:  ldloc.2
    IL_00af:  ldarg.0
    IL_00b0:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_XmlConfiguration()
    IL_00b5:  call       int32 [mscorlib]System.String::CompareOrdinal(string,
                                                                       string)
    IL_00ba:  ldc.i4.0
    IL_00bb:  cgt.un
    IL_00bd:  ldloc.s    V_4
    IL_00bf:  or
    IL_00c0:  brfalse.s  IL_012e

    IL_00c2:  ldarg.0
    IL_00c3:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_00c8:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab()
    IL_00cd:  stloc.s    V_5
    IL_00cf:  ldarg.0
    IL_00d0:  ldloc.2
    IL_00d1:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_XmlConfiguration(string)
    IL_00d6:  ldarg.0
    IL_00d7:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_00dc:  ldarg.0
    IL_00dd:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_00e2:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_00e7:  ldsfld     string [mscorlib]System.String::Empty
    IL_00ec:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                            string)
    IL_00f1:  ldarg.0
    IL_00f2:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_00f7:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::RefreshData()
    IL_00fc:  ldarg.0
    IL_00fd:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0102:  ldarg.0
    IL_0103:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0108:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_010d:  ldarg.0
    IL_010e:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_XmlConfiguration()
    IL_0113:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                            string)
    IL_0118:  ldloc.s    V_5
    IL_011a:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_011f:  brtrue.s   IL_012e

    IL_0121:  ldarg.0
    IL_0122:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0127:  ldloc.s    V_5
    IL_0129:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::set_SelectedTab(string)
    IL_012e:  ldarg.0
    IL_012f:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0134:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::RefreshData()
    IL_0139:  ret
  } // end of method MMSummaryGridFormViewModel::TryInitializeViewData

  .method private hidebysig instance string 
          BuildXmlConfiguration() cil managed
  {
    // Code size       476 (0x1dc)
    .maxstack  9
    .locals init (string V_0,
             string V_1,
             string V_2,
             string V_3,
             string V_4,
             string V_5,
             class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>> V_6,
             int32 V_7,
             string V_8,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string> V_9,
             string V_10,
             string V_11,
             string V_12)
    IL_0000:  ldsfld     string [mscorlib]System.String::Empty
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldstr      "XMLObjFilter"
    IL_000c:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveParameter(string)
    IL_0011:  isinst     [mscorlib]System.String
    IL_0016:  stloc.1
    IL_0017:  ldloc.1
    IL_0018:  ldstr      "UnitOpt"
    IL_001d:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0022:  brfalse    IL_0171

    IL_0027:  ldarg.0
    IL_0028:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_ScopedId()
    IL_002d:  stloc.2
    IL_002e:  ldarg.0
    IL_002f:  ldstr      "@main"
    IL_0034:  ldstr      "type"
    IL_0039:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ExpandDataPathAndGet(string,
                                                                                                                                             string)
    IL_003e:  isinst     [mscorlib]System.String
    IL_0043:  stloc.3
    IL_0044:  ldloc.2
    IL_0045:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_004a:  brtrue.s   IL_007b

    IL_004c:  ldloc.3
    IL_004d:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0052:  brtrue.s   IL_007b

    IL_0054:  ldloc.2
    IL_0055:  ldstr      "Results Summary"
    IL_005a:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_005f:  brtrue.s   IL_007b

    IL_0061:  ldloc.3
    IL_0062:  ldstr      "RECDEF"
    IL_0067:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_006c:  brtrue.s   IL_007b

    IL_006e:  ldloc.2
    IL_006f:  ldloc.3
    IL_0070:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::DoBlockSummary2(string,
                                                                                                            string)
    IL_0075:  stloc.0
    IL_0076:  br         IL_01c4

    IL_007b:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::DoBlockSummary()
    IL_0080:  stloc.0
    IL_0081:  ldarg.0
    IL_0082:  ldstr      "@main"
    IL_0087:  call       instance string [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ExpandDataPath(string)
    IL_008c:  stloc.s    V_4
    IL_008e:  ldloc.s    V_4
    IL_0090:  ldstr      "Results Summary"
    IL_0095:  ldstr      "Blocks."
    IL_009a:  callvirt   instance string [mscorlib]System.String::Replace(string,
                                                                          string)
    IL_009f:  stloc.s    V_4
    IL_00a1:  ldloc.s    V_4
    IL_00a3:  stloc.s    V_5
    IL_00a5:  call       class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>> [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::MDFindBlocks()
    IL_00aa:  stloc.s    V_6
    IL_00ac:  ldc.i4.0
    IL_00ad:  stloc.s    V_7
    IL_00af:  br         IL_0161

    IL_00b4:  ldloc.s    V_6
    IL_00b6:  ldloc.s    V_7
    IL_00b8:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::get_Item(int32)
    IL_00bd:  stloc.s    V_9
    IL_00bf:  ldloca.s   V_9
    IL_00c1:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>::get_Value()
    IL_00c6:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_00cb:  stloc.s    V_8
    IL_00cd:  ldloc.s    V_8
    IL_00cf:  ldstr      "ELECTROLYZER"
    IL_00d4:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00d9:  brtrue.s   IL_00e9

    IL_00db:  ldloc.s    V_8
    IL_00dd:  ldstr      "MAKEUP"
    IL_00e2:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00e7:  brfalse.s  IL_015b

    IL_00e9:  ldloc.s    V_6
    IL_00eb:  ldloc.s    V_7
    IL_00ed:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IList`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::get_Item(int32)
    IL_00f2:  stloc.s    V_9
    IL_00f4:  ldloca.s   V_9
    IL_00f6:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>::get_Key()
    IL_00fb:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_0100:  stloc.s    V_10
    IL_0102:  ldloc.s    V_10
    IL_0104:  ldc.i4.s   46
    IL_0106:  call       bool [System.Core]System.Linq.Enumerable::Contains<char>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                  !!0)
    IL_010b:  brfalse.s  IL_0120

    IL_010d:  ldloc.s    V_10
    IL_010f:  ldstr      "."
    IL_0114:  ldstr      ".Data.Blocks."
    IL_0119:  callvirt   instance string [mscorlib]System.String::Replace(string,
                                                                          string)
    IL_011e:  stloc.s    V_10
    IL_0120:  ldloc.s    V_4
    IL_0122:  ldloc.s    V_10
    IL_0124:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0129:  stloc.s    V_5
    IL_012b:  ldarg.0
    IL_012c:  ldarg.0
    IL_012d:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0132:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_0137:  ldstr      "Top.appModelV8.Custom Actions"
    IL_013c:  ldstr      "HappNode"
    IL_0141:  ldc.i4.1
    IL_0142:  newarr     [mscorlib]System.Object
    IL_0147:  dup
    IL_0148:  ldc.i4.0
    IL_0149:  ldloc.s    V_5
    IL_014b:  stelem.ref
    IL_014c:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::InvokeAction(string,
                                                                                                      string,
                                                                                                      object[])
    IL_0151:  isinst     AspenTech.AspenPlus.Happ.IHNode
    IL_0156:  stfld      class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_mainNode
    IL_015b:  ldloc.s    V_7
    IL_015d:  ldc.i4.1
    IL_015e:  add
    IL_015f:  stloc.s    V_7
    IL_0161:  ldloc.s    V_7
    IL_0163:  ldloc.s    V_6
    IL_0165:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.ICollection`1<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,string>>::get_Count()
    IL_016a:  blt        IL_00b4

    IL_016f:  br.s       IL_01c4

    IL_0171:  ldloc.1
    IL_0172:  ldstr      "Equipment"
    IL_0177:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_017c:  brfalse.s  IL_01c4

    IL_017e:  ldnull
    IL_017f:  stloc.s    V_11
    .try
    {
      IL_0181:  ldloca.s   V_11
      IL_0183:  call       string [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::DoEquipmentSummary(string&)
      IL_0188:  stloc.s    V_12
      IL_018a:  ldloc.s    V_11
      IL_018c:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
      IL_0191:  brtrue.s   IL_01bc

      IL_0193:  ldarg.0
      IL_0194:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
      IL_0199:  isinst     [WindowsBase]System.Windows.DependencyObject
      IL_019e:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
      IL_01a3:  ldloc.s    V_11
      IL_01a5:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
      IL_01aa:  ldc.i4.0
      IL_01ab:  ldc.i4.0
      IL_01ac:  ldc.i4.0
      IL_01ad:  ldc.i4.1
      IL_01ae:  ldstr      "apwn.chm"
      IL_01b3:  ldc.i4.m1
      IL_01b4:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                         string,
                                                                                                                                                                                                                         string,
                                                                                                                                                                                                                         valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                         valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                         bool,
                                                                                                                                                                                                                         int32,
                                                                                                                                                                                                                         string,
                                                                                                                                                                                                                         int32)
      IL_01b9:  pop
      IL_01ba:  br.s       IL_01bf

      IL_01bc:  ldloc.s    V_12
      IL_01be:  stloc.0
      IL_01bf:  leave.s    IL_01c4

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_01c1:  pop
      IL_01c2:  leave.s    IL_01c4

    }  // end handler
    IL_01c4:  ldloc.0
    IL_01c5:  call       bool [mscorlib]System.String::IsNullOrWhiteSpace(string)
    IL_01ca:  brtrue.s   IL_01da

    IL_01cc:  ldarg.0
    IL_01cd:  ldarg.0
    IL_01ce:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::GetCurrentUnits()
    IL_01d3:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_CurrentUnits(string)
    IL_01d8:  ldloc.0
    IL_01d9:  ret

    IL_01da:  ldnull
    IL_01db:  ret
  } // end of method MMSummaryGridFormViewModel::BuildXmlConfiguration

  .method private hidebysig instance string 
          GetCurrentUnits() cil managed
  {
    // Code size       46 (0x2e)
    .maxstack  4
    .locals init (string V_0)
    IL_0000:  ldsfld     string [mscorlib]System.String::Empty
    IL_0005:  stloc.0
    .try
    {
      IL_0006:  ldarg.0
      IL_0007:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
      IL_000c:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
      IL_0011:  ldstr      "Top.appModelV8.Setup.Global.Input.INSET"
      IL_0016:  ldstr      "value"
      IL_001b:  ldnull
      IL_001c:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                    string,
                                                                                                    string)
      IL_0021:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
      IL_0026:  stloc.0
      IL_0027:  leave.s    IL_002c

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_0029:  pop
      IL_002a:  leave.s    IL_002c

    }  // end handler
    IL_002c:  ldloc.0
    IL_002d:  ret
  } // end of method MMSummaryGridFormViewModel::GetCurrentUnits

  .method private hidebysig instance void 
          RunInUIThread(class [mscorlib]System.Action action) cil managed
  {
    // Code size       46 (0x2e)
    .maxstack  3
    .locals init (class [WindowsBase]System.Windows.Threading.Dispatcher V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0006:  isinst     [PresentationCore]System.Windows.UIElement
    IL_000b:  callvirt   instance class [WindowsBase]System.Windows.Threading.Dispatcher [WindowsBase]System.Windows.Threading.DispatcherObject::get_Dispatcher()
    IL_0010:  stloc.0
    IL_0011:  ldloc.0
    IL_0012:  call       class [WindowsBase]System.Windows.Threading.Dispatcher [WindowsBase]System.Windows.Threading.Dispatcher::get_CurrentDispatcher()
    IL_0017:  bne.un.s   IL_0020

    IL_0019:  ldarg.1
    IL_001a:  callvirt   instance void [mscorlib]System.Action::Invoke()
    IL_001f:  ret

    IL_0020:  ldloc.0
    IL_0021:  ldarg.1
    IL_0022:  call       !!0[] [mscorlib]System.Array::Empty<object>()
    IL_0027:  callvirt   instance class [WindowsBase]System.Windows.Threading.DispatcherOperation [WindowsBase]System.Windows.Threading.Dispatcher::BeginInvoke(class [mscorlib]System.Delegate,
                                                                                                                                                                object[])
    IL_002c:  pop
    IL_002d:  ret
  } // end of method MMSummaryGridFormViewModel::RunInUIThread

  .method private hidebysig instance void 
          EquipmentCallback() cil managed
  {
    // Code size       19 (0x13)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.0
    IL_0002:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<EquipmentCallback>b__94_0'()
    IL_0008:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_000d:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::RunInUIThread(class [mscorlib]System.Action)
    IL_0012:  ret
  } // end of method MMSummaryGridFormViewModel::EquipmentCallback

  .method private hidebysig instance native int 
          GetEquipmentCallbackPointer() cil managed
  {
    // Code size       38 (0x26)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Action AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_equipmentCallbackDelegate
    IL_0006:  brtrue.s   IL_001a

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::EquipmentCallback()
    IL_0010:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_0015:  stfld      class [mscorlib]System.Action AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_equipmentCallbackDelegate
    IL_001a:  ldarg.0
    IL_001b:  ldfld      class [mscorlib]System.Action AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_equipmentCallbackDelegate
    IL_0020:  call       native int [mscorlib]System.Runtime.InteropServices.Marshal::GetFunctionPointerForDelegate<class [mscorlib]System.Action>(!!0)
    IL_0025:  ret
  } // end of method MMSummaryGridFormViewModel::GetEquipmentCallbackPointer

  .method public hidebysig instance string 
          GetConstString(valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString str) cil managed
  {
    // Code size       122 (0x7a)
    .maxstack  1
    .locals init (string V_0)
    IL_0000:  ldsfld     string [mscorlib]System.String::Empty
    IL_0005:  stloc.0
    IL_0006:  ldarg.1
    IL_0007:  switch     ( 
                          IL_0032,
                          IL_003a,
                          IL_0042,
                          IL_004a,
                          IL_0052,
                          IL_005a,
                          IL_0062,
                          IL_006a,
                          IL_0072)
    IL_0030:  br.s       IL_0078

    IL_0032:  ldstr      "Design-Spec"
    IL_0037:  stloc.0
    IL_0038:  br.s       IL_0078

    IL_003a:  ldstr      "Utilities"
    IL_003f:  stloc.0
    IL_0040:  br.s       IL_0078

    IL_0042:  ldstr      "XMLContext"
    IL_0047:  stloc.0
    IL_0048:  br.s       IL_0078

    IL_004a:  ldstr      "SGType"
    IL_004f:  stloc.0
    IL_0050:  br.s       IL_0078

    IL_0052:  ldstr      "SGModelType"
    IL_0057:  stloc.0
    IL_0058:  br.s       IL_0078

    IL_005a:  ldstr      "XMLObjFilter"
    IL_005f:  stloc.0
    IL_0060:  br.s       IL_0078

    IL_0062:  ldstr      "Block"
    IL_0067:  stloc.0
    IL_0068:  br.s       IL_0078

    IL_006a:  ldstr      "UnitOpt"
    IL_006f:  stloc.0
    IL_0070:  br.s       IL_0078

    IL_0072:  ldstr      "Equipment"
    IL_0077:  stloc.0
    IL_0078:  ldloc.0
    IL_0079:  ret
  } // end of method MMSummaryGridFormViewModel::GetConstString

  .method public hidebysig specialname instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior 
          get_CopyBehavior() cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_copyBehavior
    IL_0006:  brtrue.s   IL_002b

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::CopyBehavior_Executed()
    IL_0010:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_0015:  ldarg.0
    IL_0016:  ldftn      instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::CopyBehavior_CanExecute()
    IL_001c:  newobj     instance void class [mscorlib]System.Func`1<bool>::.ctor(object,
                                                                                  native int)
    IL_0021:  newobj     instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::.ctor(class [mscorlib]System.Action,
                                                                                                     class [mscorlib]System.Func`1<bool>)
    IL_0026:  stfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_copyBehavior
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_copyBehavior
    IL_0031:  ret
  } // end of method MMSummaryGridFormViewModel::get_CopyBehavior

  .method private hidebysig instance void 
          CopyBehavior_Executed() cil managed
  {
    // Code size       20 (0x14)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0006:  brfalse.s  IL_0013

    IL_0008:  ldarg.0
    IL_0009:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_000e:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::CopyToClipboard()
    IL_0013:  ret
  } // end of method MMSummaryGridFormViewModel::CopyBehavior_Executed

  .method private hidebysig instance bool 
          CopyBehavior_CanExecute() cil managed
  {
    // Code size       2 (0x2)
    .maxstack  8
    IL_0000:  ldc.i4.1
    IL_0001:  ret
  } // end of method MMSummaryGridFormViewModel::CopyBehavior_CanExecute

  .method public hidebysig specialname instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior 
          get_MapBehavior() cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_mapBehavior
    IL_0006:  brtrue.s   IL_002b

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::MapBehavior_Executed()
    IL_0010:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_0015:  ldarg.0
    IL_0016:  ldftn      instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::MapBehavior_CanExecute()
    IL_001c:  newobj     instance void class [mscorlib]System.Func`1<bool>::.ctor(object,
                                                                                  native int)
    IL_0021:  newobj     instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::.ctor(class [mscorlib]System.Action,
                                                                                                     class [mscorlib]System.Func`1<bool>)
    IL_0026:  stfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_mapBehavior
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_mapBehavior
    IL_0031:  ret
  } // end of method MMSummaryGridFormViewModel::get_MapBehavior

  .method private hidebysig instance void 
          MapBehavior_Executed() cil managed
  {
    // Code size       218 (0xda)
    .maxstack  9
    .locals init (string[] V_0,
             string V_1,
             string V_2)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0006:  brfalse    IL_00d9

    IL_000b:  ldarg.0
    IL_000c:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0011:  callvirt   instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows()
    IL_0016:  stloc.0
    IL_0017:  ldarg.0
    IL_0018:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_001d:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab()
    IL_0022:  stloc.1
    IL_0023:  ldloc.0
    IL_0024:  brfalse.s  IL_002a

    IL_0026:  ldloc.0
    IL_0027:  ldlen
    IL_0028:  brtrue.s   IL_0055

    IL_002a:  ldarg.0
    IL_002b:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0030:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_0035:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_003a:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_Map()
    IL_003f:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_0044:  ldc.i4.0
    IL_0045:  ldc.i4.0
    IL_0046:  ldc.i4.0
    IL_0047:  ldc.i4.1
    IL_0048:  ldstr      "apwn.chm"
    IL_004d:  ldc.i4.m1
    IL_004e:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_0053:  pop
    IL_0054:  ret

    IL_0055:  ldloc.1
    IL_0056:  ldstr      "Design-Spec"
    IL_005b:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0060:  brtrue.s   IL_00d9

    IL_0062:  ldloc.1
    IL_0063:  ldstr      "Utilities"
    IL_0068:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_006d:  brtrue.s   IL_00d9

    IL_006f:  ldnull
    IL_0070:  stloc.2
    IL_0071:  ldarg.0
    IL_0072:  call       instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_UnityContainer()
    IL_0077:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
    IL_007c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0081:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.RequestSaveDataShareEvent>()
    IL_0086:  ldsfld     class [mscorlib]System.EventArgs [mscorlib]System.EventArgs::Empty
    IL_008b:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::Publish(!0)
    IL_0090:  ldloc.0
    IL_0091:  call       class [mscorlib]System.Collections.Generic.List`1<!!0> [System.Core]System.Linq.Enumerable::ToList<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0096:  ldarg.0
    IL_0097:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::GetEquipmentCallbackPointer()
    IL_009c:  ldarg.0
    IL_009d:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_CurrentWindowPointer()
    IL_00a2:  ldloca.s   V_2
    IL_00a4:  call       bool [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::MapUnitOps(class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                                        native int,
                                                                                                                                        native int,
                                                                                                                                        string&)
    IL_00a9:  brtrue.s   IL_00d9

    IL_00ab:  ldloc.2
    IL_00ac:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_00b1:  brtrue.s   IL_00d9

    IL_00b3:  ldarg.0
    IL_00b4:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_00b9:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_00be:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_00c3:  ldloc.2
    IL_00c4:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_00c9:  ldc.i4.0
    IL_00ca:  ldc.i4.0
    IL_00cb:  ldc.i4.0
    IL_00cc:  ldc.i4.1
    IL_00cd:  ldstr      "apwn.chm"
    IL_00d2:  ldc.i4.m1
    IL_00d3:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_00d8:  pop
    IL_00d9:  ret
  } // end of method MMSummaryGridFormViewModel::MapBehavior_Executed

  .method private hidebysig instance bool 
          MapBehavior_CanExecute() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  call       int32 [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::GetStatus()
    IL_0005:  ldc.i4.3
    IL_0006:  clt
    IL_0008:  ldc.i4.0
    IL_0009:  ceq
    IL_000b:  ret
  } // end of method MMSummaryGridFormViewModel::MapBehavior_CanExecute

  .method public hidebysig specialname instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior 
          get_UnmapBehavior() cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_unmapBehavior
    IL_0006:  brtrue.s   IL_002b

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::UnmapBehavior_Executed()
    IL_0010:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_0015:  ldarg.0
    IL_0016:  ldftn      instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::UnmapBehavior_CanExecute()
    IL_001c:  newobj     instance void class [mscorlib]System.Func`1<bool>::.ctor(object,
                                                                                  native int)
    IL_0021:  newobj     instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::.ctor(class [mscorlib]System.Action,
                                                                                                     class [mscorlib]System.Func`1<bool>)
    IL_0026:  stfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_unmapBehavior
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_unmapBehavior
    IL_0031:  ret
  } // end of method MMSummaryGridFormViewModel::get_UnmapBehavior

  .method private hidebysig instance void 
          UnmapBehavior_Executed() cil managed
  {
    // Code size       218 (0xda)
    .maxstack  9
    .locals init (string[] V_0,
             string V_1,
             string V_2)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0006:  brfalse    IL_00d9

    IL_000b:  ldarg.0
    IL_000c:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0011:  callvirt   instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows()
    IL_0016:  stloc.0
    IL_0017:  ldarg.0
    IL_0018:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_001d:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab()
    IL_0022:  stloc.1
    IL_0023:  ldloc.0
    IL_0024:  brfalse.s  IL_002a

    IL_0026:  ldloc.0
    IL_0027:  ldlen
    IL_0028:  brtrue.s   IL_0055

    IL_002a:  ldarg.0
    IL_002b:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0030:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_0035:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_003a:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_Unap()
    IL_003f:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_0044:  ldc.i4.0
    IL_0045:  ldc.i4.0
    IL_0046:  ldc.i4.0
    IL_0047:  ldc.i4.1
    IL_0048:  ldstr      "apwn.chm"
    IL_004d:  ldc.i4.m1
    IL_004e:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_0053:  pop
    IL_0054:  ret

    IL_0055:  ldloc.1
    IL_0056:  ldstr      "Design-Spec"
    IL_005b:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0060:  brtrue.s   IL_00d9

    IL_0062:  ldloc.1
    IL_0063:  ldstr      "Utilities"
    IL_0068:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_006d:  brtrue.s   IL_00d9

    IL_006f:  ldnull
    IL_0070:  stloc.2
    IL_0071:  ldarg.0
    IL_0072:  call       instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_UnityContainer()
    IL_0077:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
    IL_007c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0081:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.RequestSaveDataShareEvent>()
    IL_0086:  ldsfld     class [mscorlib]System.EventArgs [mscorlib]System.EventArgs::Empty
    IL_008b:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::Publish(!0)
    IL_0090:  ldloc.0
    IL_0091:  call       class [mscorlib]System.Collections.Generic.List`1<!!0> [System.Core]System.Linq.Enumerable::ToList<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0096:  ldarg.0
    IL_0097:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::GetEquipmentCallbackPointer()
    IL_009c:  ldarg.0
    IL_009d:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_CurrentWindowPointer()
    IL_00a2:  ldloca.s   V_2
    IL_00a4:  call       bool [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::UnMapUnitOps(class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                                          native int,
                                                                                                                                          native int,
                                                                                                                                          string&)
    IL_00a9:  brtrue.s   IL_00d9

    IL_00ab:  ldloc.2
    IL_00ac:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_00b1:  brtrue.s   IL_00d9

    IL_00b3:  ldarg.0
    IL_00b4:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_00b9:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_00be:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_00c3:  ldloc.2
    IL_00c4:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_00c9:  ldc.i4.0
    IL_00ca:  ldc.i4.0
    IL_00cb:  ldc.i4.0
    IL_00cc:  ldc.i4.1
    IL_00cd:  ldstr      "apwn.chm"
    IL_00d2:  ldc.i4.m1
    IL_00d3:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_00d8:  pop
    IL_00d9:  ret
  } // end of method MMSummaryGridFormViewModel::UnmapBehavior_Executed

  .method private hidebysig instance bool 
          UnmapBehavior_CanExecute() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  call       int32 [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::GetStatus()
    IL_0005:  ldc.i4.3
    IL_0006:  clt
    IL_0008:  ldc.i4.0
    IL_0009:  ceq
    IL_000b:  ret
  } // end of method MMSummaryGridFormViewModel::UnmapBehavior_CanExecute

  .method public hidebysig specialname instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior 
          get_OpenFormBehavior() cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_openFormBehavior
    IL_0006:  brtrue.s   IL_002b

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::OpenFormBehavior_Executed()
    IL_0010:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_0015:  ldarg.0
    IL_0016:  ldftn      instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::OpenFormBehavior_CanExecute()
    IL_001c:  newobj     instance void class [mscorlib]System.Func`1<bool>::.ctor(object,
                                                                                  native int)
    IL_0021:  newobj     instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::.ctor(class [mscorlib]System.Action,
                                                                                                     class [mscorlib]System.Func`1<bool>)
    IL_0026:  stfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_openFormBehavior
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_openFormBehavior
    IL_0031:  ret
  } // end of method MMSummaryGridFormViewModel::get_OpenFormBehavior

  .method private hidebysig instance void 
          OpenFormBehavior_Executed() cil managed
  {
    // Code size       207 (0xcf)
    .maxstack  9
    .locals init (string[] V_0,
             string V_1,
             string V_2)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0006:  brfalse    IL_00ce

    IL_000b:  ldarg.0
    IL_000c:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0011:  callvirt   instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows()
    IL_0016:  stloc.0
    IL_0017:  ldarg.0
    IL_0018:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_001d:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab()
    IL_0022:  stloc.1
    IL_0023:  ldloc.1
    IL_0024:  ldstr      "Stream (Price)"
    IL_0029:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_002e:  brfalse.s  IL_0036

    IL_0030:  ldstr      "STREAM-PRICE"
    IL_0035:  stloc.1
    IL_0036:  ldloc.0
    IL_0037:  brfalse.s  IL_003d

    IL_0039:  ldloc.0
    IL_003a:  ldlen
    IL_003b:  brtrue.s   IL_0068

    IL_003d:  ldarg.0
    IL_003e:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0043:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_0048:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_004d:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_Open()
    IL_0052:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_0057:  ldc.i4.0
    IL_0058:  ldc.i4.0
    IL_0059:  ldc.i4.0
    IL_005a:  ldc.i4.1
    IL_005b:  ldstr      "apwn.chm"
    IL_0060:  ldc.i4.m1
    IL_0061:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_0066:  pop
    IL_0067:  ret

    IL_0068:  ldloc.0
    IL_0069:  ldc.i4.0
    IL_006a:  ldelem.ref
    IL_006b:  ldloc.1
    IL_006c:  call       string AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::GetFullBlockPath(string,
                                                                                                             string)
    IL_0071:  stloc.2
    IL_0072:  ldloc.2
    IL_0073:  ldstr      "Flowsheeting Options.Design-Spec"
    IL_0078:  ldstr      "Flowsheeting Options.Design Specs"
    IL_007d:  callvirt   instance string [mscorlib]System.String::Replace(string,
                                                                          string)
    IL_0082:  stloc.2
    IL_0083:  ldloc.2
    IL_0084:  ldstr      "Top.appModelV8"
    IL_0089:  call       instance int32 [mscorlib]System.String::get_Length()
    IL_008e:  ldc.i4.1
    IL_008f:  add
    IL_0090:  callvirt   instance string [mscorlib]System.String::Substring(int32)
    IL_0095:  stloc.2
    IL_0096:  ldarg.0
    IL_0097:  call       instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_UnityContainer()
    IL_009c:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
    IL_00a1:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_00a6:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.NavigateToEvent>()
    IL_00ab:  newobj     instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.NavigateToEventArgs::.ctor()
    IL_00b0:  dup
    IL_00b1:  ldsfld     string [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.NavigationGroupKeys::SimulationGroup
    IL_00b6:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.NavigateToEventArgs::set_Group(string)
    IL_00bb:  dup
    IL_00bc:  ldloc.2
    IL_00bd:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.NavigateToEventArgs::set_Path(string)
    IL_00c2:  dup
    IL_00c3:  ldc.i4.1
    IL_00c4:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.NavigateToEventArgs::set_UseNewTab(bool)
    IL_00c9:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.NavigateToEventArgs>::Publish(!0)
    IL_00ce:  ret
  } // end of method MMSummaryGridFormViewModel::OpenFormBehavior_Executed

  .method private hidebysig instance bool 
          OpenFormBehavior_CanExecute() cil managed
  {
    // Code size       2 (0x2)
    .maxstack  8
    IL_0000:  ldc.i4.1
    IL_0001:  ret
  } // end of method MMSummaryGridFormViewModel::OpenFormBehavior_CanExecute

  .method public hidebysig specialname instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior 
          get_SizeBehavior() cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_sizeBehavior
    IL_0006:  brtrue.s   IL_002b

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::SizeBehavior_Executed()
    IL_0010:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_0015:  ldarg.0
    IL_0016:  ldftn      instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::SizeBehavior_CanExecute()
    IL_001c:  newobj     instance void class [mscorlib]System.Func`1<bool>::.ctor(object,
                                                                                  native int)
    IL_0021:  newobj     instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::.ctor(class [mscorlib]System.Action,
                                                                                                     class [mscorlib]System.Func`1<bool>)
    IL_0026:  stfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_sizeBehavior
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_sizeBehavior
    IL_0031:  ret
  } // end of method MMSummaryGridFormViewModel::get_SizeBehavior

  .method private hidebysig instance void 
          SizeBehavior_Executed() cil managed
  {
    // Code size       445 (0x1bd)
    .maxstack  10
    .locals init (string[] V_0,
             string V_1,
             object V_2)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0006:  brfalse    IL_01bc

    IL_000b:  ldarg.0
    IL_000c:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0011:  callvirt   instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows()
    IL_0016:  stloc.0
    IL_0017:  ldloc.0
    IL_0018:  brfalse.s  IL_001e

    IL_001a:  ldloc.0
    IL_001b:  ldlen
    IL_001c:  brtrue.s   IL_0049

    IL_001e:  ldarg.0
    IL_001f:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0024:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_0029:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_002e:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_Size()
    IL_0033:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_0038:  ldc.i4.0
    IL_0039:  ldc.i4.0
    IL_003a:  ldc.i4.0
    IL_003b:  ldc.i4.1
    IL_003c:  ldstr      "apwn.chm"
    IL_0041:  ldc.i4.m1
    IL_0042:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_0047:  pop
    IL_0048:  ret

    IL_0049:  ldnull
    IL_004a:  stloc.1
    IL_004b:  ldarg.0
    IL_004c:  call       instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_UnityContainer()
    IL_0051:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
    IL_0056:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_005b:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.RequestSaveDataShareEvent>()
    IL_0060:  ldsfld     class [mscorlib]System.EventArgs [mscorlib]System.EventArgs::Empty
    IL_0065:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::Publish(!0)
    IL_006a:  ldloc.0
    IL_006b:  call       class [mscorlib]System.Collections.Generic.List`1<!!0> [System.Core]System.Linq.Enumerable::ToList<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0070:  ldarg.0
    IL_0071:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::GetEquipmentCallbackPointer()
    IL_0076:  ldarg.0
    IL_0077:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_CurrentWindowPointer()
    IL_007c:  ldloca.s   V_1
    IL_007e:  call       bool [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::SizeEquipment(class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                                           native int,
                                                                                                                                           native int,
                                                                                                                                           string&)
    IL_0083:  brtrue.s   IL_00b7

    IL_0085:  ldloc.1
    IL_0086:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_008b:  brtrue     IL_01bc

    IL_0090:  ldarg.0
    IL_0091:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0096:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_009b:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_00a0:  ldloc.1
    IL_00a1:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_00a6:  ldc.i4.0
    IL_00a7:  ldc.i4.0
    IL_00a8:  ldc.i4.0
    IL_00a9:  ldc.i4.1
    IL_00aa:  ldstr      "apwn.chm"
    IL_00af:  ldc.i4.m1
    IL_00b0:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_00b5:  pop
    IL_00b6:  ret

    IL_00b7:  nop
    .try
    {
      IL_00b8:  ldarg.0
      IL_00b9:  call       instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_UnityContainer()
      IL_00be:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
      IL_00c3:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IApwnDocument>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                  class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
      IL_00c8:  stloc.2
      IL_00c9:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__122'::'<>p__1'
      IL_00ce:  brtrue.s   IL_00fc

      IL_00d0:  ldc.i4.0
      IL_00d1:  ldc.i4.s   83
      IL_00d3:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_00d8:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_00dd:  ldc.i4.1
      IL_00de:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_00e3:  dup
      IL_00e4:  ldc.i4.0
      IL_00e5:  ldc.i4.0
      IL_00e6:  ldnull
      IL_00e7:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_00ec:  stelem.ref
      IL_00ed:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::UnaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                     valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                     class [mscorlib]System.Type,
                                                                                                                                                                     class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_00f2:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_00f7:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__122'::'<>p__1'
      IL_00fc:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__122'::'<>p__1'
      IL_0101:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Target
      IL_0106:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__122'::'<>p__1'
      IL_010b:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__122'::'<>p__0'
      IL_0110:  brtrue.s   IL_0148

      IL_0112:  ldc.i4.0
      IL_0113:  ldc.i4.s   35
      IL_0115:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_011a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_011f:  ldc.i4.2
      IL_0120:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0125:  dup
      IL_0126:  ldc.i4.0
      IL_0127:  ldc.i4.0
      IL_0128:  ldnull
      IL_0129:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_012e:  stelem.ref
      IL_012f:  dup
      IL_0130:  ldc.i4.1
      IL_0131:  ldc.i4.2
      IL_0132:  ldnull
      IL_0133:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0138:  stelem.ref
      IL_0139:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_013e:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0143:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__122'::'<>p__0'
      IL_0148:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__122'::'<>p__0'
      IL_014d:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Target
      IL_0152:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__122'::'<>p__0'
      IL_0157:  ldloc.2
      IL_0158:  ldnull
      IL_0159:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>::Invoke(!0,
                                                                                                                                                               !1,
                                                                                                                                                               !2)
      IL_015e:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>::Invoke(!0,
                                                                                                                                                      !1)
      IL_0163:  brfalse.s  IL_01b7

      IL_0165:  ldarg.0
      IL_0166:  newobj     instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::.ctor()
      IL_016b:  stfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer
      IL_0170:  ldarg.0
      IL_0171:  ldfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer
      IL_0176:  ldarg.0
      IL_0177:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::DispatcherTimer_Tick(object,
                                                                                                                                  class [mscorlib]System.EventArgs)
      IL_017d:  newobj     instance void [mscorlib]System.EventHandler::.ctor(object,
                                                                              native int)
      IL_0182:  callvirt   instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::add_Tick(class [mscorlib]System.EventHandler)
      IL_0187:  ldarg.0
      IL_0188:  ldfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer
      IL_018d:  ldc.r8     200
      IL_0196:  call       valuetype [mscorlib]System.TimeSpan [mscorlib]System.TimeSpan::FromMilliseconds(float64)
      IL_019b:  callvirt   instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::set_Interval(valuetype [mscorlib]System.TimeSpan)
      IL_01a0:  ldarg.0
      IL_01a1:  ldfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer
      IL_01a6:  ldloc.2
      IL_01a7:  callvirt   instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::set_Tag(object)
      IL_01ac:  ldarg.0
      IL_01ad:  ldfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer
      IL_01b2:  callvirt   instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::Start()
      IL_01b7:  leave.s    IL_01bc

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_01b9:  pop
      IL_01ba:  leave.s    IL_01bc

    }  // end handler
    IL_01bc:  ret
  } // end of method MMSummaryGridFormViewModel::SizeBehavior_Executed

  .method private hidebysig instance void 
          DispatcherTimer_Tick(object sender,
                               class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       503 (0x1f7)
    .maxstack  15
    .locals init (object V_0,
             object V_1)
    .try
    {
      IL_0000:  ldarg.1
      IL_0001:  isinst     [WindowsBase]System.Windows.Threading.DispatcherTimer
      IL_0006:  callvirt   instance object [WindowsBase]System.Windows.Threading.DispatcherTimer::get_Tag()
      IL_000b:  isinst     [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IApwnDocument
      IL_0010:  stloc.0
      IL_0011:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__5'
      IL_0016:  brtrue.s   IL_0044

      IL_0018:  ldc.i4.0
      IL_0019:  ldc.i4.s   83
      IL_001b:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_0020:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0025:  ldc.i4.1
      IL_0026:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_002b:  dup
      IL_002c:  ldc.i4.0
      IL_002d:  ldc.i4.0
      IL_002e:  ldnull
      IL_002f:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0034:  stelem.ref
      IL_0035:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::UnaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                     valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                     class [mscorlib]System.Type,
                                                                                                                                                                     class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_003a:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_003f:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__5'
      IL_0044:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__5'
      IL_0049:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Target
      IL_004e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__5'
      IL_0053:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__0'
      IL_0058:  brtrue.s   IL_0090

      IL_005a:  ldc.i4.0
      IL_005b:  ldc.i4.s   35
      IL_005d:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_0062:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0067:  ldc.i4.2
      IL_0068:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_006d:  dup
      IL_006e:  ldc.i4.0
      IL_006f:  ldc.i4.0
      IL_0070:  ldnull
      IL_0071:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0076:  stelem.ref
      IL_0077:  dup
      IL_0078:  ldc.i4.1
      IL_0079:  ldc.i4.2
      IL_007a:  ldnull
      IL_007b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0080:  stelem.ref
      IL_0081:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0086:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_008b:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__0'
      IL_0090:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__0'
      IL_0095:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Target
      IL_009a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__0'
      IL_009f:  ldloc.0
      IL_00a0:  ldnull
      IL_00a1:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>::Invoke(!0,
                                                                                                                                                               !1,
                                                                                                                                                               !2)
      IL_00a6:  stloc.1
      IL_00a7:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__4'
      IL_00ac:  brtrue.s   IL_00da

      IL_00ae:  ldc.i4.0
      IL_00af:  ldc.i4.s   84
      IL_00b1:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_00b6:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_00bb:  ldc.i4.1
      IL_00bc:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_00c1:  dup
      IL_00c2:  ldc.i4.0
      IL_00c3:  ldc.i4.0
      IL_00c4:  ldnull
      IL_00c5:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_00ca:  stelem.ref
      IL_00cb:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::UnaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                     valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                     class [mscorlib]System.Type,
                                                                                                                                                                     class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_00d0:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_00d5:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__4'
      IL_00da:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__4'
      IL_00df:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Target
      IL_00e4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__4'
      IL_00e9:  ldloc.1
      IL_00ea:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>::Invoke(!0,
                                                                                                                                                      !1)
      IL_00ef:  brtrue     IL_01dd

      IL_00f4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__3'
      IL_00f9:  brtrue.s   IL_0130

      IL_00fb:  ldc.i4.8
      IL_00fc:  ldc.i4.2
      IL_00fd:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_0102:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0107:  ldc.i4.2
      IL_0108:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_010d:  dup
      IL_010e:  ldc.i4.0
      IL_010f:  ldc.i4.0
      IL_0110:  ldnull
      IL_0111:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0116:  stelem.ref
      IL_0117:  dup
      IL_0118:  ldc.i4.1
      IL_0119:  ldc.i4.0
      IL_011a:  ldnull
      IL_011b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0120:  stelem.ref
      IL_0121:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0126:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_012b:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__3'
      IL_0130:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__3'
      IL_0135:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Target
      IL_013a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__3'
      IL_013f:  ldloc.1
      IL_0140:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__2'
      IL_0145:  brtrue.s   IL_0177

      IL_0147:  ldc.i4.0
      IL_0148:  ldstr      "GetIsDone"
      IL_014d:  ldnull
      IL_014e:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_0153:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0158:  ldc.i4.1
      IL_0159:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_015e:  dup
      IL_015f:  ldc.i4.0
      IL_0160:  ldc.i4.0
      IL_0161:  ldnull
      IL_0162:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0167:  stelem.ref
      IL_0168:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_016d:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0172:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__2'
      IL_0177:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__2'
      IL_017c:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Target
      IL_0181:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__2'
      IL_0186:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__1'
      IL_018b:  brtrue.s   IL_01bc

      IL_018d:  ldc.i4.0
      IL_018e:  ldstr      "EconomicsAnalysisHelperNew"
      IL_0193:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_0198:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_019d:  ldc.i4.1
      IL_019e:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_01a3:  dup
      IL_01a4:  ldc.i4.0
      IL_01a5:  ldc.i4.0
      IL_01a6:  ldnull
      IL_01a7:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_01ac:  stelem.ref
      IL_01ad:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::GetMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                string,
                                                                                                                                                                class [mscorlib]System.Type,
                                                                                                                                                                class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_01b2:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_01b7:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__1'
      IL_01bc:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__1'
      IL_01c1:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Target
      IL_01c6:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__123'::'<>p__1'
      IL_01cb:  ldloc.0
      IL_01cc:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>::Invoke(!0,
                                                                                                                                                        !1)
      IL_01d1:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>::Invoke(!0,
                                                                                                                                                        !1)
      IL_01d6:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>::Invoke(!0,
                                                                                                                                                               !1,
                                                                                                                                                               !2)
      IL_01db:  br.s       IL_01de

      IL_01dd:  ldloc.1
      IL_01de:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>::Invoke(!0,
                                                                                                                                                      !1)
      IL_01e3:  brfalse.s  IL_01eb

      IL_01e5:  ldarg.0
      IL_01e6:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::StopTimerAndRefresh()
      IL_01eb:  leave.s    IL_01f6

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_01ed:  pop
      IL_01ee:  ldarg.0
      IL_01ef:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::StopTimerAndRefresh()
      IL_01f4:  leave.s    IL_01f6

    }  // end handler
    IL_01f6:  ret
  } // end of method MMSummaryGridFormViewModel::DispatcherTimer_Tick

  .method private hidebysig instance void 
          StopTimerAndRefresh() cil managed
  {
    // Code size       23 (0x17)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer
    IL_0006:  callvirt   instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::Stop()
    IL_000b:  call       void [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.MmgSor::MMReconnectDataShare()
    IL_0010:  ldarg.0
    IL_0011:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::OnUpdateData()
    IL_0016:  ret
  } // end of method MMSummaryGridFormViewModel::StopTimerAndRefresh

  .method private hidebysig instance bool 
          SizeBehavior_CanExecute() cil managed
  {
    // Code size       18 (0x12)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::UpdateVisibilities()
    IL_0006:  call       int32 [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::GetStatus()
    IL_000b:  ldc.i4.3
    IL_000c:  clt
    IL_000e:  ldc.i4.0
    IL_000f:  ceq
    IL_0011:  ret
  } // end of method MMSummaryGridFormViewModel::SizeBehavior_CanExecute

  .method public hidebysig specialname instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior 
          get_EvaluateBehavior() cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_evaluateBehavior
    IL_0006:  brtrue.s   IL_002b

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::EvaluateBehavior_Executed()
    IL_0010:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_0015:  ldarg.0
    IL_0016:  ldftn      instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::EvaluateBehavior_CanExecute()
    IL_001c:  newobj     instance void class [mscorlib]System.Func`1<bool>::.ctor(object,
                                                                                  native int)
    IL_0021:  newobj     instance void AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior::.ctor(class [mscorlib]System.Action,
                                                                                                     class [mscorlib]System.Func`1<bool>)
    IL_0026:  stfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_evaluateBehavior
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_evaluateBehavior
    IL_0031:  ret
  } // end of method MMSummaryGridFormViewModel::get_EvaluateBehavior

  .method private hidebysig instance void 
          EvaluateBehavior_Executed() cil managed
  {
    // Code size       445 (0x1bd)
    .maxstack  10
    .locals init (string[] V_0,
             string V_1,
             object V_2)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0006:  brfalse    IL_01bc

    IL_000b:  ldarg.0
    IL_000c:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0011:  callvirt   instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows()
    IL_0016:  stloc.0
    IL_0017:  ldloc.0
    IL_0018:  brfalse.s  IL_001e

    IL_001a:  ldloc.0
    IL_001b:  ldlen
    IL_001c:  brtrue.s   IL_0049

    IL_001e:  ldarg.0
    IL_001f:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0024:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_0029:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_002e:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_Evaluate()
    IL_0033:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_0038:  ldc.i4.0
    IL_0039:  ldc.i4.0
    IL_003a:  ldc.i4.0
    IL_003b:  ldc.i4.1
    IL_003c:  ldstr      "apwn.chm"
    IL_0041:  ldc.i4.m1
    IL_0042:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_0047:  pop
    IL_0048:  ret

    IL_0049:  ldnull
    IL_004a:  stloc.1
    IL_004b:  ldarg.0
    IL_004c:  call       instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_UnityContainer()
    IL_0051:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
    IL_0056:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_005b:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.Events.RequestSaveDataShareEvent>()
    IL_0060:  ldsfld     class [mscorlib]System.EventArgs [mscorlib]System.EventArgs::Empty
    IL_0065:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::Publish(!0)
    IL_006a:  ldloc.0
    IL_006b:  call       class [mscorlib]System.Collections.Generic.List`1<!!0> [System.Core]System.Linq.Enumerable::ToList<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0070:  ldarg.0
    IL_0071:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::GetEquipmentCallbackPointer()
    IL_0076:  ldarg.0
    IL_0077:  call       instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_CurrentWindowPointer()
    IL_007c:  ldloca.s   V_1
    IL_007e:  call       bool [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::EvaluateEquipment(class [mscorlib]System.Collections.Generic.IList`1<string>,
                                                                                                                                               native int,
                                                                                                                                               native int,
                                                                                                                                               string&)
    IL_0083:  brtrue.s   IL_00b7

    IL_0085:  ldloc.1
    IL_0086:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_008b:  brtrue     IL_01bc

    IL_0090:  ldarg.0
    IL_0091:  call       instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
    IL_0096:  isinst     [WindowsBase]System.Windows.DependencyObject
    IL_009b:  call       class [PresentationFramework]System.Windows.Window [PresentationFramework]System.Windows.Window::GetWindow(class [WindowsBase]System.Windows.DependencyObject)
    IL_00a0:  ldloc.1
    IL_00a1:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.SummaryGridResources::get_MMSummaryGridForm_ErrorMessage_DialogTitle()
    IL_00a6:  ldc.i4.0
    IL_00a7:  ldc.i4.0
    IL_00a8:  ldc.i4.0
    IL_00a9:  ldc.i4.1
    IL_00aa:  ldstr      "apwn.chm"
    IL_00af:  ldc.i4.m1
    IL_00b0:  call       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxResult [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBox::Show(class [PresentationFramework]System.Windows.Window,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxButton,
                                                                                                                                                                                                                       valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.MMMessageBoxImage,
                                                                                                                                                                                                                       bool,
                                                                                                                                                                                                                       int32,
                                                                                                                                                                                                                       string,
                                                                                                                                                                                                                       int32)
    IL_00b5:  pop
    IL_00b6:  ret

    IL_00b7:  nop
    .try
    {
      IL_00b8:  ldarg.0
      IL_00b9:  call       instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_UnityContainer()
      IL_00be:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
      IL_00c3:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IApwnDocument>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                  class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
      IL_00c8:  stloc.2
      IL_00c9:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__131'::'<>p__1'
      IL_00ce:  brtrue.s   IL_00fc

      IL_00d0:  ldc.i4.0
      IL_00d1:  ldc.i4.s   83
      IL_00d3:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_00d8:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_00dd:  ldc.i4.1
      IL_00de:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_00e3:  dup
      IL_00e4:  ldc.i4.0
      IL_00e5:  ldc.i4.0
      IL_00e6:  ldnull
      IL_00e7:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_00ec:  stelem.ref
      IL_00ed:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::UnaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                     valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                     class [mscorlib]System.Type,
                                                                                                                                                                     class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_00f2:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_00f7:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__131'::'<>p__1'
      IL_00fc:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__131'::'<>p__1'
      IL_0101:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Target
      IL_0106:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__131'::'<>p__1'
      IL_010b:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__131'::'<>p__0'
      IL_0110:  brtrue.s   IL_0148

      IL_0112:  ldc.i4.0
      IL_0113:  ldc.i4.s   35
      IL_0115:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_011a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_011f:  ldc.i4.2
      IL_0120:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0125:  dup
      IL_0126:  ldc.i4.0
      IL_0127:  ldc.i4.0
      IL_0128:  ldnull
      IL_0129:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_012e:  stelem.ref
      IL_012f:  dup
      IL_0130:  ldc.i4.1
      IL_0131:  ldc.i4.2
      IL_0132:  ldnull
      IL_0133:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0138:  stelem.ref
      IL_0139:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_013e:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0143:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__131'::'<>p__0'
      IL_0148:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__131'::'<>p__0'
      IL_014d:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Target
      IL_0152:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__131'::'<>p__0'
      IL_0157:  ldloc.2
      IL_0158:  ldnull
      IL_0159:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>::Invoke(!0,
                                                                                                                                                               !1,
                                                                                                                                                               !2)
      IL_015e:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>::Invoke(!0,
                                                                                                                                                      !1)
      IL_0163:  brfalse.s  IL_01b7

      IL_0165:  ldarg.0
      IL_0166:  newobj     instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::.ctor()
      IL_016b:  stfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer_evaluate
      IL_0170:  ldarg.0
      IL_0171:  ldfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer_evaluate
      IL_0176:  ldarg.0
      IL_0177:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::DispatcherTimer_Evaluate_Tick(object,
                                                                                                                                           class [mscorlib]System.EventArgs)
      IL_017d:  newobj     instance void [mscorlib]System.EventHandler::.ctor(object,
                                                                              native int)
      IL_0182:  callvirt   instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::add_Tick(class [mscorlib]System.EventHandler)
      IL_0187:  ldarg.0
      IL_0188:  ldfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer_evaluate
      IL_018d:  ldc.r8     200
      IL_0196:  call       valuetype [mscorlib]System.TimeSpan [mscorlib]System.TimeSpan::FromMilliseconds(float64)
      IL_019b:  callvirt   instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::set_Interval(valuetype [mscorlib]System.TimeSpan)
      IL_01a0:  ldarg.0
      IL_01a1:  ldfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer_evaluate
      IL_01a6:  ldloc.2
      IL_01a7:  callvirt   instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::set_Tag(object)
      IL_01ac:  ldarg.0
      IL_01ad:  ldfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer_evaluate
      IL_01b2:  callvirt   instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::Start()
      IL_01b7:  leave.s    IL_01bc

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_01b9:  pop
      IL_01ba:  leave.s    IL_01bc

    }  // end handler
    IL_01bc:  ret
  } // end of method MMSummaryGridFormViewModel::EvaluateBehavior_Executed

  .method private hidebysig instance void 
          DispatcherTimer_Evaluate_Tick(object sender,
                                        class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       503 (0x1f7)
    .maxstack  15
    .locals init (object V_0,
             object V_1)
    .try
    {
      IL_0000:  ldarg.1
      IL_0001:  isinst     [WindowsBase]System.Windows.Threading.DispatcherTimer
      IL_0006:  callvirt   instance object [WindowsBase]System.Windows.Threading.DispatcherTimer::get_Tag()
      IL_000b:  isinst     [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IApwnDocument
      IL_0010:  stloc.0
      IL_0011:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__5'
      IL_0016:  brtrue.s   IL_0044

      IL_0018:  ldc.i4.0
      IL_0019:  ldc.i4.s   83
      IL_001b:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_0020:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0025:  ldc.i4.1
      IL_0026:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_002b:  dup
      IL_002c:  ldc.i4.0
      IL_002d:  ldc.i4.0
      IL_002e:  ldnull
      IL_002f:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0034:  stelem.ref
      IL_0035:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::UnaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                     valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                     class [mscorlib]System.Type,
                                                                                                                                                                     class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_003a:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_003f:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__5'
      IL_0044:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__5'
      IL_0049:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Target
      IL_004e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__5'
      IL_0053:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__0'
      IL_0058:  brtrue.s   IL_0090

      IL_005a:  ldc.i4.0
      IL_005b:  ldc.i4.s   35
      IL_005d:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_0062:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0067:  ldc.i4.2
      IL_0068:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_006d:  dup
      IL_006e:  ldc.i4.0
      IL_006f:  ldc.i4.0
      IL_0070:  ldnull
      IL_0071:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0076:  stelem.ref
      IL_0077:  dup
      IL_0078:  ldc.i4.1
      IL_0079:  ldc.i4.2
      IL_007a:  ldnull
      IL_007b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0080:  stelem.ref
      IL_0081:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0086:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_008b:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__0'
      IL_0090:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__0'
      IL_0095:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Target
      IL_009a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__0'
      IL_009f:  ldloc.0
      IL_00a0:  ldnull
      IL_00a1:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>::Invoke(!0,
                                                                                                                                                               !1,
                                                                                                                                                               !2)
      IL_00a6:  stloc.1
      IL_00a7:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__4'
      IL_00ac:  brtrue.s   IL_00da

      IL_00ae:  ldc.i4.0
      IL_00af:  ldc.i4.s   84
      IL_00b1:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_00b6:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_00bb:  ldc.i4.1
      IL_00bc:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_00c1:  dup
      IL_00c2:  ldc.i4.0
      IL_00c3:  ldc.i4.0
      IL_00c4:  ldnull
      IL_00c5:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_00ca:  stelem.ref
      IL_00cb:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::UnaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                     valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                     class [mscorlib]System.Type,
                                                                                                                                                                     class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_00d0:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_00d5:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__4'
      IL_00da:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__4'
      IL_00df:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Target
      IL_00e4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__4'
      IL_00e9:  ldloc.1
      IL_00ea:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>::Invoke(!0,
                                                                                                                                                      !1)
      IL_00ef:  brtrue     IL_01dd

      IL_00f4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__3'
      IL_00f9:  brtrue.s   IL_0130

      IL_00fb:  ldc.i4.8
      IL_00fc:  ldc.i4.2
      IL_00fd:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_0102:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0107:  ldc.i4.2
      IL_0108:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_010d:  dup
      IL_010e:  ldc.i4.0
      IL_010f:  ldc.i4.0
      IL_0110:  ldnull
      IL_0111:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0116:  stelem.ref
      IL_0117:  dup
      IL_0118:  ldc.i4.1
      IL_0119:  ldc.i4.0
      IL_011a:  ldnull
      IL_011b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0120:  stelem.ref
      IL_0121:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0126:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_012b:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__3'
      IL_0130:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__3'
      IL_0135:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Target
      IL_013a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__3'
      IL_013f:  ldloc.1
      IL_0140:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__2'
      IL_0145:  brtrue.s   IL_0177

      IL_0147:  ldc.i4.0
      IL_0148:  ldstr      "GetIsDone"
      IL_014d:  ldnull
      IL_014e:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_0153:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0158:  ldc.i4.1
      IL_0159:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_015e:  dup
      IL_015f:  ldc.i4.0
      IL_0160:  ldc.i4.0
      IL_0161:  ldnull
      IL_0162:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0167:  stelem.ref
      IL_0168:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_016d:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0172:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__2'
      IL_0177:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__2'
      IL_017c:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Target
      IL_0181:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__2'
      IL_0186:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__1'
      IL_018b:  brtrue.s   IL_01bc

      IL_018d:  ldc.i4.0
      IL_018e:  ldstr      "EconomicsAnalysisHelperNew"
      IL_0193:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
      IL_0198:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_019d:  ldc.i4.1
      IL_019e:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_01a3:  dup
      IL_01a4:  ldc.i4.0
      IL_01a5:  ldc.i4.0
      IL_01a6:  ldnull
      IL_01a7:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_01ac:  stelem.ref
      IL_01ad:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::GetMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                string,
                                                                                                                                                                class [mscorlib]System.Type,
                                                                                                                                                                class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_01b2:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_01b7:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__1'
      IL_01bc:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__1'
      IL_01c1:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Target
      IL_01c6:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/'<>o__132'::'<>p__1'
      IL_01cb:  ldloc.0
      IL_01cc:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>::Invoke(!0,
                                                                                                                                                        !1)
      IL_01d1:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>::Invoke(!0,
                                                                                                                                                        !1)
      IL_01d6:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>::Invoke(!0,
                                                                                                                                                               !1,
                                                                                                                                                               !2)
      IL_01db:  br.s       IL_01de

      IL_01dd:  ldloc.1
      IL_01de:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>::Invoke(!0,
                                                                                                                                                      !1)
      IL_01e3:  brfalse.s  IL_01eb

      IL_01e5:  ldarg.0
      IL_01e6:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::StopTimerAndRefresh_Evaluate()
      IL_01eb:  leave.s    IL_01f6

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_01ed:  pop
      IL_01ee:  ldarg.0
      IL_01ef:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::StopTimerAndRefresh_Evaluate()
      IL_01f4:  leave.s    IL_01f6

    }  // end handler
    IL_01f6:  ret
  } // end of method MMSummaryGridFormViewModel::DispatcherTimer_Evaluate_Tick

  .method private hidebysig instance void 
          StopTimerAndRefresh_Evaluate() cil managed
  {
    // Code size       23 (0x17)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [WindowsBase]System.Windows.Threading.DispatcherTimer AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::_dispatcherTimer_evaluate
    IL_0006:  callvirt   instance void [WindowsBase]System.Windows.Threading.DispatcherTimer::Stop()
    IL_000b:  call       void [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.MmgSor::MMReconnectDataShare()
    IL_0010:  ldarg.0
    IL_0011:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::OnUpdateData()
    IL_0016:  ret
  } // end of method MMSummaryGridFormViewModel::StopTimerAndRefresh_Evaluate

  .method private hidebysig instance bool 
          EvaluateBehavior_CanExecute() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  call       int32 [AspenTech.AspenPlus.UnmanagedWrapper]AspenTech.AspenPlus.UnmanagedWrapper.SummaryGridWrapper::GetStatus()
    IL_0005:  ldc.i4.3
    IL_0006:  clt
    IL_0008:  ldc.i4.0
    IL_0009:  ceq
    IL_000b:  ret
  } // end of method MMSummaryGridFormViewModel::EvaluateBehavior_CanExecute

  .method public hidebysig specialname instance valuetype [PresentationCore]System.Windows.Visibility 
          get_APEABannerVisibility() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype [PresentationCore]System.Windows.Visibility AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<APEABannerVisibility>k__BackingField'
    IL_0006:  ret
  } // end of method MMSummaryGridFormViewModel::get_APEABannerVisibility

  .method public hidebysig specialname instance void 
          set_APEABannerVisibility(valuetype [PresentationCore]System.Windows.Visibility 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      valuetype [PresentationCore]System.Windows.Visibility AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::'<APEABannerVisibility>k__BackingField'
    IL_0007:  ret
  } // end of method MMSummaryGridFormViewModel::set_APEABannerVisibility

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMSummaryGridFormViewModel::.ctor

  .method private hidebysig instance void 
          '<EquipmentCallback>b__94_0'() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       60 (0x3c)
    .maxstack  8
    IL_0000:  call       void [PresentationCore]System.Windows.Input.CommandManager::InvalidateRequerySuggested()
    IL_0005:  ldarg.0
    IL_0006:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_000b:  brtrue.s   IL_000e

    IL_000d:  ret

    IL_000e:  ldarg.0
    IL_000f:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0014:  ldstr      "Top.appModelV8.Custom Actions"
    IL_0019:  ldstr      "RunPostProcessingCompletedEvent"
    IL_001e:  ldc.i4.0
    IL_001f:  ldc.i4.1
    IL_0020:  newarr     [mscorlib]System.Object
    IL_0025:  dup
    IL_0026:  ldc.i4.0
    IL_0027:  ldc.i4.1
    IL_0028:  box        [mscorlib]System.Boolean
    IL_002d:  stelem.ref
    IL_002e:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::InvokeAction(string,
                                                                                                                                                                                                                        string,
                                                                                                                                                                                                                        bool,
                                                                                                                                                                                                                        object[])
    IL_0033:  pop
    IL_0034:  ldarg.0
    IL_0035:  call       instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_UnityContainer()
    IL_003a:  pop
    IL_003b:  ret
  } // end of method MMSummaryGridFormViewModel::'<EquipmentCallback>b__94_0'

  .property instance callconv(8) class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView
          SummaryGridView()
  {
    .get instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SummaryGridView()
  } // end of property MMSummaryGridFormViewModel::SummaryGridView
  .property instance callconv(8) class AspenTech.AspenPlus.Happ.HappLS
          EventAttachedHappLS()
  {
    .get instance class AspenTech.AspenPlus.Happ.HappLS AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_EventAttachedHappLS()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_EventAttachedHappLS(class AspenTech.AspenPlus.Happ.HappLS)
  } // end of property MMSummaryGridFormViewModel::EventAttachedHappLS
  .property instance callconv(8) class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase
          EventAttachedCase()
  {
    .get instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_EventAttachedCase()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_EventAttachedCase(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
  } // end of property MMSummaryGridFormViewModel::EventAttachedCase
  .property instance callconv(8) string XmlConfiguration()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_XmlConfiguration()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_XmlConfiguration(string)
  } // end of property MMSummaryGridFormViewModel::XmlConfiguration
  .property instance callconv(8) string CurrentUnits()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_CurrentUnits()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_CurrentUnits(string)
  } // end of property MMSummaryGridFormViewModel::CurrentUnits
  .property instance callconv(8) native int
          CurrentWindowPointer()
  {
    .get instance native int AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_CurrentWindowPointer()
  } // end of property MMSummaryGridFormViewModel::CurrentWindowPointer
  .property instance callconv(8) string HierarchyScope()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_HierarchyScope()
  } // end of property MMSummaryGridFormViewModel::HierarchyScope
  .property instance callconv(8) class AspenTech.AspenPlus.Happ.IHNode
          MainNode()
  {
    .get instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_MainNode()
  } // end of property MMSummaryGridFormViewModel::MainNode
  .property instance callconv(8) string ScopedId()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_ScopedId()
  } // end of property MMSummaryGridFormViewModel::ScopedId
  .property instance callconv(8) bool HasFlagForLoading()
  {
    .get instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_HasFlagForLoading()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_HasFlagForLoading(bool)
  } // end of property MMSummaryGridFormViewModel::HasFlagForLoading
  .property instance callconv(8) class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior
          CopyBehavior()
  {
    .get instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_CopyBehavior()
  } // end of property MMSummaryGridFormViewModel::CopyBehavior
  .property instance callconv(8) class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior
          MapBehavior()
  {
    .get instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_MapBehavior()
  } // end of property MMSummaryGridFormViewModel::MapBehavior
  .property instance callconv(8) class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior
          UnmapBehavior()
  {
    .get instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_UnmapBehavior()
  } // end of property MMSummaryGridFormViewModel::UnmapBehavior
  .property instance callconv(8) class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior
          OpenFormBehavior()
  {
    .get instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_OpenFormBehavior()
  } // end of property MMSummaryGridFormViewModel::OpenFormBehavior
  .property instance callconv(8) class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior
          SizeBehavior()
  {
    .get instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_SizeBehavior()
  } // end of property MMSummaryGridFormViewModel::SizeBehavior
  .property instance callconv(8) class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior
          EvaluateBehavior()
  {
    .get instance class AspenTech.AspenPlus.MMForms.SummaryGrid.ButtonBehavior AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_EvaluateBehavior()
  } // end of property MMSummaryGridFormViewModel::EvaluateBehavior
  .property instance callconv(8) valuetype [PresentationCore]System.Windows.Visibility
          APEABannerVisibility()
  {
    .get instance valuetype [PresentationCore]System.Windows.Visibility AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_APEABannerVisibility()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::set_APEABannerVisibility(valuetype [PresentationCore]System.Windows.Visibility)
  } // end of property MMSummaryGridFormViewModel::APEABannerVisibility
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView,
                  [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 20 4D 4D 53 75 6D 6D 61 72 79 47 72 69 64   // .. MMSummaryGrid
                                                                                                    2E 4D 4D 53 75 6D 6D 61 72 79 47 72 69 64 5F 4D   // .MMSummaryGrid_M
                                                                                                    61 69 6E 00 00 )                                  // ain..
  .field private initonly class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid _summaryGrid
  .field private static literal string _CModelSumGrid = "Model"
  .field private static literal string _CEconAnalysisGrid = "Econ"
  .field assembly class [PresentationFramework]System.Windows.Controls.DockPanel dockPanel
  .field assembly class [PresentationFramework]System.Windows.Controls.StackPanel stackPanel
  .field assembly class [PresentationFramework]System.Windows.Controls.Button buttonCopy
  .field assembly class [PresentationFramework]System.Windows.Controls.Button buttonMap
  .field assembly class [PresentationFramework]System.Windows.Controls.Button buttonUnmap
  .field assembly class [PresentationFramework]System.Windows.Controls.Button buttonOpenForm
  .field assembly class [PresentationFramework]System.Windows.Controls.Button buttonSize
  .field assembly class [PresentationFramework]System.Windows.Controls.Button buttonEvaluate
  .field assembly class [PresentationFramework]System.Windows.Controls.Border Border1
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       98 (0x62)
    .maxstack  3
    .locals init ()
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::InitializeComponent()
    IL_001c:  ldarg.0
    IL_001d:  newobj     instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::.ctor()
    IL_0022:  stfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0027:  ldarg.0
    IL_0028:  ldfld      class [PresentationFramework]System.Windows.Controls.Border AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::Border1
    IL_002d:  ldarg.0
    IL_002e:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0033:  callvirt   instance void [PresentationFramework]System.Windows.Controls.Decorator::set_Child(class [PresentationCore]System.Windows.UIElement)
    IL_0038:  ldarg.0
    IL_0039:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_003e:  ldarg.0
    IL_003f:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid_OnSummaryGridTplColChange(object,
                                                                                                                                         class [mscorlib]System.EventArgs)
    IL_0045:  newobj     instance void [mscorlib]System.EventHandler::.ctor(object,
                                                                            native int)
    IL_004a:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::add_OnSummaryGridTplColChange(class [mscorlib]System.EventHandler)
    IL_004f:  ldarg.0
    IL_0050:  ldarg.0
    IL_0051:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::MMSummaryGridForm_Loaded(object,
                                                                                                                           class [PresentationCore]System.Windows.RoutedEventArgs)
    IL_0057:  newobj     instance void [PresentationCore]System.Windows.RoutedEventHandler::.ctor(object,
                                                                                                  native int)
    IL_005c:  call       instance void [PresentationFramework]System.Windows.FrameworkElement::add_Loaded(class [PresentationCore]System.Windows.RoutedEventHandler)
    IL_0061:  ret
  } // end of method MMSummaryGridForm::.ctor

  .method private hidebysig instance void 
          MMSummaryGridForm_Loaded(object sender,
                                   class [PresentationCore]System.Windows.RoutedEventArgs e) cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  1
    .locals init (class AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::get_ViewModel()
    IL_0006:  isinst     AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
    IL_000b:  stloc.0
    IL_000c:  ldloc.0
    IL_000d:  brfalse.s  IL_001d

    IL_000f:  ldloc.0
    IL_0010:  callvirt   instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::get_HasFlagForLoading()
    IL_0015:  brfalse.s  IL_001d

    IL_0017:  ldloc.0
    IL_0018:  callvirt   instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::TryInitializeViewData()
    IL_001d:  ret
  } // end of method MMSummaryGridForm::MMSummaryGridForm_Loaded

  .method private hidebysig instance void 
          _summaryGrid_OnSummaryGridTplColChange(object sender,
                                                 class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       28 (0x1c)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::GetCurSumGridType()
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  call       bool [mscorlib]System.String::IsNullOrWhiteSpace(string)
    IL_000d:  brtrue.s   IL_001b

    IL_000f:  ldarg.0
    IL_0010:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0015:  ldloc.0
    IL_0016:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::SaveTemplatesToCase(string)
    IL_001b:  ret
  } // end of method MMSummaryGridForm::_summaryGrid_OnSummaryGridTplColChange

  .method private hidebysig newslot specialname virtual final 
          instance string[]  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedRows() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedRows
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0006:  callvirt   instance string[] [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::get_SelectedRows()
    IL_000b:  ret
  } // end of method MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedRows

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedTab() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_SelectedTab
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0006:  callvirt   instance string [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::get_SelectedTab()
    IL_000b:  ret
  } // end of method MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedTab

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_SelectedTab(string 'value') cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::set_SelectedTab
    // Code size       18 (0x12)
    .maxstack  2
    .locals init ()
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
      IL_0006:  ldarg.1
      IL_0007:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_SelectedTab(string)
      IL_000c:  leave.s    IL_0011

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_000e:  pop
      IL_000f:  leave.s    IL_0011

    }  // end handler
    IL_0011:  ret
  } // end of method MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_SelectedTab

  .method private hidebysig newslot specialname virtual final 
          instance bool  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_IsVisible() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::get_IsVisible
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0006:  callvirt   instance bool [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::get_Visible()
    IL_000b:  ret
  } // end of method MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_IsVisible

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_IsVisible(bool 'value') cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::set_IsVisible
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_Visible(bool)
    IL_000c:  ret
  } // end of method MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_IsVisible

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.Initialize(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase cxsCase,
                                                                                             string configurationXml) cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::Initialize
    // Code size       151 (0x97)
    .maxstack  3
    .locals init (class AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel V_0,
             string V_1,
             string V_2)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::get_ViewModel()
    IL_0006:  isinst     AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
    IL_000b:  stloc.0
    IL_000c:  ldloc.0
    IL_000d:  brfalse.s  IL_002a

    IL_000f:  ldloc.0
    IL_0010:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::GetSingleObjectToDisplay()
    IL_0015:  stloc.2
    IL_0016:  ldloc.2
    IL_0017:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_001c:  brtrue.s   IL_002a

    IL_001e:  ldarg.0
    IL_001f:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0024:  ldloc.2
    IL_0025:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_SingleObjectToDisplay(string)
    IL_002a:  ldarg.0
    IL_002b:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0030:  ldarg.1
    IL_0031:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::get_ApplicationName()
    IL_0036:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_ApplicationName(string)
    IL_003b:  ldarg.0
    IL_003c:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0041:  ldarg.1
    IL_0042:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_Case(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_0047:  ldarg.0
    IL_0048:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_004d:  ldarg.1
    IL_004e:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::get_CaseFullFilePath()
    IL_0053:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_CasePath(string)
    IL_0058:  ldarg.0
    IL_0059:  call       instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::GetCurSumGridType()
    IL_005e:  stloc.1
    IL_005f:  ldloc.1
    IL_0060:  call       bool [mscorlib]System.String::IsNullOrWhiteSpace(string)
    IL_0065:  brtrue.s   IL_0073

    IL_0067:  ldarg.0
    IL_0068:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_006d:  ldloc.1
    IL_006e:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::SetTemplatesFromCase(string)
    IL_0073:  ldarg.0
    IL_0074:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0079:  ldarg.2
    IL_007a:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_Configuration(string)
    IL_007f:  ldarg.0
    IL_0080:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0085:  ldarg.0
    IL_0086:  ldftn      instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid_OnBatchSet(object,
                                                                                                                          class [mscorlib]System.EventArgs)
    IL_008c:  newobj     instance void [mscorlib]System.EventHandler::.ctor(object,
                                                                            native int)
    IL_0091:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::add_OnBatchSet(class [mscorlib]System.EventHandler)
    IL_0096:  ret
  } // end of method MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.Initialize

  .method private hidebysig instance string 
          GetCurSumGridType() cil managed
  {
    // Code size       115 (0x73)
    .maxstack  3
    .locals init (string V_0,
             class AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel V_1,
             string V_2,
             string V_3,
             string V_4)
    IL_0000:  ldsfld     string [mscorlib]System.String::Empty
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::get_ViewModel()
    IL_000c:  brfalse.s  IL_0071

    IL_000e:  ldarg.0
    IL_000f:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::get_ViewModel()
    IL_0014:  isinst     AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
    IL_0019:  brfalse.s  IL_0071

    IL_001b:  ldarg.0
    IL_001c:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::get_ViewModel()
    IL_0021:  isinst     AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel
    IL_0026:  stloc.1
    IL_0027:  ldarg.0
    IL_0028:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::get_ViewModel()
    IL_002d:  ldloc.1
    IL_002e:  ldc.i4.5
    IL_002f:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::GetConstString(valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString)
    IL_0034:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveParameter(string)
    IL_0039:  isinst     [mscorlib]System.String
    IL_003e:  stloc.2
    IL_003f:  ldloc.1
    IL_0040:  ldc.i4.7
    IL_0041:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::GetConstString(valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString)
    IL_0046:  stloc.3
    IL_0047:  ldloc.1
    IL_0048:  ldc.i4.8
    IL_0049:  callvirt   instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel::GetConstString(valuetype AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridFormViewModel/ConstString)
    IL_004e:  stloc.s    V_4
    IL_0050:  ldloc.2
    IL_0051:  ldloc.3
    IL_0052:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0057:  brfalse.s  IL_0061

    IL_0059:  ldstr      "Model"
    IL_005e:  stloc.0
    IL_005f:  br.s       IL_0071

    IL_0061:  ldloc.2
    IL_0062:  ldloc.s    V_4
    IL_0064:  call       bool AspenTech.AspenPlus.MMForms.SummaryGrid.BlockSummaryHelper::InvariantEquals(string,
                                                                                                          string)
    IL_0069:  brfalse.s  IL_0071

    IL_006b:  ldstr      "Econ"
    IL_0070:  stloc.0
    IL_0071:  ldloc.0
    IL_0072:  ret
  } // end of method MMSummaryGridForm::GetCurSumGridType

  .method private hidebysig instance void 
          _summaryGrid_OnBatchSet(object sender,
                                  class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::OnUpdateAll()
    IL_0006:  ret
  } // end of method MMSummaryGridForm::_summaryGrid_OnBatchSet

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.RefreshData() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::RefreshData
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0006:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::RefreshData()
    IL_000b:  ret
  } // end of method MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.RefreshData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.CopyToClipboard() cil managed
  {
    .override AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView::CopyToClipboard
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0006:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::CopyToClipboard()
    IL_000b:  ret
  } // end of method MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.CopyToClipboard

  .method public hidebysig specialname instance bool 
          get_UseCachedData() cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0006:  brtrue.s   IL_000a

    IL_0008:  ldc.i4.0
    IL_0009:  ret

    IL_000a:  ldarg.0
    IL_000b:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0010:  callvirt   instance bool [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::get_UseProvidedRowInfo()
    IL_0015:  ret
  } // end of method MMSummaryGridForm::get_UseCachedData

  .method public hidebysig specialname instance void 
          set_UseCachedData(bool 'value') cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0006:  brfalse.s  IL_0014

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_000e:  ldarg.1
    IL_000f:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_UseProvidedRowInfo(bool)
    IL_0014:  ret
  } // end of method MMSummaryGridForm::set_UseCachedData

  .method public hidebysig instance void 
          SetSelectedTab(string tabName) cil managed
  {
    // Code size       45 (0x2d)
    .maxstack  2
    .locals init (string[] V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0006:  callvirt   instance string[] [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::GetTabNames()
    IL_000b:  stloc.0
    IL_000c:  ldloc.0
    IL_000d:  brfalse.s  IL_002c

    IL_000f:  ldloc.0
    IL_0010:  ldarg.1
    IL_0011:  call       bool [System.Core]System.Linq.Enumerable::Contains<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                    !!0)
    IL_0016:  brfalse.s  IL_002c

    IL_0018:  ldarg.1
    IL_0019:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_001e:  brtrue.s   IL_002c

    IL_0020:  ldarg.0
    IL_0021:  ldfld      class [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_summaryGrid
    IL_0026:  ldarg.1
    IL_0027:  callvirt   instance void [AspenTech.AspenCxs.SummaryGrid]AspenTech.AspenCxs.SummaryGrid.TabbedSummaryGrid::set_SelectedTab(string)
    IL_002c:  ret
  } // end of method MMSummaryGridForm::SetSelectedTab

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.SummaryGrid;component"
    + "/mmsummarygridform.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMSummaryGridForm::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       171 (0xab)
    .maxstack  2
    .locals init ()
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_002e,
                          IL_003b,
                          IL_0048,
                          IL_0055,
                          IL_0062,
                          IL_006f,
                          IL_007c,
                          IL_0089,
                          IL_0096)
    IL_002c:  br.s       IL_00a3

    IL_002e:  ldarg.0
    IL_002f:  ldarg.2
    IL_0030:  castclass  [PresentationFramework]System.Windows.Controls.DockPanel
    IL_0035:  stfld      class [PresentationFramework]System.Windows.Controls.DockPanel AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::dockPanel
    IL_003a:  ret

    IL_003b:  ldarg.0
    IL_003c:  ldarg.2
    IL_003d:  castclass  [PresentationFramework]System.Windows.Controls.StackPanel
    IL_0042:  stfld      class [PresentationFramework]System.Windows.Controls.StackPanel AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::stackPanel
    IL_0047:  ret

    IL_0048:  ldarg.0
    IL_0049:  ldarg.2
    IL_004a:  castclass  [PresentationFramework]System.Windows.Controls.Button
    IL_004f:  stfld      class [PresentationFramework]System.Windows.Controls.Button AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::buttonCopy
    IL_0054:  ret

    IL_0055:  ldarg.0
    IL_0056:  ldarg.2
    IL_0057:  castclass  [PresentationFramework]System.Windows.Controls.Button
    IL_005c:  stfld      class [PresentationFramework]System.Windows.Controls.Button AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::buttonMap
    IL_0061:  ret

    IL_0062:  ldarg.0
    IL_0063:  ldarg.2
    IL_0064:  castclass  [PresentationFramework]System.Windows.Controls.Button
    IL_0069:  stfld      class [PresentationFramework]System.Windows.Controls.Button AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::buttonUnmap
    IL_006e:  ret

    IL_006f:  ldarg.0
    IL_0070:  ldarg.2
    IL_0071:  castclass  [PresentationFramework]System.Windows.Controls.Button
    IL_0076:  stfld      class [PresentationFramework]System.Windows.Controls.Button AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::buttonOpenForm
    IL_007b:  ret

    IL_007c:  ldarg.0
    IL_007d:  ldarg.2
    IL_007e:  castclass  [PresentationFramework]System.Windows.Controls.Button
    IL_0083:  stfld      class [PresentationFramework]System.Windows.Controls.Button AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::buttonSize
    IL_0088:  ret

    IL_0089:  ldarg.0
    IL_008a:  ldarg.2
    IL_008b:  castclass  [PresentationFramework]System.Windows.Controls.Button
    IL_0090:  stfld      class [PresentationFramework]System.Windows.Controls.Button AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::buttonEvaluate
    IL_0095:  ret

    IL_0096:  ldarg.0
    IL_0097:  ldarg.2
    IL_0098:  castclass  [PresentationFramework]System.Windows.Controls.Border
    IL_009d:  stfld      class [PresentationFramework]System.Windows.Controls.Border AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::Border1
    IL_00a2:  ret

    IL_00a3:  ldarg.0
    IL_00a4:  ldc.i4.1
    IL_00a5:  stfld      bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::_contentLoaded
    IL_00aa:  ret
  } // end of method MMSummaryGridForm::System.Windows.Markup.IComponentConnector.Connect

  .property instance callconv(8) string[]
          AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedRows()
  {
    .get instance string[] AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedRows()
  } // end of property MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedRows
  .property instance callconv(8) string AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedTab()
  {
    .get instance string AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_SelectedTab()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_SelectedTab(string)
  } // end of property MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.SelectedTab
  .property instance callconv(8) bool AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.IsVisible()
  {
    .get instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.get_IsVisible()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.set_IsVisible(bool)
  } // end of property MMSummaryGridForm::AspenTech.AspenPlus.MMForms.SummaryGrid.ISummaryGridView.IsVisible
  .property instance callconv(8) bool UseCachedData()
  {
    .get instance bool AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::get_UseCachedData()
    .set instance void AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm::set_UseCachedData(bool)
  } // end of property MMSummaryGridForm::UseCachedData
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.MMSummaryGridForm

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.SummaryGridModule
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMFormsModuleBase
{
  .custom instance void [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Modularity.ModuleAttribute::.ctor() = ( 01 00 01 00 54 0E 0A 4D 6F 64 75 6C 65 4E 61 6D   // ....T..ModuleNam
                                                                                                                             65 11 53 75 6D 6D 61 72 79 47 72 69 64 4D 6F 64   // e.SummaryGridMod
                                                                                                                             75 6C 65 )                                        // ule
  .custom instance void [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Modularity.ModuleDependencyAttribute::.ctor(string) = ( 01 00 2F 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ../AspenTech.Asp
                                                                                                                                             65 6E 50 6C 75 73 2E 4D 4D 43 6F 6E 74 72 6F 6C   // enPlus.MMControl
                                                                                                                                             73 2E 4D 4D 43 6F 6E 74 72 6F 6C 73 4D 6F 64 75   // s.MMControlsModu
                                                                                                                                             6C 65 00 00 )                                     // le..
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer container) cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMFormsModuleBase::.ctor(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer)
    IL_0007:  ret
  } // end of method SummaryGridModule::.ctor

} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.SummaryGridModule

.class private auto ansi sealed beforefieldinit AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings
       extends [System]System.Configuration.ApplicationSettingsBase
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 4B 4D 69 63 72 6F 73 6F 66 74 2E 56 69 73   // ..KMicrosoft.Vis
                                                                                                  75 61 6C 53 74 75 64 69 6F 2E 45 64 69 74 6F 72   // ualStudio.Editor
                                                                                                  73 2E 53 65 74 74 69 6E 67 73 44 65 73 69 67 6E   // s.SettingsDesign
                                                                                                  65 72 2E 53 65 74 74 69 6E 67 73 53 69 6E 67 6C   // er.SettingsSingl
                                                                                                  65 46 69 6C 65 47 65 6E 65 72 61 74 6F 72 09 31   // eFileGenerator.1
                                                                                                  36 2E 31 30 2E 30 2E 30 00 00 )                   // 6.10.0.0..
  .field private static class AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings defaultInstance
  .method public hidebysig specialname static 
          class AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings 
          get_Default() cil managed
  {
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  ldsfld     class AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings::defaultInstance
    IL_0005:  ret
  } // end of method Settings::get_Default

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [System]System.Configuration.ApplicationSettingsBase::.ctor()
    IL_0006:  ret
  } // end of method Settings::.ctor

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  newobj     instance void AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings::.ctor()
    IL_0005:  call       class [System]System.Configuration.SettingsBase [System]System.Configuration.SettingsBase::Synchronized(class [System]System.Configuration.SettingsBase)
    IL_000a:  castclass  AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings
    IL_000f:  stsfld     class AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings::defaultInstance
    IL_0014:  ret
  } // end of method Settings::.cctor

  .property callconv(8) class AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings
          Default()
  {
    .get class AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings::get_Default()
  } // end of property Settings::Default
} // end of class AspenTech.AspenPlus.MMForms.SummaryGrid.Properties.Settings

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.HappLS
       implements AspenTech.AspenPlus.Happ.IHapp,
                  AspenTech.AspenPlus.Happ.IAPHappEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 38 45 35 36 37 35 32 31 2D 46 39 42 41   // ..$8E567521-F9BA
                                                                                                  2D 31 31 43 46 2D 39 30 42 32 2D 30 30 30 30 43   // -11CF-90B2-0000C
                                                                                                  30 41 38 31 30 43 34 00 00 )                      // 0A810C4..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 5A 53 79 73 74 65 6D 2E 4F 62 6A 65 63 74   // ..ZSystem.Object
                                                                                                                          2C 20 6D 73 63 6F 72 6C 69 62 2C 20 56 65 72 73   // , mscorlib, Vers
                                                                                                                          69 6F 6E 3D 34 2E 30 2E 30 2E 30 2C 20 43 75 6C   // ion=4.0.0.0, Cul
                                                                                                                          74 75 72 65 3D 6E 65 75 74 72 61 6C 2C 20 50 75   // ture=neutral, Pu
                                                                                                                          62 6C 69 63 4B 65 79 54 6F 6B 65 6E 3D 62 37 37   // blicKeyToken=b77
                                                                                                                          61 35 63 35 36 31 39 33 34 65 30 38 39 00 00 )    // a5c561934e089..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.Happ.HappLS

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.IAPHappEvents
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 35 30 33 46 44 36 33 32 2D 46 36 33 45   // ..$503FD632-F63E
                                                                                                  2D 31 31 44 31 2D 38 44 33 45 2D 30 30 30 30 43   // -11D1-8D3E-0000C
                                                                                                  30 33 33 45 41 46 32 00 00 )                      // 033EAF2..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.Happ.IAPHappEvents

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.IAPHappEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComEventInterfaceAttribute::.ctor(class [mscorlib]System.Type,
                                                                                                   class [mscorlib]System.Type) = ( 01 00 26 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..&AspenTech.Asp
                                                                                                                                    65 6E 50 6C 75 73 2E 48 61 70 70 2E 49 41 50 48   // enPlus.Happ.IAPH
                                                                                                                                    61 70 70 45 76 65 6E 74 73 26 41 73 70 65 6E 54   // appEvents&AspenT
                                                                                                                                    65 63 68 2E 41 73 70 65 6E 50 6C 75 73 2E 48 61   // ech.AspenPlus.Ha
                                                                                                                                    70 70 2E 49 41 50 48 61 70 70 45 76 65 6E 74 73   // pp.IAPHappEvents
                                                                                                                                    00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor(string,
                                                                                                string) = ( 01 00 24 38 45 35 36 37 35 32 30 2D 46 39 42 41   // ..$8E567520-F9BA
                                                                                                            2D 31 31 43 46 2D 39 30 42 32 2D 30 30 30 30 43   // -11CF-90B2-0000C
                                                                                                            30 41 38 31 30 43 34 2C 41 73 70 65 6E 54 65 63   // 0A810C4,AspenTec
                                                                                                            68 2E 41 73 70 65 6E 50 6C 75 73 2E 48 61 70 70   // h.AspenPlus.Happ
                                                                                                            2E 49 41 50 48 61 70 70 45 76 65 6E 74 73 5F 45   // .IAPHappEvents_E
                                                                                                            76 65 6E 74 00 00 )                               // vent..
} // end of class AspenTech.AspenPlus.Happ.IAPHappEvents_Event

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.IHNode
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 38 45 35 36 37 35 32 32 2D 46 39 42 41   // ..$8E567522-F9BA
                                                                                                  2D 31 31 43 46 2D 39 30 42 32 2D 30 30 30 30 43   // -11CF-90B2-0000C
                                                                                                  30 41 38 31 30 43 34 00 00 )                      // 0A810C4..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_12() runtime managed
  {
  } // end of method IHNode::_VtblGap1_12

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_AttributeValue([in] int16 attrnumber,
                             [in][opt] object  marshal( struct) force) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 02 60 00 00 )                         // .....`..
  } // end of method IHNode::get_AttributeValue

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_AttributeValue([in] int16 attrnumber,
                                            [in][opt] object  marshal( struct) force,
                                            [in] object  marshal( struct) Value) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 02 60 00 00 )                         // .....`..
  } // end of method IHNode::set_AttributeValue

  .property callconv(8) object AttributeValue(int16,
                                              object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.Happ.IHNode::get_AttributeValue(int16,
                                                                             object)
    .set instance void AspenTech.AspenPlus.Happ.IHNode::set_AttributeValue(int16,
                                                                           object,
                                                                           object)
  } // end of property IHNode::AttributeValue
} // end of class AspenTech.AspenPlus.Happ.IHNode

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.IHapp
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 4E 61 6D 65 00 00 )                      // ...Name..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 38 45 35 36 37 35 32 31 2D 46 39 42 41   // ..$8E567521-F9BA
                                                                                                  2D 31 31 43 46 2D 39 30 42 32 2D 30 30 30 30 43   // -11CF-90B2-0000C
                                                                                                  30 41 38 31 30 43 34 00 00 )                      // 0A810C4..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_3() runtime managed
  {
  } // end of method IHapp::_VtblGap1_3

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IHapp::get_Name

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.Happ.IHapp::get_Name()
  } // end of property IHapp::Name
} // end of class AspenTech.AspenPlus.Happ.IHapp


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file C:\Users\Administrator\Desktop\Aspen 逆向\.local\batch-roundtrip-20261125\work-il\clr-sj2nbhzo\editable\source.res
