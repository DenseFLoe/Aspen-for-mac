# ColumnConverter.cs

Source: editable/ColumnConverters/ColumnConverter.cs

Source SHA-256: c6d101459374266bf35c858398953958c94b963cb5f5bbd369fca944f81f3e0b
