using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLScreen;

[RibbonPlotWizardMgr("WpfPLSCREEN.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class ScreenPlotWizardModule : PlotModuleBase
{
}
