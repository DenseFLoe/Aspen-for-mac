"""Dump IL of the compiled candidate into <work>/<sha8>/cand.il.

Usage: dumpcand.py <sha8>
"""
import json, subprocess, sys
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
DOTNET = r"C:\Program Files\dotnet\dotnet.exe"
ILSPY = (r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\pseudocode-batch-20261124"
         r"\tooling\ilspycmd-9.1\tools\net8.0\any\ilspycmd.dll")
WORK = Path(__file__).resolve().parent.parent


def run(sha8):
    for line in open(BASE / "per-file.jsonl", encoding="utf-8"):
        r = json.loads(line)
        if r["sha256"].startswith(sha8):
            break
    else:
        raise SystemExit("no ledger row")
    target = WORK / sha8 / "out" / r["name"]
    p = subprocess.run([DOTNET, ILSPY, "-il", str(target)], capture_output=True, timeout=1800)
    (WORK / sha8 / "cand.il").write_bytes(p.stdout)
    print(json.dumps({"sha8": sha8, "rc": p.returncode, "bytes": len(p.stdout)}, ensure_ascii=False))
    return 0 if p.returncode == 0 else 1


if __name__ == "__main__":
    sys.exit(run(sys.argv[1]))
