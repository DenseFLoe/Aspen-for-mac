"""Reassemble the authored IL and restore its bodyless COM interface slot flags."""
import argparse
import json
from pathlib import Path
import re
import struct
import subprocess

from pefile import PE

def read_u16(block, offset):
    return struct.unpack_from("<H", block, offset)[0]

def read_u32(block, offset):
    return struct.unpack_from("<I", block, offset)[0]

class MethodTable:
    """Locate #Strings and ECMA-335 MethodDef rows in a compressed CLR metadata stream."""
    def __init__(self, image):
        self.image = image
        self.pe = PE(data=bytes(image), fast_load=True)
        cli = self.pe.OPTIONAL_HEADER.DATA_DIRECTORY[14]
        header = self.pe.get_offset_from_rva(cli.VirtualAddress)
        root = self.pe.get_offset_from_rva(read_u32(image, header + 8))
        if image[root:root + 4] != b"BSJB":
            raise ValueError("Unrecognized CLR metadata root")
        pos = root + 16 + read_u32(image, root + 12)
        stream_count = read_u16(image, pos + 2)
        pos += 4
        streams = {}
        for _ in range(stream_count):
            offset, size = struct.unpack_from("<II", image, pos)
            end = image.index(0, pos + 8)
            streams[bytes(image[pos + 8:end]).decode("ascii")] = (root + offset, size)
            pos = pos + 8 + ((end - pos - 8 + 4) & ~3)
        self.strings, self.strings_size = streams["#Strings"]
        table, size = streams["#~"]
        heaps = image[table + 6]
        self.string_width = 4 if heaps & 1 else 2
        guid_width = 4 if heaps & 2 else 2
        blob_width = 4 if heaps & 4 else 2
        valid = struct.unpack_from("<Q", image, table + 8)[0]
        pos = table + 24
        counts = [0] * 64
        for tid in range(64):
            if valid & (1 << tid):
                counts[tid] = read_u32(image, pos)
                pos += 4

        def index_width(tid):
            return 4 if counts[tid] >= 65536 else 2

        def coded_width(bits, tables):
            return 4 if max(counts[tid] for tid in tables) >= (1 << (16 - bits)) else 2

        preceding_row_sizes = [
            2 + self.string_width + 3 * guid_width,
            coded_width(2, [0, 26, 35, 1]) + 2 * self.string_width,
            4 + 2 * self.string_width + coded_width(2, [2, 1, 27]) + index_width(4) + index_width(6),
            index_width(4), 2 + self.string_width + blob_width, index_width(6),
        ]
        self.start = pos + sum(counts[i] * width for i, width in enumerate(preceding_row_sizes))
        self.count = counts[6]
        self.row_size = 8 + self.string_width + blob_width + index_width(8)
        if self.start + self.count * self.row_size > table + size:
            raise ValueError("Invalid MethodDef extent")

    def rows(self):
        for rid in range(1, self.count + 1):
            pos = self.start + (rid - 1) * self.row_size
            rva, impl, flags = struct.unpack_from("<IHH", self.image, pos)
            key = int.from_bytes(self.image[pos + 8:pos + 8 + self.string_width], "little")
            if key >= self.strings_size:
                raise ValueError("Invalid method name")
            name_start = self.strings + key
            end = self.image.index(0, name_start, self.strings + self.strings_size)
            yield rid, pos, bytes(self.image[name_start:end]).decode("utf-8"), rva, impl, flags

def restore_slot_flags(il, raw):
    # Microsoft ILAsm adds mdAbstract and mdVirtual when a COM slot is a bodyless, nonvirtual interface method.
    declarations = re.findall(
        r"(?m)^\s*\.method\s+([^{}]*?)\binstance\s+void\s+(_VtblGap\d+_\d+)\s*"
        r"\(\s*\)\s+runtime\s+managed\s*\{\s*\}", il)
    wanted = {}
    attr_bits = {"public": 0x0006, "specialname": 0x0800, "rtspecialname": 0x1000}
    for attrs, name in declarations:
        if name in wanted or set(attrs.split()) != set(attr_bits):
            raise ValueError("Ambiguous or unsupported COM slot declaration: " + name)
        wanted[name] = sum(attr_bits[k] for k in attrs.split())
    all_names = re.findall(r"\b(_VtblGap\d+_\d+)\s*\(", re.sub(r"//[^\n]*", "", il))
    if not wanted or sorted(wanted) != sorted(all_names):
        raise ValueError("Unaccounted COM slot declarations")
    output = bytearray(raw)
    changes = []
    for rid, pos, name, rva, impl, flags in MethodTable(raw).rows():
        if name not in wanted:
            continue
        expected = wanted.pop(name)
        if rva != 0 or impl != 3 or flags not in (expected, expected | 0x0440):
            raise ValueError("ILAsm emitted an unexpected COM slot shape: " + name)
        struct.pack_into("<H", output, pos + 6, expected)
        changes.append(dict(token=f"06{rid:06X}", name=name, before=flags, after=expected, file_offset=pos + 6))
    if wanted:
        raise ValueError("Compiled image missing authored COM slots")
    return output, changes

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ilasm", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    source, = here.glob("*.dll.il")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    name = source.stem
    assembled = output / "raw" / name
    assembled.parent.mkdir(exist_ok=True)
    subprocess.run([str(args.ilasm.resolve()), "/dll", "/quiet", "/resource=original.res",
                    "/output=" + str(assembled), source.name], cwd=here, check=True)
    data, changes = restore_slot_flags(source.read_text(encoding="utf-8-sig"), assembled.read_bytes())
    (output / name).write_bytes(data)
    (output / "declaration-changes.json").write_text(json.dumps(changes, indent=2) + "\n", encoding="utf-8")
    print(name, json.dumps(changes))

if __name__ == "__main__":
    main()
