using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;

// Read CIL and metadata as data. No input assembly is loaded or executed.
static partial class ResolvedCilEvidence
{
    static readonly Dictionary<ushort, OpCode> Opcodes = typeof(OpCodes).GetFields()
        .Where(f => f.FieldType == typeof(OpCode)).Select(f => (OpCode)f.GetValue(null)!)
        .ToDictionary(o => unchecked((ushort)o.Value));

    static string Part(string tag, params string[] items) => tag + "(" + string.Concat(items.Select(s => $"{s.Length}:{s}")) + ")";
    static string Digest(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();

    sealed class Signatures(MetadataReader reader) : ISignatureTypeProvider<string, int>
    {
        public string Entity(EntityHandle handle, int depth = 0)
        {
            if (handle.IsNil) return "nil";
            if (depth > 40) throw new BadImageFormatException("Excessive metadata reference nesting");
            switch (handle.Kind)
            {
                case HandleKind.TypeDefinition:
                    var td = reader.GetTypeDefinition((TypeDefinitionHandle)handle);
                    return Part("typedef", Entity(td.GetDeclaringType(), depth + 1), reader.GetString(td.Namespace), reader.GetString(td.Name));
                case HandleKind.TypeReference:
                    var tr = reader.GetTypeReference((TypeReferenceHandle)handle);
                    return Part("typeref", Entity(tr.ResolutionScope, depth + 1), reader.GetString(tr.Namespace), reader.GetString(tr.Name));
                case HandleKind.TypeSpecification:
                    return Part("typespec", reader.GetTypeSpecification((TypeSpecificationHandle)handle).DecodeSignature(this, depth + 1));
                case HandleKind.AssemblyReference:
                    var ar = reader.GetAssemblyReference((AssemblyReferenceHandle)handle);
                    return Part("assemblyref", reader.GetString(ar.Name), ar.Version.ToString(), reader.GetString(ar.Culture),
                                ((int)ar.Flags).ToString(), Convert.ToHexString(reader.GetBlobBytes(ar.PublicKeyOrToken)),
                                Convert.ToHexString(reader.GetBlobBytes(ar.HashValue)));
                case HandleKind.ModuleDefinition:
                    return Part("module", reader.GetString(reader.GetModuleDefinition().Name));
                case HandleKind.ModuleReference:
                    return Part("moduleref", reader.GetString(reader.GetModuleReference((ModuleReferenceHandle)handle).Name));
                case HandleKind.MethodDefinition:
                    var md = reader.GetMethodDefinition((MethodDefinitionHandle)handle);
                    return Part("methoddef", Entity(md.GetDeclaringType(), depth + 1), reader.GetString(md.Name),
                                MethodSignature(md.DecodeSignature(this, depth + 1)));
                case HandleKind.FieldDefinition:
                    var fd = reader.GetFieldDefinition((FieldDefinitionHandle)handle);
                    return Part("fielddef", Entity(fd.GetDeclaringType(), depth + 1), reader.GetString(fd.Name),
                                fd.DecodeSignature(this, depth + 1));
                case HandleKind.MemberReference:
                    var mr = reader.GetMemberReference((MemberReferenceHandle)handle);
                    string signature = mr.GetKind() == MemberReferenceKind.Field ? mr.DecodeFieldSignature(this, depth + 1)
                                       : MethodSignature(mr.DecodeMethodSignature(this, depth + 1));
                    return Part("memberref", Entity(mr.Parent, depth + 1), reader.GetString(mr.Name), signature);
                case HandleKind.MethodSpecification:
                    var ms = reader.GetMethodSpecification((MethodSpecificationHandle)handle);
                    return Part("methodspec", Entity(ms.Method, depth + 1), Part("typeargs", ms.DecodeSignature(this, depth + 1).ToArray()));
                case HandleKind.StandaloneSignature:
                    var ss = reader.GetStandaloneSignature((StandaloneSignatureHandle)handle);
                    if (ss.GetKind() == StandaloneSignatureKind.LocalVariables)
                        return Part("locals", ss.DecodeLocalSignature(this, depth + 1).ToArray());
                    return Part("callsite", MethodSignature(ss.DecodeMethodSignature(this, depth + 1)));
                default:
                    throw new BadImageFormatException("Unsupported entity handle " + handle.Kind);
            }
        }

        static string MethodSignature(MethodSignature<string> s) => Part("sig", s.Header.RawValue.ToString(),
            s.GenericParameterCount.ToString(), s.RequiredParameterCount.ToString(), s.ReturnType, Part("args", s.ParameterTypes.ToArray()));
        public string GetTypeFromDefinition(MetadataReader r, TypeDefinitionHandle h, byte kind) => Part(kind.ToString(), Entity(h));
        public string GetTypeFromReference(MetadataReader r, TypeReferenceHandle h, byte kind) => Part(kind.ToString(), Entity(h));
        public string GetTypeFromSpecification(MetadataReader r, int context, TypeSpecificationHandle h, byte kind) => Part(kind.ToString(), Entity(h, context + 1));
        public string GetArrayType(string e, ArrayShape shape) => Part("array", e, shape.Rank.ToString(), string.Join(",", shape.Sizes), string.Join(",", shape.LowerBounds));
        public string GetByReferenceType(string e) => Part("byref", e);
        public string GetFunctionPointerType(MethodSignature<string> s) => Part("fn", MethodSignature(s));
        public string GetGenericInstantiation(string e, ImmutableArray<string> args) => Part("inst", e, Part("args", args.ToArray()));
        public string GetGenericMethodParameter(int context, int index) => "!!" + index;
        public string GetGenericTypeParameter(int context, int index) => "!" + index;
        public string GetModifiedType(string m, string e, bool required) => Part(required ? "modreq" : "modopt", m, e);
        public string GetPinnedType(string e) => Part("pinned", e);
        public string GetPointerType(string e) => Part("ptr", e);
        public string GetPrimitiveType(PrimitiveTypeCode code) => code.ToString();
        public string GetSZArrayType(string e) => Part("szarray", e);
    }

    record TokenOperand(int Offset, int OperandOffset, string Kind, string RawToken, string Resolved);
    record MethodEvidence(string Token, string Identity, int Attributes, int ImplementationAttributes, string Scope,
                          string? CodeDigest, string? RawCodeDigest, string? ShapeDigest, int? MaxStack, bool? InitLocals,
                          TokenOperand[] Operands, object? ExceptionRegions,
                          object[] Parameters, string[] CustomAttributes);

    static TokenOperand[] DecodeOperands(byte[] il, MetadataReader reader, Signatures names, List<string> decoded)
    {
        var tokens = new List<TokenOperand>();
        for (int position = 0; position < il.Length;)
        {
            int instruction = position;
            ushort prefix = il[position++];
            if (prefix == 0xfe) prefix = (ushort)(0xfe00 | il[position++]);
            OpCode op = Opcodes[prefix];
            int size;
            switch (op.OperandType)
            {
                case OperandType.InlineNone: size = 0; break;
                case OperandType.ShortInlineBrTarget:
                case OperandType.ShortInlineVar:
                case OperandType.ShortInlineI: size = 1; break;
                case OperandType.InlineVar: size = 2; break;
                case OperandType.InlineBrTarget:
                case OperandType.InlineI:
                case OperandType.ShortInlineR: size = 4; break;
                case OperandType.InlineI8:
                case OperandType.InlineR: size = 8; break;
                case OperandType.InlineSwitch:
                    int count = BinaryPrimitives.ReadInt32LittleEndian(il.AsSpan(position, 4));
                    if (count < 0) throw new BadImageFormatException("Negative switch count");
                    size = checked(4 + count * 4);
                    break;
                case OperandType.InlineField:
                case OperandType.InlineMethod:
                case OperandType.InlineSig:
                case OperandType.InlineString:
                case OperandType.InlineTok:
                case OperandType.InlineType:
                    int token = BinaryPrimitives.ReadInt32LittleEndian(il.AsSpan(position, 4));
                    string resolved = op.OperandType == OperandType.InlineString
                        ? Part("userstring", reader.GetUserString(MetadataTokens.UserStringHandle(token & 0xffffff)))
                        : names.Entity(MetadataTokens.EntityHandle(token));
                    decoded.Add(Part(op.Name!, instruction.ToString(), resolved));
                    tokens.Add(new TokenOperand(instruction, position, op.OperandType.ToString(), $"{token:X8}", resolved));
                    position += 4;
                    continue;
                default: throw new BadImageFormatException("Unsupported operand " + op.OperandType);
            }
            decoded.Add(Part(op.Name!, instruction.ToString(), Convert.ToHexString(il.AsSpan(position, size))));
            position += size;
        }
        return tokens.ToArray();
    }

    static string[] Attributes(MetadataReader reader, Signatures names, CustomAttributeHandleCollection handles) => handles
        .Select(h => reader.GetCustomAttribute(h)).Select(a => Part("attr", names.Entity(a.Constructor), Convert.ToHexString(reader.GetBlobBytes(a.Value))))
        .ToArray();

    static object Inspect(string path)
    {
        using var file = File.OpenRead(path);
        using var pe = new PEReader(file);
        MetadataReader reader = pe.GetMetadataReader();
        var names = new Signatures(reader);
        var methods = new List<MethodEvidence>();
        foreach (var h in reader.MethodDefinitions)
        {
            var m = reader.GetMethodDefinition(h);
            string id = names.Entity(h);
            string scope = m.RelativeVirtualAddress == 0 ? "declaration" : "CIL";
            string? codeDigest = null, rawCode = null;
            string? shapeDigest = null;
            int? maxStack = null;
            bool? initLocals = null;
            object? exceptions = null;
            TokenOperand[] operands = [];
            if (m.RelativeVirtualAddress != 0)
            {
                if ((m.ImplAttributes & MethodImplAttributes.CodeTypeMask) != MethodImplAttributes.IL)
                    throw new BadImageFormatException("Non-CIL implementation at " + id);
                var body = pe.GetMethodBody(m.RelativeVirtualAddress);
                byte[] il = body.GetILBytes() ?? throw new BadImageFormatException("Missing CIL body");
                var decoded = new List<string>();
                operands = DecodeOperands(il, reader, names, decoded);
                exceptions = body.ExceptionRegions.Select(e => new { kind = e.Kind.ToString(), e.TryOffset, e.TryLength,
                    e.HandlerOffset, e.HandlerLength, e.FilterOffset, catchType = names.Entity(e.CatchType),
                    rawCatchToken = $"{MetadataTokens.GetToken(e.CatchType):X8}" }).ToArray();
                var normalizedEh = body.ExceptionRegions.Select(e => new { kind = e.Kind.ToString(), e.TryOffset, e.TryLength,
                    e.HandlerOffset, e.HandlerLength, e.FilterOffset, catchType = names.Entity(e.CatchType) }).ToArray();
                codeDigest = Digest(JsonSerializer.SerializeToUtf8Bytes(new { body.MaxStack, body.LocalVariablesInitialized,
                    locals = names.Entity(body.LocalSignature), decoded, normalizedEh }));
                rawCode = Digest(il);
                foreach (var operand in operands)
                    il.AsSpan(operand.OperandOffset, 4).Clear();
                shapeDigest = Digest(il);
                maxStack = body.MaxStack;
                initLocals = body.LocalVariablesInitialized;
            }
            var parameters = m.GetParameters().Select(reader.GetParameter).Select(p => new {
                p.SequenceNumber, name = reader.GetString(p.Name), attributes = (int)p.Attributes,
                marshal = Convert.ToHexString(reader.GetBlobBytes(p.GetMarshallingDescriptor())),
                defaultValue = p.GetDefaultValue().IsNil ? "" : Part("default", reader.GetConstant(p.GetDefaultValue()).TypeCode.ToString(),
                    Convert.ToHexString(reader.GetBlobBytes(reader.GetConstant(p.GetDefaultValue()).Value))),
                customAttributes = Attributes(reader, names, p.GetCustomAttributes())
            }).ToArray();
            methods.Add(new MethodEvidence($"{MetadataTokens.GetToken(h):X8}", id, (int)m.Attributes, (int)m.ImplAttributes,
                           scope, codeDigest, rawCode, shapeDigest, maxStack, initLocals,
                           operands, exceptions, parameters, Attributes(reader, names, m.GetCustomAttributes())));
        }
        var assembly = reader.GetAssemblyDefinition();
        var typeDefinitions = reader.TypeDefinitions.Select(h => {
            var t = reader.GetTypeDefinition(h);
            return new { identity = names.Entity(h), flags = (int)t.Attributes, baseType = names.Entity(t.BaseType),
                         interfaces = t.GetInterfaceImplementations().Select(i => names.Entity(reader.GetInterfaceImplementation(i).Interface)).ToArray(),
                         customAttributes = Attributes(reader, names, t.GetCustomAttributes()) };
        }).ToArray();
        return new { assembly = new { name = reader.GetString(assembly.Name), version = assembly.Version.ToString(),
            culture = reader.GetString(assembly.Culture), flags = (int)assembly.Flags,
            publicKey = Convert.ToHexString(reader.GetBlobBytes(assembly.PublicKey)), attributes = Attributes(reader, names, assembly.GetCustomAttributes()) },
            assemblyReferences = reader.AssemblyReferences.Select(h => names.Entity(h)).OrderBy(x => x, StringComparer.Ordinal).ToArray(),
            types = typeDefinitions, methods, details = Details(reader, names), pe = PeDetails(pe, reader, path),
            locals = reader.MethodDefinitions.Select(handle => {
                var method = reader.GetMethodDefinition(handle);
                return new { Token = $"{MetadataTokens.GetToken(handle):X8}", Signature = method.RelativeVirtualAddress == 0
                    ? "nil" : names.Entity(pe.GetMethodBody(method.RelativeVirtualAddress).LocalSignature) };
            }).ToArray() };
    }

    static void Main(string[] args)
    {
        if (args.Length != 1) throw new ArgumentException("Use a single managed PE path");
        if (args.Length == 1 && args[0] == "--opcode-kinds")
        {
            Console.WriteLine(JsonSerializer.Serialize(Opcodes.ToDictionary(row => row.Key,
                row => new { Name = row.Value.Name, Kind = row.Value.OperandType.ToString() })));
            return;
        }
        Console.WriteLine(JsonSerializer.Serialize(Inspect(args[0])));
    }
}
