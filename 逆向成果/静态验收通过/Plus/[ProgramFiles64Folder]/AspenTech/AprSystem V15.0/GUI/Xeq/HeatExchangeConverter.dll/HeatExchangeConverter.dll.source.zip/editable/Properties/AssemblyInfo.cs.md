# AssemblyInfo.cs

Source: editable/Properties/AssemblyInfo.cs

Source SHA-256: 8f975787a06cc18b235f8e8f5b43986daf6d960f7f4ed6a7364ba4504b8bb77f
