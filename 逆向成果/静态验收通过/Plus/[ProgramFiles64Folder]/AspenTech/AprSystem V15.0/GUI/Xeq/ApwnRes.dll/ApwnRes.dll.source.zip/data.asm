; .data PE metadata and initialized data.
bits 64

    dq 0xffffd466d2205dcd                                      ; +0x0000 Initial security cookie complement
    dq 0x2b992ddfa232                                          ; +0x0008 Initial security cookie
    db 0xff, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00  ; constant data at +0x10
    db 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x20
    db 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x30
    times 16 db 0  ; constant data at +0x40
    times 16 db 0  ; constant data at +0x50
    times 16 db 0  ; constant data at +0x60
    times 16 db 0  ; constant data at +0x70
    times 16 db 0  ; constant data at +0x80
    times 16 db 0  ; constant data at +0x90
    times 16 db 0  ; constant data at +0xa0
    times 16 db 0  ; constant data at +0xb0
    times 16 db 0  ; constant data at +0xc0
    times 16 db 0  ; constant data at +0xd0
    times 16 db 0  ; constant data at +0xe0
    times 16 db 0  ; constant data at +0xf0
    times 16 db 0  ; constant data at +0x100
    times 16 db 0  ; constant data at +0x110
    times 16 db 0  ; constant data at +0x120
    times 16 db 0  ; constant data at +0x130
    times 16 db 0  ; constant data at +0x140
    times 16 db 0  ; constant data at +0x150
    times 16 db 0  ; constant data at +0x160
    times 16 db 0  ; constant data at +0x170
    times 16 db 0  ; constant data at +0x180
    times 16 db 0  ; constant data at +0x190
    times 16 db 0  ; constant data at +0x1a0
    times 16 db 0  ; constant data at +0x1b0
    times 16 db 0  ; constant data at +0x1c0
    times 16 db 0  ; constant data at +0x1d0
    times 16 db 0  ; constant data at +0x1e0
    times 16 db 0  ; constant data at +0x1f0
