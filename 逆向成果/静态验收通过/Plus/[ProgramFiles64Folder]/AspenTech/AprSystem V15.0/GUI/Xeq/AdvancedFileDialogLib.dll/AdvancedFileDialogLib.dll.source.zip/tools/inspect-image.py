#!/usr/bin/env python3
"""Report PE resources and raw managed method extents without loading the target."""
import argparse
import json
import struct
import sys
from hashlib import sha256
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS / "vendor"))
import pefile
import clr_meta

TABLE_NAMES = {
    **clr_meta.TABLE_NAMES, 0x09: "InterfaceImpl", 0x0C: "CustomAttribute",
    0x0D: "FieldMarshal", 0x19: "MethodImpl",
}


def digest(data):
    return sha256(data).hexdigest()


def pe_resources(pe):
    directory = pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_RESOURCE"]
    pe.parse_data_directories(directories=[directory])
    if not hasattr(pe, "DIRECTORY_ENTRY_RESOURCE"):
        return []

    def walk(node, keys):
        for entry in node.entries:
            key = str(entry.name) if entry.name is not None else entry.id
            path = keys + [key]
            if hasattr(entry, "directory"):
                yield from walk(entry.directory, path)
            else:
                span = entry.data.struct
                payload = pe.get_data(span.OffsetToData, span.Size)
                yield {"path": path, "code_page": span.CodePage, "bytes": len(payload),
                       "sha256": digest(payload)}

    return list(walk(pe.DIRECTORY_ENTRY_RESOURCE, []))


def res_items(path):
    data = path.read_bytes()
    at = 0
    items = []
    while at < len(data):
        size, header = struct.unpack_from("<II", data, at)
        header_end = at + header
        if header < 24 or header_end + size > len(data):
            raise ValueError("invalid .res member bounds")
        p = at + 8
        keys = []
        for _ in range(2):
            first, = struct.unpack_from("<H", data, p)
            if first == 0xFFFF:
                value, = struct.unpack_from("<H", data, p + 2)
                p += 4
            else:
                end = p
                while data[end:end + 2] != b"\0\0" and end < header_end:
                    end += 2
                value = data[p:end].decode("utf-16-le")
                p = end + 2
            keys.append(value)
        p = (p + 3) & ~3
        language, = struct.unpack_from("<H", data, p + 6)
        if size:
            items.append({"path": keys + [language], "bytes": size,
                          "sha256": digest(data[header_end:header_end + size])})
        at = (header_end + size + 3) & ~3
    return items


def exception_data(body, flags, code_end):
    if not flags & 8:
        return []
    at = (code_end + 3) & ~3
    kind = body[at]
    if kind == 1:
        size, row_width = body[at + 1], 12
        layout = "<HHBHBI"
    elif kind == 0x41:
        size, row_width = int.from_bytes(body[at + 1:at + 4], "little"), 24
        layout = "<IIIIII"
    else:
        raise ValueError("unhandled CIL data section")
    if size != len(body) - at or (size - 4) % row_width:
        raise ValueError("invalid exception section extent")
    clauses = []
    for start in range(at + 4, at + size, row_width):
        flag, try_start, try_size, handler, handler_size, value = struct.unpack_from(layout, body, start)
        clauses.append({
            "flags": flag, "try_start": try_start, "try_end": try_start + try_size,
            "handler_start": handler, "handler_end": handler + handler_size,
            "value_word": f"0x{value:08x}",
        })
    return [{"kind": kind, "at_in_body": at, "data_size": size,
             "hex": body[at:at + size].hex(), "clauses": clauses}]


def inspect(path):
    data = path.read_bytes()
    pe, cli, root = clr_meta.read_image(data)
    rows = clr_meta.method_defs(pe, cli, root)
    counts = root["tables"]["rows"]
    methods = []
    for i, row in enumerate(rows):
        param_end = rows[i + 1]["param_list"] if i + 1 < len(rows) else counts[8] + 1
        params = []
        for index in range(row["param_list"], param_end):
            item = clr_meta.read_row(root["bytes"], root["tables"], 8, index)
            params.append({"sequence": item[1], "flags": item[0],
                           "name": clr_meta.strings(pe, cli, root, item[2])})
        value = {"token": f"0x{row['token']:08x}", "rva": row["rva"],
                 "flags": row["flags"], "impl_flags": row["impl_flags"],
                 "params": params, "code_size": row["code_size"]}
        if row["rva"]:
            body = pe.get_data(row["rva"], row["body_bytes"])
            value.update({
                "extent": len(body), "body_sha256": digest(body),
                "sections": exception_data(body, row["method_flags"], row["header_bytes"] + row["code_size"]),
            })
        methods.append(value)

    cert = pe.OPTIONAL_HEADER.DATA_DIRECTORY[4]
    strong_name = pe.get_data(cli["strong_name_rva"], cli["strong_name_size"])
    return {
        "sha256": digest(data), "bytes": len(data),
        "metadata_tables": {TABLE_NAMES.get(table, f"0x{table:02x}"): count for table, count in counts.items()},
        "method_count": len(rows),
        "bodies": sum(bool(row["rva"]) for row in rows),
        "code_bytes": sum(row["code_size"] for row in rows),
        "method_bytes_including_headers_and_eh": sum(row["body_bytes"] for row in rows),
        "methods": methods,
        "managed_resource_size": cli["resource_size"],
        "native_resources": pe_resources(pe),
        "clr_flags": cli["flags"],
        "strong_name": {"bytes": cli["strong_name_size"], "slot_all_zero": not any(strong_name),
                        "sha256": digest(strong_name)},
        "authenticode": {"bytes": cert.Size, "sha256": digest(data[cert.VirtualAddress:cert.VirtualAddress + cert.Size])},
        "pe_build": {"coff_timestamp": pe.FILE_HEADER.TimeDateStamp, "checksum": pe.OPTIONAL_HEADER.CheckSum,
                     "machine": pe.FILE_HEADER.Machine},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", required=True, type=Path)
    parser.add_argument("--source-candidate", required=True, type=Path)
    parser.add_argument("--replay-candidate", required=True, type=Path)
    parser.add_argument("--resource", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    original, assembled, replayed = (inspect(path)
                                     for path in (args.original, args.source_candidate, args.replay_candidate))
    items = res_items(args.resource)
    result = {"original": original, "source": assembled, "replay": replayed,
              "archive_res": {"sha256": digest(args.resource.read_bytes()), "resources": items},
              "source_pe_resource_equal": original["native_resources"] == assembled["native_resources"],
              "res_payload_equal": [
                  {key: value for key, value in item.items() if key != "code_page"}
                  for item in original["native_resources"]
              ] == items, "replay_byte_identical": original["sha256"] == replayed["sha256"]}
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

