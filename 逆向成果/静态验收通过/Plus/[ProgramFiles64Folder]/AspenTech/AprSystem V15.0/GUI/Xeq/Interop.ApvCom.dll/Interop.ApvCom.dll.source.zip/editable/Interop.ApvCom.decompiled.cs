using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;

[assembly: ImportedFromTypeLib("APVCOMLib")]
[assembly: TypeLibVersion(32, 0)]
[assembly: Guid("7BEB6E40-D9EA-4A55-9EA7-1ABB1AA20762")]
[assembly: AssemblyVersion("32.0.0.0")]
namespace AspenTech.AspenPlus.ApvCom;

[ComImport]
[Guid("6CA03FD9-E4F8-46A8-BD6A-358B175D8997")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAPVPropRequest
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetRequest([In] int requestField);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void AddRequest([In] int requestField);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Clear();
}
[ComImport]
[Guid("6CA03FD9-E4F8-46A8-BD6A-358B175D8997")]
[CoClass(typeof(APVPropRequestClass))]
public interface APVPropRequest : IAPVPropRequest
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("09C4499D-A89C-42E1-9DEC-A9493972F618")]
[ClassInterface(ClassInterfaceType.None)]
public class APVPropRequestClass : IAPVPropRequest, APVPropRequest
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropRequest.SetRequest([In] int requestField);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropRequest.AddRequest([In] int requestField);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropRequest.Clear();
}
[ComImport]
[Guid("6CA03FDB-E4F8-46A8-BD6A-358B175D8997")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAPVPropResults
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void InqProp([In] int request, [In] int bufferSize, out double values);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetProp([In] int request, [In] int bufferSize, [In] ref double values);
}
[ComImport]
[Guid("6CA03FDB-E4F8-46A8-BD6A-358B175D8997")]
[CoClass(typeof(APVPropResultsClass))]
public interface APVPropResults : IAPVPropResults
{
}
[ComImport]
[Guid("09C4499E-A89C-42E1-9DEC-A9493972F618")]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[ClassInterface(ClassInterfaceType.None)]
public class APVPropResultsClass : IAPVPropResults, APVPropResults
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropResults.InqProp([In] int request, [In] int bufferSize, out double values);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropResults.SetProp([In] int request, [In] int bufferSize, [In] ref double values);
}
[ComImport]
[Guid("1A234221-1B19-4D87-8AF9-169771F54DFC")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAPVPhase
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	double GetScalarProperty([In] uint propnum);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetProperty(uint propnum, out double value, [In] int bufferSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetIntegerPhaseVariable([In] cPHASEVARIABLE variable, out int values, [In] int bufferSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetRealPhaseVariable([In] cPHASEVARIABLE variable, out double values, [In] int bufferSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetIntegerPhaseVariable([In] cPHASEVARIABLE variable, [In] ref int values, [In] int bufferSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetRealPhaseVariable([In] cPHASEVARIABLE variable, [In] ref double values, [In] int bufferSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CopyFrom([In][MarshalAs(UnmanagedType.Interface)] APVPhase other);
}
[ComImport]
[CoClass(typeof(APVPhaseClass))]
[Guid("1A234221-1B19-4D87-8AF9-169771F54DFC")]
public interface APVPhase : IAPVPhase
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("1945D61C-B640-4154-8078-3EDA76255C36")]
public class APVPhaseClass : IAPVPhase, APVPhase
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double IAPVPhase.GetScalarProperty([In] uint propnum);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPhase.GetProperty(uint propnum, out double value, [In] int bufferSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPhase.GetIntegerPhaseVariable([In] cPHASEVARIABLE variable, out int values, [In] int bufferSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPhase.GetRealPhaseVariable([In] cPHASEVARIABLE variable, out double values, [In] int bufferSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPhase.SetIntegerPhaseVariable([In] cPHASEVARIABLE variable, [In] ref int values, [In] int bufferSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPhase.SetRealPhaseVariable([In] cPHASEVARIABLE variable, [In] ref double values, [In] int bufferSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPhase.CopyFrom([In][MarshalAs(UnmanagedType.Interface)] APVPhase other);
}
[ComImport]
[Guid("CF7CCCF1-E337-434C-BBCC-AD8F505CADEC")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAPVPhaseCollection
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetNumberOfComponents([In] int nc);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	APVPhase GetPhaseReference([In] cPHASELABEL type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetPhaseActive([In] cPHASELABEL type, [In] int active);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void InitializeFromStream([In][MarshalAs(UnmanagedType.LPStr)] string streamName);
}
[ComImport]
[Guid("CF7CCCF1-E337-434C-BBCC-AD8F505CADEC")]
[CoClass(typeof(APVPhaseCollectionClass))]
public interface APVPhaseCollection : IAPVPhaseCollection
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("E0DC6BE9-2126-4510-AE93-F954B67CACC5")]
public class APVPhaseCollectionClass : IAPVPhaseCollection, APVPhaseCollection
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPhaseCollection.SetNumberOfComponents([In] int nc);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	extern APVPhase IAPVPhaseCollection.GetPhaseReference([In] cPHASELABEL type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPhaseCollection.SetPhaseActive([In] cPHASELABEL type, [In] int active);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPhaseCollection.InitializeFromStream([In][MarshalAs(UnmanagedType.LPStr)] string streamName);
}
[ComImport]
[Guid("E5AE580D-EE4F-414E-9FE9-64D5DDD19522")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAPVCallBackFunctions
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetProperty(ref byte sPropName, ref int Indices, ref int cLength, ref double values);
}
[ComImport]
[Guid("E5AE580D-EE4F-414E-9FE9-64D5DDD19522")]
[CoClass(typeof(APVCallBackFunctionsClass))]
public interface APVCallBackFunctions : IAPVCallBackFunctions
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("3D19B121-2861-4EA6-B219-D377A6FB9A20")]
[ClassInterface(ClassInterfaceType.None)]
public class APVCallBackFunctionsClass : IAPVCallBackFunctions, APVCallBackFunctions
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVCallBackFunctions.GetProperty(ref byte sPropName, ref int Indices, ref int cLength, ref double values);
}
[ComImport]
[ComConversionLoss]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("7B6F9721-4BA4-4548-9CC7-5E6095BAD72E")]
public interface IAPVPropSystem
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Initialize([In][MarshalAs(UnmanagedType.LPStr)] string pdffile, [In] int abortFlag, [In][MarshalAs(UnmanagedType.Interface)] IAPVNotify notifyHandler, [In] int licenseKey, [In] cHBASE basis);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetGlobalPackage();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetPackage([In][MarshalAs(UnmanagedType.LPStr)] string mainPropMethod, [In][MarshalAs(UnmanagedType.LPStr)] string henryComp, [In][MarshalAs(UnmanagedType.LPStr)] string chemistry, [In] cTRUECOMP trueComp, [In][MarshalAs(UnmanagedType.LPStr)] string freeWaterMethod, [In] cSOLUWATER soluWater);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetPackage([Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder mainPropMethod, [Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder henryComp, [Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder chemistry, out cTRUECOMP trueComp, [Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder freeWaterMethod, out cSOLUWATER soluWater);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ClosePDF();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int GetAvailablePropertyMethodCount();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetAvailablePropertyMethods([In] int count, out sbyte propMethods);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int GetAvailableFreeWaterMethodCount();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetAvailableFreeWaterMethods([In] int count, out sbyte freeWaterMethods);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int GetAvailableChemistryIDCount();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetAvailableChemistryIDs([In] int count, out sbyte chemistryIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int GetAvailableHenryComponentsIDCount();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetAvailableHenryComponentsIDs([In] int count, out sbyte henryComponentsIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetBaseOpsetName([In][MarshalAs(UnmanagedType.LPStr)] string opset, [Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder baseOpset, out int isReplaced);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int TotalComp();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetPackageComponents([In] int nc, out sbyte cids, out sbyte aliases, out sbyte cnames, out sbyte casnums);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	APVPropResults CalcPhaseProperties1([In] double temp, [In] double pres, [In] ref double molefrac, [In] int nComp, [In] ref int compIndex, [In] cPHASESTATE phaseState, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	APVPropResults CalcPhaseProperties2([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcPhaseProperties3([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	APVPropResults CalcTwoPhaseProperties1([In] double temp, [In] double pres, [In] ref double molefrac1, [In] ref double molefrac2, [In] int nComp, [In] ref int compIndex, [In] cPHASESTATE phase1State, [In] cPHASESTATE phase2State, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	APVPropResults CalcTwoPhaseProperties2([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase1, [In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase2, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcEnthalpy1([In] double temp, [In] double pres, [In] ref double molefrac, [In] int nComp, [In] ref int compIndex, [In] cPHASESTATE phaseState, out double h, out double cp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcEnthalpy2([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, out double h, out double cp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcEnthalpy3([In] double temp, [In] double pres, [In] ref double molefrac, [In] int nComp, [In] ref int compIndex, [In] cPHASESTATE phaseState, out double h, out double s, out double cp, out double v);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcEnthalpy4([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, out double h, out double s, out double cp, out double v);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcKValue1([In] double temp, [In] double pres, [In] ref double molefracLiquid, [In] ref double molefracVapor, [In] int nComp, [In] ref int compIndex, out double kvalue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcKValue2([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhaseLiquid, [In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhaseVapor, [In] int nComp, out double kvalue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcSingleProperty([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, [In] int property, [In] int bufferSize, out double values);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	APVPropResults CalcIdealGasProperties1([In] double temp, [In] ref double molefrac, [In] int nComp, [In] ref int compIndex, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	APVPropResults CalcIdealGasProperties2([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcIdealGasProperties3([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcPhaseEquilibrium1([In][MarshalAs(UnmanagedType.Interface)] APVPhaseCollection pPhases, [In] cFLASHTYPE flashType, [In] cVALIDPHASE validPhases, [In] int maxIterations, [In] double tolerance);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcPhaseEquilibrium2([In][MarshalAs(UnmanagedType.Interface)] APVPhaseCollection pPhases, [In] cFLASHTYPE flashType, [In] cVALIDPHASE validPhases, [In] int maxIterations, [In] double tolerance, [In][Out] ref double realRetention, [In][Out] ref int intRetention, [In] cRESTART restart, [In] int realLength, [In] int intLength);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcInitK([In] int compIndex, [In] double temp, [In] double pres, [In] cPHASELABEL label, out double value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OrderPhase([In][MarshalAs(UnmanagedType.Interface)] APVPhaseCollection phaseCollection);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetPropertyInfo([In][MarshalAs(UnmanagedType.LPStr)] string property, out int pPropIndex, out int pNumElem, out int pNumDim, out int pNumDataSets, out int unitRow, out int tempUnitRow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetProperties([In] int propIndex, [In] int nDataSet, [In] int nComp, [In] ref int compIndex, [In] int nParamSize, out double paramValues, out int paramStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IAPVEnumParameter GetParametersForPropertyMethod([In][MarshalAs(UnmanagedType.LPStr)] string propMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void UpdateEstimates([In] int nComp, [In] ref int compIndex, [In] ref double nbp, [In] ref double sg, [In] ref double mw);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetProperties([In] int propIndex, [In] int nDataSet, [In] int nComp, [In] ref int compIndex, [In] int nParamSize, [In] ref double paramValues, [In] ref int paramStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetBinaryProperties([In] int propIndex, [In] int nDataSet, [In] int nPair, [In] ref int compIndex1, [In] ref int compIndex2, [In] int nParamSize, [In] ref double paramValues, [In] ref int paramStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetPropDiagLevel([In] cDIAGLEVEL diagLevel);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetFlashDiagLevel([In] cDIAGLEVEL diagLevel);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetHBase([In] cHBASE hBase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	cHBASE GetHBase();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetComponentIndices([In] int nComp, [In][MarshalAs(UnmanagedType.LPStr)] ref string compNames, out int compIndex, out int kerr);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetCustomPropertyID([In][MarshalAs(UnmanagedType.LPStr)] string customProperty, out int propertyID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RegisterCustomPropertyMethod([In][MarshalAs(UnmanagedType.LPStr)] string customProperty, [In][MarshalAs(UnmanagedType.IUnknown)] object function, out int propertyID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int GetRealRetentionLength();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int GetIntRetentionLength();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetRealRetention([In] int bufferSize, out double values);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetIntRetention([In] int bufferSize, out int values);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetFlashRestartFlag(out int restart);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetFlashRestartFlag([In] int restart);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetRealGlobal([In] cREALGLOBAL global, out double value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetIntGlobal([In] cINTGLOBAL global, out int value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	double CalcPhaseProperties4([In] double temp, [In] double pres, [In] ref double molefrac, [In] int nComp, [In] ref int compIndex, [In] cPHASESTATE phaseState, [In] int propRequest, [In][Out] ref int nResults);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	cDIAGLEVEL GetPropDiagLevel();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	cDIAGLEVEL GetFlashDiagLevel();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IAPVEnumPropCalc GetPropCalcList();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	cDIAGLEVEL GetDiagLevel([In] cDIAGTYPE diagType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetDiagLevel([In] cDIAGTYPE diagType, [In] cDIAGLEVEL diagLevel);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ReloadParameters();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ReloadParameterData([In][MarshalAs(UnmanagedType.LPStr)] string param, [In] int maxnds);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetPropParamElementInfo([In] int propIndex, [In] int nElem, out PropParamElementInfo info);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CheckEOS();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FitLiqViscosity([In] int nVal, [In] ref double temp, [In] ref double visc, out double muland);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FitLiqVolume(int compid, [In] int nVal, [In] ref double temp, [In] ref double mvol, out double rktzra);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetFilename([In] cFNAMETYPE __MIDL__IAPVPropSystem0000, [Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SynchronizePMLPackage([In] int nPackages);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
	void SetDupInfo([In] ref int reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Initialize2([In][MarshalAs(UnmanagedType.LPStr)] string pdffile, [In] int abortFlag, [In][MarshalAs(UnmanagedType.Interface)] IAPVNotify notifyHandler, [In] int licenseKey, [In] cHBASE basis, [In] int writablePdf);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Attach([In][MarshalAs(UnmanagedType.LPStr)] string pdffile);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ReleasePropertyCallBack([In][MarshalAs(UnmanagedType.Interface)] APVCallBackFunctions pCallBackFunctions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetPropertyCallBack([In][MarshalAs(UnmanagedType.Interface)] APVCallBackFunctions pCallBackFunctions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetPairParameters0([In] int propIndex, [In] int nDataSet, [In] int nComp, [In] ref int compIndex, out double Charge, out int nParamSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetPairParameters1([In] int propIndex, [In] int nDataSet, [In] int nComp, [In] ref int compIndex, out double Charge, [In] int nParamSize, out int IDPair, out double paramValues, out int paramSources);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetPairParameters([In] int propIndex, [In] int nDataSet, [In] int nComp, [In] ref int compIndex, [In] int nParamSize, [In] ref int IDPair, [In] ref double paramValues, out int paramSources);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetHenryComponentListCount([In][MarshalAs(UnmanagedType.Interface)] APVPropSystem henryIDs, out int count);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetHenryComponentList([In] int count, [In][MarshalAs(UnmanagedType.Interface)] APVPropSystem henryIDs, out sbyte henryCompIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetChemistryInformation([In] ref sbyte ChemistryID, [Out] IntPtr pcheminfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FreeChemistryInformation([In] ref CHEM_INFO cheminfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ResetMessageStatus();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetPropSetProperty([In] ref sbyte propname, [In] double temp, [In] double pres, [In] int nComp, [In] ref double xComp, [In] ref int idxComp, [In] cVALIDPHASE validPhases, [In] int basis, [In] int iPhase, out double PropValues);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void DeleteNotifyHandler();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetPasswodFordatabase([In] int password);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetUnitLabel([In] int unitRow, [In] int unitcol, out sbyte label, out double RA, out double RB);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetSimOptions(out double TLower, out double TUpper, out double PLower, out double PUpper, out double Xh2o, out double FlashTol, out int FlashMax, out int DerivFlag, out int GamuBase, out int GamaBase, out int FlashMeth, out int FlashOpt);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetSimOptions([In] int OPTIndex, [In] double Real8Value, [In] int IntegerValue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetOLIPath([In] ref byte path);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetAspenCalculationErrors(out int iTotalTerminal, out int iPropTerminal, out int iSysTerminal, out int iSimuTerminal, out int iTotalSevere, out int iPropSevere, out int iSysSevere, out int iSimuSevere, out int iTotalError, out int iPropError, out int iSysError, out int iSimuError, out int iTotalWarn, out int iPropWarn, out int iSysWarn, out int iSimuWarn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int GetAvailableCompGroupsIDCount();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetAvailableCompGroupsIDs([In] int count, out sbyte CompGroupsIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetCompGroupComponentListCount([In] ref sbyte CompGroupsIDs, out int count);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetCompGroupComponentList([In] int count, [In] ref sbyte CompGroupsIDs, out sbyte CompGroupCompIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Initialize3();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void UpdateEstimates2([In] int nComp, [In] ref int compIndex, [In] ref double nbp, [In] ref double sg, [In] ref double mw, [In] ref double tc, [In] ref double pc, [In] ref double vc, [In] ref double omega, [In] ref double vtheta, [In] ref double vstctd, [In] ref double omgctd, [In] int SetViscParam);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetEOFlashFlag([In] int EOFlasg);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void AmineEnabled([In] int nComp, [In] ref int compIndex, out int enabled);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void AminePkgStgEfficiencies([In] double temp, [In] double pres, [In] int nComp, [In] ref int idx, [In] double L, [In] ref double x, [In] double v, [In] ref double y, [In] double Lin, [In] ref double xin, [In] double Vin, [In] ref double yin, [In] int TypeFlag, [In] int kstg, [In] int emMode, [In][Out][MarshalAs(UnmanagedType.LPArray, SizeConst = 3)] double[] em3, [In] double Afac, [In][MarshalAs(UnmanagedType.LPArray, SizeConst = 20)] int[] icolp, [In][MarshalAs(UnmanagedType.LPArray, SizeConst = 30)] double[] rcolp, [In][MarshalAs(UnmanagedType.LPArray, SizeConst = 30)] double[] pkprms, [In][MarshalAs(UnmanagedType.LPArray, SizeConst = 50)] double[] gencor, [In] sbyte IsLiqLiqExtractor);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void InitializeFromInputFile([In][MarshalAs(UnmanagedType.LPStr)] string inputfile, [In] int abortFlag, [In][MarshalAs(UnmanagedType.Interface)] IAPVNotify notifyHandler, [In] int licenseKey, [In] cHBASE basis, [In][MarshalAs(UnmanagedType.LPStr)] string insertlib);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void InitializeFromInput([In][MarshalAs(UnmanagedType.LPStr)] string input, [In] int abortFlag, [In][MarshalAs(UnmanagedType.Interface)] IAPVNotify notifyHandler, [In] int licenseKey, [In] cHBASE basis, [In][MarshalAs(UnmanagedType.LPStr)] string insertlib);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void AddInput([In][MarshalAs(UnmanagedType.LPStr)] string fragment, [In][MarshalAs(UnmanagedType.LPStr)] string key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoveInput([In][MarshalAs(UnmanagedType.LPStr)] string key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CurrentInput([MarshalAs(UnmanagedType.LPStr)] out string allinput);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Activate(out int valid);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void InsertLibrary([In][MarshalAs(UnmanagedType.LPStr)] string insert);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Backup([In][MarshalAs(UnmanagedType.LPStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetComponentTypeByComponentID([In] int nComp, [In] ref sbyte compid, out int compIndex, out int compType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void WriteMessage([In][MarshalAs(UnmanagedType.LPStr)] string message);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetComponentTypeByComponentIndex([In] int nComp, [In] ref int compIndex, out int compType, out int nIon, out int nSolid, out int nMolecular, out int nDiss);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int GetAvailableReacDistNumber();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetAvailableReacDistID([In] int NumRdist, out sbyte RDistIDs, out int RxnNo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetReacDistInformation([In] ref sbyte RDistIDs, [In] int NumRdist, [Out] IntPtr pRdistinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FreeReacDistInformation([In] ref RDIST_INFO rdistinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcPhaseEquilibriumElec1([In][MarshalAs(UnmanagedType.Interface)] APVPhaseCollection pPhases, [In] cFLASHTYPE flashType, [In] cVALIDPHASE validPhases, [In] int maxIterations, [In] double tolerance);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CalcPhaseEquilibriumElec2([In][MarshalAs(UnmanagedType.Interface)] APVPhaseCollection pPhases, [In] cFLASHTYPE flashType, [In] cVALIDPHASE validPhases, [In] int maxIterations, [In] double tolerance, [In][Out] ref double realRetention, [In][Out] ref int intRetention, [In] cRESTART restart, [In] int realLength, [In] int intLength);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void TrueComp2AppComp([In] int nComp, [In] ref int compIndex, [In] ref double trueComp, [In] double TrueFlow, out double AppComp, out double AppFlow, [In] int phase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void EditReacDist([In] ref sbyte RDistIDs, [In] int RxnID, [In] int type, [In] int iParam, [In] double param);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void AccessLock([In] sbyte locked, [In] sbyte wait);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Update();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetPropSystemFromStream([In][MarshalAs(UnmanagedType.LPStr)] string streamName);
}
[ComImport]
[Guid("7B6F9721-4BA4-4548-9CC7-5E6095BAD72E")]
[CoClass(typeof(APVPropSystemClass))]
public interface APVPropSystem : IAPVPropSystem
{
}
[ComImport]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("35FB5ECD-B606-4434-8F02-EAECB66268D9")]
[ComConversionLoss]
public interface IAPVPropSystemInfo
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetVersion([In] cVERSIONINFO versionType, [In][Out] IntPtr ppVersion);
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[ComConversionLoss]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("B8D12C17-D843-44B5-81AD-1D3A11841B91")]
public class APVPropSystemClass : IAPVPropSystem, APVPropSystem, IAPVPropSystemInfo
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.Initialize([In][MarshalAs(UnmanagedType.LPStr)] string pdffile, [In] int abortFlag, [In][MarshalAs(UnmanagedType.Interface)] IAPVNotify notifyHandler, [In] int licenseKey, [In] cHBASE basis);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetGlobalPackage();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetPackage([In][MarshalAs(UnmanagedType.LPStr)] string mainPropMethod, [In][MarshalAs(UnmanagedType.LPStr)] string henryComp, [In][MarshalAs(UnmanagedType.LPStr)] string chemistry, [In] cTRUECOMP trueComp, [In][MarshalAs(UnmanagedType.LPStr)] string freeWaterMethod, [In] cSOLUWATER soluWater);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetPackage([Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder mainPropMethod, [Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder henryComp, [Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder chemistry, out cTRUECOMP trueComp, [Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder freeWaterMethod, out cSOLUWATER soluWater);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.ClosePDF();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IAPVPropSystem.GetAvailablePropertyMethodCount();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetAvailablePropertyMethods([In] int count, out sbyte propMethods);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IAPVPropSystem.GetAvailableFreeWaterMethodCount();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetAvailableFreeWaterMethods([In] int count, out sbyte freeWaterMethods);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IAPVPropSystem.GetAvailableChemistryIDCount();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetAvailableChemistryIDs([In] int count, out sbyte chemistryIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IAPVPropSystem.GetAvailableHenryComponentsIDCount();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetAvailableHenryComponentsIDs([In] int count, out sbyte henryComponentsIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetBaseOpsetName([In][MarshalAs(UnmanagedType.LPStr)] string opset, [Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder baseOpset, out int isReplaced);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IAPVPropSystem.TotalComp();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetPackageComponents([In] int nc, out sbyte cids, out sbyte aliases, out sbyte cnames, out sbyte casnums);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	extern APVPropResults IAPVPropSystem.CalcPhaseProperties1([In] double temp, [In] double pres, [In] ref double molefrac, [In] int nComp, [In] ref int compIndex, [In] cPHASESTATE phaseState, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	extern APVPropResults IAPVPropSystem.CalcPhaseProperties2([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcPhaseProperties3([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	extern APVPropResults IAPVPropSystem.CalcTwoPhaseProperties1([In] double temp, [In] double pres, [In] ref double molefrac1, [In] ref double molefrac2, [In] int nComp, [In] ref int compIndex, [In] cPHASESTATE phase1State, [In] cPHASESTATE phase2State, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	extern APVPropResults IAPVPropSystem.CalcTwoPhaseProperties2([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase1, [In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase2, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcEnthalpy1([In] double temp, [In] double pres, [In] ref double molefrac, [In] int nComp, [In] ref int compIndex, [In] cPHASESTATE phaseState, out double h, out double cp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcEnthalpy2([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, out double h, out double cp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcEnthalpy3([In] double temp, [In] double pres, [In] ref double molefrac, [In] int nComp, [In] ref int compIndex, [In] cPHASESTATE phaseState, out double h, out double s, out double cp, out double v);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcEnthalpy4([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, out double h, out double s, out double cp, out double v);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcKValue1([In] double temp, [In] double pres, [In] ref double molefracLiquid, [In] ref double molefracVapor, [In] int nComp, [In] ref int compIndex, out double kvalue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcKValue2([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhaseLiquid, [In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhaseVapor, [In] int nComp, out double kvalue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcSingleProperty([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, [In] int property, [In] int bufferSize, out double values);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	extern APVPropResults IAPVPropSystem.CalcIdealGasProperties1([In] double temp, [In] ref double molefrac, [In] int nComp, [In] ref int compIndex, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	extern APVPropResults IAPVPropSystem.CalcIdealGasProperties2([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcIdealGasProperties3([In][MarshalAs(UnmanagedType.Interface)] APVPhase pPhase, [In][MarshalAs(UnmanagedType.Interface)] APVPropRequest pPropRequest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcPhaseEquilibrium1([In][MarshalAs(UnmanagedType.Interface)] APVPhaseCollection pPhases, [In] cFLASHTYPE flashType, [In] cVALIDPHASE validPhases, [In] int maxIterations, [In] double tolerance);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcPhaseEquilibrium2([In][MarshalAs(UnmanagedType.Interface)] APVPhaseCollection pPhases, [In] cFLASHTYPE flashType, [In] cVALIDPHASE validPhases, [In] int maxIterations, [In] double tolerance, [In][Out] ref double realRetention, [In][Out] ref int intRetention, [In] cRESTART restart, [In] int realLength, [In] int intLength);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcInitK([In] int compIndex, [In] double temp, [In] double pres, [In] cPHASELABEL label, out double value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.OrderPhase([In][MarshalAs(UnmanagedType.Interface)] APVPhaseCollection phaseCollection);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetPropertyInfo([In][MarshalAs(UnmanagedType.LPStr)] string property, out int pPropIndex, out int pNumElem, out int pNumDim, out int pNumDataSets, out int unitRow, out int tempUnitRow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetProperties([In] int propIndex, [In] int nDataSet, [In] int nComp, [In] ref int compIndex, [In] int nParamSize, out double paramValues, out int paramStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	extern IAPVEnumParameter IAPVPropSystem.GetParametersForPropertyMethod([In][MarshalAs(UnmanagedType.LPStr)] string propMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.UpdateEstimates([In] int nComp, [In] ref int compIndex, [In] ref double nbp, [In] ref double sg, [In] ref double mw);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetProperties([In] int propIndex, [In] int nDataSet, [In] int nComp, [In] ref int compIndex, [In] int nParamSize, [In] ref double paramValues, [In] ref int paramStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetBinaryProperties([In] int propIndex, [In] int nDataSet, [In] int nPair, [In] ref int compIndex1, [In] ref int compIndex2, [In] int nParamSize, [In] ref double paramValues, [In] ref int paramStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetPropDiagLevel([In] cDIAGLEVEL diagLevel);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetFlashDiagLevel([In] cDIAGLEVEL diagLevel);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetHBase([In] cHBASE hBase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern cHBASE IAPVPropSystem.GetHBase();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetComponentIndices([In] int nComp, [In][MarshalAs(UnmanagedType.LPStr)] ref string compNames, out int compIndex, out int kerr);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetCustomPropertyID([In][MarshalAs(UnmanagedType.LPStr)] string customProperty, out int propertyID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.RegisterCustomPropertyMethod([In][MarshalAs(UnmanagedType.LPStr)] string customProperty, [In][MarshalAs(UnmanagedType.IUnknown)] object function, out int propertyID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IAPVPropSystem.GetRealRetentionLength();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IAPVPropSystem.GetIntRetentionLength();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetRealRetention([In] int bufferSize, out double values);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetIntRetention([In] int bufferSize, out int values);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetFlashRestartFlag(out int restart);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetFlashRestartFlag([In] int restart);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetRealGlobal([In] cREALGLOBAL global, out double value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetIntGlobal([In] cINTGLOBAL global, out int value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double IAPVPropSystem.CalcPhaseProperties4([In] double temp, [In] double pres, [In] ref double molefrac, [In] int nComp, [In] ref int compIndex, [In] cPHASESTATE phaseState, [In] int propRequest, [In][Out] ref int nResults);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern cDIAGLEVEL IAPVPropSystem.GetPropDiagLevel();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern cDIAGLEVEL IAPVPropSystem.GetFlashDiagLevel();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	extern IAPVEnumPropCalc IAPVPropSystem.GetPropCalcList();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern cDIAGLEVEL IAPVPropSystem.GetDiagLevel([In] cDIAGTYPE diagType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetDiagLevel([In] cDIAGTYPE diagType, [In] cDIAGLEVEL diagLevel);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.ReloadParameters();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.ReloadParameterData([In][MarshalAs(UnmanagedType.LPStr)] string param, [In] int maxnds);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetPropParamElementInfo([In] int propIndex, [In] int nElem, out PropParamElementInfo info);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CheckEOS();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.FitLiqViscosity([In] int nVal, [In] ref double temp, [In] ref double visc, out double muland);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.FitLiqVolume(int compid, [In] int nVal, [In] ref double temp, [In] ref double mvol, out double rktzra);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetFilename([In] cFNAMETYPE __MIDL__IAPVPropSystem0000, [Out][MarshalAs(UnmanagedType.LPStr)] StringBuilder filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SynchronizePMLPackage([In] int nPackages);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
	extern void IAPVPropSystem.SetDupInfo([In] ref int reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.Initialize2([In][MarshalAs(UnmanagedType.LPStr)] string pdffile, [In] int abortFlag, [In][MarshalAs(UnmanagedType.Interface)] IAPVNotify notifyHandler, [In] int licenseKey, [In] cHBASE basis, [In] int writablePdf);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.Attach([In][MarshalAs(UnmanagedType.LPStr)] string pdffile);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.ReleasePropertyCallBack([In][MarshalAs(UnmanagedType.Interface)] APVCallBackFunctions pCallBackFunctions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetPropertyCallBack([In][MarshalAs(UnmanagedType.Interface)] APVCallBackFunctions pCallBackFunctions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetPairParameters0([In] int propIndex, [In] int nDataSet, [In] int nComp, [In] ref int compIndex, out double Charge, out int nParamSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetPairParameters1([In] int propIndex, [In] int nDataSet, [In] int nComp, [In] ref int compIndex, out double Charge, [In] int nParamSize, out int IDPair, out double paramValues, out int paramSources);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetPairParameters([In] int propIndex, [In] int nDataSet, [In] int nComp, [In] ref int compIndex, [In] int nParamSize, [In] ref int IDPair, [In] ref double paramValues, out int paramSources);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetHenryComponentListCount([In][MarshalAs(UnmanagedType.Interface)] APVPropSystem henryIDs, out int count);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetHenryComponentList([In] int count, [In][MarshalAs(UnmanagedType.Interface)] APVPropSystem henryIDs, out sbyte henryCompIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetChemistryInformation([In] ref sbyte ChemistryID, [Out] IntPtr pcheminfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.FreeChemistryInformation([In] ref CHEM_INFO cheminfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.ResetMessageStatus();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetPropSetProperty([In] ref sbyte propname, [In] double temp, [In] double pres, [In] int nComp, [In] ref double xComp, [In] ref int idxComp, [In] cVALIDPHASE validPhases, [In] int basis, [In] int iPhase, out double PropValues);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.DeleteNotifyHandler();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetPasswodFordatabase([In] int password);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetUnitLabel([In] int unitRow, [In] int unitcol, out sbyte label, out double RA, out double RB);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetSimOptions(out double TLower, out double TUpper, out double PLower, out double PUpper, out double Xh2o, out double FlashTol, out int FlashMax, out int DerivFlag, out int GamuBase, out int GamaBase, out int FlashMeth, out int FlashOpt);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetSimOptions([In] int OPTIndex, [In] double Real8Value, [In] int IntegerValue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetOLIPath([In] ref byte path);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetAspenCalculationErrors(out int iTotalTerminal, out int iPropTerminal, out int iSysTerminal, out int iSimuTerminal, out int iTotalSevere, out int iPropSevere, out int iSysSevere, out int iSimuSevere, out int iTotalError, out int iPropError, out int iSysError, out int iSimuError, out int iTotalWarn, out int iPropWarn, out int iSysWarn, out int iSimuWarn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IAPVPropSystem.GetAvailableCompGroupsIDCount();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetAvailableCompGroupsIDs([In] int count, out sbyte CompGroupsIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetCompGroupComponentListCount([In] ref sbyte CompGroupsIDs, out int count);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetCompGroupComponentList([In] int count, [In] ref sbyte CompGroupsIDs, out sbyte CompGroupCompIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.Initialize3();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.UpdateEstimates2([In] int nComp, [In] ref int compIndex, [In] ref double nbp, [In] ref double sg, [In] ref double mw, [In] ref double tc, [In] ref double pc, [In] ref double vc, [In] ref double omega, [In] ref double vtheta, [In] ref double vstctd, [In] ref double omgctd, [In] int SetViscParam);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetEOFlashFlag([In] int EOFlasg);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.AmineEnabled([In] int nComp, [In] ref int compIndex, out int enabled);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.AminePkgStgEfficiencies([In] double temp, [In] double pres, [In] int nComp, [In] ref int idx, [In] double L, [In] ref double x, [In] double v, [In] ref double y, [In] double Lin, [In] ref double xin, [In] double Vin, [In] ref double yin, [In] int TypeFlag, [In] int kstg, [In] int emMode, [In][Out][MarshalAs(UnmanagedType.LPArray, SizeConst = 3)] double[] em3, [In] double Afac, [In][MarshalAs(UnmanagedType.LPArray, SizeConst = 20)] int[] icolp, [In][MarshalAs(UnmanagedType.LPArray, SizeConst = 30)] double[] rcolp, [In][MarshalAs(UnmanagedType.LPArray, SizeConst = 30)] double[] pkprms, [In][MarshalAs(UnmanagedType.LPArray, SizeConst = 50)] double[] gencor, [In] sbyte IsLiqLiqExtractor);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.InitializeFromInputFile([In][MarshalAs(UnmanagedType.LPStr)] string inputfile, [In] int abortFlag, [In][MarshalAs(UnmanagedType.Interface)] IAPVNotify notifyHandler, [In] int licenseKey, [In] cHBASE basis, [In][MarshalAs(UnmanagedType.LPStr)] string insertlib);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.InitializeFromInput([In][MarshalAs(UnmanagedType.LPStr)] string input, [In] int abortFlag, [In][MarshalAs(UnmanagedType.Interface)] IAPVNotify notifyHandler, [In] int licenseKey, [In] cHBASE basis, [In][MarshalAs(UnmanagedType.LPStr)] string insertlib);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.AddInput([In][MarshalAs(UnmanagedType.LPStr)] string fragment, [In][MarshalAs(UnmanagedType.LPStr)] string key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.RemoveInput([In][MarshalAs(UnmanagedType.LPStr)] string key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CurrentInput([MarshalAs(UnmanagedType.LPStr)] out string allinput);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.Activate(out int valid);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.InsertLibrary([In][MarshalAs(UnmanagedType.LPStr)] string insert);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.Backup([In][MarshalAs(UnmanagedType.LPStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetComponentTypeByComponentID([In] int nComp, [In] ref sbyte compid, out int compIndex, out int compType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.WriteMessage([In][MarshalAs(UnmanagedType.LPStr)] string message);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetComponentTypeByComponentIndex([In] int nComp, [In] ref int compIndex, out int compType, out int nIon, out int nSolid, out int nMolecular, out int nDiss);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IAPVPropSystem.GetAvailableReacDistNumber();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetAvailableReacDistID([In] int NumRdist, out sbyte RDistIDs, out int RxnNo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.GetReacDistInformation([In] ref sbyte RDistIDs, [In] int NumRdist, [Out] IntPtr pRdistinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.FreeReacDistInformation([In] ref RDIST_INFO rdistinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcPhaseEquilibriumElec1([In][MarshalAs(UnmanagedType.Interface)] APVPhaseCollection pPhases, [In] cFLASHTYPE flashType, [In] cVALIDPHASE validPhases, [In] int maxIterations, [In] double tolerance);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.CalcPhaseEquilibriumElec2([In][MarshalAs(UnmanagedType.Interface)] APVPhaseCollection pPhases, [In] cFLASHTYPE flashType, [In] cVALIDPHASE validPhases, [In] int maxIterations, [In] double tolerance, [In][Out] ref double realRetention, [In][Out] ref int intRetention, [In] cRESTART restart, [In] int realLength, [In] int intLength);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.TrueComp2AppComp([In] int nComp, [In] ref int compIndex, [In] ref double trueComp, [In] double TrueFlow, out double AppComp, out double AppFlow, [In] int phase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.EditReacDist([In] ref sbyte RDistIDs, [In] int RxnID, [In] int type, [In] int iParam, [In] double param);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.AccessLock([In] sbyte locked, [In] sbyte wait);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.Update();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystem.SetPropSystemFromStream([In][MarshalAs(UnmanagedType.LPStr)] string streamName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IAPVPropSystemInfo.GetVersion([In] cVERSIONINFO versionType, [In][Out] IntPtr ppVersion);
}
public enum cPHASEVARIABLE
{
	cpvTemperature,
	cpvPressure,
	cpvNumComp,
	cpvCompIndex,
	cpvMoleFracs,
	cpvPhaseState,
	cpvPhaseLabel,
	cpvPhaseStatus,
	cpvVfrac,
	cpvBeta,
	cpvEnthalpy,
	cpvEntropy,
	cpvGibbsEnergy,
	cpvMolarVolume,
	cpvKVL,
	cpvKVL2,
	cpvAMW,
	cpvFlowRatio,
	cpvTrueComps,
	cpvSolIndex,
	cpvAqVol,
	cpvPH,
	cpvOsmoticP,
	cpvIONSM,
	cpvTrueVisc,
	cpvTrueSCmp,
	cpvTrueVfrac,
	cpvTrueBeta,
	cpvTrueSfrac,
	cpvTrueAqCmp,
	cpvTrueSCp
}
public enum cPHASELABEL
{
	cplVapor = 1,
	cplLiquid,
	cplSolid,
	cplLiquid2,
	cplOverall,
	cplOrganic,
	cplAqueous,
	cplUnknown
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDispatchable)]
[Guid("AA7DA703-1D59-47FA-9765-19D15A54EF00")]
public interface IAPVNotify
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OnAbort();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OnWriteTerminal([In] int nLines, [In] int lineLength, [In][MarshalAs(UnmanagedType.LPStr)] string lines);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OnPDFChange([In] APVPDFChangeType type, [In] int len, [In][MarshalAs(UnmanagedType.LPStr)] string pdfname);
}
public enum cHBASE
{
	chbComponent,
	chbElement
}
public enum cTRUECOMP
{
	ctcApparent,
	ctcTrue
}
public enum cSOLUWATER
{
	cswSaturatedSteamTable,
	cswSaturatedPrimaryPackage,
	cswUnsaturatedPrimaryPakcage,
	cswNoCorrection,
	cswWaterSolubilityIsOne,
	cswUnsaturatedSteamTable
}
public enum cPHASESTATE
{
	cpsVapor = 1,
	cpsLiquid,
	cpsSolid,
	cpsMixed,
	cpsUnknown
}
public enum cFLASHTYPE
{
	cftPQ = 1,
	cftTP,
	cftPV,
	cftTQ,
	cftTV,
	cftPS,
	cftPU
}
public enum cVALIDPHASE
{
	cvpVaporOnly = 1,
	cvpLiquidOnly,
	cvpSolidOnly,
	cvpVaporLiquid,
	cvpVaporLiquidLiquid,
	cvpVaporLiquidFreeWater,
	cvpLiquidFreeWater,
	cvpLiquidDirtyWater,
	cvpVaporLiquidDirtyWater
}
public enum cRESTART
{
	rsNo,
	rsYes,
	rsContinue
}
[ComImport]
[Guid("8EC87582-03F2-4B6A-968A-96BCB7CEDAA3")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAPVEnumParameter
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Next([In] uint celt, out ParameterInfo rgelt, out uint pceltFetched);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Skip([In] uint celt);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Clone([MarshalAs(UnmanagedType.Interface)] out IAPVEnumParameter ppenum);
}
public enum cDIAGLEVEL
{
	cdlTerminal_Error = 0,
	cdlSevere_Error = 1,
	cdlError = 2,
	cdlWarning = 3,
	cdlInformation = 4,
	cdlDetailed = 8
}
public enum cREALGLOBAL
{
	cgrRMISS,
	cgrRMIN,
	cgrRGAS
}
public enum cINTGLOBAL
{
	cgrIMISS,
	cgiNBCOMN
}
[ComImport]
[Guid("48AD041C-4999-45F5-A3DE-ED14091F9ACE")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAPVEnumPropCalc
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Next([In] uint celt, out PackPropInfo rgelt, out uint pceltFetched);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Skip([In] uint celt);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Clone([MarshalAs(UnmanagedType.Interface)] out IAPVEnumPropCalc ppenum);
}
public enum cDIAGTYPE
{
	cdtSystem,
	cdtSimulation,
	cdtProperties,
	cdtComponents,
	cdtHistorySystem,
	cdtHistorySimulation,
	cdtHistoryProperties,
	cdtHistoryComponents
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct PropParamElementInfo
{
	public int size;

	public double defval;

	public double nomval;

	public double loval;

	public double hival;

	public int symmetry;
}
public enum cFNAMETYPE
{
	cfnNAMES,
	cfnINPUT,
	cfnUSRP1A,
	cfnUSRP1B,
	cfnUSRP2A,
	cfnUSRP2B,
	cfnUSRP2C,
	cfnUSRCST,
	cfnMODNM,
	cfnMSF,
	cfnLIBRRY,
	cfnPCKLIB,
	cfnOUTFIL,
	cfnHISTRY,
	cfnSINPUT,
	cfnACCONT,
	cfnPARM,
	cfnRETCOD,
	cfnSORTED,
	cfnREPRT1,
	cfnREPRT2,
	cfnMCP,
	cfnNOLOAD,
	cfnITDUMP,
	cfnPDF,
	cfnPCF,
	cfnREPORT,
	cfnSUMARY,
	cfnPLTFIL,
	cfnURP,
	cfnSRP,
	cfnTEM,
	cfnXITDB,
	cfnXSCD,
	cfnXCOM,
	cfnXDIPPR,
	cfnXIPCD,
	cfnXISOL,
	cfnXIAQU,
	cfnXILB,
	cfnXPCD,
	cfnXFLO,
	cfnXSOL,
	cfnXAQU,
	cfnXBIN,
	cfnXSDF,
	cfnDRSRPT,
	cfnIAP1,
	cfnIAP2,
	cfnNINPUT,
	cfnEDF,
	cfnJOURNL,
	cfnPRDATA,
	cfnBACKUP,
	cfnSCRIPT,
	cfnADVENT,
	cfnSTRLIB,
	cfnHLPLIB,
	cfnAPINI,
	cfnXBPS,
	cfnXBARIN,
	cfnXMRL,
	cfnXNPL,
	cfnXNBS,
	cfnXJAN,
	cfnXSGT,
	cfnXIBIN,
	cfnXPC85,
	cfnXFACT,
	cfnDFMSFL,
	cfnXPROJ,
	cfnXPOPCD,
	cfnXSEPCD,
	cfnDLOPT,
	cfnXPC93,
	cfnXAQ92,
	cfnDYL,
	cfnXIKC,
	cfnXPPDS,
	cfnXPC11,
	cfnXDMO,
	cfnXETHL,
	cfnPROPPDF,
	cfnXPPSDF,
	cfnMRSHL,
	cfnDLOPTU,
	cfnXPC12,
	cfnXINIT,
	cfnXPC13,
	cfnXAPED,
	cfnXPC20
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
[ComConversionLoss]
public struct CHEM_INFO
{
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
	public sbyte[] ChemID;

	public int NumOfRxns;

	public int basis;

	public int Hydrate;

	public double TempAppEqui;

	public int NumOfStoic;

	public int NumOfSalt;

	public int NumOfDiss;

	[ComConversionLoss]
	public IntPtr Stoic;

	[ComConversionLoss]
	public IntPtr Salt;

	[ComConversionLoss]
	public IntPtr Diss;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
[ComConversionLoss]
public struct RDIST_INFO
{
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
	public sbyte[] RDistID;

	public int NumOfRxns;

	public int Gibbs;

	public int Elect;

	public int basis;

	[ComConversionLoss]
	public IntPtr Rxns;
}
public enum APVPDFChangeType
{
	APV_Loaded,
	APV_Unloading,
	APV_Unloaded
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
[ComConversionLoss]
public struct ParameterInfo
{
	public ushort size;

	public ushort length;

	public int ndst;

	public int nElem;

	public int nDim;

	[ComConversionLoss]
	public IntPtr parameter;
}
[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct PackPropInfo
{
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
	public sbyte[] propname;

	public cPKBASISQUAL basis;

	public cPKSUBSTREAM substream;

	public cPKQUAL qual;

	public cPKPHASE phase;

	public int flash;

	public int nomassbalonly;

	public int unitRow;

	public int propgroup;

	public int refpropnum;

	public int propnum;

	public cPKCURVEFLAG curveflag;

	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
	public sbyte[] defname;

	public cPKBLENDMETHOD blendmethod;

	public int expolflg;

	public int flowdepflg;

	public int compdepflg;

	public int presdepflg;

	public int tempdepflg;
}
public enum cPKBASISQUAL
{
	PKNOTALLOWED,
	PKOPTIONAL
}
public enum cPKSUBSTREAM
{
	PKMIXED = 1,
	PKCISOLID = 2,
	PKNC = 4,
	PKALL = 8
}
public enum cPKQUAL
{
	PKQCOMP = 1,
	PKQPHASE = 4,
	PKQTEMP = 16,
	PKQPRES = 64,
	PKQPCTLV = 256,
	PKQBASECOMP = 1024,
	PKQCOMPREQ = 3,
	PKQPHASEREQ = 12,
	PKQTEMPREQ = 48,
	PKQPRESREQ = 192,
	PKQPCTLVREQ = 768,
	PKQBASECOMPREQ = 3072
}
public enum cPKPHASE
{
	PKTOTAL = 1,
	PKV = 2,
	PKL = 4,
	PKL1 = 8,
	PKL2 = 0x10,
	PKS = 0x20
}
public enum cPKCURVEFLAG
{
	PKSCALAR,
	PKNOTEMPDEPEND,
	PKTEMPDEPEND
}
public enum cPKBLENDMETHOD
{
	PKNONE,
	PKSTDVOLBASIS,
	PKMASSBASIS,
	PKMOLEBASIS,
	PKUSERBASIS
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
[ComConversionLoss]
public struct RXN_INFO
{
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
	public sbyte[] RxnID;

	public int NumOfComp;

	[ComConversionLoss]
	public IntPtr compid;

	[ComConversionLoss]
	public IntPtr Stoi;

	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
	public double[] Coeff;

	public double TempApp;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
[ComConversionLoss]
public struct RDIST_RXN_INFO
{
	public int RxnID;

	public int type;

	public int phase;

	public double Delt;

	public int basis;

	public int NumOfComp;

	[ComConversionLoss]
	public IntPtr compid;

	[ComConversionLoss]
	public IntPtr Stoi;

	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
	public double[] KCoeff;

	public double PreExp;

	public double ACTEn;

	public double TExp;

	public double TRef;

	public int PWENumOfComp;

	[ComConversionLoss]
	public IntPtr PWECompID;

	[ComConversionLoss]
	public IntPtr PWExp;
}
public enum cVERSIONINFO
{
	cvlShort = 1,
	cvlShortLabel,
	cvlRegistry,
	cvlPatchLevel,
	cvlBuildNumber,
	cvlBuildTime,
	cvlFullVersion,
	cvlAPrSystemRegistry
}
