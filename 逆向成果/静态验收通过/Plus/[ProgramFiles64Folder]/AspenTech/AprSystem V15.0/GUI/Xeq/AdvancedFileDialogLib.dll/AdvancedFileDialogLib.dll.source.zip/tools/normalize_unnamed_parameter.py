"""Keep ILASM's generated name out of the private COM event-provider constructor."""
from pathlib import Path

import clr_meta


def normalize(path):
    path = Path(path)
    data = bytearray(path.read_bytes())
    pe, cli, root = clr_meta.read_image(bytes(data))
    tables = root["tables"]
    read = lambda table, row: clr_meta.read_row(root["bytes"], tables, table, row)
    get_string = lambda offset: clr_meta.strings(pe, cli, root, offset)

    expected_namespace = "AdvancedFileDialogLib"
    expected_type = "_DAdvancedFileDialogEvents_EventProvider"
    method_count = tables["rows"][6]
    param_count = tables["rows"][8]
    for rid in range(1, tables["rows"][2] + 1):
        owner = read(2, rid)
        if (get_string(owner[2]), get_string(owner[1])) == (expected_namespace, expected_type):
            method_end = read(2, rid + 1)[5] if rid < tables["rows"][2] else method_count + 1
            break
    else:
        return False

    for rid in range(owner[5], method_end):
        method = read(6, rid)
        signature = clr_meta.blob(pe, cli, root, method[4])
        if get_string(method[3]) != ".ctor" or signature != bytes.fromhex("20 01 01 1c"):
            continue
        param_end = read(6, rid + 1)[5] if rid < method_count else param_count + 1
        for pid in range(method[5], param_end):
            param = read(8, pid)
            if param[0] or param[1] != 1 or get_string(param[2]) != "A_0":
                continue
            for table, column, coded_param in (
                (0x0C, 0, (pid << 5) | 4),  # HasCustomAttribute
                (0x0B, 2, (pid << 2) | 1),  # HasConstant
                (0x0D, 0, (pid << 1) | 1),  # HasFieldMarshal
            ):
                if any(read(table, i)[column] == coded_param
                       for i in range(1, tables["rows"].get(table, 0) + 1)):
                    raise ValueError("generated parameter carries additional metadata")
            layout = tables["layout"][8]
            width = 4 if tables["heap_sizes"] & 1 else 2
            start = pe.get_offset_from_rva(cli["metadata_rva"]) + layout["offset"]
            name = start + (pid - 1) * layout["row_size"] + 4
            data[name:name + width] = bytes(width)
            path.write_bytes(data)
            return True
    return False

