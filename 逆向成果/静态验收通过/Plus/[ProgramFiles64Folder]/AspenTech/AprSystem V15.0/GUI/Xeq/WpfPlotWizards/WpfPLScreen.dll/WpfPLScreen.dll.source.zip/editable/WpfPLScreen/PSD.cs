using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPLControls;
using WpfPlotwizard;

namespace WpfPLScreen;

[ProgId("WpfPLScreen.PSD")]
public class PSD : UserControl, IRibbonPlotWizardType, IPlotWizardTemplate, IComponentConnector
{
	private IHNode _context;

	private IHWizardPlot2 _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private string _uniqueId = "PSD";

	private string _plotName;

	private object _nodeCxs;

	private System.Drawing.Image _imgBitmap;

	private bool _bHasInputDialog;

	private string[] _portName;

	private readonly string _plotType = WpfPLDiscurvesResources.PSDPlotType;

	private readonly string _massFrac = WpfPLDiscurvesResources.PSDPlotType_Mass_Fraction;

	private readonly string _cumMassFrac = WpfPLDiscurvesResources.PSDPlotType_Cumulative_Mass_Fraction;

	private readonly string _massDensityDist = WpfPLDiscurvesResources.PSDPlotType_Mass_Density_Distribution;

	private readonly string _rrsb = "RRSB";

	private string _currentPlotType = string.Empty;

	private string _currentConfigValue = string.Empty;

	private string[] _varNames;

	private string[] type;

	private int _globalXScale;

	public static RoutedCommand OKCommand = new RoutedCommand();

	public static RoutedCommand CancelCommand = new RoutedCommand();

	private bool _bCheckDataOnly;

	internal CurvesSelectorControl SubStreamList;

	internal CurvesSelectorControl StreamList;

	private bool _contentLoaded;

	public string TooltipContentForRibbonItem => WpfPLDiscurvesResources.PSDTooltip;

	public string TooltipHeaderForRibbonItem => WpfPLDiscurvesResources.PSDTooltip;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot2;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _plotType };

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public PSD()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		InitializeComponent();
		_bHasInputDialog = true;
		type = new string[4]
		{
			WpfPLDiscurvesResources.PSDPlotType_Mass_Fraction,
			WpfPLDiscurvesResources.PSDPlotType_Cumulative_Mass_Fraction,
			WpfPLDiscurvesResources.PSDPlotType_Mass_Density_Distribution,
			"RRSB"
		};
		if (_imgBitmap == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLScreen.Images.PSD.ico");
			_imgBitmap = new Bitmap(manifestResourceStream);
		}
		CommandBinding commandBinding = new CommandBinding(OKCommand, ExecuteOKCommand, CanExecuteOKCommand);
		CommandBinding commandBinding2 = new CommandBinding(CancelCommand, ExecuteCancelCommand);
		base.CommandBindings.Add(commandBinding);
		base.CommandBindings.Add(commandBinding2);
		_portName = new string[4] { "Ports/F(IN)", "Ports/O(OUT)", "Ports/U(OUT)", "Ports/MS(OUT)" };
		_varNames = new string[2] { "../../Results Summary/Stream-Sum/Dist-Curve/Output/SUBS-ATTR/", "../../Results Summary/Stream-Sum/Dist-Curve/Output/MAXIMUM" };
	}

	public void SetCaption(ref string caption)
	{
		caption = "PSD";
	}

	public void SetDefaultHeight(ref double defaultHeight)
	{
		defaultHeight = 350.0;
	}

	public void SetDefaultWidth(ref double defaultWidth)
	{
		defaultWidth = 300.0;
	}

	public void SetMinHeight(ref double minHeight)
	{
		minHeight = 350.0;
	}

	public void SetMinWidth(ref double minWidth)
	{
		minWidth = 300.0;
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		if (sFieldName.CompareTo(_plotType) == 0)
		{
			return new List<string> { _massFrac, _cumMassFrac, _massDensityDist, _rrsb };
		}
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
		if (sFieldName.CompareTo(_plotType) == 0)
		{
			sCurrentVal = _currentPlotType;
		}
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
		if (sFieldName.CompareTo(_plotType) == 0)
		{
			_currentPlotType = sValue;
		}
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		if (sField.CompareTo(_plotType) == 0)
		{
			return (RibbonControlType)1;
		}
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
		sConfigValue = _currentConfigValue;
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
		_currentConfigValue = sValue;
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot2;
		IHNode iHNode = null;
		if (_currentPlotType == string.Empty)
		{
			_currentPlotType = type[1];
			iHNode = _context.Application.Tree.FindNode("Settings/psdplottype");
			if (iHNode != null)
			{
				_currentPlotType = type[(dynamic)iHNode.get_Value(Type.Missing)];
			}
		}
		iHNode = _context.Application.Tree.FindNode("Settings/psdxscale");
		if (iHNode != null)
		{
			_globalXScale = (dynamic)iHNode.get_Value(Type.Missing);
		}
		List<string> list = new List<string>();
		for (int i = 0; i < _portName.Count(); i++)
		{
			IHNode iHNode2 = _context.FindNode(_portName[i]);
			if (iHNode2 != null && iHNode2.Elements.Count > 0)
			{
				for (int j = 0; j < iHNode2.Elements.Count; j++)
				{
					list.Add(iHNode2.Elements.get_Label(0, j, Type.Missing));
				}
			}
		}
		if (list.Count() <= 0)
		{
			ierror = 1;
			return;
		}
		IHNode iHNode3 = _context.FindNode(_varNames[0]);
		if (iHNode3 == null || iHNode3.Elements.Count <= 0)
		{
			if (_context.FindNode("Stream Results/Display") != null)
			{
				iHNode3 = _context.FindNode(_varNames[0]);
				if (iHNode3 != null && iHNode3.Elements.Count > 0)
				{
					goto PlotNodeAvailable;
				}
				ierror = 1;
				return;
			}
			else
			{
				ierror = 1;
				return;
			}
		}
		PlotNodeAvailable:
		List<string> list2 = new List<string>();
		for (int k = 0; k < iHNode3.Elements.Count; k++)
		{
			string item = iHNode3.Elements.get_Label(0, k, Type.Missing);
			list2.Add(item);
		}
		SubStreamList.SetCurves(list2.ToArray());
		SubStreamList.Header = WpfPLDiscurvesResources.PSDSubstream;
		if (string.IsNullOrEmpty(_currentConfigValue))
		{
			List<string> list3 = new List<string>();
			list3.Add(list2[0].ToString());
			SubStreamList.SetSelectedCurves(list3.ToArray());
		}
		if (list2.Count == 1)
		{
			SubStreamList.IsCheckAll = true;
		}
		IHNode iHNode4 = iHNode3.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing];
		if (iHNode4 == null || iHNode4.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		List<string> list4 = new List<string>();
		for (int l = 0; l < iHNode4.Elements.Count; l++)
		{
			string text = iHNode4.Elements.get_Label(0, l, Type.Missing);
			for (int m = 0; m < list.Count; m++)
			{
				if (!list4.Contains(text) && text.CompareTo(list[m]) == 0)
				{
					list4.Add(text);
					break;
				}
			}
		}
		StreamList.SetCurves(list4.ToArray());
		StreamList.Header = WpfPLDiscurvesResources.PSDStream;
		StreamList.IsCheckAll = true;
		_bHasInputDialog = false;
		if (!string.IsNullOrEmpty(_currentConfigValue))
		{
			SubStreamList.IsCheckAll = false;
			StreamList.IsCheckAll = false;
			RestoreConfigValue(_currentConfigValue);
			_bHasInputDialog = true;
		}
	}

	public void UpdateWizardData()
	{
		_wizardPlot.RemoveAllDependentVariable();
		List<string> list = new List<string>(StreamList.GetSelectedCurves());
		List<string> list2 = new List<string>(SubStreamList.GetSelectedCurves());
		if (list.Count <= 0 || list2.Count <= 0)
		{
			return;
		}
		IHNode iHNode = _context.FindNode(_varNames[0]);
		IHNode iHNode2 = _context.FindNode(_varNames[1]);
		if (iHNode == null || iHNode.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing] == null || iHNode.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing] == null)
		{
			return;
		}
		_wizardPlot.RemoveAllIndependentVariable();
		_ = iHNode2.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.Count;
		_wizardPlot.PlotVal.NVariables = 0;
		_wizardPlot.PlotVal.NXVariables = 0;
		_help.SetXData(_context, _wizardPlot, list2, _varNames[1], _currentPlotType);
		_help.SetYData(_context, _wizardPlot, _currentPlotType, list, list2, _varNames);
		((IHPlotVal)_wizardPlot.PlotVal).set_AxisScale(0, _globalXScale);
		if (_currentPlotType == _rrsb)
		{
			((IHPlotVal)_wizardPlot.PlotVal).set_AxisScale(0, 1);
			((IHPlotVal)_wizardPlot.PlotVal).set_AxisScale(1, 4);
		}
		_currentConfigValue = SaveConfigValue();
		_bHasInputDialog = true;
	}

	private void ExecuteOKCommand(object sender, ExecutedRoutedEventArgs e)
	{
		UpdateWizardData();
		_help.CloseForm((UserControl)this, (bool?)true);
	}

	private void CanExecuteOKCommand(object sender, CanExecuteRoutedEventArgs e)
	{
		int num = StreamList.GetSelectedCurves().Count();
		int num2 = SubStreamList.GetSelectedCurves().Count();
		e.CanExecute = num == 0 || num2 == 0 ? false : true;
	}

	private void ExecuteCancelCommand(object sender, ExecutedRoutedEventArgs e)
	{
		_help.CloseForm((UserControl)this, (bool?)false);
	}

	private string SaveConfigValue()
	{
		_ = string.Empty;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("SubStreamSelection=");
		List<string> list = new List<string>(SubStreamList.GetSelectedCurves());
		int count = list.Count;
		for (int i = 0; i < count; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(",");
			}
			stringBuilder.Append(list[i]);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("CheckAll=");
		stringBuilder.Append(SubStreamList.IsCheckAll);
		stringBuilder.Append(";");
		stringBuilder.Append("StreamSelection=");
		List<string> list2 = new List<string>(StreamList.GetSelectedCurves());
		count = list2.Count;
		for (int j = 0; j < count; j++)
		{
			if (j > 0)
			{
				stringBuilder.Append(",");
			}
			stringBuilder.Append(list2[j]);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("CheckAll=");
		stringBuilder.Append(StreamList.IsCheckAll);
		stringBuilder.Append(";");
		return stringBuilder.ToString();
	}

	private void RestoreConfigValue(string ConfigString)
	{
		string[] array = ConfigString.Split(';');
		int num = 0;
		string text = array[num].Substring(array[num].IndexOf('=') + 1);
		string[] array2 = text.Split(',');
		List<string> list = new List<string>();
		string[] array3 = array2;
		foreach (string item in array3)
		{
			list.Add(item);
		}
		SubStreamList.SetSelectedCurves(list.ToArray());
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		SubStreamList.IsCheckAll = Convert.ToBoolean(text);
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		string[] array4 = text.Split(',');
		List<string> list2 = new List<string>();
		array3 = array4;
		foreach (string item2 in array3)
		{
			list2.Add(item2);
		}
		StreamList.SetSelectedCurves(list2.ToArray());
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		StreamList.IsCheckAll = Convert.ToBoolean(text);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	public void InitializeComponent()
	{
		if (_contentLoaded)
		{
			return;
		}
		_contentLoaded = true;
		Uri resourceLocator = new Uri("/WpfPLScreen;component/psd.xaml", UriKind.Relative);
		Application.LoadComponent(this, resourceLocator);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			SubStreamList = (CurvesSelectorControl)target;
			break;
		case 2:
			StreamList = (CurvesSelectorControl)target;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}
