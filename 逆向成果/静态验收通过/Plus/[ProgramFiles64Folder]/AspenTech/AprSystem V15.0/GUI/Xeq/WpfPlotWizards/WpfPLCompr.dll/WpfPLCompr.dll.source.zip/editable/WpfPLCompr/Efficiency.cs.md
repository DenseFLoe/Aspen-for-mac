# Efficiency.cs

Source: editable/WpfPLCompr/Efficiency.cs

Source SHA-256: 9f4ad4820e63dee4d9c51456817e1c9e3c1062edc018a1af0a807e3ddc3d2257
