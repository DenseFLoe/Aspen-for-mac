# 可复跑历史诊断探针

从 ZIP 解包根使用与主构建相同的四个依赖，指定新的输出目录。

```powershell
python ./evidence/check-historical-report.py --original $original --ilasm $ilasm --dotnet $net9Dotnet --cecil $cecil --out-dir ../history-probe
```

探针用两个独立的副本。第一个只修改历史 expected SHA 为 64 个零并更新变动成员的指纹，预期历史字段 `status="computed"`、`matches=false`。第二个在历史构造块中注入错误并更新指纹，预期历史字段 `status="unavailable"`、`matches=null`、`reason="synthetic historical probe failure"`。这两个副本均须完成构建并生成与当前原件一致的 `WpfPLData.dll`。原 ZIP 和其解包内容保持原样。探针在 `../history-probe/probe-receipt.json` 记录退出状态和产物指纹。
