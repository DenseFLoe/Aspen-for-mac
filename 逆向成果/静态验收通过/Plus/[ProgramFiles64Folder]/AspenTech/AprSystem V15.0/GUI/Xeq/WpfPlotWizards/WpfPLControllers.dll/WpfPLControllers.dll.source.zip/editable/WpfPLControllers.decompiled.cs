using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPlotWizardsHelper;
using WpfPlotwizard;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("WpfPLControllers")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("WpfPLControllers")]
[assembly: AssemblyCopyright("Copyright ©  2017 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("92340b4b-5fa5-4aba-9904-1fcf97bb0061")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("1.0.0.0")]
namespace WpfPLControllers
{
	[ProgId("WpfPLControllers.RibbonPlotWizardMgr")]
	public class RibbonPlotWizardMgr : IRibbonPlotWizardMgr
	{
		private static string[] supportedTypes = new string[1] { "Summary" };

		private IHNode _hnode;

		private IHWizardPlot _wizardPlot;

		private static List<PWRPlotType> _lspwrTypes = new List<PWRPlotType>();

		private PWRParser _pwrParser = new PWRParser();

		private Assembly _asm;

		private Dictionary<string, IRibbonPlotWizardType> _dicTagIdToPlotType;

		private IHWizardPlot _tempWizard = (CHWizardPlot)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("9E14C11F-6706-4067-8112-35CE9468F3A5")));

		public RibbonPlotWizardMgr()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			Initialize();
		}

		long IRibbonPlotWizardMgr.SupportedPlotTypes(ref List<string> lsTagIds)
		{
			lsTagIds.Clear();
			for (int i = 0; i < _lspwrTypes.Count; i++)
			{
				PWRPlotType val = _lspwrTypes[i];
				IRibbonPlotWizardType iplotType = null;
				_tempWizard.Clear();
				_pwrParser.FillDefaultPlotVal(val, ref _hnode, ref _tempWizard);
				if (DoesPlotTypeHaveData(val.TagId, ref iplotType, ref _tempWizard))
				{
					lsTagIds.Add(val.TagId);
				}
			}
			return _lspwrTypes.Count;
		}

		long IRibbonPlotWizardMgr.GetPlotType(string sTagId, ref IRibbonPlotWizardType plwType)
		{
			if (_dicTagIdToPlotType.ContainsKey(sTagId))
			{
				plwType = _dicTagIdToPlotType[sTagId];
				if (plwType == null)
				{
					return 0L;
				}
				PWRPlotType val = null;
				_pwrParser.FindPlotType(sTagId, ref _lspwrTypes, ref val);
				_pwrParser.FillDefaultPlotVal(val, ref _hnode, ref _wizardPlot);
			}
			return 0L;
		}

		void IRibbonPlotWizardMgr.SetContext(object oNode, ref object oWizard)
		{
			_hnode = oNode as IHNode;
			_wizardPlot = oWizard as IHWizardPlot;
		}

		void IRibbonPlotWizardMgr.ShowInputDialog(string sPlotName)
		{
		}

		private void InitializeWizardPlot()
		{
		}

		private void Initialize()
		{
			_asm = Assembly.GetExecutingAssembly();
			StreamReader streamReader = new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLControllers.Text.Controlerspwr.txt"));
			_lspwrTypes.Clear();
			_pwrParser.ParsePwrFile(streamReader, ref _lspwrTypes);
			_dicTagIdToPlotType = new Dictionary<string, IRibbonPlotWizardType>();
			string[] array = supportedTypes;
			foreach (string text in array)
			{
				if (text == supportedTypes[0])
				{
					IRibbonPlotWizardType value = new Summary();
					_dicTagIdToPlotType.Add(text, value);
				}
			}
		}

		private bool DoesPlotTypeHaveData(string sTagId, ref IRibbonPlotWizardType iplotType, ref IHWizardPlot iWizardPlot)
		{
			int num = 0;
			if (_dicTagIdToPlotType.ContainsKey(sTagId))
			{
				iplotType = _dicTagIdToPlotType[sTagId];
				if (iplotType == null)
				{
					return false;
				}
				object obj = iWizardPlot;
				iplotType.Context((object)_hnode, ref obj, ref num);
				if (num == 0)
				{
					return true;
				}
			}
			return false;
		}
	}
	[RibbonPlotWizardMgr("WpfPLControllers.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
	public class ControlersPlotWizardModule : PlotModuleBase
	{
	}
	[ProgId("WpfPLControllers.Summary")]
	public class Summary : IRibbonPlotWizardType, IPlotWizardTemplate
	{
		private IHNode _context;

		private IHWizardPlot _wizardPlot;

		private PlotwizardHelper _help = new PlotwizardHelper();

		private string _variableUnit = string.Empty;

		private string _currentConfigValue = string.Empty;

		private dynamic _mvarControlContext;

		private string sTimePlot = "TimePlot";

		private string _sTitle = string.Empty;

		private string _uniqueId = WpfPLControlsResource.Summary_ID;

		private string _plotName;

		private object _nodeCxs;

		private Image _imgBitmap;

		private bool _bHasInputDialog;

		private readonly string _SummaryId = WpfPLControlsResource.Summary_ID;

		private readonly string _timeUnitFieldId = WpfPLControlsResource.Time;

		private Dictionary<string, string[]> _VarNamesDic;

		private Dictionary<string, string[]> _sYAxisNameDic;

		private Dictionary<string, string[]> _sYAxisGroupDic;

		private bool _bCheckDataOnly;

		public string TooltipContentForRibbonItem => WpfPLControlsResource.Summary_TooltipContent;

		public string TooltipHeaderForRibbonItem => WpfPLControlsResource.Summary_ID;

		string IRibbonPlotWizardType.TagID
		{
			get
			{
				return _uniqueId;
			}
			set
			{
				_uniqueId = value;
			}
		}

		string IRibbonPlotWizardType.Name
		{
			get
			{
				return _plotName;
			}
			set
			{
				_plotName = value;
			}
		}

		object IRibbonPlotWizardType.WizardPlot
		{
			get
			{
				return _wizardPlot;
			}
			set
			{
				_wizardPlot = value as IHWizardPlot;
			}
		}

		object IRibbonPlotWizardType.CxsNode
		{
			get
			{
				return _nodeCxs;
			}
			set
			{
				_nodeCxs = value;
			}
		}

		Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

		bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

		string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

		long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

		List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string>();

		List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

		public bool CheckDataOnly
		{
			get
			{
				return _bCheckDataOnly;
			}
			set
			{
				_bCheckDataOnly = value;
			}
		}

		public Summary()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			_bHasInputDialog = false;
			_currentConfigValue = string.Empty;
			SetVariables();
			if (_imgBitmap == null)
			{
				Assembly.GetExecutingAssembly();
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLControllers.Images.temp.ico");
				_imgBitmap = new Bitmap(manifestResourceStream);
			}
		}

		private void SetVariables()
		{
			_VarNamesDic = new Dictionary<string, string[]>
			{
				{
					"PID",
					new string[3] { "PROCESS_VAR", "SET_POINT", "MANIPULAT_VAR" }
				},
				{
					"SPLITRANGE",
					new string[3] { "PROCESS_VAR", "MANIPULAT_VAR", "MANIPULAT_VAR_2" }
				},
				{
					"DEADTIME",
					new string[2] { "PROCESS_VAR", "MANIPULAT_VAR" }
				},
				{
					"LAG",
					new string[2] { "PROCESS_VAR", "MANIPULAT_VAR" }
				},
				{
					"RATIO",
					new string[3] { "PROCESS_VAR", "PROCESS_VAR_2", "MANIPULAT_VAR" }
				},
				{
					"COMPARATOR",
					new string[3] { "PROCESS_VAR", "PROCESS_VAR_2", "MANIPULAT_VAR" }
				},
				{
					"MULTIPLY",
					new string[3] { "PROCESS_VAR", "PROCESS_VAR_2", "MANIPULAT_VAR" }
				}
			};
			_sYAxisNameDic = new Dictionary<string, string[]>
			{
				{
					"PID",
					new string[3]
					{
						ApwnResources.MMPID_Result_PID_ProcessVariable,
						ApwnResources.MMPID_Result_PID_SetPoint,
						ApwnResources.MMPID_Plot_Output + " (OP)"
					}
				},
				{
					"SPLITRANGE",
					new string[3]
					{
						ApwnResources.MMPID_Result_PID_ProcessVariable,
						ApwnResources.MMPID_Plot_ControllerOutput + " 1 (OP1)",
						ApwnResources.MMPID_Plot_ControllerOutput + " 2 (OP2)"
					}
				},
				{
					"DEADTIME",
					new string[2]
					{
						ApwnResources.MMPID_Result_PID_ProcessVariable,
						ApwnResources.MMPID_Result_PID_Output
					}
				},
				{
					"LAG",
					new string[2]
					{
						ApwnResources.MMPID_Result_PID_ProcessVariable,
						ApwnResources.MMPID_Result_PID_Output
					}
				},
				{
					"RATIO",
					new string[3]
					{
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable + " 1 (PV1)",
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable + " 2 (PV2)",
						ApwnResources.MMPID_Result_PID_Output
					}
				},
				{
					"COMPARATOR",
					new string[3]
					{
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable + " 1 (PV1)",
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable + " 2 (PV2)",
						ApwnResources.MMPID_Result_PID_Output
					}
				},
				{
					"MULTIPLY",
					new string[3]
					{
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable + " 1 (PV1)",
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable + " 2 (PV2)",
						ApwnResources.MMPID_Result_PID_Output
					}
				}
			};
			_sYAxisGroupDic = new Dictionary<string, string[]>
			{
				{
					"PID",
					new string[3]
					{
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMPID_Plot_Output
					}
				},
				{
					"SPLITRANGE",
					new string[3]
					{
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMPID_Plot_Output,
						ApwnResources.MMPID_Plot_Output
					}
				},
				{
					"DEADTIME",
					new string[2]
					{
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMPID_Plot_Output
					}
				},
				{
					"LAG",
					new string[2]
					{
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMPID_Plot_Output
					}
				},
				{
					"RATIO",
					new string[3]
					{
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMPID_Plot_Output
					}
				},
				{
					"COMPARATOR",
					new string[3]
					{
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMPID_Plot_Output
					}
				},
				{
					"MULTIPLY",
					new string[3]
					{
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMOperatingSteps_Steps_Config_ProcessVariable,
						ApwnResources.MMPID_Plot_Output
					}
				}
			};
		}

		public void SetCaption(ref string caption)
		{
			caption = WpfPLControlsResource.Summary_ID;
		}

		public void SetDefaultHeight(ref double defaultHeight)
		{
			defaultHeight = 380.0;
		}

		public void SetDefaultWidth(ref double defaultWidth)
		{
			defaultWidth = 300.0;
		}

		public void SetMinHeight(ref double minHeight)
		{
			minHeight = 380.0;
		}

		public void SetMinWidth(ref double minWidth)
		{
			minWidth = 300.0;
		}

		List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
		{
			if (sFieldName.CompareTo(_SummaryId) == 0)
			{
				List<string> list = new List<string>();
				dynamic val = _mvarControlContext.Pot.T.ValidValues("units");
				{
					foreach (string item in val)
					{
						list.Add(item);
					}
					return list;
				}
			}
			return null;
		}

		void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_SummaryId) == 0)
			{
				sCurrentVal = _mvarControlContext.Pot.T.Units("CurrentUnits");
			}
		}

		void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_SummaryId) == 0)
			{
				_variableUnit = sValue;
			}
			else if (sFieldName.CompareTo(_timeUnitFieldId) == 0)
			{
				_variableUnit = sValue;
			}
		}

		void IRibbonPlotWizardType.ShowInputDialog()
		{
		}

		RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
		{
			return (RibbonControlType)0;
		}

		void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
		{
		}

		void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
		{
		}

		void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
		{
			sConfigValue = _currentConfigValue;
		}

		void IRibbonPlotWizardType.SetConfigData(string sValue)
		{
			_currentConfigValue = sValue;
		}

		void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
		{
			ierror = 1;
			if (HWizardPlot == null || HNode == null)
			{
				return;
			}
			ierror = 2;
			_context = HNode as IHNode;
			if (_context == null)
			{
				return;
			}
			ierror = 3;
			_wizardPlot = HWizardPlot as IHWizardPlot;
			_bHasInputDialog = false;
			string text = (dynamic)_context.get_AttributeValue((short)6, Type.Missing);
			string text2 = (dynamic)_context.get_AttributeValue((short)65, Type.Missing);
			ierror = 4;
			_sTitle = WpfPLControlsResource.ControllersTitle + text;
			_sTitle = _sTitle.Replace("%ID%", text2);
			StringBuilder stringBuilder = new StringBuilder("");
			stringBuilder.Append("Type:$").Append(sTimePlot);
			string[] array = _VarNamesDic[text];
			foreach (string value in array)
			{
				stringBuilder.Append("!VarPaths:$").Append(value);
			}
			stringBuilder.Append("!PlotTitle:$").Append(_sTitle);
			array = _sYAxisNameDic[text];
			foreach (string value2 in array)
			{
				stringBuilder.Append("!YAxisNames:$").Append(value2);
			}
			array = _sYAxisGroupDic[text];
			foreach (string value3 in array)
			{
				stringBuilder.Append("!YAxisGroup:$").Append(value3);
			}
			stringBuilder.Append("!BlockPath:$").Append(text2).Append("!TabTitle:$")
				.Append(_sTitle)
				.Append("!PlotSettings:$");
			switch (text)
			{
			case "PID":
			case "SPLITRANGE":
			case "DEADTIME":
				stringBuilder.Append("<Scpc ShowMultipleYAxes=\"true\">\r\n\t                    <OtherSettings>\r\n\t\t                    <ShowTitle>true</ShowTitle>\r\n                            <ShowLegend>true</ShowLegend>\r\n\t                    </OtherSettings>\r\n                    </Scpc>");
				break;
			default:
				stringBuilder.Append("<Scpc ShowMultipleYAxes=\"false\">\r\n\t                    <OtherSettings>\r\n\t\t                    <ShowTitle>true</ShowTitle>\r\n                            <ShowLegend>true</ShowLegend>\r\n\t                    </OtherSettings>\r\n                    </Scpc>");
				break;
			}
			_currentConfigValue = stringBuilder.ToString();
			ierror = 0;
		}

		public void UpdateWizardData()
		{
		}
	}
}
