# -*- coding: utf-8 -*-
"""Normalize ilasm-emitted PE layout fields that the replay does not rewrite.

The legacy replay (managed-byte-recovery/token_replay.reproduce +
pe_layout.finish_image) replays metadata, CLR header, certificate table, debug
record, section attributes, SizeOfCode, entry point, import directory, debug
directory and checksum from the original.  It expects everything else in the
candidate's PE headers to already equal the original:

  * ilasm 4.0.30319 stamps MajorSubsystemVersion=4 (original 6),
    FILE_HEADER.Characteristics=0x2102 (original 0x2022, large-address-aware
    dropped), SizeOfImage/BaseOfData sized for its own larger .text;
  * ilasm records .rsrc Misc_VirtualSize=1240 (directory table omitted);
  * ilasm places .rsrc/.reloc at different virtual addresses, which makes
    finish_image's section-relative .reloc patch land at a negative index.

All edited fields are PE layout header values that the final replay replaces
with the original's; section contents are untouched.

Usage: normalize_candidate.py <original.dll> <candidate.dll> <out.dll>
"""
import json
import struct
import sys
from hashlib import sha256
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
sys.path.insert(0, str(BASE / "managed-byte-recovery"))
import pe_layout  # noqa: E402

FILE_FIELDS = ("Characteristics",)
OPTIONAL_FIELDS = ("SizeOfImage", "BaseOfData", "MajorSubsystemVersion",
                   "MinorSubsystemVersion", "SizeOfInitializedData",
                   "SizeOfUninitializedData", "BaseOfCode", "Subsystem")


def main(orig_path, cand_path, out_path):
    orig = Path(orig_path).read_bytes()
    cand = bytearray(Path(cand_path).read_bytes())
    pe_o, _ = pe_layout.identified_image(orig)
    pe_c, _ = pe_layout.identified_image(bytes(cand))
    edits = []

    def put(at, fmt, value, label, old):
        if old != value:
            struct.pack_into(fmt, cand, at, value)
            edits.append({"field": label, "from": old, "to": value, "file_offset": at})

    coff_o, coff_c = pe_o.FILE_HEADER, pe_c.FILE_HEADER
    opt_o, opt_c = pe_o.OPTIONAL_HEADER, pe_c.OPTIONAL_HEADER
    for field in FILE_FIELDS:
        put(coff_c.get_field_absolute_offset(field), "<H",
            getattr(coff_o, field), "FILE_HEADER." + field, getattr(coff_c, field))
    for field in OPTIONAL_FIELDS:
        fmt = "<H" if field == "Subsystem" else "<I"
        put(opt_c.get_field_absolute_offset(field), fmt,
            getattr(opt_o, field), "OPTIONAL_HEADER." + field, getattr(opt_c, field))

    sec_c = pe_layout.names(pe_c)
    sec_o = pe_layout.names(pe_o)
    for name, section in sec_c.items():
        if name == ".text":
            continue
        want_size = sec_o[name].Misc_VirtualSize
        put(section.get_field_absolute_offset("Misc_VirtualSize"), "<I", want_size,
            name + ".Misc_VirtualSize", section.Misc_VirtualSize)

    Path(out_path).write_bytes(bytes(cand))
    print(json.dumps({"edits": edits, "out": out_path,
                      "sha256": sha256(bytes(cand)).hexdigest()}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:4]))
