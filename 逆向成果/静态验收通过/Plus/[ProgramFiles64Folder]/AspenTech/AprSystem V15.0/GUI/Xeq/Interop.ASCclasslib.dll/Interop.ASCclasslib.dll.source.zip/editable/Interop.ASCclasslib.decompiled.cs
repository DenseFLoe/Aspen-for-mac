using System;
using System.Collections;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Threading;

[assembly: Guid("00400002-DB36-42E7-B6C4-C035DD463707")]
[assembly: ImportedFromTypeLib("ASCClassLib400")]
[assembly: TypeLibVersion(40, 0)]
[assembly: AssemblyVersion("40.0.0.0")]
namespace AspenTech.AspenPlus.ASCclasslib;

[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400001-F704-49A8-9694-22DA620B8282")]
public interface IASCObject
{
	[DispId(1610743809)]
	IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[Guid("00400003-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCSimulation : IASCObject
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	string BuildVersion
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809346)]
	ASCBlock Flowsheet
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809347)]
	ASCSolverCollection Solvers
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	void PushScope([In][MarshalAs(UnmanagedType.BStr)] string pbScope);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	void PopScope();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	void ResetScope();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	void Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	void SolveWithObjective([In][MarshalAs(UnmanagedType.BStr)] string bObjective);

	[DispId(1610809353)]
	string DefaultObjective
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809360)]
	void TriggerCancel([In] short level);
}
[ComImport]
[Guid("00400047-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCSimulation2 : IASCSimulation
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	new string BuildVersion
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809346)]
	new ASCBlock Flowsheet
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809347)]
	new ASCSolverCollection Solvers
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	new void PushScope([In][MarshalAs(UnmanagedType.BStr)] string pbScope);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	new void PopScope();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	new void ResetScope();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	new void Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	new void SolveWithObjective([In][MarshalAs(UnmanagedType.BStr)] string bObjective);

	[DispId(1610809353)]
	new string DefaultObjective
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809360)]
	new void TriggerCancel([In] short level);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809361)]
	void SaveSimulation([In][MarshalAs(UnmanagedType.BStr)] string bFilePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809362)]
	void OpenSimulation([In][MarshalAs(UnmanagedType.BStr)] string bFilePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809363)]
	void AddSimulation([In][MarshalAs(UnmanagedType.BStr)] string bFilePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809364)]
	void SaveBlock([In][MarshalAs(UnmanagedType.BStr)] string bFilePath, [In][MarshalAs(UnmanagedType.BStr)] string bBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809365)]
	void LoadBlock([In][MarshalAs(UnmanagedType.BStr)] string bFilePath);
}
[ComImport]
[CoClass(typeof(ASCSimulationClass))]
[Guid("00400047-F704-49A8-9694-22DA620B8282")]
public interface ASCSimulation : IASCSimulation2
{
}
[ComImport]
[Guid("00400001-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCSimulationClass
{
	[DispId(1610743809)]
	public virtual extern IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern string BuildVersion
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809346)]
	public virtual extern ASCBlock Flowsheet
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809347)]
	public virtual extern ASCSolverCollection Solvers
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809353)]
	public virtual extern string DefaultObjective
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	public virtual extern void PushScope([In][MarshalAs(UnmanagedType.BStr)] string pbScope);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	public virtual extern void PopScope();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	public virtual extern void ResetScope();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	public virtual extern void Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	public virtual extern void SolveWithObjective([In][MarshalAs(UnmanagedType.BStr)] string bObjective);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809360)]
	public virtual extern void TriggerCancel([In] short level);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809361)]
	public virtual extern void SaveSimulation([In][MarshalAs(UnmanagedType.BStr)] string bFilePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809362)]
	public virtual extern void OpenSimulation([In][MarshalAs(UnmanagedType.BStr)] string bFilePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809363)]
	public virtual extern void AddSimulation([In][MarshalAs(UnmanagedType.BStr)] string bFilePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809364)]
	public virtual extern void SaveBlock([In][MarshalAs(UnmanagedType.BStr)] string bFilePath, [In][MarshalAs(UnmanagedType.BStr)] string bBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809365)]
	public virtual extern void LoadBlock([In][MarshalAs(UnmanagedType.BStr)] string bFilePath);
}
[ComImport]
[Guid("00400004-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCBlock : IASCObject
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	bool IsBlockContainer
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
	}

	[DispId(1610809346)]
	ASCBlockCollection Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809347)]
	ASCVariableCollection Variables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809348)]
	ASCEquationCollection Equations
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809349)]
	ASCParameterCollection Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809350)]
	ASCPortCollection Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[CoClass(typeof(ASCBlockClass))]
[Guid("00400004-F704-49A8-9694-22DA620B8282")]
public interface ASCBlock : IASCBlock
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400002-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCBlockClass
{
	[DispId(1610743809)]
	public virtual extern IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern bool IsBlockContainer
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
	}

	[DispId(1610809346)]
	public virtual extern ASCBlockCollection Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809347)]
	public virtual extern ASCVariableCollection Variables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809348)]
	public virtual extern ASCEquationCollection Equations
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809349)]
	public virtual extern ASCParameterCollection Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809350)]
	public virtual extern ASCPortCollection Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[Guid("00400002-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCObjectCollection : IEnumerable
{
	[DispId(0)]
	IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743811)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);
}
[ComImport]
[Guid("00400005-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCBlockCollection : IASCObjectCollection
{
	[DispId(0)]
	new IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743811)]
	new int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	new IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	new object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[DispId(1610809345)]
	ASCBlock Block
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[Guid("00400005-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCBlockCollectionClass))]
public interface ASCBlockCollection : IASCBlockCollection
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400008-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCBlockCollectionClass
{
	[DispId(0)]
	public virtual extern IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern ASCBlock Block
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);
}
[ComImport]
[Guid("00400006-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCVariable : IASCObject
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	double Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		set;
	}

	[DispId(1610809346)]
	double LowerBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[param: In]
		set;
	}

	[DispId(1610809347)]
	double UpperBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[param: In]
		set;
	}

	[DispId(1610809348)]
	ASCSpec Spec
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[param: In]
		set;
	}

	[DispId(1610809349)]
	double Scale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[param: In]
		set;
	}

	[DispId(1610809350)]
	double SBWeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[param: In]
		set;
	}

	[DispId(1610809351)]
	double ShadowPrice
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		[param: In]
		set;
	}

	[DispId(1610809352)]
	bool Marked
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[param: In]
		set;
	}

	[DispId(1610809353)]
	bool Modified
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[param: In]
		set;
	}

	[DispId(1610809354)]
	ASCActiveBound ActiveBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809354)]
		get;
	}

	[DispId(1610809355)]
	ASCVarQuality Quality
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		[param: In]
		set;
	}

	[DispId(1610809356)]
	string UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610809357)]
	double Initial
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		[param: In]
		set;
	}

	[DispId(1610809358)]
	double Change
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		[param: In]
		set;
	}

	[DispId(1610809359)]
	int Number
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809359)]
		get;
	}

	[DispId(1610809360)]
	ASCVarBoundType BoundType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		[param: In]
		set;
	}

	[DispId(1610809361)]
	double InternalScale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		[param: In]
		set;
	}

	[DispId(1610809362)]
	double Step
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		[param: In]
		set;
	}

	[DispId(1610809363)]
	string PhysicalType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809363)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809364)]
	object UOMList
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809364)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}
}
[ComImport]
[CoClass(typeof(ASCVariableClass))]
[Guid("00400006-F704-49A8-9694-22DA620B8282")]
public interface ASCVariable : IASCVariable
{
}
[ComImport]
[Guid("00400004-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCVariableClass
{
	[DispId(1610743809)]
	public virtual extern IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern double Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		set;
	}

	[DispId(1610809346)]
	public virtual extern double LowerBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[param: In]
		set;
	}

	[DispId(1610809347)]
	public virtual extern double UpperBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[param: In]
		set;
	}

	[DispId(1610809348)]
	public virtual extern ASCSpec Spec
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[param: In]
		set;
	}

	[DispId(1610809349)]
	public virtual extern double Scale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[param: In]
		set;
	}

	[DispId(1610809350)]
	public virtual extern double SBWeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[param: In]
		set;
	}

	[DispId(1610809351)]
	public virtual extern double ShadowPrice
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		[param: In]
		set;
	}

	[DispId(1610809352)]
	public virtual extern bool Marked
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[param: In]
		set;
	}

	[DispId(1610809353)]
	public virtual extern bool Modified
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[param: In]
		set;
	}

	[DispId(1610809354)]
	public virtual extern ASCActiveBound ActiveBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809354)]
		get;
	}

	[DispId(1610809355)]
	public virtual extern ASCVarQuality Quality
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		[param: In]
		set;
	}

	[DispId(1610809356)]
	public virtual extern string UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610809357)]
	public virtual extern double Initial
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		[param: In]
		set;
	}

	[DispId(1610809358)]
	public virtual extern double Change
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		[param: In]
		set;
	}

	[DispId(1610809359)]
	public virtual extern int Number
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809359)]
		get;
	}

	[DispId(1610809360)]
	public virtual extern ASCVarBoundType BoundType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		[param: In]
		set;
	}

	[DispId(1610809361)]
	public virtual extern double InternalScale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		[param: In]
		set;
	}

	[DispId(1610809362)]
	public virtual extern double Step
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		[param: In]
		set;
	}

	[DispId(1610809363)]
	public virtual extern string PhysicalType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809363)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809364)]
	public virtual extern object UOMList
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809364)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400007-F704-49A8-9694-22DA620B8282")]
public interface IASCVariableCollection : IASCObjectCollection
{
	[DispId(0)]
	new IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743811)]
	new int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	new IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	new object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[DispId(1610809345)]
	ASCVariable Variable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[CoClass(typeof(ASCVariableCollectionClass))]
[Guid("00400007-F704-49A8-9694-22DA620B8282")]
public interface ASCVariableCollection : IASCVariableCollection
{
}
[ComImport]
[Guid("00400009-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCVariableCollectionClass
{
	[DispId(0)]
	public virtual extern IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern ASCVariable Variable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400015-F704-49A8-9694-22DA620B8282")]
public interface IASCEquation : IASCObject
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[CoClass(typeof(ASCEquationClass))]
[Guid("00400015-F704-49A8-9694-22DA620B8282")]
public interface ASCEquation : IASCEquation
{
}
[ComImport]
[Guid("00400010-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCEquationClass
{
	[DispId(1610743809)]
	public virtual extern IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[Guid("00400016-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCEquationCollection : IASCObjectCollection
{
	[DispId(0)]
	new IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743811)]
	new int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	new IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	new object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[DispId(1610809345)]
	ASCEquation Equation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[Guid("00400016-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCEquationCollectionClass))]
public interface ASCEquationCollection : IASCEquationCollection
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400011-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCEquationCollectionClass
{
	[DispId(0)]
	public virtual extern IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern ASCEquation Equation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);
}
[ComImport]
[Guid("00400008-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCPort : IASCObject
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	ASCPortDir Direction
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
	}

	[DispId(1610809346)]
	ASCPortType Type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
	}

	[DispId(1610809347)]
	string Stream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[Guid("00400009-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCPort2 : IASCPort
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	new ASCPortDir Direction
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
	}

	[DispId(1610809346)]
	new ASCPortType Type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
	}

	[DispId(1610809347)]
	new string Stream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610874881)]
	ASCVariableCollection Variables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874881)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[CoClass(typeof(ASCPortClass))]
[Guid("00400009-F704-49A8-9694-22DA620B8282")]
public interface ASCPort : IASCPort2
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400003-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCPortClass
{
	[DispId(1610743809)]
	public virtual extern IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern ASCPortDir Direction
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
	}

	[DispId(1610809346)]
	public virtual extern ASCPortType Type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
	}

	[DispId(1610809347)]
	public virtual extern string Stream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610874881)]
	public virtual extern ASCVariableCollection Variables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874881)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[Guid("00400010-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCPortCollection : IASCObjectCollection
{
	[DispId(0)]
	new IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743811)]
	new int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	new IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	new object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[DispId(1610809345)]
	IASCPort Port
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[CoClass(typeof(ASCPortCollectionClass))]
[Guid("00400010-F704-49A8-9694-22DA620B8282")]
public interface ASCPortCollection : IASCPortCollection
{
}
[ComImport]
[Guid("00400013-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCPortCollectionClass
{
	[DispId(0)]
	public virtual extern IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern IASCPort Port
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);
}
[ComImport]
[Guid("00400018-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCSolver : IASCObject
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	ASCParameters Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[Guid("00400018-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCSolverClass))]
public interface ASCSolver : IASCSolver
{
}
[ComImport]
[Guid("00400005-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCSolverClass
{
	[DispId(1610743809)]
	public virtual extern IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern ASCParameters Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400019-F704-49A8-9694-22DA620B8282")]
public interface IASCSolverCollection : IASCObjectCollection
{
	[DispId(0)]
	new IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743811)]
	new int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	new IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	new object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[DispId(1610809345)]
	ASCSolver Solver
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[Guid("00400019-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCSolverCollectionClass))]
public interface ASCSolverCollection : IASCSolverCollection
{
}
[ComImport]
[Guid("00400015-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCSolverCollectionClass
{
	[DispId(0)]
	public virtual extern IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern ASCSolver Solver
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400011-F704-49A8-9694-22DA620B8282")]
public interface IASCParameters : IEnumerable
{
	[DispId(0)]
	object this[[In][MarshalAs(UnmanagedType.Struct)] object Index]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743811)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(1610743812)]
	string Description
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[CoClass(typeof(ASCParametersClass))]
[Guid("00400011-F704-49A8-9694-22DA620B8282")]
public interface ASCParameters : IASCParameters
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400014-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCParametersClass
{
	[DispId(0)]
	public virtual extern object this[[In][MarshalAs(UnmanagedType.Struct)] object Index]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern string Description
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400028-F704-49A8-9694-22DA620B8282")]
public interface IASCParameter : IASCObject
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	object Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610809346)]
	string UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809347)]
	ASCParameterAccess Access
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
	}

	[DispId(1610809348)]
	string Description
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400041-F704-49A8-9694-22DA620B8282")]
public interface IASCParameter2 : IASCParameter
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	new object Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610809346)]
	new string UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809347)]
	new ASCParameterAccess Access
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
	}

	[DispId(1610809348)]
	new string Description
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809349)]
	object Lower
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610809350)]
	object Upper
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400049-F704-49A8-9694-22DA620B8282")]
public interface IASCParameter3 : IASCParameter2
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	new object Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610809346)]
	new string UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809347)]
	new ASCParameterAccess Access
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
	}

	[DispId(1610809348)]
	new string Description
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809349)]
	new object Lower
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610809350)]
	new object Upper
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610809351)]
	string PhysicalType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809352)]
	object UOM_2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}
}
[ComImport]
[CoClass(typeof(ASCParameterClass))]
[Guid("00400049-F704-49A8-9694-22DA620B8282")]
public interface ASCParameter : IASCParameter3
{
}
[ComImport]
[Guid("00400026-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCParameterClass
{
	[DispId(1610743809)]
	public virtual extern IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern object Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610809346)]
	public virtual extern string UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809347)]
	public virtual extern ASCParameterAccess Access
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
	}

	[DispId(1610809348)]
	public virtual extern string Description
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809349)]
	public virtual extern object Lower
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610809350)]
	public virtual extern object Upper
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610809351)]
	public virtual extern string PhysicalType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809352)]
	public virtual extern object ASCParameter_UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[Guid("00400029-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCParameterCollection : IASCObjectCollection
{
	[DispId(0)]
	new IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743811)]
	new int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	new IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	new object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[DispId(1610809345)]
	IASCParameter Parameter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[Guid("00400029-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCParameterCollectionClass))]
public interface ASCParameterCollection : IASCParameterCollection
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400027-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCParameterCollectionClass
{
	[DispId(0)]
	public virtual extern IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern IASCParameter Parameter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);
}
[ComImport]
[Guid("00400012-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IEBScriptService
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void Execute([In][MarshalAs(UnmanagedType.BStr)] string bCommand);
}
[ComImport]
[Guid("00400012-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(EBScriptServiceClass))]
public interface EBScriptService : IEBScriptService
{
}
[ComImport]
[Guid("00400006-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class EBScriptServiceClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void Execute([In][MarshalAs(UnmanagedType.BStr)] string bCommand);
}
[ComImport]
[Guid("00400020-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCEditBlock
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void AddBlock([In][MarshalAs(UnmanagedType.BStr)] string BlockName, [In][MarshalAs(UnmanagedType.BStr)] string BlockType, [In][MarshalAs(UnmanagedType.Struct)] object Args);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void RemoveBlock([In][MarshalAs(UnmanagedType.BStr)] string BlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void RemoveAllBlocks();
}
[ComImport]
[Guid("00400020-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCEditBlockClass))]
public interface ASCEditBlock : IASCEditBlock
{
}
[ComImport]
[Guid("00400017-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCEditBlockClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void AddBlock([In][MarshalAs(UnmanagedType.BStr)] string BlockName, [In][MarshalAs(UnmanagedType.BStr)] string BlockType, [In][MarshalAs(UnmanagedType.Struct)] object Args);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void RemoveBlock([In][MarshalAs(UnmanagedType.BStr)] string BlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	public virtual extern void RemoveAllBlocks();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400021-F704-49A8-9694-22DA620B8282")]
public interface IASCEditLibraries
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void AddLibrary([In][MarshalAs(UnmanagedType.BStr)] string LibraryName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void RemoveLibrary([In][MarshalAs(UnmanagedType.BStr)] string LibraryName);
}
[ComImport]
[Guid("00400021-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCEditLibrariesClass))]
public interface ASCEditLibraries : IASCEditLibraries
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400018-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCEditLibrariesClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void AddLibrary([In][MarshalAs(UnmanagedType.BStr)] string LibraryName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void RemoveLibrary([In][MarshalAs(UnmanagedType.BStr)] string LibraryName);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400013-F704-49A8-9694-22DA620B8282")]
public interface IASCSimulationMsgs
{
	[DispId(1610743809)]
	int BufferSize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		set;
	}

	[DispId(1610743810)]
	int LineCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}

	[DispId(1610743811)]
	string[] GetLines
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void ClearBuffer();

	[DispId(1610743813)]
	string OutputFile
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDispatchable)]
[InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
[Guid("00400014-F704-49A8-9694-22DA620B8282")]
public interface DASCSimulationMsgsEvents
{
	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void OnNewLine([In][MarshalAs(UnmanagedType.BStr)] string bText);
}
[ComEventInterface(typeof(DASCSimulationMsgsEvents), typeof(DASCSimulationMsgsEvents_EventProvider))]
[ComVisible(false)]
[TypeLibType(TypeLibTypeFlags.FHidden)]
public interface DASCSimulationMsgsEvents_Event
{
	event DASCSimulationMsgsEvents_OnNewLineEventHandler OnNewLine;
}
[ComImport]
[CoClass(typeof(ASCSimulationMsgsClass))]
[Guid("00400013-F704-49A8-9694-22DA620B8282")]
public interface ASCSimulationMsgs : IASCSimulationMsgs, DASCSimulationMsgsEvents_Event
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400051-F704-49A8-9694-22DA620B8282")]
public interface IASCSimulationMsgs2 : IASCSimulationMsgs
{
	[DispId(1610743809)]
	new int BufferSize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		set;
	}

	[DispId(1610743810)]
	new int LineCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}

	[DispId(1610743811)]
	new string[] GetLines
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	new void ClearBuffer();

	[DispId(1610743813)]
	new string OutputFile
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void UpdateProfiles([In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] nameArray, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] object[] valArray, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] object[] typeArray, [In] double time);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void ResetSimulation();
}
[ComImport]
[Guid("00400052-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDispatchable)]
[InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
public interface DASCSimulationMsgsEvents2
{
	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void OnNewLine([In][MarshalAs(UnmanagedType.BStr)] string bText);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void UpdateProfiles([In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] nameArray, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] object[] valArray, double time);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void ResetSimulation();
}
[ComEventInterface(typeof(DASCSimulationMsgsEvents2), typeof(DASCSimulationMsgsEvents2_EventProvider))]
[TypeLibType(TypeLibTypeFlags.FHidden)]
[ComVisible(false)]
public interface DASCSimulationMsgsEvents2_Event
{
	event DASCSimulationMsgsEvents2_OnNewLineEventHandler OnNewLine;

	event DASCSimulationMsgsEvents2_UpdateProfilesEventHandler UpdateProfiles;

	event DASCSimulationMsgsEvents2_ResetSimulationEventHandler ResetSimulation;
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[ComSourceInterfaces("AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents\0AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2\0\0")]
[Guid("00400007-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCSimulationMsgsClass
{
	[DispId(1610743809)]
	public virtual extern int BufferSize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		set;
	}

	[DispId(1610743810)]
	public virtual extern int LineCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern string[] GetLines
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)]
		get;
	}

	[DispId(1610743813)]
	public virtual extern string OutputFile
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	public virtual extern int IASCSimulationMsgs2_BufferSize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern int IASCSimulationMsgs2_LineCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern string[] IASCSimulationMsgs2_GetLines
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)]
		get;
	}

	public virtual extern string IASCSimulationMsgs2_OutputFile
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	public virtual extern event DASCSimulationMsgsEvents_OnNewLineEventHandler OnNewLine;

	public virtual extern event DASCSimulationMsgsEvents2_OnNewLineEventHandler DASCSimulationMsgsEvents2_Event_OnNewLine;

	public virtual extern event DASCSimulationMsgsEvents2_UpdateProfilesEventHandler DASCSimulationMsgsEvents2_Event_UpdateProfiles;

	public virtual extern event DASCSimulationMsgsEvents2_ResetSimulationEventHandler DASCSimulationMsgsEvents2_Event_ResetSimulation;

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	public virtual extern void ClearBuffer();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IASCSimulationMsgs2_ClearBuffer();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void UpdateProfiles([In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] nameArray, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] object[] valArray, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] object[] typeArray, [In] double time);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void ResetSimulation();
}
[ComImport]
[Guid("00400017-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCGridService : IASCObjectCollection
{
	[DispId(0)]
	new IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743811)]
	new int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	new IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	new object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809345)]
	void SetSortKeys([In][MarshalAs(UnmanagedType.Struct)] object SortKeys, [In][MarshalAs(UnmanagedType.Struct)] object SortOrder);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809346)]
	void SetQueryStrings([In][MarshalAs(UnmanagedType.Struct)] object QueryStrings);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809347)]
	void SetGridColumns([In][MarshalAs(UnmanagedType.Struct)] object ColumnAttributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	void Prepare();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	void Sort();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	void SetAttr([In][MarshalAs(UnmanagedType.BStr)] string AttrName, [In][MarshalAs(UnmanagedType.Struct)] object Value, [In] int iRowNum);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	void GetIndexPositions([In][MarshalAs(UnmanagedType.Struct)] object Indices, [MarshalAs(UnmanagedType.Struct)] out object Positions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	void GetPositionIndices([In][MarshalAs(UnmanagedType.Struct)] object Positions, [MarshalAs(UnmanagedType.Struct)] out object Indices);
}
[ComImport]
[CoClass(typeof(ASCVariableGridClass))]
[Guid("00400017-F704-49A8-9694-22DA620B8282")]
public interface ASCVariableGrid : IASCGridService
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400012-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCVariableGridClass
{
	[DispId(0)]
	public virtual extern IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809345)]
	public virtual extern void SetSortKeys([In][MarshalAs(UnmanagedType.Struct)] object SortKeys, [In][MarshalAs(UnmanagedType.Struct)] object SortOrder);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809346)]
	public virtual extern void SetQueryStrings([In][MarshalAs(UnmanagedType.Struct)] object QueryStrings);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809347)]
	public virtual extern void SetGridColumns([In][MarshalAs(UnmanagedType.Struct)] object ColumnAttributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	public virtual extern void Prepare();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	public virtual extern void Sort();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	public virtual extern void SetAttr([In][MarshalAs(UnmanagedType.BStr)] string AttrName, [In][MarshalAs(UnmanagedType.Struct)] object Value, [In] int iRowNum);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	public virtual extern void GetIndexPositions([In][MarshalAs(UnmanagedType.Struct)] object Indices, [MarshalAs(UnmanagedType.Struct)] out object Positions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	public virtual extern void GetPositionIndices([In][MarshalAs(UnmanagedType.Struct)] object Positions, [MarshalAs(UnmanagedType.Struct)] out object Indices);
}
[ComImport]
[CoClass(typeof(ASCEquationGridClass))]
[Guid("00400017-F704-49A8-9694-22DA620B8282")]
public interface ASCEquationGrid : IASCGridService
{
}
[ComImport]
[Guid("00400016-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCEquationGridClass
{
	[DispId(0)]
	public virtual extern IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809345)]
	public virtual extern void SetSortKeys([In][MarshalAs(UnmanagedType.Struct)] object SortKeys, [In][MarshalAs(UnmanagedType.Struct)] object SortOrder);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809346)]
	public virtual extern void SetQueryStrings([In][MarshalAs(UnmanagedType.Struct)] object QueryStrings);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809347)]
	public virtual extern void SetGridColumns([In][MarshalAs(UnmanagedType.Struct)] object ColumnAttributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	public virtual extern void Prepare();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	public virtual extern void Sort();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	public virtual extern void SetAttr([In][MarshalAs(UnmanagedType.BStr)] string AttrName, [In][MarshalAs(UnmanagedType.Struct)] object Value, [In] int iRowNum);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	public virtual extern void GetIndexPositions([In][MarshalAs(UnmanagedType.Struct)] object Indices, [MarshalAs(UnmanagedType.Struct)] out object Positions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	public virtual extern void GetPositionIndices([In][MarshalAs(UnmanagedType.Struct)] object Positions, [MarshalAs(UnmanagedType.Struct)] out object Indices);
}
[ComImport]
[Guid("00400022-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCSensitivity
{
	[DispId(1610743809)]
	object DependentVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743810)]
	int NumDependentVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}

	[DispId(1610743811)]
	object IndependentVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743812)]
	int NumIndependentVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610743813)]
	string Objective
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object Calculate([In][Out][MarshalAs(UnmanagedType.Struct)] ref object pDifferentiable);
}
[ComImport]
[CoClass(typeof(ASCSensitivityClass))]
[Guid("00400022-F704-49A8-9694-22DA620B8282")]
public interface ASCSensitivity : IASCSensitivity
{
}
[ComImport]
[Guid("00400019-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCSensitivityClass
{
	[DispId(1610743809)]
	public virtual extern object DependentVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743810)]
	public virtual extern int NumDependentVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern object IndependentVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743812)]
	public virtual extern int NumIndependentVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610743813)]
	public virtual extern string Objective
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object Calculate([In][Out][MarshalAs(UnmanagedType.Struct)] ref object pDifferentiable);
}
[ComImport]
[Guid("00400023-F704-49A8-9694-22DA620B8282")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[TypeLibType(TypeLibTypeFlags.FOleAutomation)]
public interface IASCSimEventMgr
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int Advise([In] int lEventFilter, [In][MarshalAs(UnmanagedType.Interface)] IASCSimEventSink pSink);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void UnAdvise([In] int lAdviseId);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	ASCSimEventLock BlockEvents([In] int lEventFilter, [In] int lAdviseId);
}
[ComImport]
[Guid("00400023-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCSimEventMgrClass))]
public interface ASCSimEventMgr : IASCSimEventMgr
{
}
[ComImport]
[Guid("00400020-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCSimEventMgrClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int Advise([In] int lEventFilter, [In][MarshalAs(UnmanagedType.Interface)] IASCSimEventSink pSink);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void UnAdvise([In] int lAdviseId);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern ASCSimEventLock BlockEvents([In] int lEventFilter, [In] int lAdviseId);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FOleAutomation)]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("00400025-F704-49A8-9694-22DA620B8282")]
public interface IASCSimEventLock
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FlushEvents();
}
[ComImport]
[Guid("00400025-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCSimEventLockClass))]
public interface ASCSimEventLock : IASCSimEventLock
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("00400021-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCSimEventLockClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void FlushEvents();
}
[ComImport]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("00400026-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FOleAutomation)]
public interface IASCInterfaceHolder
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Register([In][MarshalAs(UnmanagedType.BStr)] string ident, [In][MarshalAs(UnmanagedType.IUnknown)] object pInterface);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Unregister([In][MarshalAs(UnmanagedType.BStr)] string ident);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetInterface([In][MarshalAs(UnmanagedType.BStr)] string ident, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
}
[ComImport]
[CoClass(typeof(ASCInterfaceHolderClass))]
[Guid("00400026-F704-49A8-9694-22DA620B8282")]
public interface ASCInterfaceHolder : IASCInterfaceHolder
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("00400022-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCInterfaceHolderClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Register([In][MarshalAs(UnmanagedType.BStr)] string ident, [In][MarshalAs(UnmanagedType.IUnknown)] object pInterface);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Unregister([In][MarshalAs(UnmanagedType.BStr)] string ident);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetInterface([In][MarshalAs(UnmanagedType.BStr)] string ident, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400027-F704-49A8-9694-22DA620B8282")]
public interface IASCExternalFileService
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void QueryContents([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] ASCExternalFileType file_type, out int var_attributes, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] out string[] pbBlockIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void Import([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] ASCExternalFileType file_type, [In] int var_attributes, [In][MarshalAs(UnmanagedType.BStr)] string blockid, [In][MarshalAs(UnmanagedType.BStr)] string match, [In][MarshalAs(UnmanagedType.BStr)] string substitute, [In] bool usescope);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void Export([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] ASCExternalFileType file_type, [In] int var_attributes, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] bBlockIDs);
}
[ComImport]
[CoClass(typeof(ASCExternalFileServiceClass))]
[Guid("00400027-F704-49A8-9694-22DA620B8282")]
public interface ASCExternalFileService : IASCExternalFileService
{
}
[ComImport]
[Guid("00400023-087A-4DD9-B6F3-A99D7CBA1039")]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[ClassInterface(ClassInterfaceType.None)]
public class ASCExternalFileServiceClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void QueryContents([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] ASCExternalFileType file_type, out int var_attributes, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] out string[] pbBlockIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void Import([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] ASCExternalFileType file_type, [In] int var_attributes, [In][MarshalAs(UnmanagedType.BStr)] string blockid, [In][MarshalAs(UnmanagedType.BStr)] string match, [In][MarshalAs(UnmanagedType.BStr)] string substitute, [In] bool usescope);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	public virtual extern void Export([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] ASCExternalFileType file_type, [In] int var_attributes, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] bBlockIDs);
}
[ComImport]
[Guid("00400017-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCPortGridClass))]
public interface ASCPortGrid : IASCGridService
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400024-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCPortGridClass
{
	[DispId(0)]
	public virtual extern IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809345)]
	public virtual extern void SetSortKeys([In][MarshalAs(UnmanagedType.Struct)] object SortKeys, [In][MarshalAs(UnmanagedType.Struct)] object SortOrder);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809346)]
	public virtual extern void SetQueryStrings([In][MarshalAs(UnmanagedType.Struct)] object QueryStrings);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809347)]
	public virtual extern void SetGridColumns([In][MarshalAs(UnmanagedType.Struct)] object ColumnAttributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	public virtual extern void Prepare();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	public virtual extern void Sort();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	public virtual extern void SetAttr([In][MarshalAs(UnmanagedType.BStr)] string AttrName, [In][MarshalAs(UnmanagedType.Struct)] object Value, [In] int iRowNum);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	public virtual extern void GetIndexPositions([In][MarshalAs(UnmanagedType.Struct)] object Indices, [MarshalAs(UnmanagedType.Struct)] out object Positions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	public virtual extern void GetPositionIndices([In][MarshalAs(UnmanagedType.Struct)] object Positions, [MarshalAs(UnmanagedType.Struct)] out object Indices);
}
[ComImport]
[Guid("00400017-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCParameterGridClass))]
public interface ASCParameterGrid : IASCGridService
{
}
[ComImport]
[Guid("00400025-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCParameterGridClass
{
	[DispId(0)]
	public virtual extern IASCObject this[[In] int lIndex]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IASCObject Find([In][MarshalAs(UnmanagedType.BStr)] string bName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In] int iFirst = 1, [In] int lCount = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetAttributes([In][MarshalAs(UnmanagedType.Struct)] object ObjectAttributes, [In][MarshalAs(UnmanagedType.Struct)] object AttribValues, [In] int iFirst = 1);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809345)]
	public virtual extern void SetSortKeys([In][MarshalAs(UnmanagedType.Struct)] object SortKeys, [In][MarshalAs(UnmanagedType.Struct)] object SortOrder);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809346)]
	public virtual extern void SetQueryStrings([In][MarshalAs(UnmanagedType.Struct)] object QueryStrings);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809347)]
	public virtual extern void SetGridColumns([In][MarshalAs(UnmanagedType.Struct)] object ColumnAttributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	public virtual extern void Prepare();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	public virtual extern void Sort();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	public virtual extern void SetAttr([In][MarshalAs(UnmanagedType.BStr)] string AttrName, [In][MarshalAs(UnmanagedType.Struct)] object Value, [In] int iRowNum);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	public virtual extern void GetIndexPositions([In][MarshalAs(UnmanagedType.Struct)] object Indices, [MarshalAs(UnmanagedType.Struct)] out object Positions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	public virtual extern void GetPositionIndices([In][MarshalAs(UnmanagedType.Struct)] object Positions, [MarshalAs(UnmanagedType.Struct)] out object Indices);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400030-F704-49A8-9694-22DA620B8282")]
public interface IASCGridInfo
{
	[DispId(1610809345)]
	int ColHeaderHeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
	}

	[DispId(1610809346)]
	int RowHeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
	}

	[DispId(1610809347)]
	int FrozenCols
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
	}

	[DispId(1610809348)]
	int FrozenRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
	}

	[DispId(1610809349)]
	ASCGridColumnCollection Columns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809350)]
	ASCGridStyleCollection ControlStyles
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809351)]
	int ColCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
	}

	[DispId(1610809352)]
	int PrimaryCol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		get;
	}

	[DispId(100675593)]
	bool ShowRowHdr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(100675593)]
		get;
	}

	[DispId(1610809360)]
	bool AllowQueries
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		get;
	}

	[DispId(1610809361)]
	string HelpFile
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809362)]
	int Mode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		[param: In]
		set;
	}

	[DispId(1610809363)]
	object PreSortedCols
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809363)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}
}
[ComImport]
[Guid("00400030-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCGridInfoClass))]
public interface ASCGridInfo : IASCGridInfo
{
}
[ComImport]
[Guid("00400028-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCGridInfoClass
{
	[DispId(1610809345)]
	public virtual extern int ColHeaderHeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
	}

	[DispId(1610809346)]
	public virtual extern int RowHeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
	}

	[DispId(1610809347)]
	public virtual extern int FrozenCols
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
	}

	[DispId(1610809348)]
	public virtual extern int FrozenRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
	}

	[DispId(1610809349)]
	public virtual extern ASCGridColumnCollection Columns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809350)]
	public virtual extern ASCGridStyleCollection ControlStyles
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809351)]
	public virtual extern int ColCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
	}

	[DispId(1610809352)]
	public virtual extern int PrimaryCol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		get;
	}

	[DispId(100675593)]
	public virtual extern bool ShowRowHdr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(100675593)]
		get;
	}

	[DispId(1610809360)]
	public virtual extern bool AllowQueries
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		get;
	}

	[DispId(1610809361)]
	public virtual extern string HelpFile
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809362)]
	public virtual extern int Mode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		[param: In]
		set;
	}

	[DispId(1610809363)]
	public virtual extern object PreSortedCols
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809363)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400031-F704-49A8-9694-22DA620B8282")]
public interface IASCGridVarInfo
{
	[DispId(1610809344)]
	string EngineName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809344)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809345)]
	string DisplayName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809346)]
	uint ColumnWidth
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
	}

	[DispId(1610809347)]
	bool Visible
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
	}

	[DispId(1610809348)]
	bool ReadOnly
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
	}

	[DispId(1610809349)]
	bool Resize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	bool CanQuery();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	int get_DefaultControlStyle();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	[return: ComAliasName("AspenTech.AspenPlus.ASCclasslib.ASCControlType")]
	ASCControlType get_DefaultControlType();

	[DispId(1610809353)]
	uint ModMask
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		get;
	}
}
[ComImport]
[Guid("00400031-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCGridVarInfoClass))]
public interface ASCGridVarInfo : IASCGridVarInfo
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400029-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCGridVarInfoClass
{
	[DispId(1610809344)]
	public virtual extern string EngineName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809344)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809345)]
	public virtual extern string DisplayName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809346)]
	public virtual extern uint ColumnWidth
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
	}

	[DispId(1610809347)]
	public virtual extern bool Visible
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
	}

	[DispId(1610809348)]
	public virtual extern bool ReadOnly
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
	}

	[DispId(1610809349)]
	public virtual extern bool Resize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		get;
	}

	[DispId(1610809353)]
	public virtual extern uint ModMask
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	public virtual extern bool CanQuery();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	public virtual extern int get_DefaultControlStyle();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	[return: ComAliasName("AspenTech.AspenPlus.ASCclasslib.ASCControlType")]
	public virtual extern ASCControlType get_DefaultControlType();
}
[ComImport]
[Guid("00400032-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCGridStaticControl
{
	[DispId(1610809345)]
	string DefaultValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[CoClass(typeof(ASCGridStaticControlClass))]
[Guid("00400032-F704-49A8-9694-22DA620B8282")]
public interface ASCGridStaticControl : IASCGridStaticControl
{
}
[ComImport]
[Guid("00400030-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCGridStaticControlClass
{
	[DispId(1610809345)]
	public virtual extern string DefaultValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[Guid("00400033-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCGridTextBoxControl
{
	[DispId(1610809345)]
	object DefaultValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809346)]
	uint MaxSize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
	}

	[DispId(1610809347)]
	object VarType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	bool UseFormat();

	[DispId(1610809350)]
	object FormatType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809351)]
	int NumPlaces
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
	}

	[DispId(1610809352)]
	string MaskInc
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[CoClass(typeof(ASCGridTextBoxControlClass))]
[Guid("00400033-F704-49A8-9694-22DA620B8282")]
public interface ASCGridTextBoxControl : IASCGridTextBoxControl
{
}
[ComImport]
[Guid("00400031-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCGridTextBoxControlClass
{
	[DispId(1610809345)]
	public virtual extern object DefaultValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809346)]
	public virtual extern uint MaxSize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
	}

	[DispId(1610809347)]
	public virtual extern object VarType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809350)]
	public virtual extern object FormatType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809351)]
	public virtual extern int NumPlaces
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
	}

	[DispId(1610809352)]
	public virtual extern string MaskInc
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	public virtual extern bool UseFormat();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400034-F704-49A8-9694-22DA620B8282")]
public interface IASCGridCheckBoxControl
{
	[ComAliasName("AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState")]
	[DispId(1610809345)]
	ASCCheckBoxState DefaultState
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: ComAliasName("AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState")]
		get;
	}

	[DispId(1610809346)]
	object Type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809347)]
	object Checked
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809348)]
	object UnChecked
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809349)]
	string CheckDisplay
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809350)]
	string UnCheckedDisplay
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[Guid("00400034-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCGridCheckBoxControlClass))]
public interface ASCGridCheckBoxControl : IASCGridCheckBoxControl
{
}
[ComImport]
[Guid("00400032-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCGridCheckBoxControlClass
{
	[ComAliasName("AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState")]
	[DispId(1610809345)]
	public virtual extern ASCCheckBoxState DefaultState
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: ComAliasName("AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState")]
		get;
	}

	[DispId(1610809346)]
	public virtual extern object Type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809347)]
	public virtual extern object Checked
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809348)]
	public virtual extern object UnChecked
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809349)]
	public virtual extern string CheckDisplay
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809350)]
	public virtual extern string UnCheckedDisplay
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[Guid("00400035-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCGridComboBoxControl
{
	[DispId(1610809345)]
	object DefaultValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809346)]
	object Type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809347)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object Item([In] ref int Index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	int Count();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object GetEnum();
}
[ComImport]
[CoClass(typeof(ASCGridComboBoxControlClass))]
[Guid("00400035-F704-49A8-9694-22DA620B8282")]
public interface ASCGridComboBoxControl : IASCGridComboBoxControl
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400033-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCGridComboBoxControlClass
{
	[DispId(1610809345)]
	public virtual extern object DefaultValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809346)]
	public virtual extern object Type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809347)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object Item([In] ref int Index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	public virtual extern int Count();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	public virtual extern object GetEnum();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400036-F704-49A8-9694-22DA620B8282")]
public interface IASCGridComboBoxItem
{
	[DispId(1610809345)]
	object Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809346)]
	string DisplayName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809347)]
	string QueryName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[CoClass(typeof(ASCGridComboBoxItemClass))]
[Guid("00400036-F704-49A8-9694-22DA620B8282")]
public interface ASCGridComboBoxItem : IASCGridComboBoxItem
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("00400034-087A-4DD9-B6F3-A99D7CBA1039")]
public class ASCGridComboBoxItemClass
{
	[DispId(1610809345)]
	public virtual extern object Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809346)]
	public virtual extern string DisplayName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809347)]
	public virtual extern string QueryName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[DefaultMember("Item")]
[Guid("00400037-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCGridColumnCollection : IEnumerable
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(0)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object Item([In][MarshalAs(UnmanagedType.Struct)] object vtVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	int Count();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();
}
[ComImport]
[Guid("00400037-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCGridColumnCollectionClass))]
public interface ASCGridColumnCollection : IASCGridColumnCollection
{
}
[ComImport]
[DefaultMember("Item")]
[Guid("00400035-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCGridColumnCollectionClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(0)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object Item([In][MarshalAs(UnmanagedType.Struct)] object vtVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	public virtual extern int Count();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[DefaultMember("Item")]
[Guid("00400038-F704-49A8-9694-22DA620B8282")]
public interface IASCGridStyleCollection : IEnumerable
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(0)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object Item([In] ref int pIndex, [ComAliasName("AspenTech.AspenPlus.ASCclasslib.ASCControlType")] out ASCControlType pType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	int Count();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();
}
[ComImport]
[Guid("00400038-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCGridStyleCollectionClass))]
public interface ASCGridStyleCollection : IASCGridStyleCollection
{
}
[ComImport]
[Guid("00400036-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
[DefaultMember("Item")]
public class ASCGridStyleCollectionClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(0)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object Item([In] ref int pIndex, [ComAliasName("AspenTech.AspenPlus.ASCclasslib.ASCControlType")] out ASCControlType pType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	public virtual extern int Count();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400044-F704-49A8-9694-22DA620B8282")]
public interface IASCDynamicsService
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string AddTasks([In][MarshalAs(UnmanagedType.BStr)] string xml);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void ActivateTask([In][MarshalAs(UnmanagedType.BStr)] string taskName, [In] bool active);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void RemoveTask([In][MarshalAs(UnmanagedType.BStr)] string taskName);
}
[ComImport]
[Guid("00400044-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(ASCDynamicsServiceClass))]
public interface ASCDynamicsService : IASCDynamicsService
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400053-F704-49A8-9694-22DA620B8282")]
public interface IASCDynamicsService2 : IASCDynamicsService
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.BStr)]
	new string AddTasks([In][MarshalAs(UnmanagedType.BStr)] string xml);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	new void ActivateTask([In][MarshalAs(UnmanagedType.BStr)] string taskName, [In] bool active);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	new void RemoveTask([In][MarshalAs(UnmanagedType.BStr)] string taskName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string AddTasks2([In][MarshalAs(UnmanagedType.BStr)] string xml, [In][MarshalAs(UnmanagedType.BStr)] string scope);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void ActivateTask2([In][MarshalAs(UnmanagedType.BStr)] string taskName, [In] bool active, [In][MarshalAs(UnmanagedType.BStr)] string scope);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void RemoveTask2([In][MarshalAs(UnmanagedType.BStr)] string taskName, [In][MarshalAs(UnmanagedType.BStr)] string scope);
}
[ComImport]
[Guid("00400037-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCDynamicsServiceClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.BStr)]
	public virtual extern string AddTasks([In][MarshalAs(UnmanagedType.BStr)] string xml);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	public virtual extern void ActivateTask([In][MarshalAs(UnmanagedType.BStr)] string taskName, [In] bool active);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	public virtual extern void RemoveTask([In][MarshalAs(UnmanagedType.BStr)] string taskName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.BStr)]
	public virtual extern string IASCDynamicsService2_AddTasks([In][MarshalAs(UnmanagedType.BStr)] string xml);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IASCDynamicsService2_ActivateTask([In][MarshalAs(UnmanagedType.BStr)] string taskName, [In] bool active);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IASCDynamicsService2_RemoveTask([In][MarshalAs(UnmanagedType.BStr)] string taskName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.BStr)]
	public virtual extern string AddTasks2([In][MarshalAs(UnmanagedType.BStr)] string xml, [In][MarshalAs(UnmanagedType.BStr)] string scope);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void ActivateTask2([In][MarshalAs(UnmanagedType.BStr)] string taskName, [In] bool active, [In][MarshalAs(UnmanagedType.BStr)] string scope);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void RemoveTask2([In][MarshalAs(UnmanagedType.BStr)] string taskName, [In][MarshalAs(UnmanagedType.BStr)] string scope);
}
[ComImport]
[Guid("00400045-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCVariableProfile
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object GetProfileByIndex([In] int varIndex, [In] double startTime, [In] double endTime, [In] double interval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object GetProfileByName([In][MarshalAs(UnmanagedType.BStr)] string varName, [In] double startTime, [In] double endTime, [In] double interval);
}
[ComImport]
[CoClass(typeof(ASCVariableProfileClass))]
[Guid("00400045-F704-49A8-9694-22DA620B8282")]
public interface ASCVariableProfile : IASCVariableProfile
{
}
[ComImport]
[Guid("00400038-087A-4DD9-B6F3-A99D7CBA1039")]
[ClassInterface(ClassInterfaceType.None)]
public class ASCVariableProfileClass
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetProfileByIndex([In] int varIndex, [In] double startTime, [In] double endTime, [In] double interval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object GetProfileByName([In][MarshalAs(UnmanagedType.BStr)] string varName, [In] double startTime, [In] double endTime, [In] double interval);
}
public enum ASCSpec
{
	ASCSpec_Calc,
	ASCSpec_Constant,
	ASCSpec_Indep,
	ASCSpec_Meas,
	ASCSpec_Param,
	ASCSpec_Optim,
	ASCSpec_Recon,
	ASCSpec_Initial
}
public enum ASCActiveBound
{
	ASCActiveBound_NotAtBounds,
	ASCActiveBound_StepLower,
	ASCActiveBound_StepUpper,
	ASCActiveBound_ExceededStepLower,
	ASCActiveBound_ExceededStepUpper,
	ASCActiveBound_Lower,
	ASCActiveBound_Upper,
	ASCActiveBound_ExceededLower,
	ASCActiveBound_ExceededUpper,
	ASCActiveBound_SoftLower,
	ASCActiveBound_SoftUpper,
	ASCActiveBound_ExceededSoftLower,
	ASCActiveBound_ExceededSoftUpper,
	ASCActiveBound_RelaxedLower,
	ASCActiveBound_RelaxedUpper,
	ASCActiveBound_ExceededRelaxedLower,
	ASCActiveBound_ExceededRelaxedUpper,
	ASCActiveBound_Pinched
}
public enum ASCVarQuality
{
	ASCVarQuality_Good,
	ASCVarQuality_Bad,
	ASCVarQuality_Override
}
public enum ASCVarBoundType
{
	ASCVarBoundType_Hard,
	ASCVarBoundType_Relaxed,
	ASCVarBoundType_Soft
}
public enum ASCPortDir
{
	ASCPortDir_Unspecified,
	ASCPortDir_Input,
	ASCPortDir_Output
}
public enum ASCPortType
{
	ASCPortType_Unspecified,
	ASCPortType_Material,
	ASCPortType_Information,
	ASCPortType_Special_Ordered_Set
}
public enum ASCParameterAccess
{
	ASCReadOnly,
	ASCReadWrite
}
[ComVisible(false)]
public delegate void DASCSimulationMsgsEvents_OnNewLineEventHandler([In][MarshalAs(UnmanagedType.BStr)] string bText);
[ComImport]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("00400024-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FOleAutomation)]
public interface IASCSimEventSink
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OnNewEvent([In] int lEventId, [In][MarshalAs(UnmanagedType.Struct)] object Hint1, [In][MarshalAs(UnmanagedType.Struct)] object Hint2);
}
public enum ASCExternalFileType
{
	ASCExternalFile_XFile,
	ASCExternalFile_VarFile,
	ASCExternalFile_FileExists
}
public enum ASCControlType
{
	ECT_STATIC,
	ECT_TEXT,
	ECT_CHECKBOX,
	ECT_COMBOBOX
}
public enum ASCCheckBoxState
{
	ECBD_UNSPECIFIED,
	ECBD_CHECKED,
	ECBD_UNCHECKED
}
public enum __MIDL___MIDL_itf_ascclasslib_0000_0000_0003
{
	ECT_STATIC,
	ECT_TEXT,
	ECT_CHECKBOX,
	ECT_COMBOBOX
}
public enum __MIDL___MIDL_itf_ascclasslib_0000_0000_0004
{
	ECBD_UNSPECIFIED,
	ECBD_CHECKED,
	ECBD_UNCHECKED
}
[ComImport]
[Guid("00400039-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCObjectCollectionHelper
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874881)]
	int Name2Index([In][MarshalAs(UnmanagedType.BStr)] string bName);
}
[ComImport]
[Guid("00400040-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCBlock2 : IASCBlock
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	new bool IsBlockContainer
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
	}

	[DispId(1610809346)]
	new ASCBlockCollection Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809347)]
	new ASCVariableCollection Variables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809348)]
	new ASCEquationCollection Equations
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809349)]
	new ASCParameterCollection Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809350)]
	new ASCPortCollection Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610809351)]
	bool IsIncluded
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
	}
}
[ComImport]
[Guid("00400042-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCVariable2 : IASCVariable
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	new double Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		set;
	}

	[DispId(1610809346)]
	new double LowerBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[param: In]
		set;
	}

	[DispId(1610809347)]
	new double UpperBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[param: In]
		set;
	}

	[DispId(1610809348)]
	new ASCSpec Spec
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[param: In]
		set;
	}

	[DispId(1610809349)]
	new double Scale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[param: In]
		set;
	}

	[DispId(1610809350)]
	new double SBWeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[param: In]
		set;
	}

	[DispId(1610809351)]
	new double ShadowPrice
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		[param: In]
		set;
	}

	[DispId(1610809352)]
	new bool Marked
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[param: In]
		set;
	}

	[DispId(1610809353)]
	new bool Modified
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[param: In]
		set;
	}

	[DispId(1610809354)]
	new ASCActiveBound ActiveBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809354)]
		get;
	}

	[DispId(1610809355)]
	new ASCVarQuality Quality
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		[param: In]
		set;
	}

	[DispId(1610809356)]
	new string UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610809357)]
	new double Initial
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		[param: In]
		set;
	}

	[DispId(1610809358)]
	new double Change
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		[param: In]
		set;
	}

	[DispId(1610809359)]
	new int Number
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809359)]
		get;
	}

	[DispId(1610809360)]
	new ASCVarBoundType BoundType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		[param: In]
		set;
	}

	[DispId(1610809361)]
	new double InternalScale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		[param: In]
		set;
	}

	[DispId(1610809362)]
	new double Step
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		[param: In]
		set;
	}

	[DispId(1610809363)]
	new string PhysicalType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809363)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809364)]
	new object UOMList
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809364)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809365)]
	ASCHomotopyParam HomotopyParameter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809365)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809365)]
		[param: In]
		set;
	}

	[DispId(1610809366)]
	double HomotopyTarget
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809366)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809366)]
		[param: In]
		set;
	}

	[DispId(1610809367)]
	string Description
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809367)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
public enum ASCHomotopyParam
{
	ASCHomotopyParam_NotAParam,
	ASCHomotopyParam_IsAParam
}
[ComImport]
[Guid("00400043-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCVariable3 : IASCVariable2
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	new double Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		set;
	}

	[DispId(1610809346)]
	new double LowerBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[param: In]
		set;
	}

	[DispId(1610809347)]
	new double UpperBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[param: In]
		set;
	}

	[DispId(1610809348)]
	new ASCSpec Spec
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[param: In]
		set;
	}

	[DispId(1610809349)]
	new double Scale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[param: In]
		set;
	}

	[DispId(1610809350)]
	new double SBWeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[param: In]
		set;
	}

	[DispId(1610809351)]
	new double ShadowPrice
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		[param: In]
		set;
	}

	[DispId(1610809352)]
	new bool Marked
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[param: In]
		set;
	}

	[DispId(1610809353)]
	new bool Modified
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[param: In]
		set;
	}

	[DispId(1610809354)]
	new ASCActiveBound ActiveBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809354)]
		get;
	}

	[DispId(1610809355)]
	new ASCVarQuality Quality
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		[param: In]
		set;
	}

	[DispId(1610809356)]
	new string UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610809357)]
	new double Initial
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		[param: In]
		set;
	}

	[DispId(1610809358)]
	new double Change
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		[param: In]
		set;
	}

	[DispId(1610809359)]
	new int Number
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809359)]
		get;
	}

	[DispId(1610809360)]
	new ASCVarBoundType BoundType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		[param: In]
		set;
	}

	[DispId(1610809361)]
	new double InternalScale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		[param: In]
		set;
	}

	[DispId(1610809362)]
	new double Step
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		[param: In]
		set;
	}

	[DispId(1610809363)]
	new string PhysicalType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809363)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809364)]
	new object UOMList
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809364)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809365)]
	new ASCHomotopyParam HomotopyParameter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809365)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809365)]
		[param: In]
		set;
	}

	[DispId(1610809366)]
	new double HomotopyTarget
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809366)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809366)]
		[param: In]
		set;
	}

	[DispId(1610809367)]
	new string Description
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809367)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809368)]
	ASCVariableType VariableType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809368)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809368)]
		[param: In]
		set;
	}
}
public enum ASCVariableType
{
	ASCVariableType_ALGEBRAIC = 0,
	ASCVariableType_STATE = 1,
	ASCVariableType_DIFFERENTIAL = 2,
	ASCVariableType_INTEGER = 3,
	ASCVariableType_DISCRETE_ESLACK = 4,
	ASCVariableType_BINARY = 5,
	ASCVariableType_PARTIAL_INTEGER = 6,
	ASCVariableType_SEMI_CONTINUOUS = 7,
	ASCVariableType_SEMI_CONTINUOUS_INTEGER = 64
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("00400048-F704-49A8-9694-22DA620B8282")]
public interface IASCVariable4 : IASCVariable3
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	new double Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		set;
	}

	[DispId(1610809346)]
	new double LowerBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[param: In]
		set;
	}

	[DispId(1610809347)]
	new double UpperBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[param: In]
		set;
	}

	[DispId(1610809348)]
	new ASCSpec Spec
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[param: In]
		set;
	}

	[DispId(1610809349)]
	new double Scale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[param: In]
		set;
	}

	[DispId(1610809350)]
	new double SBWeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[param: In]
		set;
	}

	[DispId(1610809351)]
	new double ShadowPrice
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		[param: In]
		set;
	}

	[DispId(1610809352)]
	new bool Marked
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[param: In]
		set;
	}

	[DispId(1610809353)]
	new bool Modified
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[param: In]
		set;
	}

	[DispId(1610809354)]
	new ASCActiveBound ActiveBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809354)]
		get;
	}

	[DispId(1610809355)]
	new ASCVarQuality Quality
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		[param: In]
		set;
	}

	[DispId(1610809356)]
	new string UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610809357)]
	new double Initial
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		[param: In]
		set;
	}

	[DispId(1610809358)]
	new double Change
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		[param: In]
		set;
	}

	[DispId(1610809359)]
	new int Number
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809359)]
		get;
	}

	[DispId(1610809360)]
	new ASCVarBoundType BoundType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		[param: In]
		set;
	}

	[DispId(1610809361)]
	new double InternalScale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		[param: In]
		set;
	}

	[DispId(1610809362)]
	new double Step
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		[param: In]
		set;
	}

	[DispId(1610809363)]
	new string PhysicalType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809363)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809364)]
	new object UOMList
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809364)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809365)]
	new ASCHomotopyParam HomotopyParameter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809365)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809365)]
		[param: In]
		set;
	}

	[DispId(1610809366)]
	new double HomotopyTarget
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809366)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809366)]
		[param: In]
		set;
	}

	[DispId(1610809367)]
	new string Description
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809367)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809368)]
	new ASCVariableType VariableType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809368)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809368)]
		[param: In]
		set;
	}

	[DispId(1610809369)]
	int ConnectionType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809369)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809369)]
		[param: In]
		set;
	}

	[DispId(1610809376)]
	string Description_2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809376)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610809377)]
	string PhysicalType_2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809377)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}
}
[ComImport]
[Guid("00400050-F704-49A8-9694-22DA620B8282")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IASCVariable5 : IASCVariable4
{
	[DispId(1610743809)]
	new IASCObject Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new IASCSimulation Simulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	new bool IsValid
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);

	[DispId(1610809345)]
	new double Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		set;
	}

	[DispId(1610809346)]
	new double LowerBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[param: In]
		set;
	}

	[DispId(1610809347)]
	new double UpperBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809347)]
		[param: In]
		set;
	}

	[DispId(1610809348)]
	new ASCSpec Spec
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[param: In]
		set;
	}

	[DispId(1610809349)]
	new double Scale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809349)]
		[param: In]
		set;
	}

	[DispId(1610809350)]
	new double SBWeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[param: In]
		set;
	}

	[DispId(1610809351)]
	new double ShadowPrice
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809351)]
		[param: In]
		set;
	}

	[DispId(1610809352)]
	new bool Marked
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[param: In]
		set;
	}

	[DispId(1610809353)]
	new bool Modified
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809353)]
		[param: In]
		set;
	}

	[DispId(1610809354)]
	new ASCActiveBound ActiveBound
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809354)]
		get;
	}

	[DispId(1610809355)]
	new ASCVarQuality Quality
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809355)]
		[param: In]
		set;
	}

	[DispId(1610809356)]
	new string UOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809356)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610809357)]
	new double Initial
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809357)]
		[param: In]
		set;
	}

	[DispId(1610809358)]
	new double Change
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809358)]
		[param: In]
		set;
	}

	[DispId(1610809359)]
	new int Number
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809359)]
		get;
	}

	[DispId(1610809360)]
	new ASCVarBoundType BoundType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809360)]
		[param: In]
		set;
	}

	[DispId(1610809361)]
	new double InternalScale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809361)]
		[param: In]
		set;
	}

	[DispId(1610809362)]
	new double Step
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809362)]
		[param: In]
		set;
	}

	[DispId(1610809363)]
	new string PhysicalType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809363)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809364)]
	new object UOMList
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809364)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610809365)]
	new ASCHomotopyParam HomotopyParameter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809365)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809365)]
		[param: In]
		set;
	}

	[DispId(1610809366)]
	new double HomotopyTarget
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809366)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809366)]
		[param: In]
		set;
	}

	[DispId(1610809367)]
	new string Description
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809367)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610809368)]
	new ASCVariableType VariableType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809368)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809368)]
		[param: In]
		set;
	}

	[DispId(1610809369)]
	new int ConnectionType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809369)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809369)]
		[param: In]
		set;
	}

	[DispId(1610809376)]
	new string Description_2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809376)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610809377)]
	new string PhysicalType_2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809377)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610809378)]
	string baseUOM
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809378)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComVisible(false)]
public delegate void DASCSimulationMsgsEvents2_OnNewLineEventHandler([In][MarshalAs(UnmanagedType.BStr)] string bText);
[ComVisible(false)]
public delegate void DASCSimulationMsgsEvents2_UpdateProfilesEventHandler([In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] nameArray, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] object[] valArray, double time);
[ComVisible(false)]
public delegate void DASCSimulationMsgsEvents2_ResetSimulationEventHandler();
[ClassInterface(ClassInterfaceType.None)]
[TypeLibType(TypeLibTypeFlags.FHidden)]
public sealed class DASCSimulationMsgsEvents_SinkHelper : DASCSimulationMsgsEvents
{
	public DASCSimulationMsgsEvents_OnNewLineEventHandler m_OnNewLineDelegate;

	public int m_dwCookie;

	public void OnNewLine(string P_0)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnNewLineDelegate != null)
		{
			m_OnNewLineDelegate(P_0);
		}
	}

	internal DASCSimulationMsgsEvents_SinkHelper()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		m_dwCookie = 0;
		m_OnNewLineDelegate = null;
	}
}
internal sealed class DASCSimulationMsgsEvents_EventProvider : IDisposable
{
	private WeakReference m_wkConnectionPointContainer;

	private ArrayList m_aEventSinkHelpers;

	private IConnectionPoint m_ConnectionPoint;

	private void Init()
	{
		IConnectionPoint ppCP = null;
		byte[] guidBytes = new byte[16];
guidBytes[0] = 20;
guidBytes[1] = 0;
guidBytes[2] = 64;
guidBytes[3] = 0;
guidBytes[4] = 4;
guidBytes[5] = 247;
guidBytes[6] = 168;
guidBytes[7] = 73;
guidBytes[8] = 150;
guidBytes[9] = 148;
guidBytes[10] = 34;
guidBytes[11] = 218;
guidBytes[12] = 98;
guidBytes[13] = 11;
guidBytes[14] = 130;
guidBytes[15] = 130;
Guid riid = new Guid(guidBytes);
		((IConnectionPointContainer)m_wkConnectionPointContainer.Target).FindConnectionPoint(ref riid, out ppCP);
		m_ConnectionPoint = ppCP;
		m_aEventSinkHelpers = new ArrayList();
	}

	public void add_OnNewLine(DASCSimulationMsgsEvents_OnNewLineEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			DASCSimulationMsgsEvents_SinkHelper dASCSimulationMsgsEvents_SinkHelper = new DASCSimulationMsgsEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dASCSimulationMsgsEvents_SinkHelper, out pdwCookie);
			dASCSimulationMsgsEvents_SinkHelper.m_dwCookie = pdwCookie;
			dASCSimulationMsgsEvents_SinkHelper.m_OnNewLineDelegate = P_0;
			m_aEventSinkHelpers.Add(dASCSimulationMsgsEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnNewLine(DASCSimulationMsgsEvents_OnNewLineEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				DASCSimulationMsgsEvents_SinkHelper dASCSimulationMsgsEvents_SinkHelper = (DASCSimulationMsgsEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (dASCSimulationMsgsEvents_SinkHelper.m_OnNewLineDelegate != null && ((dASCSimulationMsgsEvents_SinkHelper.m_OnNewLineDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dASCSimulationMsgsEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public DASCSimulationMsgsEvents_EventProvider(object P_0)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		m_wkConnectionPointContainer = new WeakReference((IConnectionPointContainer)P_0, trackResurrection: false);
	}

	public void Finalize()
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
				do
				{
					DASCSimulationMsgsEvents_SinkHelper dASCSimulationMsgsEvents_SinkHelper = (DASCSimulationMsgsEvents_SinkHelper)m_aEventSinkHelpers[num];
					m_ConnectionPoint.Unadvise(dASCSimulationMsgsEvents_SinkHelper.m_dwCookie);
					num++;
				}
				while (num < count);
			}
			Marshal.ReleaseComObject(m_ConnectionPoint);
			}
		}
		catch (Exception)
		{
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void Dispose()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		Finalize();
		GC.SuppressFinalize(this);
	}
}
[TypeLibType(TypeLibTypeFlags.FHidden)]
[ClassInterface(ClassInterfaceType.None)]
public sealed class DASCSimulationMsgsEvents2_SinkHelper : DASCSimulationMsgsEvents2
{
	public DASCSimulationMsgsEvents2_OnNewLineEventHandler m_OnNewLineDelegate;

	public DASCSimulationMsgsEvents2_UpdateProfilesEventHandler m_UpdateProfilesDelegate;

	public DASCSimulationMsgsEvents2_ResetSimulationEventHandler m_ResetSimulationDelegate;

	public int m_dwCookie;

	public void OnNewLine(string P_0)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnNewLineDelegate != null)
		{
			m_OnNewLineDelegate(P_0);
		}
	}

	public void UpdateProfiles(string[] P_0, object[] P_1, double P_2)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_UpdateProfilesDelegate != null)
		{
			m_UpdateProfilesDelegate(P_0, P_1, P_2);
		}
	}

	public void ResetSimulation()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_ResetSimulationDelegate != null)
		{
			m_ResetSimulationDelegate();
		}
	}

	internal DASCSimulationMsgsEvents2_SinkHelper()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		m_dwCookie = 0;
		m_OnNewLineDelegate = null;
		m_UpdateProfilesDelegate = null;
		m_ResetSimulationDelegate = null;
	}
}
internal sealed class DASCSimulationMsgsEvents2_EventProvider : IDisposable
{
	private WeakReference m_wkConnectionPointContainer;

	private ArrayList m_aEventSinkHelpers;

	private IConnectionPoint m_ConnectionPoint;

	private void Init()
	{
		IConnectionPoint ppCP = null;
		byte[] guidBytes = new byte[16];
guidBytes[0] = 82;
guidBytes[1] = 0;
guidBytes[2] = 64;
guidBytes[3] = 0;
guidBytes[4] = 4;
guidBytes[5] = 247;
guidBytes[6] = 168;
guidBytes[7] = 73;
guidBytes[8] = 150;
guidBytes[9] = 148;
guidBytes[10] = 34;
guidBytes[11] = 218;
guidBytes[12] = 98;
guidBytes[13] = 11;
guidBytes[14] = 130;
guidBytes[15] = 130;
Guid riid = new Guid(guidBytes);
		((IConnectionPointContainer)m_wkConnectionPointContainer.Target).FindConnectionPoint(ref riid, out ppCP);
		m_ConnectionPoint = ppCP;
		m_aEventSinkHelpers = new ArrayList();
	}

	public void add_OnNewLine(DASCSimulationMsgsEvents2_OnNewLineEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			DASCSimulationMsgsEvents2_SinkHelper dASCSimulationMsgsEvents2_SinkHelper = new DASCSimulationMsgsEvents2_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dASCSimulationMsgsEvents2_SinkHelper, out pdwCookie);
			dASCSimulationMsgsEvents2_SinkHelper.m_dwCookie = pdwCookie;
			dASCSimulationMsgsEvents2_SinkHelper.m_OnNewLineDelegate = P_0;
			m_aEventSinkHelpers.Add(dASCSimulationMsgsEvents2_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnNewLine(DASCSimulationMsgsEvents2_OnNewLineEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				DASCSimulationMsgsEvents2_SinkHelper dASCSimulationMsgsEvents2_SinkHelper = (DASCSimulationMsgsEvents2_SinkHelper)m_aEventSinkHelpers[num];
				if (dASCSimulationMsgsEvents2_SinkHelper.m_OnNewLineDelegate != null && ((dASCSimulationMsgsEvents2_SinkHelper.m_OnNewLineDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dASCSimulationMsgsEvents2_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_UpdateProfiles(DASCSimulationMsgsEvents2_UpdateProfilesEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			DASCSimulationMsgsEvents2_SinkHelper dASCSimulationMsgsEvents2_SinkHelper = new DASCSimulationMsgsEvents2_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dASCSimulationMsgsEvents2_SinkHelper, out pdwCookie);
			dASCSimulationMsgsEvents2_SinkHelper.m_dwCookie = pdwCookie;
			dASCSimulationMsgsEvents2_SinkHelper.m_UpdateProfilesDelegate = P_0;
			m_aEventSinkHelpers.Add(dASCSimulationMsgsEvents2_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_UpdateProfiles(DASCSimulationMsgsEvents2_UpdateProfilesEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				DASCSimulationMsgsEvents2_SinkHelper dASCSimulationMsgsEvents2_SinkHelper = (DASCSimulationMsgsEvents2_SinkHelper)m_aEventSinkHelpers[num];
				if (dASCSimulationMsgsEvents2_SinkHelper.m_UpdateProfilesDelegate != null && ((dASCSimulationMsgsEvents2_SinkHelper.m_UpdateProfilesDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dASCSimulationMsgsEvents2_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_ResetSimulation(DASCSimulationMsgsEvents2_ResetSimulationEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			DASCSimulationMsgsEvents2_SinkHelper dASCSimulationMsgsEvents2_SinkHelper = new DASCSimulationMsgsEvents2_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dASCSimulationMsgsEvents2_SinkHelper, out pdwCookie);
			dASCSimulationMsgsEvents2_SinkHelper.m_dwCookie = pdwCookie;
			dASCSimulationMsgsEvents2_SinkHelper.m_ResetSimulationDelegate = P_0;
			m_aEventSinkHelpers.Add(dASCSimulationMsgsEvents2_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_ResetSimulation(DASCSimulationMsgsEvents2_ResetSimulationEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				DASCSimulationMsgsEvents2_SinkHelper dASCSimulationMsgsEvents2_SinkHelper = (DASCSimulationMsgsEvents2_SinkHelper)m_aEventSinkHelpers[num];
				if (dASCSimulationMsgsEvents2_SinkHelper.m_ResetSimulationDelegate != null && ((dASCSimulationMsgsEvents2_SinkHelper.m_ResetSimulationDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dASCSimulationMsgsEvents2_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public DASCSimulationMsgsEvents2_EventProvider(object P_0)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		m_wkConnectionPointContainer = new WeakReference((IConnectionPointContainer)P_0, trackResurrection: false);
	}

	public void Finalize()
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
				do
				{
					DASCSimulationMsgsEvents2_SinkHelper dASCSimulationMsgsEvents2_SinkHelper = (DASCSimulationMsgsEvents2_SinkHelper)m_aEventSinkHelpers[num];
					m_ConnectionPoint.Unadvise(dASCSimulationMsgsEvents2_SinkHelper.m_dwCookie);
					num++;
				}
				while (num < count);
			}
			Marshal.ReleaseComObject(m_ConnectionPoint);
			}
		}
		catch (Exception)
		{
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void Dispose()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		Finalize();
		GC.SuppressFinalize(this);
	}
}
