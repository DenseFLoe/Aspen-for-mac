using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPLControls;
using WpfPlotWizardsHelper;
using WpfPlotwizard;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("WpfPLScreen")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, INC.")]
[assembly: AssemblyProduct("WpfPLScreen")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, INC. 2012 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("c6ddfb08-7487-490d-bcbc-06936aacfb0e")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]
namespace WpfPLFluidBed
{
	[ProgId("WpfPLFluidBed.BubbleDiam")]
	public class BubbleDiam : IRibbonPlotWizardType
	{
		private IHNode _context;

		private IHWizardPlot _wizardPlot;

		private PlotwizardHelper _help = new PlotwizardHelper();

		private string _currentLengthUnit = string.Empty;

		private string _uniqueId = PlotPWRResource.Bubble_Diameter;

		private string _plotName;

		private object _nodeCxs;

		private System.Drawing.Image _imgBitmap;

		private bool _bHasInputDialog;

		private string _currentlengthUnit = string.Empty;

		private string _currentdiamUnit = string.Empty;

		private readonly string _lengthUnitFieldId = PlotPWRResource.Height;

		private readonly string _diamUnitFieldId = PlotPWRResource.Diameter;

		private readonly string _stageOnFieldId = PlotPWRResource.Diameter_on;

		private readonly string _stageOrderFieldId = PlotPWRResource.Diameter_order;

		private readonly string _yAxis = WpfPLRadFracResources.Y_axis;

		private readonly string _xAxis = WpfPLRadFracResources.X_axis;

		private readonly string _ascending = WpfPLRadFracResources.Ascending;

		private readonly string _descending = WpfPLRadFracResources.Descending;

		private string _varXName;

		private string _varYName;

		private bool _bCheckDataOnly;

		public string TooltipContentForRibbonItem => PlotPWRResource.Bubble_Diameter;

		public string TooltipHeaderForRibbonItem => PlotPWRResource.Bubble_Diameter;

		string IRibbonPlotWizardType.TagID
		{
			get
			{
				return _uniqueId;
			}
			set
			{
				_uniqueId = value;
			}
		}

		string IRibbonPlotWizardType.Name
		{
			get
			{
				return _plotName;
			}
			set
			{
				_plotName = value;
			}
		}

		object IRibbonPlotWizardType.WizardPlot
		{
			get
			{
				return _wizardPlot;
			}
			set
			{
				_wizardPlot = value as IHWizardPlot;
			}
		}

		object IRibbonPlotWizardType.CxsNode
		{
			get
			{
				return _nodeCxs;
			}
			set
			{
				_nodeCxs = value;
			}
		}

		System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

		bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

		string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

		long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

		List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _diamUnitFieldId, _lengthUnitFieldId };

		List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string> { _stageOrderFieldId, _stageOnFieldId };

		public bool CheckDataOnly
		{
			get
			{
				return _bCheckDataOnly;
			}
			set
			{
				_bCheckDataOnly = value;
			}
		}

		public BubbleDiam()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			_varXName = "Output/DIAM";
			_varYName = "Output/FHEIGHT";
			_bHasInputDialog = false;
			if (_imgBitmap == null)
			{
				Assembly.GetExecutingAssembly();
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLFluidBed.Images.BinaryPX.ico");
				_imgBitmap = new Bitmap(manifestResourceStream);
			}
		}

		List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				List<string> list = new List<string>();
				_help.LoadUnitsList(_context.Application.Tree, _wizardPlot, list);
				return list;
			}
			if (sFieldName.CompareTo(_diamUnitFieldId) == 0)
			{
				List<string> list2 = new List<string>();
				_help.LoadXUnitsList(_context.Application.Tree, _wizardPlot, list2);
				return list2;
			}
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				return new List<string> { _ascending, _descending };
			}
			if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				return new List<string> { _xAxis, _yAxis };
			}
			return null;
		}

		void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetUnitString(_context.Application.Tree, _wizardPlot);
			}
			else if (sFieldName.CompareTo(_diamUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
		}

		void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				_currentLengthUnit = sValue;
			}
			else if (sFieldName.CompareTo(_diamUnitFieldId) == 0)
			{
				_currentdiamUnit = sValue;
			}
		}

		void IRibbonPlotWizardType.ShowInputDialog()
		{
		}

		RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
		{
			if (sField.CompareTo(_lengthUnitFieldId) == 0 || sField.CompareTo(_diamUnitFieldId) == 0 || sField.CompareTo(_stageOrderFieldId) == 0 || sField.CompareTo(_stageOnFieldId) == 0)
			{
				return (RibbonControlType)1;
			}
			return (RibbonControlType)0;
		}

		void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.ReverseXAxis)
				{
					sCurrentVal = _descending;
				}
				else
				{
					sCurrentVal = _ascending;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.SwapAxises)
				{
					sCurrentVal = _yAxis;
				}
				else
				{
					sCurrentVal = _xAxis;
				}
			}
		}

		void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (sValue.CompareTo(_ascending) == 0)
				{
					_wizardPlot.PlotVal.ReverseXAxis = false;
				}
				else
				{
					_wizardPlot.PlotVal.ReverseXAxis = true;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (sValue.CompareTo(_yAxis) == 0)
				{
					_wizardPlot.PlotVal.SwapAxises = true;
				}
				else
				{
					_wizardPlot.PlotVal.SwapAxises = false;
				}
			}
		}

		void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
		{
		}

		void IRibbonPlotWizardType.SetConfigData(string sValue)
		{
		}

		void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
		{
			if (HWizardPlot == null || HNode == null)
			{
				ierror = 1;
				return;
			}
			_context = HNode as IHNode;
			_wizardPlot = HWizardPlot as IHWizardPlot;
			IHNode iHNode = _context.FindNode(_varXName);
			if (iHNode == null || iHNode.Elements.Count <= 0)
			{
				ierror = 1;
				return;
			}
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
		}

		public void UpdateWizardData()
		{
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
			_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currentLengthUnit);
			_help.SaveXUnitsComboText(_context.Application.Tree, _wizardPlot, _currentdiamUnit);
			string text = _currentdiamUnit;
			if (string.IsNullOrEmpty(text))
			{
				text = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(0, PlotPWRResource.Bubble_Diameter + " " + text);
		}
	}
	[ProgId("WpfPLFluidBed.BubbleFlow")]
	public class BubbleFlow : IRibbonPlotWizardType
	{
		private IHNode _context;

		private IHWizardPlot _wizardPlot;

		private PlotwizardHelper _help = new PlotwizardHelper();

		private string _currentLengthUnit = string.Empty;

		private string _currentflowUnit = string.Empty;

		private string _uniqueId = PlotPWRResource.Volumetric_bubble_flow;

		private string _plotName;

		private object _nodeCxs;

		private System.Drawing.Image _imgBitmap;

		private bool _bHasInputDialog;

		private readonly string _lengthUnitFieldId = PlotPWRResource.Height;

		private readonly string _flowUnitFieldId = PlotPWRResource.Volume_Flow;

		private readonly string _stageOnFieldId = PlotPWRResource.Volume_Flow_on;

		private readonly string _stageOrderFieldId = PlotPWRResource.Volume_Flow_order;

		private readonly string _yAxis = WpfPLRadFracResources.Y_axis;

		private readonly string _xAxis = WpfPLRadFracResources.X_axis;

		private readonly string _ascending = WpfPLRadFracResources.Ascending;

		private readonly string _descending = WpfPLRadFracResources.Descending;

		private string _varXName;

		private string _varYName;

		private bool _bCheckDataOnly;

		public string TooltipContentForRibbonItem => PlotPWRResource.Volumetric_bubble_flow;

		public string TooltipHeaderForRibbonItem => PlotPWRResource.Volumetric_bubble_flow;

		string IRibbonPlotWizardType.TagID
		{
			get
			{
				return _uniqueId;
			}
			set
			{
				_uniqueId = value;
			}
		}

		string IRibbonPlotWizardType.Name
		{
			get
			{
				return _plotName;
			}
			set
			{
				_plotName = value;
			}
		}

		object IRibbonPlotWizardType.WizardPlot
		{
			get
			{
				return _wizardPlot;
			}
			set
			{
				_wizardPlot = value as IHWizardPlot;
			}
		}

		object IRibbonPlotWizardType.CxsNode
		{
			get
			{
				return _nodeCxs;
			}
			set
			{
				_nodeCxs = value;
			}
		}

		System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

		bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

		string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

		long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

		List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _flowUnitFieldId, _lengthUnitFieldId };

		List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string> { _stageOrderFieldId, _stageOnFieldId };

		public bool CheckDataOnly
		{
			get
			{
				return _bCheckDataOnly;
			}
			set
			{
				_bCheckDataOnly = value;
			}
		}

		public BubbleFlow()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			_varXName = "Output/GAS_FLOW";
			_varYName = "Output/FHEIGHT";
			_bHasInputDialog = false;
			if (_imgBitmap == null)
			{
				Assembly.GetExecutingAssembly();
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLFluidBed.Images.BinaryPX.ico");
				_imgBitmap = new Bitmap(manifestResourceStream);
			}
		}

		List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				List<string> list = new List<string>();
				_help.LoadUnitsList(_context.Application.Tree, _wizardPlot, list);
				return list;
			}
			if (sFieldName.CompareTo(_flowUnitFieldId) == 0)
			{
				List<string> list2 = new List<string>();
				_help.LoadXUnitsList(_context.Application.Tree, _wizardPlot, list2);
				return list2;
			}
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				return new List<string> { _ascending, _descending };
			}
			if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				return new List<string> { _xAxis, _yAxis };
			}
			return null;
		}

		void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetUnitString(_context.Application.Tree, _wizardPlot);
			}
			else if (sFieldName.CompareTo(_flowUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
		}

		void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				_currentLengthUnit = sValue;
			}
			else if (sFieldName.CompareTo(_flowUnitFieldId) == 0)
			{
				_currentflowUnit = sValue;
			}
		}

		void IRibbonPlotWizardType.ShowInputDialog()
		{
		}

		RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
		{
			if (sField.CompareTo(_lengthUnitFieldId) == 0 || sField.CompareTo(_flowUnitFieldId) == 0 || sField.CompareTo(_stageOrderFieldId) == 0 || sField.CompareTo(_stageOnFieldId) == 0)
			{
				return (RibbonControlType)1;
			}
			return (RibbonControlType)0;
		}

		void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.ReverseXAxis)
				{
					sCurrentVal = _descending;
				}
				else
				{
					sCurrentVal = _ascending;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.SwapAxises)
				{
					sCurrentVal = _yAxis;
				}
				else
				{
					sCurrentVal = _xAxis;
				}
			}
		}

		void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (sValue.CompareTo(_ascending) == 0)
				{
					_wizardPlot.PlotVal.ReverseXAxis = false;
				}
				else
				{
					_wizardPlot.PlotVal.ReverseXAxis = true;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (sValue.CompareTo(_yAxis) == 0)
				{
					_wizardPlot.PlotVal.SwapAxises = true;
				}
				else
				{
					_wizardPlot.PlotVal.SwapAxises = false;
				}
			}
		}

		void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
		{
		}

		void IRibbonPlotWizardType.SetConfigData(string sValue)
		{
		}

		void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
		{
			if (HWizardPlot == null || HNode == null)
			{
				ierror = 1;
				return;
			}
			_context = HNode as IHNode;
			_wizardPlot = HWizardPlot as IHWizardPlot;
			IHNode iHNode = _context.FindNode(_varXName);
			if (iHNode == null || iHNode.Elements.Count <= 0)
			{
				ierror = 1;
				return;
			}
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
		}

		public void UpdateWizardData()
		{
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
			_help.SaveXUnitsComboText(_context.Application.Tree, _wizardPlot, _currentflowUnit);
			_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currentLengthUnit);
			string text = _currentflowUnit;
			if (string.IsNullOrEmpty(text))
			{
				text = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(0, PlotPWRResource.Volumetric_bubble_flow + " " + text);
		}
	}
	[ProgId("WpfPLFluidBed.BubbleVel")]
	public class BubbleVel : IRibbonPlotWizardType
	{
		private IHNode _context;

		private IHWizardPlot _wizardPlot;

		private PlotwizardHelper _help = new PlotwizardHelper();

		private string _currentvelocityUnit = string.Empty;

		private string _currentLengthUnit = string.Empty;

		private string _uniqueId = PlotPWRResource.Bubble_Rise_Velocity;

		private string _plotName;

		private object _nodeCxs;

		private System.Drawing.Image _imgBitmap;

		private bool _bHasInputDialog;

		private readonly string _velocityUnitFieldId = PlotPWRResource.Velocity;

		private readonly string _lengthUnitFieldId = PlotPWRResource.Height;

		private readonly string _stageOnFieldId = PlotPWRResource.Velocity_on;

		private readonly string _stageOrderFieldId = PlotPWRResource.Velocity_order;

		private readonly string _yAxis = WpfPLRadFracResources.Y_axis;

		private readonly string _xAxis = WpfPLRadFracResources.X_axis;

		private readonly string _ascending = WpfPLRadFracResources.Ascending;

		private readonly string _descending = WpfPLRadFracResources.Descending;

		private string _varXName;

		private string _varYName;

		private bool _bCheckDataOnly;

		public string TooltipContentForRibbonItem => PlotPWRResource.Bubble_Rise_Velocity;

		public string TooltipHeaderForRibbonItem => PlotPWRResource.Bubble_Rise_Velocity;

		string IRibbonPlotWizardType.TagID
		{
			get
			{
				return _uniqueId;
			}
			set
			{
				_uniqueId = value;
			}
		}

		string IRibbonPlotWizardType.Name
		{
			get
			{
				return _plotName;
			}
			set
			{
				_plotName = value;
			}
		}

		object IRibbonPlotWizardType.WizardPlot
		{
			get
			{
				return _wizardPlot;
			}
			set
			{
				_wizardPlot = value as IHWizardPlot;
			}
		}

		object IRibbonPlotWizardType.CxsNode
		{
			get
			{
				return _nodeCxs;
			}
			set
			{
				_nodeCxs = value;
			}
		}

		System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

		bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

		string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

		long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

		List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _velocityUnitFieldId, _lengthUnitFieldId };

		List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string> { _stageOrderFieldId, _stageOnFieldId };

		public bool CheckDataOnly
		{
			get
			{
				return _bCheckDataOnly;
			}
			set
			{
				_bCheckDataOnly = value;
			}
		}

		public BubbleVel()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			_varXName = "Output/OUT_VELOC";
			_varYName = "Output/FHEIGHT";
			_bHasInputDialog = false;
			if (_imgBitmap == null)
			{
				Assembly.GetExecutingAssembly();
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLFluidBed.Images.BinaryPX.ico");
				_imgBitmap = new Bitmap(manifestResourceStream);
			}
		}

		List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
		{
			if (sFieldName.CompareTo(_velocityUnitFieldId) == 0)
			{
				List<string> list = new List<string>();
				_help.LoadXUnitsList(_context.Application.Tree, _wizardPlot, list);
				return list;
			}
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				List<string> list2 = new List<string>();
				_help.LoadUnitsList(_context.Application.Tree, _wizardPlot, list2);
				return list2;
			}
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				return new List<string> { _ascending, _descending };
			}
			if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				return new List<string> { _xAxis, _yAxis };
			}
			return null;
		}

		void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_velocityUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
			else if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetUnitString(_context.Application.Tree, _wizardPlot);
			}
		}

		void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_velocityUnitFieldId) == 0)
			{
				_currentvelocityUnit = sValue;
			}
			else if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				_currentLengthUnit = sValue;
			}
		}

		void IRibbonPlotWizardType.ShowInputDialog()
		{
		}

		RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
		{
			if (sField.CompareTo(_velocityUnitFieldId) == 0 || sField.CompareTo(_lengthUnitFieldId) == 0 || sField.CompareTo(_stageOrderFieldId) == 0 || sField.CompareTo(_stageOnFieldId) == 0)
			{
				return (RibbonControlType)1;
			}
			return (RibbonControlType)0;
		}

		void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.ReverseXAxis)
				{
					sCurrentVal = _descending;
				}
				else
				{
					sCurrentVal = _ascending;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.SwapAxises)
				{
					sCurrentVal = _yAxis;
				}
				else
				{
					sCurrentVal = _xAxis;
				}
			}
		}

		void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (sValue.CompareTo(_ascending) == 0)
				{
					_wizardPlot.PlotVal.ReverseXAxis = false;
				}
				else
				{
					_wizardPlot.PlotVal.ReverseXAxis = true;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (sValue.CompareTo(_yAxis) == 0)
				{
					_wizardPlot.PlotVal.SwapAxises = true;
				}
				else
				{
					_wizardPlot.PlotVal.SwapAxises = false;
				}
			}
		}

		void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
		{
		}

		void IRibbonPlotWizardType.SetConfigData(string sValue)
		{
		}

		void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
		{
			if (HWizardPlot == null || HNode == null)
			{
				ierror = 1;
				return;
			}
			_context = HNode as IHNode;
			_wizardPlot = HWizardPlot as IHWizardPlot;
			IHNode iHNode = _context.FindNode(_varXName);
			if (iHNode == null || iHNode.Elements.Count <= 0)
			{
				ierror = 1;
				return;
			}
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
		}

		public void UpdateWizardData()
		{
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
			_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currentLengthUnit);
			_help.SaveXUnitsComboText(_context.Application.Tree, _wizardPlot, _currentvelocityUnit);
			string text = _currentvelocityUnit;
			if (string.IsNullOrEmpty(text))
			{
				text = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(0, PlotPWRResource.Bubble_Rise_Velocity + " " + text);
		}
	}
	[ProgId("WpfPLFluidBed.BVolFrac")]
	public class BVolFrac : IRibbonPlotWizardType
	{
		private IHNode _context;

		private IHWizardPlot _wizardPlot;

		private PlotwizardHelper _help = new PlotwizardHelper();

		private string _currentLengthUnit = string.Empty;

		private string _uniqueId = PlotPWRResource.Bubble_Volume_Fraction;

		private string _plotName;

		private object _nodeCxs;

		private System.Drawing.Image _imgBitmap;

		private bool _bHasInputDialog;

		private readonly string _lengthUnitFieldId = PlotPWRResource.Height;

		private readonly string _stageOnFieldId = PlotPWRResource.Fraction_on;

		private readonly string _stageOrderFieldId = PlotPWRResource.Fraction_order;

		private readonly string _yAxis = WpfPLRadFracResources.Y_axis;

		private readonly string _xAxis = WpfPLRadFracResources.X_axis;

		private readonly string _ascending = WpfPLRadFracResources.Ascending;

		private readonly string _descending = WpfPLRadFracResources.Descending;

		private string _varXName;

		private string _varYName;

		private bool _bCheckDataOnly;

		public string TooltipContentForRibbonItem => PlotPWRResource.Bubble_Volume_Fraction;

		public string TooltipHeaderForRibbonItem => PlotPWRResource.Bubble_Volume_Fraction;

		string IRibbonPlotWizardType.TagID
		{
			get
			{
				return _uniqueId;
			}
			set
			{
				_uniqueId = value;
			}
		}

		string IRibbonPlotWizardType.Name
		{
			get
			{
				return _plotName;
			}
			set
			{
				_plotName = value;
			}
		}

		object IRibbonPlotWizardType.WizardPlot
		{
			get
			{
				return _wizardPlot;
			}
			set
			{
				_wizardPlot = value as IHWizardPlot;
			}
		}

		object IRibbonPlotWizardType.CxsNode
		{
			get
			{
				return _nodeCxs;
			}
			set
			{
				_nodeCxs = value;
			}
		}

		System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

		bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

		string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

		long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

		List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _lengthUnitFieldId };

		List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string> { _stageOrderFieldId, _stageOnFieldId };

		public bool CheckDataOnly
		{
			get
			{
				return _bCheckDataOnly;
			}
			set
			{
				_bCheckDataOnly = value;
			}
		}

		public BVolFrac()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			_varXName = "Output/STDVFRAC";
			_varYName = "Output/FHEIGHT";
			_bHasInputDialog = false;
			if (_imgBitmap == null)
			{
				Assembly.GetExecutingAssembly();
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLFluidBed.Images.BinaryTX.ico");
				_imgBitmap = new Bitmap(manifestResourceStream);
			}
		}

		List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				List<string> list = new List<string>();
				_help.LoadUnitsList(_context.Application.Tree, _wizardPlot, list);
				return list;
			}
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				return new List<string> { _ascending, _descending };
			}
			if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				return new List<string> { _xAxis, _yAxis };
			}
			return null;
		}

		void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetUnitString(_context.Application.Tree, _wizardPlot);
			}
		}

		void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				_currentLengthUnit = sValue;
			}
		}

		void IRibbonPlotWizardType.ShowInputDialog()
		{
		}

		RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
		{
			if (sField.CompareTo(_lengthUnitFieldId) == 0 || sField.CompareTo(_stageOrderFieldId) == 0 || sField.CompareTo(_stageOnFieldId) == 0)
			{
				return (RibbonControlType)1;
			}
			return (RibbonControlType)0;
		}

		void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.ReverseXAxis)
				{
					sCurrentVal = _descending;
				}
				else
				{
					sCurrentVal = _ascending;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.SwapAxises)
				{
					sCurrentVal = _yAxis;
				}
				else
				{
					sCurrentVal = _xAxis;
				}
			}
		}

		void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (sValue.CompareTo(_ascending) == 0)
				{
					_wizardPlot.PlotVal.ReverseXAxis = false;
				}
				else
				{
					_wizardPlot.PlotVal.ReverseXAxis = true;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (sValue.CompareTo(_yAxis) == 0)
				{
					_wizardPlot.PlotVal.SwapAxises = true;
				}
				else
				{
					_wizardPlot.PlotVal.SwapAxises = false;
				}
			}
		}

		void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
		{
		}

		void IRibbonPlotWizardType.SetConfigData(string sValue)
		{
		}

		void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
		{
			if (HWizardPlot == null || HNode == null)
			{
				ierror = 1;
				return;
			}
			_context = HNode as IHNode;
			_wizardPlot = HWizardPlot as IHWizardPlot;
			IHNode iHNode = _context.FindNode(_varXName);
			if (iHNode == null || iHNode.Elements.Count <= 0)
			{
				ierror = 1;
				return;
			}
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
		}

		public void UpdateWizardData()
		{
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(0, PlotPWRResource.Bubble_Volume_Fraction);
			_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currentLengthUnit);
		}
	}
	[ProgId("WpfPLFluidBed.Composition")]
	public class Composition : UserControl, IRibbonPlotWizardType, IPlotWizardTemplate, IComponentConnector
	{
		private IHNode _context;

		private IHWizardPlot _wizardPlot;

		private PlotwizardHelper _help = new PlotwizardHelper("plotwiz.chm", 11L);

		private string _currentConfigValue = string.Empty;

		private readonly string _lengthUnitFieldId = WpfPLRPlugResources.Length;

		private string _uniqueId = WpfPLRadFracResources.Composition_ID;

		private string _plotName;

		private object _nodeCxs;

		private string _currentLengthUnit = string.Empty;

		private System.Drawing.Image _imgBitmap;

		private bool _bHasInputDialog;

		private readonly string _stageOnFieldId = WpfPLRadFracResources.Stage_number_on;

		private readonly string _stageOrderFieldId = WpfPLRadFracResources.Stage_numbering_order;

		private readonly string _yAxis = WpfPLRadFracResources.Y_axis;

		private readonly string _xAxis = WpfPLRadFracResources.X_axis;

		private readonly string _ascending = WpfPLRadFracResources.Ascending;

		private readonly string _descending = WpfPLRadFracResources.Descending;

		private string[] _varNames;

		private string[] _strTitle;

		private string[] _strYAxisTitle;

		private string[] _strYTitle;

		private List<RadioButton> _basisRadBtnList;

		public static RoutedCommand OKCommand = new RoutedCommand();

		public static RoutedCommand CancelCommand = new RoutedCommand();

		private bool _bCheckDataOnly;

		internal GroupBox BasisSelection;

		internal RadioButton radBtnMole;

		internal RadioButton radBtnMass;

		internal CurvesSelectorControl CurveList;

		internal TextBlock NoCompAvailable;

		private bool _contentLoaded;

		public string TooltipContentForRibbonItem => WpfPLDryerResources.TooltipContentForRibbonItem_Comp;

		public string TooltipHeaderForRibbonItem => WpfPLRadFracResources.TooltipHeaderForRibbonItem_Comp;

		string IRibbonPlotWizardType.TagID
		{
			get
			{
				return _uniqueId;
			}
			set
			{
				_uniqueId = value;
			}
		}

		string IRibbonPlotWizardType.Name
		{
			get
			{
				return _plotName;
			}
			set
			{
				_plotName = value;
			}
		}

		object IRibbonPlotWizardType.WizardPlot
		{
			get
			{
				return _wizardPlot;
			}
			set
			{
				_wizardPlot = value as IHWizardPlot;
			}
		}

		object IRibbonPlotWizardType.CxsNode
		{
			get
			{
				return _nodeCxs;
			}
			set
			{
				_nodeCxs = value;
			}
		}

		System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

		bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

		string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

		long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

		List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _lengthUnitFieldId };

		List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

		public bool CheckDataOnly
		{
			get
			{
				return _bCheckDataOnly;
			}
			set
			{
				_bCheckDataOnly = value;
			}
		}

		public Composition()
		{
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_0013: Expected O, but got Unknown
			InitializeComponent();
			SetVariables();
			SetControls();
			_bHasInputDialog = true;
			if (_imgBitmap == null)
			{
				Assembly.GetExecutingAssembly();
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLFluidBed.Images.BinaryPX.ico");
				_imgBitmap = System.Drawing.Image.FromStream(manifestResourceStream);
			}
			CommandBinding commandBinding = new CommandBinding(OKCommand, ExecuteOKCommand, CanExecuteOKCommand);
			CommandBinding commandBinding2 = new CommandBinding(CancelCommand, ExecuteCancelCommand);
			base.CommandBindings.Add(commandBinding);
			base.CommandBindings.Add(commandBinding2);
			CurveList.Header = WpfPLRadFracResources.Select_Comp;
		}

		public void SetCaption(ref string caption)
		{
			caption = WpfPLRadFracResources.Composition_WindowTitle;
		}

		public void SetDefaultHeight(ref double defaultHeight)
		{
		}

		public void SetDefaultWidth(ref double defaultWidth)
		{
		}

		public void SetMinHeight(ref double minHeight)
		{
		}

		public void SetMinWidth(ref double minWidth)
		{
			minWidth = 300.0;
		}

		List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				List<string> list = new List<string>();
				_help.LoadXUnitsList(_context.Application.Tree, _wizardPlot, list);
				return list;
			}
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				return new List<string> { _xAxis, _yAxis };
			}
			return null;
		}

		void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
		}

		void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				_currentLengthUnit = sValue;
			}
		}

		void IRibbonPlotWizardType.ShowInputDialog()
		{
		}

		RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
		{
			if (sField.CompareTo(_lengthUnitFieldId) == 0)
			{
				return (RibbonControlType)1;
			}
			return (RibbonControlType)0;
		}

		void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
		{
		}

		void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
		{
		}

		void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
		{
			sConfigValue = _currentConfigValue;
		}

		void IRibbonPlotWizardType.SetConfigData(string sValue)
		{
			_currentConfigValue = sValue;
		}

		void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
		{
			if (HWizardPlot == null || HNode == null)
			{
				ierror = 1;
				return;
			}
			_context = HNode as IHNode;
			_wizardPlot = HWizardPlot as IHWizardPlot;
			IHNode iHNode = null;
			bool flag = false;
			for (int i = 0; i < _varNames.GetLength(0); i++)
			{
				iHNode = _context.FindNode(_varNames[i]);
				if (iHNode != null && iHNode.Elements.Count > 0)
				{
					flag = true;
				}
			}
			if (!flag)
			{
				ierror = 1;
				NoCompAvailable.Visibility = Visibility.Visible;
				CurveList.Visibility = Visibility.Collapsed;
				BasisSelection.Visibility = Visibility.Collapsed;
				return;
			}
			List<string> list = new List<string>();
			int count = iHNode.Elements.Count;
			for (int j = 0; j < count; j++)
			{
				string item = iHNode.Elements.get_Label(0, j, Type.Missing);
				list.Add(item);
			}
			CurveList.SetCurves(list.ToArray());
			CurveList.Header = WpfPLDryerResources.ComponentList_Header;
			List<string> list2 = new List<string>();
			if (string.IsNullOrEmpty(_currentConfigValue))
			{
				list2.Add(list[0].ToString());
				CurveList.SetSelectedCurves(list2.ToArray());
				iHNode = iHNode.Elements[list2[0].ToString(), Type.Missing, Type.Missing, Type.Missing, Type.Missing];
				if (iHNode == null || iHNode.Elements.Count <= 0)
				{
					ierror = 1;
					return;
				}
			}
			if (string.IsNullOrEmpty(_currentConfigValue))
			{
				_basisRadBtnList[0].IsChecked = true;
				iHNode = _context.FindNode(_varNames[0]);
				if (list.Count == 1)
				{
					CurveList.IsCheckAll = true;
					_bHasInputDialog = false;
				}
			}
			else
			{
				RestoreConfigValue(_currentConfigValue);
			}
			if (CurveList.Curves.Count == 0)
			{
				NoCompAvailable.Visibility = Visibility.Visible;
				CurveList.Visibility = Visibility.Collapsed;
				BasisSelection.Visibility = Visibility.Collapsed;
			}
			else
			{
				NoCompAvailable.Visibility = Visibility.Collapsed;
				BasisSelection.Visibility = Visibility.Visible;
				CurveList.Visibility = Visibility.Visible;
			}
		}

		public void UpdateWizardData()
		{
			IHNode iHNode = _context.FindNode("Output/HEIGHT");
			if (iHNode == null || iHNode.Elements.Count <= 0)
			{
				return;
			}
			string text = "";
			string text2 = "";
			text = _strTitle[0];
			text2 = _strYTitle[0];
			int num = -1;
			string text3 = "";
			for (int i = 0; i < _basisRadBtnList.Count; i++)
			{
				bool? flag0 = _basisRadBtnList[i].IsChecked;
				bool expected0 = true;
				if ((flag0.GetValueOrDefault() == expected0) & flag0.HasValue)
				{
					num = i;
					text3 = _strYAxisTitle[i];
					break;
				}
			}
			if (num < 0)
			{
				return;
			}
			_wizardPlot.basis = num + 1;
			_wizardPlot.SetIndependentVariable(_context, "Output/HEIGHT");
			iHNode = _context.FindNode(_varNames[num]);
			string text4 = _varNames[num] + "/";
			if (iHNode != null)
			{
				List<string> list = new List<string>(CurveList.GetSelectedCurves());
				int count = list.Count;
				_ = iHNode.Elements.Count;
				_wizardPlot.PlotVal.NVariables = count;
				try
				{
					_wizardPlot.RemoveAllDependentVariable();
					for (int j = 0; j < count; j++)
					{
						string depvar = text4 + list[j];
						_wizardPlot.AddDependentVariable(_context, depvar);
						string text5 = list[j];
						((IHPlotVal)_wizardPlot.PlotVal).set_Label(j, text5 + " " + text3);
					}
					_help.SaveXUnitsComboText(_context.Application.Tree, _wizardPlot, _currentLengthUnit);
					string xUnitString = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
					_wizardPlot.PlotVal.XAxisTitle = WpfPLDryerResources.Length_XAxisTitle + xUnitString;
				}
				catch
				{
				}
			}
			_wizardPlot.PlotVal.Title = text;
			((IHPlotVal)_wizardPlot.PlotVal).set_YAxisTitle((object)null, text2 + " " + text3);
			_currentConfigValue = SaveConfigValue();
		}

		private void ExecuteOKCommand(object sender, ExecutedRoutedEventArgs e)
		{
			UpdateWizardData();
			CurveList.UpdateCurvesStatus();
			_help.CloseForm((UserControl)this, (bool?)true);
		}

		private void CanExecuteOKCommand(object sender, CanExecuteRoutedEventArgs e)
		{
			int num = CurveList.GetSelectedCurves().Count();
			if (num == CurveList.Curves.Count)
			{
				CurveList.IsCheckAll = true;
			}
			else
			{
				string[] selectedCurves = CurveList.GetSelectedCurves();
				CurveList.IsCheckAll = false;
				CurveList.SetSelectedCurves(selectedCurves);
			}
			e.CanExecute = num != 0;
		}

		private void ExecuteCancelCommand(object sender, ExecutedRoutedEventArgs e)
		{
			_help.CloseForm((UserControl)this, (bool?)false);
		}

		private void SetVariables()
		{
			_varNames = new string[2] { "Output/GASCOMP_ML", "Output/GASCOMP_MS" };
			_strTitle = new string[1] { WpfPLDryerResources.Gas_composition };
			_strYTitle = new string[1] { "Y" };
			_strYAxisTitle = new string[2]
			{
				WpfPLRadFracResources.Composition_Title_Mole,
				WpfPLRadFracResources.Composition_Title_Mass
			};
		}

		private void SetControls()
		{
			_basisRadBtnList = new List<RadioButton>();
			_basisRadBtnList.Add(radBtnMole);
			_basisRadBtnList.Add(radBtnMass);
		}

		private string SaveConfigValue()
		{
			_ = string.Empty;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append("BasisOption=");
			for (int i = 0; i < _basisRadBtnList.Count; i++)
			{
				bool? flag1 = _basisRadBtnList[i].IsChecked;
				bool expected1 = true;
				if ((flag1.GetValueOrDefault() == expected1) & flag1.HasValue)
				{
					stringBuilder.Append(i.ToString());
					break;
				}
			}
			stringBuilder.Append(";");
			stringBuilder.Append("BasisEnable=");
			int num = 0;
			for (int j = 0; j < _basisRadBtnList.Count; j++)
			{
				if (_basisRadBtnList[j].IsEnabled)
				{
					if (num > 0)
					{
						stringBuilder.Append(",");
					}
					stringBuilder.Append(j.ToString());
					num++;
				}
			}
			stringBuilder.Append(";");
			stringBuilder.Append("CompSelection=");
			List<string> list = new List<string>(CurveList.GetSelectedCurves());
			int count = list.Count;
			for (int k = 0; k < count; k++)
			{
				if (k > 0)
				{
					stringBuilder.Append(",");
				}
				string value = list[k];
				stringBuilder.Append(value);
			}
			stringBuilder.Append(";");
			stringBuilder.Append("CheckAll=");
			stringBuilder.Append(CurveList.IsCheckAll);
			stringBuilder.Append(";");
			return stringBuilder.ToString();
		}

		private void RestoreConfigValue(string ConfigString)
		{
			string[] array = ConfigString.Split(';');
			int num = 0;
			string value = array[num].Substring(array[num].IndexOf('=') + 1);
			_basisRadBtnList[Convert.ToInt16(value)].IsChecked = true;
			num++;
			value = array[num].Substring(array[num].IndexOf('=') + 1);
			string[] array2 = value.Split(',');
			foreach (string value2 in array2)
			{
				_basisRadBtnList[Convert.ToInt16(value2)].IsEnabled = true;
			}
			num++;
			value = array[num].Substring(array[num].IndexOf('=') + 1);
			string[] array3 = value.Split(',');
			List<string> list = new List<string>();
			array2 = array3;
			foreach (string item in array2)
			{
				list.Add(item);
			}
			CurveList.SetSelectedCurves(list.ToArray());
			num++;
			value = array[num].Substring(array[num].IndexOf('=') + 1);
			CurveList.IsCheckAll = Convert.ToBoolean(value);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
				_contentLoaded = true;
			Uri resourceLocator = new Uri("/WpfPLFluidBed;component/composition.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				BasisSelection = (GroupBox)target;
				break;
			case 2:
				radBtnMole = (RadioButton)target;
				break;
			case 3:
				radBtnMass = (RadioButton)target;
				break;
			case 4:
				CurveList = (CurvesSelectorControl)target;
				break;
			case 5:
				NoCompAvailable = (TextBlock)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("WpfPLFluidBed.RibbonPlotWizardMgr")]
	public class RibbonPlotWizardMgr : IRibbonPlotWizardMgr
	{
		private static string[] supportedTypes = new string[9] { "Superficial velocity", "Interstitial velocity", "Solids volume fraction", "Pressure", "Bubble volume fraction", "Bubble rise velocity", "Bubble diameter", "Volumetric bubble flow", "Composition" };

		private IHNode _hnode;

		private IHWizardPlot _wizardPlot;

		private static List<PWRPlotType> _lspwrTypes = new List<PWRPlotType>();

		private PWRParser _pwrParser = new PWRParser();

		private Assembly _asm;

		private Dictionary<string, IRibbonPlotWizardType> _dicTagIdToPlotType;

		private IHWizardPlot _tempWizard = (CHWizardPlot)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("9E14C11F-6706-4067-8112-35CE9468F3A5")));

		public RibbonPlotWizardMgr()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			Initialize();
		}

		long IRibbonPlotWizardMgr.SupportedPlotTypes(ref List<string> lsTagIds)
		{
			lsTagIds.Clear();
			for (int i = 0; i < _lspwrTypes.Count; i++)
			{
				PWRPlotType val = _lspwrTypes[i];
				IRibbonPlotWizardType iplotType = null;
				_tempWizard.Clear();
				_pwrParser.FillDefaultPlotVal(val, ref _hnode, ref _tempWizard);
				if (DoesPlotTypeHaveData(val.TagId, ref iplotType, ref _tempWizard))
				{
					lsTagIds.Add(val.TagId);
				}
			}
			return _lspwrTypes.Count;
		}

		long IRibbonPlotWizardMgr.GetPlotType(string sTagId, ref IRibbonPlotWizardType plwType)
		{
			if (_dicTagIdToPlotType.ContainsKey(sTagId))
			{
				plwType = _dicTagIdToPlotType[sTagId];
				if (plwType == null)
				{
					return 0L;
				}
				PWRPlotType val = null;
				_pwrParser.FindPlotType(sTagId, ref _lspwrTypes, ref val);
				_pwrParser.FillDefaultPlotVal(val, ref _hnode, ref _wizardPlot);
			}
			return 0L;
		}

		void IRibbonPlotWizardMgr.SetContext(object oNode, ref object oWizard)
		{
			_hnode = oNode as IHNode;
			_wizardPlot = oWizard as IHWizardPlot;
		}

		void IRibbonPlotWizardMgr.ShowInputDialog(string sPlotName)
		{
		}

		private void InitializeWizardPlot()
		{
		}

		private void Initialize()
		{
			_asm = Assembly.GetExecutingAssembly();
			StreamReader streamReader = new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLFluidBed.Text.FluidBedpwr.txt"));
			_lspwrTypes.Clear();
			_pwrParser.ParsePwrFile(streamReader, ref _lspwrTypes);
			_dicTagIdToPlotType = new Dictionary<string, IRibbonPlotWizardType>();
			string[] array = supportedTypes;
			foreach (string text in array)
			{
				if (text == supportedTypes[0])
				{
					IRibbonPlotWizardType value = new SuperVel();
					_dicTagIdToPlotType.Add(text, value);
				}
				if (text == supportedTypes[1])
				{
					IRibbonPlotWizardType value2 = new InterVel();
					_dicTagIdToPlotType.Add(text, value2);
				}
				if (text == supportedTypes[2])
				{
					IRibbonPlotWizardType value3 = new SVolFrac();
					_dicTagIdToPlotType.Add(text, value3);
				}
				if (text == supportedTypes[3])
				{
					IRibbonPlotWizardType value4 = new Pressure();
					_dicTagIdToPlotType.Add(text, value4);
				}
				if (text == supportedTypes[4])
				{
					IRibbonPlotWizardType value5 = new BVolFrac();
					_dicTagIdToPlotType.Add(text, value5);
				}
				if (text == supportedTypes[5])
				{
					IRibbonPlotWizardType value6 = new BubbleVel();
					_dicTagIdToPlotType.Add(text, value6);
				}
				if (text == supportedTypes[6])
				{
					IRibbonPlotWizardType value7 = new BubbleDiam();
					_dicTagIdToPlotType.Add(text, value7);
				}
				if (text == supportedTypes[7])
				{
					IRibbonPlotWizardType value8 = new BubbleFlow();
					_dicTagIdToPlotType.Add(text, value8);
				}
				if (text == supportedTypes[8])
				{
					IRibbonPlotWizardType value9 = new Composition();
					_dicTagIdToPlotType.Add(text, value9);
				}
			}
		}

		private bool DoesPlotTypeHaveData(string sTagId, ref IRibbonPlotWizardType iplotType, ref IHWizardPlot iWizardPlot)
		{
			int num = 0;
			if (_dicTagIdToPlotType.ContainsKey(sTagId))
			{
				iplotType = _dicTagIdToPlotType[sTagId];
				if (iplotType == null)
				{
					return false;
				}
				object obj = iWizardPlot;
				iplotType.Context((object)_hnode, ref obj, ref num);
				if (num == 0)
				{
					return true;
				}
			}
			return false;
		}
	}
	[ProgId("WpfPLFluidBed.InterVel")]
	public class InterVel : IRibbonPlotWizardType
	{
		private IHNode _context;

		private IHWizardPlot _wizardPlot;

		private PlotwizardHelper _help = new PlotwizardHelper();

		private string _currentvelocityUnit = string.Empty;

		private string _currentLengthUnit = string.Empty;

		private string _uniqueId = PlotPWRResource.Interstitial_Velocity;

		private string _plotName;

		private object _nodeCxs;

		private System.Drawing.Image _imgBitmap;

		private bool _bHasInputDialog;

		private readonly string _velocityUnitFieldId = PlotPWRResource.Velocity;

		private readonly string _lengthUnitFieldId = PlotPWRResource.Height;

		private readonly string _stageOnFieldId = PlotPWRResource.Velocity_on;

		private readonly string _stageOrderFieldId = PlotPWRResource.Velocity_order;

		private readonly string _yAxis = WpfPLRadFracResources.Y_axis;

		private readonly string _xAxis = WpfPLRadFracResources.X_axis;

		private readonly string _ascending = WpfPLRadFracResources.Ascending;

		private readonly string _descending = WpfPLRadFracResources.Descending;

		private string _varXName;

		private string _varYName;

		private bool _bCheckDataOnly;

		public string TooltipContentForRibbonItem => PlotPWRResource.Interstitial_Velocity;

		public string TooltipHeaderForRibbonItem => PlotPWRResource.Interstitial_Velocity;

		string IRibbonPlotWizardType.TagID
		{
			get
			{
				return _uniqueId;
			}
			set
			{
				_uniqueId = value;
			}
		}

		string IRibbonPlotWizardType.Name
		{
			get
			{
				return _plotName;
			}
			set
			{
				_plotName = value;
			}
		}

		object IRibbonPlotWizardType.WizardPlot
		{
			get
			{
				return _wizardPlot;
			}
			set
			{
				_wizardPlot = value as IHWizardPlot;
			}
		}

		object IRibbonPlotWizardType.CxsNode
		{
			get
			{
				return _nodeCxs;
			}
			set
			{
				_nodeCxs = value;
			}
		}

		System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

		bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

		string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

		long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

		List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _velocityUnitFieldId, _lengthUnitFieldId };

		List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string> { _stageOrderFieldId, _stageOnFieldId };

		public bool CheckDataOnly
		{
			get
			{
				return _bCheckDataOnly;
			}
			set
			{
				_bCheckDataOnly = value;
			}
		}

		public InterVel()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			_varXName = "Output/FLUID_VEL";
			_varYName = "Output/HEIGHT";
			_bHasInputDialog = false;
			if (_imgBitmap == null)
			{
				Assembly.GetExecutingAssembly();
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLFluidBed.Images.mw.ico");
				_imgBitmap = new Bitmap(manifestResourceStream);
			}
		}

		List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
		{
			if (sFieldName.CompareTo(_velocityUnitFieldId) == 0)
			{
				List<string> list = new List<string>();
				_help.LoadXUnitsList(_context.Application.Tree, _wizardPlot, list);
				return list;
			}
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				List<string> list2 = new List<string>();
				_help.LoadUnitsList(_context.Application.Tree, _wizardPlot, list2);
				return list2;
			}
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				return new List<string> { _ascending, _descending };
			}
			if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				return new List<string> { _xAxis, _yAxis };
			}
			return null;
		}

		void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_velocityUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
			else if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetUnitString(_context.Application.Tree, _wizardPlot);
			}
		}

		void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_velocityUnitFieldId) == 0)
			{
				_currentvelocityUnit = sValue;
			}
			else if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				_currentLengthUnit = sValue;
			}
		}

		void IRibbonPlotWizardType.ShowInputDialog()
		{
		}

		RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
		{
			if (sField.CompareTo(_velocityUnitFieldId) == 0 || sField.CompareTo(_lengthUnitFieldId) == 0 || sField.CompareTo(_stageOrderFieldId) == 0 || sField.CompareTo(_stageOnFieldId) == 0)
			{
				return (RibbonControlType)1;
			}
			return (RibbonControlType)0;
		}

		void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.ReverseXAxis)
				{
					sCurrentVal = _descending;
				}
				else
				{
					sCurrentVal = _ascending;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.SwapAxises)
				{
					sCurrentVal = _yAxis;
				}
				else
				{
					sCurrentVal = _xAxis;
				}
			}
		}

		void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (sValue.CompareTo(_ascending) == 0)
				{
					_wizardPlot.PlotVal.ReverseXAxis = false;
				}
				else
				{
					_wizardPlot.PlotVal.ReverseXAxis = true;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (sValue.CompareTo(_yAxis) == 0)
				{
					_wizardPlot.PlotVal.SwapAxises = true;
				}
				else
				{
					_wizardPlot.PlotVal.SwapAxises = false;
				}
			}
		}

		void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
		{
		}

		void IRibbonPlotWizardType.SetConfigData(string sValue)
		{
		}

		void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
		{
			if (HWizardPlot == null || HNode == null)
			{
				ierror = 1;
				return;
			}
			_context = HNode as IHNode;
			_wizardPlot = HWizardPlot as IHWizardPlot;
			IHNode iHNode = _context.FindNode(_varXName);
			if (iHNode == null || iHNode.Elements.Count <= 0)
			{
				ierror = 1;
				return;
			}
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
		}

		public void UpdateWizardData()
		{
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
			_help.SaveXUnitsComboText(_context.Application.Tree, _wizardPlot, _currentvelocityUnit);
			_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currentLengthUnit);
			string text = _currentvelocityUnit;
			if (string.IsNullOrEmpty(text))
			{
				text = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(0, PlotPWRResource.Interstitial_Velocity + " " + text);
		}
	}
	[RibbonPlotWizardMgr("WpfPLFLUIDBED.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
	public class FluidBedPlotWizardModule : PlotModuleBase
	{
	}
	[ProgId("WpfPLFluidBed.Pressure")]
	public class Pressure : IRibbonPlotWizardType
	{
		private IHNode _context;

		private IHWizardPlot _wizardPlot;

		private PlotwizardHelper _help = new PlotwizardHelper();

		private string _currentPresUnit = string.Empty;

		private string _currentLengthUnit = string.Empty;

		private string _uniqueId = WpfPLRadFracResources.Pressure;

		private string _plotName;

		private object _nodeCxs;

		private System.Drawing.Image _imgBitmap;

		private bool _bHasInputDialog;

		private readonly string _presUnitFieldId = WpfPLRadFracResources.Pressure;

		private readonly string _lengthUnitFieldId = PlotPWRResource.Height;

		private readonly string _stageOnFieldId = PlotPWRResource.Pressure_on;

		private readonly string _stageOrderFieldId = PlotPWRResource.Pressure_order;

		private readonly string _yAxis = WpfPLRadFracResources.Y_axis;

		private readonly string _xAxis = WpfPLRadFracResources.X_axis;

		private readonly string _ascending = WpfPLRadFracResources.Ascending;

		private readonly string _descending = WpfPLRadFracResources.Descending;

		private string _varXName;

		private string _varYName;

		private bool _bCheckDataOnly;

		public string TooltipContentForRibbonItem => WpfPLRadFracResources.Pressure;

		public string TooltipHeaderForRibbonItem => WpfPLRadFracResources.Pressure;

		string IRibbonPlotWizardType.TagID
		{
			get
			{
				return _uniqueId;
			}
			set
			{
				_uniqueId = value;
			}
		}

		string IRibbonPlotWizardType.Name
		{
			get
			{
				return _plotName;
			}
			set
			{
				_plotName = value;
			}
		}

		object IRibbonPlotWizardType.WizardPlot
		{
			get
			{
				return _wizardPlot;
			}
			set
			{
				_wizardPlot = value as IHWizardPlot;
			}
		}

		object IRibbonPlotWizardType.CxsNode
		{
			get
			{
				return _nodeCxs;
			}
			set
			{
				_nodeCxs = value;
			}
		}

		System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

		bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

		string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

		long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

		List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _presUnitFieldId, _lengthUnitFieldId };

		List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string> { _stageOrderFieldId, _stageOnFieldId };

		public bool CheckDataOnly
		{
			get
			{
				return _bCheckDataOnly;
			}
			set
			{
				_bCheckDataOnly = value;
			}
		}

		public Pressure()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			_varYName = "Output/HEIGHT";
			_varXName = "Output/PRES";
			_bHasInputDialog = false;
			if (_imgBitmap == null)
			{
				Assembly.GetExecutingAssembly();
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLFluidBed.Images.BinaryTX.ico");
				_imgBitmap = new Bitmap(manifestResourceStream);
			}
		}

		List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
		{
			if (sFieldName.CompareTo(_presUnitFieldId) == 0)
			{
				List<string> list = new List<string>();
				_help.LoadXUnitsList(_context.Application.Tree, _wizardPlot, list);
				return list;
			}
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				List<string> list2 = new List<string>();
				_help.LoadUnitsList(_context.Application.Tree, _wizardPlot, list2);
				return list2;
			}
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				return new List<string> { _ascending, _descending };
			}
			if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				return new List<string> { _xAxis, _yAxis };
			}
			return null;
		}

		void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_presUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
			else if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetUnitString(_context.Application.Tree, _wizardPlot);
			}
		}

		void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_presUnitFieldId) == 0)
			{
				_currentPresUnit = sValue;
			}
			else if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				_currentLengthUnit = sValue;
			}
		}

		void IRibbonPlotWizardType.ShowInputDialog()
		{
		}

		RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
		{
			if (sField.CompareTo(_presUnitFieldId) == 0 || sField.CompareTo(_lengthUnitFieldId) == 0 || sField.CompareTo(_stageOrderFieldId) == 0 || sField.CompareTo(_stageOnFieldId) == 0)
			{
				return (RibbonControlType)1;
			}
			return (RibbonControlType)0;
		}

		void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.ReverseXAxis)
				{
					sCurrentVal = _descending;
				}
				else
				{
					sCurrentVal = _ascending;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.SwapAxises)
				{
					sCurrentVal = _yAxis;
				}
				else
				{
					sCurrentVal = _xAxis;
				}
			}
		}

		void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (sValue.CompareTo(_ascending) == 0)
				{
					_wizardPlot.PlotVal.ReverseXAxis = false;
				}
				else
				{
					_wizardPlot.PlotVal.ReverseXAxis = true;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (sValue.CompareTo(_yAxis) == 0)
				{
					_wizardPlot.PlotVal.SwapAxises = true;
				}
				else
				{
					_wizardPlot.PlotVal.SwapAxises = false;
				}
			}
		}

		void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
		{
		}

		void IRibbonPlotWizardType.SetConfigData(string sValue)
		{
		}

		void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
		{
			if (HWizardPlot == null || HNode == null)
			{
				ierror = 1;
				return;
			}
			_context = HNode as IHNode;
			_wizardPlot = HWizardPlot as IHWizardPlot;
			IHNode iHNode = _context.FindNode(_varXName);
			if (iHNode == null || iHNode.Elements.Count <= 0)
			{
				ierror = 1;
				return;
			}
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
		}

		public void UpdateWizardData()
		{
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
			_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currentLengthUnit);
			_help.SaveXUnitsComboText(_context.Application.Tree, _wizardPlot, _currentPresUnit);
			string text = _currentPresUnit;
			if (string.IsNullOrEmpty(text))
			{
				text = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(0, WpfPLRadFracResources.Pressure + " " + text);
		}
	}
	[ProgId("WpfPLFluidBed.SuperVel")]
	public class SuperVel : IRibbonPlotWizardType
	{
		private IHNode _context;

		private IHWizardPlot _wizardPlot;

		private PlotwizardHelper _help = new PlotwizardHelper();

		private string _currentvelocityUnit = string.Empty;

		private string _currentLengthUnit = string.Empty;

		private string _uniqueId = PlotPWRResource.Superficial_Velocity;

		private string _plotName;

		private object _nodeCxs;

		private System.Drawing.Image _imgBitmap;

		private bool _bHasInputDialog;

		private readonly string _velocityUnitFieldId = PlotPWRResource.Velocity;

		private readonly string _lengthUnitFieldId = PlotPWRResource.Height;

		private readonly string _stageOnFieldId = PlotPWRResource.Velocity_on;

		private readonly string _stageOrderFieldId = PlotPWRResource.Velocity_order;

		private readonly string _yAxis = WpfPLRadFracResources.Y_axis;

		private readonly string _xAxis = WpfPLRadFracResources.X_axis;

		private readonly string _ascending = WpfPLRadFracResources.Ascending;

		private readonly string _descending = WpfPLRadFracResources.Descending;

		private string _varXName;

		private string _varYName;

		private bool _bCheckDataOnly;

		public string TooltipContentForRibbonItem => PlotPWRResource.Superficial_Velocity;

		public string TooltipHeaderForRibbonItem => PlotPWRResource.Superficial_Velocity;

		string IRibbonPlotWizardType.TagID
		{
			get
			{
				return _uniqueId;
			}
			set
			{
				_uniqueId = value;
			}
		}

		string IRibbonPlotWizardType.Name
		{
			get
			{
				return _plotName;
			}
			set
			{
				_plotName = value;
			}
		}

		object IRibbonPlotWizardType.WizardPlot
		{
			get
			{
				return _wizardPlot;
			}
			set
			{
				_wizardPlot = value as IHWizardPlot;
			}
		}

		object IRibbonPlotWizardType.CxsNode
		{
			get
			{
				return _nodeCxs;
			}
			set
			{
				_nodeCxs = value;
			}
		}

		System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

		bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

		string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

		long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

		List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _velocityUnitFieldId, _lengthUnitFieldId };

		List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string> { _stageOrderFieldId, _stageOnFieldId };

		public bool CheckDataOnly
		{
			get
			{
				return _bCheckDataOnly;
			}
			set
			{
				_bCheckDataOnly = value;
			}
		}

		public SuperVel()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			_varXName = "Output/VELOC_LOC";
			_varYName = "Output/HEIGHT";
			_bHasInputDialog = false;
			if (_imgBitmap == null)
			{
				Assembly.GetExecutingAssembly();
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLFluidBed.Images.mw.ico");
				_imgBitmap = new Bitmap(manifestResourceStream);
			}
		}

		List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
		{
			if (sFieldName.CompareTo(_velocityUnitFieldId) == 0)
			{
				List<string> list = new List<string>();
				_help.LoadXUnitsList(_context.Application.Tree, _wizardPlot, list);
				return list;
			}
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				List<string> list2 = new List<string>();
				_help.LoadUnitsList(_context.Application.Tree, _wizardPlot, list2);
				return list2;
			}
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				return new List<string> { _ascending, _descending };
			}
			if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				return new List<string> { _xAxis, _yAxis };
			}
			return null;
		}

		void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_velocityUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
			else if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetUnitString(_context.Application.Tree, _wizardPlot);
			}
		}

		void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_velocityUnitFieldId) == 0)
			{
				_currentvelocityUnit = sValue;
			}
			else if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				_currentLengthUnit = sValue;
			}
		}

		void IRibbonPlotWizardType.ShowInputDialog()
		{
		}

		RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
		{
			if (sField.CompareTo(_velocityUnitFieldId) == 0 || sField.CompareTo(_lengthUnitFieldId) == 0 || sField.CompareTo(_stageOrderFieldId) == 0 || sField.CompareTo(_stageOnFieldId) == 0)
			{
				return (RibbonControlType)1;
			}
			return (RibbonControlType)0;
		}

		void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.ReverseXAxis)
				{
					sCurrentVal = _descending;
				}
				else
				{
					sCurrentVal = _ascending;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.SwapAxises)
				{
					sCurrentVal = _yAxis;
				}
				else
				{
					sCurrentVal = _xAxis;
				}
			}
		}

		void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (sValue.CompareTo(_ascending) == 0)
				{
					_wizardPlot.PlotVal.ReverseXAxis = false;
				}
				else
				{
					_wizardPlot.PlotVal.ReverseXAxis = true;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (sValue.CompareTo(_yAxis) == 0)
				{
					_wizardPlot.PlotVal.SwapAxises = true;
				}
				else
				{
					_wizardPlot.PlotVal.SwapAxises = false;
				}
			}
		}

		void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
		{
		}

		void IRibbonPlotWizardType.SetConfigData(string sValue)
		{
		}

		void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
		{
			if (HWizardPlot == null || HNode == null)
			{
				ierror = 1;
				return;
			}
			_context = HNode as IHNode;
			_wizardPlot = HWizardPlot as IHWizardPlot;
			IHNode iHNode = _context.FindNode(_varXName);
			if (iHNode == null || iHNode.Elements.Count <= 0)
			{
				ierror = 1;
				return;
			}
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
		}

		public void UpdateWizardData()
		{
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
			_help.SaveXUnitsComboText(_context.Application.Tree, _wizardPlot, _currentvelocityUnit);
			_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currentLengthUnit);
			string text = _currentvelocityUnit;
			if (string.IsNullOrEmpty(text))
			{
				text = _help.GetXUnitString(_context.Application.Tree, _wizardPlot);
			}
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(0, PlotPWRResource.Superficial_Velocity + " " + text);
		}
	}
	[ProgId("WpfPLFluidBed.SVolFrac")]
	public class SVolFrac : IRibbonPlotWizardType
	{
		private IHNode _context;

		private IHWizardPlot _wizardPlot;

		private PlotwizardHelper _help = new PlotwizardHelper();

		private string _currentLengthUnit = string.Empty;

		private string _uniqueId = PlotPWRResource.Solids_Volume_Fraction;

		private string _plotName;

		private object _nodeCxs;

		private System.Drawing.Image _imgBitmap;

		private bool _bHasInputDialog;

		private readonly string _lengthUnitFieldId = PlotPWRResource.Height;

		private readonly string _stageOnFieldId = PlotPWRResource.Fraction_on;

		private readonly string _stageOrderFieldId = PlotPWRResource.Fraction_order;

		private readonly string _yAxis = WpfPLRadFracResources.Y_axis;

		private readonly string _xAxis = WpfPLRadFracResources.X_axis;

		private readonly string _ascending = WpfPLRadFracResources.Ascending;

		private readonly string _descending = WpfPLRadFracResources.Descending;

		private string _varXName;

		private string _varYName;

		private bool _bCheckDataOnly;

		public string TooltipContentForRibbonItem => PlotPWRResource.Solids_Volume_Fraction;

		public string TooltipHeaderForRibbonItem => PlotPWRResource.Solids_Volume_Fraction;

		string IRibbonPlotWizardType.TagID
		{
			get
			{
				return _uniqueId;
			}
			set
			{
				_uniqueId = value;
			}
		}

		string IRibbonPlotWizardType.Name
		{
			get
			{
				return _plotName;
			}
			set
			{
				_plotName = value;
			}
		}

		object IRibbonPlotWizardType.WizardPlot
		{
			get
			{
				return _wizardPlot;
			}
			set
			{
				_wizardPlot = value as IHWizardPlot;
			}
		}

		object IRibbonPlotWizardType.CxsNode
		{
			get
			{
				return _nodeCxs;
			}
			set
			{
				_nodeCxs = value;
			}
		}

		System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

		bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

		string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

		long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

		List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _lengthUnitFieldId };

		List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string> { _stageOrderFieldId, _stageOnFieldId };

		public bool CheckDataOnly
		{
			get
			{
				return _bCheckDataOnly;
			}
			set
			{
				_bCheckDataOnly = value;
			}
		}

		public SVolFrac()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			_varXName = "Output/VOLFRAC";
			_varYName = "Output/HEIGHT";
			_bHasInputDialog = false;
			if (_imgBitmap == null)
			{
				Assembly.GetExecutingAssembly();
				Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLFluidBed.Images.BinaryTX.ico");
				_imgBitmap = new Bitmap(manifestResourceStream);
			}
		}

		List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				List<string> list = new List<string>();
				_help.LoadUnitsList(_context.Application.Tree, _wizardPlot, list);
				return list;
			}
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				return new List<string> { _ascending, _descending };
			}
			if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				return new List<string> { _xAxis, _yAxis };
			}
			return null;
		}

		void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				sCurrentVal = _help.GetUnitString(_context.Application.Tree, _wizardPlot);
			}
		}

		void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
			{
				_currentLengthUnit = sValue;
			}
		}

		void IRibbonPlotWizardType.ShowInputDialog()
		{
		}

		RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
		{
			if (sField.CompareTo(_lengthUnitFieldId) == 0 || sField.CompareTo(_stageOrderFieldId) == 0 || sField.CompareTo(_stageOnFieldId) == 0)
			{
				return (RibbonControlType)1;
			}
			return (RibbonControlType)0;
		}

		void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.ReverseXAxis)
				{
					sCurrentVal = _descending;
				}
				else
				{
					sCurrentVal = _ascending;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (_wizardPlot.PlotVal.SwapAxises)
				{
					sCurrentVal = _yAxis;
				}
				else
				{
					sCurrentVal = _xAxis;
				}
			}
		}

		void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
		{
			if (sFieldName.CompareTo(_stageOrderFieldId) == 0)
			{
				if (sValue.CompareTo(_ascending) == 0)
				{
					_wizardPlot.PlotVal.ReverseXAxis = false;
				}
				else
				{
					_wizardPlot.PlotVal.ReverseXAxis = true;
				}
			}
			else if (sFieldName.CompareTo(_stageOnFieldId) == 0)
			{
				if (sValue.CompareTo(_yAxis) == 0)
				{
					_wizardPlot.PlotVal.SwapAxises = true;
				}
				else
				{
					_wizardPlot.PlotVal.SwapAxises = false;
				}
			}
		}

		void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
		{
		}

		void IRibbonPlotWizardType.SetConfigData(string sValue)
		{
		}

		void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
		{
			if (HWizardPlot == null || HNode == null)
			{
				ierror = 1;
				return;
			}
			_context = HNode as IHNode;
			_wizardPlot = HWizardPlot as IHWizardPlot;
			IHNode iHNode = _context.FindNode(_varXName);
			if (iHNode == null || iHNode.Elements.Count <= 0)
			{
				ierror = 1;
				return;
			}
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
		}

		public void UpdateWizardData()
		{
			_wizardPlot.RemoveAllDependentVariable();
			_wizardPlot.SetIndependentVariable(_context, _varXName);
			_wizardPlot.AddDependentVariable(_context, _varYName);
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(0, PlotPWRResource.Solids_Volume_Fraction);
			_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currentLengthUnit);
		}
	}
}
namespace WpfPLFluidBed.Properties
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (resourceMan == null)
				{
					resourceMan = new ResourceManager("WpfPLFluidBed.Properties.Resources", typeof(Resources).Assembly);
				}
				return resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return resourceCulture;
			}
			set
			{
				resourceCulture = value;
			}
		}

		internal Resources()
		{
		}
	}
}
