﻿
//  .NET IL Disassembler.  Version 9.0.23



// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .hash = (1B 76 1C 70 5A B0 DF 24 A6 58 38 30 EE DE 63 1C   // .v.pZ..$.X80..c.
           DD BF 1B AE ) 
  .ver 4:0:0:0
}
.assembly WpfPLBatchSep.resources
{
  .custom instance void [mscorlib]System.Reflection.AssemblyTitleAttribute::.ctor(string) = ( 01 00 0D 57 70 66 50 4C 42 61 74 63 68 53 65 70   // ...WpfPLBatchSep
                                                                                              00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyDescriptionAttribute::.ctor(string) = ( 01 00 FF 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyCompanyAttribute::.ctor(string) = ( 01 00 16 41 73 70 65 6E 20 54 65 63 68 6E 6F 6C   // ...Aspen Technol
                                                                                                6F 67 79 2C 20 49 6E 63 2E 00 00 )                // ogy, Inc...
  .custom instance void [mscorlib]System.Reflection.AssemblyProductAttribute::.ctor(string) = ( 01 00 0D 57 70 66 50 4C 42 61 74 63 68 53 65 70   // ...WpfPLBatchSep
                                                                                                00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyCopyrightAttribute::.ctor(string) = ( 01 00 2F 43 6F 70 79 72 69 67 68 74 20 C2 A9 20   // ../Copyright .. 
                                                                                                  41 73 70 65 6E 20 54 65 63 68 6E 6F 6C 6F 67 79   // Aspen Technology
                                                                                                  2C 20 49 6E 63 2E 20 32 30 31 30 20 2D 20 32 30   // , Inc. 2010 - 20
                                                                                                  32 34 00 00 )                                     // 24..
  .custom instance void [mscorlib]System.Reflection.AssemblyTrademarkAttribute::.ctor(string) = ( 01 00 FF 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyFileVersionAttribute::.ctor(string) = ( 01 00 0A 34 31 2E 30 2E 30 2E 36 31 34 00 00 )    // ...41.0.0.614..
  .hash algorithm 0x00008004
  .ver 41:0:0:614
  .locale = (65 00 6E 00 2D 00 55 00 53 00 00 00 )             // e.n.-.U.S...
}
.mresource public 'WpfPLBatchSep.g.en-US.resources'
{
  // Offset: 0x00000000 Length: 0x0000A6AB
  // WARNING: managed resource file 'WpfPLBatchSep.g.en-US.resources' created
}
.module WpfPLBatchSep.resources.dll
// MVID: {576aec54-bad2-4796-a0f6-9652d9f5bada}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000001    //  ILONLY
// Image base: 0x0000023F75D00000

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file WpfPLBatchSep.resources.dll.res
