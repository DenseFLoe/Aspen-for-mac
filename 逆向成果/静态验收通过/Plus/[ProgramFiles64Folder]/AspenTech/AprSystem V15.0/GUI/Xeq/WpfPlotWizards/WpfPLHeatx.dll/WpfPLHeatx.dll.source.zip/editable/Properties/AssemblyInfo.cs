using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("WpfPLMCompr")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("WpfPLMCompr")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, INC. 2010 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: Guid("1e3a45a6-07a8-4117-afc2-0948923c0f73")]
[assembly: AssemblyVersion("41.0.0.614")]
