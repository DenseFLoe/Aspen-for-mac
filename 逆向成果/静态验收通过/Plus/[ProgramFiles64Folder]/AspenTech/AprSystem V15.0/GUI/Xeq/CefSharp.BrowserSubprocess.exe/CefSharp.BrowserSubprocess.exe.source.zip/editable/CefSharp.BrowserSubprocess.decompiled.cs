using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using CefSharp.RenderProcess;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("CefSharp.BrowserSubprocess")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCompany("The CefSharp Authors")]
[assembly: AssemblyProduct("CefSharp")]
[assembly: AssemblyCopyright("Copyright © 2023 The CefSharp Authors")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("113.1.40.0")]
[assembly: CLSCompliant(false)]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("113.1.40.0")]
namespace CefSharp.BrowserSubprocess;

public class Program
{
	public static int Main(string[] args)
	{
		IRenderProcessHandler handler = null;
		WcfBrowserSubprocessExecutable wcfBrowserSubprocessExecutable = new WcfBrowserSubprocessExecutable();
		int result = wcfBrowserSubprocessExecutable.Main(args, handler);
		return result;
	}
}
