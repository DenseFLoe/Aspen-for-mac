using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using DevExpress.Charts.Model;
using DevExpress.DataVisualization.Native;
using DevExpress.Drawing;
using DevExpress.Utils;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("DevExpress.DataVisualization.Core")]
[assembly: AssemblyDescription("DevExpress.DataVisualization.Core")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Developer Express Inc.")]
[assembly: AssemblyProduct("DevExpress.DataVisualization.Core")]
[assembly: AssemblyCopyright("Copyright © 2000-2024 Developer Express Inc.")]
[assembly: AssemblyTrademark("DevExpress.DataVisualization.Core")]
[assembly: CLSCompliant(true)]
[assembly: AllowPartiallyTrustedCallers]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: AssemblyFileVersion("23.2.4.0")]
[assembly: SatelliteContractVersion("23.2.0.0")]
[assembly: TargetFramework(".NETFramework,Version=v4.5.2", FrameworkDisplayName = ".NET Framework 4.5.2")]
[assembly: AssemblyVersion("23.2.4.0")]
namespace DevExpress.Charts.Model
{
	public class ChartAppearanceOptions : ModelElement
	{
		private ChartAppearance chartAppearance;

		private LegendAppearance legendAppearance;

		private DiagramAppearance diagramAppearance;

		private SeriesAppearance seriesAppearance;

		public ChartAppearance ChartAppearance
		{
			get
			{
				return chartAppearance;
			}
			set
			{
				if (chartAppearance != value)
				{
					UpdateElementParent(chartAppearance, null);
					chartAppearance = value;
					UpdateElementParent(chartAppearance, this);
				}
			}
		}

		public LegendAppearance LegendAppearance
		{
			get
			{
				return legendAppearance;
			}
			set
			{
				if (legendAppearance != value)
				{
					UpdateElementParent(legendAppearance, null);
					legendAppearance = value;
					UpdateElementParent(legendAppearance, this);
				}
			}
		}

		public DiagramAppearance DiagramAppearance
		{
			get
			{
				return diagramAppearance;
			}
			set
			{
				if (diagramAppearance != value)
				{
					UpdateElementParent(diagramAppearance, null);
					diagramAppearance = value;
					UpdateElementParent(diagramAppearance, this);
				}
			}
		}

		public SeriesAppearance SeriesAppearance
		{
			get
			{
				return seriesAppearance;
			}
			set
			{
				if (seriesAppearance != value)
				{
					UpdateElementParent(seriesAppearance, null);
					seriesAppearance = value;
					UpdateElementParent(seriesAppearance, this);
				}
			}
		}
	}
	public class ChartAppearance : ModelElement
	{
		private Border border;

		private FillStyle fillStyle;

		private RectangleIndents padding;

		private ChartTitleAppearance titleAppearance;

		public ColorARGB BackColor { get; set; }

		public Border Border
		{
			get
			{
				return border;
			}
			set
			{
				if (border != value)
				{
					UpdateElementParent(border, null);
					border = value;
					UpdateElementParent(border, this);
				}
			}
		}

		public FillStyle FillStyle
		{
			get
			{
				return fillStyle;
			}
			set
			{
				if (fillStyle != value)
				{
					UpdateElementParent(fillStyle, null);
					fillStyle = value;
					UpdateElementParent(fillStyle, this);
				}
			}
		}

		public RectangleIndents Padding
		{
			get
			{
				return padding;
			}
			set
			{
				if (padding != value)
				{
					UpdateElementParent(padding, null);
					padding = value;
					UpdateElementParent(padding, this);
				}
			}
		}

		public ChartTitleAppearance TitleAppearance
		{
			get
			{
				return titleAppearance;
			}
			set
			{
				if (titleAppearance != value)
				{
					UpdateElementParent(titleAppearance, null);
					titleAppearance = value;
					UpdateElementParent(titleAppearance, this);
				}
			}
		}
	}
	public class LegendAppearance : ModelElement
	{
		private Border border;

		private FillStyle fillStyle;

		private Shadow shadow;

		private RectangleIndents margins;

		private RectangleIndents padding;

		public ColorARGB BackColor { get; set; }

		public Border Border
		{
			get
			{
				return border;
			}
			set
			{
				if (border != value)
				{
					UpdateElementParent(border, null);
					border = value;
					UpdateElementParent(border, this);
				}
			}
		}

		public ColorARGB TextColor { get; set; }

		public FillStyle FillStyle
		{
			get
			{
				return fillStyle;
			}
			set
			{
				if (fillStyle != value)
				{
					UpdateElementParent(fillStyle, null);
					fillStyle = value;
					UpdateElementParent(fillStyle, this);
				}
			}
		}

		public Shadow Shadow
		{
			get
			{
				return shadow;
			}
			set
			{
				if (shadow != value)
				{
					UpdateElementParent(shadow, null);
					shadow = value;
					UpdateElementParent(shadow, this);
				}
			}
		}

		public RectangleIndents Margins
		{
			get
			{
				return margins;
			}
			set
			{
				if (margins != value)
				{
					UpdateElementParent(margins, null);
					margins = value;
					UpdateElementParent(margins, this);
				}
			}
		}

		public RectangleIndents Padding
		{
			get
			{
				return padding;
			}
			set
			{
				if (padding != value)
				{
					UpdateElementParent(padding, null);
					padding = value;
					UpdateElementParent(padding, this);
				}
			}
		}
	}
	public class DiagramAppearance : ModelElement
	{
		private AxisAppearance axesAppearance;

		private FillStyle fillStyle;

		private Shadow shadow;

		private RectangleIndents margins;

		public ColorARGB BackColor { get; set; }

		public ColorARGB BorderColor { get; set; }

		public bool BorderVisible { get; set; }

		public AxisAppearance AxesAppearance
		{
			get
			{
				return axesAppearance;
			}
			set
			{
				if (axesAppearance != value)
				{
					UpdateElementParent(axesAppearance, null);
					axesAppearance = value;
					UpdateElementParent(axesAppearance, this);
				}
			}
		}

		public FillStyle FillStyle
		{
			get
			{
				return fillStyle;
			}
			set
			{
				if (fillStyle != value)
				{
					UpdateElementParent(fillStyle, null);
					fillStyle = value;
					UpdateElementParent(fillStyle, this);
				}
			}
		}

		public Shadow Shadow
		{
			get
			{
				return shadow;
			}
			set
			{
				if (shadow != value)
				{
					UpdateElementParent(shadow, null);
					shadow = value;
					UpdateElementParent(shadow, this);
				}
			}
		}

		public RectangleIndents Margins
		{
			get
			{
				return margins;
			}
			set
			{
				if (margins != value)
				{
					UpdateElementParent(margins, null);
					margins = value;
					UpdateElementParent(margins, this);
				}
			}
		}
	}
	public class AxisAppearance : ModelElement
	{
		private FillStyle interlacedFillStyle;

		private LineStyle gridLinesLineStyle;

		private LineStyle gridLinesMinorLineStyle;

		private AxisTitleAppearance titleAppearance;

		public ColorARGB Color { get; set; }

		public int Thickness { get; set; } = 1;

		public bool Interlaced { get; set; }

		public FillStyle InterlacedFillStyle
		{
			get
			{
				return interlacedFillStyle;
			}
			set
			{
				if (interlacedFillStyle != value)
				{
					UpdateElementParent(interlacedFillStyle, null);
					interlacedFillStyle = value;
					UpdateElementParent(interlacedFillStyle, this);
				}
			}
		}

		public ColorARGB InterlacedColor { get; set; }

		public ColorARGB GridLinesColor { get; set; }

		public LineStyle GridLinesLineStyle
		{
			get
			{
				return gridLinesLineStyle;
			}
			set
			{
				if (gridLinesLineStyle != value)
				{
					UpdateElementParent(gridLinesLineStyle, null);
					gridLinesLineStyle = value;
					UpdateElementParent(gridLinesLineStyle, this);
				}
			}
		}

		public ColorARGB GridLinesMinorColor { get; set; }

		public LineStyle GridLinesMinorLineStyle
		{
			get
			{
				return gridLinesMinorLineStyle;
			}
			set
			{
				if (gridLinesMinorLineStyle != value)
				{
					UpdateElementParent(gridLinesMinorLineStyle, null);
					gridLinesMinorLineStyle = value;
					UpdateElementParent(gridLinesMinorLineStyle, this);
				}
			}
		}

		public ColorARGB LabelTextColor { get; set; }

		public AxisTitleAppearance TitleAppearance
		{
			get
			{
				return titleAppearance;
			}
			set
			{
				if (titleAppearance != value)
				{
					UpdateElementParent(titleAppearance, null);
					titleAppearance = value;
					UpdateElementParent(titleAppearance, this);
				}
			}
		}
	}
	public class SeriesAppearance : ModelElement
	{
		private Border border;

		private FillStyle fillStyle;

		private Shadow shadow;

		private LineStyle lineStyle;

		private MarkerAppearance markerAppearance;

		private SeriesLabelAppearance labelAppearance;

		public ColorARGB Color { get; set; } = ColorARGB.Empty;

		public Border Border
		{
			get
			{
				return border;
			}
			set
			{
				if (border != value)
				{
					UpdateElementParent(border, null);
					border = value;
					UpdateElementParent(border, this);
				}
			}
		}

		public FillStyle FillStyle
		{
			get
			{
				return fillStyle;
			}
			set
			{
				if (fillStyle != value)
				{
					UpdateElementParent(fillStyle, null);
					fillStyle = value;
					UpdateElementParent(fillStyle, this);
				}
			}
		}

		public Shadow Shadow
		{
			get
			{
				return shadow;
			}
			set
			{
				if (shadow != value)
				{
					UpdateElementParent(shadow, null);
					shadow = value;
					UpdateElementParent(shadow, this);
				}
			}
		}

		public LineStyle LineStyle
		{
			get
			{
				return lineStyle;
			}
			set
			{
				if (lineStyle != value)
				{
					UpdateElementParent(lineStyle, null);
					lineStyle = value;
					UpdateElementParent(lineStyle, this);
				}
			}
		}

		public MarkerAppearance MarkerAppearance
		{
			get
			{
				return markerAppearance;
			}
			set
			{
				if (markerAppearance != value)
				{
					UpdateElementParent(markerAppearance, null);
					markerAppearance = value;
					UpdateElementParent(markerAppearance, this);
				}
			}
		}

		public SeriesLabelAppearance LabelAppearance
		{
			get
			{
				return labelAppearance;
			}
			set
			{
				if (labelAppearance != value)
				{
					UpdateElementParent(labelAppearance, null);
					labelAppearance = value;
					UpdateElementParent(labelAppearance, this);
				}
			}
		}
	}
	public class MarkerAppearance : ModelElement
	{
		private FillStyle fillStyle;

		public ColorARGB BorderColor { get; set; }

		public bool BorderVisible { get; set; }

		public FillStyle FillStyle
		{
			get
			{
				return fillStyle;
			}
			set
			{
				if (fillStyle != value)
				{
					UpdateElementParent(fillStyle, null);
					fillStyle = value;
					UpdateElementParent(fillStyle, this);
				}
			}
		}
	}
	public class SeriesLabelAppearance : ModelElement
	{
		private Border border;

		private FillStyle fillStyle;

		private LineStyle lineStyle;

		private Shadow shadow;

		public ColorARGB BackColor { get; set; }

		public Border Border
		{
			get
			{
				return border;
			}
			set
			{
				UpdateElementParent(border, null);
				border = value;
				UpdateElementParent(border, this);
			}
		}

		public FillStyle FillStyle
		{
			get
			{
				return fillStyle;
			}
			set
			{
				if (fillStyle != value)
				{
					UpdateElementParent(fillStyle, null);
					fillStyle = value;
					UpdateElementParent(fillStyle, this);
				}
			}
		}

		public ColorARGB LineColor { get; set; }

		public int LineLength { get; set; }

		public LineStyle LineStyle
		{
			get
			{
				return lineStyle;
			}
			set
			{
				if (lineStyle != value)
				{
					UpdateElementParent(lineStyle, null);
					lineStyle = value;
					UpdateElementParent(lineStyle, this);
				}
			}
		}

		public bool LineVisible { get; set; }

		public Shadow Shadow
		{
			get
			{
				return shadow;
			}
			set
			{
				if (shadow != value)
				{
					UpdateElementParent(shadow, null);
					shadow = value;
					UpdateElementParent(shadow, this);
				}
			}
		}

		public ColorARGB TextColor { get; set; }
	}
	public abstract class TitleAppearanceBase : ModelElement
	{
		public ColorARGB TextColor { get; set; }
	}
	public class AxisTitleAppearance : TitleAppearanceBase
	{
	}
	public class ChartTitleAppearance : TitleAppearanceBase
	{
		public int Indent { get; set; } = 5;
	}
	public class Palette : ModelElement
	{
		private readonly List<PaletteEntry> entries;

		public List<PaletteEntry> Entries => entries;

		public Palette(ModelElement parent)
			: base(parent)
		{
			entries = new List<PaletteEntry>();
		}

		public Palette()
		{
			entries = new List<PaletteEntry>();
		}

		public Palette(List<PaletteEntry> entries)
		{
			this.entries = entries;
		}
	}
	public struct PaletteEntry
	{
		public ColorARGB Color { get; }

		public ColorARGB Color2 { get; }

		public PaletteEntry(ColorARGB color, ColorARGB color2)
		{
			Color = color;
			Color2 = color2;
		}

		public PaletteEntry(ColorARGB color)
			: this(color, ColorARGB.Empty)
		{
		}
	}
	public class Border : ModelElement
	{
		public int Thickness { get; set; } = 1;

		public ColorARGB Color { get; set; } = ColorARGB.Empty;

		public Border()
			: this(null)
		{
		}

		public Border(ModelElement parent)
			: base(parent)
		{
		}
	}
	public class Shadow : ModelElement
	{
		public ColorARGB Color { get; set; } = ColorARGB.Empty;

		public int Size { get; set; } = 2;
	}
	public enum FillMode
	{
		Empty,
		Solid,
		Gradient
	}
	public enum GradientMode
	{
		TopToBottom,
		BottomToTop,
		LeftToRight,
		RightToLeft,
		TopLeftToBottomRight,
		BottomRightToTopLeft,
		TopRightToBottomLeft,
		BottomLeftToTopRight,
		FromCenterHorizontal,
		ToCenterHorizontal,
		FromCenterVertical,
		ToCenterVertical
	}
	public enum DashStyle
	{
		Empty,
		Solid,
		Dash,
		Dot,
		DashDot,
		DashDotDot
	}
	public class FillOptions : ModelElement
	{
		public ColorARGB Color2 { get; set; }

		public GradientMode GradientMode { get; set; }
	}
	public class FillStyle : ModelElement
	{
		private FillOptions options;

		public FillMode FillMode { get; set; }

		public FillOptions Options
		{
			get
			{
				return options;
			}
			set
			{
				if (options != value)
				{
					UpdateElementParent(options, null);
					options = value;
					UpdateElementParent(options, this);
				}
			}
		}
	}
	public class LineStyle : ModelElement
	{
		public int Thickness { get; set; } = 1;

		public DashStyle DashStyle { get; set; } = DashStyle.Solid;
	}
	public class RectangleIndents : ModelElement
	{
		public const int Undefined = -1;

		public int Left { get; set; }

		public int Top { get; set; }

		public int Right { get; set; }

		public int Bottom { get; set; }

		public int All
		{
			get
			{
				if (Left != Top || Left != Right || Left != Bottom)
				{
					return -1;
				}
				return Left;
			}
			set
			{
				Left = value;
				Top = value;
				Right = value;
				Bottom = value;
			}
		}

		public RectangleIndents(int left, int top, int right, int bottom)
		{
			Left = left;
			Top = top;
			Right = right;
			Bottom = bottom;
		}

		public RectangleIndents(int all)
			: this(all, all, all, all)
		{
		}

		public RectangleIndents()
			: this(0)
		{
		}
	}
	public class LabelAppearance : ModelElement
	{
		public bool Visible { get; set; } = true;

		public ColorARGB TextColor { get; set; }

		public ColorARGB TextGlowColor { get; set; }

		public FontModel Font { get; set; }

		public StringAlignment HorizontalAlignment { get; set; }

		public StringAlignment VerticalAlignment { get; set; }
	}
	public class HierarchicalItemAppearance : ModelElement
	{
		private LabelAppearance labelAppearance = new LabelAppearance();

		public bool BorderVisible { get; set; } = true;

		public ColorARGB BorderColor { get; set; } = new ColorARGB(64, 0, 0, 0);

		public float BorderBrightnessCoeff { get; set; } = 1f;

		public LabelAppearance LabelAppearance
		{
			get
			{
				return labelAppearance;
			}
			set
			{
				if (labelAppearance != value)
				{
					UpdateElementParent(labelAppearance, null);
					labelAppearance = value;
					UpdateElementParent(labelAppearance, this);
				}
			}
		}
	}
	public abstract class AreaSeriesBase : MarkerCartesianSeriesBase, ISupportTransparencySeries
	{
		public byte Transparency { get; set; } = 120;
	}
	public class AreaSeries : AreaSeriesBase, ISupportColorEachSeries
	{
		public override bool ActualColorEach => ColorEach;

		public bool ColorEach { get; set; }
	}
	public class SplineAreaSeries : AreaSeries
	{
	}
	public class RangeAreaSeries : AreaSeries
	{
	}
	public class StepAreaSeries : AreaSeries
	{
	}
	public class StackedAreaSeries : AreaSeriesBase
	{
		public override bool ActualColorEach => false;
	}
	public class StackedStepAreaSeries : StackedAreaSeries
	{
	}
	public class StackedSplineAreaSeries : StackedAreaSeries
	{
	}
	public class FullStackedAreaSeries : StackedAreaSeries
	{
	}
	public class FullStackedStepAreaSeries : StackedAreaSeries
	{
	}
	public class FullStackedSplineAreaSeries : StackedAreaSeries
	{
	}
	public class RadarAreaSeries : RadarLineSeries, ISupportTransparencySeries
	{
		public byte Transparency { get; set; } = 120;
	}
	public class RadarRangeAreaSeries : RadarAreaSeries
	{
	}
	public class PolarAreaSeries : PolarLineSeries, ISupportTransparencySeries
	{
		public byte Transparency { get; set; } = 120;
	}
	public class PolarRangeAreaSeries : PolarAreaSeries
	{
	}
	public enum AxisPosition
	{
		Left,
		Right,
		Top,
		Bottom
	}
	public enum DateTimeGridAlignment
	{
		Millisecond,
		Second,
		Minute,
		Hour,
		Day,
		Week,
		Month,
		Quarter,
		Year
	}
	public class AxisTitle : TitleBase
	{
		private string text;

		private bool visible;

		public string Text
		{
			get
			{
				return text;
			}
			set
			{
				if (text != value)
				{
					text = value;
				}
			}
		}

		public bool Visible
		{
			get
			{
				return visible;
			}
			set
			{
				if (visible != value)
				{
					visible = value;
				}
			}
		}

		public AxisTitle(Axis parent)
			: base(parent)
		{
		}
	}
	public abstract class AxisBase : ModelElement
	{
		private bool gridLinesVisible;

		private bool gridLinesMinorVisible;

		private AxisLabel label;

		private AxisRange range;

		private AxisAppearance appearance;

		private bool visible = true;

		private int? gridSpacingFactor;

		public bool GridLinesVisible
		{
			get
			{
				return gridLinesVisible;
			}
			set
			{
				if (gridLinesVisible != value)
				{
					gridLinesVisible = value;
				}
			}
		}

		public bool GridLinesMinorVisible
		{
			get
			{
				return gridLinesMinorVisible;
			}
			set
			{
				if (gridLinesMinorVisible != value)
				{
					gridLinesMinorVisible = value;
				}
			}
		}

		public AxisLabel Label
		{
			get
			{
				return label;
			}
			set
			{
				if (label != value)
				{
					label = value;
				}
			}
		}

		public AxisRange Range
		{
			get
			{
				return range;
			}
			set
			{
				if (range != value)
				{
					range = value;
				}
			}
		}

		public AxisAppearance Appearance
		{
			get
			{
				return appearance;
			}
			set
			{
				if (appearance != value)
				{
					UpdateElementParent(appearance, null);
					appearance = value;
					UpdateElementParent(appearance, this);
				}
			}
		}

		public bool Visible
		{
			get
			{
				return visible;
			}
			set
			{
				if (visible != value)
				{
					visible = value;
				}
			}
		}

		public int? GridSpacingFactor
		{
			get
			{
				return gridSpacingFactor;
			}
			set
			{
				if (gridSpacingFactor != value)
				{
					gridSpacingFactor = value;
				}
			}
		}

		protected AxisBase()
			: this(null)
		{
		}

		protected AxisBase(Chart parent)
			: base(parent)
		{
		}
	}
	public abstract class NonPolarAxis : AxisBase
	{
		private double gridSpacing = 1.0;

		private DateTimeGridAlignment gridAlignment = DateTimeGridAlignment.Day;

		private bool autoGrid = true;

		private bool logarithmic;

		private double logarithmicBase = 10.0;

		public double GridSpacing
		{
			get
			{
				return gridSpacing;
			}
			set
			{
				if (gridSpacing != value)
				{
					gridSpacing = value;
				}
			}
		}

		public DateTimeGridAlignment GridAlignment
		{
			get
			{
				return gridAlignment;
			}
			set
			{
				if (gridAlignment != value)
				{
					gridAlignment = value;
				}
			}
		}

		public bool AutoGrid
		{
			get
			{
				return autoGrid;
			}
			set
			{
				if (autoGrid != value)
				{
					autoGrid = value;
				}
			}
		}

		public bool Logarithmic
		{
			get
			{
				return logarithmic;
			}
			set
			{
				if (logarithmic != value)
				{
					logarithmic = value;
				}
			}
		}

		public double LogarithmicBase
		{
			get
			{
				return logarithmicBase;
			}
			set
			{
				if (logarithmicBase != value)
				{
					logarithmicBase = value;
				}
			}
		}

		protected NonPolarAxis()
			: this(null)
		{
		}

		protected NonPolarAxis(Chart parent)
			: base(parent)
		{
		}
	}
	public class Axis : NonPolarAxis
	{
		private AxisPosition position;

		private bool tickmarksVisible;

		private bool tickmarksMinorVisible;

		private bool tickmarksCrossAxis;

		private AxisTitle title;

		private bool reverse;

		public AxisPosition Position
		{
			get
			{
				return position;
			}
			set
			{
				if (position == value)
				{
					return;
				}
				position = value;
			}
		}

		public bool TickmarksVisible
		{
			get
			{
				return tickmarksVisible;
			}
			set
			{
				if (tickmarksVisible != value)
				{
					tickmarksVisible = value;
				}
			}
		}

		public bool TickmarksMinorVisible
		{
			get
			{
				return tickmarksMinorVisible;
			}
			set
			{
				if (tickmarksMinorVisible != value)
				{
					tickmarksMinorVisible = value;
				}
			}
		}

		public bool TickmarksCrossAxis
		{
			get
			{
				return tickmarksCrossAxis;
			}
			set
			{
				if (tickmarksCrossAxis != value)
				{
					tickmarksCrossAxis = value;
				}
			}
		}

		public AxisTitle Title
		{
			get
			{
				return title;
			}
			set
			{
				if (title != value)
				{
					title = value;
				}
			}
		}

		public bool Reverse
		{
			get
			{
				return reverse;
			}
			set
			{
				if (reverse != value)
				{
					reverse = value;
				}
			}
		}

		public ModelIntervalOptions IntervalOptions { get; set; }

		public Axis()
			: this(null)
		{
		}

		public Axis(CartesianChart parent)
			: base(parent)
		{
		}
	}
	public class RadarAxisX : NonPolarAxis
	{
	}
	public class PolarAxisX : AxisBase
	{
	}
	public class CircularAxisY : NonPolarAxis
	{
		private bool tickmarksVisible;

		private bool tickmarksMinorVisible;

		private bool tickmarksCrossAxis;

		public bool TickmarksVisible
		{
			get
			{
				return tickmarksVisible;
			}
			set
			{
				if (tickmarksVisible != value)
				{
					tickmarksVisible = value;
				}
			}
		}

		public bool TickmarksMinorVisible
		{
			get
			{
				return tickmarksMinorVisible;
			}
			set
			{
				if (tickmarksMinorVisible != value)
				{
					tickmarksMinorVisible = value;
				}
			}
		}

		public bool TickmarksCrossAxis
		{
			get
			{
				return tickmarksCrossAxis;
			}
			set
			{
				if (tickmarksCrossAxis != value)
				{
					tickmarksCrossAxis = value;
				}
			}
		}
	}
	public interface IAxisLabelFormatter
	{
		string GetAxisLabelText(object axisValue);
	}
	public class AxisLabel : ModelElement
	{
		private bool visible = true;

		private DefaultBoolean enableAntialiasing = DefaultBoolean.Default;

		private IAxisLabelFormatter formatter;

		private int rotationAngleDegree;

		private ModelAxisLabelResolveOverlappingOptions resolveOverlappingOptions;

		public bool Visible
		{
			get
			{
				return visible;
			}
			set
			{
				if (visible != value)
				{
					visible = value;
				}
			}
		}

		public IAxisLabelFormatter Formatter
		{
			get
			{
				return formatter;
			}
			set
			{
				if (formatter != value)
				{
					formatter = value;
				}
			}
		}

		public DefaultBoolean EnableAntialiasing
		{
			get
			{
				return enableAntialiasing;
			}
			set
			{
				if (enableAntialiasing != value)
				{
					enableAntialiasing = value;
				}
			}
		}

		public int RotationAngleDegree
		{
			get
			{
				return rotationAngleDegree;
			}
			set
			{
				if (rotationAngleDegree != value)
				{
					rotationAngleDegree = value;
				}
			}
		}

		public ModelAxisLabelResolveOverlappingOptions ResolveOverlappingOptions
		{
			get
			{
				return resolveOverlappingOptions;
			}
			set
			{
				if (resolveOverlappingOptions != value)
				{
					SetResolveOverlappingOptions(value);
				}
			}
		}

		public AxisLabel(AxisBase parent)
			: base(parent)
		{
		}

		private void SetResolveOverlappingOptions(ModelAxisLabelResolveOverlappingOptions newValue)
		{
			if (resolveOverlappingOptions != null)
			{
				resolveOverlappingOptions.Parent = null;
			}
			resolveOverlappingOptions = newValue;
			if (resolveOverlappingOptions != null)
			{
				resolveOverlappingOptions.Parent = this;
			}
		}
	}
	public class AxisRange : ModelElement
	{
		private object minValue;

		private object maxValue;

		public object MinValue
		{
			get
			{
				return minValue;
			}
			set
			{
				if (minValue != value)
				{
					minValue = value;
				}
			}
		}

		public object MaxValue
		{
			get
			{
				return maxValue;
			}
			set
			{
				if (maxValue != value)
				{
					maxValue = value;
				}
			}
		}

		public AxisRange(AxisBase parent)
			: base(parent)
		{
		}
	}
	public class AxisCollection : ModelElementCollection<Axis>
	{
		public AxisCollection(CartesianChart parent)
			: base((ModelElement)parent)
		{
		}
	}
	public class ModelAxisLabelResolveOverlappingOptions : ModelElement
	{
		private const int DefaultMinIndent = 5;

		private const bool DefaultAllowStagger = true;

		private const bool DefaultAllowRotate = true;

		private const bool DefaultAllowHide = true;

		private bool allowStagger = true;

		private bool allowRotate = true;

		private bool allowHide = true;

		private int minIndent = 5;

		public bool AllowStagger
		{
			get
			{
				return allowStagger;
			}
			set
			{
				if (allowStagger != value)
				{
					allowStagger = value;
				}
			}
		}

		public bool AllowRotate
		{
			get
			{
				return allowRotate;
			}
			set
			{
				if (allowRotate != value)
				{
					allowRotate = value;
				}
			}
		}

		public bool AllowHide
		{
			get
			{
				return allowHide;
			}
			set
			{
				if (allowHide != value)
				{
					allowHide = value;
				}
			}
		}

		public int MinIndent
		{
			get
			{
				return minIndent;
			}
			set
			{
				if (minIndent != value)
				{
					minIndent = value;
				}
			}
		}

		public ModelAxisLabelResolveOverlappingOptions()
		{
		}

		public ModelAxisLabelResolveOverlappingOptions(AxisLabel axisLabel)
			: base(axisLabel)
		{
		}
	}
	public enum IntervalDivisionMode
	{
		Auto,
		Width,
		Count
	}
	public class ModelIntervalOptions : ModelElement
	{
		public IntervalDivisionMode DivisionMode { get; set; }

		public double Width { get; set; }

		public int Count { get; set; }

		public object UnderflowValue { get; set; }

		public object OverflowValue { get; set; }
	}
	public class ChartDataTable
	{
		public bool ShowBorder { get; set; } = true;

		public bool ShowHorizontalLines { get; set; } = true;

		public bool ShowVerticalLines { get; set; } = true;

		public FontModel Font { get; set; }

		public ColorARGB TextColor { get; set; } = ColorARGB.Empty;

		public ColorARGB LineColor { get; set; } = ColorARGB.Empty;

		public LineStyle LineStyle { get; } = new LineStyle();

		public bool ShowLegendMarker { get; set; } = true;

		public bool Visible { get; set; }

		public int VerticalIndent { get; set; }
	}
	public class Indicator : ModelElement
	{
		private LineStyle lineStyle;

		public ColorARGB Color { get; set; }

		public LineStyle LineStyle => lineStyle;

		public string Name { get; set; }

		public bool ShowInLegend { get; set; }

		public bool Visible { get; set; }

		public bool DisplayEquation { get; set; }

		public bool DisplayRSquare { get; set; }

		public Indicator()
		{
			lineStyle = new LineStyle();
			Visible = true;
		}
	}
	public abstract class ParametricRegression : Indicator
	{
		public double ForecastBackwardPeriods { get; set; }

		public double ForecastForwardPeriods { get; set; }
	}
	public class RegressionLine : ParametricRegression
	{
	}
	public class SimpleMovingAverage : Indicator
	{
		public int PointsCount { get; set; }
	}
	public class ExponentialRegression : ParametricRegression
	{
	}
	public class PowerRegression : ParametricRegression
	{
	}
	public class LogarithmicRegression : ParametricRegression
	{
	}
	public class PolynomialRegression : ParametricRegression
	{
		public int Degree { get; set; }
	}
	public abstract class ErrorBars : Indicator
	{
		public ErrorBarsDirection Direction { get; set; }

		public ErrorBarsEndStyle EndStyle { get; set; }
	}
	public class StandardErrorBars : ErrorBars
	{
	}
	public class PercentageErrorBars : ErrorBars
	{
		public double Percent { get; set; }
	}
	public class StandardDeviationErrorBars : ErrorBars
	{
		public double Multiplier { get; set; }
	}
	public class FixedValueErrorBars : ErrorBars
	{
		public double NegativeError { get; set; }

		public double PositiveError { get; set; }
	}
	public class DataSourceBasedErrorBars : ErrorBars
	{
		public string NegativeErrorDataMember { get; set; }

		public string PositiveErrorDataMember { get; set; }
	}
	public enum ErrorBarsDirection
	{
		Both,
		Minus,
		Plus
	}
	public enum ErrorBarsEndStyle
	{
		Cap,
		NoCap
	}
	public static class LegendPositionConverter
	{
		private static readonly Dictionary<LegendPosition, LayoutAlignmentHorizontal> horizontalAlignmentDict;

		private static readonly Dictionary<LegendPosition, LayoutAlignmentVertical> verticalAlignmentDict;

		static LegendPositionConverter()
		{
			horizontalAlignmentDict = new Dictionary<LegendPosition, LayoutAlignmentHorizontal>();
			verticalAlignmentDict = new Dictionary<LegendPosition, LayoutAlignmentVertical>();
			horizontalAlignmentDict[LegendPosition.Left] = LayoutAlignmentHorizontal.Left;
			horizontalAlignmentDict[LegendPosition.Top] = LayoutAlignmentHorizontal.Center;
			horizontalAlignmentDict[LegendPosition.Right] = LayoutAlignmentHorizontal.Right;
			horizontalAlignmentDict[LegendPosition.Bottom] = LayoutAlignmentHorizontal.Center;
			horizontalAlignmentDict[LegendPosition.TopRight] = LayoutAlignmentHorizontal.Right;
			verticalAlignmentDict[LegendPosition.Left] = LayoutAlignmentVertical.Center;
			verticalAlignmentDict[LegendPosition.Top] = LayoutAlignmentVertical.Top;
			verticalAlignmentDict[LegendPosition.Right] = LayoutAlignmentVertical.Center;
			verticalAlignmentDict[LegendPosition.Bottom] = LayoutAlignmentVertical.Bottom;
			verticalAlignmentDict[LegendPosition.TopRight] = LayoutAlignmentVertical.Top;
		}

		public static LayoutAlignmentHorizontal ConverterToHorizontalAlignment(LegendPosition position, bool overlay)
		{
			LayoutAlignmentHorizontal layoutAlignmentHorizontal = horizontalAlignmentDict[position];
			if (!overlay)
			{
				if (layoutAlignmentHorizontal == LayoutAlignmentHorizontal.Left)
				{
					layoutAlignmentHorizontal = LayoutAlignmentHorizontal.LeftOutside;
				}
				if (layoutAlignmentHorizontal == LayoutAlignmentHorizontal.Right)
				{
					layoutAlignmentHorizontal = LayoutAlignmentHorizontal.RightOutside;
				}
			}
			return layoutAlignmentHorizontal;
		}

		public static LayoutAlignmentVertical ConverterToVerticalAlignment(LegendPosition position, bool overlay)
		{
			LayoutAlignmentVertical layoutAlignmentVertical = verticalAlignmentDict[position];
			if (!overlay)
			{
				if (layoutAlignmentVertical == LayoutAlignmentVertical.Top)
				{
					layoutAlignmentVertical = LayoutAlignmentVertical.TopOutside;
				}
				if (layoutAlignmentVertical == LayoutAlignmentVertical.Bottom)
				{
					layoutAlignmentVertical = LayoutAlignmentVertical.BottomOutside;
				}
			}
			return layoutAlignmentVertical;
		}
	}
	public class RunModel
	{
		public string Text { get; set; }

		public ColorARGB Color { get; set; }

		public FontModel Font { get; set; }
	}
	public class ParagraphModel
	{
		public IList<RunModel> Runs { get; } = new List<RunModel>();
	}
	public class BoxPlotSeries : CartesianSeriesBase
	{
		public override bool ActualColorEach => false;

		public bool ShowMeanLine { get; set; }
	}
	public abstract class ChartBase : ModelElement
	{
		private Palette palette;

		private object dataSource;

		private Legend legend;

		private readonly ChartTitleCollection titles;

		public object DataSource
		{
			get
			{
				return dataSource;
			}
			set
			{
				if (object.Equals(dataSource, value))
				{
					return;
				}
				dataSource = value;
			}
		}

		public Palette Palette
		{
			get
			{
				return palette;
			}
			set
			{
				if (palette != value)
				{
					UpdateElementParent(palette, null);
					palette = value;
					UpdateElementParent(palette, this);
				}
			}
		}

		public Legend Legend
		{
			get
			{
				return legend;
			}
			set
			{
				if (legend == value)
				{
					return;
				}
				UpdateElementParent(legend, null);
				legend = value;
				UpdateElementParent(legend, this);
			}
		}

		public ChartTitleCollection Titles => titles;

		protected ChartBase()
		{
			titles = new ChartTitleCollection(this);
		}
	}
	public abstract class Chart : ChartBase
	{
		private readonly SeriesCollection series;

		private ChartAppearanceOptions appearance;

		private bool autoLayout = true;

		public SeriesCollection Series => series;

		public ChartAppearanceOptions Appearance
		{
			get
			{
				return appearance;
			}
			set
			{
				if (appearance != value)
				{
					UpdateElementParent(appearance, null);
					appearance = value;
					UpdateElementParent(appearance, this);
				}
			}
		}

		public bool AutoLayout
		{
			get
			{
				return autoLayout;
			}
			set
			{
				if (value != autoLayout)
				{
					autoLayout = value;
				}
			}
		}

		protected Chart()
		{
			series = new SeriesCollection(this);
		}

		protected internal abstract bool IsSeriesValid(SeriesModel value);
	}
	public class CartesianChart : Chart
	{
		private readonly AxisCollection secondaryArgumentAxes;

		private readonly AxisCollection secondaryValueAxes;

		private Axis argumentAxis;

		private Axis valueAxis;

		public ChartDataTable ChartDataTable { get; set; }

		public bool Rotated { get; set; }

		public double BarDistance { get; set; }

		public int BarDistanceFixed { get; set; }

		public AxisCollection SecondaryArgumentAxes => secondaryArgumentAxes;

		public AxisCollection SecondaryValueAxes => secondaryValueAxes;

		public bool UseRangeDependentEnqueuer { get; set; }

		public Axis ArgumentAxis
		{
			get
			{
				return argumentAxis;
			}
			set
			{
				if (argumentAxis == value)
				{
					return;
				}
				UpdateElementParent(argumentAxis, null);
				argumentAxis = value;
				UpdateElementParent(argumentAxis, this);
			}
		}

		public Axis ValueAxis
		{
			get
			{
				return valueAxis;
			}
			set
			{
				if (valueAxis == value)
				{
					return;
				}
				UpdateElementParent(valueAxis, null);
				valueAxis = value;
				UpdateElementParent(valueAxis, this);
			}
		}

		public CartesianChart()
		{
			secondaryArgumentAxes = new AxisCollection(this);
			secondaryValueAxes = new AxisCollection(this);
			BarDistanceFixed = 1;
		}

		protected internal override bool IsSeriesValid(SeriesModel value)
		{
			return typeof(CartesianSeriesBase).IsAssignableFrom(value.GetType());
		}
	}
	public class Cartesian3DChart : CartesianChart, IChart3D
	{
		private readonly Options3D options3D;

		public IOptions3D Options3D => options3D;

		public Cartesian3DChart()
		{
			options3D = new Options3D(this);
		}

		protected internal override bool IsSeriesValid(SeriesModel value)
		{
			return typeof(SeriesModel).IsAssignableFrom(value.GetType());
		}
	}
	public class PieChart : Chart
	{
		protected internal override bool IsSeriesValid(SeriesModel value)
		{
			return typeof(PieSeriesBase).IsAssignableFrom(value.GetType());
		}
	}
	public class FunnelChart : Chart
	{
		protected internal override bool IsSeriesValid(SeriesModel value)
		{
			return typeof(FunnelSeries).IsAssignableFrom(value.GetType());
		}
	}
	public class Pie3DChart : PieChart, IChart3D
	{
		private readonly Options3D options3D;

		public IOptions3D Options3D => options3D;

		public Pie3DChart()
		{
			options3D = new Options3D(this);
		}
	}
	public abstract class CircularChart : Chart
	{
		private DirectionMode direction;

		private CircularAxisY valueAxis;

		private CircularDiagramStyle style;

		private bool useRangeDependentEnqueuer = true;

		public DirectionMode Direction
		{
			get
			{
				return direction;
			}
			set
			{
				if (direction != value)
				{
					direction = value;
				}
			}
		}

		public CircularAxisY ValueAxis
		{
			get
			{
				return valueAxis;
			}
			set
			{
				if (valueAxis == value)
				{
					return;
				}
				UpdateElementParent(valueAxis, null);
				valueAxis = value;
				UpdateElementParent(valueAxis, this);
			}
		}

		public CircularDiagramStyle Style
		{
			get
			{
				return style;
			}
			set
			{
				if (style != value)
				{
					style = value;
				}
			}
		}

		public bool UseRangeDependentEnqueuer
		{
			get
			{
				return useRangeDependentEnqueuer;
			}
			set
			{
				if (value != useRangeDependentEnqueuer)
				{
					useRangeDependentEnqueuer = value;
				}
			}
		}
	}
	public class RadarChart : CircularChart
	{
		private RadarAxisX argumentAxis;

		public RadarAxisX ArgumentAxis
		{
			get
			{
				return argumentAxis;
			}
			set
			{
				if (argumentAxis == value)
				{
					return;
				}
				UpdateElementParent(argumentAxis, null);
				argumentAxis = value;
				UpdateElementParent(argumentAxis, this);
			}
		}

		protected internal override bool IsSeriesValid(SeriesModel value)
		{
			return typeof(RadarSeriesBase).IsAssignableFrom(value.GetType());
		}
	}
	public class PolarChart : CircularChart
	{
		private PolarAxisX argumentAxis;

		public PolarAxisX ArgumentAxis
		{
			get
			{
				return argumentAxis;
			}
			set
			{
				if (argumentAxis == value)
				{
					return;
				}
				UpdateElementParent(argumentAxis, null);
				argumentAxis = value;
				UpdateElementParent(argumentAxis, this);
			}
		}

		protected internal override bool IsSeriesValid(SeriesModel value)
		{
			return typeof(PolarSeriesBase).IsAssignableFrom(value.GetType());
		}
	}
	public abstract class HierarchicalChart : ChartBase
	{
		private ChartAppearance plotAppearance;

		private LegendAppearance legendAppearance;

		private HierarchicalItemAppearance itemAppearance;

		public HierarchicalChartDataAdapterBase DataAdapter { get; set; }

		public IDataLabelFormatter LabelFormatter { get; set; }

		public LegendAppearance LegendAppearance
		{
			get
			{
				return legendAppearance;
			}
			set
			{
				if (legendAppearance != value)
				{
					UpdateElementParent(legendAppearance, null);
					legendAppearance = value;
					UpdateElementParent(legendAppearance, this);
				}
			}
		}

		public ChartAppearance PlotAppearance
		{
			get
			{
				return plotAppearance;
			}
			set
			{
				if (plotAppearance != value)
				{
					UpdateElementParent(plotAppearance, null);
					plotAppearance = value;
					UpdateElementParent(plotAppearance, this);
				}
			}
		}

		public HierarchicalItemAppearance ItemAppearance
		{
			get
			{
				return itemAppearance;
			}
			set
			{
				if (itemAppearance != value)
				{
					UpdateElementParent(itemAppearance, null);
					itemAppearance = value;
					UpdateElementParent(itemAppearance, this);
				}
			}
		}
	}
	public class TreeMap : HierarchicalChart
	{
		private HierarchicalItemAppearance groupAppearance;

		public HierarchicalItemAppearance GroupAppearance
		{
			get
			{
				return groupAppearance;
			}
			set
			{
				if (groupAppearance != value)
				{
					UpdateElementParent(groupAppearance, null);
					groupAppearance = value;
					UpdateElementParent(groupAppearance, this);
				}
			}
		}
	}
	public class Sunburst : HierarchicalChart
	{
		private const int DefaultHoleSizePercent = 34;

		private const double DefaultStartAngle = -90.0;

		public double StartAngle { get; set; } = -90.0;

		public int HoleRadiusPercent { get; set; } = 34;
	}
	public abstract class HierarchicalChartDataAdapterBase : ModelElement
	{
		public abstract bool HasGroupData { get; }
	}
	public class HierarchicalChartFlatDataAdapter : HierarchicalChartDataAdapterBase
	{
		public override bool HasGroupData
		{
			get
			{
				return GroupDataMembers?.Length > 0;
			}
		}

		public string LabelDataMember { get; set; }

		public string ValueDataMember { get; set; }

		public string ColorDataMember { get; set; }

		public string[] GroupDataMembers { get; set; }
	}
	public class HierarchicalChartHierarchicalDataAdapter : HierarchicalChartDataAdapterBase
	{
		public override bool HasGroupData
		{
			get
			{
				return Mappings?.Count > 0 && !string.IsNullOrEmpty(Mappings[0].ChildrenDataMember);
			}
		}

		public List<HierarchicalChartDataMapping> Mappings { get; set; }
	}
	public class HierarchicalChartDataMapping
	{
		public string LabelDataMember { get; set; }

		public string ValueDataMember { get; set; }

		public string ColorDataMember { get; set; }

		public string ChildrenDataMember { get; set; }

		public Type Type { get; set; }
	}
	public interface IChart3D
	{
		IOptions3D Options3D { get; }
	}
	public interface IOptions3D
	{
		int RotationAngleX { get; set; }

		int RotationAngleY { get; set; }

		int RotationAngleZ { get; set; }

		int PerspectiveAngle { get; set; }

		bool EnableAntialiasing { get; set; }
	}
	public class Options3D : ModelElement, IOptions3D
	{
		private bool enableAntialiasing;

		private int rotationAngleX = 20;

		private int rotationAngleY = -40;

		private int rotationAngleZ;

		private int perspectiveAngle = 50;

		public int RotationAngleX
		{
			get
			{
				return rotationAngleX;
			}
			set
			{
				if (rotationAngleX != value)
				{
					rotationAngleX = value;
				}
			}
		}

		public int RotationAngleY
		{
			get
			{
				return rotationAngleY;
			}
			set
			{
				if (rotationAngleY != value)
				{
					rotationAngleY = value;
				}
			}
		}

		public int RotationAngleZ
		{
			get
			{
				return rotationAngleZ;
			}
			set
			{
				if (rotationAngleZ != value)
				{
					rotationAngleZ = value;
				}
			}
		}

		public int PerspectiveAngle
		{
			get
			{
				return perspectiveAngle;
			}
			set
			{
				if (perspectiveAngle != value)
				{
					perspectiveAngle = value;
				}
			}
		}

		public bool EnableAntialiasing
		{
			get
			{
				return enableAntialiasing;
			}
			set
			{
				if (enableAntialiasing != value)
				{
					enableAntialiasing = value;
				}
			}
		}

		public Options3D(ModelElement parent)
			: base(parent)
		{
		}
	}
	public abstract class ModelControllerFactoryBase
	{
		public abstract IController CreateController();

		public abstract IChartRenderContext CreateRenderContext(ModelRect bounds, params object[] renderParams);
	}
	public interface IController
	{
		ChartBase ChartModel { get; set; }

		void RenderChart(IChartRenderContext renderContext);

		HitInfo CalcHitInfo(double x, double y);

		void Select(ModelElement element);

		void Deselect(ModelElement element);

		void ClearSelection();
	}
	public abstract class Controller : IController
	{
		private ChartBase chartModel;

		protected internal IModelElementContainer ElementContainer { get; }

		public ChartBase ChartModel
		{
			get
			{
				return chartModel;
			}
			set
			{
				if (object.Equals(ChartModel, value))
				{
					return;
				}
				chartModel = value;
				ClearElementContainer();
				OnModelChanged();
			}
		}

		protected Controller()
		{
			ElementContainer = new ModelElementContainer();
		}

		protected abstract void OnModelChanged();

		private void ClearElementContainer()
		{
			ElementContainer.Clear();
		}

		public abstract HitInfo CalcHitInfo(double x, double y);

		public abstract void Select(ModelElement element);

		public abstract void Deselect(ModelElement element);

		public abstract void ClearSelection();

		public abstract void RenderChart(IChartRenderContext renderContext);

		protected HitInfo CreateHitInfo(object hitObject)
		{
			if (hitObject == null)
			{
				return null;
			}
			ModelElement modelElement = ElementContainer.FindModelElement(hitObject);
			if (modelElement == null)
			{
				return HitInfo.Empty;
			}
			return new HitInfo(modelElement);
		}
	}
	public class ModelElementContainer : IModelElementContainer
	{
		private readonly Dictionary<object, ModelElement> modelElements;

		private readonly Dictionary<ModelElement, object> viewObjects;

		public ModelElementContainer()
		{
			modelElements = new Dictionary<object, ModelElement>();
			viewObjects = new Dictionary<ModelElement, object>();
		}

		public void Clear()
		{
			modelElements.Clear();
			viewObjects.Clear();
		}

		public void Register(object viewObject, ModelElement element)
		{
			if (!modelElements.ContainsKey(viewObject))
			{
				modelElements[viewObject] = element;
			}
			if (!viewObjects.ContainsKey(element))
			{
				viewObjects[element] = viewObject;
			}
		}

		public ModelElement FindModelElement(object viewObject)
		{
			if (modelElements.TryGetValue(viewObject, out var value))
			{
				return value;
			}
			return null;
		}

		public object FindViewObject(ModelElement element)
		{
			if (viewObjects.TryGetValue(element, out var value))
			{
				return value;
			}
			return null;
		}
	}
	public class ChartModelException : Exception
	{
		public ChartModelException(string message)
			: base(message)
		{
		}

		public static ChartModelException ThrowNullReferenceException(string objectName)
		{
			return new ChartModelException(string.Format("'null' is not a valid value for '{0}'", objectName));
		}
	}
	public interface IModelElementContainer
	{
		void Clear();

		void Register(object viewObject, ModelElement element);

		ModelElement FindModelElement(object viewObject);

		object FindViewObject(ModelElement element);
	}
	public interface IChartRenderContext
	{
		ModelRect Bounds { get; }
	}
	public enum LegendPosition
	{
		Bottom,
		Left,
		Right,
		Top,
		TopRight
	}
	public enum LegendOrientation
	{
		Vertical,
		Horizontal
	}
	public class Legend : ModelElement
	{
		private readonly LegendItemCollection items;

		private LegendPosition legendPosition;

		private LegendOrientation orientation;

		private Border border;

		private bool overlay;

		private DefaultBoolean enableAntialiasing = DefaultBoolean.Default;

		public LegendItemCollection Items => items;

		public LegendPosition LegendPosition
		{
			get
			{
				return legendPosition;
			}
			set
			{
				if (legendPosition == value)
				{
					return;
				}
				legendPosition = value;
			}
		}

		public LegendOrientation Orientation
		{
			get
			{
				return orientation;
			}
			set
			{
				if (orientation != value)
				{
					orientation = value;
				}
			}
		}

		public Border Border
		{
			get
			{
				return border;
			}
			set
			{
				if (border != value)
				{
					border = value;
				}
			}
		}

		public bool Overlay
		{
			get
			{
				return overlay;
			}
			set
			{
				if (overlay != value)
				{
					overlay = value;
				}
			}
		}

		public DefaultBoolean EnableAntialiasing
		{
			get
			{
				return enableAntialiasing;
			}
			set
			{
				if (enableAntialiasing != value)
				{
					enableAntialiasing = value;
				}
			}
		}

		public FontModel Font { get; set; }

		public Legend()
		{
			items = new LegendItemCollection(this);
			LegendPosition = LegendPosition.Right;
		}
	}
	public class LegendItemCollection : ModelElementCollection<LegendItem>
	{
		public LegendItemCollection(Legend parent)
			: base((ModelElement)parent)
		{
		}
	}
	public class LegendItem : ModelElement
	{
		public string Text { get; set; }

		public LegendItem()
			: base(null)
		{
		}
	}
	public enum DataMemberType
	{
		Argument,
		Value,
		Color,
		Open,
		High,
		Low,
		Close,
		Weight,
		Value2,
		BoxPlotMin,
		BoxPlotQuartile1,
		BoxPlotMedian,
		BoxPlotQuartile3,
		BoxPlotMax,
		BoxPlotMean,
		BoxPlotOutliers
	}
	public enum DirectionMode
	{
		Counterclockwise,
		Clockwise
	}
	public enum CircularDiagramStyle
	{
		Circle,
		Polygon
	}
	public enum ArgumentScaleType
	{
		Qualitative,
		Numerical,
		DateTime,
		TimeSpan,
		Auto
	}
	public enum ValueScaleType
	{
		Numerical = 1,
		DateTime,
		TimeSpan
	}
	public enum ProcessMissingPointsMode
	{
		Skip = 0,
		InsertEmptyPoints = 2
	}
	public enum StringAlignment
	{
		Near,
		Center,
		Far
	}
	public enum ProcessEmptyPointsMode
	{
		InsertZero,
		Ignore
	}
	public abstract class ModelElement
	{
		private ModelElement parent;

		public ModelElement Parent
		{
			get
			{
				return parent;
			}
			set
			{
				if (object.Equals(parent, value))
				{
					return;
				}
				parent = value;
			}
		}

		protected ModelElement()
		{
		}

		protected ModelElement(ModelElement parent)
		{
			this.parent = parent;
		}

		protected void UpdateElementParent(ModelElement element, ModelElement parent)
		{
			if (element != null)
			{
				element.Parent = parent;
			}
		}
	}
	public abstract class ModelElementCollection<T> : DXCollection<T> where T : ModelElement
	{
		private readonly ModelElement parent;

		protected ModelElement Parent => parent;

		protected ModelElementCollection(ModelElement parent)
		{
			this.parent = parent;
		}

		protected override void OnInsertComplete(int index, T value)
		{
			base.OnInsertComplete(index, value);
			value.Parent = parent;
		}

		protected override void OnRemoveComplete(int index, T value)
		{
			base.OnRemoveComplete(index, value);
			value.Parent = null;
		}

		protected override void OnSetComplete(int index, T oldValue, T newValue)
		{
			base.OnSetComplete(index, oldValue, newValue);
			oldValue.Parent = null;
			newValue.Parent = parent;
		}

		protected override bool OnClear()
		{
			for (int i = 0; i < base.Count; i++)
			{
				this[i].Parent = null;
			}
			return base.OnClear();
		}
	}
	public class UpdateInfo
	{
		public static readonly UpdateInfo Empty = new UpdateInfo();

		public bool Handled { get; set; }

		public ModelElement Element { get; private set; }

		public string PropertyName { get; private set; }

		public object Value { get; private set; }

		internal UpdateInfo()
		{
		}

		public UpdateInfo(ModelElement element, string propertyName, object value)
		{
			Element = element;
			PropertyName = propertyName;
			Value = value;
		}

		public override string ToString()
		{
			string arg = ((Value != null) ? Value.ToString() : "(null)");
			return string.Format("Element='{0}' Property='{1}' Value='{2}'", Element.GetType().Name, PropertyName, arg);
		}
	}
	public interface ISupportMarkerSeries
	{
		Marker Marker { get; set; }
	}
	public interface ISupportColorEachSeries
	{
		bool ColorEach { get; set; }
	}
	public interface ISupportTransparencySeries
	{
		byte Transparency { get; set; }
	}
	public interface ISupportBarWidthSeries
	{
		double BarWidth { get; set; }
	}
	public interface ISupportBar3DModelSeries
	{
		Bar3DModel Model { get; set; }
	}
	public interface IDataLabelFormatter
	{
		string GetDataLabelText(LabelPointData pointData);
	}
	public enum MarkerType
	{
		Square,
		Diamond,
		Triangle,
		InvertedTriangle,
		Circle,
		Plus,
		Cross,
		Star,
		Pentagon,
		Hexagon
	}
	public class Marker : ModelElement
	{
		public int Size { get; set; }

		public bool Visible { get; set; }

		public ColorARGB Color { get; set; }

		public MarkerType MarkerType { get; set; }

		public bool BorderVisible { get; set; }

		public ColorARGB BorderColor { get; set; }

		public int BorderThickness { get; set; }

		public Marker(ModelElement parent)
			: base(parent)
		{
			Size = 0;
			Visible = true;
			Color = ColorARGB.Empty;
			BorderColor = ColorARGB.Empty;
			BorderThickness = 1;
		}
	}
	public enum SeriesLabelPosition
	{
		Left,
		Top,
		Right,
		Bottom,
		Center,
		InsideBase,
		InsideEnd,
		OutsideEnd,
		BestFit
	}
	public class SeriesLabel : ModelElement
	{
		private SeriesLabelPosition position;

		private IDataLabelFormatter formatter;

		private DefaultBoolean enableAntialiasing = DefaultBoolean.Default;

		private TextOrientation textOrientation;

		public SeriesLabelPosition Position
		{
			get
			{
				return position;
			}
			set
			{
				if (position != value)
				{
					position = value;
				}
			}
		}

		public IDataLabelFormatter Formatter
		{
			get
			{
				return formatter;
			}
			set
			{
				if (formatter != value)
				{
					formatter = value;
				}
			}
		}

		public DefaultBoolean EnableAntialiasing
		{
			get
			{
				return enableAntialiasing;
			}
			set
			{
				if (enableAntialiasing != value)
				{
					enableAntialiasing = value;
				}
			}
		}

		public TextOrientation TextOrientation
		{
			get
			{
				return textOrientation;
			}
			set
			{
				if (textOrientation != value)
				{
					textOrientation = value;
				}
			}
		}

		public SeriesLabel(ModelElement parent)
			: base(parent)
		{
		}
	}
	public enum TextOrientation
	{
		Horizontal,
		TopToBottom,
		BottomToTop
	}
	public struct LabelPointData
	{
		private readonly object context;

		private readonly object argument;

		private readonly double normalizedValue;

		public object Context => context;

		public object Argument => argument;

		public double NormalizedValue => normalizedValue;

		public LabelPointData(object context, object argument, double normalizedValue)
		{
			this.context = context;
			this.argument = argument;
			this.normalizedValue = normalizedValue;
		}
	}
	public enum Bar3DModel
	{
		Box,
		Cylinder,
		Cone,
		Pyramid
	}
	public abstract class BarSeries : ColorEachCartesianSeriesBase, ISupportBarWidthSeries, ISupportBar3DModelSeries, ISupportTransparencySeries
	{
		public double BarWidth { get; set; } = 0.6;

		public Bar3DModel Model { get; set; }

		public byte Transparency { get; set; } = 120;
	}
	public class SideBySideBarSeries : BarSeries
	{
	}
	public class StackedBarSeries : BarSeries
	{
	}
	public class FullStackedBarSeries : StackedBarSeries
	{
	}
	public class SideBySideStackedBarSeries : StackedBarSeries
	{
	}
	public class SideBySideFullStackedBarSeries : SideBySideStackedBarSeries
	{
	}
	public class RangeBarSeries : BarSeries
	{
	}
	public class SideBySideRangeBarSeries : RangeBarSeries
	{
	}
	public class ManhattanBarSeries : SeriesModel, ISupportColorEachSeries, ISupportBarWidthSeries, ISupportBar3DModelSeries
	{
		public override bool ActualColorEach => ColorEach;

		public double BarWidth { get; set; } = 0.6;

		public bool ColorEach { get; set; }

		public Bar3DModel Model { get; set; }
	}
	public class WaterfallSeries : BarSeries
	{
		public bool ShowConnectors { get; set; } = true;

		public ColorARGB RisingBarColor { get; set; } = ColorARGB.Empty;

		public ColorARGB FallingBarColor { get; set; } = ColorARGB.Empty;

		public ColorARGB SubtotalBarColor { get; set; } = ColorARGB.Empty;

		public ColorARGB ConnectorColor { get; set; } = ColorARGB.Empty;

		public FillStyle RisingBarFillStyle { get; set; }

		public FillStyle FallingBarFillStyle { get; set; }

		public FillStyle SubtotalBarFillStyle { get; set; }

		public List<int> Subtotals { get; set; } = new List<int>();
	}
	public abstract class FinancialSeries : CartesianSeriesBase
	{
		public override bool ActualColorEach => false;
	}
	public class StockSeries : FinancialSeries
	{
	}
	public class CandleStickSeries : FinancialSeries
	{
	}
	public class ScatterLineSeries : MarkerCartesianSeriesBase, ISupportColorEachSeries
	{
		public override bool ActualColorEach => ColorEach;

		public bool ColorEach { get; set; }

		public ProcessMissingPointsMode ProcessMissingPointsMode { get; set; } = ProcessMissingPointsMode.InsertEmptyPoints;
	}
	public class LineSeries : ScatterLineSeries
	{
	}
	public class StepLineSeries : LineSeries
	{
	}
	public class RadarLineSeries : RadarPointSeries
	{
	}
	public class PolarLineSeries : PolarPointSeries
	{
	}
	public class StackedLineSeries : LineSeries
	{
	}
	public class FullStackedLineSeries : StackedLineSeries
	{
	}
	public class SplineSeries : LineSeries
	{
	}
	public enum PieExplodeMode
	{
		None,
		All,
		UsePoints
	}
	public enum PieSweepDirection
	{
		Clockwise,
		Counterclockwise
	}
	public abstract class PieSeriesBase : SeriesModel
	{
		private const double DefaultExplodedDistancePercentage = 10.0;

		private readonly List<int> explodedPointsIndexes = new List<int>();

		private double explodedDistancePercentage = 10.0;

		private PieExplodeMode explodeMode;

		private int rotationAngle;

		private int depthPercent;

		private PieSweepDirection sweepDirection = PieSweepDirection.Counterclockwise;

		public override bool ActualColorEach => false;

		public int RotationAngle
		{
			get
			{
				return rotationAngle;
			}
			set
			{
				if (rotationAngle != value)
				{
					rotationAngle = value;
				}
			}
		}

		public double ExplodedDistancePercentage
		{
			get
			{
				return explodedDistancePercentage;
			}
			set
			{
				if (explodedDistancePercentage != value)
				{
					explodedDistancePercentage = value;
				}
			}
		}

		public PieExplodeMode ExplodeMode
		{
			get
			{
				return explodeMode;
			}
			set
			{
				if (explodeMode != value)
				{
					explodeMode = value;
				}
			}
		}

		public List<int> ExplodedPointsIndexes => explodedPointsIndexes;

		public int DepthPercent
		{
			get
			{
				return depthPercent;
			}
			set
			{
				if (depthPercent != value)
				{
					depthPercent = value;
				}
			}
		}

		public PieSweepDirection SweepDirection
		{
			get
			{
				return sweepDirection;
			}
			set
			{
				if (sweepDirection != value)
				{
					sweepDirection = value;
				}
			}
		}
	}
	public class PieSeries : PieSeriesBase
	{
	}
	public class DonutSeries : PieSeriesBase
	{
		private const int DefaultHoleRadiusPercent = 60;

		private int holeRadiusPercent = 60;

		public int HoleRadiusPercent
		{
			get
			{
				return holeRadiusPercent;
			}
			set
			{
				if (holeRadiusPercent != value)
				{
					holeRadiusPercent = value;
				}
			}
		}
	}
	public class NestedDonutSeries : DonutSeries
	{
		private const double DefaultInnerIndent = 0.0;

		public double InnerIndent { get; set; }
	}
	public class FunnelSeries : SeriesModel
	{
		private const bool DefaultColorEach = false;

		private const int DefaultGapWidth = 2;

		private const FunnelPointShape DefaultPointShape = FunnelPointShape.Rectangle;

		public override bool ActualColorEach => ColorEach;

		public bool ColorEach { get; set; }

		public int GapWidth { get; set; } = 2;

		public FunnelPointShape PointShape { get; set; }
	}
	public enum FunnelPointShape
	{
		Rectangle,
		Trapezoid
	}
	public class PointSeriesBase : MarkerCartesianSeriesBase, ISupportColorEachSeries
	{
		public override bool ActualColorEach => ColorEach;

		public bool ColorEach { get; set; }
	}
	public class BubbleSeries : PointSeriesBase, ISupportTransparencySeries
	{
		private double minSize = 0.3;

		private double maxSize = 0.9;

		public byte Transparency { get; set; } = 120;

		public double MinSize
		{
			get
			{
				return minSize;
			}
			set
			{
				if (minSize != value)
				{
					if (value >= maxSize || value < 0.0)
					{
						throw new ArgumentException("The minimum size should be greater than or equal to 0, and less than the maximum size.");
					}
					minSize = value;
				}
			}
		}

		public double MaxSize
		{
			get
			{
				return maxSize;
			}
			set
			{
				if (maxSize != value)
				{
					if (value <= minSize)
					{
						throw new ArgumentException("The maximum size should be greater than the minimum size.");
					}
					maxSize = value;
				}
			}
		}
	}
	public class PointSeries : PointSeriesBase
	{
	}
	public class RadarPointSeries : RadarSeriesBase
	{
	}
	public class PolarPointSeries : PolarSeriesBase
	{
	}
	public abstract class SeriesModel : ModelElement
	{
		private readonly Dictionary<DataMemberType, string> dataMembers;

		private ArgumentScaleType argumentScaleType = ArgumentScaleType.Auto;

		private ValueScaleType valueScaleType = ValueScaleType.Numerical;

		private object dataSource;

		private bool labelsVisibility;

		private SeriesLabel label;

		private SeriesAppearance appearance;

		private bool? allowResampleCore;

		public abstract bool ActualColorEach { get; }

		public string DisplayName { get; set; }

		public string LegendPointPattern { get; set; }

		public bool ShowInLegend { get; set; }

		public virtual ArgumentScaleType ArgumentScaleType
		{
			get
			{
				return argumentScaleType;
			}
			set
			{
				argumentScaleType = value;
			}
		}

		public ValueScaleType ValueScaleType
		{
			get
			{
				return valueScaleType;
			}
			set
			{
				valueScaleType = value;
			}
		}

		public Dictionary<DataMemberType, string> DataMembers => dataMembers;

		public object DataSource
		{
			get
			{
				return dataSource;
			}
			set
			{
				dataSource = value;
			}
		}

		public SeriesAppearance Appearance
		{
			get
			{
				return appearance;
			}
			set
			{
				if (appearance != value)
				{
					appearance = value;
				}
			}
		}

		public bool LabelsVisibility
		{
			get
			{
				return labelsVisibility;
			}
			set
			{
				if (labelsVisibility != value)
				{
					labelsVisibility = value;
				}
			}
		}

		public SeriesLabel Label
		{
			get
			{
				return label;
			}
			set
			{
				if (label != value)
				{
					label = value;
				}
			}
		}

		public bool? AllowResample
		{
			get
			{
				return allowResampleCore;
			}
			set
			{
				if (allowResampleCore != value)
				{
					allowResampleCore = value;
				}
			}
		}

		protected SeriesModel()
		{
			dataMembers = new Dictionary<DataMemberType, string>();
			ShowInLegend = true;
		}
	}
	public class SeriesCollection : ModelElementCollection<SeriesModel>
	{
		public SeriesCollection(Chart parent)
			: base((ModelElement)parent)
		{
		}

		protected override void OnValidate(SeriesModel value)
		{
			base.OnValidate(value);
			if (base.Parent is Chart chart && !chart.IsSeriesValid(value))
			{
				throw new ChartModelException("Invalid series type for this type of chart");
			}
		}
	}
	public abstract class CartesianSeriesBase : SeriesModel
	{
		private int secondaryArgumentAxisIndex = -1;

		private int secondaryValueAxisIndex = -1;

		private ProcessEmptyPointsMode processEmptyPoints;

		private List<Indicator> indicators = new List<Indicator>();

		public int SecondaryArgumentAxisIndex
		{
			get
			{
				return secondaryArgumentAxisIndex;
			}
			set
			{
				if (secondaryArgumentAxisIndex != value)
				{
					secondaryArgumentAxisIndex = value;
				}
			}
		}

		public int SecondaryValueAxisIndex
		{
			get
			{
				return secondaryValueAxisIndex;
			}
			set
			{
				if (secondaryValueAxisIndex != value)
				{
					secondaryValueAxisIndex = value;
				}
			}
		}

		public ProcessEmptyPointsMode ProcessEmptyPoints
		{
			get
			{
				return processEmptyPoints;
			}
			set
			{
				if (processEmptyPoints != value)
				{
					processEmptyPoints = value;
				}
			}
		}

		public List<Indicator> Indicators => indicators;
	}
	public abstract class ColorEachCartesianSeriesBase : CartesianSeriesBase, ISupportColorEachSeries
	{
		public override bool ActualColorEach => ColorEach;

		public bool ColorEach { get; set; }
	}
	public abstract class MarkerCartesianSeriesBase : CartesianSeriesBase, ISupportMarkerSeries
	{
		public Marker Marker { get; set; }
	}
	public abstract class ColorEachMarkerSeriesBase : SeriesModel, ISupportMarkerSeries, ISupportColorEachSeries
	{
		public bool ColorEach { get; set; }

		public Marker Marker { get; set; }
	}
	public abstract class RadarSeriesBase : ColorEachMarkerSeriesBase
	{
		public override bool ActualColorEach => false;
	}
	public abstract class PolarSeriesBase : ColorEachMarkerSeriesBase
	{
		public override bool ActualColorEach => false;

		public override ArgumentScaleType ArgumentScaleType
		{
			get
			{
				return ArgumentScaleType.Numerical;
			}
			set
			{
			}
		}
	}
	public abstract class TitleBase : ModelElement
	{
		public DefaultBoolean EnableAntialiasing { get; set; } = DefaultBoolean.Default;

		public FontModel Font { get; set; }

		public IList<ParagraphModel> RichFormattedText { get; set; }

		protected TitleBase(ModelElement parent)
			: base(parent)
		{
		}
	}
	public class ChartTitle : TitleBase
	{
		public string[] Lines { get; set; }

		public bool IsOverlay { get; set; }

		public ChartTitle()
			: base(null)
		{
		}
	}
	public class ChartTitleCollection : ModelElementCollection<ChartTitle>
	{
		public ChartTitleCollection(ChartBase parent)
			: base((ModelElement)parent)
		{
		}
	}
	[ComVisible(false)]
	public struct ModelRect : IEquatable<ModelRect>
	{
		public static readonly ModelRect Empty = new ModelRect(0.0, 0.0, 0.0, 0.0);

		private double left;

		private double top;

		private double width;

		private double height;

		public double Left
		{
			get
			{
				return left;
			}
			set
			{
				left = value;
			}
		}

		public double Top
		{
			get
			{
				return top;
			}
			set
			{
				top = value;
			}
		}

		public double Width
		{
			get
			{
				return width;
			}
			set
			{
				width = value;
			}
		}

		public double Height
		{
			get
			{
				return height;
			}
			set
			{
				height = value;
			}
		}

		public static bool operator ==(ModelRect rect1, ModelRect rect2)
		{
			if (rect1.Left == rect2.left && rect1.top == rect2.top && rect1.width == rect2.width)
			{
				return rect1.height == rect2.height;
			}
			return false;
		}

		public static bool operator !=(ModelRect rect1, ModelRect rect2)
		{
			return !(rect1 == rect2);
		}

		public static bool Equals(ModelRect rect1, ModelRect rect2)
		{
			if (rect1.left.Equals(rect2.left) && rect1.top.Equals(rect2.top) && rect1.width.Equals(rect2.width))
			{
				return rect1.height.Equals(rect2.height);
			}
			return false;
		}

		public ModelRect(double left, double top, double width, double height)
		{
			this.left = left;
			this.top = top;
			this.width = width;
			this.height = height;
		}

		public bool Equals(ModelRect other)
		{
			return Equals(this, other);
		}

		public override bool Equals(object obj)
		{
			if (obj is ModelRect)
			{
				return Equals((ModelRect)obj);
			}
			return false;
		}

		public override int GetHashCode()
		{
			return HashCodeHelper.CalculateGeneric(left, top, width, height);
		}
	}
	public class HitInfo
	{
		public static readonly HitInfo Empty = new HitInfo(null);

		private readonly ModelElement element;

		public ModelElement Element => element;

		public HitInfo(ModelElement element)
		{
			this.element = element;
		}

		public override bool Equals(object obj)
		{
			HitInfo hitInfo = obj as HitInfo;
			ModelElement objB = ((hitInfo != null) ? hitInfo.Element : null);
			return object.Equals(Element, objB);
		}

		public override int GetHashCode()
		{
			return HashCodeHelper.CalculateGeneric(Element);
		}
	}
	public struct ColorARGB : IComparable<ColorARGB>, IEquatable<ColorARGB>
	{
		public static ColorARGB Empty = default(ColorARGB);

		public static ColorARGB Transparent = new ColorARGB(0, byte.MaxValue, byte.MaxValue, byte.MaxValue);

		private readonly uint argb;

		public byte A => (byte)(argb >> 24);

		public byte R => (byte)(argb >> 16);

		public byte G => (byte)(argb >> 8);

		public byte B => (byte)argb;

		public bool IsEmpty => this == Empty;

		public bool IsTransparent => this == Transparent;

		public static ColorARGB Parse(string argbColor)
		{
			if (argbColor.Length != 8)
			{
				return Empty;
			}
			byte alpha = byte.Parse(argbColor.Substring(0, 2), NumberStyles.HexNumber);
			byte blue = byte.Parse(argbColor.Substring(2, 2), NumberStyles.HexNumber);
			byte green = byte.Parse(argbColor.Substring(4, 2), NumberStyles.HexNumber);
			byte red = byte.Parse(argbColor.Substring(6, 2), NumberStyles.HexNumber);
			return new ColorARGB(alpha, red, green, blue);
		}

		public static bool operator ==(ColorARGB color1, ColorARGB color2)
		{
			return color1.argb == color2.argb;
		}

		public static bool operator !=(ColorARGB color1, ColorARGB color2)
		{
			return !(color1 == color2);
		}

		public static bool Equals(ColorARGB color1, ColorARGB color2)
		{
			return color1 == color2;
		}

		public ColorARGB(byte alpha, byte red, byte green, byte blue)
		{
			argb = (uint)((alpha << 24) | (red << 16) | (green << 8) | blue);
		}

		public bool Equals(ColorARGB other)
		{
			return Equals(this, other);
		}

		public override bool Equals(object obj)
		{
			ColorARGB? colorARGB = obj as ColorARGB?;
			if (colorARGB.HasValue)
			{
				return Equals(this, colorARGB.Value);
			}
			return false;
		}

		public override int GetHashCode()
		{
			return argb.GetHashCode();
		}

		public int CompareTo(ColorARGB other)
		{
			return argb.CompareTo(other.argb);
		}
	}
	public class FontModel : ModelElement
	{
		public bool Bold { get; set; }

		public bool Italic { get; set; }

		public bool Underline { get; set; }

		public bool Strikeout { get; set; }

		public string Name { get; set; }

		public float Size { get; set; }

		public bool Subscript { get; set; }

		public bool Superscript { get; set; }

		public override bool Equals(object obj)
		{
			if (!(obj is FontModel fontModel))
			{
				return false;
			}
			if (Bold == fontModel.Bold && Italic == fontModel.Italic && Underline == fontModel.Underline && Strikeout == fontModel.Strikeout && Name == fontModel.Name && Size == fontModel.Size && Subscript == fontModel.Subscript)
			{
				return Superscript == fontModel.Superscript;
			}
			return false;
		}

		public override int GetHashCode()
		{
			return HashCodeHelper.CalculateGeneric(Bold, Italic, Underline, Strikeout, Name, Size, Subscript, Superscript);
		}
	}
	public static class FontConversion
	{
		private const double pixelToPointRatio = 1.3333333333333333;

		public static double ConvertFromPointToPixel(double fontSizeInPoints)
		{
			return fontSizeInPoints * 1.3333333333333333;
		}

		public static double ConvertFromPixelToPoint(double fontSizeInPixels)
		{
			return fontSizeInPixels / 1.3333333333333333;
		}
	}
}
namespace DevExpress.Charts.Model.Helpers
{
	public static class FontConfiguratorHelper
	{
		public static DXFont ConfigureDXFont(FontModel fontModel, string fallbackFontName)
		{
			if (fontModel == null)
			{
				return null;
			}
			DXFontStyle dXFontStyle = DXFontStyle.Regular;
			if (fontModel.Bold)
			{
				dXFontStyle |= DXFontStyle.Bold;
			}
			if (fontModel.Italic)
			{
				dXFontStyle |= DXFontStyle.Italic;
			}
			if (fontModel.Underline)
			{
				dXFontStyle |= DXFontStyle.Underline;
			}
			if (fontModel.Strikeout)
			{
				dXFontStyle |= DXFontStyle.Strikeout;
			}
			string name = (string.IsNullOrEmpty(fontModel.Name) ? fallbackFontName : fontModel.Name);
			return new DXFont(name, fontModel.Size, dXFontStyle);
		}
	}
}
namespace DevExpress.DataVisualization.Native
{
	public class ColorHSL
	{
		private const float minLuminance = 0.5f;

		private const float maxLuminance = 0.8f;

		private float hue;

		private float saturation;

		private float luminance;

		public float Hue
		{
			get
			{
				return hue;
			}
			set
			{
				hue = value;
			}
		}

		public float Saturation
		{
			get
			{
				return saturation;
			}
			set
			{
				saturation = value;
			}
		}

		public float Luminance
		{
			get
			{
				return luminance;
			}
			set
			{
				luminance = value;
			}
		}

		public float MinLuminance => Math.Min(0.5f, luminance * 0.9f);

		public float MaxLuminance => Math.Max(0.8f, luminance + (1f - luminance) * 0.15f);

		private static float GetHue(ColorARGB color)
		{
			if (color.R == color.G && color.G == color.B)
			{
				return 0f;
			}
			float num = (float)(int)color.R / 255f;
			float num2 = (float)(int)color.G / 255f;
			float num3 = (float)(int)color.B / 255f;
			float num4, num5, num6, num7;
			num7 = 0f;
			num4 = num;
			num5 = num;
			if (num2 > num4)
			{
				num4 = num2;
			}
			if (num3 > num4)
			{
				num4 = num3;
			}
			if (num2 < num5)
			{
				num5 = num2;
			}
			if (num3 < num5)
			{
				num5 = num3;
			}
			num6 = num4 - num5;
			if (num == num4)
			{
				num7 = (num2 - num3) / num6;
			}
			else if (num2 == num4)
			{
				num7 = 2f + (num3 - num) / num6;
			}
			else if (num3 == num4)
			{
				num7 = 4f + (num - num2) / num6;
			}
			num7 *= 60f;
			if (num7 < 0f)
			{
				num7 += 360f;
			}
			return num7;
		}

		private static float GetSaturation(ColorARGB color)
		{
			float num = (float)(int)color.R / 255f;
			float num2 = (float)(int)color.G / 255f;
			float num3 = (float)(int)color.B / 255f;
			float num4, num5, num6, result;
			result = 0f;
			num4 = num;
			num5 = num;
			if (num2 > num4)
			{
				num4 = num2;
			}
			if (num3 > num4)
			{
				num4 = num3;
			}
			if (num2 < num5)
			{
				num5 = num2;
			}
			if (num3 < num5)
			{
				num5 = num3;
			}
			if (num4 != num5)
			{
				num6 = (num4 + num5) / 2f;
				if ((double)num6 <= 0.5)
				{
					result = (num4 - num5) / (num4 + num5);
				}
				else
				{
					result = (num4 - num5) / (2f - num4 - num5);
				}
			}
			return result;
		}

		private static float GetBrightness(ColorARGB color)
		{
			float num = (float)(int)color.R / 255f;
			float num2 = (float)(int)color.G / 255f;
			float num3 = (float)(int)color.B / 255f;
			float num4, num5;
			num4 = num;
			num5 = num;
			if (num2 > num4)
			{
				num4 = num2;
			}
			if (num3 > num4)
			{
				num4 = num3;
			}
			if (num2 < num5)
			{
				num5 = num2;
			}
			if (num3 < num5)
			{
				num5 = num3;
			}
			return (num4 + num5) / 2f;
		}

		private static byte GetComponent(float q, float p, float t)
		{
			while (t < 0f)
			{
				t += 1f;
			}
			while (t > 1f)
			{
				t -= 1f;
			}
			float num;
			if (t < 1f / 6f)
			{
				num = p + (q - p) * 6f * t;
			}
			else if (t < 0.5f)
			{
				num = q;
			}
			else if (t < 2f / 3f)
			{
				num = p + (q - p) * (2f / 3f - t) * 6f;
			}
			else
			{
				num = p;
			}
			return (byte)Math.Round(num * 255f);
		}

		public static explicit operator ColorHSL(ColorARGB color)
		{
			return new ColorHSL(GetHue(color), GetSaturation(color), GetBrightness(color));
		}

		public static explicit operator ColorARGB(ColorHSL color)
		{
			float num = ((color.luminance < 0.5f) ? (color.luminance * (1f + color.saturation)) : (color.luminance + color.saturation - color.luminance * color.saturation));
			float p = 2f * color.luminance - num;
			float num2 = color.hue / 360f;
			return new ColorARGB(byte.MaxValue, GetComponent(num, p, num2 + 1f / 3f), GetComponent(num, p, num2), GetComponent(num, p, num2 - 1f / 3f));
		}

		public ColorHSL(float hue, float saturation, float luminance)
		{
			this.hue = hue;
			this.saturation = saturation;
			this.luminance = luminance;
		}
	}
	public abstract class ColorIndexCacheCore
	{
		private readonly Dictionary<int, int> indexCount = new Dictionary<int, int>();

		protected int GetActualIndexRepeatCount(int index, int actualIndex)
		{
			int num = 0;
			if (!indexCount.ContainsKey(actualIndex))
			{
				indexCount[actualIndex] = num;
			}
			else
			{
				num = ++indexCount[actualIndex];
			}
			return num;
		}

		protected ColorARGB ConvertColor(ColorARGB color, int colorRepeat)
		{
			ColorHSL colorHSL = (ColorHSL)color;
			float num = (((double)colorHSL.Luminance > 0.5) ? (1f - colorHSL.Luminance) : colorHSL.Luminance) / 4f;
			float num2 = colorHSL.Luminance + num;
			for (int i = 1; i < colorRepeat; i++)
			{
				num /= 1.5f;
				if (num2 + num > 1f)
				{
					num2 = num2 + (1f - num2) / 2f;
				}
				else
				{
					num2 = num2 + num;
				}
			}
			colorHSL.Luminance = num2;
			return (ColorARGB)colorHSL;
		}
	}
	public enum DockStyleCore
	{
		None,
		Top,
		Bottom,
		Left,
		Right,
		Fill
	}
	public enum LayoutAlignmentHorizontal
	{
		LeftOutside,
		Left,
		Center,
		Right,
		RightOutside
	}
	public enum LayoutAlignmentVertical
	{
		TopOutside,
		Top,
		Center,
		Bottom,
		BottomOutside
	}
}
