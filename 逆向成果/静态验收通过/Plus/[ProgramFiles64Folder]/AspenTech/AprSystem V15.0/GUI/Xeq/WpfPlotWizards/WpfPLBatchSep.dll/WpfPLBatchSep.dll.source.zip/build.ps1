param(
    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'out'),
    [string]$Dotnet = 'dotnet',
    [string]$Ilasm = (Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/ilasm.exe')
)
$ErrorActionPreference = 'Stop'
$Dotnet = (Get-Command -Name $Dotnet -CommandType Application -ErrorAction Stop).Source
$Ilasm = (Get-Item -LiteralPath $Ilasm).FullName
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
if (Test-Path -LiteralPath $OutputDirectory) {
    if (@(Get-ChildItem -LiteralPath $OutputDirectory -Force).Count) {
        throw 'Select an empty output directory.'
    }
} else {
    $null = New-Item -ItemType Directory -Path $OutputDirectory
}
$Work = Join-Path $OutputDirectory 'build'
$Main = Join-Path $Work 'main'
$Satellite = Join-Path $Work 'satellite'
$OutputCulture = Join-Path $OutputDirectory 'en-US'
$null = New-Item -ItemType Directory -Path $Main, $Satellite, $OutputCulture
foreach ($file in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'source/main') -File) {
    Copy-Item -LiteralPath $file.FullName -Destination $Main
}
foreach ($file in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'source/en-US') -File) {
    Copy-Item -LiteralPath $file.FullName -Destination $Satellite
}
$tools = Join-Path $Work 'tools-src'
$null = New-Item -ItemType Directory -Path $tools
foreach ($file in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'tools') -File) {
    Copy-Item -LiteralPath $file.FullName -Destination $tools
}

$previous = @{}
$overrides = @{
    DOTNET_CLI_HOME = (Join-Path $Work 'dotnet-home')
    DOTNET_CLI_TELEMETRY_OPTOUT = '1'
    DOTNET_SKIP_FIRST_TIME_EXPERIENCE = '1'
    DOTNET_GENERATE_ASPNET_CERTIFICATE = 'false'
    TEMP = (Join-Path $Work 'tmp')
    TMP = (Join-Path $Work 'tmp')
    NUGET_PACKAGES = (Join-Path $Work 'packages')
}
foreach ($name in $overrides.Keys) {
    $previous[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
    [Environment]::SetEnvironmentVariable($name, $overrides[$name], 'Process')
}
$null = New-Item -ItemType Directory -Path $env:TEMP
try {
    $patchOut = Join-Path $Work 'tools-bin'
    & $Dotnet build (Join-Path $tools 'Patch.csproj') --nologo --ignore-failed-sources -o $patchOut
    if ($LASTEXITCODE -ne 0) { throw 'Building the metadata correction tool failed.' }
    $patch = Join-Path $patchOut 'Patch.dll'

    $rawMain = Join-Path $Main 'WpfPLBatchSep.dll'
    $mainResult = Join-Path $OutputDirectory 'WpfPLBatchSep.dll'
    Push-Location $Main
    try {
        & $Ilasm /DLL /QUIET /DEBUG=OPT /RESOURCE=WpfPLBatchSep.dll.res /OUTPUT=WpfPLBatchSep.dll WpfPLBatchSep.dll.il
        if ($LASTEXITCODE -ne 0) { throw 'Assembling the main IL failed.' }
    } finally { Pop-Location }
    & $Dotnet $patch $rawMain $mainResult (Join-Path $PSScriptRoot 'source/method-intent.json')
    if ($LASTEXITCODE -ne 0) { throw 'Correcting the main assembly metadata failed.' }

    $rawSatellite = Join-Path $Satellite 'WpfPLBatchSep.resources.dll'
    $satelliteResult = Join-Path $OutputCulture 'WpfPLBatchSep.resources.dll'
    Push-Location $Satellite
    try {
        & $Ilasm /DLL /QUIET /RESOURCE=WpfPLBatchSep.resources.dll.res /OUTPUT=WpfPLBatchSep.resources.dll WpfPLBatchSep.resources.dll.il
        if ($LASTEXITCODE -ne 0) { throw 'Assembling the en-US satellite failed.' }
    } finally { Pop-Location }
    & $Dotnet $patch $rawSatellite $satelliteResult '-'
    if ($LASTEXITCODE -ne 0) { throw 'Normalizing the satellite build metadata failed.' }

    foreach ($result in $mainResult, $satelliteResult) {
        $hash = (Get-FileHash -LiteralPath $result -Algorithm SHA256).Hash.ToLowerInvariant()
        Write-Output "$hash  $result"
    }
} finally {
    foreach ($name in $previous.Keys) {
        [Environment]::SetEnvironmentVariable($name, $previous[$name], 'Process')
    }
}
