using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPlotwizard;

namespace WpfPLVscrub;

[ProgId("WpfPLVscrub.DropletDistr")]
public class DropletDistr : UserControl, IRibbonPlotWizardType, IComponentConnector
{
	private IHNode _context;

	private IHWizardPlot2 _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private string _uniqueId = "Fraction";

	private string _plotName;

	private object _nodeCxs;

	private string _currentLengthUnit = string.Empty;

	private System.Drawing.Image _imgBitmap;

	private bool _bHasInputDialog;

	private string _currentConfigValue = string.Empty;

	private readonly string _lengthUnitFieldId = WpfPLRPlugResources.Length;

	private bool _bCheckDataOnly;

	private bool _contentLoaded;

	public string TooltipContentForRibbonItem => WpfPLViscrubResources.TooltipContent_DropletDistr;

	public string TooltipHeaderForRibbonItem => WpfPLViscrubResources.TooltipHeader_DropletDistr;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot2;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _lengthUnitFieldId };

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public DropletDistr()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		InitializeComponent();
		_bHasInputDialog = false;
		if (_imgBitmap == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLVscrub.Images.SepEff.ico");
			_imgBitmap = new Bitmap(manifestResourceStream);
		}
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
		{
			List<string> list = new List<string>();
			_help.LoadXUnitsList(_context.Application.Tree, (IHWizardPlot)_wizardPlot, list);
			return list;
		}
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
		if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
		{
			sCurrentVal = _help.GetXUnitString(_context.Application.Tree, (IHWizardPlot)_wizardPlot);
		}
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
		if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
		{
			_currentLengthUnit = sValue;
		}
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		if (sField.CompareTo(_lengthUnitFieldId) == 0)
		{
			return (RibbonControlType)1;
		}
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
		sConfigValue = _currentConfigValue;
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
		_currentConfigValue = sValue;
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot2;
		new List<string>();
		IHNode iHNode = _context.FindNode("Output/FRACTION");
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
		}
		else
		{
			_wizardPlot.SetIndependentVariable(_context, "Output/DROP_DIAM");
		}
	}

	public void UpdateWizardData()
	{
		_wizardPlot.RemoveAllDependentVariable();
		IHNode iHNode = _context.FindNode("Output/DROP_DIAM");
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			return;
		}
		string indepvar = "Output/DROP_DIAM";
		string depvar = "Output/FRACTION";
		_wizardPlot.SetIndependentVariable(_context, indepvar);
		_wizardPlot.AddDependentVariable(_context, depvar);
		_help.SaveXUnitsComboText(_context.Application.Tree, (IHWizardPlot)_wizardPlot, _currentLengthUnit);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	public void InitializeComponent()
	{
		if (_contentLoaded)
		{
			return;
		}
		_contentLoaded = true;
		Uri resourceLocator = new Uri("/WpfPLVscrub;component/dropletdistr.xaml", UriKind.Relative);
		Application.LoadComponent(this, resourceLocator);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		_contentLoaded = true;
	}
}
