﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  WpfPLData.Comp
  WpfPLData.RibbonPlotWizardMgr
  WpfPLData.DataCurve
  WpfPLData.PLDataHelper
  WpfPLData.DataPlotWizardModule
  WpfPLData.Triangle
  AspenTech.AspenPlus.Happ.CHPlotVal
  AspenTech.AspenPlus.Happ.CHWizardPlot
  AspenTech.AspenPlus.Happ.IHNode
  AspenTech.AspenPlus.Happ.IHNodeCol
  AspenTech.AspenPlus.Happ.IHPlotVal
  AspenTech.AspenPlus.Happ.IHWizardPlot
  WpfPLData.Comp/'<>o__74'
  WpfPLData.Comp/'<>o__75'
  WpfPLData.Comp/'<>o__83'
  WpfPLData.Comp/'<>o__90'
  WpfPLData.DataCurve/'<>o__61'
  WpfPLData.PLDataHelper/'<>o__5'
  WpfPLData.PLDataHelper/'<>o__6'
  WpfPLData.PLDataHelper/'<>o__7'
  WpfPLData.Triangle/'<>o__67'
  WpfPLData.Triangle/'<>o__72'
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern PresentationFramework
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern AspenTech.AspenPlus.Infrastructure
{
  .ver 41:0:0:614
}
.assembly extern System.Drawing
{
  .publickeytoken = (B0 3F 5F 7F 11 D5 0A 3A )                         // .?_....:
  .ver 4:0:0:0
}
.assembly extern System.Core
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern System.Xaml
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern PresentationCore
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern AspenTech.WpfControls.Engineering
{
  .ver 41:0:0:0
}
.assembly extern WpfPLControls
{
  .ver 41:0:0:614
}
.assembly extern System
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern WpfPlotWizardsHelper
{
  .ver 41:0:0:614
}
.assembly extern AspenTech.AspenPlus.Localization
{
  .ver 41:0:0:614
}
.assembly extern Microsoft.CSharp
{
  .publickeytoken = (B0 3F 5F 7F 11 D5 0A 3A )                         // .?_....:
  .ver 4:0:0:0
}
.assembly WpfPLData
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.

  // --- The following custom attribute is added automatically, do not uncomment -------
  //  .custom instance void [mscorlib]System.Diagnostics.DebuggableAttribute::.ctor(valuetype [mscorlib]System.Diagnostics.DebuggableAttribute/DebuggingModes) = ( 01 00 02 00 00 00 00 00 ) 

  .custom instance void [mscorlib]System.Reflection.AssemblyFileVersionAttribute::.ctor(string) = ( 01 00 0A 34 31 2E 30 2E 30 2E 36 31 34 00 00 )    // ...41.0.0.614..
  .custom instance void [mscorlib]System.Reflection.AssemblyTitleAttribute::.ctor(string) = ( 01 00 04 44 61 74 61 00 00 )                      // ...Data..
  .custom instance void [mscorlib]System.Reflection.AssemblyDescriptionAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyConfigurationAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyCompanyAttribute::.ctor(string) = ( 01 00 16 41 73 70 65 6E 20 54 65 63 68 6E 6F 6C   // ...Aspen Technol
                                                                                                6F 67 79 2C 20 49 6E 63 2E 00 00 )                // ogy, Inc...
  .custom instance void [mscorlib]System.Reflection.AssemblyProductAttribute::.ctor(string) = ( 01 00 04 44 61 74 61 00 00 )                      // ...Data..
  .custom instance void [mscorlib]System.Reflection.AssemblyCopyrightAttribute::.ctor(string) = ( 01 00 29 43 6F 70 79 72 69 67 68 74 20 C2 A9 20   // ..)Copyright .. 
                                                                                                  41 73 70 65 6E 20 54 65 63 68 6E 6F 6C 6F 67 79   // Aspen Technology
                                                                                                  20 32 30 31 31 20 2D 20 32 30 32 34 00 00 )       //  2011 - 2024..
  .custom instance void [mscorlib]System.Reflection.AssemblyTrademarkAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Resources.NeutralResourcesLanguageAttribute::.ctor(string,
                                                                                            valuetype [mscorlib]System.Resources.UltimateResourceFallbackLocation) = ( 01 00 05 65 6E 2D 55 53 01 00 00 00 00 00 )       // ...en-US......
  .custom instance void [PresentationFramework]System.Windows.ThemeInfoAttribute::.ctor(valuetype [PresentationFramework]System.Windows.ResourceDictionaryLocation,
                                                                                        valuetype [PresentationFramework]System.Windows.ResourceDictionaryLocation) = ( 01 00 00 00 00 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.Versioning.TargetFrameworkAttribute::.ctor(string) = ( 01 00 1A 2E 4E 45 54 46 72 61 6D 65 77 6F 72 6B   // ....NETFramework
                                                                                                        2C 56 65 72 73 69 6F 6E 3D 76 34 2E 38 01 00 54   // ,Version=v4.8..T
                                                                                                        0E 14 46 72 61 6D 65 77 6F 72 6B 44 69 73 70 6C   // ..FrameworkDispl
                                                                                                        61 79 4E 61 6D 65 12 2E 4E 45 54 20 46 72 61 6D   // ayName..NET Fram
                                                                                                        65 77 6F 72 6B 20 34 2E 38 )                      // ework 4.8
  .hash algorithm 0x00008004
  .ver 41:0:0:614
}
.mresource public WpfPLData.Images.DataPxy.ico
{
  // Offset: 0x00000000 Length: 0x000010BE
  // WARNING: managed resource file WpfPLData.Images.DataPxy.ico created
}
.mresource public WpfPLData.Images.DataTX.ico
{
  // Offset: 0x000010C8 Length: 0x000010BE
  // WARNING: managed resource file WpfPLData.Images.DataTX.ico created
}
.mresource public WpfPLData.Images.DataTXY.ico
{
  // Offset: 0x00002190 Length: 0x000010BE
  // WARNING: managed resource file WpfPLData.Images.DataTXY.ico created
}
.mresource public WpfPLData.Images.DataPx.ico
{
  // Offset: 0x00003258 Length: 0x000010BE
  // WARNING: managed resource file WpfPLData.Images.DataPx.ico created
}
.mresource public WpfPLData.Images.DataXX.ico
{
  // Offset: 0x00004320 Length: 0x000010BE
  // WARNING: managed resource file WpfPLData.Images.DataXX.ico created
}
.mresource public WpfPLData.Images.DataYX.ico
{
  // Offset: 0x000053E8 Length: 0x000010BE
  // WARNING: managed resource file WpfPLData.Images.DataYX.ico created
}
.mresource public WpfPLData.Images.DataPropt.ico
{
  // Offset: 0x000064B0 Length: 0x000010BE
  // WARNING: managed resource file WpfPLData.Images.DataPropt.ico created
}
.mresource public WpfPLData.Images.DataPropx.ico
{
  // Offset: 0x00007578 Length: 0x000010BE
  // WARNING: managed resource file WpfPLData.Images.DataPropx.ico created
}
.mresource public WpfPLData.Images.DataTri.ico
{
  // Offset: 0x00008640 Length: 0x000010BE
  // WARNING: managed resource file WpfPLData.Images.DataTri.ico created
}
.mresource public WpfPLData.Text.Datapwr.txt
{
  // Offset: 0x00009708 Length: 0x00000CEC
  // WARNING: managed resource file WpfPLData.Text.Datapwr.txt created
}
.module WpfPLData.dll
// MVID: {6728aada-a483-4cc7-aaae-d3f1e634b751}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000001    //  ILONLY
// Image base: 0x0000028D54430000


// =============== CLASS MEMBERS DECLARATION ===================

.class public auto ansi beforefieldinit WpfPLData.Comp
       extends [mscorlib]System.Object
       implements [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 0E 57 70 66 50 4C 44 61 74 61 2E 43 6F 6D   // ...WpfPLData.Com
                                                                                                    70 00 00 )                                        // p..
  .class abstract auto ansi sealed nested private beforefieldinit '<>o__74'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__0'
  } // end of class '<>o__74'

  .class abstract auto ansi sealed nested private beforefieldinit '<>o__75'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> '<>p__0'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__1'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__2'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__3'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__4'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> '<>p__5'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__6'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__7'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__8'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__9'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> '<>p__10'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__11'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__12'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__13'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__14'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> '<>p__15'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__16'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__17'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__18'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__19'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> '<>p__20'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__21'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__22'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__23'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__24'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> '<>p__25'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__26'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__27'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__28'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__29'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> '<>p__30'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__31'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__32'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__33'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__34'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> '<>p__35'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__36'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__37'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> '<>p__38'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__39'
  } // end of class '<>o__75'

  .class abstract auto ansi sealed nested private beforefieldinit '<>o__83'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> '<>p__0'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>> '<>p__1'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> '<>p__2'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> '<>p__3'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__4'
  } // end of class '<>o__83'

  .class abstract auto ansi sealed nested private beforefieldinit '<>o__90'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> '<>p__0'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>> '<>p__1'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> '<>p__2'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> '<>p__3'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__4'
  } // end of class '<>o__90'

  .field private class AspenTech.AspenPlus.Happ.IHNode _context
  .field private class AspenTech.AspenPlus.Happ.IHWizardPlot _wizardPlot
  .field private class WpfPLData.PLDataHelper _help
  .field private string _propertyId
  .field private string _componentId
  .field private bool _showProperty
  .field private bool _showComponent
  .field private string _uniqueId
  .field private string _plotName
  .field private object _nodeCxs
  .field private class [System.Drawing]System.Drawing.Image _imgIcon
  .field private bool _bHasInputDialog
  .field private string _type
  .field private string[] VarNames
  .field private int32[] DataElement
  .field private string MoleType
  .field private int32 TempElement
  .field private string TempUnit
  .field private int32 Temp2Element
  .field private string Temp2Unit
  .field private int32 PresElement
  .field private string PresUnit
  .field private string TempAmt
  .field private string PresAmt
  .field private int32 PlotType
  .field private class [mscorlib]System.Collections.Generic.List`1<string> ComponentList
  .field private class [mscorlib]System.Collections.Generic.List`1<string> XPropName
  .field private class [mscorlib]System.Collections.Generic.List`1<string> XPropUnit
  .field private class [mscorlib]System.Collections.Generic.List`1<int32> XPropc
  .field private int32[] Xc
  .field private int32[] X2c
  .field private int32[] Yc
  .field private bool _bCheckDataOnly
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string 'type') cil managed
  {
    // Code size       240 (0xf0)
    .maxstack  3
    .locals init (class [mscorlib]System.IO.Stream V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "PlotWiz.hlp"
    IL_0006:  ldc.i4.s   108
    IL_0008:  conv.i8
    IL_0009:  newobj     instance void WpfPLData.PLDataHelper::.ctor(string,
                                                                     int64)
    IL_000e:  stfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_0013:  ldarg.0
    IL_0014:  ldc.i4.1
    IL_0015:  stfld      bool WpfPLData.Comp::_showProperty
    IL_001a:  ldarg.0
    IL_001b:  ldc.i4.1
    IL_001c:  stfld      bool WpfPLData.Comp::_showComponent
    IL_0021:  ldarg.0
    IL_0022:  ldstr      "Data_Comp"
    IL_0027:  stfld      string WpfPLData.Comp::_uniqueId
    IL_002c:  ldarg.0
    IL_002d:  ldstr      ""
    IL_0032:  stfld      string WpfPLData.Comp::_type
    IL_0037:  ldarg.0
    IL_0038:  ldstr      ""
    IL_003d:  stfld      string WpfPLData.Comp::MoleType
    IL_0042:  ldarg.0
    IL_0043:  ldstr      ""
    IL_0048:  stfld      string WpfPLData.Comp::TempUnit
    IL_004d:  ldarg.0
    IL_004e:  ldstr      ""
    IL_0053:  stfld      string WpfPLData.Comp::Temp2Unit
    IL_0058:  ldarg.0
    IL_0059:  ldstr      ""
    IL_005e:  stfld      string WpfPLData.Comp::PresUnit
    IL_0063:  ldarg.0
    IL_0064:  ldstr      ""
    IL_0069:  stfld      string WpfPLData.Comp::TempAmt
    IL_006e:  ldarg.0
    IL_006f:  ldstr      ""
    IL_0074:  stfld      string WpfPLData.Comp::PresAmt
    IL_0079:  ldarg.0
    IL_007a:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_007f:  stfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0084:  ldarg.0
    IL_0085:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_008a:  stfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_008f:  ldarg.0
    IL_0090:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0095:  stfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_009a:  ldarg.0
    IL_009b:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<int32>::.ctor()
    IL_00a0:  stfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_00a5:  ldarg.0
    IL_00a6:  call       instance void [mscorlib]System.Object::.ctor()
    IL_00ab:  ldarg.0
    IL_00ac:  ldc.i4.0
    IL_00ad:  stfld      bool WpfPLData.Comp::_bHasInputDialog
    IL_00b2:  ldarg.0
    IL_00b3:  ldarg.1
    IL_00b4:  stfld      string WpfPLData.Comp::_type
    IL_00b9:  ldarg.0
    IL_00ba:  ldfld      class [System.Drawing]System.Drawing.Image WpfPLData.Comp::_imgIcon
    IL_00bf:  brtrue.s   IL_00ef

    IL_00c1:  call       class [mscorlib]System.Reflection.Assembly [mscorlib]System.Reflection.Assembly::GetExecutingAssembly()
    IL_00c6:  pop
    IL_00c7:  call       class [mscorlib]System.Reflection.Assembly [mscorlib]System.Reflection.Assembly::GetExecutingAssembly()
    IL_00cc:  ldarg.0
    IL_00cd:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_00d2:  ldarg.0
    IL_00d3:  ldfld      string WpfPLData.Comp::_type
    IL_00d8:  callvirt   instance string WpfPLData.PLDataHelper::GetIconResource(string)
    IL_00dd:  callvirt   instance class [mscorlib]System.IO.Stream [mscorlib]System.Reflection.Assembly::GetManifestResourceStream(string)
    IL_00e2:  stloc.0
    IL_00e3:  ldarg.0
    IL_00e4:  ldloc.0
    IL_00e5:  newobj     instance void [System.Drawing]System.Drawing.Bitmap::.ctor(class [mscorlib]System.IO.Stream)
    IL_00ea:  stfld      class [System.Drawing]System.Drawing.Image WpfPLData.Comp::_imgIcon
    IL_00ef:  ret
  } // end of method Comp::.ctor

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipContentForRibbonItem() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_TooltipContentForRibbonItem
    // Code size       160 (0xa0)
    .maxstack  2
    .locals init (string V_0,
             int32 V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0006:  brtrue.s   IL_000a

    IL_0008:  ldnull
    IL_0009:  ret

    IL_000a:  ldnull
    IL_000b:  stloc.0
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0012:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_0017:  stloc.1
    IL_0018:  ldloc.1
    IL_0019:  ldc.i4.1
    IL_001a:  sub
    IL_001b:  switch     ( 
                          IL_0050,
                          IL_0058,
                          IL_0060,
                          IL_0068,
                          IL_0070,
                          IL_0078,
                          IL_0080,
                          IL_0088,
                          IL_0090)
    IL_0044:  ldloc.1
    IL_0045:  ldc.i4.s   29
    IL_0047:  beq.s      IL_0090

    IL_0049:  ldloc.1
    IL_004a:  ldc.i4.s   30
    IL_004c:  beq.s      IL_0098

    IL_004e:  br.s       IL_009e

    IL_0050:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_TXY()
    IL_0055:  stloc.0
    IL_0056:  br.s       IL_009e

    IL_0058:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_PXY()
    IL_005d:  stloc.0
    IL_005e:  br.s       IL_009e

    IL_0060:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_TX()
    IL_0065:  stloc.0
    IL_0066:  br.s       IL_009e

    IL_0068:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_PX()
    IL_006d:  stloc.0
    IL_006e:  br.s       IL_009e

    IL_0070:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_YX()
    IL_0075:  stloc.0
    IL_0076:  br.s       IL_009e

    IL_0078:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_TXX()
    IL_007d:  stloc.0
    IL_007e:  br.s       IL_009e

    IL_0080:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_PXX()
    IL_0085:  stloc.0
    IL_0086:  br.s       IL_009e

    IL_0088:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_PropX()
    IL_008d:  stloc.0
    IL_008e:  br.s       IL_009e

    IL_0090:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_PropT()
    IL_0095:  stloc.0
    IL_0096:  br.s       IL_009e

    IL_0098:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_PropP()
    IL_009d:  stloc.0
    IL_009e:  ldloc.0
    IL_009f:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipContentForRibbonItem

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipHeaderForRibbonItem() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_TooltipHeaderForRibbonItem
    // Code size       160 (0xa0)
    .maxstack  2
    .locals init (string V_0,
             int32 V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0006:  brtrue.s   IL_000a

    IL_0008:  ldnull
    IL_0009:  ret

    IL_000a:  ldnull
    IL_000b:  stloc.0
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0012:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_0017:  stloc.1
    IL_0018:  ldloc.1
    IL_0019:  ldc.i4.1
    IL_001a:  sub
    IL_001b:  switch     ( 
                          IL_0050,
                          IL_0058,
                          IL_0060,
                          IL_0068,
                          IL_0070,
                          IL_0078,
                          IL_0080,
                          IL_0088,
                          IL_0090)
    IL_0044:  ldloc.1
    IL_0045:  ldc.i4.s   29
    IL_0047:  beq.s      IL_0090

    IL_0049:  ldloc.1
    IL_004a:  ldc.i4.s   30
    IL_004c:  beq.s      IL_0098

    IL_004e:  br.s       IL_009e

    IL_0050:  ldstr      "T-xy"
    IL_0055:  stloc.0
    IL_0056:  br.s       IL_009e

    IL_0058:  ldstr      "P-xy"
    IL_005d:  stloc.0
    IL_005e:  br.s       IL_009e

    IL_0060:  ldstr      "T-x"
    IL_0065:  stloc.0
    IL_0066:  br.s       IL_009e

    IL_0068:  ldstr      "P-x"
    IL_006d:  stloc.0
    IL_006e:  br.s       IL_009e

    IL_0070:  ldstr      "y-x"
    IL_0075:  stloc.0
    IL_0076:  br.s       IL_009e

    IL_0078:  ldstr      "T-xx"
    IL_007d:  stloc.0
    IL_007e:  br.s       IL_009e

    IL_0080:  ldstr      "P-xx"
    IL_0085:  stloc.0
    IL_0086:  br.s       IL_009e

    IL_0088:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipHeaderForRibbonItem_PropX()
    IL_008d:  stloc.0
    IL_008e:  br.s       IL_009e

    IL_0090:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipHeaderForRibbonItem_PropT()
    IL_0095:  stloc.0
    IL_0096:  br.s       IL_009e

    IL_0098:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipHeaderForRibbonItem_PropP()
    IL_009d:  stloc.0
    IL_009e:  ldloc.0
    IL_009f:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipHeaderForRibbonItem

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TagID() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_TagID
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string WpfPLData.Comp::_uniqueId
    IL_0006:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TagID

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_TagID(string 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_TagID
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string WpfPLData.Comp::_uniqueId
    IL_0007:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_TagID

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_Name() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_Name
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string WpfPLData.Comp::_plotName
    IL_0006:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_Name

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_Name(string 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_Name
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string WpfPLData.Comp::_plotName
    IL_0007:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_Name

  .method private hidebysig newslot specialname virtual final 
          instance object  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_WizardPlot() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_WizardPlot
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0006:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_WizardPlot

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_WizardPlot(object 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_WizardPlot
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  isinst     AspenTech.AspenPlus.Happ.IHWizardPlot
    IL_0007:  stfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_000c:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_WizardPlot

  .method private hidebysig newslot specialname virtual final 
          instance object  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_CxsNode() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_CxsNode
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object WpfPLData.Comp::_nodeCxs
    IL_0006:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_CxsNode

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_CxsNode(object 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_CxsNode
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      object WpfPLData.Comp::_nodeCxs
    IL_0007:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_CxsNode

  .method private hidebysig newslot specialname virtual final 
          instance class [System.Drawing]System.Drawing.Image 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_ImageIcon() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_ImageIcon
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System.Drawing]System.Drawing.Image WpfPLData.Comp::_imgIcon
    IL_0006:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_ImageIcon

  .method private hidebysig newslot specialname virtual final 
          instance bool  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HasInputDialog() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_HasInputDialog
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool WpfPLData.Comp::_bHasInputDialog
    IL_0006:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HasInputDialog

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpFile() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_HelpFile
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_0006:  callvirt   instance string [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper::GetHelpFileName()
    IL_000b:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpFile

  .method private hidebysig newslot specialname virtual final 
          instance int64  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpID() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_HelpID
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_0006:  callvirt   instance int64 [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper::GetHelpID()
    IL_000b:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpID

  .method private hidebysig newslot specialname virtual final 
          instance class [mscorlib]System.Collections.Generic.List`1<string> 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedDataFields() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_SupportedDataFields
    // Code size       46 (0x2e)
    .maxstack  2
    .locals init (class [mscorlib]System.Collections.Generic.List`1<string> V_0)
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      bool WpfPLData.Comp::_showProperty
    IL_000c:  brfalse.s  IL_0019

    IL_000e:  ldloc.0
    IL_000f:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Property_Title()
    IL_0014:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0019:  ldarg.0
    IL_001a:  ldfld      bool WpfPLData.Comp::_showComponent
    IL_001f:  brfalse.s  IL_002c

    IL_0021:  ldloc.0
    IL_0022:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component_Title()
    IL_0027:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_002c:  ldloc.0
    IL_002d:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedDataFields

  .method private hidebysig newslot specialname virtual final 
          instance class [mscorlib]System.Collections.Generic.List`1<string> 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedStyleFields() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_SupportedStyleFields
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0005:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedStyleFields

  .method private hidebysig newslot virtual final 
          instance class [mscorlib]System.Collections.Generic.List`1<string> 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.FieldDataOptionList(string sFieldName) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::FieldDataOptionList
    // Code size       42 (0x2a)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Property_Title()
    IL_0006:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_000b:  brtrue.s   IL_0014

    IL_000d:  ldarg.0
    IL_000e:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_0013:  ret

    IL_0014:  ldarg.1
    IL_0015:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component_Title()
    IL_001a:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_001f:  brtrue.s   IL_0028

    IL_0021:  ldarg.0
    IL_0022:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0027:  ret

    IL_0028:  ldnull
    IL_0029:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.FieldDataOptionList

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldData(string sFieldName,
                                                                                               string& sCurrentVal) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetFieldData
    // Code size       43 (0x2b)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component_Title()
    IL_0006:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_000b:  brtrue.s   IL_0015

    IL_000d:  ldarg.2
    IL_000e:  ldarg.0
    IL_000f:  ldfld      string WpfPLData.Comp::_componentId
    IL_0014:  stind.ref
    IL_0015:  ldarg.1
    IL_0016:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Property_Title()
    IL_001b:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_0020:  brtrue.s   IL_002a

    IL_0022:  ldarg.2
    IL_0023:  ldarg.0
    IL_0024:  ldfld      string WpfPLData.Comp::_propertyId
    IL_0029:  stind.ref
    IL_002a:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldData(string sFieldName,
                                                                                               string sValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::SetFieldData
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldc.i4.0
    IL_0001:  ldarg.1
    IL_0002:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Property_Title()
    IL_0007:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_000c:  brtrue.s   IL_0015

    IL_000e:  ldarg.0
    IL_000f:  ldarg.2
    IL_0010:  stfld      string WpfPLData.Comp::_propertyId
    IL_0015:  ldarg.1
    IL_0016:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component_Title()
    IL_001b:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_0020:  brtrue.s   IL_0029

    IL_0022:  ldarg.0
    IL_0023:  ldarg.2
    IL_0024:  stfld      string WpfPLData.Comp::_componentId
    IL_0029:  brfalse.s  IL_0031

    IL_002b:  ldarg.0
    IL_002c:  call       instance void WpfPLData.Comp::UpdateWizardData()
    IL_0031:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ShowInputDialog() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::ShowInputDialog
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ShowInputDialog

  .method private hidebysig newslot virtual final 
          instance valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.RibbonControlType 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldCtrlType(string sField) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetFieldCtrlType
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Property_Title()
    IL_0006:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_000b:  brtrue.s   IL_000f

    IL_000d:  ldc.i4.1
    IL_000e:  ret

    IL_000f:  ldarg.1
    IL_0010:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component_Title()
    IL_0015:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_001a:  brtrue.s   IL_001e

    IL_001c:  ldc.i4.1
    IL_001d:  ret

    IL_001e:  ldc.i4.0
    IL_001f:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldCtrlType

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldStyle(string sFieldName,
                                                                                                string& sCurrentVal) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetFieldStyle
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldStyle

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldStyle(string sFieldName,
                                                                                                string sValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::SetFieldStyle
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldStyle

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetConfigData(string& sConfigValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetConfigData
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetConfigData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetConfigData(string sValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::SetConfigData
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetConfigData

  .method public hidebysig newslot specialname virtual final 
          instance bool  get_CheckDataOnly() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool WpfPLData.Comp::_bCheckDataOnly
    IL_0006:  ret
  } // end of method Comp::get_CheckDataOnly

  .method public hidebysig newslot specialname virtual final 
          instance void  set_CheckDataOnly(bool 'value') cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool WpfPLData.Comp::_bCheckDataOnly
    IL_0007:  ret
  } // end of method Comp::set_CheckDataOnly

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Context(object HNode,
                                                                                          object& HWizardPlot,
                                                                                          int32& ierror) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::Context
    // Code size       430 (0x1ae)
    .maxstack  5
    .locals init (string V_0)
    IL_0000:  ldarg.2
    IL_0001:  ldind.ref
    IL_0002:  brfalse.s  IL_0007

    IL_0004:  ldarg.1
    IL_0005:  brtrue.s   IL_000b

    IL_0007:  ldarg.3
    IL_0008:  ldc.i4.1
    IL_0009:  stind.i4
    IL_000a:  ret

    IL_000b:  ldarg.0
    IL_000c:  ldarg.1
    IL_000d:  isinst     AspenTech.AspenPlus.Happ.IHNode
    IL_0012:  stfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_0017:  ldarg.0
    IL_0018:  ldarg.2
    IL_0019:  ldind.ref
    IL_001a:  isinst     AspenTech.AspenPlus.Happ.IHWizardPlot
    IL_001f:  stfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0024:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__74'::'<>p__0'
    IL_0029:  brtrue.s   IL_004f

    IL_002b:  ldc.i4.0
    IL_002c:  ldtoken    [mscorlib]System.String
    IL_0031:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0036:  ldtoken    WpfPLData.Comp
    IL_003b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0040:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_0045:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_004a:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__74'::'<>p__0'
    IL_004f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__74'::'<>p__0'
    IL_0054:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_0059:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__74'::'<>p__0'
    IL_005e:  ldarg.0
    IL_005f:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_0064:  ldstr      "Input/STATESPEC"
    IL_0069:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_006e:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0073:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_0078:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_007d:  stloc.0
    IL_007e:  ldloc.0
    IL_007f:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0084:  brtrue.s   IL_0097

    IL_0086:  ldloc.0
    IL_0087:  ldstr      "GEN-"
    IL_008c:  callvirt   instance bool [mscorlib]System.String::Contains(string)
    IL_0091:  brfalse.s  IL_0097

    IL_0093:  ldarg.3
    IL_0094:  ldc.i4.1
    IL_0095:  stind.i4
    IL_0096:  ret

    IL_0097:  ldarg.0
    IL_0098:  ldc.i4.3
    IL_0099:  newarr     [mscorlib]System.String
    IL_009e:  dup
    IL_009f:  ldc.i4.0
    IL_00a0:  ldstr      "Input/CIDS"
    IL_00a5:  stelem.ref
    IL_00a6:  dup
    IL_00a7:  ldc.i4.1
    IL_00a8:  ldstr      "Input/USE"
    IL_00ad:  stelem.ref
    IL_00ae:  dup
    IL_00af:  ldc.i4.2
    IL_00b0:  ldstr      "Input/VALUE"
    IL_00b5:  stelem.ref
    IL_00b6:  stfld      string[] WpfPLData.Comp::VarNames
    IL_00bb:  ldarg.0
    IL_00bc:  call       instance bool WpfPLData.Comp::Build_CandidateList()
    IL_00c1:  brtrue.s   IL_00c7

    IL_00c3:  ldarg.3
    IL_00c4:  ldc.i4.1
    IL_00c5:  stind.i4
    IL_00c6:  ret

    IL_00c7:  ldarg.0
    IL_00c8:  ldfld      string WpfPLData.Comp::_componentId
    IL_00cd:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_00d2:  brfalse.s  IL_00f4

    IL_00d4:  ldarg.0
    IL_00d5:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_00da:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_00df:  ldc.i4.0
    IL_00e0:  ble.s      IL_00f4

    IL_00e2:  ldarg.0
    IL_00e3:  ldarg.0
    IL_00e4:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_00e9:  ldc.i4.0
    IL_00ea:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_00ef:  stfld      string WpfPLData.Comp::_componentId
    IL_00f4:  ldarg.0
    IL_00f5:  ldfld      string WpfPLData.Comp::_propertyId
    IL_00fa:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_00ff:  brfalse.s  IL_0166

    IL_0101:  ldarg.0
    IL_0102:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_0107:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_010c:  ldc.i4.0
    IL_010d:  ble.s      IL_0166

    IL_010f:  ldarg.0
    IL_0110:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0115:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_011a:  ldc.i4.s   29
    IL_011c:  bne.un.s   IL_0154

    IL_011e:  ldarg.0
    IL_011f:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_0124:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_0129:  ldc.i4.1
    IL_012a:  ble.s      IL_0140

    IL_012c:  ldarg.0
    IL_012d:  ldarg.0
    IL_012e:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_0133:  ldc.i4.1
    IL_0134:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_0139:  stfld      string WpfPLData.Comp::_propertyId
    IL_013e:  br.s       IL_0166

    IL_0140:  ldarg.0
    IL_0141:  ldarg.0
    IL_0142:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_0147:  ldc.i4.0
    IL_0148:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_014d:  stfld      string WpfPLData.Comp::_propertyId
    IL_0152:  br.s       IL_0166

    IL_0154:  ldarg.0
    IL_0155:  ldarg.0
    IL_0156:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_015b:  ldc.i4.0
    IL_015c:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_0161:  stfld      string WpfPLData.Comp::_propertyId
    IL_0166:  ldarg.0
    IL_0167:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_016c:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_0171:  ldc.i4.s   29
    IL_0173:  bne.un.s   IL_0184

    IL_0175:  ldarg.0
    IL_0176:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_017b:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_0180:  ldc.i4.s   30
    IL_0182:  beq.s      IL_019b

    IL_0184:  ldarg.0
    IL_0185:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_018a:  ldarg.0
    IL_018b:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_0190:  ldarg.0
    IL_0191:  ldflda     string WpfPLData.Comp::MoleType
    IL_0196:  callvirt   instance void WpfPLData.PLDataHelper::DetermineMoleType(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                 string&)
    IL_019b:  ldarg.0
    IL_019c:  call       instance void WpfPLData.Comp::Build_Node_Lookup()
    IL_01a1:  ldarg.0
    IL_01a2:  call       instance void WpfPLData.Comp::SetWindowTitle()
    IL_01a7:  ldarg.0
    IL_01a8:  call       instance void WpfPLData.Comp::SetAxisTitles()
    IL_01ad:  ret
  } // end of method Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Context

  .method public hidebysig newslot virtual final 
          instance void  UpdateWizardData() cil managed
  {
    // Code size       11433 (0x2ca9)
    .maxstack  17
    .locals init (class AspenTech.AspenPlus.Happ.IHNode V_0,
             int32 V_1,
             class [mscorlib]System.Collections.Generic.List`1<int32> V_2,
             int32 V_3,
             int32 V_4,
             int32 V_5,
             int32 V_6,
             bool[] V_7,
             int32 V_8,
             int32 V_9,
             int32 V_10,
             int32 V_11,
             string V_12,
             string V_13,
             int32 V_14,
             int32 V_15,
             string V_16,
             string V_17,
             int32 V_18,
             int32 V_19,
             string V_20,
             string V_21,
             int32 V_22,
             int32 V_23,
             string V_24,
             string V_25,
             int32 V_26,
             int32 V_27,
             int32 V_28,
             int32 V_29,
             int32 V_30,
             int32 V_31,
             int32 V_32,
             int32 V_33,
             int32 V_34,
             int32 V_35,
             int32 V_36,
             int32 V_37,
             int32 V_38,
             int32 V_39,
             int32 V_40,
             int32 V_41,
             string V_42,
             int32 V_43,
             int32 V_44,
             int32 V_45,
             string V_46,
             int32 V_47,
             int32 V_48,
             string V_49,
             int32 V_50,
             int32 V_51,
             string V_52)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_0006:  ldarg.0
    IL_0007:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_000c:  ldc.i4.2
    IL_000d:  ldelem.ref
    IL_000e:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_0013:  stloc.0
    IL_0014:  ldc.i4.m1
    IL_0015:  stloc.1
    IL_0016:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<int32>::.ctor()
    IL_001b:  stloc.2
    IL_001c:  ldc.i4.m1
    IL_001d:  stloc.3
    IL_001e:  ldarg.0
    IL_001f:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0024:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_0029:  stloc.s    V_8
    IL_002b:  ldloc.s    V_8
    IL_002d:  ldc.i4.1
    IL_002e:  sub
    IL_002f:  ldc.i4.6
    IL_0030:  ble.un.s   IL_0043

    IL_0032:  ldloc.s    V_8
    IL_0034:  ldc.i4.8
    IL_0035:  sub
    IL_0036:  ldc.i4.1
    IL_0037:  ble.un.s   IL_0064

    IL_0039:  ldloc.s    V_8
    IL_003b:  ldc.i4.s   29
    IL_003d:  sub
    IL_003e:  ldc.i4.1
    IL_003f:  ble.un.s   IL_0092

    IL_0041:  br.s       IL_00a4

    IL_0043:  ldarg.0
    IL_0044:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0049:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_004e:  brfalse.s  IL_00a4

    IL_0050:  ldarg.0
    IL_0051:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0056:  ldarg.0
    IL_0057:  ldfld      string WpfPLData.Comp::_componentId
    IL_005c:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::IndexOf(!0)
    IL_0061:  stloc.1
    IL_0062:  br.s       IL_00a4

    IL_0064:  ldarg.0
    IL_0065:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_006a:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_006f:  brfalse.s  IL_0083

    IL_0071:  ldarg.0
    IL_0072:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0077:  ldarg.0
    IL_0078:  ldfld      string WpfPLData.Comp::_componentId
    IL_007d:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::IndexOf(!0)
    IL_0082:  stloc.1
    IL_0083:  ldarg.0
    IL_0084:  ldarg.0
    IL_0085:  ldfld      string WpfPLData.Comp::_propertyId
    IL_008a:  call       instance class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropPtrArray(string)
    IL_008f:  stloc.2
    IL_0090:  br.s       IL_00a4

    IL_0092:  ldarg.0
    IL_0093:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_0098:  ldarg.0
    IL_0099:  ldfld      string WpfPLData.Comp::_propertyId
    IL_009e:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::IndexOf(!0)
    IL_00a3:  stloc.3
    IL_00a4:  ldc.i4.0
    IL_00a5:  stloc.s    V_4
    IL_00a7:  ldc.i4.0
    IL_00a8:  stloc.s    V_5
    IL_00aa:  ldarg.0
    IL_00ab:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_00b0:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_00b5:  stloc.s    V_8
    IL_00b7:  ldloc.s    V_8
    IL_00b9:  ldc.i4.1
    IL_00ba:  sub
    IL_00bb:  switch     ( 
                          IL_00fb,
                          IL_0157,
                          IL_01b3,
                          IL_01f4,
                          IL_0235,
                          IL_0266,
                          IL_02b5,
                          IL_0304,
                          IL_0338)
    IL_00e4:  ldloc.s    V_8
    IL_00e6:  ldc.i4.s   29
    IL_00e8:  beq        IL_0382

    IL_00ed:  ldloc.s    V_8
    IL_00ef:  ldc.i4.s   30
    IL_00f1:  beq        IL_03be

    IL_00f6:  br         IL_03f8

    IL_00fb:  ldarg.0
    IL_00fc:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_0101:  ldc.i4.m1
    IL_0102:  bne.un.s   IL_0119

    IL_0104:  ldarg.0
    IL_0105:  ldfld      string WpfPLData.Comp::TempAmt
    IL_010a:  ldstr      ""
    IL_010f:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_0114:  brfalse    IL_03f8

    IL_0119:  ldarg.0
    IL_011a:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_011f:  ldloc.1
    IL_0120:  ldelem.i4
    IL_0121:  ldc.i4.m1
    IL_0122:  beq.s      IL_0134

    IL_0124:  ldloc.s    V_4
    IL_0126:  ldc.i4.1
    IL_0127:  add
    IL_0128:  stloc.s    V_4
    IL_012a:  ldarg.0
    IL_012b:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_0130:  ldlen
    IL_0131:  conv.i4
    IL_0132:  stloc.s    V_5
    IL_0134:  ldarg.0
    IL_0135:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_013a:  ldloc.1
    IL_013b:  ldelem.i4
    IL_013c:  ldc.i4.m1
    IL_013d:  beq        IL_03f8

    IL_0142:  ldloc.s    V_4
    IL_0144:  ldc.i4.1
    IL_0145:  add
    IL_0146:  stloc.s    V_4
    IL_0148:  ldarg.0
    IL_0149:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_014e:  ldlen
    IL_014f:  conv.i4
    IL_0150:  stloc.s    V_5
    IL_0152:  br         IL_03f8

    IL_0157:  ldarg.0
    IL_0158:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_015d:  ldc.i4.m1
    IL_015e:  bne.un.s   IL_0175

    IL_0160:  ldarg.0
    IL_0161:  ldfld      string WpfPLData.Comp::PresAmt
    IL_0166:  ldstr      ""
    IL_016b:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_0170:  brfalse    IL_03f8

    IL_0175:  ldarg.0
    IL_0176:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_017b:  ldloc.1
    IL_017c:  ldelem.i4
    IL_017d:  ldc.i4.m1
    IL_017e:  beq.s      IL_0190

    IL_0180:  ldloc.s    V_4
    IL_0182:  ldc.i4.1
    IL_0183:  add
    IL_0184:  stloc.s    V_4
    IL_0186:  ldarg.0
    IL_0187:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_018c:  ldlen
    IL_018d:  conv.i4
    IL_018e:  stloc.s    V_5
    IL_0190:  ldarg.0
    IL_0191:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_0196:  ldloc.1
    IL_0197:  ldelem.i4
    IL_0198:  ldc.i4.m1
    IL_0199:  beq        IL_03f8

    IL_019e:  ldloc.s    V_4
    IL_01a0:  ldc.i4.1
    IL_01a1:  add
    IL_01a2:  stloc.s    V_4
    IL_01a4:  ldarg.0
    IL_01a5:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_01aa:  ldlen
    IL_01ab:  conv.i4
    IL_01ac:  stloc.s    V_5
    IL_01ae:  br         IL_03f8

    IL_01b3:  ldarg.0
    IL_01b4:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_01b9:  ldc.i4.m1
    IL_01ba:  bne.un.s   IL_01d1

    IL_01bc:  ldarg.0
    IL_01bd:  ldfld      string WpfPLData.Comp::TempAmt
    IL_01c2:  ldstr      ""
    IL_01c7:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_01cc:  brfalse    IL_03f8

    IL_01d1:  ldarg.0
    IL_01d2:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_01d7:  ldloc.1
    IL_01d8:  ldelem.i4
    IL_01d9:  ldc.i4.m1
    IL_01da:  beq        IL_03f8

    IL_01df:  ldloc.s    V_4
    IL_01e1:  ldc.i4.1
    IL_01e2:  add
    IL_01e3:  stloc.s    V_4
    IL_01e5:  ldarg.0
    IL_01e6:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_01eb:  ldlen
    IL_01ec:  conv.i4
    IL_01ed:  stloc.s    V_5
    IL_01ef:  br         IL_03f8

    IL_01f4:  ldarg.0
    IL_01f5:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_01fa:  ldc.i4.m1
    IL_01fb:  bne.un.s   IL_0212

    IL_01fd:  ldarg.0
    IL_01fe:  ldfld      string WpfPLData.Comp::PresAmt
    IL_0203:  ldstr      ""
    IL_0208:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_020d:  brfalse    IL_03f8

    IL_0212:  ldarg.0
    IL_0213:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_0218:  ldloc.1
    IL_0219:  ldelem.i4
    IL_021a:  ldc.i4.m1
    IL_021b:  beq        IL_03f8

    IL_0220:  ldloc.s    V_4
    IL_0222:  ldc.i4.1
    IL_0223:  add
    IL_0224:  stloc.s    V_4
    IL_0226:  ldarg.0
    IL_0227:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_022c:  ldlen
    IL_022d:  conv.i4
    IL_022e:  stloc.s    V_5
    IL_0230:  br         IL_03f8

    IL_0235:  ldarg.0
    IL_0236:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_023b:  ldloc.1
    IL_023c:  ldelem.i4
    IL_023d:  ldc.i4.m1
    IL_023e:  beq        IL_03f8

    IL_0243:  ldarg.0
    IL_0244:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_0249:  ldloc.1
    IL_024a:  ldelem.i4
    IL_024b:  ldc.i4.m1
    IL_024c:  beq        IL_03f8

    IL_0251:  ldloc.s    V_4
    IL_0253:  ldc.i4.1
    IL_0254:  add
    IL_0255:  stloc.s    V_4
    IL_0257:  ldarg.0
    IL_0258:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_025d:  ldlen
    IL_025e:  conv.i4
    IL_025f:  stloc.s    V_5
    IL_0261:  br         IL_03f8

    IL_0266:  ldarg.0
    IL_0267:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_026c:  ldc.i4.m1
    IL_026d:  bne.un.s   IL_0284

    IL_026f:  ldarg.0
    IL_0270:  ldfld      string WpfPLData.Comp::TempAmt
    IL_0275:  ldstr      ""
    IL_027a:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_027f:  brfalse    IL_03f8

    IL_0284:  ldarg.0
    IL_0285:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_028a:  ldloc.1
    IL_028b:  ldelem.i4
    IL_028c:  ldc.i4.m1
    IL_028d:  beq        IL_03f8

    IL_0292:  ldarg.0
    IL_0293:  ldfld      int32[] WpfPLData.Comp::X2c
    IL_0298:  ldloc.1
    IL_0299:  ldelem.i4
    IL_029a:  ldc.i4.m1
    IL_029b:  beq        IL_03f8

    IL_02a0:  ldloc.s    V_4
    IL_02a2:  ldc.i4.2
    IL_02a3:  add
    IL_02a4:  stloc.s    V_4
    IL_02a6:  ldarg.0
    IL_02a7:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_02ac:  ldlen
    IL_02ad:  conv.i4
    IL_02ae:  stloc.s    V_5
    IL_02b0:  br         IL_03f8

    IL_02b5:  ldarg.0
    IL_02b6:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_02bb:  ldc.i4.m1
    IL_02bc:  bne.un.s   IL_02d3

    IL_02be:  ldarg.0
    IL_02bf:  ldfld      string WpfPLData.Comp::PresAmt
    IL_02c4:  ldstr      ""
    IL_02c9:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_02ce:  brfalse    IL_03f8

    IL_02d3:  ldarg.0
    IL_02d4:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_02d9:  ldloc.1
    IL_02da:  ldelem.i4
    IL_02db:  ldc.i4.m1
    IL_02dc:  beq        IL_03f8

    IL_02e1:  ldarg.0
    IL_02e2:  ldfld      int32[] WpfPLData.Comp::X2c
    IL_02e7:  ldloc.1
    IL_02e8:  ldelem.i4
    IL_02e9:  ldc.i4.m1
    IL_02ea:  beq        IL_03f8

    IL_02ef:  ldloc.s    V_4
    IL_02f1:  ldc.i4.2
    IL_02f2:  add
    IL_02f3:  stloc.s    V_4
    IL_02f5:  ldarg.0
    IL_02f6:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_02fb:  ldlen
    IL_02fc:  conv.i4
    IL_02fd:  stloc.s    V_5
    IL_02ff:  br         IL_03f8

    IL_0304:  ldarg.0
    IL_0305:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_030a:  ldloc.1
    IL_030b:  ldelem.i4
    IL_030c:  ldc.i4.m1
    IL_030d:  beq        IL_03f8

    IL_0312:  ldloc.2
    IL_0313:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Count()
    IL_0318:  ldc.i4.0
    IL_0319:  ble        IL_03f8

    IL_031e:  ldloc.s    V_4
    IL_0320:  ldloc.2
    IL_0321:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Count()
    IL_0326:  add
    IL_0327:  stloc.s    V_4
    IL_0329:  ldarg.0
    IL_032a:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_032f:  ldlen
    IL_0330:  conv.i4
    IL_0331:  stloc.s    V_5
    IL_0333:  br         IL_03f8

    IL_0338:  ldarg.0
    IL_0339:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_033e:  ldc.i4.m1
    IL_033f:  bne.un.s   IL_035f

    IL_0341:  ldarg.0
    IL_0342:  ldfld      string WpfPLData.Comp::TempAmt
    IL_0347:  ldstr      ""
    IL_034c:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_0351:  brtrue.s   IL_035f

    IL_0353:  ldarg.0
    IL_0354:  ldfld      int32 WpfPLData.Comp::Temp2Element
    IL_0359:  ldc.i4.m1
    IL_035a:  beq        IL_03f8

    IL_035f:  ldloc.2
    IL_0360:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Count()
    IL_0365:  ldc.i4.0
    IL_0366:  ble        IL_03f8

    IL_036b:  ldloc.s    V_4
    IL_036d:  ldloc.2
    IL_036e:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Count()
    IL_0373:  add
    IL_0374:  stloc.s    V_4
    IL_0376:  ldarg.0
    IL_0377:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_037c:  ldlen
    IL_037d:  conv.i4
    IL_037e:  stloc.s    V_5
    IL_0380:  br.s       IL_03f8

    IL_0382:  ldarg.0
    IL_0383:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_0388:  ldc.i4.m1
    IL_0389:  bne.un.s   IL_039d

    IL_038b:  ldarg.0
    IL_038c:  ldfld      string WpfPLData.Comp::TempAmt
    IL_0391:  ldstr      ""
    IL_0396:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_039b:  brfalse.s  IL_03f8

    IL_039d:  ldarg.0
    IL_039e:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_03a3:  ldloc.3
    IL_03a4:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_03a9:  ldc.i4.m1
    IL_03aa:  beq.s      IL_03f8

    IL_03ac:  ldloc.s    V_4
    IL_03ae:  ldc.i4.1
    IL_03af:  add
    IL_03b0:  stloc.s    V_4
    IL_03b2:  ldarg.0
    IL_03b3:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_03b8:  ldlen
    IL_03b9:  conv.i4
    IL_03ba:  stloc.s    V_5
    IL_03bc:  br.s       IL_03f8

    IL_03be:  ldarg.0
    IL_03bf:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_03c4:  ldc.i4.m1
    IL_03c5:  bne.un.s   IL_03d9

    IL_03c7:  ldarg.0
    IL_03c8:  ldfld      string WpfPLData.Comp::PresAmt
    IL_03cd:  ldstr      ""
    IL_03d2:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_03d7:  brfalse.s  IL_03f8

    IL_03d9:  ldarg.0
    IL_03da:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_03df:  ldloc.3
    IL_03e0:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_03e5:  ldc.i4.m1
    IL_03e6:  beq.s      IL_03f8

    IL_03e8:  ldloc.s    V_4
    IL_03ea:  ldc.i4.1
    IL_03eb:  add
    IL_03ec:  stloc.s    V_4
    IL_03ee:  ldarg.0
    IL_03ef:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_03f4:  ldlen
    IL_03f5:  conv.i4
    IL_03f6:  stloc.s    V_5
    IL_03f8:  ldarg.0
    IL_03f9:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_03fe:  callvirt   instance void AspenTech.AspenPlus.Happ.IHWizardPlot::RemoveAllDependentVariable()
    IL_0403:  ldarg.0
    IL_0404:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0409:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_040e:  ldloc.s    V_4
    IL_0410:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NVariables(int32)
    IL_0415:  ldarg.0
    IL_0416:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_041b:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0420:  ldloc.s    V_4
    IL_0422:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NXVariables(int32)
    IL_0427:  ldarg.0
    IL_0428:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_042d:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0432:  ldloc.s    V_5
    IL_0434:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NPoints(int32)
    IL_0439:  ldc.i4.0
    IL_043a:  stloc.s    V_6
    IL_043c:  ldloc.s    V_4
    IL_043e:  newarr     [mscorlib]System.Boolean
    IL_0443:  stloc.s    V_7
    IL_0445:  ldc.i4.0
    IL_0446:  stloc.s    V_9
    IL_0448:  br.s       IL_0456

    IL_044a:  ldloc.s    V_7
    IL_044c:  ldloc.s    V_9
    IL_044e:  ldc.i4.0
    IL_044f:  stelem.i1
    IL_0450:  ldloc.s    V_9
    IL_0452:  ldc.i4.1
    IL_0453:  add
    IL_0454:  stloc.s    V_9
    IL_0456:  ldloc.s    V_9
    IL_0458:  ldloc.s    V_4
    IL_045a:  blt.s      IL_044a

    IL_045c:  ldarg.0
    IL_045d:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0462:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_0467:  stloc.s    V_8
    IL_0469:  ldloc.s    V_8
    IL_046b:  ldc.i4.1
    IL_046c:  sub
    IL_046d:  switch     ( 
                          IL_04ad,
                          IL_0b9d,
                          IL_04ad,
                          IL_0b9d,
                          IL_128d,
                          IL_13f8,
                          IL_169f,
                          IL_1946,
                          IL_1af4)
    IL_0496:  ldloc.s    V_8
    IL_0498:  ldc.i4.s   29
    IL_049a:  beq        IL_2433

    IL_049f:  ldloc.s    V_8
    IL_04a1:  ldc.i4.s   30
    IL_04a3:  beq        IL_28bd

    IL_04a8:  br         IL_2c6c

    IL_04ad:  ldarg.0
    IL_04ae:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_04b3:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_04b8:  ldarg.0
    IL_04b9:  ldfld      string WpfPLData.Comp::MoleType
    IL_04be:  ldarg.0
    IL_04bf:  ldfld      string WpfPLData.Comp::_componentId
    IL_04c4:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_04c9:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_04ce:  ldarg.0
    IL_04cf:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_04d4:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_04d9:  ldc.i4.1
    IL_04da:  bne.un     IL_0829

    IL_04df:  ldarg.0
    IL_04e0:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_04e5:  ldc.i4.m1
    IL_04e6:  bne.un.s   IL_04fd

    IL_04e8:  ldarg.0
    IL_04e9:  ldfld      string WpfPLData.Comp::TempAmt
    IL_04ee:  ldstr      ""
    IL_04f3:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_04f8:  brfalse    IL_0829

    IL_04fd:  ldarg.0
    IL_04fe:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_0503:  ldloc.1
    IL_0504:  ldelem.i4
    IL_0505:  ldc.i4.m1
    IL_0506:  beq        IL_0829

    IL_050b:  ldc.i4.0
    IL_050c:  stloc.s    V_10
    IL_050e:  br         IL_0814

    IL_0513:  ldloc.s    V_10
    IL_0515:  stloc.s    V_11
    IL_0517:  ldloc.s    V_7
    IL_0519:  ldloc.s    V_6
    IL_051b:  ldelem.u1
    IL_051c:  brtrue     IL_0748

    IL_0521:  ldstr      ""
    IL_0526:  stloc.s    V_12
    IL_0528:  ldarg.0
    IL_0529:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_052e:  ldc.i4.m1
    IL_052f:  beq        IL_070c

    IL_0534:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__4'
    IL_0539:  brtrue.s   IL_055f

    IL_053b:  ldc.i4.0
    IL_053c:  ldtoken    [mscorlib]System.String
    IL_0541:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0546:  ldtoken    WpfPLData.Comp
    IL_054b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0550:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_0555:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_055a:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__4'
    IL_055f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__4'
    IL_0564:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_0569:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__4'
    IL_056e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__3'
    IL_0573:  brtrue.s   IL_05aa

    IL_0575:  ldc.i4.0
    IL_0576:  ldc.i4.0
    IL_0577:  ldtoken    WpfPLData.Comp
    IL_057c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0581:  ldc.i4.2
    IL_0582:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_0587:  dup
    IL_0588:  ldc.i4.0
    IL_0589:  ldc.i4.0
    IL_058a:  ldnull
    IL_058b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0590:  stelem.ref
    IL_0591:  dup
    IL_0592:  ldc.i4.1
    IL_0593:  ldc.i4.3
    IL_0594:  ldnull
    IL_0595:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_059a:  stelem.ref
    IL_059b:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_05a0:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_05a5:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__3'
    IL_05aa:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__3'
    IL_05af:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_05b4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__3'
    IL_05b9:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__2'
    IL_05be:  brtrue.s   IL_05f5

    IL_05c0:  ldc.i4.0
    IL_05c1:  ldc.i4.0
    IL_05c2:  ldtoken    WpfPLData.Comp
    IL_05c7:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_05cc:  ldc.i4.2
    IL_05cd:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_05d2:  dup
    IL_05d3:  ldc.i4.0
    IL_05d4:  ldc.i4.0
    IL_05d5:  ldnull
    IL_05d6:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_05db:  stelem.ref
    IL_05dc:  dup
    IL_05dd:  ldc.i4.1
    IL_05de:  ldc.i4.1
    IL_05df:  ldnull
    IL_05e0:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_05e5:  stelem.ref
    IL_05e6:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_05eb:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_05f0:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__2'
    IL_05f5:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__2'
    IL_05fa:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_05ff:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__2'
    IL_0604:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__1'
    IL_0609:  brtrue.s   IL_0640

    IL_060b:  ldc.i4.0
    IL_060c:  ldc.i4.0
    IL_060d:  ldtoken    WpfPLData.Comp
    IL_0612:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0617:  ldc.i4.2
    IL_0618:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_061d:  dup
    IL_061e:  ldc.i4.0
    IL_061f:  ldc.i4.0
    IL_0620:  ldnull
    IL_0621:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0626:  stelem.ref
    IL_0627:  dup
    IL_0628:  ldc.i4.1
    IL_0629:  ldc.i4.3
    IL_062a:  ldnull
    IL_062b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0630:  stelem.ref
    IL_0631:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0636:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_063b:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__1'
    IL_0640:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__1'
    IL_0645:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_064a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__1'
    IL_064f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__0'
    IL_0654:  brtrue.s   IL_068b

    IL_0656:  ldc.i4.0
    IL_0657:  ldc.i4.0
    IL_0658:  ldtoken    WpfPLData.Comp
    IL_065d:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0662:  ldc.i4.2
    IL_0663:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_0668:  dup
    IL_0669:  ldc.i4.0
    IL_066a:  ldc.i4.3
    IL_066b:  ldnull
    IL_066c:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0671:  stelem.ref
    IL_0672:  dup
    IL_0673:  ldc.i4.1
    IL_0674:  ldc.i4.0
    IL_0675:  ldnull
    IL_0676:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_067b:  stelem.ref
    IL_067c:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0681:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0686:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__0'
    IL_068b:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__0'
    IL_0690:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Target
    IL_0695:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__0'
    IL_069a:  ldstr      " ("
    IL_069f:  ldloc.0
    IL_06a0:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_06a5:  ldarg.0
    IL_06a6:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_06ab:  ldc.i4.0
    IL_06ac:  ldelem.i4
    IL_06ad:  box        [mscorlib]System.Int32
    IL_06b2:  ldarg.0
    IL_06b3:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_06b8:  box        [mscorlib]System.Int32
    IL_06bd:  ldarg.0
    IL_06be:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_06c3:  box        [mscorlib]System.Int32
    IL_06c8:  ldsfld     object [mscorlib]System.Type::Missing
    IL_06cd:  ldsfld     object [mscorlib]System.Type::Missing
    IL_06d2:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_06d7:  ldsfld     object [mscorlib]System.Type::Missing
    IL_06dc:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_06e1:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_06e6:  ldstr      " "
    IL_06eb:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_06f0:  ldarg.0
    IL_06f1:  ldfld      string WpfPLData.Comp::PresUnit
    IL_06f6:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_06fb:  ldstr      ")"
    IL_0700:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_0705:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_070a:  stloc.s    V_12
    IL_070c:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_Y_ID()
    IL_0711:  ldloc.s    V_12
    IL_0713:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_0718:  stloc.s    V_13
    IL_071a:  ldarg.0
    IL_071b:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0720:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0725:  ldloc.s    V_6
    IL_0727:  ldloc.s    V_13
    IL_0729:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_072e:  ldarg.0
    IL_072f:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0734:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0739:  ldloc.s    V_6
    IL_073b:  ldc.i4.s   15
    IL_073d:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_0742:  ldloc.s    V_7
    IL_0744:  ldloc.s    V_6
    IL_0746:  ldc.i4.1
    IL_0747:  stelem.i1
    IL_0748:  ldarg.0
    IL_0749:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_074e:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0753:  ldloc.s    V_6
    IL_0755:  ldloc.s    V_11
    IL_0757:  ldc.i4.1
    IL_0758:  ldloc.0
    IL_0759:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_075e:  ldarg.0
    IL_075f:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_0764:  ldloc.s    V_11
    IL_0766:  ldelem.i4
    IL_0767:  box        [mscorlib]System.Int32
    IL_076c:  ldarg.0
    IL_076d:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_0772:  ldloc.1
    IL_0773:  ldelem.i4
    IL_0774:  box        [mscorlib]System.Int32
    IL_0779:  ldarg.0
    IL_077a:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_077f:  ldloc.1
    IL_0780:  ldelem.i4
    IL_0781:  box        [mscorlib]System.Int32
    IL_0786:  ldsfld     object [mscorlib]System.Type::Missing
    IL_078b:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0790:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_0795:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_079a:  ldarg.0
    IL_079b:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_07a0:  ldc.i4.m1
    IL_07a1:  beq.s      IL_07f3

    IL_07a3:  ldarg.0
    IL_07a4:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_07a9:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_07ae:  ldloc.s    V_6
    IL_07b0:  ldloc.s    V_11
    IL_07b2:  ldc.i4.1
    IL_07b3:  ldloc.0
    IL_07b4:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_07b9:  ldarg.0
    IL_07ba:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_07bf:  ldloc.s    V_11
    IL_07c1:  ldelem.i4
    IL_07c2:  box        [mscorlib]System.Int32
    IL_07c7:  ldarg.0
    IL_07c8:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_07cd:  box        [mscorlib]System.Int32
    IL_07d2:  ldarg.0
    IL_07d3:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_07d8:  box        [mscorlib]System.Int32
    IL_07dd:  ldsfld     object [mscorlib]System.Type::Missing
    IL_07e2:  ldsfld     object [mscorlib]System.Type::Missing
    IL_07e7:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_07ec:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_07f1:  br.s       IL_080e

    IL_07f3:  ldarg.0
    IL_07f4:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_07f9:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_07fe:  ldloc.s    V_6
    IL_0800:  ldloc.s    V_11
    IL_0802:  ldc.i4.0
    IL_0803:  ldarg.0
    IL_0804:  ldfld      string WpfPLData.Comp::TempAmt
    IL_0809:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_080e:  ldloc.s    V_10
    IL_0810:  ldc.i4.1
    IL_0811:  add
    IL_0812:  stloc.s    V_10
    IL_0814:  ldloc.s    V_10
    IL_0816:  ldarg.0
    IL_0817:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_081c:  ldlen
    IL_081d:  conv.i4
    IL_081e:  blt        IL_0513

    IL_0823:  ldloc.s    V_6
    IL_0825:  ldc.i4.1
    IL_0826:  add
    IL_0827:  stloc.s    V_6
    IL_0829:  ldarg.0
    IL_082a:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_082f:  ldc.i4.m1
    IL_0830:  bne.un.s   IL_0847

    IL_0832:  ldarg.0
    IL_0833:  ldfld      string WpfPLData.Comp::TempAmt
    IL_0838:  ldstr      ""
    IL_083d:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_0842:  brfalse    IL_2c6c

    IL_0847:  ldarg.0
    IL_0848:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_084d:  ldloc.1
    IL_084e:  ldelem.i4
    IL_084f:  ldc.i4.m1
    IL_0850:  beq        IL_2c6c

    IL_0855:  ldc.i4.0
    IL_0856:  stloc.s    V_14
    IL_0858:  br         IL_0b83

    IL_085d:  ldloc.s    V_14
    IL_085f:  stloc.s    V_15
    IL_0861:  ldloc.s    V_7
    IL_0863:  ldloc.s    V_6
    IL_0865:  ldelem.u1
    IL_0866:  brtrue     IL_0ab7

    IL_086b:  ldstr      ""
    IL_0870:  stloc.s    V_16
    IL_0872:  ldarg.0
    IL_0873:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_0878:  ldc.i4.m1
    IL_0879:  beq        IL_0a56

    IL_087e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__9'
    IL_0883:  brtrue.s   IL_08a9

    IL_0885:  ldc.i4.0
    IL_0886:  ldtoken    [mscorlib]System.String
    IL_088b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0890:  ldtoken    WpfPLData.Comp
    IL_0895:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_089a:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_089f:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_08a4:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__9'
    IL_08a9:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__9'
    IL_08ae:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_08b3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__9'
    IL_08b8:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__8'
    IL_08bd:  brtrue.s   IL_08f4

    IL_08bf:  ldc.i4.0
    IL_08c0:  ldc.i4.0
    IL_08c1:  ldtoken    WpfPLData.Comp
    IL_08c6:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_08cb:  ldc.i4.2
    IL_08cc:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_08d1:  dup
    IL_08d2:  ldc.i4.0
    IL_08d3:  ldc.i4.0
    IL_08d4:  ldnull
    IL_08d5:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_08da:  stelem.ref
    IL_08db:  dup
    IL_08dc:  ldc.i4.1
    IL_08dd:  ldc.i4.3
    IL_08de:  ldnull
    IL_08df:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_08e4:  stelem.ref
    IL_08e5:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_08ea:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_08ef:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__8'
    IL_08f4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__8'
    IL_08f9:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_08fe:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__8'
    IL_0903:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__7'
    IL_0908:  brtrue.s   IL_093f

    IL_090a:  ldc.i4.0
    IL_090b:  ldc.i4.0
    IL_090c:  ldtoken    WpfPLData.Comp
    IL_0911:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0916:  ldc.i4.2
    IL_0917:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_091c:  dup
    IL_091d:  ldc.i4.0
    IL_091e:  ldc.i4.0
    IL_091f:  ldnull
    IL_0920:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0925:  stelem.ref
    IL_0926:  dup
    IL_0927:  ldc.i4.1
    IL_0928:  ldc.i4.1
    IL_0929:  ldnull
    IL_092a:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_092f:  stelem.ref
    IL_0930:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0935:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_093a:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__7'
    IL_093f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__7'
    IL_0944:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_0949:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__7'
    IL_094e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__6'
    IL_0953:  brtrue.s   IL_098a

    IL_0955:  ldc.i4.0
    IL_0956:  ldc.i4.0
    IL_0957:  ldtoken    WpfPLData.Comp
    IL_095c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0961:  ldc.i4.2
    IL_0962:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_0967:  dup
    IL_0968:  ldc.i4.0
    IL_0969:  ldc.i4.0
    IL_096a:  ldnull
    IL_096b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0970:  stelem.ref
    IL_0971:  dup
    IL_0972:  ldc.i4.1
    IL_0973:  ldc.i4.3
    IL_0974:  ldnull
    IL_0975:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_097a:  stelem.ref
    IL_097b:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0980:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0985:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__6'
    IL_098a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__6'
    IL_098f:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_0994:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__6'
    IL_0999:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__5'
    IL_099e:  brtrue.s   IL_09d5

    IL_09a0:  ldc.i4.0
    IL_09a1:  ldc.i4.0
    IL_09a2:  ldtoken    WpfPLData.Comp
    IL_09a7:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_09ac:  ldc.i4.2
    IL_09ad:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_09b2:  dup
    IL_09b3:  ldc.i4.0
    IL_09b4:  ldc.i4.3
    IL_09b5:  ldnull
    IL_09b6:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_09bb:  stelem.ref
    IL_09bc:  dup
    IL_09bd:  ldc.i4.1
    IL_09be:  ldc.i4.0
    IL_09bf:  ldnull
    IL_09c0:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_09c5:  stelem.ref
    IL_09c6:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_09cb:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_09d0:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__5'
    IL_09d5:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__5'
    IL_09da:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Target
    IL_09df:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__5'
    IL_09e4:  ldstr      " ("
    IL_09e9:  ldloc.0
    IL_09ea:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_09ef:  ldarg.0
    IL_09f0:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_09f5:  ldc.i4.0
    IL_09f6:  ldelem.i4
    IL_09f7:  box        [mscorlib]System.Int32
    IL_09fc:  ldarg.0
    IL_09fd:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_0a02:  box        [mscorlib]System.Int32
    IL_0a07:  ldarg.0
    IL_0a08:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_0a0d:  box        [mscorlib]System.Int32
    IL_0a12:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0a17:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0a1c:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_0a21:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0a26:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_0a2b:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_0a30:  ldstr      " "
    IL_0a35:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_0a3a:  ldarg.0
    IL_0a3b:  ldfld      string WpfPLData.Comp::PresUnit
    IL_0a40:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_0a45:  ldstr      ")"
    IL_0a4a:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_0a4f:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_0a54:  stloc.s    V_16
    IL_0a56:  ldstr      ""
    IL_0a5b:  stloc.s    V_17
    IL_0a5d:  ldarg.0
    IL_0a5e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0a63:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_0a68:  ldc.i4.1
    IL_0a69:  bne.un.s   IL_0a7b

    IL_0a6b:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_X_ID()
    IL_0a70:  ldloc.s    V_16
    IL_0a72:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_0a77:  stloc.s    V_17
    IL_0a79:  br.s       IL_0a89

    IL_0a7b:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_ID_Format()
    IL_0a80:  ldloc.s    V_16
    IL_0a82:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_0a87:  stloc.s    V_17
    IL_0a89:  ldarg.0
    IL_0a8a:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0a8f:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0a94:  ldloc.s    V_6
    IL_0a96:  ldloc.s    V_17
    IL_0a98:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_0a9d:  ldarg.0
    IL_0a9e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0aa3:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0aa8:  ldloc.s    V_6
    IL_0aaa:  ldc.i4.s   15
    IL_0aac:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_0ab1:  ldloc.s    V_7
    IL_0ab3:  ldloc.s    V_6
    IL_0ab5:  ldc.i4.1
    IL_0ab6:  stelem.i1
    IL_0ab7:  ldarg.0
    IL_0ab8:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0abd:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0ac2:  ldloc.s    V_6
    IL_0ac4:  ldloc.s    V_15
    IL_0ac6:  ldc.i4.1
    IL_0ac7:  ldloc.0
    IL_0ac8:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0acd:  ldarg.0
    IL_0ace:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_0ad3:  ldloc.s    V_15
    IL_0ad5:  ldelem.i4
    IL_0ad6:  box        [mscorlib]System.Int32
    IL_0adb:  ldarg.0
    IL_0adc:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_0ae1:  ldloc.1
    IL_0ae2:  ldelem.i4
    IL_0ae3:  box        [mscorlib]System.Int32
    IL_0ae8:  ldarg.0
    IL_0ae9:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_0aee:  ldloc.1
    IL_0aef:  ldelem.i4
    IL_0af0:  box        [mscorlib]System.Int32
    IL_0af5:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0afa:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0aff:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_0b04:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_0b09:  ldarg.0
    IL_0b0a:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_0b0f:  ldc.i4.m1
    IL_0b10:  beq.s      IL_0b62

    IL_0b12:  ldarg.0
    IL_0b13:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0b18:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0b1d:  ldloc.s    V_6
    IL_0b1f:  ldloc.s    V_15
    IL_0b21:  ldc.i4.1
    IL_0b22:  ldloc.0
    IL_0b23:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0b28:  ldarg.0
    IL_0b29:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_0b2e:  ldloc.s    V_15
    IL_0b30:  ldelem.i4
    IL_0b31:  box        [mscorlib]System.Int32
    IL_0b36:  ldarg.0
    IL_0b37:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_0b3c:  box        [mscorlib]System.Int32
    IL_0b41:  ldarg.0
    IL_0b42:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_0b47:  box        [mscorlib]System.Int32
    IL_0b4c:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0b51:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0b56:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_0b5b:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_0b60:  br.s       IL_0b7d

    IL_0b62:  ldarg.0
    IL_0b63:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0b68:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0b6d:  ldloc.s    V_6
    IL_0b6f:  ldloc.s    V_15
    IL_0b71:  ldc.i4.0
    IL_0b72:  ldarg.0
    IL_0b73:  ldfld      string WpfPLData.Comp::TempAmt
    IL_0b78:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_0b7d:  ldloc.s    V_14
    IL_0b7f:  ldc.i4.1
    IL_0b80:  add
    IL_0b81:  stloc.s    V_14
    IL_0b83:  ldloc.s    V_14
    IL_0b85:  ldarg.0
    IL_0b86:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_0b8b:  ldlen
    IL_0b8c:  conv.i4
    IL_0b8d:  blt        IL_085d

    IL_0b92:  ldloc.s    V_6
    IL_0b94:  ldc.i4.1
    IL_0b95:  add
    IL_0b96:  stloc.s    V_6
    IL_0b98:  br         IL_2c6c

    IL_0b9d:  ldarg.0
    IL_0b9e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0ba3:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0ba8:  ldarg.0
    IL_0ba9:  ldfld      string WpfPLData.Comp::MoleType
    IL_0bae:  ldarg.0
    IL_0baf:  ldfld      string WpfPLData.Comp::_componentId
    IL_0bb4:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0bb9:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_0bbe:  ldarg.0
    IL_0bbf:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0bc4:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_0bc9:  ldc.i4.2
    IL_0bca:  bne.un     IL_0f19

    IL_0bcf:  ldarg.0
    IL_0bd0:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_0bd5:  ldc.i4.m1
    IL_0bd6:  bne.un.s   IL_0bed

    IL_0bd8:  ldarg.0
    IL_0bd9:  ldfld      string WpfPLData.Comp::PresAmt
    IL_0bde:  ldstr      ""
    IL_0be3:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_0be8:  brfalse    IL_0f19

    IL_0bed:  ldarg.0
    IL_0bee:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_0bf3:  ldloc.1
    IL_0bf4:  ldelem.i4
    IL_0bf5:  ldc.i4.m1
    IL_0bf6:  beq        IL_0f19

    IL_0bfb:  ldc.i4.0
    IL_0bfc:  stloc.s    V_18
    IL_0bfe:  br         IL_0f04

    IL_0c03:  ldloc.s    V_18
    IL_0c05:  stloc.s    V_19
    IL_0c07:  ldloc.s    V_7
    IL_0c09:  ldloc.s    V_6
    IL_0c0b:  ldelem.u1
    IL_0c0c:  brtrue     IL_0e38

    IL_0c11:  ldstr      ""
    IL_0c16:  stloc.s    V_20
    IL_0c18:  ldarg.0
    IL_0c19:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_0c1e:  ldc.i4.m1
    IL_0c1f:  beq        IL_0dfc

    IL_0c24:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__14'
    IL_0c29:  brtrue.s   IL_0c4f

    IL_0c2b:  ldc.i4.0
    IL_0c2c:  ldtoken    [mscorlib]System.String
    IL_0c31:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0c36:  ldtoken    WpfPLData.Comp
    IL_0c3b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0c40:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_0c45:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0c4a:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__14'
    IL_0c4f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__14'
    IL_0c54:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_0c59:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__14'
    IL_0c5e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__13'
    IL_0c63:  brtrue.s   IL_0c9a

    IL_0c65:  ldc.i4.0
    IL_0c66:  ldc.i4.0
    IL_0c67:  ldtoken    WpfPLData.Comp
    IL_0c6c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0c71:  ldc.i4.2
    IL_0c72:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_0c77:  dup
    IL_0c78:  ldc.i4.0
    IL_0c79:  ldc.i4.0
    IL_0c7a:  ldnull
    IL_0c7b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0c80:  stelem.ref
    IL_0c81:  dup
    IL_0c82:  ldc.i4.1
    IL_0c83:  ldc.i4.3
    IL_0c84:  ldnull
    IL_0c85:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0c8a:  stelem.ref
    IL_0c8b:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0c90:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0c95:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__13'
    IL_0c9a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__13'
    IL_0c9f:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_0ca4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__13'
    IL_0ca9:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__12'
    IL_0cae:  brtrue.s   IL_0ce5

    IL_0cb0:  ldc.i4.0
    IL_0cb1:  ldc.i4.0
    IL_0cb2:  ldtoken    WpfPLData.Comp
    IL_0cb7:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0cbc:  ldc.i4.2
    IL_0cbd:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_0cc2:  dup
    IL_0cc3:  ldc.i4.0
    IL_0cc4:  ldc.i4.0
    IL_0cc5:  ldnull
    IL_0cc6:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0ccb:  stelem.ref
    IL_0ccc:  dup
    IL_0ccd:  ldc.i4.1
    IL_0cce:  ldc.i4.1
    IL_0ccf:  ldnull
    IL_0cd0:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0cd5:  stelem.ref
    IL_0cd6:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0cdb:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0ce0:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__12'
    IL_0ce5:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__12'
    IL_0cea:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_0cef:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__12'
    IL_0cf4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__11'
    IL_0cf9:  brtrue.s   IL_0d30

    IL_0cfb:  ldc.i4.0
    IL_0cfc:  ldc.i4.0
    IL_0cfd:  ldtoken    WpfPLData.Comp
    IL_0d02:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0d07:  ldc.i4.2
    IL_0d08:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_0d0d:  dup
    IL_0d0e:  ldc.i4.0
    IL_0d0f:  ldc.i4.0
    IL_0d10:  ldnull
    IL_0d11:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0d16:  stelem.ref
    IL_0d17:  dup
    IL_0d18:  ldc.i4.1
    IL_0d19:  ldc.i4.3
    IL_0d1a:  ldnull
    IL_0d1b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0d20:  stelem.ref
    IL_0d21:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0d26:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0d2b:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__11'
    IL_0d30:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__11'
    IL_0d35:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_0d3a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__11'
    IL_0d3f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__10'
    IL_0d44:  brtrue.s   IL_0d7b

    IL_0d46:  ldc.i4.0
    IL_0d47:  ldc.i4.0
    IL_0d48:  ldtoken    WpfPLData.Comp
    IL_0d4d:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0d52:  ldc.i4.2
    IL_0d53:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_0d58:  dup
    IL_0d59:  ldc.i4.0
    IL_0d5a:  ldc.i4.3
    IL_0d5b:  ldnull
    IL_0d5c:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0d61:  stelem.ref
    IL_0d62:  dup
    IL_0d63:  ldc.i4.1
    IL_0d64:  ldc.i4.0
    IL_0d65:  ldnull
    IL_0d66:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0d6b:  stelem.ref
    IL_0d6c:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0d71:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0d76:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__10'
    IL_0d7b:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__10'
    IL_0d80:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Target
    IL_0d85:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__10'
    IL_0d8a:  ldstr      " ("
    IL_0d8f:  ldloc.0
    IL_0d90:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0d95:  ldarg.0
    IL_0d96:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_0d9b:  ldc.i4.0
    IL_0d9c:  ldelem.i4
    IL_0d9d:  box        [mscorlib]System.Int32
    IL_0da2:  ldarg.0
    IL_0da3:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_0da8:  box        [mscorlib]System.Int32
    IL_0dad:  ldarg.0
    IL_0dae:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_0db3:  box        [mscorlib]System.Int32
    IL_0db8:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0dbd:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0dc2:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_0dc7:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0dcc:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_0dd1:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_0dd6:  ldstr      " "
    IL_0ddb:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_0de0:  ldarg.0
    IL_0de1:  ldfld      string WpfPLData.Comp::TempUnit
    IL_0de6:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_0deb:  ldstr      ")"
    IL_0df0:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_0df5:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_0dfa:  stloc.s    V_20
    IL_0dfc:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_Y_ID()
    IL_0e01:  ldloc.s    V_20
    IL_0e03:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_0e08:  stloc.s    V_21
    IL_0e0a:  ldarg.0
    IL_0e0b:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0e10:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0e15:  ldloc.s    V_6
    IL_0e17:  ldloc.s    V_21
    IL_0e19:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_0e1e:  ldarg.0
    IL_0e1f:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0e24:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0e29:  ldloc.s    V_6
    IL_0e2b:  ldc.i4.s   15
    IL_0e2d:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_0e32:  ldloc.s    V_7
    IL_0e34:  ldloc.s    V_6
    IL_0e36:  ldc.i4.1
    IL_0e37:  stelem.i1
    IL_0e38:  ldarg.0
    IL_0e39:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0e3e:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0e43:  ldloc.s    V_6
    IL_0e45:  ldloc.s    V_19
    IL_0e47:  ldc.i4.1
    IL_0e48:  ldloc.0
    IL_0e49:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0e4e:  ldarg.0
    IL_0e4f:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_0e54:  ldloc.s    V_19
    IL_0e56:  ldelem.i4
    IL_0e57:  box        [mscorlib]System.Int32
    IL_0e5c:  ldarg.0
    IL_0e5d:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_0e62:  ldloc.1
    IL_0e63:  ldelem.i4
    IL_0e64:  box        [mscorlib]System.Int32
    IL_0e69:  ldarg.0
    IL_0e6a:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_0e6f:  ldloc.1
    IL_0e70:  ldelem.i4
    IL_0e71:  box        [mscorlib]System.Int32
    IL_0e76:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0e7b:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0e80:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_0e85:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_0e8a:  ldarg.0
    IL_0e8b:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_0e90:  ldc.i4.m1
    IL_0e91:  beq.s      IL_0ee3

    IL_0e93:  ldarg.0
    IL_0e94:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0e99:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0e9e:  ldloc.s    V_6
    IL_0ea0:  ldloc.s    V_19
    IL_0ea2:  ldc.i4.1
    IL_0ea3:  ldloc.0
    IL_0ea4:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0ea9:  ldarg.0
    IL_0eaa:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_0eaf:  ldloc.s    V_19
    IL_0eb1:  ldelem.i4
    IL_0eb2:  box        [mscorlib]System.Int32
    IL_0eb7:  ldarg.0
    IL_0eb8:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_0ebd:  box        [mscorlib]System.Int32
    IL_0ec2:  ldarg.0
    IL_0ec3:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_0ec8:  box        [mscorlib]System.Int32
    IL_0ecd:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0ed2:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0ed7:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_0edc:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_0ee1:  br.s       IL_0efe

    IL_0ee3:  ldarg.0
    IL_0ee4:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0ee9:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0eee:  ldloc.s    V_6
    IL_0ef0:  ldloc.s    V_19
    IL_0ef2:  ldc.i4.0
    IL_0ef3:  ldarg.0
    IL_0ef4:  ldfld      string WpfPLData.Comp::PresAmt
    IL_0ef9:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_0efe:  ldloc.s    V_18
    IL_0f00:  ldc.i4.1
    IL_0f01:  add
    IL_0f02:  stloc.s    V_18
    IL_0f04:  ldloc.s    V_18
    IL_0f06:  ldarg.0
    IL_0f07:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_0f0c:  ldlen
    IL_0f0d:  conv.i4
    IL_0f0e:  blt        IL_0c03

    IL_0f13:  ldloc.s    V_6
    IL_0f15:  ldc.i4.1
    IL_0f16:  add
    IL_0f17:  stloc.s    V_6
    IL_0f19:  ldarg.0
    IL_0f1a:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_0f1f:  ldc.i4.m1
    IL_0f20:  bne.un.s   IL_0f37

    IL_0f22:  ldarg.0
    IL_0f23:  ldfld      string WpfPLData.Comp::PresAmt
    IL_0f28:  ldstr      ""
    IL_0f2d:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_0f32:  brfalse    IL_2c6c

    IL_0f37:  ldarg.0
    IL_0f38:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_0f3d:  ldloc.1
    IL_0f3e:  ldelem.i4
    IL_0f3f:  ldc.i4.m1
    IL_0f40:  beq        IL_2c6c

    IL_0f45:  ldc.i4.0
    IL_0f46:  stloc.s    V_22
    IL_0f48:  br         IL_1273

    IL_0f4d:  ldloc.s    V_22
    IL_0f4f:  stloc.s    V_23
    IL_0f51:  ldloc.s    V_7
    IL_0f53:  ldloc.s    V_6
    IL_0f55:  ldelem.u1
    IL_0f56:  brtrue     IL_11a7

    IL_0f5b:  ldstr      ""
    IL_0f60:  stloc.s    V_24
    IL_0f62:  ldarg.0
    IL_0f63:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_0f68:  ldc.i4.m1
    IL_0f69:  beq        IL_1146

    IL_0f6e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__19'
    IL_0f73:  brtrue.s   IL_0f99

    IL_0f75:  ldc.i4.0
    IL_0f76:  ldtoken    [mscorlib]System.String
    IL_0f7b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0f80:  ldtoken    WpfPLData.Comp
    IL_0f85:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0f8a:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_0f8f:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0f94:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__19'
    IL_0f99:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__19'
    IL_0f9e:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_0fa3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__19'
    IL_0fa8:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__18'
    IL_0fad:  brtrue.s   IL_0fe4

    IL_0faf:  ldc.i4.0
    IL_0fb0:  ldc.i4.0
    IL_0fb1:  ldtoken    WpfPLData.Comp
    IL_0fb6:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0fbb:  ldc.i4.2
    IL_0fbc:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_0fc1:  dup
    IL_0fc2:  ldc.i4.0
    IL_0fc3:  ldc.i4.0
    IL_0fc4:  ldnull
    IL_0fc5:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0fca:  stelem.ref
    IL_0fcb:  dup
    IL_0fcc:  ldc.i4.1
    IL_0fcd:  ldc.i4.3
    IL_0fce:  ldnull
    IL_0fcf:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0fd4:  stelem.ref
    IL_0fd5:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0fda:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0fdf:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__18'
    IL_0fe4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__18'
    IL_0fe9:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_0fee:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__18'
    IL_0ff3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__17'
    IL_0ff8:  brtrue.s   IL_102f

    IL_0ffa:  ldc.i4.0
    IL_0ffb:  ldc.i4.0
    IL_0ffc:  ldtoken    WpfPLData.Comp
    IL_1001:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_1006:  ldc.i4.2
    IL_1007:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_100c:  dup
    IL_100d:  ldc.i4.0
    IL_100e:  ldc.i4.0
    IL_100f:  ldnull
    IL_1010:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_1015:  stelem.ref
    IL_1016:  dup
    IL_1017:  ldc.i4.1
    IL_1018:  ldc.i4.1
    IL_1019:  ldnull
    IL_101a:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_101f:  stelem.ref
    IL_1020:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_1025:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_102a:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__17'
    IL_102f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__17'
    IL_1034:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_1039:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__17'
    IL_103e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__16'
    IL_1043:  brtrue.s   IL_107a

    IL_1045:  ldc.i4.0
    IL_1046:  ldc.i4.0
    IL_1047:  ldtoken    WpfPLData.Comp
    IL_104c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_1051:  ldc.i4.2
    IL_1052:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_1057:  dup
    IL_1058:  ldc.i4.0
    IL_1059:  ldc.i4.0
    IL_105a:  ldnull
    IL_105b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_1060:  stelem.ref
    IL_1061:  dup
    IL_1062:  ldc.i4.1
    IL_1063:  ldc.i4.3
    IL_1064:  ldnull
    IL_1065:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_106a:  stelem.ref
    IL_106b:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_1070:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_1075:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__16'
    IL_107a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__16'
    IL_107f:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_1084:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__16'
    IL_1089:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__15'
    IL_108e:  brtrue.s   IL_10c5

    IL_1090:  ldc.i4.0
    IL_1091:  ldc.i4.0
    IL_1092:  ldtoken    WpfPLData.Comp
    IL_1097:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_109c:  ldc.i4.2
    IL_109d:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_10a2:  dup
    IL_10a3:  ldc.i4.0
    IL_10a4:  ldc.i4.3
    IL_10a5:  ldnull
    IL_10a6:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_10ab:  stelem.ref
    IL_10ac:  dup
    IL_10ad:  ldc.i4.1
    IL_10ae:  ldc.i4.0
    IL_10af:  ldnull
    IL_10b0:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_10b5:  stelem.ref
    IL_10b6:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_10bb:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_10c0:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__15'
    IL_10c5:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__15'
    IL_10ca:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Target
    IL_10cf:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__15'
    IL_10d4:  ldstr      " ("
    IL_10d9:  ldloc.0
    IL_10da:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_10df:  ldarg.0
    IL_10e0:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_10e5:  ldc.i4.0
    IL_10e6:  ldelem.i4
    IL_10e7:  box        [mscorlib]System.Int32
    IL_10ec:  ldarg.0
    IL_10ed:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_10f2:  box        [mscorlib]System.Int32
    IL_10f7:  ldarg.0
    IL_10f8:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_10fd:  box        [mscorlib]System.Int32
    IL_1102:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1107:  ldsfld     object [mscorlib]System.Type::Missing
    IL_110c:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_1111:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1116:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_111b:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_1120:  ldstr      " "
    IL_1125:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_112a:  ldarg.0
    IL_112b:  ldfld      string WpfPLData.Comp::TempUnit
    IL_1130:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_1135:  ldstr      ")"
    IL_113a:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_113f:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_1144:  stloc.s    V_24
    IL_1146:  ldstr      ""
    IL_114b:  stloc.s    V_25
    IL_114d:  ldarg.0
    IL_114e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1153:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_1158:  ldc.i4.2
    IL_1159:  bne.un.s   IL_116b

    IL_115b:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_X_ID()
    IL_1160:  ldloc.s    V_24
    IL_1162:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_1167:  stloc.s    V_25
    IL_1169:  br.s       IL_1179

    IL_116b:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_ID_Format()
    IL_1170:  ldloc.s    V_24
    IL_1172:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_1177:  stloc.s    V_25
    IL_1179:  ldarg.0
    IL_117a:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_117f:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1184:  ldloc.s    V_6
    IL_1186:  ldloc.s    V_25
    IL_1188:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_118d:  ldarg.0
    IL_118e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1193:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1198:  ldloc.s    V_6
    IL_119a:  ldc.i4.s   15
    IL_119c:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_11a1:  ldloc.s    V_7
    IL_11a3:  ldloc.s    V_6
    IL_11a5:  ldc.i4.1
    IL_11a6:  stelem.i1
    IL_11a7:  ldarg.0
    IL_11a8:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_11ad:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_11b2:  ldloc.s    V_6
    IL_11b4:  ldloc.s    V_23
    IL_11b6:  ldc.i4.1
    IL_11b7:  ldloc.0
    IL_11b8:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_11bd:  ldarg.0
    IL_11be:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_11c3:  ldloc.s    V_23
    IL_11c5:  ldelem.i4
    IL_11c6:  box        [mscorlib]System.Int32
    IL_11cb:  ldarg.0
    IL_11cc:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_11d1:  ldloc.1
    IL_11d2:  ldelem.i4
    IL_11d3:  box        [mscorlib]System.Int32
    IL_11d8:  ldarg.0
    IL_11d9:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_11de:  ldloc.1
    IL_11df:  ldelem.i4
    IL_11e0:  box        [mscorlib]System.Int32
    IL_11e5:  ldsfld     object [mscorlib]System.Type::Missing
    IL_11ea:  ldsfld     object [mscorlib]System.Type::Missing
    IL_11ef:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_11f4:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_11f9:  ldarg.0
    IL_11fa:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_11ff:  ldc.i4.m1
    IL_1200:  beq.s      IL_1252

    IL_1202:  ldarg.0
    IL_1203:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1208:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_120d:  ldloc.s    V_6
    IL_120f:  ldloc.s    V_23
    IL_1211:  ldc.i4.1
    IL_1212:  ldloc.0
    IL_1213:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1218:  ldarg.0
    IL_1219:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_121e:  ldloc.s    V_23
    IL_1220:  ldelem.i4
    IL_1221:  box        [mscorlib]System.Int32
    IL_1226:  ldarg.0
    IL_1227:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_122c:  box        [mscorlib]System.Int32
    IL_1231:  ldarg.0
    IL_1232:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_1237:  box        [mscorlib]System.Int32
    IL_123c:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1241:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1246:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_124b:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1250:  br.s       IL_126d

    IL_1252:  ldarg.0
    IL_1253:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1258:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_125d:  ldloc.s    V_6
    IL_125f:  ldloc.s    V_23
    IL_1261:  ldc.i4.0
    IL_1262:  ldarg.0
    IL_1263:  ldfld      string WpfPLData.Comp::PresAmt
    IL_1268:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_126d:  ldloc.s    V_22
    IL_126f:  ldc.i4.1
    IL_1270:  add
    IL_1271:  stloc.s    V_22
    IL_1273:  ldloc.s    V_22
    IL_1275:  ldarg.0
    IL_1276:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_127b:  ldlen
    IL_127c:  conv.i4
    IL_127d:  blt        IL_0f4d

    IL_1282:  ldloc.s    V_6
    IL_1284:  ldc.i4.1
    IL_1285:  add
    IL_1286:  stloc.s    V_6
    IL_1288:  br         IL_2c6c

    IL_128d:  ldarg.0
    IL_128e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1293:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1298:  ldarg.0
    IL_1299:  ldfld      string WpfPLData.Comp::MoleType
    IL_129e:  ldarg.0
    IL_129f:  ldfld      string WpfPLData.Comp::_componentId
    IL_12a4:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_12a9:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_12ae:  ldarg.0
    IL_12af:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_12b4:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_12b9:  ldsfld     object [mscorlib]System.Type::Missing
    IL_12be:  ldarg.0
    IL_12bf:  ldfld      string WpfPLData.Comp::MoleType
    IL_12c4:  ldarg.0
    IL_12c5:  ldfld      string WpfPLData.Comp::_componentId
    IL_12ca:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_12cf:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_12d4:  ldarg.0
    IL_12d5:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_12da:  ldloc.1
    IL_12db:  ldelem.i4
    IL_12dc:  ldc.i4.m1
    IL_12dd:  beq        IL_2c6c

    IL_12e2:  ldarg.0
    IL_12e3:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_12e8:  ldloc.1
    IL_12e9:  ldelem.i4
    IL_12ea:  ldc.i4.m1
    IL_12eb:  beq        IL_2c6c

    IL_12f0:  ldc.i4.0
    IL_12f1:  stloc.s    V_26
    IL_12f3:  br         IL_13de

    IL_12f8:  ldloc.s    V_26
    IL_12fa:  stloc.s    V_27
    IL_12fc:  ldloc.s    V_7
    IL_12fe:  ldloc.s    V_6
    IL_1300:  ldelem.u1
    IL_1301:  brtrue.s   IL_1334

    IL_1303:  ldarg.0
    IL_1304:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1309:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_130e:  ldloc.s    V_6
    IL_1310:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_ID()
    IL_1315:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_131a:  ldarg.0
    IL_131b:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1320:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1325:  ldloc.s    V_6
    IL_1327:  ldc.i4.s   15
    IL_1329:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_132e:  ldloc.s    V_7
    IL_1330:  ldloc.s    V_6
    IL_1332:  ldc.i4.1
    IL_1333:  stelem.i1
    IL_1334:  ldarg.0
    IL_1335:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_133a:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_133f:  ldloc.s    V_6
    IL_1341:  ldloc.s    V_27
    IL_1343:  ldc.i4.1
    IL_1344:  ldloc.0
    IL_1345:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_134a:  ldarg.0
    IL_134b:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1350:  ldloc.s    V_27
    IL_1352:  ldelem.i4
    IL_1353:  box        [mscorlib]System.Int32
    IL_1358:  ldarg.0
    IL_1359:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_135e:  ldloc.1
    IL_135f:  ldelem.i4
    IL_1360:  box        [mscorlib]System.Int32
    IL_1365:  ldarg.0
    IL_1366:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_136b:  ldloc.1
    IL_136c:  ldelem.i4
    IL_136d:  box        [mscorlib]System.Int32
    IL_1372:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1377:  ldsfld     object [mscorlib]System.Type::Missing
    IL_137c:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_1381:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1386:  ldarg.0
    IL_1387:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_138c:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1391:  ldloc.s    V_6
    IL_1393:  ldloc.s    V_27
    IL_1395:  ldc.i4.1
    IL_1396:  ldloc.0
    IL_1397:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_139c:  ldarg.0
    IL_139d:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_13a2:  ldloc.s    V_27
    IL_13a4:  ldelem.i4
    IL_13a5:  box        [mscorlib]System.Int32
    IL_13aa:  ldarg.0
    IL_13ab:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_13b0:  ldloc.1
    IL_13b1:  ldelem.i4
    IL_13b2:  box        [mscorlib]System.Int32
    IL_13b7:  ldarg.0
    IL_13b8:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_13bd:  ldloc.1
    IL_13be:  ldelem.i4
    IL_13bf:  box        [mscorlib]System.Int32
    IL_13c4:  ldsfld     object [mscorlib]System.Type::Missing
    IL_13c9:  ldsfld     object [mscorlib]System.Type::Missing
    IL_13ce:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_13d3:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_13d8:  ldloc.s    V_26
    IL_13da:  ldc.i4.1
    IL_13db:  add
    IL_13dc:  stloc.s    V_26
    IL_13de:  ldloc.s    V_26
    IL_13e0:  ldarg.0
    IL_13e1:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_13e6:  ldlen
    IL_13e7:  conv.i4
    IL_13e8:  blt        IL_12f8

    IL_13ed:  ldloc.s    V_6
    IL_13ef:  ldc.i4.1
    IL_13f0:  add
    IL_13f1:  stloc.s    V_6
    IL_13f3:  br         IL_2c6c

    IL_13f8:  ldarg.0
    IL_13f9:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_13fe:  ldc.i4.m1
    IL_13ff:  bne.un.s   IL_1416

    IL_1401:  ldarg.0
    IL_1402:  ldfld      string WpfPLData.Comp::TempAmt
    IL_1407:  ldstr      ""
    IL_140c:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_1411:  brfalse    IL_1549

    IL_1416:  ldarg.0
    IL_1417:  ldfld      int32[] WpfPLData.Comp::X2c
    IL_141c:  ldloc.1
    IL_141d:  ldelem.i4
    IL_141e:  ldc.i4.m1
    IL_141f:  beq        IL_1549

    IL_1424:  ldc.i4.0
    IL_1425:  stloc.s    V_28
    IL_1427:  br         IL_1534

    IL_142c:  ldloc.s    V_28
    IL_142e:  stloc.s    V_29
    IL_1430:  ldloc.s    V_7
    IL_1432:  ldloc.s    V_6
    IL_1434:  ldelem.u1
    IL_1435:  brtrue.s   IL_1468

    IL_1437:  ldarg.0
    IL_1438:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_143d:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1442:  ldloc.s    V_6
    IL_1444:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_X2_ID()
    IL_1449:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_144e:  ldarg.0
    IL_144f:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1454:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1459:  ldloc.s    V_6
    IL_145b:  ldc.i4.s   15
    IL_145d:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_1462:  ldloc.s    V_7
    IL_1464:  ldloc.s    V_6
    IL_1466:  ldc.i4.1
    IL_1467:  stelem.i1
    IL_1468:  ldarg.0
    IL_1469:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_146e:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1473:  ldloc.s    V_6
    IL_1475:  ldloc.s    V_29
    IL_1477:  ldc.i4.1
    IL_1478:  ldloc.0
    IL_1479:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_147e:  ldarg.0
    IL_147f:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1484:  ldloc.s    V_29
    IL_1486:  ldelem.i4
    IL_1487:  box        [mscorlib]System.Int32
    IL_148c:  ldarg.0
    IL_148d:  ldfld      int32[] WpfPLData.Comp::X2c
    IL_1492:  ldloc.1
    IL_1493:  ldelem.i4
    IL_1494:  box        [mscorlib]System.Int32
    IL_1499:  ldarg.0
    IL_149a:  ldfld      int32[] WpfPLData.Comp::X2c
    IL_149f:  ldloc.1
    IL_14a0:  ldelem.i4
    IL_14a1:  box        [mscorlib]System.Int32
    IL_14a6:  ldsfld     object [mscorlib]System.Type::Missing
    IL_14ab:  ldsfld     object [mscorlib]System.Type::Missing
    IL_14b0:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_14b5:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_14ba:  ldarg.0
    IL_14bb:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_14c0:  ldc.i4.m1
    IL_14c1:  beq.s      IL_1513

    IL_14c3:  ldarg.0
    IL_14c4:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_14c9:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_14ce:  ldloc.s    V_6
    IL_14d0:  ldloc.s    V_29
    IL_14d2:  ldc.i4.1
    IL_14d3:  ldloc.0
    IL_14d4:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_14d9:  ldarg.0
    IL_14da:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_14df:  ldloc.s    V_29
    IL_14e1:  ldelem.i4
    IL_14e2:  box        [mscorlib]System.Int32
    IL_14e7:  ldarg.0
    IL_14e8:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_14ed:  box        [mscorlib]System.Int32
    IL_14f2:  ldarg.0
    IL_14f3:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_14f8:  box        [mscorlib]System.Int32
    IL_14fd:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1502:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1507:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_150c:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1511:  br.s       IL_152e

    IL_1513:  ldarg.0
    IL_1514:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1519:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_151e:  ldloc.s    V_6
    IL_1520:  ldloc.s    V_29
    IL_1522:  ldc.i4.0
    IL_1523:  ldarg.0
    IL_1524:  ldfld      string WpfPLData.Comp::TempAmt
    IL_1529:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_152e:  ldloc.s    V_28
    IL_1530:  ldc.i4.1
    IL_1531:  add
    IL_1532:  stloc.s    V_28
    IL_1534:  ldloc.s    V_28
    IL_1536:  ldarg.0
    IL_1537:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_153c:  ldlen
    IL_153d:  conv.i4
    IL_153e:  blt        IL_142c

    IL_1543:  ldloc.s    V_6
    IL_1545:  ldc.i4.1
    IL_1546:  add
    IL_1547:  stloc.s    V_6
    IL_1549:  ldarg.0
    IL_154a:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_154f:  ldc.i4.m1
    IL_1550:  bne.un.s   IL_1567

    IL_1552:  ldarg.0
    IL_1553:  ldfld      string WpfPLData.Comp::TempAmt
    IL_1558:  ldstr      ""
    IL_155d:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_1562:  brfalse    IL_2c6c

    IL_1567:  ldarg.0
    IL_1568:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_156d:  ldloc.1
    IL_156e:  ldelem.i4
    IL_156f:  ldc.i4.m1
    IL_1570:  beq        IL_2c6c

    IL_1575:  ldc.i4.0
    IL_1576:  stloc.s    V_30
    IL_1578:  br         IL_1685

    IL_157d:  ldloc.s    V_30
    IL_157f:  stloc.s    V_31
    IL_1581:  ldloc.s    V_7
    IL_1583:  ldloc.s    V_6
    IL_1585:  ldelem.u1
    IL_1586:  brtrue.s   IL_15b9

    IL_1588:  ldarg.0
    IL_1589:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_158e:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1593:  ldloc.s    V_6
    IL_1595:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_X1_ID()
    IL_159a:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_159f:  ldarg.0
    IL_15a0:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_15a5:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_15aa:  ldloc.s    V_6
    IL_15ac:  ldc.i4.s   15
    IL_15ae:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_15b3:  ldloc.s    V_7
    IL_15b5:  ldloc.s    V_6
    IL_15b7:  ldc.i4.1
    IL_15b8:  stelem.i1
    IL_15b9:  ldarg.0
    IL_15ba:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_15bf:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_15c4:  ldloc.s    V_6
    IL_15c6:  ldloc.s    V_31
    IL_15c8:  ldc.i4.1
    IL_15c9:  ldloc.0
    IL_15ca:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_15cf:  ldarg.0
    IL_15d0:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_15d5:  ldloc.s    V_31
    IL_15d7:  ldelem.i4
    IL_15d8:  box        [mscorlib]System.Int32
    IL_15dd:  ldarg.0
    IL_15de:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_15e3:  ldloc.1
    IL_15e4:  ldelem.i4
    IL_15e5:  box        [mscorlib]System.Int32
    IL_15ea:  ldarg.0
    IL_15eb:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_15f0:  ldloc.1
    IL_15f1:  ldelem.i4
    IL_15f2:  box        [mscorlib]System.Int32
    IL_15f7:  ldsfld     object [mscorlib]System.Type::Missing
    IL_15fc:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1601:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_1606:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_160b:  ldarg.0
    IL_160c:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_1611:  ldc.i4.m1
    IL_1612:  beq.s      IL_1664

    IL_1614:  ldarg.0
    IL_1615:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_161a:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_161f:  ldloc.s    V_6
    IL_1621:  ldloc.s    V_31
    IL_1623:  ldc.i4.1
    IL_1624:  ldloc.0
    IL_1625:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_162a:  ldarg.0
    IL_162b:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1630:  ldloc.s    V_31
    IL_1632:  ldelem.i4
    IL_1633:  box        [mscorlib]System.Int32
    IL_1638:  ldarg.0
    IL_1639:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_163e:  box        [mscorlib]System.Int32
    IL_1643:  ldarg.0
    IL_1644:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_1649:  box        [mscorlib]System.Int32
    IL_164e:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1653:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1658:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_165d:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1662:  br.s       IL_167f

    IL_1664:  ldarg.0
    IL_1665:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_166a:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_166f:  ldloc.s    V_6
    IL_1671:  ldloc.s    V_31
    IL_1673:  ldc.i4.0
    IL_1674:  ldarg.0
    IL_1675:  ldfld      string WpfPLData.Comp::TempAmt
    IL_167a:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_167f:  ldloc.s    V_30
    IL_1681:  ldc.i4.1
    IL_1682:  add
    IL_1683:  stloc.s    V_30
    IL_1685:  ldloc.s    V_30
    IL_1687:  ldarg.0
    IL_1688:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_168d:  ldlen
    IL_168e:  conv.i4
    IL_168f:  blt        IL_157d

    IL_1694:  ldloc.s    V_6
    IL_1696:  ldc.i4.1
    IL_1697:  add
    IL_1698:  stloc.s    V_6
    IL_169a:  br         IL_2c6c

    IL_169f:  ldarg.0
    IL_16a0:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_16a5:  ldc.i4.m1
    IL_16a6:  bne.un.s   IL_16bd

    IL_16a8:  ldarg.0
    IL_16a9:  ldfld      string WpfPLData.Comp::PresAmt
    IL_16ae:  ldstr      ""
    IL_16b3:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_16b8:  brfalse    IL_17f0

    IL_16bd:  ldarg.0
    IL_16be:  ldfld      int32[] WpfPLData.Comp::X2c
    IL_16c3:  ldloc.1
    IL_16c4:  ldelem.i4
    IL_16c5:  ldc.i4.m1
    IL_16c6:  beq        IL_17f0

    IL_16cb:  ldc.i4.0
    IL_16cc:  stloc.s    V_32
    IL_16ce:  br         IL_17db

    IL_16d3:  ldloc.s    V_32
    IL_16d5:  stloc.s    V_33
    IL_16d7:  ldloc.s    V_7
    IL_16d9:  ldloc.s    V_6
    IL_16db:  ldelem.u1
    IL_16dc:  brtrue.s   IL_170f

    IL_16de:  ldarg.0
    IL_16df:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_16e4:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_16e9:  ldloc.s    V_6
    IL_16eb:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_X2_ID()
    IL_16f0:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_16f5:  ldarg.0
    IL_16f6:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_16fb:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1700:  ldloc.s    V_6
    IL_1702:  ldc.i4.s   15
    IL_1704:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_1709:  ldloc.s    V_7
    IL_170b:  ldloc.s    V_6
    IL_170d:  ldc.i4.1
    IL_170e:  stelem.i1
    IL_170f:  ldarg.0
    IL_1710:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1715:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_171a:  ldloc.s    V_6
    IL_171c:  ldloc.s    V_33
    IL_171e:  ldc.i4.1
    IL_171f:  ldloc.0
    IL_1720:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1725:  ldarg.0
    IL_1726:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_172b:  ldloc.s    V_33
    IL_172d:  ldelem.i4
    IL_172e:  box        [mscorlib]System.Int32
    IL_1733:  ldarg.0
    IL_1734:  ldfld      int32[] WpfPLData.Comp::X2c
    IL_1739:  ldloc.1
    IL_173a:  ldelem.i4
    IL_173b:  box        [mscorlib]System.Int32
    IL_1740:  ldarg.0
    IL_1741:  ldfld      int32[] WpfPLData.Comp::X2c
    IL_1746:  ldloc.1
    IL_1747:  ldelem.i4
    IL_1748:  box        [mscorlib]System.Int32
    IL_174d:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1752:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1757:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_175c:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1761:  ldarg.0
    IL_1762:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_1767:  ldc.i4.m1
    IL_1768:  beq.s      IL_17ba

    IL_176a:  ldarg.0
    IL_176b:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1770:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1775:  ldloc.s    V_6
    IL_1777:  ldloc.s    V_33
    IL_1779:  ldc.i4.1
    IL_177a:  ldloc.0
    IL_177b:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1780:  ldarg.0
    IL_1781:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1786:  ldloc.s    V_33
    IL_1788:  ldelem.i4
    IL_1789:  box        [mscorlib]System.Int32
    IL_178e:  ldarg.0
    IL_178f:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_1794:  box        [mscorlib]System.Int32
    IL_1799:  ldarg.0
    IL_179a:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_179f:  box        [mscorlib]System.Int32
    IL_17a4:  ldsfld     object [mscorlib]System.Type::Missing
    IL_17a9:  ldsfld     object [mscorlib]System.Type::Missing
    IL_17ae:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_17b3:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_17b8:  br.s       IL_17d5

    IL_17ba:  ldarg.0
    IL_17bb:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_17c0:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_17c5:  ldloc.s    V_6
    IL_17c7:  ldloc.s    V_33
    IL_17c9:  ldc.i4.0
    IL_17ca:  ldarg.0
    IL_17cb:  ldfld      string WpfPLData.Comp::PresAmt
    IL_17d0:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_17d5:  ldloc.s    V_32
    IL_17d7:  ldc.i4.1
    IL_17d8:  add
    IL_17d9:  stloc.s    V_32
    IL_17db:  ldloc.s    V_32
    IL_17dd:  ldarg.0
    IL_17de:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_17e3:  ldlen
    IL_17e4:  conv.i4
    IL_17e5:  blt        IL_16d3

    IL_17ea:  ldloc.s    V_6
    IL_17ec:  ldc.i4.1
    IL_17ed:  add
    IL_17ee:  stloc.s    V_6
    IL_17f0:  ldarg.0
    IL_17f1:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_17f6:  ldc.i4.m1
    IL_17f7:  bne.un.s   IL_180e

    IL_17f9:  ldarg.0
    IL_17fa:  ldfld      string WpfPLData.Comp::PresAmt
    IL_17ff:  ldstr      ""
    IL_1804:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_1809:  brfalse    IL_2c6c

    IL_180e:  ldarg.0
    IL_180f:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_1814:  ldloc.1
    IL_1815:  ldelem.i4
    IL_1816:  ldc.i4.m1
    IL_1817:  beq        IL_2c6c

    IL_181c:  ldc.i4.0
    IL_181d:  stloc.s    V_34
    IL_181f:  br         IL_192c

    IL_1824:  ldloc.s    V_34
    IL_1826:  stloc.s    V_35
    IL_1828:  ldloc.s    V_7
    IL_182a:  ldloc.s    V_6
    IL_182c:  ldelem.u1
    IL_182d:  brtrue.s   IL_1860

    IL_182f:  ldarg.0
    IL_1830:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1835:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_183a:  ldloc.s    V_6
    IL_183c:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_X1_ID()
    IL_1841:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_1846:  ldarg.0
    IL_1847:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_184c:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1851:  ldloc.s    V_6
    IL_1853:  ldc.i4.s   15
    IL_1855:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_185a:  ldloc.s    V_7
    IL_185c:  ldloc.s    V_6
    IL_185e:  ldc.i4.1
    IL_185f:  stelem.i1
    IL_1860:  ldarg.0
    IL_1861:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1866:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_186b:  ldloc.s    V_6
    IL_186d:  ldloc.s    V_35
    IL_186f:  ldc.i4.1
    IL_1870:  ldloc.0
    IL_1871:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1876:  ldarg.0
    IL_1877:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_187c:  ldloc.s    V_35
    IL_187e:  ldelem.i4
    IL_187f:  box        [mscorlib]System.Int32
    IL_1884:  ldarg.0
    IL_1885:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_188a:  ldloc.1
    IL_188b:  ldelem.i4
    IL_188c:  box        [mscorlib]System.Int32
    IL_1891:  ldarg.0
    IL_1892:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_1897:  ldloc.1
    IL_1898:  ldelem.i4
    IL_1899:  box        [mscorlib]System.Int32
    IL_189e:  ldsfld     object [mscorlib]System.Type::Missing
    IL_18a3:  ldsfld     object [mscorlib]System.Type::Missing
    IL_18a8:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_18ad:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_18b2:  ldarg.0
    IL_18b3:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_18b8:  ldc.i4.m1
    IL_18b9:  beq.s      IL_190b

    IL_18bb:  ldarg.0
    IL_18bc:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_18c1:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_18c6:  ldloc.s    V_6
    IL_18c8:  ldloc.s    V_35
    IL_18ca:  ldc.i4.1
    IL_18cb:  ldloc.0
    IL_18cc:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_18d1:  ldarg.0
    IL_18d2:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_18d7:  ldloc.s    V_35
    IL_18d9:  ldelem.i4
    IL_18da:  box        [mscorlib]System.Int32
    IL_18df:  ldarg.0
    IL_18e0:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_18e5:  box        [mscorlib]System.Int32
    IL_18ea:  ldarg.0
    IL_18eb:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_18f0:  box        [mscorlib]System.Int32
    IL_18f5:  ldsfld     object [mscorlib]System.Type::Missing
    IL_18fa:  ldsfld     object [mscorlib]System.Type::Missing
    IL_18ff:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_1904:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1909:  br.s       IL_1926

    IL_190b:  ldarg.0
    IL_190c:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1911:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1916:  ldloc.s    V_6
    IL_1918:  ldloc.s    V_35
    IL_191a:  ldc.i4.0
    IL_191b:  ldarg.0
    IL_191c:  ldfld      string WpfPLData.Comp::PresAmt
    IL_1921:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1926:  ldloc.s    V_34
    IL_1928:  ldc.i4.1
    IL_1929:  add
    IL_192a:  stloc.s    V_34
    IL_192c:  ldloc.s    V_34
    IL_192e:  ldarg.0
    IL_192f:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1934:  ldlen
    IL_1935:  conv.i4
    IL_1936:  blt        IL_1824

    IL_193b:  ldloc.s    V_6
    IL_193d:  ldc.i4.1
    IL_193e:  add
    IL_193f:  stloc.s    V_6
    IL_1941:  br         IL_2c6c

    IL_1946:  ldarg.0
    IL_1947:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_194c:  ldloc.1
    IL_194d:  ldelem.i4
    IL_194e:  ldc.i4.m1
    IL_194f:  beq        IL_2c6c

    IL_1954:  ldloc.2
    IL_1955:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Count()
    IL_195a:  ldc.i4.0
    IL_195b:  ble        IL_2c6c

    IL_1960:  ldarg.0
    IL_1961:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1966:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_196b:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1970:  ldarg.0
    IL_1971:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_1976:  ldloc.2
    IL_1977:  ldc.i4.0
    IL_1978:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_197d:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_1982:  ldstr      ", "
    IL_1987:  ldarg.0
    IL_1988:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_198d:  ldloc.2
    IL_198e:  ldc.i4.0
    IL_198f:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1994:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_1999:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_199e:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_19a3:  ldc.i4.0
    IL_19a4:  stloc.s    V_36
    IL_19a6:  br         IL_1ae2

    IL_19ab:  ldc.i4.0
    IL_19ac:  stloc.s    V_37
    IL_19ae:  br         IL_1ac7

    IL_19b3:  ldloc.s    V_37
    IL_19b5:  stloc.s    V_38
    IL_19b7:  ldloc.s    V_7
    IL_19b9:  ldloc.s    V_6
    IL_19bb:  ldelem.u1
    IL_19bc:  brtrue.s   IL_1a07

    IL_19be:  ldarg.0
    IL_19bf:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_19c4:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_19c9:  ldloc.s    V_6
    IL_19cb:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_Format_ID()
    IL_19d0:  ldarg.0
    IL_19d1:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_19d6:  ldloc.2
    IL_19d7:  ldloc.s    V_36
    IL_19d9:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_19de:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_19e3:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_19e8:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_19ed:  ldarg.0
    IL_19ee:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_19f3:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_19f8:  ldloc.s    V_6
    IL_19fa:  ldc.i4.s   15
    IL_19fc:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_1a01:  ldloc.s    V_7
    IL_1a03:  ldloc.s    V_6
    IL_1a05:  ldc.i4.1
    IL_1a06:  stelem.i1
    IL_1a07:  ldarg.0
    IL_1a08:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1a0d:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1a12:  ldloc.s    V_6
    IL_1a14:  ldloc.s    V_38
    IL_1a16:  ldc.i4.1
    IL_1a17:  ldloc.0
    IL_1a18:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1a1d:  ldarg.0
    IL_1a1e:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1a23:  ldloc.s    V_38
    IL_1a25:  ldelem.i4
    IL_1a26:  box        [mscorlib]System.Int32
    IL_1a2b:  ldarg.0
    IL_1a2c:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_1a31:  ldloc.1
    IL_1a32:  ldelem.i4
    IL_1a33:  box        [mscorlib]System.Int32
    IL_1a38:  ldarg.0
    IL_1a39:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_1a3e:  ldloc.1
    IL_1a3f:  ldelem.i4
    IL_1a40:  box        [mscorlib]System.Int32
    IL_1a45:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1a4a:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1a4f:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_1a54:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1a59:  ldarg.0
    IL_1a5a:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1a5f:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1a64:  ldloc.s    V_6
    IL_1a66:  ldloc.s    V_38
    IL_1a68:  ldc.i4.1
    IL_1a69:  ldloc.0
    IL_1a6a:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1a6f:  ldarg.0
    IL_1a70:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1a75:  ldloc.s    V_37
    IL_1a77:  ldelem.i4
    IL_1a78:  box        [mscorlib]System.Int32
    IL_1a7d:  ldarg.0
    IL_1a7e:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_1a83:  ldloc.2
    IL_1a84:  ldloc.s    V_36
    IL_1a86:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1a8b:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1a90:  box        [mscorlib]System.Int32
    IL_1a95:  ldarg.0
    IL_1a96:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_1a9b:  ldloc.2
    IL_1a9c:  ldloc.s    V_36
    IL_1a9e:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1aa3:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1aa8:  box        [mscorlib]System.Int32
    IL_1aad:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1ab2:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1ab7:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_1abc:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1ac1:  ldloc.s    V_37
    IL_1ac3:  ldc.i4.1
    IL_1ac4:  add
    IL_1ac5:  stloc.s    V_37
    IL_1ac7:  ldloc.s    V_37
    IL_1ac9:  ldarg.0
    IL_1aca:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1acf:  ldlen
    IL_1ad0:  conv.i4
    IL_1ad1:  blt        IL_19b3

    IL_1ad6:  ldloc.s    V_6
    IL_1ad8:  ldc.i4.1
    IL_1ad9:  add
    IL_1ada:  stloc.s    V_6
    IL_1adc:  ldloc.s    V_36
    IL_1ade:  ldc.i4.1
    IL_1adf:  add
    IL_1ae0:  stloc.s    V_36
    IL_1ae2:  ldloc.s    V_36
    IL_1ae4:  ldloc.2
    IL_1ae5:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Count()
    IL_1aea:  blt        IL_19ab

    IL_1aef:  br         IL_2c6c

    IL_1af4:  ldarg.0
    IL_1af5:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_1afa:  ldc.i4.m1
    IL_1afb:  bne.un.s   IL_1b1b

    IL_1afd:  ldarg.0
    IL_1afe:  ldfld      string WpfPLData.Comp::TempAmt
    IL_1b03:  ldstr      ""
    IL_1b08:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_1b0d:  brtrue.s   IL_1b1b

    IL_1b0f:  ldarg.0
    IL_1b10:  ldfld      int32 WpfPLData.Comp::Temp2Element
    IL_1b15:  ldc.i4.m1
    IL_1b16:  beq        IL_2c6c

    IL_1b1b:  ldloc.2
    IL_1b1c:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Count()
    IL_1b21:  ldc.i4.0
    IL_1b22:  ble        IL_2c6c

    IL_1b27:  ldarg.0
    IL_1b28:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_1b2d:  ldloc.2
    IL_1b2e:  ldc.i4.0
    IL_1b2f:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1b34:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_1b39:  ldstr      "GAMINF1"
    IL_1b3e:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_1b43:  brtrue.s   IL_1b66

    IL_1b45:  ldarg.0
    IL_1b46:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_1b4b:  ldloc.2
    IL_1b4c:  ldc.i4.0
    IL_1b4d:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1b52:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_1b57:  ldstr      "GAMINF2"
    IL_1b5c:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_1b61:  brfalse    IL_2067

    IL_1b66:  ldarg.0
    IL_1b67:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1b6c:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1b71:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1b76:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Infinite_DilutionActivityCoefficient()
    IL_1b7b:  ldarg.0
    IL_1b7c:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_1b81:  ldloc.2
    IL_1b82:  ldc.i4.0
    IL_1b83:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1b88:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_1b8d:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_1b92:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_1b97:  ldc.i4.0
    IL_1b98:  stloc.s    V_39
    IL_1b9a:  br         IL_2055

    IL_1b9f:  ldc.i4.0
    IL_1ba0:  stloc.s    V_40
    IL_1ba2:  br         IL_203a

    IL_1ba7:  ldloc.s    V_40
    IL_1ba9:  stloc.s    V_41
    IL_1bab:  ldloc.s    V_7
    IL_1bad:  ldloc.s    V_6
    IL_1baf:  ldelem.u1
    IL_1bb0:  brtrue     IL_1e11

    IL_1bb5:  ldstr      ""
    IL_1bba:  stloc.s    V_42
    IL_1bbc:  ldarg.0
    IL_1bbd:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_1bc2:  ldc.i4.m1
    IL_1bc3:  beq        IL_1da2

    IL_1bc8:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__24'
    IL_1bcd:  brtrue.s   IL_1bf3

    IL_1bcf:  ldc.i4.0
    IL_1bd0:  ldtoken    [mscorlib]System.String
    IL_1bd5:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_1bda:  ldtoken    WpfPLData.Comp
    IL_1bdf:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_1be4:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_1be9:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_1bee:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__24'
    IL_1bf3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__24'
    IL_1bf8:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_1bfd:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__24'
    IL_1c02:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__23'
    IL_1c07:  brtrue.s   IL_1c3e

    IL_1c09:  ldc.i4.0
    IL_1c0a:  ldc.i4.0
    IL_1c0b:  ldtoken    WpfPLData.Comp
    IL_1c10:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_1c15:  ldc.i4.2
    IL_1c16:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_1c1b:  dup
    IL_1c1c:  ldc.i4.0
    IL_1c1d:  ldc.i4.0
    IL_1c1e:  ldnull
    IL_1c1f:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_1c24:  stelem.ref
    IL_1c25:  dup
    IL_1c26:  ldc.i4.1
    IL_1c27:  ldc.i4.3
    IL_1c28:  ldnull
    IL_1c29:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_1c2e:  stelem.ref
    IL_1c2f:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_1c34:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_1c39:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__23'
    IL_1c3e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__23'
    IL_1c43:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_1c48:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__23'
    IL_1c4d:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__22'
    IL_1c52:  brtrue.s   IL_1c89

    IL_1c54:  ldc.i4.0
    IL_1c55:  ldc.i4.0
    IL_1c56:  ldtoken    WpfPLData.Comp
    IL_1c5b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_1c60:  ldc.i4.2
    IL_1c61:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_1c66:  dup
    IL_1c67:  ldc.i4.0
    IL_1c68:  ldc.i4.0
    IL_1c69:  ldnull
    IL_1c6a:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_1c6f:  stelem.ref
    IL_1c70:  dup
    IL_1c71:  ldc.i4.1
    IL_1c72:  ldc.i4.1
    IL_1c73:  ldnull
    IL_1c74:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_1c79:  stelem.ref
    IL_1c7a:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_1c7f:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_1c84:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__22'
    IL_1c89:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__22'
    IL_1c8e:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_1c93:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__22'
    IL_1c98:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__21'
    IL_1c9d:  brtrue.s   IL_1cd4

    IL_1c9f:  ldc.i4.0
    IL_1ca0:  ldc.i4.0
    IL_1ca1:  ldtoken    WpfPLData.Comp
    IL_1ca6:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_1cab:  ldc.i4.2
    IL_1cac:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_1cb1:  dup
    IL_1cb2:  ldc.i4.0
    IL_1cb3:  ldc.i4.0
    IL_1cb4:  ldnull
    IL_1cb5:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_1cba:  stelem.ref
    IL_1cbb:  dup
    IL_1cbc:  ldc.i4.1
    IL_1cbd:  ldc.i4.3
    IL_1cbe:  ldnull
    IL_1cbf:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_1cc4:  stelem.ref
    IL_1cc5:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_1cca:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_1ccf:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__21'
    IL_1cd4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__21'
    IL_1cd9:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_1cde:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__21'
    IL_1ce3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__20'
    IL_1ce8:  brtrue.s   IL_1d1f

    IL_1cea:  ldc.i4.0
    IL_1ceb:  ldc.i4.0
    IL_1cec:  ldtoken    WpfPLData.Comp
    IL_1cf1:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_1cf6:  ldc.i4.2
    IL_1cf7:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_1cfc:  dup
    IL_1cfd:  ldc.i4.0
    IL_1cfe:  ldc.i4.3
    IL_1cff:  ldnull
    IL_1d00:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_1d05:  stelem.ref
    IL_1d06:  dup
    IL_1d07:  ldc.i4.1
    IL_1d08:  ldc.i4.0
    IL_1d09:  ldnull
    IL_1d0a:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_1d0f:  stelem.ref
    IL_1d10:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_1d15:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_1d1a:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__20'
    IL_1d1f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__20'
    IL_1d24:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Target
    IL_1d29:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__20'
    IL_1d2e:  ldstr      " ("
    IL_1d33:  ldloc.0
    IL_1d34:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1d39:  ldarg.0
    IL_1d3a:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1d3f:  ldc.i4.0
    IL_1d40:  ldelem.i4
    IL_1d41:  box        [mscorlib]System.Int32
    IL_1d46:  ldarg.0
    IL_1d47:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_1d4c:  box        [mscorlib]System.Int32
    IL_1d51:  ldarg.0
    IL_1d52:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_1d57:  box        [mscorlib]System.Int32
    IL_1d5c:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1d61:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1d66:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_1d6b:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1d70:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_1d75:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_1d7a:  ldstr      " "
    IL_1d7f:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_1d84:  ldarg.0
    IL_1d85:  ldfld      string WpfPLData.Comp::PresUnit
    IL_1d8a:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_1d8f:  ldstr      ")"
    IL_1d94:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_1d99:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_1d9e:  stloc.s    V_42
    IL_1da0:  br.s       IL_1dc6

    IL_1da2:  ldarg.0
    IL_1da3:  call       instance string WpfPLData.Comp::PressureAmtUnits()
    IL_1da8:  stloc.s    V_42
    IL_1daa:  ldloc.s    V_42
    IL_1dac:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_1db1:  brtrue.s   IL_1dc6

    IL_1db3:  ldstr      " ("
    IL_1db8:  ldloc.s    V_42
    IL_1dba:  ldstr      ")"
    IL_1dbf:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_1dc4:  stloc.s    V_42
    IL_1dc6:  ldarg.0
    IL_1dc7:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1dcc:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1dd1:  ldloc.s    V_6
    IL_1dd3:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_Format_ID_Format()
    IL_1dd8:  ldarg.0
    IL_1dd9:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_1dde:  ldloc.2
    IL_1ddf:  ldloc.s    V_39
    IL_1de1:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1de6:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_1deb:  ldloc.s    V_42
    IL_1ded:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_1df2:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_1df7:  ldarg.0
    IL_1df8:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1dfd:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1e02:  ldloc.s    V_6
    IL_1e04:  ldc.i4.s   15
    IL_1e06:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_1e0b:  ldloc.s    V_7
    IL_1e0d:  ldloc.s    V_6
    IL_1e0f:  ldc.i4.1
    IL_1e10:  stelem.i1
    IL_1e11:  ldarg.0
    IL_1e12:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_1e17:  ldc.i4.m1
    IL_1e18:  bne.un.s   IL_1e2f

    IL_1e1a:  ldarg.0
    IL_1e1b:  ldfld      string WpfPLData.Comp::TempAmt
    IL_1e20:  ldstr      ""
    IL_1e25:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_1e2a:  brfalse    IL_1f2c

    IL_1e2f:  ldarg.0
    IL_1e30:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_1e35:  ldloc.2
    IL_1e36:  ldc.i4.0
    IL_1e37:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1e3c:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_1e41:  ldstr      "GAMINF1"
    IL_1e46:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_1e4b:  brfalse    IL_1f2c

    IL_1e50:  ldarg.0
    IL_1e51:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_1e56:  ldc.i4.m1
    IL_1e57:  beq.s      IL_1ea9

    IL_1e59:  ldarg.0
    IL_1e5a:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1e5f:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1e64:  ldloc.s    V_6
    IL_1e66:  ldloc.s    V_41
    IL_1e68:  ldc.i4.1
    IL_1e69:  ldloc.0
    IL_1e6a:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1e6f:  ldarg.0
    IL_1e70:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1e75:  ldloc.s    V_41
    IL_1e77:  ldelem.i4
    IL_1e78:  box        [mscorlib]System.Int32
    IL_1e7d:  ldarg.0
    IL_1e7e:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_1e83:  box        [mscorlib]System.Int32
    IL_1e88:  ldarg.0
    IL_1e89:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_1e8e:  box        [mscorlib]System.Int32
    IL_1e93:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1e98:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1e9d:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_1ea2:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1ea7:  br.s       IL_1ec4

    IL_1ea9:  ldarg.0
    IL_1eaa:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1eaf:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1eb4:  ldloc.s    V_6
    IL_1eb6:  ldloc.s    V_41
    IL_1eb8:  ldc.i4.0
    IL_1eb9:  ldarg.0
    IL_1eba:  ldfld      string WpfPLData.Comp::TempAmt
    IL_1ebf:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1ec4:  ldarg.0
    IL_1ec5:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1eca:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1ecf:  ldloc.s    V_6
    IL_1ed1:  ldloc.s    V_41
    IL_1ed3:  ldc.i4.1
    IL_1ed4:  ldloc.0
    IL_1ed5:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1eda:  ldarg.0
    IL_1edb:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1ee0:  ldloc.s    V_41
    IL_1ee2:  ldelem.i4
    IL_1ee3:  box        [mscorlib]System.Int32
    IL_1ee8:  ldarg.0
    IL_1ee9:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_1eee:  ldloc.2
    IL_1eef:  ldloc.s    V_39
    IL_1ef1:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1ef6:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1efb:  box        [mscorlib]System.Int32
    IL_1f00:  ldarg.0
    IL_1f01:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_1f06:  ldloc.2
    IL_1f07:  ldloc.s    V_39
    IL_1f09:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1f0e:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1f13:  box        [mscorlib]System.Int32
    IL_1f18:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1f1d:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1f22:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_1f27:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1f2c:  ldarg.0
    IL_1f2d:  ldfld      int32 WpfPLData.Comp::Temp2Element
    IL_1f32:  ldc.i4.m1
    IL_1f33:  beq        IL_2034

    IL_1f38:  ldarg.0
    IL_1f39:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_1f3e:  ldloc.2
    IL_1f3f:  ldc.i4.0
    IL_1f40:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1f45:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_1f4a:  ldstr      "GAMINF2"
    IL_1f4f:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_1f54:  brfalse    IL_2034

    IL_1f59:  ldarg.0
    IL_1f5a:  ldfld      int32 WpfPLData.Comp::Temp2Element
    IL_1f5f:  ldc.i4.m1
    IL_1f60:  beq.s      IL_1fb2

    IL_1f62:  ldarg.0
    IL_1f63:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1f68:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1f6d:  ldloc.s    V_6
    IL_1f6f:  ldloc.s    V_41
    IL_1f71:  ldc.i4.1
    IL_1f72:  ldloc.0
    IL_1f73:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1f78:  ldarg.0
    IL_1f79:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1f7e:  ldloc.s    V_41
    IL_1f80:  ldelem.i4
    IL_1f81:  box        [mscorlib]System.Int32
    IL_1f86:  ldarg.0
    IL_1f87:  ldfld      int32 WpfPLData.Comp::Temp2Element
    IL_1f8c:  box        [mscorlib]System.Int32
    IL_1f91:  ldarg.0
    IL_1f92:  ldfld      int32 WpfPLData.Comp::Temp2Element
    IL_1f97:  box        [mscorlib]System.Int32
    IL_1f9c:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1fa1:  ldsfld     object [mscorlib]System.Type::Missing
    IL_1fa6:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_1fab:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1fb0:  br.s       IL_1fcc

    IL_1fb2:  ldarg.0
    IL_1fb3:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1fb8:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1fbd:  ldloc.s    V_6
    IL_1fbf:  ldloc.s    V_41
    IL_1fc1:  ldc.i4.0
    IL_1fc2:  ldstr      ""
    IL_1fc7:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_1fcc:  ldarg.0
    IL_1fcd:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_1fd2:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1fd7:  ldloc.s    V_6
    IL_1fd9:  ldloc.s    V_41
    IL_1fdb:  ldc.i4.1
    IL_1fdc:  ldloc.0
    IL_1fdd:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_1fe2:  ldarg.0
    IL_1fe3:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_1fe8:  ldloc.s    V_41
    IL_1fea:  ldelem.i4
    IL_1feb:  box        [mscorlib]System.Int32
    IL_1ff0:  ldarg.0
    IL_1ff1:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_1ff6:  ldloc.2
    IL_1ff7:  ldloc.s    V_39
    IL_1ff9:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_1ffe:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_2003:  box        [mscorlib]System.Int32
    IL_2008:  ldarg.0
    IL_2009:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_200e:  ldloc.2
    IL_200f:  ldloc.s    V_39
    IL_2011:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_2016:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_201b:  box        [mscorlib]System.Int32
    IL_2020:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2025:  ldsfld     object [mscorlib]System.Type::Missing
    IL_202a:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_202f:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_2034:  ldloc.s    V_40
    IL_2036:  ldc.i4.1
    IL_2037:  add
    IL_2038:  stloc.s    V_40
    IL_203a:  ldloc.s    V_40
    IL_203c:  ldarg.0
    IL_203d:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_2042:  ldlen
    IL_2043:  conv.i4
    IL_2044:  blt        IL_1ba7

    IL_2049:  ldloc.s    V_6
    IL_204b:  ldc.i4.1
    IL_204c:  add
    IL_204d:  stloc.s    V_6
    IL_204f:  ldloc.s    V_39
    IL_2051:  ldc.i4.1
    IL_2052:  add
    IL_2053:  stloc.s    V_39
    IL_2055:  ldloc.s    V_39
    IL_2057:  ldloc.2
    IL_2058:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Count()
    IL_205d:  blt        IL_1b9f

    IL_2062:  br         IL_2c6c

    IL_2067:  ldarg.0
    IL_2068:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_206d:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2072:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2077:  ldarg.0
    IL_2078:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_207d:  ldloc.2
    IL_207e:  ldc.i4.0
    IL_207f:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_2084:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_2089:  ldstr      ", "
    IL_208e:  ldarg.0
    IL_208f:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_2094:  ldloc.2
    IL_2095:  ldc.i4.0
    IL_2096:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_209b:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_20a0:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_20a5:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_20aa:  ldc.i4.0
    IL_20ab:  stloc.s    V_43
    IL_20ad:  br         IL_2421

    IL_20b2:  ldc.i4.0
    IL_20b3:  stloc.s    V_44
    IL_20b5:  br         IL_2406

    IL_20ba:  ldloc.s    V_44
    IL_20bc:  stloc.s    V_45
    IL_20be:  ldloc.s    V_7
    IL_20c0:  ldloc.s    V_6
    IL_20c2:  ldelem.u1
    IL_20c3:  brtrue     IL_2324

    IL_20c8:  ldstr      ""
    IL_20cd:  stloc.s    V_46
    IL_20cf:  ldarg.0
    IL_20d0:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_20d5:  ldc.i4.m1
    IL_20d6:  beq        IL_22b5

    IL_20db:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__29'
    IL_20e0:  brtrue.s   IL_2106

    IL_20e2:  ldc.i4.0
    IL_20e3:  ldtoken    [mscorlib]System.String
    IL_20e8:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_20ed:  ldtoken    WpfPLData.Comp
    IL_20f2:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_20f7:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_20fc:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_2101:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__29'
    IL_2106:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__29'
    IL_210b:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_2110:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__29'
    IL_2115:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__28'
    IL_211a:  brtrue.s   IL_2151

    IL_211c:  ldc.i4.0
    IL_211d:  ldc.i4.0
    IL_211e:  ldtoken    WpfPLData.Comp
    IL_2123:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_2128:  ldc.i4.2
    IL_2129:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_212e:  dup
    IL_212f:  ldc.i4.0
    IL_2130:  ldc.i4.0
    IL_2131:  ldnull
    IL_2132:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2137:  stelem.ref
    IL_2138:  dup
    IL_2139:  ldc.i4.1
    IL_213a:  ldc.i4.3
    IL_213b:  ldnull
    IL_213c:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2141:  stelem.ref
    IL_2142:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_2147:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_214c:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__28'
    IL_2151:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__28'
    IL_2156:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_215b:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__28'
    IL_2160:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__27'
    IL_2165:  brtrue.s   IL_219c

    IL_2167:  ldc.i4.0
    IL_2168:  ldc.i4.0
    IL_2169:  ldtoken    WpfPLData.Comp
    IL_216e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_2173:  ldc.i4.2
    IL_2174:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_2179:  dup
    IL_217a:  ldc.i4.0
    IL_217b:  ldc.i4.0
    IL_217c:  ldnull
    IL_217d:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2182:  stelem.ref
    IL_2183:  dup
    IL_2184:  ldc.i4.1
    IL_2185:  ldc.i4.1
    IL_2186:  ldnull
    IL_2187:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_218c:  stelem.ref
    IL_218d:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_2192:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_2197:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__27'
    IL_219c:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__27'
    IL_21a1:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_21a6:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__27'
    IL_21ab:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__26'
    IL_21b0:  brtrue.s   IL_21e7

    IL_21b2:  ldc.i4.0
    IL_21b3:  ldc.i4.0
    IL_21b4:  ldtoken    WpfPLData.Comp
    IL_21b9:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_21be:  ldc.i4.2
    IL_21bf:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_21c4:  dup
    IL_21c5:  ldc.i4.0
    IL_21c6:  ldc.i4.0
    IL_21c7:  ldnull
    IL_21c8:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_21cd:  stelem.ref
    IL_21ce:  dup
    IL_21cf:  ldc.i4.1
    IL_21d0:  ldc.i4.3
    IL_21d1:  ldnull
    IL_21d2:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_21d7:  stelem.ref
    IL_21d8:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_21dd:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_21e2:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__26'
    IL_21e7:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__26'
    IL_21ec:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_21f1:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__26'
    IL_21f6:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__25'
    IL_21fb:  brtrue.s   IL_2232

    IL_21fd:  ldc.i4.0
    IL_21fe:  ldc.i4.0
    IL_21ff:  ldtoken    WpfPLData.Comp
    IL_2204:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_2209:  ldc.i4.2
    IL_220a:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_220f:  dup
    IL_2210:  ldc.i4.0
    IL_2211:  ldc.i4.3
    IL_2212:  ldnull
    IL_2213:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2218:  stelem.ref
    IL_2219:  dup
    IL_221a:  ldc.i4.1
    IL_221b:  ldc.i4.0
    IL_221c:  ldnull
    IL_221d:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2222:  stelem.ref
    IL_2223:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_2228:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_222d:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__25'
    IL_2232:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__25'
    IL_2237:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Target
    IL_223c:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__25'
    IL_2241:  ldstr      " ("
    IL_2246:  ldloc.0
    IL_2247:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_224c:  ldarg.0
    IL_224d:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_2252:  ldc.i4.0
    IL_2253:  ldelem.i4
    IL_2254:  box        [mscorlib]System.Int32
    IL_2259:  ldarg.0
    IL_225a:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_225f:  box        [mscorlib]System.Int32
    IL_2264:  ldarg.0
    IL_2265:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_226a:  box        [mscorlib]System.Int32
    IL_226f:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2274:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2279:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_227e:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2283:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_2288:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_228d:  ldstr      " "
    IL_2292:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_2297:  ldarg.0
    IL_2298:  ldfld      string WpfPLData.Comp::PresUnit
    IL_229d:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_22a2:  ldstr      ")"
    IL_22a7:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_22ac:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_22b1:  stloc.s    V_46
    IL_22b3:  br.s       IL_22d9

    IL_22b5:  ldarg.0
    IL_22b6:  call       instance string WpfPLData.Comp::PressureAmtUnits()
    IL_22bb:  stloc.s    V_46
    IL_22bd:  ldloc.s    V_46
    IL_22bf:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_22c4:  brtrue.s   IL_22d9

    IL_22c6:  ldstr      " ("
    IL_22cb:  ldloc.s    V_46
    IL_22cd:  ldstr      ")"
    IL_22d2:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_22d7:  stloc.s    V_46
    IL_22d9:  ldarg.0
    IL_22da:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_22df:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_22e4:  ldloc.s    V_6
    IL_22e6:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_Format_ID_Format()
    IL_22eb:  ldarg.0
    IL_22ec:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_22f1:  ldloc.2
    IL_22f2:  ldloc.s    V_43
    IL_22f4:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_22f9:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_22fe:  ldloc.s    V_46
    IL_2300:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_2305:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_230a:  ldarg.0
    IL_230b:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2310:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2315:  ldloc.s    V_6
    IL_2317:  ldc.i4.s   15
    IL_2319:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_231e:  ldloc.s    V_7
    IL_2320:  ldloc.s    V_6
    IL_2322:  ldc.i4.1
    IL_2323:  stelem.i1
    IL_2324:  ldarg.0
    IL_2325:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_232a:  ldc.i4.m1
    IL_232b:  beq.s      IL_237d

    IL_232d:  ldarg.0
    IL_232e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2333:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2338:  ldloc.s    V_6
    IL_233a:  ldloc.s    V_44
    IL_233c:  ldc.i4.1
    IL_233d:  ldloc.0
    IL_233e:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_2343:  ldarg.0
    IL_2344:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_2349:  ldloc.s    V_45
    IL_234b:  ldelem.i4
    IL_234c:  box        [mscorlib]System.Int32
    IL_2351:  ldarg.0
    IL_2352:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_2357:  box        [mscorlib]System.Int32
    IL_235c:  ldarg.0
    IL_235d:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_2362:  box        [mscorlib]System.Int32
    IL_2367:  ldsfld     object [mscorlib]System.Type::Missing
    IL_236c:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2371:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_2376:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_237b:  br.s       IL_2398

    IL_237d:  ldarg.0
    IL_237e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2383:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2388:  ldloc.s    V_6
    IL_238a:  ldloc.s    V_44
    IL_238c:  ldc.i4.0
    IL_238d:  ldarg.0
    IL_238e:  ldfld      string WpfPLData.Comp::TempAmt
    IL_2393:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_2398:  ldarg.0
    IL_2399:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_239e:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_23a3:  ldloc.s    V_6
    IL_23a5:  ldloc.s    V_44
    IL_23a7:  ldc.i4.1
    IL_23a8:  ldloc.0
    IL_23a9:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_23ae:  ldarg.0
    IL_23af:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_23b4:  ldloc.s    V_44
    IL_23b6:  ldelem.i4
    IL_23b7:  box        [mscorlib]System.Int32
    IL_23bc:  ldarg.0
    IL_23bd:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_23c2:  ldloc.2
    IL_23c3:  ldloc.s    V_43
    IL_23c5:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_23ca:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_23cf:  box        [mscorlib]System.Int32
    IL_23d4:  ldarg.0
    IL_23d5:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_23da:  ldloc.2
    IL_23db:  ldloc.s    V_43
    IL_23dd:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_23e2:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_23e7:  box        [mscorlib]System.Int32
    IL_23ec:  ldsfld     object [mscorlib]System.Type::Missing
    IL_23f1:  ldsfld     object [mscorlib]System.Type::Missing
    IL_23f6:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_23fb:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_2400:  ldloc.s    V_44
    IL_2402:  ldc.i4.1
    IL_2403:  add
    IL_2404:  stloc.s    V_44
    IL_2406:  ldloc.s    V_44
    IL_2408:  ldarg.0
    IL_2409:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_240e:  ldlen
    IL_240f:  conv.i4
    IL_2410:  blt        IL_20ba

    IL_2415:  ldloc.s    V_6
    IL_2417:  ldc.i4.1
    IL_2418:  add
    IL_2419:  stloc.s    V_6
    IL_241b:  ldloc.s    V_43
    IL_241d:  ldc.i4.1
    IL_241e:  add
    IL_241f:  stloc.s    V_43
    IL_2421:  ldloc.s    V_43
    IL_2423:  ldloc.2
    IL_2424:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Count()
    IL_2429:  blt        IL_20b2

    IL_242e:  br         IL_2c6c

    IL_2433:  ldarg.0
    IL_2434:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_2439:  ldc.i4.m1
    IL_243a:  bne.un.s   IL_2451

    IL_243c:  ldarg.0
    IL_243d:  ldfld      string WpfPLData.Comp::TempAmt
    IL_2442:  ldstr      ""
    IL_2447:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_244c:  brfalse    IL_2c6c

    IL_2451:  ldarg.0
    IL_2452:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_2457:  ldloc.3
    IL_2458:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_245d:  ldc.i4.m1
    IL_245e:  beq        IL_2c6c

    IL_2463:  ldarg.0
    IL_2464:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2469:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_246e:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2473:  ldarg.0
    IL_2474:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_2479:  ldloc.3
    IL_247a:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_247f:  ldstr      ", "
    IL_2484:  ldarg.0
    IL_2485:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_248a:  ldloc.3
    IL_248b:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_2490:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_2495:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_249a:  ldarg.0
    IL_249b:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_24a0:  ldloc.3
    IL_24a1:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_24a6:  ldstr      "PL"
    IL_24ab:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_24b0:  brtrue.s   IL_24e5

    IL_24b2:  ldarg.0
    IL_24b3:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_24b8:  ldloc.3
    IL_24b9:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_24be:  ldstr      "PS"
    IL_24c3:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_24c8:  brtrue.s   IL_24e5

    IL_24ca:  ldarg.0
    IL_24cb:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_24d0:  ldloc.3
    IL_24d1:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_24d6:  ldstr      "PRESSURE"
    IL_24db:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_24e0:  brfalse    IL_2570

    IL_24e5:  ldarg.0
    IL_24e6:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_24eb:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_24f0:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHPlotVal::get_NXVariables()
    IL_24f5:  ldc.i4.1
    IL_24f6:  bne.un.s   IL_254c

    IL_24f8:  ldarg.0
    IL_24f9:  ldfld      string WpfPLData.Comp::TempUnit
    IL_24fe:  callvirt   instance string [mscorlib]System.String::Trim()
    IL_2503:  ldstr      "K"
    IL_2508:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_250d:  brtrue.s   IL_2526

    IL_250f:  ldarg.0
    IL_2510:  ldfld      string WpfPLData.Comp::TempUnit
    IL_2515:  callvirt   instance string [mscorlib]System.String::Trim()
    IL_251a:  ldstr      "R"
    IL_251f:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_2524:  brfalse.s  IL_254c

    IL_2526:  ldarg.0
    IL_2527:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_252c:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2531:  ldc.i4.1
    IL_2532:  ldc.i4.1
    IL_2533:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_AxisScale(int32,
                                                                                         int32)
    IL_2538:  ldarg.0
    IL_2539:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_253e:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2543:  ldc.i4.0
    IL_2544:  ldc.i4.2
    IL_2545:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_AxisScale(int32,
                                                                                         int32)
    IL_254a:  br.s       IL_2570

    IL_254c:  ldarg.0
    IL_254d:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2552:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2557:  ldc.i4.1
    IL_2558:  ldc.i4.0
    IL_2559:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_AxisScale(int32,
                                                                                         int32)
    IL_255e:  ldarg.0
    IL_255f:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2564:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2569:  ldc.i4.0
    IL_256a:  ldc.i4.0
    IL_256b:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_AxisScale(int32,
                                                                                         int32)
    IL_2570:  ldc.i4.0
    IL_2571:  stloc.s    V_47
    IL_2573:  br         IL_28a3

    IL_2578:  ldloc.s    V_47
    IL_257a:  stloc.s    V_48
    IL_257c:  ldloc.s    V_7
    IL_257e:  ldloc.s    V_6
    IL_2580:  ldelem.u1
    IL_2581:  brtrue     IL_27cf

    IL_2586:  ldstr      ""
    IL_258b:  stloc.s    V_49
    IL_258d:  ldarg.0
    IL_258e:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_2593:  ldc.i4.m1
    IL_2594:  beq        IL_2773

    IL_2599:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__34'
    IL_259e:  brtrue.s   IL_25c4

    IL_25a0:  ldc.i4.0
    IL_25a1:  ldtoken    [mscorlib]System.String
    IL_25a6:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_25ab:  ldtoken    WpfPLData.Comp
    IL_25b0:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_25b5:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_25ba:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_25bf:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__34'
    IL_25c4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__34'
    IL_25c9:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_25ce:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__34'
    IL_25d3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__33'
    IL_25d8:  brtrue.s   IL_260f

    IL_25da:  ldc.i4.0
    IL_25db:  ldc.i4.0
    IL_25dc:  ldtoken    WpfPLData.Comp
    IL_25e1:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_25e6:  ldc.i4.2
    IL_25e7:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_25ec:  dup
    IL_25ed:  ldc.i4.0
    IL_25ee:  ldc.i4.0
    IL_25ef:  ldnull
    IL_25f0:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_25f5:  stelem.ref
    IL_25f6:  dup
    IL_25f7:  ldc.i4.1
    IL_25f8:  ldc.i4.3
    IL_25f9:  ldnull
    IL_25fa:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_25ff:  stelem.ref
    IL_2600:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_2605:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_260a:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__33'
    IL_260f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__33'
    IL_2614:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_2619:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__33'
    IL_261e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__32'
    IL_2623:  brtrue.s   IL_265a

    IL_2625:  ldc.i4.0
    IL_2626:  ldc.i4.0
    IL_2627:  ldtoken    WpfPLData.Comp
    IL_262c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_2631:  ldc.i4.2
    IL_2632:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_2637:  dup
    IL_2638:  ldc.i4.0
    IL_2639:  ldc.i4.0
    IL_263a:  ldnull
    IL_263b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2640:  stelem.ref
    IL_2641:  dup
    IL_2642:  ldc.i4.1
    IL_2643:  ldc.i4.1
    IL_2644:  ldnull
    IL_2645:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_264a:  stelem.ref
    IL_264b:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_2650:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_2655:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__32'
    IL_265a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__32'
    IL_265f:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_2664:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__32'
    IL_2669:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__31'
    IL_266e:  brtrue.s   IL_26a5

    IL_2670:  ldc.i4.0
    IL_2671:  ldc.i4.0
    IL_2672:  ldtoken    WpfPLData.Comp
    IL_2677:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_267c:  ldc.i4.2
    IL_267d:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_2682:  dup
    IL_2683:  ldc.i4.0
    IL_2684:  ldc.i4.0
    IL_2685:  ldnull
    IL_2686:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_268b:  stelem.ref
    IL_268c:  dup
    IL_268d:  ldc.i4.1
    IL_268e:  ldc.i4.3
    IL_268f:  ldnull
    IL_2690:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2695:  stelem.ref
    IL_2696:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_269b:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_26a0:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__31'
    IL_26a5:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__31'
    IL_26aa:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_26af:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__31'
    IL_26b4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__30'
    IL_26b9:  brtrue.s   IL_26f0

    IL_26bb:  ldc.i4.0
    IL_26bc:  ldc.i4.0
    IL_26bd:  ldtoken    WpfPLData.Comp
    IL_26c2:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_26c7:  ldc.i4.2
    IL_26c8:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_26cd:  dup
    IL_26ce:  ldc.i4.0
    IL_26cf:  ldc.i4.3
    IL_26d0:  ldnull
    IL_26d1:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_26d6:  stelem.ref
    IL_26d7:  dup
    IL_26d8:  ldc.i4.1
    IL_26d9:  ldc.i4.0
    IL_26da:  ldnull
    IL_26db:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_26e0:  stelem.ref
    IL_26e1:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_26e6:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_26eb:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__30'
    IL_26f0:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__30'
    IL_26f5:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Target
    IL_26fa:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__30'
    IL_26ff:  ldstr      " ("
    IL_2704:  ldloc.0
    IL_2705:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_270a:  ldarg.0
    IL_270b:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_2710:  ldc.i4.0
    IL_2711:  ldelem.i4
    IL_2712:  box        [mscorlib]System.Int32
    IL_2717:  ldarg.0
    IL_2718:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_271d:  box        [mscorlib]System.Int32
    IL_2722:  ldarg.0
    IL_2723:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_2728:  box        [mscorlib]System.Int32
    IL_272d:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2732:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2737:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_273c:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2741:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_2746:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_274b:  ldstr      " "
    IL_2750:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_2755:  ldarg.0
    IL_2756:  ldfld      string WpfPLData.Comp::PresUnit
    IL_275b:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_2760:  ldstr      ")"
    IL_2765:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_276a:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_276f:  stloc.s    V_49
    IL_2771:  br.s       IL_2797

    IL_2773:  ldarg.0
    IL_2774:  call       instance string WpfPLData.Comp::PressureAmtUnits()
    IL_2779:  stloc.s    V_49
    IL_277b:  ldloc.s    V_49
    IL_277d:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_2782:  brtrue.s   IL_2797

    IL_2784:  ldstr      " ("
    IL_2789:  ldloc.s    V_49
    IL_278b:  ldstr      ")"
    IL_2790:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_2795:  stloc.s    V_49
    IL_2797:  ldarg.0
    IL_2798:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_279d:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_27a2:  ldloc.s    V_6
    IL_27a4:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_ID()
    IL_27a9:  ldloc.s    V_49
    IL_27ab:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_27b0:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_27b5:  ldarg.0
    IL_27b6:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_27bb:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_27c0:  ldloc.s    V_6
    IL_27c2:  ldc.i4.s   15
    IL_27c4:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_27c9:  ldloc.s    V_7
    IL_27cb:  ldloc.s    V_6
    IL_27cd:  ldc.i4.1
    IL_27ce:  stelem.i1
    IL_27cf:  ldarg.0
    IL_27d0:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_27d5:  ldc.i4.m1
    IL_27d6:  beq.s      IL_2828

    IL_27d8:  ldarg.0
    IL_27d9:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_27de:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_27e3:  ldloc.s    V_6
    IL_27e5:  ldloc.s    V_48
    IL_27e7:  ldc.i4.1
    IL_27e8:  ldloc.0
    IL_27e9:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_27ee:  ldarg.0
    IL_27ef:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_27f4:  ldloc.s    V_48
    IL_27f6:  ldelem.i4
    IL_27f7:  box        [mscorlib]System.Int32
    IL_27fc:  ldarg.0
    IL_27fd:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_2802:  box        [mscorlib]System.Int32
    IL_2807:  ldarg.0
    IL_2808:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_280d:  box        [mscorlib]System.Int32
    IL_2812:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2817:  ldsfld     object [mscorlib]System.Type::Missing
    IL_281c:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_2821:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_2826:  br.s       IL_2843

    IL_2828:  ldarg.0
    IL_2829:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_282e:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2833:  ldloc.s    V_6
    IL_2835:  ldloc.s    V_48
    IL_2837:  ldc.i4.0
    IL_2838:  ldarg.0
    IL_2839:  ldfld      string WpfPLData.Comp::TempAmt
    IL_283e:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_2843:  ldarg.0
    IL_2844:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2849:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_284e:  ldloc.s    V_6
    IL_2850:  ldloc.s    V_48
    IL_2852:  ldc.i4.1
    IL_2853:  ldloc.0
    IL_2854:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_2859:  ldarg.0
    IL_285a:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_285f:  ldloc.s    V_48
    IL_2861:  ldelem.i4
    IL_2862:  box        [mscorlib]System.Int32
    IL_2867:  ldarg.0
    IL_2868:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_286d:  ldloc.3
    IL_286e:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_2873:  box        [mscorlib]System.Int32
    IL_2878:  ldarg.0
    IL_2879:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_287e:  ldloc.3
    IL_287f:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_2884:  box        [mscorlib]System.Int32
    IL_2889:  ldsfld     object [mscorlib]System.Type::Missing
    IL_288e:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2893:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_2898:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_289d:  ldloc.s    V_47
    IL_289f:  ldc.i4.1
    IL_28a0:  add
    IL_28a1:  stloc.s    V_47
    IL_28a3:  ldloc.s    V_47
    IL_28a5:  ldarg.0
    IL_28a6:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_28ab:  ldlen
    IL_28ac:  conv.i4
    IL_28ad:  blt        IL_2578

    IL_28b2:  ldloc.s    V_6
    IL_28b4:  ldc.i4.1
    IL_28b5:  add
    IL_28b6:  stloc.s    V_6
    IL_28b8:  br         IL_2c6c

    IL_28bd:  ldarg.0
    IL_28be:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_28c3:  ldc.i4.m1
    IL_28c4:  bne.un.s   IL_28db

    IL_28c6:  ldarg.0
    IL_28c7:  ldfld      string WpfPLData.Comp::PresAmt
    IL_28cc:  ldstr      ""
    IL_28d1:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_28d6:  brfalse    IL_2c6c

    IL_28db:  ldarg.0
    IL_28dc:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_28e1:  ldloc.3
    IL_28e2:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_28e7:  ldc.i4.m1
    IL_28e8:  beq        IL_2c6c

    IL_28ed:  ldarg.0
    IL_28ee:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_28f3:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_28f8:  ldsfld     object [mscorlib]System.Type::Missing
    IL_28fd:  ldarg.0
    IL_28fe:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_2903:  ldloc.3
    IL_2904:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_2909:  ldstr      ", "
    IL_290e:  ldarg.0
    IL_290f:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_2914:  ldloc.3
    IL_2915:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_291a:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_291f:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_2924:  ldc.i4.0
    IL_2925:  stloc.s    V_50
    IL_2927:  br         IL_2c57

    IL_292c:  ldloc.s    V_50
    IL_292e:  stloc.s    V_51
    IL_2930:  ldloc.s    V_7
    IL_2932:  ldloc.s    V_6
    IL_2934:  ldelem.u1
    IL_2935:  brtrue     IL_2b83

    IL_293a:  ldstr      ""
    IL_293f:  stloc.s    V_52
    IL_2941:  ldarg.0
    IL_2942:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_2947:  ldc.i4.m1
    IL_2948:  beq        IL_2b27

    IL_294d:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__39'
    IL_2952:  brtrue.s   IL_2978

    IL_2954:  ldc.i4.0
    IL_2955:  ldtoken    [mscorlib]System.String
    IL_295a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_295f:  ldtoken    WpfPLData.Comp
    IL_2964:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_2969:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_296e:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_2973:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__39'
    IL_2978:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__39'
    IL_297d:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_2982:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__75'::'<>p__39'
    IL_2987:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__38'
    IL_298c:  brtrue.s   IL_29c3

    IL_298e:  ldc.i4.0
    IL_298f:  ldc.i4.0
    IL_2990:  ldtoken    WpfPLData.Comp
    IL_2995:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_299a:  ldc.i4.2
    IL_299b:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_29a0:  dup
    IL_29a1:  ldc.i4.0
    IL_29a2:  ldc.i4.0
    IL_29a3:  ldnull
    IL_29a4:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_29a9:  stelem.ref
    IL_29aa:  dup
    IL_29ab:  ldc.i4.1
    IL_29ac:  ldc.i4.3
    IL_29ad:  ldnull
    IL_29ae:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_29b3:  stelem.ref
    IL_29b4:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_29b9:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_29be:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__38'
    IL_29c3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__38'
    IL_29c8:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_29cd:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__38'
    IL_29d2:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__37'
    IL_29d7:  brtrue.s   IL_2a0e

    IL_29d9:  ldc.i4.0
    IL_29da:  ldc.i4.0
    IL_29db:  ldtoken    WpfPLData.Comp
    IL_29e0:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_29e5:  ldc.i4.2
    IL_29e6:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_29eb:  dup
    IL_29ec:  ldc.i4.0
    IL_29ed:  ldc.i4.0
    IL_29ee:  ldnull
    IL_29ef:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_29f4:  stelem.ref
    IL_29f5:  dup
    IL_29f6:  ldc.i4.1
    IL_29f7:  ldc.i4.1
    IL_29f8:  ldnull
    IL_29f9:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_29fe:  stelem.ref
    IL_29ff:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_2a04:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_2a09:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__37'
    IL_2a0e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__37'
    IL_2a13:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_2a18:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__37'
    IL_2a1d:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__36'
    IL_2a22:  brtrue.s   IL_2a59

    IL_2a24:  ldc.i4.0
    IL_2a25:  ldc.i4.0
    IL_2a26:  ldtoken    WpfPLData.Comp
    IL_2a2b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_2a30:  ldc.i4.2
    IL_2a31:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_2a36:  dup
    IL_2a37:  ldc.i4.0
    IL_2a38:  ldc.i4.0
    IL_2a39:  ldnull
    IL_2a3a:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2a3f:  stelem.ref
    IL_2a40:  dup
    IL_2a41:  ldc.i4.1
    IL_2a42:  ldc.i4.3
    IL_2a43:  ldnull
    IL_2a44:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2a49:  stelem.ref
    IL_2a4a:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_2a4f:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_2a54:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__36'
    IL_2a59:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__36'
    IL_2a5e:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>>::Target
    IL_2a63:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>> WpfPLData.Comp/'<>o__75'::'<>p__36'
    IL_2a68:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__35'
    IL_2a6d:  brtrue.s   IL_2aa4

    IL_2a6f:  ldc.i4.0
    IL_2a70:  ldc.i4.0
    IL_2a71:  ldtoken    WpfPLData.Comp
    IL_2a76:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_2a7b:  ldc.i4.2
    IL_2a7c:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_2a81:  dup
    IL_2a82:  ldc.i4.0
    IL_2a83:  ldc.i4.3
    IL_2a84:  ldnull
    IL_2a85:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2a8a:  stelem.ref
    IL_2a8b:  dup
    IL_2a8c:  ldc.i4.1
    IL_2a8d:  ldc.i4.0
    IL_2a8e:  ldnull
    IL_2a8f:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_2a94:  stelem.ref
    IL_2a95:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_2a9a:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_2a9f:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__35'
    IL_2aa4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__35'
    IL_2aa9:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>>::Target
    IL_2aae:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>> WpfPLData.Comp/'<>o__75'::'<>p__35'
    IL_2ab3:  ldstr      " ("
    IL_2ab8:  ldloc.0
    IL_2ab9:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_2abe:  ldarg.0
    IL_2abf:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_2ac4:  ldc.i4.0
    IL_2ac5:  ldelem.i4
    IL_2ac6:  box        [mscorlib]System.Int32
    IL_2acb:  ldarg.0
    IL_2acc:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_2ad1:  box        [mscorlib]System.Int32
    IL_2ad6:  ldarg.0
    IL_2ad7:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_2adc:  box        [mscorlib]System.Int32
    IL_2ae1:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2ae6:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2aeb:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_2af0:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2af5:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_2afa:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,string,object,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_2aff:  ldstr      " "
    IL_2b04:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_2b09:  ldarg.0
    IL_2b0a:  ldfld      string WpfPLData.Comp::PresUnit
    IL_2b0f:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_2b14:  ldstr      ")"
    IL_2b19:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_2b1e:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_2b23:  stloc.s    V_52
    IL_2b25:  br.s       IL_2b4b

    IL_2b27:  ldarg.0
    IL_2b28:  call       instance string WpfPLData.Comp::PressureAmtUnits()
    IL_2b2d:  stloc.s    V_52
    IL_2b2f:  ldloc.s    V_52
    IL_2b31:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_2b36:  brtrue.s   IL_2b4b

    IL_2b38:  ldstr      " ("
    IL_2b3d:  ldloc.s    V_52
    IL_2b3f:  ldstr      ")"
    IL_2b44:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_2b49:  stloc.s    V_52
    IL_2b4b:  ldarg.0
    IL_2b4c:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2b51:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2b56:  ldloc.s    V_6
    IL_2b58:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_ID()
    IL_2b5d:  ldloc.s    V_52
    IL_2b5f:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_2b64:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_2b69:  ldarg.0
    IL_2b6a:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2b6f:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2b74:  ldloc.s    V_6
    IL_2b76:  ldc.i4.s   15
    IL_2b78:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_2b7d:  ldloc.s    V_7
    IL_2b7f:  ldloc.s    V_6
    IL_2b81:  ldc.i4.1
    IL_2b82:  stelem.i1
    IL_2b83:  ldarg.0
    IL_2b84:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_2b89:  ldc.i4.m1
    IL_2b8a:  beq.s      IL_2bdc

    IL_2b8c:  ldarg.0
    IL_2b8d:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2b92:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2b97:  ldloc.s    V_6
    IL_2b99:  ldloc.s    V_51
    IL_2b9b:  ldc.i4.1
    IL_2b9c:  ldloc.0
    IL_2b9d:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_2ba2:  ldarg.0
    IL_2ba3:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_2ba8:  ldloc.s    V_51
    IL_2baa:  ldelem.i4
    IL_2bab:  box        [mscorlib]System.Int32
    IL_2bb0:  ldarg.0
    IL_2bb1:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_2bb6:  box        [mscorlib]System.Int32
    IL_2bbb:  ldarg.0
    IL_2bbc:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_2bc1:  box        [mscorlib]System.Int32
    IL_2bc6:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2bcb:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2bd0:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_2bd5:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_2bda:  br.s       IL_2bf7

    IL_2bdc:  ldarg.0
    IL_2bdd:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2be2:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2be7:  ldloc.s    V_6
    IL_2be9:  ldloc.s    V_51
    IL_2beb:  ldc.i4.0
    IL_2bec:  ldarg.0
    IL_2bed:  ldfld      string WpfPLData.Comp::PresAmt
    IL_2bf2:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_2bf7:  ldarg.0
    IL_2bf8:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2bfd:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2c02:  ldloc.s    V_6
    IL_2c04:  ldloc.s    V_51
    IL_2c06:  ldc.i4.1
    IL_2c07:  ldloc.0
    IL_2c08:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_2c0d:  ldarg.0
    IL_2c0e:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_2c13:  ldloc.s    V_51
    IL_2c15:  ldelem.i4
    IL_2c16:  box        [mscorlib]System.Int32
    IL_2c1b:  ldarg.0
    IL_2c1c:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_2c21:  ldloc.3
    IL_2c22:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_2c27:  box        [mscorlib]System.Int32
    IL_2c2c:  ldarg.0
    IL_2c2d:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_2c32:  ldloc.3
    IL_2c33:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<int32>::get_Item(int32)
    IL_2c38:  box        [mscorlib]System.Int32
    IL_2c3d:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2c42:  ldsfld     object [mscorlib]System.Type::Missing
    IL_2c47:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_2c4c:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                     int32,
                                                                                     int16,
                                                                                     object)
    IL_2c51:  ldloc.s    V_50
    IL_2c53:  ldc.i4.1
    IL_2c54:  add
    IL_2c55:  stloc.s    V_50
    IL_2c57:  ldloc.s    V_50
    IL_2c59:  ldarg.0
    IL_2c5a:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_2c5f:  ldlen
    IL_2c60:  conv.i4
    IL_2c61:  blt        IL_292c

    IL_2c66:  ldloc.s    V_6
    IL_2c68:  ldc.i4.1
    IL_2c69:  add
    IL_2c6a:  stloc.s    V_6
    IL_2c6c:  ldarg.0
    IL_2c6d:  call       instance void WpfPLData.Comp::SetWindowTitle()
    IL_2c72:  ldarg.0
    IL_2c73:  call       instance void WpfPLData.Comp::SetAxisTitles()
    IL_2c78:  ldarg.0
    IL_2c79:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2c7e:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_2c83:  ldc.i4.5
    IL_2c84:  bne.un.s   IL_2ca8

    IL_2c86:  ldarg.0
    IL_2c87:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2c8c:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2c91:  ldc.i4.1
    IL_2c92:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_SquarePlot(bool)
    IL_2c97:  ldarg.0
    IL_2c98:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_2c9d:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_2ca2:  ldc.i4.1
    IL_2ca3:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_ShowDiagonalLine(bool)
    IL_2ca8:  ret
  } // end of method Comp::UpdateWizardData

  .method private hidebysig instance int32 
          CountFor(string sName) cil managed
  {
    // Code size       247 (0xf7)
    .maxstack  6
    .locals init (int32 V_0,
             string V_1)
    IL_0000:  ldc.i4.0
    IL_0001:  stloc.0
    IL_0002:  ldsfld     string [mscorlib]System.String::Empty
    IL_0007:  stloc.1
    IL_0008:  ldarg.1
    IL_0009:  ldstr      "TEMPERATURE"
    IL_000e:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0013:  brfalse.s  IL_003c

    IL_0015:  ldarg.0
    IL_0016:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_001b:  ldarg.0
    IL_001c:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_0021:  ldarg.0
    IL_0022:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_0027:  ldc.i4.2
    IL_0028:  ldelem.ref
    IL_0029:  ldarg.1
    IL_002a:  ldarg.0
    IL_002b:  ldflda     int32 WpfPLData.Comp::TempElement
    IL_0030:  ldarg.0
    IL_0031:  ldflda     string WpfPLData.Comp::TempUnit
    IL_0036:  callvirt   instance int32 WpfPLData.PLDataHelper::GetElementCount(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                string,
                                                                                string,
                                                                                int32&,
                                                                                string&)
    IL_003b:  ret

    IL_003c:  ldarg.1
    IL_003d:  ldstr      "TEMP1"
    IL_0042:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0047:  brfalse.s  IL_0070

    IL_0049:  ldarg.0
    IL_004a:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_004f:  ldarg.0
    IL_0050:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_0055:  ldarg.0
    IL_0056:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_005b:  ldc.i4.2
    IL_005c:  ldelem.ref
    IL_005d:  ldarg.1
    IL_005e:  ldarg.0
    IL_005f:  ldflda     int32 WpfPLData.Comp::TempElement
    IL_0064:  ldarg.0
    IL_0065:  ldflda     string WpfPLData.Comp::TempUnit
    IL_006a:  callvirt   instance int32 WpfPLData.PLDataHelper::GetElementCount(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                string,
                                                                                string,
                                                                                int32&,
                                                                                string&)
    IL_006f:  ret

    IL_0070:  ldarg.1
    IL_0071:  ldstr      "TEMP2"
    IL_0076:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_007b:  brfalse.s  IL_00a4

    IL_007d:  ldarg.0
    IL_007e:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_0083:  ldarg.0
    IL_0084:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_0089:  ldarg.0
    IL_008a:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_008f:  ldc.i4.2
    IL_0090:  ldelem.ref
    IL_0091:  ldarg.1
    IL_0092:  ldarg.0
    IL_0093:  ldflda     int32 WpfPLData.Comp::Temp2Element
    IL_0098:  ldarg.0
    IL_0099:  ldflda     string WpfPLData.Comp::Temp2Unit
    IL_009e:  callvirt   instance int32 WpfPLData.PLDataHelper::GetElementCount(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                string,
                                                                                string,
                                                                                int32&,
                                                                                string&)
    IL_00a3:  ret

    IL_00a4:  ldarg.1
    IL_00a5:  ldstr      "PRESSURE"
    IL_00aa:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00af:  brfalse.s  IL_00d8

    IL_00b1:  ldarg.0
    IL_00b2:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_00b7:  ldarg.0
    IL_00b8:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_00bd:  ldarg.0
    IL_00be:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_00c3:  ldc.i4.2
    IL_00c4:  ldelem.ref
    IL_00c5:  ldarg.1
    IL_00c6:  ldarg.0
    IL_00c7:  ldflda     int32 WpfPLData.Comp::PresElement
    IL_00cc:  ldarg.0
    IL_00cd:  ldflda     string WpfPLData.Comp::PresUnit
    IL_00d2:  callvirt   instance int32 WpfPLData.PLDataHelper::GetElementCount(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                string,
                                                                                string,
                                                                                int32&,
                                                                                string&)
    IL_00d7:  ret

    IL_00d8:  ldarg.0
    IL_00d9:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_00de:  ldarg.0
    IL_00df:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_00e4:  ldarg.0
    IL_00e5:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_00ea:  ldc.i4.2
    IL_00eb:  ldelem.ref
    IL_00ec:  ldarg.1
    IL_00ed:  ldloca.s   V_0
    IL_00ef:  ldloca.s   V_1
    IL_00f1:  callvirt   instance int32 WpfPLData.PLDataHelper::GetElementCount(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                string,
                                                                                string,
                                                                                int32&,
                                                                                string&)
    IL_00f6:  ret
  } // end of method Comp::CountFor

  .method private hidebysig instance bool 
          IsMixture() cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_000c:  ldarg.0
    IL_000d:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_0012:  ldc.i4.0
    IL_0013:  ldelem.ref
    IL_0014:  callvirt   instance bool WpfPLData.PLDataHelper::IsMixture(class AspenTech.AspenPlus.Happ.IHNode,
                                                                         string)
    IL_0019:  ret
  } // end of method Comp::IsMixture

  .method private hidebysig instance bool 
          Build_CandidateList() cil managed
  {
    // Code size       687 (0x2af)
    .maxstack  5
    .locals init (bool V_0,
             int32 V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldstr      ""
    IL_0006:  stfld      string WpfPLData.Comp::TempUnit
    IL_000b:  ldarg.0
    IL_000c:  ldc.i4.m1
    IL_000d:  stfld      int32 WpfPLData.Comp::TempElement
    IL_0012:  ldarg.0
    IL_0013:  ldstr      ""
    IL_0018:  stfld      string WpfPLData.Comp::Temp2Unit
    IL_001d:  ldarg.0
    IL_001e:  ldc.i4.m1
    IL_001f:  stfld      int32 WpfPLData.Comp::Temp2Element
    IL_0024:  ldarg.0
    IL_0025:  ldstr      ""
    IL_002a:  stfld      string WpfPLData.Comp::PresUnit
    IL_002f:  ldarg.0
    IL_0030:  ldc.i4.m1
    IL_0031:  stfld      int32 WpfPLData.Comp::PresElement
    IL_0036:  ldarg.0
    IL_0037:  ldarg.0
    IL_0038:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_003d:  ldarg.0
    IL_003e:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_0043:  ldarg.0
    IL_0044:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_0049:  ldc.i4.1
    IL_004a:  ldelem.ref
    IL_004b:  callvirt   instance int32[] WpfPLData.PLDataHelper::GetDataElementsArray(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                       string)
    IL_0050:  stfld      int32[] WpfPLData.Comp::DataElement
    IL_0055:  ldarg.0
    IL_0056:  ldfld      int32[] WpfPLData.Comp::DataElement
    IL_005b:  ldlen
    IL_005c:  brtrue.s   IL_0060

    IL_005e:  ldc.i4.0
    IL_005f:  ret

    IL_0060:  ldarg.0
    IL_0061:  ldarg.0
    IL_0062:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0067:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_006c:  stfld      int32 WpfPLData.Comp::PlotType
    IL_0071:  ldarg.0
    IL_0072:  ldfld      int32 WpfPLData.Comp::PlotType
    IL_0077:  stloc.1
    IL_0078:  ldloc.1
    IL_0079:  ldc.i4.1
    IL_007a:  sub
    IL_007b:  switch     ( 
                          IL_00ad,
                          IL_00ad,
                          IL_00ad,
                          IL_00ad,
                          IL_00ad,
                          IL_00ad,
                          IL_00ad,
                          IL_00dc,
                          IL_010b)
    IL_00a4:  ldloc.1
    IL_00a5:  ldc.i4.s   29
    IL_00a7:  sub
    IL_00a8:  ldc.i4.1
    IL_00a9:  ble.un.s   IL_010b

    IL_00ab:  br.s       IL_0119

    IL_00ad:  ldarg.0
    IL_00ae:  ldarg.0
    IL_00af:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_00b4:  ldarg.0
    IL_00b5:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_00ba:  ldarg.0
    IL_00bb:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_00c0:  ldc.i4.0
    IL_00c1:  ldelem.ref
    IL_00c2:  callvirt   instance class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.PLDataHelper::GetComponentList(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                                                                     string)
    IL_00c7:  stfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_00cc:  ldarg.0
    IL_00cd:  ldc.i4.0
    IL_00ce:  stfld      bool WpfPLData.Comp::_showProperty
    IL_00d3:  ldarg.0
    IL_00d4:  ldc.i4.1
    IL_00d5:  stfld      bool WpfPLData.Comp::_showComponent
    IL_00da:  br.s       IL_0119

    IL_00dc:  ldarg.0
    IL_00dd:  ldarg.0
    IL_00de:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_00e3:  ldarg.0
    IL_00e4:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_00e9:  ldarg.0
    IL_00ea:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_00ef:  ldc.i4.0
    IL_00f0:  ldelem.ref
    IL_00f1:  callvirt   instance class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.PLDataHelper::GetComponentList(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                                                                     string)
    IL_00f6:  stfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_00fb:  ldarg.0
    IL_00fc:  ldc.i4.1
    IL_00fd:  stfld      bool WpfPLData.Comp::_showProperty
    IL_0102:  ldarg.0
    IL_0103:  ldc.i4.1
    IL_0104:  stfld      bool WpfPLData.Comp::_showComponent
    IL_0109:  br.s       IL_0119

    IL_010b:  ldarg.0
    IL_010c:  ldc.i4.1
    IL_010d:  stfld      bool WpfPLData.Comp::_showProperty
    IL_0112:  ldarg.0
    IL_0113:  ldc.i4.0
    IL_0114:  stfld      bool WpfPLData.Comp::_showComponent
    IL_0119:  ldc.i4.1
    IL_011a:  stloc.0
    IL_011b:  ldarg.0
    IL_011c:  ldfld      int32 WpfPLData.Comp::PlotType
    IL_0121:  stloc.1
    IL_0122:  ldloc.1
    IL_0123:  ldc.i4.1
    IL_0124:  sub
    IL_0125:  switch     ( 
                          IL_0163,
                          IL_0182,
                          IL_01a1,
                          IL_01b8,
                          IL_01cf,
                          IL_01e6,
                          IL_0213,
                          IL_023d,
                          IL_0251)
    IL_014e:  ldloc.1
    IL_014f:  ldc.i4.s   29
    IL_0151:  beq        IL_026d

    IL_0156:  ldloc.1
    IL_0157:  ldc.i4.s   30
    IL_0159:  beq        IL_028c

    IL_015e:  br         IL_02ab

    IL_0163:  ldarg.0
    IL_0164:  call       instance bool WpfPLData.Comp::IsTempPresent()
    IL_0169:  brfalse.s  IL_017b

    IL_016b:  ldarg.0
    IL_016c:  call       instance bool WpfPLData.Comp::IsXPresent()
    IL_0171:  brfalse.s  IL_017b

    IL_0173:  ldarg.0
    IL_0174:  call       instance bool WpfPLData.Comp::IsYPresent()
    IL_0179:  br.s       IL_017c

    IL_017b:  ldc.i4.0
    IL_017c:  stloc.0
    IL_017d:  br         IL_02ad

    IL_0182:  ldarg.0
    IL_0183:  call       instance bool WpfPLData.Comp::IsPresPresent()
    IL_0188:  brfalse.s  IL_019a

    IL_018a:  ldarg.0
    IL_018b:  call       instance bool WpfPLData.Comp::IsXPresent()
    IL_0190:  brfalse.s  IL_019a

    IL_0192:  ldarg.0
    IL_0193:  call       instance bool WpfPLData.Comp::IsYPresent()
    IL_0198:  br.s       IL_019b

    IL_019a:  ldc.i4.0
    IL_019b:  stloc.0
    IL_019c:  br         IL_02ad

    IL_01a1:  ldarg.0
    IL_01a2:  call       instance bool WpfPLData.Comp::IsTempPresent()
    IL_01a7:  brfalse.s  IL_01b1

    IL_01a9:  ldarg.0
    IL_01aa:  call       instance bool WpfPLData.Comp::IsXPresent()
    IL_01af:  br.s       IL_01b2

    IL_01b1:  ldc.i4.0
    IL_01b2:  stloc.0
    IL_01b3:  br         IL_02ad

    IL_01b8:  ldarg.0
    IL_01b9:  call       instance bool WpfPLData.Comp::IsPresPresent()
    IL_01be:  brfalse.s  IL_01c8

    IL_01c0:  ldarg.0
    IL_01c1:  call       instance bool WpfPLData.Comp::IsXPresent()
    IL_01c6:  br.s       IL_01c9

    IL_01c8:  ldc.i4.0
    IL_01c9:  stloc.0
    IL_01ca:  br         IL_02ad

    IL_01cf:  ldarg.0
    IL_01d0:  call       instance bool WpfPLData.Comp::IsYPresent()
    IL_01d5:  brfalse.s  IL_01df

    IL_01d7:  ldarg.0
    IL_01d8:  call       instance bool WpfPLData.Comp::IsXPresent()
    IL_01dd:  br.s       IL_01e0

    IL_01df:  ldc.i4.0
    IL_01e0:  stloc.0
    IL_01e1:  br         IL_02ad

    IL_01e6:  ldarg.0
    IL_01e7:  call       instance bool WpfPLData.Comp::IsTempPresent()
    IL_01ec:  brfalse.s  IL_020c

    IL_01ee:  ldarg.0
    IL_01ef:  ldstr      "X1"
    IL_01f4:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_01f9:  ldc.i4.2
    IL_01fa:  bne.un.s   IL_020c

    IL_01fc:  ldarg.0
    IL_01fd:  ldstr      "X2"
    IL_0202:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_0207:  ldc.i4.2
    IL_0208:  ceq
    IL_020a:  br.s       IL_020d

    IL_020c:  ldc.i4.0
    IL_020d:  stloc.0
    IL_020e:  br         IL_02ad

    IL_0213:  ldarg.0
    IL_0214:  call       instance bool WpfPLData.Comp::IsPresPresent()
    IL_0219:  brfalse.s  IL_0239

    IL_021b:  ldarg.0
    IL_021c:  ldstr      "X1"
    IL_0221:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_0226:  ldc.i4.2
    IL_0227:  bne.un.s   IL_0239

    IL_0229:  ldarg.0
    IL_022a:  ldstr      "X2"
    IL_022f:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_0234:  ldc.i4.2
    IL_0235:  ceq
    IL_0237:  br.s       IL_023a

    IL_0239:  ldc.i4.0
    IL_023a:  stloc.0
    IL_023b:  br.s       IL_02ad

    IL_023d:  ldarg.0
    IL_023e:  call       instance bool WpfPLData.Comp::IsXPresent()
    IL_0243:  brfalse.s  IL_024d

    IL_0245:  ldarg.0
    IL_0246:  call       instance bool WpfPLData.Comp::IsPropertyPresent()
    IL_024b:  br.s       IL_024e

    IL_024d:  ldc.i4.0
    IL_024e:  stloc.0
    IL_024f:  br.s       IL_02ad

    IL_0251:  ldarg.0
    IL_0252:  call       instance bool WpfPLData.Comp::IsTempPresent()
    IL_0257:  brfalse.s  IL_0269

    IL_0259:  ldarg.0
    IL_025a:  call       instance bool WpfPLData.Comp::IsPropertyPresent()
    IL_025f:  brfalse.s  IL_0269

    IL_0261:  ldarg.0
    IL_0262:  call       instance bool WpfPLData.Comp::IsMixture()
    IL_0267:  br.s       IL_026a

    IL_0269:  ldc.i4.0
    IL_026a:  stloc.0
    IL_026b:  br.s       IL_02ad

    IL_026d:  ldarg.0
    IL_026e:  call       instance bool WpfPLData.Comp::IsTempPresent()
    IL_0273:  brfalse.s  IL_0288

    IL_0275:  ldarg.0
    IL_0276:  call       instance bool WpfPLData.Comp::IsPropertyPresent()
    IL_027b:  brfalse.s  IL_0288

    IL_027d:  ldarg.0
    IL_027e:  call       instance bool WpfPLData.Comp::IsMixture()
    IL_0283:  ldc.i4.0
    IL_0284:  ceq
    IL_0286:  br.s       IL_0289

    IL_0288:  ldc.i4.0
    IL_0289:  stloc.0
    IL_028a:  br.s       IL_02ad

    IL_028c:  ldarg.0
    IL_028d:  call       instance bool WpfPLData.Comp::IsPresPresent2()
    IL_0292:  brfalse.s  IL_02a7

    IL_0294:  ldarg.0
    IL_0295:  call       instance bool WpfPLData.Comp::IsPropertyPresent()
    IL_029a:  brfalse.s  IL_02a7

    IL_029c:  ldarg.0
    IL_029d:  call       instance bool WpfPLData.Comp::IsMixture()
    IL_02a2:  ldc.i4.0
    IL_02a3:  ceq
    IL_02a5:  br.s       IL_02a8

    IL_02a7:  ldc.i4.0
    IL_02a8:  stloc.0
    IL_02a9:  br.s       IL_02ad

    IL_02ab:  ldc.i4.0
    IL_02ac:  stloc.0
    IL_02ad:  ldloc.0
    IL_02ae:  ret
  } // end of method Comp::Build_CandidateList

  .method private hidebysig instance void 
          Build_Node_Lookup() cil managed
  {
    // Code size       707 (0x2c3)
    .maxstack  4
    .locals init (class AspenTech.AspenPlus.Happ.IHNode V_0,
             int32 V_1,
             int32 V_2,
             int32 V_3,
             int32 V_4,
             int32 V_5,
             string V_6,
             string V_7,
             int32 V_8,
             char V_9)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0006:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_000b:  stloc.2
    IL_000c:  ldloc.2
    IL_000d:  ldc.i4.1
    IL_000e:  sub
    IL_000f:  ldc.i4.7
    IL_0010:  bgt.un.s   IL_0069

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0018:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_001d:  stloc.1
    IL_001e:  ldarg.0
    IL_001f:  ldloc.1
    IL_0020:  newarr     [mscorlib]System.Int32
    IL_0025:  stfld      int32[] WpfPLData.Comp::Xc
    IL_002a:  ldarg.0
    IL_002b:  ldloc.1
    IL_002c:  newarr     [mscorlib]System.Int32
    IL_0031:  stfld      int32[] WpfPLData.Comp::X2c
    IL_0036:  ldarg.0
    IL_0037:  ldloc.1
    IL_0038:  newarr     [mscorlib]System.Int32
    IL_003d:  stfld      int32[] WpfPLData.Comp::Yc
    IL_0042:  ldc.i4.0
    IL_0043:  stloc.3
    IL_0044:  br.s       IL_0065

    IL_0046:  ldarg.0
    IL_0047:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_004c:  ldloc.3
    IL_004d:  ldc.i4.m1
    IL_004e:  stelem.i4
    IL_004f:  ldarg.0
    IL_0050:  ldfld      int32[] WpfPLData.Comp::X2c
    IL_0055:  ldloc.3
    IL_0056:  ldc.i4.m1
    IL_0057:  stelem.i4
    IL_0058:  ldarg.0
    IL_0059:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_005e:  ldloc.3
    IL_005f:  ldc.i4.m1
    IL_0060:  stelem.i4
    IL_0061:  ldloc.3
    IL_0062:  ldc.i4.1
    IL_0063:  add
    IL_0064:  stloc.3
    IL_0065:  ldloc.3
    IL_0066:  ldloc.1
    IL_0067:  blt.s      IL_0046

    IL_0069:  ldarg.0
    IL_006a:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_006f:  ldarg.0
    IL_0070:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_0075:  ldc.i4.2
    IL_0076:  ldelem.ref
    IL_0077:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_007c:  stloc.0
    IL_007d:  ldloc.0
    IL_007e:  brfalse    IL_02c2

    IL_0083:  ldloc.0
    IL_0084:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0089:  ldc.i4.1
    IL_008a:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHNodeCol::get_RowCount(int32)
    IL_008f:  stloc.s    V_4
    IL_0091:  ldc.i4.0
    IL_0092:  stloc.s    V_5
    IL_0094:  br         IL_02b9

    IL_0099:  ldloc.0
    IL_009a:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_009f:  ldc.i4.1
    IL_00a0:  ldloc.s    V_5
    IL_00a2:  ldsfld     object [mscorlib]System.Type::Missing
    IL_00a7:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_00ac:  stloc.s    V_6
    IL_00ae:  ldloc.0
    IL_00af:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_00b4:  ldc.i4.2
    IL_00b5:  ldloc.s    V_5
    IL_00b7:  ldsfld     object [mscorlib]System.Type::Missing
    IL_00bc:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_00c1:  stloc.s    V_7
    IL_00c3:  ldc.i4.m1
    IL_00c4:  stloc.s    V_8
    IL_00c6:  ldloc.s    V_6
    IL_00c8:  brfalse    IL_02b3

    IL_00cd:  ldloc.s    V_6
    IL_00cf:  call       instance int32 [mscorlib]System.String::get_Length()
    IL_00d4:  stloc.2
    IL_00d5:  ldloc.2
    IL_00d6:  ldc.i4.1
    IL_00d7:  sub
    IL_00d8:  switch     ( 
                          IL_011d,
                          IL_013e,
                          IL_02b3,
                          IL_02b3,
                          IL_0102)
    IL_00f1:  ldloc.2
    IL_00f2:  ldc.i4.8
    IL_00f3:  beq        IL_0195

    IL_00f8:  ldloc.2
    IL_00f9:  ldc.i4.s   11
    IL_00fb:  beq.s      IL_0159

    IL_00fd:  br         IL_02b3

    IL_0102:  ldloc.s    V_6
    IL_0104:  ldc.i4.4
    IL_0105:  call       instance char [mscorlib]System.String::get_Chars(int32)
    IL_010a:  stloc.s    V_9
    IL_010c:  ldloc.s    V_9
    IL_010e:  ldc.i4.s   49
    IL_0110:  beq.s      IL_016c

    IL_0112:  ldloc.s    V_9
    IL_0114:  ldc.i4.s   50
    IL_0116:  beq.s      IL_017f

    IL_0118:  br         IL_02b3

    IL_011d:  ldloc.s    V_6
    IL_011f:  ldc.i4.0
    IL_0120:  call       instance char [mscorlib]System.String::get_Chars(int32)
    IL_0125:  stloc.s    V_9
    IL_0127:  ldloc.s    V_9
    IL_0129:  ldc.i4.s   88
    IL_012b:  beq        IL_0252

    IL_0130:  ldloc.s    V_9
    IL_0132:  ldc.i4.s   89
    IL_0134:  beq        IL_0294

    IL_0139:  br         IL_02b3

    IL_013e:  ldloc.s    V_6
    IL_0140:  ldc.i4.1
    IL_0141:  call       instance char [mscorlib]System.String::get_Chars(int32)
    IL_0146:  stloc.s    V_9
    IL_0148:  ldloc.s    V_9
    IL_014a:  ldc.i4.s   49
    IL_014c:  beq.s      IL_01ab

    IL_014e:  ldloc.s    V_9
    IL_0150:  ldc.i4.s   50
    IL_0152:  beq.s      IL_01c1

    IL_0154:  br         IL_02b3

    IL_0159:  ldloc.s    V_6
    IL_015b:  ldstr      "TEMPERATURE"
    IL_0160:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0165:  brtrue.s   IL_01d7

    IL_0167:  br         IL_02b3

    IL_016c:  ldloc.s    V_6
    IL_016e:  ldstr      "TEMP1"
    IL_0173:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0178:  brtrue.s   IL_01f8

    IL_017a:  br         IL_02b3

    IL_017f:  ldloc.s    V_6
    IL_0181:  ldstr      "TEMP2"
    IL_0186:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_018b:  brtrue     IL_0219

    IL_0190:  br         IL_02b3

    IL_0195:  ldloc.s    V_6
    IL_0197:  ldstr      "PRESSURE"
    IL_019c:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_01a1:  brtrue     IL_0237

    IL_01a6:  br         IL_02b3

    IL_01ab:  ldloc.s    V_6
    IL_01ad:  ldstr      "X1"
    IL_01b2:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_01b7:  brtrue     IL_0252

    IL_01bc:  br         IL_02b3

    IL_01c1:  ldloc.s    V_6
    IL_01c3:  ldstr      "X2"
    IL_01c8:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_01cd:  brtrue     IL_0273

    IL_01d2:  br         IL_02b3

    IL_01d7:  ldarg.0
    IL_01d8:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_01dd:  ldc.i4.m1
    IL_01de:  bne.un     IL_02b3

    IL_01e3:  ldarg.0
    IL_01e4:  ldloc.s    V_7
    IL_01e6:  stfld      string WpfPLData.Comp::TempUnit
    IL_01eb:  ldarg.0
    IL_01ec:  ldloc.s    V_5
    IL_01ee:  stfld      int32 WpfPLData.Comp::TempElement
    IL_01f3:  br         IL_02b3

    IL_01f8:  ldarg.0
    IL_01f9:  ldfld      int32 WpfPLData.Comp::TempElement
    IL_01fe:  ldc.i4.m1
    IL_01ff:  bne.un     IL_02b3

    IL_0204:  ldarg.0
    IL_0205:  ldloc.s    V_7
    IL_0207:  stfld      string WpfPLData.Comp::TempUnit
    IL_020c:  ldarg.0
    IL_020d:  ldloc.s    V_5
    IL_020f:  stfld      int32 WpfPLData.Comp::TempElement
    IL_0214:  br         IL_02b3

    IL_0219:  ldarg.0
    IL_021a:  ldfld      int32 WpfPLData.Comp::Temp2Element
    IL_021f:  ldc.i4.m1
    IL_0220:  bne.un     IL_02b3

    IL_0225:  ldarg.0
    IL_0226:  ldloc.s    V_7
    IL_0228:  stfld      string WpfPLData.Comp::Temp2Unit
    IL_022d:  ldarg.0
    IL_022e:  ldloc.s    V_5
    IL_0230:  stfld      int32 WpfPLData.Comp::Temp2Element
    IL_0235:  br.s       IL_02b3

    IL_0237:  ldarg.0
    IL_0238:  ldfld      int32 WpfPLData.Comp::PresElement
    IL_023d:  ldc.i4.m1
    IL_023e:  bne.un.s   IL_02b3

    IL_0240:  ldarg.0
    IL_0241:  ldloc.s    V_7
    IL_0243:  stfld      string WpfPLData.Comp::PresUnit
    IL_0248:  ldarg.0
    IL_0249:  ldloc.s    V_5
    IL_024b:  stfld      int32 WpfPLData.Comp::PresElement
    IL_0250:  br.s       IL_02b3

    IL_0252:  ldarg.0
    IL_0253:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0258:  ldloc.s    V_7
    IL_025a:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::IndexOf(!0)
    IL_025f:  stloc.s    V_8
    IL_0261:  ldloc.s    V_8
    IL_0263:  ldc.i4.0
    IL_0264:  blt.s      IL_02b3

    IL_0266:  ldarg.0
    IL_0267:  ldfld      int32[] WpfPLData.Comp::Xc
    IL_026c:  ldloc.s    V_8
    IL_026e:  ldloc.s    V_5
    IL_0270:  stelem.i4
    IL_0271:  br.s       IL_02b3

    IL_0273:  ldarg.0
    IL_0274:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0279:  ldloc.s    V_7
    IL_027b:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::IndexOf(!0)
    IL_0280:  stloc.s    V_8
    IL_0282:  ldloc.s    V_8
    IL_0284:  ldc.i4.0
    IL_0285:  blt.s      IL_02b3

    IL_0287:  ldarg.0
    IL_0288:  ldfld      int32[] WpfPLData.Comp::X2c
    IL_028d:  ldloc.s    V_8
    IL_028f:  ldloc.s    V_5
    IL_0291:  stelem.i4
    IL_0292:  br.s       IL_02b3

    IL_0294:  ldarg.0
    IL_0295:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_029a:  ldloc.s    V_7
    IL_029c:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::IndexOf(!0)
    IL_02a1:  stloc.s    V_8
    IL_02a3:  ldloc.s    V_8
    IL_02a5:  ldc.i4.0
    IL_02a6:  blt.s      IL_02b3

    IL_02a8:  ldarg.0
    IL_02a9:  ldfld      int32[] WpfPLData.Comp::Yc
    IL_02ae:  ldloc.s    V_8
    IL_02b0:  ldloc.s    V_5
    IL_02b2:  stelem.i4
    IL_02b3:  ldloc.s    V_5
    IL_02b5:  ldc.i4.1
    IL_02b6:  add
    IL_02b7:  stloc.s    V_5
    IL_02b9:  ldloc.s    V_5
    IL_02bb:  ldloc.s    V_4
    IL_02bd:  blt        IL_0099

    IL_02c2:  ret
  } // end of method Comp::Build_Node_Lookup

  .method private hidebysig instance bool 
          IsPropertyPresent() cil managed
  {
    // Code size       654 (0x28e)
    .maxstack  4
    .locals init (bool V_0,
             class AspenTech.AspenPlus.Happ.IHNode V_1,
             int32 V_2,
             int32 V_3,
             int32 V_4,
             string V_5,
             string V_6,
             int32 V_7,
             char V_8)
    IL_0000:  ldc.i4.0
    IL_0001:  stloc.0
    IL_0002:  ldarg.0
    IL_0003:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_0008:  ldarg.0
    IL_0009:  ldfld      string[] WpfPLData.Comp::VarNames
    IL_000e:  ldc.i4.2
    IL_000f:  ldelem.ref
    IL_0010:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_0015:  stloc.1
    IL_0016:  ldloc.1
    IL_0017:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_001c:  ldc.i4.1
    IL_001d:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHNodeCol::get_RowCount(int32)
    IL_0022:  stloc.2
    IL_0023:  ldc.i4.0
    IL_0024:  stloc.3
    IL_0025:  ldarg.0
    IL_0026:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_002b:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Clear()
    IL_0030:  ldarg.0
    IL_0031:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_0036:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Clear()
    IL_003b:  ldarg.0
    IL_003c:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_0041:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<int32>::Clear()
    IL_0046:  ldc.i4.0
    IL_0047:  stloc.s    V_4
    IL_0049:  br         IL_027e

    IL_004e:  ldloc.1
    IL_004f:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0054:  ldc.i4.1
    IL_0055:  ldloc.s    V_4
    IL_0057:  ldsfld     object [mscorlib]System.Type::Missing
    IL_005c:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_0061:  stloc.s    V_5
    IL_0063:  ldloc.1
    IL_0064:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0069:  ldc.i4.2
    IL_006a:  ldloc.s    V_4
    IL_006c:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0071:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_0076:  stloc.s    V_6
    IL_0078:  ldloc.s    V_5
    IL_007a:  brfalse    IL_0220

    IL_007f:  ldloc.s    V_5
    IL_0081:  call       instance int32 [mscorlib]System.String::get_Length()
    IL_0086:  stloc.s    V_7
    IL_0088:  ldloc.s    V_7
    IL_008a:  ldc.i4.1
    IL_008b:  sub
    IL_008c:  switch     ( 
                          IL_00d6,
                          IL_00f7,
                          IL_0220,
                          IL_0220,
                          IL_00bb)
    IL_00a5:  ldloc.s    V_7
    IL_00a7:  ldc.i4.8
    IL_00a8:  beq        IL_0180

    IL_00ad:  ldloc.s    V_7
    IL_00af:  ldc.i4.s   11
    IL_00b1:  beq        IL_013e

    IL_00b6:  br         IL_0220

    IL_00bb:  ldloc.s    V_5
    IL_00bd:  ldc.i4.4
    IL_00be:  call       instance char [mscorlib]System.String::get_Chars(int32)
    IL_00c3:  stloc.s    V_8
    IL_00c5:  ldloc.s    V_8
    IL_00c7:  ldc.i4.s   49
    IL_00c9:  beq.s      IL_0112

    IL_00cb:  ldloc.s    V_8
    IL_00cd:  ldc.i4.s   50
    IL_00cf:  beq.s      IL_0128

    IL_00d1:  br         IL_0220

    IL_00d6:  ldloc.s    V_5
    IL_00d8:  ldc.i4.0
    IL_00d9:  call       instance char [mscorlib]System.String::get_Chars(int32)
    IL_00de:  stloc.s    V_8
    IL_00e0:  ldloc.s    V_8
    IL_00e2:  ldc.i4.s   88
    IL_00e4:  beq        IL_0278

    IL_00e9:  ldloc.s    V_8
    IL_00eb:  ldc.i4.s   89
    IL_00ed:  beq        IL_0278

    IL_00f2:  br         IL_0220

    IL_00f7:  ldloc.s    V_5
    IL_00f9:  ldc.i4.1
    IL_00fa:  call       instance char [mscorlib]System.String::get_Chars(int32)
    IL_00ff:  stloc.s    V_8
    IL_0101:  ldloc.s    V_8
    IL_0103:  ldc.i4.s   49
    IL_0105:  beq.s      IL_0154

    IL_0107:  ldloc.s    V_8
    IL_0109:  ldc.i4.s   50
    IL_010b:  beq.s      IL_016a

    IL_010d:  br         IL_0220

    IL_0112:  ldloc.s    V_5
    IL_0114:  ldstr      "TEMP1"
    IL_0119:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_011e:  brtrue     IL_0278

    IL_0123:  br         IL_0220

    IL_0128:  ldloc.s    V_5
    IL_012a:  ldstr      "TEMP2"
    IL_012f:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0134:  brtrue     IL_0278

    IL_0139:  br         IL_0220

    IL_013e:  ldloc.s    V_5
    IL_0140:  ldstr      "TEMPERATURE"
    IL_0145:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_014a:  brtrue     IL_0278

    IL_014f:  br         IL_0220

    IL_0154:  ldloc.s    V_5
    IL_0156:  ldstr      "X1"
    IL_015b:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0160:  brtrue     IL_0278

    IL_0165:  br         IL_0220

    IL_016a:  ldloc.s    V_5
    IL_016c:  ldstr      "X2"
    IL_0171:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0176:  brtrue     IL_0278

    IL_017b:  br         IL_0220

    IL_0180:  ldloc.s    V_5
    IL_0182:  ldstr      "PRESSURE"
    IL_0187:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_018c:  brfalse    IL_0220

    IL_0191:  ldarg.0
    IL_0192:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0197:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_019c:  ldc.i4.s   9
    IL_019e:  beq        IL_0278

    IL_01a3:  ldarg.0
    IL_01a4:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_01a9:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_01ae:  ldc.i4.8
    IL_01af:  beq        IL_0278

    IL_01b4:  ldarg.0
    IL_01b5:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_01ba:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_01bf:  ldc.i4.s   30
    IL_01c1:  beq        IL_0278

    IL_01c6:  ldloc.3
    IL_01c7:  ldc.i4.1
    IL_01c8:  add
    IL_01c9:  stloc.3
    IL_01ca:  ldarg.0
    IL_01cb:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_01d0:  ldloc.s    V_5
    IL_01d2:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<string>::Contains(!0)
    IL_01d7:  brtrue.s   IL_01e6

    IL_01d9:  ldarg.0
    IL_01da:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_01df:  ldloc.s    V_5
    IL_01e1:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_01e6:  ldarg.0
    IL_01e7:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_01ec:  ldloc.s    V_6
    IL_01ee:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<string>::Contains(!0)
    IL_01f3:  brtrue.s   IL_0202

    IL_01f5:  ldarg.0
    IL_01f6:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_01fb:  ldloc.s    V_6
    IL_01fd:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0202:  ldarg.0
    IL_0203:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_0208:  ldloc.s    V_4
    IL_020a:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<int32>::Contains(!0)
    IL_020f:  brtrue.s   IL_0278

    IL_0211:  ldarg.0
    IL_0212:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_0217:  ldloc.s    V_4
    IL_0219:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<int32>::Add(!0)
    IL_021e:  br.s       IL_0278

    IL_0220:  ldloc.3
    IL_0221:  ldc.i4.1
    IL_0222:  add
    IL_0223:  stloc.3
    IL_0224:  ldarg.0
    IL_0225:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_022a:  ldloc.s    V_5
    IL_022c:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<string>::Contains(!0)
    IL_0231:  brtrue.s   IL_0240

    IL_0233:  ldarg.0
    IL_0234:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_0239:  ldloc.s    V_5
    IL_023b:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0240:  ldarg.0
    IL_0241:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_0246:  ldloc.s    V_6
    IL_0248:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<string>::Contains(!0)
    IL_024d:  brtrue.s   IL_025c

    IL_024f:  ldarg.0
    IL_0250:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropUnit
    IL_0255:  ldloc.s    V_6
    IL_0257:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_025c:  ldarg.0
    IL_025d:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_0262:  ldloc.s    V_4
    IL_0264:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<int32>::Contains(!0)
    IL_0269:  brtrue.s   IL_0278

    IL_026b:  ldarg.0
    IL_026c:  ldfld      class [mscorlib]System.Collections.Generic.List`1<int32> WpfPLData.Comp::XPropc
    IL_0271:  ldloc.s    V_4
    IL_0273:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<int32>::Add(!0)
    IL_0278:  ldloc.s    V_4
    IL_027a:  ldc.i4.1
    IL_027b:  add
    IL_027c:  stloc.s    V_4
    IL_027e:  ldloc.s    V_4
    IL_0280:  ldloc.2
    IL_0281:  blt        IL_004e

    IL_0286:  ldloc.3
    IL_0287:  ldc.i4.0
    IL_0288:  ble.s      IL_028c

    IL_028a:  ldc.i4.1
    IL_028b:  stloc.0
    IL_028c:  ldloc.0
    IL_028d:  ret
  } // end of method Comp::IsPropertyPresent

  .method private hidebysig instance bool 
          IsTempPresent() cil managed
  {
    // Code size       48 (0x30)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldc.i4.0
    IL_0001:  stloc.0
    IL_0002:  ldarg.0
    IL_0003:  ldstr      "TEMPERATURE"
    IL_0008:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_000d:  ldc.i4.0
    IL_000e:  bgt.s      IL_002c

    IL_0010:  ldarg.0
    IL_0011:  ldstr      "TEMP1"
    IL_0016:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_001b:  ldc.i4.0
    IL_001c:  bgt.s      IL_002c

    IL_001e:  ldarg.0
    IL_001f:  ldstr      "TEMP2"
    IL_0024:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_0029:  ldc.i4.0
    IL_002a:  ble.s      IL_002e

    IL_002c:  ldc.i4.1
    IL_002d:  stloc.0
    IL_002e:  ldloc.0
    IL_002f:  ret
  } // end of method Comp::IsTempPresent

  .method private hidebysig instance bool 
          IsPresPresent2() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldc.i4.0
    IL_0001:  stloc.0
    IL_0002:  ldarg.0
    IL_0003:  ldstr      "PRESSURE"
    IL_0008:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_000d:  ldc.i4.0
    IL_000e:  bgt.s      IL_001e

    IL_0010:  ldarg.0
    IL_0011:  ldstr      "PRES"
    IL_0016:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_001b:  ldc.i4.0
    IL_001c:  ble.s      IL_0020

    IL_001e:  ldc.i4.1
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method Comp::IsPresPresent2

  .method private hidebysig instance bool 
          IsPresPresent() cil managed
  {
    // Code size       491 (0x1eb)
    .maxstack  13
    .locals init (bool V_0,
             class AspenTech.AspenPlus.Happ.IHNode V_1,
             bool V_2)
    IL_0000:  ldc.i4.0
    IL_0001:  stloc.0
    IL_0002:  ldarg.0
    IL_0003:  ldstr      "PRESSURE"
    IL_0008:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_000d:  ldc.i4.0
    IL_000e:  ble.s      IL_0017

    IL_0010:  ldc.i4.1
    IL_0011:  stloc.0
    IL_0012:  br         IL_01e9

    IL_0017:  ldarg.0
    IL_0018:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_001d:  ldstr      "Input/PRES"
    IL_0022:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_0027:  stloc.1
    IL_0028:  ldloc.1
    IL_0029:  ldnull
    IL_002a:  ceq
    IL_002c:  stloc.2
    IL_002d:  ldloc.2
    IL_002e:  brtrue     IL_012b

    IL_0033:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> WpfPLData.Comp/'<>o__83'::'<>p__2'
    IL_0038:  brtrue.s   IL_0066

    IL_003a:  ldc.i4.0
    IL_003b:  ldc.i4.s   83
    IL_003d:  ldtoken    WpfPLData.Comp
    IL_0042:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0047:  ldc.i4.1
    IL_0048:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_004d:  dup
    IL_004e:  ldc.i4.0
    IL_004f:  ldc.i4.0
    IL_0050:  ldnull
    IL_0051:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0056:  stelem.ref
    IL_0057:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::UnaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_005c:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0061:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> WpfPLData.Comp/'<>o__83'::'<>p__2'
    IL_0066:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> WpfPLData.Comp/'<>o__83'::'<>p__2'
    IL_006b:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Target
    IL_0070:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> WpfPLData.Comp/'<>o__83'::'<>p__2'
    IL_0075:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__1'
    IL_007a:  brtrue.s   IL_00b2

    IL_007c:  ldc.i4.8
    IL_007d:  ldc.i4.s   36
    IL_007f:  ldtoken    WpfPLData.Comp
    IL_0084:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0089:  ldc.i4.2
    IL_008a:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_008f:  dup
    IL_0090:  ldc.i4.0
    IL_0091:  ldc.i4.1
    IL_0092:  ldnull
    IL_0093:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0098:  stelem.ref
    IL_0099:  dup
    IL_009a:  ldc.i4.1
    IL_009b:  ldc.i4.0
    IL_009c:  ldnull
    IL_009d:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_00a2:  stelem.ref
    IL_00a3:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_00a8:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_00ad:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__1'
    IL_00b2:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__1'
    IL_00b7:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>>::Target
    IL_00bc:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__1'
    IL_00c1:  ldloc.2
    IL_00c2:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__0'
    IL_00c7:  brtrue.s   IL_00ff

    IL_00c9:  ldc.i4.0
    IL_00ca:  ldc.i4.s   13
    IL_00cc:  ldtoken    WpfPLData.Comp
    IL_00d1:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_00d6:  ldc.i4.2
    IL_00d7:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_00dc:  dup
    IL_00dd:  ldc.i4.0
    IL_00de:  ldc.i4.0
    IL_00df:  ldnull
    IL_00e0:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_00e5:  stelem.ref
    IL_00e6:  dup
    IL_00e7:  ldc.i4.1
    IL_00e8:  ldc.i4.2
    IL_00e9:  ldnull
    IL_00ea:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_00ef:  stelem.ref
    IL_00f0:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_00f5:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_00fa:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__0'
    IL_00ff:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__0'
    IL_0104:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Target
    IL_0109:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__0'
    IL_010e:  ldloc.1
    IL_010f:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0114:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_0119:  ldnull
    IL_011a:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_011f:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>::Invoke(!0,
                                                                                                                                                           !1,
                                                                                                                                                           !2)
    IL_0124:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>::Invoke(!0,
                                                                                                                                                    !1)
    IL_0129:  brfalse.s  IL_013b

    IL_012b:  ldarg.0
    IL_012c:  ldsfld     string [mscorlib]System.String::Empty
    IL_0131:  stfld      string WpfPLData.Comp::PresAmt
    IL_0136:  br         IL_01d6

    IL_013b:  ldarg.0
    IL_013c:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__83'::'<>p__4'
    IL_0141:  brtrue.s   IL_0167

    IL_0143:  ldc.i4.0
    IL_0144:  ldtoken    [mscorlib]System.String
    IL_0149:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_014e:  ldtoken    WpfPLData.Comp
    IL_0153:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0158:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_015d:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0162:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__83'::'<>p__4'
    IL_0167:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__83'::'<>p__4'
    IL_016c:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_0171:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__83'::'<>p__4'
    IL_0176:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__3'
    IL_017b:  brtrue.s   IL_01ad

    IL_017d:  ldc.i4.0
    IL_017e:  ldstr      "ToString"
    IL_0183:  ldnull
    IL_0184:  ldtoken    WpfPLData.Comp
    IL_0189:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_018e:  ldc.i4.1
    IL_018f:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_0194:  dup
    IL_0195:  ldc.i4.0
    IL_0196:  ldc.i4.0
    IL_0197:  ldnull
    IL_0198:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_019d:  stelem.ref
    IL_019e:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                 string,
                                                                                                                                                                 class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                 class [mscorlib]System.Type,
                                                                                                                                                                 class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_01a3:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_01a8:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__3'
    IL_01ad:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__3'
    IL_01b2:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Target
    IL_01b7:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> WpfPLData.Comp/'<>o__83'::'<>p__3'
    IL_01bc:  ldloc.1
    IL_01bd:  ldsfld     object [mscorlib]System.Type::Missing
    IL_01c2:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_01c7:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>::Invoke(!0,
                                                                                                                                                      !1)
    IL_01cc:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_01d1:  stfld      string WpfPLData.Comp::PresAmt
    IL_01d6:  ldarg.0
    IL_01d7:  ldfld      string WpfPLData.Comp::PresAmt
    IL_01dc:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_01e1:  brtrue.s   IL_01e7

    IL_01e3:  ldc.i4.1
    IL_01e4:  stloc.0
    IL_01e5:  br.s       IL_01e9

    IL_01e7:  ldc.i4.0
    IL_01e8:  stloc.0
    IL_01e9:  ldloc.0
    IL_01ea:  ret
  } // end of method Comp::IsPresPresent

  .method private hidebysig instance bool 
          IsXPresent() cil managed
  {
    // Code size       15 (0xf)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "X"
    IL_0006:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_000b:  ldc.i4.0
    IL_000c:  cgt
    IL_000e:  ret
  } // end of method Comp::IsXPresent

  .method private hidebysig instance bool 
          IsX1Present() cil managed
  {
    // Code size       15 (0xf)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "X1"
    IL_0006:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_000b:  ldc.i4.0
    IL_000c:  cgt
    IL_000e:  ret
  } // end of method Comp::IsX1Present

  .method private hidebysig instance bool 
          IsX2Present() cil managed
  {
    // Code size       15 (0xf)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "X2"
    IL_0006:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_000b:  ldc.i4.0
    IL_000c:  cgt
    IL_000e:  ret
  } // end of method Comp::IsX2Present

  .method private hidebysig instance bool 
          IsYPresent() cil managed
  {
    // Code size       15 (0xf)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "Y"
    IL_0006:  call       instance int32 WpfPLData.Comp::CountFor(string)
    IL_000b:  ldc.i4.0
    IL_000c:  cgt
    IL_000e:  ret
  } // end of method Comp::IsYPresent

  .method private hidebysig instance void 
          SetWindowTitle() cil managed
  {
    // Code size       489 (0x1e9)
    .maxstack  6
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0006:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_000b:  stloc.0
    IL_000c:  ldloc.0
    IL_000d:  ldc.i4.1
    IL_000e:  sub
    IL_000f:  switch     ( 
                          IL_0049,
                          IL_007b,
                          IL_00ad,
                          IL_00df,
                          IL_0111,
                          IL_0143,
                          IL_0175,
                          IL_01a7,
                          IL_01bd)
    IL_0038:  ldloc.0
    IL_0039:  ldc.i4.s   29
    IL_003b:  beq        IL_01bd

    IL_0040:  ldloc.0
    IL_0041:  ldc.i4.s   30
    IL_0043:  beq        IL_01d3

    IL_0048:  ret

    IL_0049:  ldarg.0
    IL_004a:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_004f:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0054:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TXYTitle()
    IL_0059:  ldarg.0
    IL_005a:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_005f:  ldarg.0
    IL_0060:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0065:  ldstr      "/"
    IL_006a:  ldc.i4.0
    IL_006b:  callvirt   instance string WpfPLData.PLDataHelper::Join(class [mscorlib]System.Collections.Generic.List`1<string>,
                                                                      string,
                                                                      bool)
    IL_0070:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_0075:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_007a:  ret

    IL_007b:  ldarg.0
    IL_007c:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0081:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0086:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_PXYTitle()
    IL_008b:  ldarg.0
    IL_008c:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_0091:  ldarg.0
    IL_0092:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0097:  ldstr      "/"
    IL_009c:  ldc.i4.0
    IL_009d:  callvirt   instance string WpfPLData.PLDataHelper::Join(class [mscorlib]System.Collections.Generic.List`1<string>,
                                                                      string,
                                                                      bool)
    IL_00a2:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_00a7:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_00ac:  ret

    IL_00ad:  ldarg.0
    IL_00ae:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_00b3:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_00b8:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TXTitle()
    IL_00bd:  ldarg.0
    IL_00be:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_00c3:  ldarg.0
    IL_00c4:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_00c9:  ldstr      "/"
    IL_00ce:  ldc.i4.0
    IL_00cf:  callvirt   instance string WpfPLData.PLDataHelper::Join(class [mscorlib]System.Collections.Generic.List`1<string>,
                                                                      string,
                                                                      bool)
    IL_00d4:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_00d9:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_00de:  ret

    IL_00df:  ldarg.0
    IL_00e0:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_00e5:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_00ea:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_PXTitle()
    IL_00ef:  ldarg.0
    IL_00f0:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_00f5:  ldarg.0
    IL_00f6:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_00fb:  ldstr      "/"
    IL_0100:  ldc.i4.0
    IL_0101:  callvirt   instance string WpfPLData.PLDataHelper::Join(class [mscorlib]System.Collections.Generic.List`1<string>,
                                                                      string,
                                                                      bool)
    IL_0106:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_010b:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_0110:  ret

    IL_0111:  ldarg.0
    IL_0112:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0117:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_011c:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_YXTitle()
    IL_0121:  ldarg.0
    IL_0122:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_0127:  ldarg.0
    IL_0128:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_012d:  ldstr      "/"
    IL_0132:  ldc.i4.0
    IL_0133:  callvirt   instance string WpfPLData.PLDataHelper::Join(class [mscorlib]System.Collections.Generic.List`1<string>,
                                                                      string,
                                                                      bool)
    IL_0138:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_013d:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_0142:  ret

    IL_0143:  ldarg.0
    IL_0144:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0149:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_014e:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TXXTitle()
    IL_0153:  ldarg.0
    IL_0154:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_0159:  ldarg.0
    IL_015a:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_015f:  ldstr      "/"
    IL_0164:  ldc.i4.0
    IL_0165:  callvirt   instance string WpfPLData.PLDataHelper::Join(class [mscorlib]System.Collections.Generic.List`1<string>,
                                                                      string,
                                                                      bool)
    IL_016a:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_016f:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_0174:  ret

    IL_0175:  ldarg.0
    IL_0176:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_017b:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0180:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_PXXTitle()
    IL_0185:  ldarg.0
    IL_0186:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Comp::_help
    IL_018b:  ldarg.0
    IL_018c:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::ComponentList
    IL_0191:  ldstr      "/"
    IL_0196:  ldc.i4.0
    IL_0197:  callvirt   instance string WpfPLData.PLDataHelper::Join(class [mscorlib]System.Collections.Generic.List`1<string>,
                                                                      string,
                                                                      bool)
    IL_019c:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_01a1:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_01a6:  ret

    IL_01a7:  ldarg.0
    IL_01a8:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_01ad:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_01b2:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_PropCompTitle()
    IL_01b7:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_01bc:  ret

    IL_01bd:  ldarg.0
    IL_01be:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_01c3:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_01c8:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_PropTempTitle()
    IL_01cd:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_01d2:  ret

    IL_01d3:  ldarg.0
    IL_01d4:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_01d9:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_01de:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_PropPresTitle()
    IL_01e3:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_01e8:  ret
  } // end of method Comp::SetWindowTitle

  .method private hidebysig instance void 
          SetAxisTitles() cil managed
  {
    // Code size       348 (0x15c)
    .maxstack  4
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0006:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_000b:  stloc.0
    IL_000c:  ldloc.0
    IL_000d:  ldc.i4.1
    IL_000e:  sub
    IL_000f:  switch     ( 
                          IL_0049,
                          IL_0090,
                          IL_0049,
                          IL_0090,
                          IL_015b,
                          IL_0049,
                          IL_0090,
                          IL_00d7,
                          IL_00f9)
    IL_0038:  ldloc.0
    IL_0039:  ldc.i4.s   29
    IL_003b:  beq        IL_011a

    IL_0040:  ldloc.0
    IL_0041:  ldc.i4.s   30
    IL_0043:  beq        IL_013b

    IL_0048:  ret

    IL_0049:  ldarg.0
    IL_004a:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_004f:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0054:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0059:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Temperature()
    IL_005e:  ldarg.0
    IL_005f:  ldfld      string WpfPLData.Comp::TempUnit
    IL_0064:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0069:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_006e:  ldarg.0
    IL_006f:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0074:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0079:  ldarg.0
    IL_007a:  ldfld      string WpfPLData.Comp::MoleType
    IL_007f:  ldarg.0
    IL_0080:  ldfld      string WpfPLData.Comp::_componentId
    IL_0085:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_008a:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_008f:  ret

    IL_0090:  ldarg.0
    IL_0091:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0096:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_009b:  ldsfld     object [mscorlib]System.Type::Missing
    IL_00a0:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Pressure()
    IL_00a5:  ldarg.0
    IL_00a6:  ldfld      string WpfPLData.Comp::PresUnit
    IL_00ab:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_00b0:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_00b5:  ldarg.0
    IL_00b6:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_00bb:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_00c0:  ldarg.0
    IL_00c1:  ldfld      string WpfPLData.Comp::MoleType
    IL_00c6:  ldarg.0
    IL_00c7:  ldfld      string WpfPLData.Comp::_componentId
    IL_00cc:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_00d1:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_00d6:  ret

    IL_00d7:  ldarg.0
    IL_00d8:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_00dd:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_00e2:  ldarg.0
    IL_00e3:  ldfld      string WpfPLData.Comp::MoleType
    IL_00e8:  ldarg.0
    IL_00e9:  ldfld      string WpfPLData.Comp::_componentId
    IL_00ee:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_00f3:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_00f8:  ret

    IL_00f9:  ldarg.0
    IL_00fa:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_00ff:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0104:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Temperature()
    IL_0109:  ldarg.0
    IL_010a:  ldfld      string WpfPLData.Comp::TempUnit
    IL_010f:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0114:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_0119:  ret

    IL_011a:  ldarg.0
    IL_011b:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0120:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0125:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Temperature()
    IL_012a:  ldarg.0
    IL_012b:  ldfld      string WpfPLData.Comp::TempUnit
    IL_0130:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0135:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_013a:  ret

    IL_013b:  ldarg.0
    IL_013c:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Comp::_wizardPlot
    IL_0141:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0146:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Pressure()
    IL_014b:  ldarg.0
    IL_014c:  ldfld      string WpfPLData.Comp::PresUnit
    IL_0151:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0156:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_015b:  ret
  } // end of method Comp::SetAxisTitles

  .method private hidebysig instance string 
          PressureAmtUnits() cil managed
  {
    // Code size       527 (0x20f)
    .maxstack  13
    .locals init (class AspenTech.AspenPlus.Happ.IHNode V_0,
             string V_1,
             string V_2,
             bool V_3)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Comp::_context
    IL_0006:  ldstr      "Input/PRES"
    IL_000b:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_0010:  stloc.0
    IL_0011:  ldsfld     string [mscorlib]System.String::Empty
    IL_0016:  stloc.1
    IL_0017:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> WpfPLData.Comp/'<>o__90'::'<>p__2'
    IL_001c:  brtrue.s   IL_004a

    IL_001e:  ldc.i4.0
    IL_001f:  ldc.i4.s   83
    IL_0021:  ldtoken    WpfPLData.Comp
    IL_0026:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_002b:  ldc.i4.1
    IL_002c:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_0031:  dup
    IL_0032:  ldc.i4.0
    IL_0033:  ldc.i4.0
    IL_0034:  ldnull
    IL_0035:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_003a:  stelem.ref
    IL_003b:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::UnaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0040:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0045:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> WpfPLData.Comp/'<>o__90'::'<>p__2'
    IL_004a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> WpfPLData.Comp/'<>o__90'::'<>p__2'
    IL_004f:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>>::Target
    IL_0054:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>> WpfPLData.Comp/'<>o__90'::'<>p__2'
    IL_0059:  ldloc.0
    IL_005a:  ldnull
    IL_005b:  cgt.un
    IL_005d:  stloc.3
    IL_005e:  ldloc.3
    IL_005f:  brfalse    IL_0114

    IL_0064:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__1'
    IL_0069:  brtrue.s   IL_00a0

    IL_006b:  ldc.i4.8
    IL_006c:  ldc.i4.2
    IL_006d:  ldtoken    WpfPLData.Comp
    IL_0072:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0077:  ldc.i4.2
    IL_0078:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_007d:  dup
    IL_007e:  ldc.i4.0
    IL_007f:  ldc.i4.1
    IL_0080:  ldnull
    IL_0081:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0086:  stelem.ref
    IL_0087:  dup
    IL_0088:  ldc.i4.1
    IL_0089:  ldc.i4.0
    IL_008a:  ldnull
    IL_008b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0090:  stelem.ref
    IL_0091:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_0096:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_009b:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__1'
    IL_00a0:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__1'
    IL_00a5:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>>::Target
    IL_00aa:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__1'
    IL_00af:  ldloc.3
    IL_00b0:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__0'
    IL_00b5:  brtrue.s   IL_00ed

    IL_00b7:  ldc.i4.0
    IL_00b8:  ldc.i4.s   35
    IL_00ba:  ldtoken    WpfPLData.Comp
    IL_00bf:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_00c4:  ldc.i4.2
    IL_00c5:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_00ca:  dup
    IL_00cb:  ldc.i4.0
    IL_00cc:  ldc.i4.0
    IL_00cd:  ldnull
    IL_00ce:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_00d3:  stelem.ref
    IL_00d4:  dup
    IL_00d5:  ldc.i4.1
    IL_00d6:  ldc.i4.2
    IL_00d7:  ldnull
    IL_00d8:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_00dd:  stelem.ref
    IL_00de:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                    valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                    class [mscorlib]System.Type,
                                                                                                                                                                    class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_00e3:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_00e8:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__0'
    IL_00ed:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__0'
    IL_00f2:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>>::Target
    IL_00f7:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__0'
    IL_00fc:  ldloc.0
    IL_00fd:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0102:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_0107:  ldnull
    IL_0108:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object,object>::Invoke(!0,
                                                                                                                                                             !1,
                                                                                                                                                             !2)
    IL_010d:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,bool,object,object>::Invoke(!0,
                                                                                                                                                           !1,
                                                                                                                                                           !2)
    IL_0112:  br.s       IL_011a

    IL_0114:  ldloc.3
    IL_0115:  box        [mscorlib]System.Boolean
    IL_011a:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,bool>::Invoke(!0,
                                                                                                                                                    !1)
    IL_011f:  brfalse    IL_01ba

    IL_0124:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__90'::'<>p__4'
    IL_0129:  brtrue.s   IL_014f

    IL_012b:  ldc.i4.0
    IL_012c:  ldtoken    [mscorlib]System.String
    IL_0131:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0136:  ldtoken    WpfPLData.Comp
    IL_013b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0140:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_0145:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_014a:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__90'::'<>p__4'
    IL_014f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__90'::'<>p__4'
    IL_0154:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_0159:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Comp/'<>o__90'::'<>p__4'
    IL_015e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__3'
    IL_0163:  brtrue.s   IL_0195

    IL_0165:  ldc.i4.0
    IL_0166:  ldstr      "ToString"
    IL_016b:  ldnull
    IL_016c:  ldtoken    WpfPLData.Comp
    IL_0171:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0176:  ldc.i4.1
    IL_0177:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
    IL_017c:  dup
    IL_017d:  ldc.i4.0
    IL_017e:  ldc.i4.0
    IL_017f:  ldnull
    IL_0180:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                               string)
    IL_0185:  stelem.ref
    IL_0186:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                 string,
                                                                                                                                                                 class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                 class [mscorlib]System.Type,
                                                                                                                                                                 class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
    IL_018b:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0190:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__3'
    IL_0195:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__3'
    IL_019a:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>>::Target
    IL_019f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>> WpfPLData.Comp/'<>o__90'::'<>p__3'
    IL_01a4:  ldloc.0
    IL_01a5:  ldsfld     object [mscorlib]System.Type::Missing
    IL_01aa:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_01af:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,object>::Invoke(!0,
                                                                                                                                                      !1)
    IL_01b4:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_01b9:  stloc.1
    IL_01ba:  ldsfld     string [mscorlib]System.String::Empty
    IL_01bf:  stloc.2
    IL_01c0:  ldloc.0
    IL_01c1:  brfalse.s  IL_01e4

    .try
    {
      IL_01c3:  ldloc.0
      IL_01c4:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHNode::get_Dimension()
      IL_01c9:  brfalse.s  IL_01df

      IL_01cb:  ldloc.0
      IL_01cc:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_01d1:  ldc.i4.0
      IL_01d2:  ldc.i4.s   -7
      IL_01d4:  ldsfld     object [mscorlib]System.Type::Missing
      IL_01d9:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                         int32,
                                                                                         object)
      IL_01de:  stloc.2
      IL_01df:  leave.s    IL_01e4

    }  // end .try
    catch [mscorlib]System.Runtime.InteropServices.COMException 
    {
      IL_01e1:  pop
      IL_01e2:  leave.s    IL_01e4

    }  // end handler
    IL_01e4:  ldloc.1
    IL_01e5:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_01ea:  brtrue.s   IL_0203

    IL_01ec:  ldloc.2
    IL_01ed:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_01f2:  brtrue.s   IL_020d

    IL_01f4:  ldloc.1
    IL_01f5:  ldstr      " "
    IL_01fa:  ldloc.2
    IL_01fb:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0200:  stloc.1
    IL_0201:  br.s       IL_020d

    IL_0203:  ldloc.2
    IL_0204:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0209:  brtrue.s   IL_020d

    IL_020b:  ldloc.2
    IL_020c:  stloc.1
    IL_020d:  ldloc.1
    IL_020e:  ret
  } // end of method Comp::PressureAmtUnits

  .method public hidebysig instance class [mscorlib]System.Collections.Generic.List`1<int32> 
          XPropPtrArray(string PropID) cil managed
  {
    // Code size       57 (0x39)
    .maxstack  2
    .locals init (class [mscorlib]System.Collections.Generic.List`1<int32> V_0,
             int32 V_1)
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<int32>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldc.i4.0
    IL_0007:  stloc.1
    IL_0008:  br.s       IL_0029

    IL_000a:  ldarg.0
    IL_000b:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_0010:  ldloc.1
    IL_0011:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_0016:  ldarg.1
    IL_0017:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_001c:  brfalse.s  IL_0025

    IL_001e:  ldloc.0
    IL_001f:  ldloc.1
    IL_0020:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<int32>::Add(!0)
    IL_0025:  ldloc.1
    IL_0026:  ldc.i4.1
    IL_0027:  add
    IL_0028:  stloc.1
    IL_0029:  ldloc.1
    IL_002a:  ldarg.0
    IL_002b:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::XPropName
    IL_0030:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_0035:  blt.s      IL_000a

    IL_0037:  ldloc.0
    IL_0038:  ret
  } // end of method Comp::XPropPtrArray

  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TooltipContentForRibbonItem()
  {
    .get instance string WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipContentForRibbonItem()
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TooltipContentForRibbonItem
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TooltipHeaderForRibbonItem()
  {
    .get instance string WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipHeaderForRibbonItem()
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TooltipHeaderForRibbonItem
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TagID()
  {
    .get instance string WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TagID()
    .set instance void WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_TagID(string)
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TagID
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Name()
  {
    .get instance string WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_Name()
    .set instance void WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_Name(string)
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Name
  .property instance callconv(8) object AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.WizardPlot()
  {
    .get instance object WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_WizardPlot()
    .set instance void WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_WizardPlot(object)
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.WizardPlot
  .property instance callconv(8) object AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.CxsNode()
  {
    .get instance object WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_CxsNode()
    .set instance void WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_CxsNode(object)
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.CxsNode
  .property instance callconv(8) class [System.Drawing]System.Drawing.Image
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ImageIcon()
  {
    .get instance class [System.Drawing]System.Drawing.Image WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_ImageIcon()
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ImageIcon
  .property instance callconv(8) bool AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HasInputDialog()
  {
    .get instance bool WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HasInputDialog()
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HasInputDialog
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpFile()
  {
    .get instance string WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpFile()
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpFile
  .property instance callconv(8) int64 AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpID()
  {
    .get instance int64 WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpID()
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpID
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.List`1<string>
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedDataFields()
  {
    .get instance class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedDataFields()
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedDataFields
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.List`1<string>
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedStyleFields()
  {
    .get instance class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedStyleFields()
  } // end of property Comp::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedStyleFields
  .property instance callconv(8) bool CheckDataOnly()
  {
    .get instance bool WpfPLData.Comp::get_CheckDataOnly()
    .set instance void WpfPLData.Comp::set_CheckDataOnly(bool)
  } // end of property Comp::CheckDataOnly
} // end of class WpfPLData.Comp

.class public auto ansi beforefieldinit WpfPLData.RibbonPlotWizardMgr
       extends [mscorlib]System.Object
       implements [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 1D 57 70 66 50 4C 44 61 74 61 2E 52 69 62   // ...WpfPLData.Rib
                                                                                                    62 6F 6E 50 6C 6F 74 57 69 7A 61 72 64 4D 67 72   // bonPlotWizardMgr
                                                                                                    00 00 ) 
  .field private static string[] supportedTypes
  .field private class AspenTech.AspenPlus.Happ.IHNode _hnode
  .field private class AspenTech.AspenPlus.Happ.IHWizardPlot _wizardPlot
  .field private static class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType> _lspwrTypes
  .field private class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser _pwrParser
  .field private class [mscorlib]System.Reflection.Assembly _asm
  .field private class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> _dicTagIdToPlotType
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       24 (0x18)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  newobj     instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser::.ctor()
    IL_0006:  stfld      class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser WpfPLData.RibbonPlotWizardMgr::_pwrParser
    IL_000b:  ldarg.0
    IL_000c:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0011:  ldarg.0
    IL_0012:  call       instance void WpfPLData.RibbonPlotWizardMgr::Initialize()
    IL_0017:  ret
  } // end of method RibbonPlotWizardMgr::.ctor

  .method private hidebysig newslot virtual final 
          instance int64  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr.SupportedPlotTypes(class [mscorlib]System.Collections.Generic.List`1<string>& lsTagIds) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr::SupportedPlotTypes
    // Code size       146 (0x92)
    .maxstack  4
    .locals init (int32 V_0,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType V_1,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_2,
             class AspenTech.AspenPlus.Happ.IHWizardPlot V_3)
    IL_0000:  ldarg.1
    IL_0001:  ldind.ref
    IL_0002:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Clear()
    IL_0007:  ldc.i4.0
    IL_0008:  stloc.0
    IL_0009:  br.s       IL_0079

    IL_000b:  ldsfld     class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType> WpfPLData.RibbonPlotWizardMgr::_lspwrTypes
    IL_0010:  ldloc.0
    IL_0011:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType>::get_Item(int32)
    IL_0016:  stloc.1
    IL_0017:  ldnull
    IL_0018:  stloc.2
    IL_0019:  ldstr      "9E14C11F-6706-4067-8112-35CE9468F3A5"
    IL_001e:  newobj     instance void [mscorlib]System.Guid::.ctor(string)
    IL_0023:  call       class [mscorlib]System.Type [mscorlib]System.Runtime.InteropServices.Marshal::GetTypeFromCLSID(valuetype [mscorlib]System.Guid)
    IL_0028:  call       object [mscorlib]System.Activator::CreateInstance(class [mscorlib]System.Type)
    IL_002d:  castclass  AspenTech.AspenPlus.Happ.CHWizardPlot
    IL_0032:  stloc.3
    IL_0033:  ldarg.0
    IL_0034:  ldfld      class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser WpfPLData.RibbonPlotWizardMgr::_pwrParser
    IL_0039:  ldloc.1
    IL_003a:  ldarg.0
    IL_003b:  ldflda     class AspenTech.AspenPlus.Happ.IHNode WpfPLData.RibbonPlotWizardMgr::_hnode
    IL_0040:  ldloca.s   V_3
    IL_0042:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser::FillDefaultPlotVal(class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType,
                                                                                                                                            class AspenTech.AspenPlus.Happ.IHNode&,
                                                                                                                                            class AspenTech.AspenPlus.Happ.IHWizardPlot&)
    IL_0047:  ldarg.0
    IL_0048:  ldloc.1
    IL_0049:  callvirt   instance string [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType::get_TagId()
    IL_004e:  ldloca.s   V_2
    IL_0050:  ldloca.s   V_3
    IL_0052:  call       instance bool WpfPLData.RibbonPlotWizardMgr::DoesPlotTypeHaveData(string,
                                                                                           class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType&,
                                                                                           class AspenTech.AspenPlus.Happ.IHWizardPlot&)
    IL_0057:  brfalse.s  IL_0075

    IL_0059:  ldarg.1
    IL_005a:  ldind.ref
    IL_005b:  ldloc.1
    IL_005c:  callvirt   instance string [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType::get_TagId()
    IL_0061:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<string>::Contains(!0)
    IL_0066:  brtrue.s   IL_0075

    IL_0068:  ldarg.1
    IL_0069:  ldind.ref
    IL_006a:  ldloc.1
    IL_006b:  callvirt   instance string [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType::get_TagId()
    IL_0070:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0075:  ldloc.0
    IL_0076:  ldc.i4.1
    IL_0077:  add
    IL_0078:  stloc.0
    IL_0079:  ldloc.0
    IL_007a:  ldsfld     class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType> WpfPLData.RibbonPlotWizardMgr::_lspwrTypes
    IL_007f:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType>::get_Count()
    IL_0084:  blt.s      IL_000b

    IL_0086:  ldsfld     class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType> WpfPLData.RibbonPlotWizardMgr::_lspwrTypes
    IL_008b:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType>::get_Count()
    IL_0090:  conv.i8
    IL_0091:  ret
  } // end of method RibbonPlotWizardMgr::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr.SupportedPlotTypes

  .method private hidebysig newslot virtual final 
          instance int64  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr.GetPlotType(string sTagId,
                                                                                              class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType& plwType) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr::GetPlotType
    // Code size       84 (0x54)
    .maxstack  4
    .locals init (class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance bool class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::ContainsKey(!0)
    IL_000c:  brfalse.s  IL_0051

    IL_000e:  ldarg.2
    IL_000f:  ldarg.0
    IL_0010:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_0015:  ldarg.1
    IL_0016:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::get_Item(!0)
    IL_001b:  stind.ref
    IL_001c:  ldarg.2
    IL_001d:  ldind.ref
    IL_001e:  brtrue.s   IL_0023

    IL_0020:  ldc.i4.0
    IL_0021:  conv.i8
    IL_0022:  ret

    IL_0023:  ldnull
    IL_0024:  stloc.0
    IL_0025:  ldarg.0
    IL_0026:  ldfld      class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser WpfPLData.RibbonPlotWizardMgr::_pwrParser
    IL_002b:  ldarg.1
    IL_002c:  ldsflda    class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType> WpfPLData.RibbonPlotWizardMgr::_lspwrTypes
    IL_0031:  ldloca.s   V_0
    IL_0033:  callvirt   instance bool [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser::FindPlotType(string,
                                                                                                                                      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType>&,
                                                                                                                                      class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType&)
    IL_0038:  pop
    IL_0039:  ldarg.0
    IL_003a:  ldfld      class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser WpfPLData.RibbonPlotWizardMgr::_pwrParser
    IL_003f:  ldloc.0
    IL_0040:  ldarg.0
    IL_0041:  ldflda     class AspenTech.AspenPlus.Happ.IHNode WpfPLData.RibbonPlotWizardMgr::_hnode
    IL_0046:  ldarg.0
    IL_0047:  ldflda     class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.RibbonPlotWizardMgr::_wizardPlot
    IL_004c:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser::FillDefaultPlotVal(class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType,
                                                                                                                                            class AspenTech.AspenPlus.Happ.IHNode&,
                                                                                                                                            class AspenTech.AspenPlus.Happ.IHWizardPlot&)
    IL_0051:  ldc.i4.0
    IL_0052:  conv.i8
    IL_0053:  ret
  } // end of method RibbonPlotWizardMgr::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr.GetPlotType

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr.SetContext(object oNode,
                                                                                            object& oWizard) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr::SetContext
    // Code size       26 (0x1a)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  isinst     AspenTech.AspenPlus.Happ.IHNode
    IL_0007:  stfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.RibbonPlotWizardMgr::_hnode
    IL_000c:  ldarg.0
    IL_000d:  ldarg.2
    IL_000e:  ldind.ref
    IL_000f:  isinst     AspenTech.AspenPlus.Happ.IHWizardPlot
    IL_0014:  stfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.RibbonPlotWizardMgr::_wizardPlot
    IL_0019:  ret
  } // end of method RibbonPlotWizardMgr::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr.SetContext

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr.ShowInputDialog(string sPlotName) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr::ShowInputDialog
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method RibbonPlotWizardMgr::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardMgr.ShowInputDialog

  .method private hidebysig instance void 
          InitializeWizardPlot() cil managed
  {
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method RibbonPlotWizardMgr::InitializeWizardPlot

  .method private hidebysig instance void 
          Initialize() cil managed
  {
    // Code size       679 (0x2a7)
    .maxstack  3
    .locals init (class [mscorlib]System.IO.StreamReader V_0,
             string[] V_1,
             int32 V_2,
             string V_3,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_4,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_5,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_6,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_7,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_8,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_9,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_10,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_11,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_12,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_13,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_14,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_15,
             class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType V_16)
    IL_0000:  ldarg.0
    IL_0001:  call       class [mscorlib]System.Reflection.Assembly [mscorlib]System.Reflection.Assembly::GetExecutingAssembly()
    IL_0006:  stfld      class [mscorlib]System.Reflection.Assembly WpfPLData.RibbonPlotWizardMgr::_asm
    IL_000b:  call       class [mscorlib]System.Reflection.Assembly [mscorlib]System.Reflection.Assembly::GetExecutingAssembly()
    IL_0010:  ldstr      "WpfPLData.Text.Datapwr.txt"
    IL_0015:  callvirt   instance class [mscorlib]System.IO.Stream [mscorlib]System.Reflection.Assembly::GetManifestResourceStream(string)
    IL_001a:  newobj     instance void [mscorlib]System.IO.StreamReader::.ctor(class [mscorlib]System.IO.Stream)
    IL_001f:  stloc.0
    IL_0020:  ldsfld     class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType> WpfPLData.RibbonPlotWizardMgr::_lspwrTypes
    IL_0025:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType>::Clear()
    IL_002a:  ldarg.0
    IL_002b:  ldfld      class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser WpfPLData.RibbonPlotWizardMgr::_pwrParser
    IL_0030:  ldloc.0
    IL_0031:  ldsflda    class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType> WpfPLData.RibbonPlotWizardMgr::_lspwrTypes
    IL_0036:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRParser::ParsePwrFile(class [mscorlib]System.IO.StreamReader,
                                                                                                                                      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType>&)
    IL_003b:  ldarg.0
    IL_003c:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::.ctor()
    IL_0041:  stfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_0046:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_004b:  stloc.1
    IL_004c:  ldc.i4.0
    IL_004d:  stloc.2
    IL_004e:  br         IL_029d

    IL_0053:  ldloc.1
    IL_0054:  ldloc.2
    IL_0055:  ldelem.ref
    IL_0056:  stloc.3
    IL_0057:  ldloc.3
    IL_0058:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_005d:  ldc.i4.0
    IL_005e:  ldelem.ref
    IL_005f:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0064:  brfalse.s  IL_0085

    IL_0066:  ldstr      "T-xy"
    IL_006b:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_0070:  stloc.s    V_4
    IL_0072:  ldarg.0
    IL_0073:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_0078:  ldloc.3
    IL_0079:  ldloc.s    V_4
    IL_007b:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_0080:  br         IL_0299

    IL_0085:  ldloc.3
    IL_0086:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_008b:  ldc.i4.1
    IL_008c:  ldelem.ref
    IL_008d:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0092:  brfalse.s  IL_00b3

    IL_0094:  ldstr      "P-xy"
    IL_0099:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_009e:  stloc.s    V_5
    IL_00a0:  ldarg.0
    IL_00a1:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_00a6:  ldloc.3
    IL_00a7:  ldloc.s    V_5
    IL_00a9:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_00ae:  br         IL_0299

    IL_00b3:  ldloc.3
    IL_00b4:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_00b9:  ldc.i4.2
    IL_00ba:  ldelem.ref
    IL_00bb:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00c0:  brfalse.s  IL_00e1

    IL_00c2:  ldstr      "T-x"
    IL_00c7:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_00cc:  stloc.s    V_6
    IL_00ce:  ldarg.0
    IL_00cf:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_00d4:  ldloc.3
    IL_00d5:  ldloc.s    V_6
    IL_00d7:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_00dc:  br         IL_0299

    IL_00e1:  ldloc.3
    IL_00e2:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_00e7:  ldc.i4.3
    IL_00e8:  ldelem.ref
    IL_00e9:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00ee:  brfalse.s  IL_010f

    IL_00f0:  ldstr      "P-x"
    IL_00f5:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_00fa:  stloc.s    V_7
    IL_00fc:  ldarg.0
    IL_00fd:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_0102:  ldloc.3
    IL_0103:  ldloc.s    V_7
    IL_0105:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_010a:  br         IL_0299

    IL_010f:  ldloc.3
    IL_0110:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_0115:  ldc.i4.4
    IL_0116:  ldelem.ref
    IL_0117:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_011c:  brfalse.s  IL_013d

    IL_011e:  ldstr      "y-x"
    IL_0123:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_0128:  stloc.s    V_8
    IL_012a:  ldarg.0
    IL_012b:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_0130:  ldloc.3
    IL_0131:  ldloc.s    V_8
    IL_0133:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_0138:  br         IL_0299

    IL_013d:  ldloc.3
    IL_013e:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_0143:  ldc.i4.5
    IL_0144:  ldelem.ref
    IL_0145:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_014a:  brfalse.s  IL_016b

    IL_014c:  ldstr      "T-xx"
    IL_0151:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_0156:  stloc.s    V_9
    IL_0158:  ldarg.0
    IL_0159:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_015e:  ldloc.3
    IL_015f:  ldloc.s    V_9
    IL_0161:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_0166:  br         IL_0299

    IL_016b:  ldloc.3
    IL_016c:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_0171:  ldc.i4.6
    IL_0172:  ldelem.ref
    IL_0173:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0178:  brfalse.s  IL_0199

    IL_017a:  ldstr      "P-xx"
    IL_017f:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_0184:  stloc.s    V_10
    IL_0186:  ldarg.0
    IL_0187:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_018c:  ldloc.3
    IL_018d:  ldloc.s    V_10
    IL_018f:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_0194:  br         IL_0299

    IL_0199:  ldloc.3
    IL_019a:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_019f:  ldc.i4.7
    IL_01a0:  ldelem.ref
    IL_01a1:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_01a6:  brfalse.s  IL_01c7

    IL_01a8:  ldstr      "Prop-x"
    IL_01ad:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_01b2:  stloc.s    V_11
    IL_01b4:  ldarg.0
    IL_01b5:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_01ba:  ldloc.3
    IL_01bb:  ldloc.s    V_11
    IL_01bd:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_01c2:  br         IL_0299

    IL_01c7:  ldloc.3
    IL_01c8:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_01cd:  ldc.i4.8
    IL_01ce:  ldelem.ref
    IL_01cf:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_01d4:  brfalse.s  IL_01f5

    IL_01d6:  ldstr      "Prop-T"
    IL_01db:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_01e0:  stloc.s    V_12
    IL_01e2:  ldarg.0
    IL_01e3:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_01e8:  ldloc.3
    IL_01e9:  ldloc.s    V_12
    IL_01eb:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_01f0:  br         IL_0299

    IL_01f5:  ldloc.3
    IL_01f6:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_01fb:  ldc.i4.s   9
    IL_01fd:  ldelem.ref
    IL_01fe:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0203:  brfalse.s  IL_021c

    IL_0205:  newobj     instance void WpfPLData.Triangle::.ctor()
    IL_020a:  stloc.s    V_13
    IL_020c:  ldarg.0
    IL_020d:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_0212:  ldloc.3
    IL_0213:  ldloc.s    V_13
    IL_0215:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_021a:  br.s       IL_0299

    IL_021c:  ldloc.3
    IL_021d:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_0222:  ldc.i4.s   10
    IL_0224:  ldelem.ref
    IL_0225:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_022a:  brfalse.s  IL_0248

    IL_022c:  ldstr      "Property-T"
    IL_0231:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_0236:  stloc.s    V_14
    IL_0238:  ldarg.0
    IL_0239:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_023e:  ldloc.3
    IL_023f:  ldloc.s    V_14
    IL_0241:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_0246:  br.s       IL_0299

    IL_0248:  ldloc.3
    IL_0249:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_024e:  ldc.i4.s   11
    IL_0250:  ldelem.ref
    IL_0251:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0256:  brfalse.s  IL_0274

    IL_0258:  ldstr      "Property-P"
    IL_025d:  newobj     instance void WpfPLData.Comp::.ctor(string)
    IL_0262:  stloc.s    V_15
    IL_0264:  ldarg.0
    IL_0265:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_026a:  ldloc.3
    IL_026b:  ldloc.s    V_15
    IL_026d:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_0272:  br.s       IL_0299

    IL_0274:  ldloc.3
    IL_0275:  ldsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_027a:  ldc.i4.s   12
    IL_027c:  ldelem.ref
    IL_027d:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0282:  brfalse.s  IL_0299

    IL_0284:  newobj     instance void WpfPLData.DataCurve::.ctor()
    IL_0289:  stloc.s    V_16
    IL_028b:  ldarg.0
    IL_028c:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_0291:  ldloc.3
    IL_0292:  ldloc.s    V_16
    IL_0294:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::Add(!0,
                                                                                                                                                                                                               !1)
    IL_0299:  ldloc.2
    IL_029a:  ldc.i4.1
    IL_029b:  add
    IL_029c:  stloc.2
    IL_029d:  ldloc.2
    IL_029e:  ldloc.1
    IL_029f:  ldlen
    IL_02a0:  conv.i4
    IL_02a1:  blt        IL_0053

    IL_02a6:  ret
  } // end of method RibbonPlotWizardMgr::Initialize

  .method private hidebysig instance bool 
          DoesPlotTypeHaveData(string sTagId,
                               class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType& iplotType,
                               class AspenTech.AspenPlus.Happ.IHWizardPlot& iWizardPlot) cil managed
  {
    // Code size       63 (0x3f)
    .maxstack  4
    .locals init (int32 V_0,
             object V_1)
    IL_0000:  ldc.i4.0
    IL_0001:  stloc.0
    IL_0002:  ldarg.0
    IL_0003:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_0008:  ldarg.1
    IL_0009:  callvirt   instance bool class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::ContainsKey(!0)
    IL_000e:  brfalse.s  IL_003d

    IL_0010:  ldarg.2
    IL_0011:  ldarg.0
    IL_0012:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType> WpfPLData.RibbonPlotWizardMgr::_dicTagIdToPlotType
    IL_0017:  ldarg.1
    IL_0018:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType>::get_Item(!0)
    IL_001d:  stind.ref
    IL_001e:  ldarg.2
    IL_001f:  ldind.ref
    IL_0020:  brtrue.s   IL_0024

    IL_0022:  ldc.i4.0
    IL_0023:  ret

    IL_0024:  ldarg.3
    IL_0025:  ldind.ref
    IL_0026:  stloc.1
    IL_0027:  ldarg.2
    IL_0028:  ldind.ref
    IL_0029:  ldarg.0
    IL_002a:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.RibbonPlotWizardMgr::_hnode
    IL_002f:  ldloca.s   V_1
    IL_0031:  ldloca.s   V_0
    IL_0033:  callvirt   instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::Context(object,
                                                                                                                                             object&,
                                                                                                                                             int32&)
    IL_0038:  ldloc.0
    IL_0039:  brtrue.s   IL_003d

    IL_003b:  ldc.i4.1
    IL_003c:  ret

    IL_003d:  ldc.i4.0
    IL_003e:  ret
  } // end of method RibbonPlotWizardMgr::DoesPlotTypeHaveData

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       131 (0x83)
    .maxstack  4
    IL_0000:  ldc.i4.s   13
    IL_0002:  newarr     [mscorlib]System.String
    IL_0007:  dup
    IL_0008:  ldc.i4.0
    IL_0009:  ldstr      "T-xy"
    IL_000e:  stelem.ref
    IL_000f:  dup
    IL_0010:  ldc.i4.1
    IL_0011:  ldstr      "P-xy"
    IL_0016:  stelem.ref
    IL_0017:  dup
    IL_0018:  ldc.i4.2
    IL_0019:  ldstr      "T-x"
    IL_001e:  stelem.ref
    IL_001f:  dup
    IL_0020:  ldc.i4.3
    IL_0021:  ldstr      "P-x"
    IL_0026:  stelem.ref
    IL_0027:  dup
    IL_0028:  ldc.i4.4
    IL_0029:  ldstr      "y-x"
    IL_002e:  stelem.ref
    IL_002f:  dup
    IL_0030:  ldc.i4.5
    IL_0031:  ldstr      "T-xx"
    IL_0036:  stelem.ref
    IL_0037:  dup
    IL_0038:  ldc.i4.6
    IL_0039:  ldstr      "P-xx"
    IL_003e:  stelem.ref
    IL_003f:  dup
    IL_0040:  ldc.i4.7
    IL_0041:  ldstr      "Prop-x"
    IL_0046:  stelem.ref
    IL_0047:  dup
    IL_0048:  ldc.i4.8
    IL_0049:  ldstr      "Prop-T"
    IL_004e:  stelem.ref
    IL_004f:  dup
    IL_0050:  ldc.i4.s   9
    IL_0052:  ldstr      "Triangular"
    IL_0057:  stelem.ref
    IL_0058:  dup
    IL_0059:  ldc.i4.s   10
    IL_005b:  ldstr      "Property-T"
    IL_0060:  stelem.ref
    IL_0061:  dup
    IL_0062:  ldc.i4.s   11
    IL_0064:  ldstr      "Property-P"
    IL_0069:  stelem.ref
    IL_006a:  dup
    IL_006b:  ldc.i4.s   12
    IL_006d:  ldstr      "Data Curve"
    IL_0072:  stelem.ref
    IL_0073:  stsfld     string[] WpfPLData.RibbonPlotWizardMgr::supportedTypes
    IL_0078:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType>::.ctor()
    IL_007d:  stsfld     class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.PWRPlotType> WpfPLData.RibbonPlotWizardMgr::_lspwrTypes
    IL_0082:  ret
  } // end of method RibbonPlotWizardMgr::.cctor

} // end of class WpfPLData.RibbonPlotWizardMgr

.class public auto ansi beforefieldinit WpfPLData.DataCurve
       extends [PresentationFramework]System.Windows.Controls.UserControl
       implements [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType,
                  [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IPlotWizardTemplate,
                  [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 13 57 70 66 50 4C 44 61 74 61 2E 44 61 74   // ...WpfPLData.Dat
                                                                                                    61 43 75 72 76 65 00 00 )                         // aCurve..
  .class abstract auto ansi sealed nested private beforefieldinit '<>o__61'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__0'
  } // end of class '<>o__61'

  .field private class AspenTech.AspenPlus.Happ.IHNode _context
  .field private class AspenTech.AspenPlus.Happ.IHWizardPlot _wizardPlot
  .field private class WpfPLData.PLDataHelper _help
  .field private string _uniqueId
  .field private string _plotName
  .field private object _nodeCxs
  .field private class [System.Drawing]System.Drawing.Image _imgBitmap
  .field private bool _bHasInputDialog
  .field private string _currentConfigValue
  .field private string[] VarNames
  .field private int32[] DataNum
  .field public static class [PresentationCore]System.Windows.Input.RoutedCommand OKCommand
  .field public static class [PresentationCore]System.Windows.Input.RoutedCommand CancelCommand
  .field public static class [PresentationCore]System.Windows.Input.RoutedCommand ClearCommand
  .field private bool _bCheckDataOnly
  .field assembly class [PresentationFramework]System.Windows.Controls.GroupBox groupBoxOption
  .field assembly class [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesLabel lblXAxis
  .field assembly class [PresentationFramework]System.Windows.Controls.ComboBox ComboBoxXAxis
  .field assembly class [PresentationFramework]System.Windows.Controls.CheckBox chkParaVar
  .field assembly class [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesLabel lblParaVar
  .field assembly class [PresentationFramework]System.Windows.Controls.ComboBox ComboBoxParaVar
  .field assembly class [WpfPLControls]WpfPLControls.CurvesSelectorControl CurveList
  .field assembly class [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesCmdButton btnClear
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       223 (0xdf)
    .maxstack  4
    .locals init (class [PresentationCore]System.Windows.Input.CommandBinding V_0,
             class [PresentationCore]System.Windows.Input.CommandBinding V_1,
             class [PresentationCore]System.Windows.Input.CommandBinding V_2,
             class [mscorlib]System.IO.Stream V_3)
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "PlotWiz.hlp"
    IL_0006:  ldc.i4.s   108
    IL_0008:  conv.i8
    IL_0009:  newobj     instance void WpfPLData.PLDataHelper::.ctor(string,
                                                                     int64)
    IL_000e:  stfld      class WpfPLData.PLDataHelper WpfPLData.DataCurve::_help
    IL_0013:  ldarg.0
    IL_0014:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLSensitivityResources::get_DataSet_ID()
    IL_0019:  stfld      string WpfPLData.DataCurve::_uniqueId
    IL_001e:  ldarg.0
    IL_001f:  ldsfld     string [mscorlib]System.String::Empty
    IL_0024:  stfld      string WpfPLData.DataCurve::_currentConfigValue
    IL_0029:  ldarg.0
    IL_002a:  call       instance void [PresentationFramework]System.Windows.Controls.UserControl::.ctor()
    IL_002f:  ldarg.0
    IL_0030:  call       instance void WpfPLData.DataCurve::InitializeComponent()
    IL_0035:  ldarg.0
    IL_0036:  ldc.i4.1
    IL_0037:  stfld      bool WpfPLData.DataCurve::_bHasInputDialog
    IL_003c:  ldarg.0
    IL_003d:  ldfld      class [System.Drawing]System.Drawing.Image WpfPLData.DataCurve::_imgBitmap
    IL_0042:  brtrue.s   IL_0066

    IL_0044:  call       class [mscorlib]System.Reflection.Assembly [mscorlib]System.Reflection.Assembly::GetExecutingAssembly()
    IL_0049:  pop
    IL_004a:  call       class [mscorlib]System.Reflection.Assembly [mscorlib]System.Reflection.Assembly::GetExecutingAssembly()
    IL_004f:  ldstr      "WpfPLData.Images.DataPropt.ico"
    IL_0054:  callvirt   instance class [mscorlib]System.IO.Stream [mscorlib]System.Reflection.Assembly::GetManifestResourceStream(string)
    IL_0059:  stloc.3
    IL_005a:  ldarg.0
    IL_005b:  ldloc.3
    IL_005c:  call       class [System.Drawing]System.Drawing.Image [System.Drawing]System.Drawing.Image::FromStream(class [mscorlib]System.IO.Stream)
    IL_0061:  stfld      class [System.Drawing]System.Drawing.Image WpfPLData.DataCurve::_imgBitmap
    IL_0066:  ldsfld     class [PresentationCore]System.Windows.Input.RoutedCommand WpfPLData.DataCurve::OKCommand
    IL_006b:  ldarg.0
    IL_006c:  ldftn      instance void WpfPLData.DataCurve::ExecuteOKCommand(object,
                                                                             class [PresentationCore]System.Windows.Input.ExecutedRoutedEventArgs)
    IL_0072:  newobj     instance void [PresentationCore]System.Windows.Input.ExecutedRoutedEventHandler::.ctor(object,
                                                                                                                native int)
    IL_0077:  ldarg.0
    IL_0078:  ldftn      instance void WpfPLData.DataCurve::CanExecuteOKCommand(object,
                                                                                class [PresentationCore]System.Windows.Input.CanExecuteRoutedEventArgs)
    IL_007e:  newobj     instance void [PresentationCore]System.Windows.Input.CanExecuteRoutedEventHandler::.ctor(object,
                                                                                                                  native int)
    IL_0083:  newobj     instance void [PresentationCore]System.Windows.Input.CommandBinding::.ctor(class [System]System.Windows.Input.ICommand,
                                                                                                    class [PresentationCore]System.Windows.Input.ExecutedRoutedEventHandler,
                                                                                                    class [PresentationCore]System.Windows.Input.CanExecuteRoutedEventHandler)
    IL_0088:  stloc.0
    IL_0089:  ldsfld     class [PresentationCore]System.Windows.Input.RoutedCommand WpfPLData.DataCurve::CancelCommand
    IL_008e:  ldarg.0
    IL_008f:  ldftn      instance void WpfPLData.DataCurve::ExecuteCancelCommand(object,
                                                                                 class [PresentationCore]System.Windows.Input.ExecutedRoutedEventArgs)
    IL_0095:  newobj     instance void [PresentationCore]System.Windows.Input.ExecutedRoutedEventHandler::.ctor(object,
                                                                                                                native int)
    IL_009a:  newobj     instance void [PresentationCore]System.Windows.Input.CommandBinding::.ctor(class [System]System.Windows.Input.ICommand,
                                                                                                    class [PresentationCore]System.Windows.Input.ExecutedRoutedEventHandler)
    IL_009f:  stloc.1
    IL_00a0:  ldsfld     class [PresentationCore]System.Windows.Input.RoutedCommand WpfPLData.DataCurve::ClearCommand
    IL_00a5:  ldarg.0
    IL_00a6:  ldftn      instance void WpfPLData.DataCurve::ExecuteClearCommand(object,
                                                                                class [PresentationCore]System.Windows.Input.ExecutedRoutedEventArgs)
    IL_00ac:  newobj     instance void [PresentationCore]System.Windows.Input.ExecutedRoutedEventHandler::.ctor(object,
                                                                                                                native int)
    IL_00b1:  newobj     instance void [PresentationCore]System.Windows.Input.CommandBinding::.ctor(class [System]System.Windows.Input.ICommand,
                                                                                                    class [PresentationCore]System.Windows.Input.ExecutedRoutedEventHandler)
    IL_00b6:  stloc.2
    IL_00b7:  ldarg.0
    IL_00b8:  call       instance class [PresentationCore]System.Windows.Input.CommandBindingCollection [PresentationCore]System.Windows.UIElement::get_CommandBindings()
    IL_00bd:  ldloc.0
    IL_00be:  callvirt   instance int32 [PresentationCore]System.Windows.Input.CommandBindingCollection::Add(class [PresentationCore]System.Windows.Input.CommandBinding)
    IL_00c3:  pop
    IL_00c4:  ldarg.0
    IL_00c5:  call       instance class [PresentationCore]System.Windows.Input.CommandBindingCollection [PresentationCore]System.Windows.UIElement::get_CommandBindings()
    IL_00ca:  ldloc.1
    IL_00cb:  callvirt   instance int32 [PresentationCore]System.Windows.Input.CommandBindingCollection::Add(class [PresentationCore]System.Windows.Input.CommandBinding)
    IL_00d0:  pop
    IL_00d1:  ldarg.0
    IL_00d2:  call       instance class [PresentationCore]System.Windows.Input.CommandBindingCollection [PresentationCore]System.Windows.UIElement::get_CommandBindings()
    IL_00d7:  ldloc.2
    IL_00d8:  callvirt   instance int32 [PresentationCore]System.Windows.Input.CommandBindingCollection::Add(class [PresentationCore]System.Windows.Input.CommandBinding)
    IL_00dd:  pop
    IL_00de:  ret
  } // end of method DataCurve::.ctor

  .method public hidebysig newslot virtual final 
          instance void  SetCaption(string& caption) cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLSensitivityResources::get_DataSet_Window_Title()
    IL_0006:  stind.ref
    IL_0007:  ret
  } // end of method DataCurve::SetCaption

  .method public hidebysig newslot virtual final 
          instance void  SetDefaultHeight(float64& defaultHeight) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.r8     380
    IL_000a:  stind.r8
    IL_000b:  ret
  } // end of method DataCurve::SetDefaultHeight

  .method public hidebysig newslot virtual final 
          instance void  SetDefaultWidth(float64& defaultWidth) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.r8     450
    IL_000a:  stind.r8
    IL_000b:  ret
  } // end of method DataCurve::SetDefaultWidth

  .method public hidebysig newslot virtual final 
          instance void  SetMinHeight(float64& minHeight) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.r8     380
    IL_000a:  stind.r8
    IL_000b:  ret
  } // end of method DataCurve::SetMinHeight

  .method public hidebysig newslot virtual final 
          instance void  SetMinWidth(float64& minWidth) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.r8     450
    IL_000a:  stind.r8
    IL_000b:  ret
  } // end of method DataCurve::SetMinWidth

  .method public hidebysig newslot specialname virtual final 
          instance string  get_TooltipContentForRibbonItem() cil managed
  {
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLSensitivityResources::get_TooltipContentForRibbonItem_Sensitivity()
    IL_0005:  ret
  } // end of method DataCurve::get_TooltipContentForRibbonItem

  .method public hidebysig newslot specialname virtual final 
          instance string  get_TooltipHeaderForRibbonItem() cil managed
  {
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_DataCurve_Title()
    IL_0005:  ret
  } // end of method DataCurve::get_TooltipHeaderForRibbonItem

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TagID() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_TagID
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string WpfPLData.DataCurve::_uniqueId
    IL_0006:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TagID

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_TagID(string 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_TagID
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string WpfPLData.DataCurve::_uniqueId
    IL_0007:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_TagID

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_Name() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_Name
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string WpfPLData.DataCurve::_plotName
    IL_0006:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_Name

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_Name(string 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_Name
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string WpfPLData.DataCurve::_plotName
    IL_0007:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_Name

  .method private hidebysig newslot specialname virtual final 
          instance object  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_WizardPlot() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_WizardPlot
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_0006:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_WizardPlot

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_WizardPlot(object 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_WizardPlot
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  isinst     AspenTech.AspenPlus.Happ.IHWizardPlot
    IL_0007:  stfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_000c:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_WizardPlot

  .method private hidebysig newslot specialname virtual final 
          instance object  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_CxsNode() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_CxsNode
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object WpfPLData.DataCurve::_nodeCxs
    IL_0006:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_CxsNode

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_CxsNode(object 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_CxsNode
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      object WpfPLData.DataCurve::_nodeCxs
    IL_0007:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_CxsNode

  .method private hidebysig newslot specialname virtual final 
          instance class [System.Drawing]System.Drawing.Image 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_ImageIcon() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_ImageIcon
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System.Drawing]System.Drawing.Image WpfPLData.DataCurve::_imgBitmap
    IL_0006:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_ImageIcon

  .method private hidebysig newslot specialname virtual final 
          instance bool  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HasInputDialog() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_HasInputDialog
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool WpfPLData.DataCurve::_bHasInputDialog
    IL_0006:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HasInputDialog

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpFile() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_HelpFile
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class WpfPLData.PLDataHelper WpfPLData.DataCurve::_help
    IL_0006:  callvirt   instance string [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper::GetHelpFileName()
    IL_000b:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpFile

  .method private hidebysig newslot specialname virtual final 
          instance int64  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpID() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_HelpID
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class WpfPLData.PLDataHelper WpfPLData.DataCurve::_help
    IL_0006:  callvirt   instance int64 [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper::GetHelpID()
    IL_000b:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpID

  .method private hidebysig newslot specialname virtual final 
          instance class [mscorlib]System.Collections.Generic.List`1<string> 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedDataFields() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_SupportedDataFields
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0005:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedDataFields

  .method private hidebysig newslot specialname virtual final 
          instance class [mscorlib]System.Collections.Generic.List`1<string> 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedStyleFields() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_SupportedStyleFields
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0005:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedStyleFields

  .method private hidebysig newslot virtual final 
          instance class [mscorlib]System.Collections.Generic.List`1<string> 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.FieldDataOptionList(string sFieldName) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::FieldDataOptionList
    // Code size       2 (0x2)
    .maxstack  8
    IL_0000:  ldnull
    IL_0001:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.FieldDataOptionList

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldData(string sFieldName,
                                                                                               string& sCurrentVal) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetFieldData
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldData(string sFieldName,
                                                                                               string sValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::SetFieldData
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ShowInputDialog() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::ShowInputDialog
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ShowInputDialog

  .method private hidebysig newslot virtual final 
          instance valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.RibbonControlType 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldCtrlType(string sField) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetFieldCtrlType
    // Code size       2 (0x2)
    .maxstack  8
    IL_0000:  ldc.i4.0
    IL_0001:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldCtrlType

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldStyle(string sFieldName,
                                                                                                string& sCurrentVal) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetFieldStyle
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldStyle

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldStyle(string sFieldName,
                                                                                                string sValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::SetFieldStyle
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldStyle

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetConfigData(string& sConfigValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetConfigData
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldarg.0
    IL_0002:  ldfld      string WpfPLData.DataCurve::_currentConfigValue
    IL_0007:  stind.ref
    IL_0008:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetConfigData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetConfigData(string sValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::SetConfigData
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string WpfPLData.DataCurve::_currentConfigValue
    IL_0007:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetConfigData

  .method public hidebysig newslot specialname virtual final 
          instance bool  get_CheckDataOnly() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool WpfPLData.DataCurve::_bCheckDataOnly
    IL_0006:  ret
  } // end of method DataCurve::get_CheckDataOnly

  .method public hidebysig newslot specialname virtual final 
          instance void  set_CheckDataOnly(bool 'value') cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool WpfPLData.DataCurve::_bCheckDataOnly
    IL_0007:  ret
  } // end of method DataCurve::set_CheckDataOnly

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Context(object HNode,
                                                                                          object& HWizardPlot,
                                                                                          int32& ierror) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::Context
    // Code size       594 (0x252)
    .maxstack  5
    .locals init (string V_0,
             class AspenTech.AspenPlus.Happ.IHNode V_1,
             class [mscorlib]System.Collections.Generic.List`1<string> V_2,
             class [mscorlib]System.Collections.Generic.List`1<string> V_3,
             int32 V_4,
             int32 V_5,
             string V_6,
             string V_7,
             int32 V_8)
    IL_0000:  ldarg.2
    IL_0001:  ldind.ref
    IL_0002:  brfalse.s  IL_0007

    IL_0004:  ldarg.1
    IL_0005:  brtrue.s   IL_000b

    IL_0007:  ldarg.3
    IL_0008:  ldc.i4.1
    IL_0009:  stind.i4
    IL_000a:  ret

    IL_000b:  ldarg.0
    IL_000c:  ldarg.1
    IL_000d:  isinst     AspenTech.AspenPlus.Happ.IHNode
    IL_0012:  stfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.DataCurve::_context
    IL_0017:  ldarg.0
    IL_0018:  ldarg.2
    IL_0019:  ldind.ref
    IL_001a:  isinst     AspenTech.AspenPlus.Happ.IHWizardPlot
    IL_001f:  stfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_0024:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.DataCurve/'<>o__61'::'<>p__0'
    IL_0029:  brtrue.s   IL_004f

    IL_002b:  ldc.i4.0
    IL_002c:  ldtoken    [mscorlib]System.String
    IL_0031:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0036:  ldtoken    WpfPLData.DataCurve
    IL_003b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0040:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_0045:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_004a:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.DataCurve/'<>o__61'::'<>p__0'
    IL_004f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.DataCurve/'<>o__61'::'<>p__0'
    IL_0054:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_0059:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.DataCurve/'<>o__61'::'<>p__0'
    IL_005e:  ldarg.0
    IL_005f:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.DataCurve::_context
    IL_0064:  ldstr      "Input/STATESPEC"
    IL_0069:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_006e:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0073:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_0078:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_007d:  stloc.0
    IL_007e:  ldloc.0
    IL_007f:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0084:  brtrue.s   IL_0097

    IL_0086:  ldloc.0
    IL_0087:  ldstr      "GEN-"
    IL_008c:  callvirt   instance bool [mscorlib]System.String::Contains(string)
    IL_0091:  brfalse.s  IL_0097

    IL_0093:  ldarg.3
    IL_0094:  ldc.i4.1
    IL_0095:  stind.i4
    IL_0096:  ret

    IL_0097:  ldarg.0
    IL_0098:  ldc.i4.3
    IL_0099:  newarr     [mscorlib]System.String
    IL_009e:  dup
    IL_009f:  ldc.i4.0
    IL_00a0:  ldstr      "Input/CIDS"
    IL_00a5:  stelem.ref
    IL_00a6:  dup
    IL_00a7:  ldc.i4.1
    IL_00a8:  ldstr      "Input/USE"
    IL_00ad:  stelem.ref
    IL_00ae:  dup
    IL_00af:  ldc.i4.2
    IL_00b0:  ldstr      "Input/VALUE"
    IL_00b5:  stelem.ref
    IL_00b6:  stfld      string[] WpfPLData.DataCurve::VarNames
    IL_00bb:  ldarg.0
    IL_00bc:  ldarg.0
    IL_00bd:  ldfld      class WpfPLData.PLDataHelper WpfPLData.DataCurve::_help
    IL_00c2:  ldarg.0
    IL_00c3:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.DataCurve::_context
    IL_00c8:  ldarg.0
    IL_00c9:  ldfld      string[] WpfPLData.DataCurve::VarNames
    IL_00ce:  ldc.i4.1
    IL_00cf:  ldelem.ref
    IL_00d0:  callvirt   instance int32[] WpfPLData.PLDataHelper::GetDataElementsArray(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                       string)
    IL_00d5:  stfld      int32[] WpfPLData.DataCurve::DataNum
    IL_00da:  ldarg.0
    IL_00db:  ldfld      int32[] WpfPLData.DataCurve::DataNum
    IL_00e0:  ldlen
    IL_00e1:  brtrue.s   IL_00e7

    IL_00e3:  ldarg.3
    IL_00e4:  ldc.i4.1
    IL_00e5:  stind.i4
    IL_00e6:  ret

    IL_00e7:  ldarg.0
    IL_00e8:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.DataCurve::_context
    IL_00ed:  ldarg.0
    IL_00ee:  ldfld      string[] WpfPLData.DataCurve::VarNames
    IL_00f3:  ldc.i4.2
    IL_00f4:  ldelem.ref
    IL_00f5:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_00fa:  stloc.1
    IL_00fb:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0100:  stloc.2
    IL_0101:  ldloc.1
    IL_0102:  brfalse.s  IL_0161

    IL_0104:  ldloc.1
    IL_0105:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_010a:  ldc.i4.1
    IL_010b:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHNodeCol::get_RowCount(int32)
    IL_0110:  stloc.s    V_4
    IL_0112:  ldc.i4.0
    IL_0113:  stloc.s    V_5
    IL_0115:  br.s       IL_015b

    IL_0117:  ldloc.1
    IL_0118:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_011d:  ldc.i4.1
    IL_011e:  ldloc.s    V_5
    IL_0120:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0125:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_012a:  stloc.s    V_6
    IL_012c:  ldloc.1
    IL_012d:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0132:  ldc.i4.2
    IL_0133:  ldloc.s    V_5
    IL_0135:  ldsfld     object [mscorlib]System.Type::Missing
    IL_013a:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_013f:  stloc.s    V_7
    IL_0141:  ldloc.2
    IL_0142:  ldloc.s    V_6
    IL_0144:  ldstr      " "
    IL_0149:  ldloc.s    V_7
    IL_014b:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0150:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0155:  ldloc.s    V_5
    IL_0157:  ldc.i4.1
    IL_0158:  add
    IL_0159:  stloc.s    V_5
    IL_015b:  ldloc.s    V_5
    IL_015d:  ldloc.s    V_4
    IL_015f:  blt.s      IL_0117

    IL_0161:  ldarg.0
    IL_0162:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_0167:  callvirt   instance class [PresentationFramework]System.Windows.Controls.ItemCollection [PresentationFramework]System.Windows.Controls.ItemsControl::get_Items()
    IL_016c:  callvirt   instance void [PresentationFramework]System.Windows.Controls.ItemCollection::Clear()
    IL_0171:  ldarg.0
    IL_0172:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxParaVar
    IL_0177:  callvirt   instance class [PresentationFramework]System.Windows.Controls.ItemCollection [PresentationFramework]System.Windows.Controls.ItemsControl::get_Items()
    IL_017c:  callvirt   instance void [PresentationFramework]System.Windows.Controls.ItemCollection::Clear()
    IL_0181:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0186:  stloc.3
    IL_0187:  ldarg.0
    IL_0188:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_018d:  ldc.i4.0
    IL_018e:  callvirt   instance void [WpfPLControls]WpfPLControls.CurvesSelectorControl::set_IsCheckAll(bool)
    IL_0193:  ldc.i4.0
    IL_0194:  stloc.s    V_8
    IL_0196:  br.s       IL_01ef

    IL_0198:  ldarg.0
    IL_0199:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_019e:  callvirt   instance class [PresentationFramework]System.Windows.Controls.ItemCollection [PresentationFramework]System.Windows.Controls.ItemsControl::get_Items()
    IL_01a3:  ldloc.2
    IL_01a4:  ldloc.s    V_8
    IL_01a6:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_01ab:  callvirt   instance int32 [PresentationFramework]System.Windows.Controls.ItemCollection::Add(object)
    IL_01b0:  pop
    IL_01b1:  ldarg.0
    IL_01b2:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxParaVar
    IL_01b7:  callvirt   instance class [PresentationFramework]System.Windows.Controls.ItemCollection [PresentationFramework]System.Windows.Controls.ItemsControl::get_Items()
    IL_01bc:  ldloc.2
    IL_01bd:  ldloc.s    V_8
    IL_01bf:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_01c4:  callvirt   instance int32 [PresentationFramework]System.Windows.Controls.ItemCollection::Add(object)
    IL_01c9:  pop
    IL_01ca:  ldloc.3
    IL_01cb:  ldloc.2
    IL_01cc:  ldloc.s    V_8
    IL_01ce:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_01d3:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_01d8:  ldarg.0
    IL_01d9:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_01de:  ldloc.3
    IL_01df:  callvirt   instance !0[] class [mscorlib]System.Collections.Generic.List`1<string>::ToArray()
    IL_01e4:  callvirt   instance void [WpfPLControls]WpfPLControls.CurvesSelectorControl::SetCurves(string[])
    IL_01e9:  ldloc.s    V_8
    IL_01eb:  ldc.i4.1
    IL_01ec:  add
    IL_01ed:  stloc.s    V_8
    IL_01ef:  ldloc.s    V_8
    IL_01f1:  ldloc.2
    IL_01f2:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_01f7:  blt.s      IL_0198

    IL_01f9:  ldarg.0
    IL_01fa:  ldfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_01ff:  ldc.i4.0
    IL_0200:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_0205:  callvirt   instance void [PresentationFramework]System.Windows.Controls.Primitives.ToggleButton::set_IsChecked(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_020a:  ldarg.0
    IL_020b:  ldfld      string WpfPLData.DataCurve::_currentConfigValue
    IL_0210:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0215:  brfalse.s  IL_0238

    IL_0217:  ldarg.0
    IL_0218:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_021d:  ldarg.0
    IL_021e:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_0223:  callvirt   instance class [PresentationFramework]System.Windows.Controls.ItemCollection [PresentationFramework]System.Windows.Controls.ItemsControl::get_Items()
    IL_0228:  ldc.i4.0
    IL_0229:  callvirt   instance object [PresentationFramework]System.Windows.Controls.ItemCollection::get_Item(int32)
    IL_022e:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_0233:  callvirt   instance void [PresentationFramework]System.Windows.Controls.ComboBox::set_Text(string)
    IL_0238:  ldarg.0
    IL_0239:  ldfld      string WpfPLData.DataCurve::_currentConfigValue
    IL_023e:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0243:  brtrue.s   IL_0251

    IL_0245:  ldarg.0
    IL_0246:  ldarg.0
    IL_0247:  ldfld      string WpfPLData.DataCurve::_currentConfigValue
    IL_024c:  call       instance void WpfPLData.DataCurve::RestoreConfigValue(string)
    IL_0251:  ret
  } // end of method DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Context

  .method public hidebysig newslot virtual final 
          instance void  UpdateWizardData() cil managed
  {
    // Code size       804 (0x324)
    .maxstack  10
    .locals init (int32 V_0,
             class [mscorlib]System.Collections.Generic.List`1<string> V_1,
             int32 V_2,
             class AspenTech.AspenPlus.Happ.IHNode V_3,
             int32 V_4,
             int32 V_5,
             int32 V_6,
             valuetype [mscorlib]System.Nullable`1<bool> V_7,
             bool V_8,
             int32 V_9,
             int32 V_10,
             int32 V_11,
             string V_12,
             int32 V_13,
             string V_14,
             int32 V_15)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_0006:  callvirt   instance void AspenTech.AspenPlus.Happ.IHWizardPlot::RemoveAllDependentVariable()
    IL_000b:  ldarg.0
    IL_000c:  ldfld      int32[] WpfPLData.DataCurve::DataNum
    IL_0011:  ldlen
    IL_0012:  conv.i4
    IL_0013:  stloc.0
    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_001a:  callvirt   instance string[] [WpfPLControls]WpfPLControls.CurvesSelectorControl::GetSelectedCurves()
    IL_001f:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor(class [mscorlib]System.Collections.Generic.IEnumerable`1<!0>)
    IL_0024:  stloc.1
    IL_0025:  ldloc.1
    IL_0026:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_002b:  stloc.2
    IL_002c:  ldarg.0
    IL_002d:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_0032:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0037:  ldloc.2
    IL_0038:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NVariables(int32)
    IL_003d:  ldarg.0
    IL_003e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_0043:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0048:  ldc.i4.1
    IL_0049:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NXVariables(int32)
    IL_004e:  ldarg.0
    IL_004f:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_0054:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0059:  ldloc.0
    IL_005a:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NPoints(int32)
    IL_005f:  ldarg.0
    IL_0060:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.DataCurve::_context
    IL_0065:  ldstr      "Input/VALUE"
    IL_006a:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_006f:  stloc.3
    IL_0070:  ldloc.3
    IL_0071:  brtrue.s   IL_0074

    IL_0073:  ret

    IL_0074:  ldarg.0
    IL_0075:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_007a:  callvirt   instance int32 [PresentationFramework]System.Windows.Controls.Primitives.Selector::get_SelectedIndex()
    IL_007f:  stloc.s    V_4
    IL_0081:  ldc.i4.0
    IL_0082:  stloc.s    V_6
    IL_0084:  br.s       IL_00d6

    IL_0086:  nop
    .try
    {
      IL_0087:  ldarg.0
      IL_0088:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
      IL_008d:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_0092:  ldc.i4.0
      IL_0093:  ldloc.s    V_6
      IL_0095:  ldc.i4.1
      IL_0096:  ldloc.3
      IL_0097:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_009c:  ldarg.0
      IL_009d:  ldfld      int32[] WpfPLData.DataCurve::DataNum
      IL_00a2:  ldloc.s    V_6
      IL_00a4:  ldelem.i4
      IL_00a5:  box        [mscorlib]System.Int32
      IL_00aa:  ldc.i4.0
      IL_00ab:  box        [mscorlib]System.Int32
      IL_00b0:  ldloc.s    V_4
      IL_00b2:  box        [mscorlib]System.Int32
      IL_00b7:  ldsfld     object [mscorlib]System.Type::Missing
      IL_00bc:  ldsfld     object [mscorlib]System.Type::Missing
      IL_00c1:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_00c6:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_00cb:  leave.s    IL_00d0

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_00cd:  pop
      IL_00ce:  leave.s    IL_00d0

    }  // end handler
    IL_00d0:  ldloc.s    V_6
    IL_00d2:  ldc.i4.1
    IL_00d3:  add
    IL_00d4:  stloc.s    V_6
    IL_00d6:  ldloc.s    V_6
    IL_00d8:  ldloc.0
    IL_00d9:  blt.s      IL_0086

    IL_00db:  ldarg.0
    IL_00dc:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_00e1:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_00e6:  ldc.i4.0
    IL_00e7:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Parametric(bool)
    IL_00ec:  ldarg.0
    IL_00ed:  ldfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_00f2:  callvirt   instance valuetype [mscorlib]System.Nullable`1<bool> [PresentationFramework]System.Windows.Controls.Primitives.ToggleButton::get_IsChecked()
    IL_00f7:  stloc.s    V_7
    IL_00f9:  ldc.i4.1
    IL_00fa:  stloc.s    V_8
    IL_00fc:  ldloca.s   V_7
    IL_00fe:  call       instance !0 valuetype [mscorlib]System.Nullable`1<bool>::GetValueOrDefault()
    IL_0103:  ldloc.s    V_8
    IL_0105:  ceq
    IL_0107:  ldloca.s   V_7
    IL_0109:  call       instance bool valuetype [mscorlib]System.Nullable`1<bool>::get_HasValue()
    IL_010e:  and
    IL_010f:  brfalse.s  IL_0189

    IL_0111:  ldarg.0
    IL_0112:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_0117:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_011c:  ldc.i4.1
    IL_011d:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Parametric(bool)
    IL_0122:  ldarg.0
    IL_0123:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxParaVar
    IL_0128:  callvirt   instance int32 [PresentationFramework]System.Windows.Controls.Primitives.Selector::get_SelectedIndex()
    IL_012d:  stloc.s    V_9
    IL_012f:  ldc.i4.0
    IL_0130:  stloc.s    V_10
    IL_0132:  br.s       IL_0184

    IL_0134:  nop
    .try
    {
      IL_0135:  ldarg.0
      IL_0136:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
      IL_013b:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_0140:  ldc.i4.0
      IL_0141:  ldloc.s    V_10
      IL_0143:  ldc.i4.1
      IL_0144:  ldloc.3
      IL_0145:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_014a:  ldarg.0
      IL_014b:  ldfld      int32[] WpfPLData.DataCurve::DataNum
      IL_0150:  ldloc.s    V_10
      IL_0152:  ldelem.i4
      IL_0153:  box        [mscorlib]System.Int32
      IL_0158:  ldc.i4.0
      IL_0159:  box        [mscorlib]System.Int32
      IL_015e:  ldloc.s    V_9
      IL_0160:  box        [mscorlib]System.Int32
      IL_0165:  ldsfld     object [mscorlib]System.Type::Missing
      IL_016a:  ldsfld     object [mscorlib]System.Type::Missing
      IL_016f:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0174:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_0179:  leave.s    IL_017e

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_017b:  pop
      IL_017c:  leave.s    IL_017e

    }  // end handler
    IL_017e:  ldloc.s    V_10
    IL_0180:  ldc.i4.1
    IL_0181:  add
    IL_0182:  stloc.s    V_10
    IL_0184:  ldloc.s    V_10
    IL_0186:  ldloc.0
    IL_0187:  blt.s      IL_0134

    IL_0189:  ldarg.0
    IL_018a:  ldfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_018f:  callvirt   instance valuetype [mscorlib]System.Nullable`1<bool> [PresentationFramework]System.Windows.Controls.Primitives.ToggleButton::get_IsChecked()
    IL_0194:  stloc.s    V_7
    IL_0196:  ldc.i4.1
    IL_0197:  stloc.s    V_8
    IL_0199:  ldloca.s   V_7
    IL_019b:  call       instance !0 valuetype [mscorlib]System.Nullable`1<bool>::GetValueOrDefault()
    IL_01a0:  ldloc.s    V_8
    IL_01a2:  ceq
    IL_01a4:  ldloca.s   V_7
    IL_01a6:  call       instance bool valuetype [mscorlib]System.Nullable`1<bool>::get_HasValue()
    IL_01ab:  and
    IL_01ac:  brfalse.s  IL_01c1

    IL_01ae:  ldarg.0
    IL_01af:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_01b4:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_01b9:  ldloc.2
    IL_01ba:  ldc.i4.1
    IL_01bb:  add
    IL_01bc:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NVariables(int32)
    IL_01c1:  ldc.i4.0
    IL_01c2:  stloc.s    V_11
    IL_01c4:  br         IL_02ce

    IL_01c9:  ldloc.1
    IL_01ca:  ldloc.s    V_11
    IL_01cc:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_01d1:  stloc.s    V_12
    IL_01d3:  ldarg.0
    IL_01d4:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_01d9:  ldloc.s    V_12
    IL_01db:  callvirt   instance int32 [WpfPLControls]WpfPLControls.CurvesSelectorControl::GetSelectedCurveIndex(string)
    IL_01e0:  stloc.s    V_13
    IL_01e2:  ldloc.s    V_11
    IL_01e4:  stloc.s    V_5
    IL_01e6:  ldloc.s    V_12
    IL_01e8:  stloc.s    V_14
    IL_01ea:  ldarg.0
    IL_01eb:  ldfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_01f0:  callvirt   instance valuetype [mscorlib]System.Nullable`1<bool> [PresentationFramework]System.Windows.Controls.Primitives.ToggleButton::get_IsChecked()
    IL_01f5:  stloc.s    V_7
    IL_01f7:  ldc.i4.1
    IL_01f8:  stloc.s    V_8
    IL_01fa:  ldloca.s   V_7
    IL_01fc:  call       instance !0 valuetype [mscorlib]System.Nullable`1<bool>::GetValueOrDefault()
    IL_0201:  ldloc.s    V_8
    IL_0203:  ceq
    IL_0205:  ldloca.s   V_7
    IL_0207:  call       instance bool valuetype [mscorlib]System.Nullable`1<bool>::get_HasValue()
    IL_020c:  and
    IL_020d:  brfalse.s  IL_022c

    IL_020f:  ldloc.s    V_11
    IL_0211:  ldc.i4.1
    IL_0212:  add
    IL_0213:  stloc.s    V_5
    IL_0215:  ldarg.0
    IL_0216:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxParaVar
    IL_021b:  callvirt   instance string [PresentationFramework]System.Windows.Controls.ComboBox::get_Text()
    IL_0220:  ldstr      " = %param%"
    IL_0225:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_022a:  stloc.s    V_14
    IL_022c:  ldc.i4.0
    IL_022d:  stloc.s    V_15
    IL_022f:  br.s       IL_0282

    IL_0231:  nop
    .try
    {
      IL_0232:  ldarg.0
      IL_0233:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
      IL_0238:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_023d:  ldloc.s    V_5
      IL_023f:  ldloc.s    V_15
      IL_0241:  ldc.i4.1
      IL_0242:  ldloc.3
      IL_0243:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0248:  ldarg.0
      IL_0249:  ldfld      int32[] WpfPLData.DataCurve::DataNum
      IL_024e:  ldloc.s    V_15
      IL_0250:  ldelem.i4
      IL_0251:  box        [mscorlib]System.Int32
      IL_0256:  ldc.i4.0
      IL_0257:  box        [mscorlib]System.Int32
      IL_025c:  ldloc.s    V_13
      IL_025e:  box        [mscorlib]System.Int32
      IL_0263:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0268:  ldsfld     object [mscorlib]System.Type::Missing
      IL_026d:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0272:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_0277:  leave.s    IL_027c

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_0279:  pop
      IL_027a:  leave.s    IL_027c

    }  // end handler
    IL_027c:  ldloc.s    V_15
    IL_027e:  ldc.i4.1
    IL_027f:  add
    IL_0280:  stloc.s    V_15
    IL_0282:  ldloc.s    V_15
    IL_0284:  ldloc.0
    IL_0285:  blt.s      IL_0231

    IL_0287:  ldarg.0
    IL_0288:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_028d:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0292:  ldloc.s    V_11
    IL_0294:  ldloc.s    V_11
    IL_0296:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_AxisMap(int32,
                                                                                       int32)
    IL_029b:  ldarg.0
    IL_029c:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_02a1:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_02a6:  ldloc.s    V_11
    IL_02a8:  box        [mscorlib]System.Int32
    IL_02ad:  ldloc.s    V_12
    IL_02af:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_02b4:  ldarg.0
    IL_02b5:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_02ba:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_02bf:  ldloc.s    V_5
    IL_02c1:  ldloc.s    V_14
    IL_02c3:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_02c8:  ldloc.s    V_11
    IL_02ca:  ldc.i4.1
    IL_02cb:  add
    IL_02cc:  stloc.s    V_11
    IL_02ce:  ldloc.s    V_11
    IL_02d0:  ldloc.2
    IL_02d1:  blt        IL_01c9

    IL_02d6:  ldarg.0
    IL_02d7:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_02dc:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_02e1:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_DataCurve_Title()
    IL_02e6:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_02eb:  ldarg.0
    IL_02ec:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_02f1:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_02f6:  ldarg.0
    IL_02f7:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_02fc:  callvirt   instance string [PresentationFramework]System.Windows.Controls.ComboBox::get_Text()
    IL_0301:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_0306:  ldarg.0
    IL_0307:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_030c:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0311:  ldc.i4.1
    IL_0312:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_LineStyle(int16)
    IL_0317:  ldarg.0
    IL_0318:  ldarg.0
    IL_0319:  call       instance string WpfPLData.DataCurve::SaveConfigValue()
    IL_031e:  stfld      string WpfPLData.DataCurve::_currentConfigValue
    IL_0323:  ret
  } // end of method DataCurve::UpdateWizardData

  .method private hidebysig instance void 
          chkParaVar_Click(object sender,
                           class [PresentationCore]System.Windows.RoutedEventArgs e) cil managed
  {
    // Code size       70 (0x46)
    .maxstack  2
    .locals init (valuetype [mscorlib]System.Nullable`1<bool> V_0,
             bool V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_0006:  callvirt   instance valuetype [mscorlib]System.Nullable`1<bool> [PresentationFramework]System.Windows.Controls.Primitives.ToggleButton::get_IsChecked()
    IL_000b:  stloc.0
    IL_000c:  ldc.i4.1
    IL_000d:  stloc.1
    IL_000e:  ldloca.s   V_0
    IL_0010:  call       instance !0 valuetype [mscorlib]System.Nullable`1<bool>::GetValueOrDefault()
    IL_0015:  ldloc.1
    IL_0016:  ceq
    IL_0018:  ldloca.s   V_0
    IL_001a:  call       instance bool valuetype [mscorlib]System.Nullable`1<bool>::get_HasValue()
    IL_001f:  and
    IL_0020:  brfalse.s  IL_0034

    IL_0022:  ldarg.0
    IL_0023:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_0028:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_002d:  ldc.i4.1
    IL_002e:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Parametric(bool)
    IL_0033:  ret

    IL_0034:  ldarg.0
    IL_0035:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.DataCurve::_wizardPlot
    IL_003a:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_003f:  ldc.i4.0
    IL_0040:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Parametric(bool)
    IL_0045:  ret
  } // end of method DataCurve::chkParaVar_Click

  .method private hidebysig instance void 
          ExecuteOKCommand(object sender,
                           class [PresentationCore]System.Windows.Input.ExecutedRoutedEventArgs e) cil managed
  {
    // Code size       25 (0x19)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void WpfPLData.DataCurve::UpdateWizardData()
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class WpfPLData.PLDataHelper WpfPLData.DataCurve::_help
    IL_000c:  ldarg.0
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_0013:  callvirt   instance void [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper::CloseForm(class [PresentationFramework]System.Windows.Controls.UserControl,
                                                                                                       valuetype [mscorlib]System.Nullable`1<bool>)
    IL_0018:  ret
  } // end of method DataCurve::ExecuteOKCommand

  .method private hidebysig instance void 
          CanExecuteOKCommand(object sender,
                              class [PresentationCore]System.Windows.Input.CanExecuteRoutedEventArgs e) cil managed
  {
    // Code size       120 (0x78)
    .maxstack  3
    .locals init (int32 V_0,
             string[] V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_0006:  callvirt   instance int32 [PresentationFramework]System.Windows.Controls.Primitives.Selector::get_SelectedIndex()
    IL_000b:  ldarg.0
    IL_000c:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_0011:  callvirt   instance string[] [WpfPLControls]WpfPLControls.CurvesSelectorControl::GetSelectedCurves()
    IL_0016:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_001b:  stloc.0
    IL_001c:  ldloc.0
    IL_001d:  ldarg.0
    IL_001e:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_0023:  callvirt   instance class [System]System.Collections.ObjectModel.ObservableCollection`1<class [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesCheckListBoxItem> [WpfPLControls]WpfPLControls.CurvesSelectorControl::get_Curves()
    IL_0028:  callvirt   instance int32 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesCheckListBoxItem>::get_Count()
    IL_002d:  bne.un.s   IL_003d

    IL_002f:  ldarg.0
    IL_0030:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_0035:  ldc.i4.1
    IL_0036:  callvirt   instance void [WpfPLControls]WpfPLControls.CurvesSelectorControl::set_IsCheckAll(bool)
    IL_003b:  br.s       IL_0061

    IL_003d:  ldarg.0
    IL_003e:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_0043:  callvirt   instance string[] [WpfPLControls]WpfPLControls.CurvesSelectorControl::GetSelectedCurves()
    IL_0048:  stloc.1
    IL_0049:  ldarg.0
    IL_004a:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_004f:  ldc.i4.0
    IL_0050:  callvirt   instance void [WpfPLControls]WpfPLControls.CurvesSelectorControl::set_IsCheckAll(bool)
    IL_0055:  ldarg.0
    IL_0056:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_005b:  ldloc.1
    IL_005c:  callvirt   instance void [WpfPLControls]WpfPLControls.CurvesSelectorControl::SetSelectedCurves(string[])
    IL_0061:  ldc.i4.0
    IL_0062:  blt.s      IL_0070

    IL_0064:  ldloc.0
    IL_0065:  ldc.i4.0
    IL_0066:  ble.s      IL_0070

    IL_0068:  ldarg.2
    IL_0069:  ldc.i4.1
    IL_006a:  callvirt   instance void [PresentationCore]System.Windows.Input.CanExecuteRoutedEventArgs::set_CanExecute(bool)
    IL_006f:  ret

    IL_0070:  ldarg.2
    IL_0071:  ldc.i4.0
    IL_0072:  callvirt   instance void [PresentationCore]System.Windows.Input.CanExecuteRoutedEventArgs::set_CanExecute(bool)
    IL_0077:  ret
  } // end of method DataCurve::CanExecuteOKCommand

  .method private hidebysig instance void 
          ExecuteCancelCommand(object sender,
                               class [PresentationCore]System.Windows.Input.ExecutedRoutedEventArgs e) cil managed
  {
    // Code size       19 (0x13)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class WpfPLData.PLDataHelper WpfPLData.DataCurve::_help
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.0
    IL_0008:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_000d:  callvirt   instance void [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper::CloseForm(class [PresentationFramework]System.Windows.Controls.UserControl,
                                                                                                       valuetype [mscorlib]System.Nullable`1<bool>)
    IL_0012:  ret
  } // end of method DataCurve::ExecuteCancelCommand

  .method private hidebysig instance void 
          ExecuteClearCommand(object sender,
                              class [PresentationCore]System.Windows.Input.ExecutedRoutedEventArgs e) cil managed
  {
    // Code size       108 (0x6c)
    .maxstack  2
    .locals init (int32 V_0,
             int32 V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_0006:  ldstr      ""
    IL_000b:  callvirt   instance void [PresentationFramework]System.Windows.Controls.ComboBox::set_Text(string)
    IL_0010:  ldarg.0
    IL_0011:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxParaVar
    IL_0016:  ldstr      ""
    IL_001b:  callvirt   instance void [PresentationFramework]System.Windows.Controls.ComboBox::set_Text(string)
    IL_0020:  ldarg.0
    IL_0021:  ldfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_0026:  ldc.i4.0
    IL_0027:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_002c:  callvirt   instance void [PresentationFramework]System.Windows.Controls.Primitives.ToggleButton::set_IsChecked(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_0031:  ldarg.0
    IL_0032:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_0037:  ldc.i4.0
    IL_0038:  callvirt   instance void [WpfPLControls]WpfPLControls.CurvesSelectorControl::set_IsCheckAll(bool)
    IL_003d:  ldarg.0
    IL_003e:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_0043:  callvirt   instance string[] [WpfPLControls]WpfPLControls.CurvesSelectorControl::GetSelectedCurves()
    IL_0048:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor(class [mscorlib]System.Collections.Generic.IEnumerable`1<!0>)
    IL_004d:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_0052:  stloc.0
    IL_0053:  ldc.i4.0
    IL_0054:  stloc.1
    IL_0055:  br.s       IL_0067

    IL_0057:  ldarg.0
    IL_0058:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_005d:  ldc.i4.0
    IL_005e:  callvirt   instance void [WpfPLControls]WpfPLControls.CurvesSelectorControl::SetItemsIsChecked(bool)
    IL_0063:  ldloc.1
    IL_0064:  ldc.i4.1
    IL_0065:  add
    IL_0066:  stloc.1
    IL_0067:  ldloc.1
    IL_0068:  ldloc.0
    IL_0069:  blt.s      IL_0057

    IL_006b:  ret
  } // end of method DataCurve::ExecuteClearCommand

  .method private hidebysig instance string 
          SaveConfigValue() cil managed
  {
    // Code size       333 (0x14d)
    .maxstack  2
    .locals init (class [mscorlib]System.Text.StringBuilder V_0,
             class [mscorlib]System.Collections.Generic.List`1<string> V_1,
             int32 V_2,
             valuetype [mscorlib]System.Nullable`1<bool> V_3,
             bool V_4,
             int32 V_5,
             string V_6)
    IL_0000:  ldsfld     string [mscorlib]System.String::Empty
    IL_0005:  pop
    IL_0006:  newobj     instance void [mscorlib]System.Text.StringBuilder::.ctor()
    IL_000b:  stloc.0
    IL_000c:  ldloc.0
    IL_000d:  ldstr      "X-Axis="
    IL_0012:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_0017:  pop
    IL_0018:  ldloc.0
    IL_0019:  ldarg.0
    IL_001a:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_001f:  callvirt   instance string [PresentationFramework]System.Windows.Controls.ComboBox::get_Text()
    IL_0024:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_0029:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_002e:  pop
    IL_002f:  ldloc.0
    IL_0030:  ldstr      ";"
    IL_0035:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_003a:  pop
    IL_003b:  ldloc.0
    IL_003c:  ldstr      "ParamatricChecked="
    IL_0041:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_0046:  pop
    IL_0047:  ldarg.0
    IL_0048:  ldfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_004d:  callvirt   instance valuetype [mscorlib]System.Nullable`1<bool> [PresentationFramework]System.Windows.Controls.Primitives.ToggleButton::get_IsChecked()
    IL_0052:  stloc.3
    IL_0053:  ldc.i4.1
    IL_0054:  stloc.s    V_4
    IL_0056:  ldloca.s   V_3
    IL_0058:  call       instance !0 valuetype [mscorlib]System.Nullable`1<bool>::GetValueOrDefault()
    IL_005d:  ldloc.s    V_4
    IL_005f:  ceq
    IL_0061:  ldloca.s   V_3
    IL_0063:  call       instance bool valuetype [mscorlib]System.Nullable`1<bool>::get_HasValue()
    IL_0068:  and
    IL_0069:  brfalse.s  IL_0075

    IL_006b:  ldloc.0
    IL_006c:  ldc.i4.1
    IL_006d:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(int32)
    IL_0072:  pop
    IL_0073:  br.s       IL_007d

    IL_0075:  ldloc.0
    IL_0076:  ldc.i4.0
    IL_0077:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(int32)
    IL_007c:  pop
    IL_007d:  ldloc.0
    IL_007e:  ldstr      ";"
    IL_0083:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_0088:  pop
    IL_0089:  ldloc.0
    IL_008a:  ldstr      "Parametric="
    IL_008f:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_0094:  pop
    IL_0095:  ldloc.0
    IL_0096:  ldarg.0
    IL_0097:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxParaVar
    IL_009c:  callvirt   instance string [PresentationFramework]System.Windows.Controls.ComboBox::get_Text()
    IL_00a1:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_00a6:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_00ab:  pop
    IL_00ac:  ldloc.0
    IL_00ad:  ldstr      ";"
    IL_00b2:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_00b7:  pop
    IL_00b8:  ldloc.0
    IL_00b9:  ldstr      "CurveSelection="
    IL_00be:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_00c3:  pop
    IL_00c4:  ldarg.0
    IL_00c5:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_00ca:  callvirt   instance string[] [WpfPLControls]WpfPLControls.CurvesSelectorControl::GetSelectedCurves()
    IL_00cf:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor(class [mscorlib]System.Collections.Generic.IEnumerable`1<!0>)
    IL_00d4:  stloc.1
    IL_00d5:  ldloc.1
    IL_00d6:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_00db:  stloc.2
    IL_00dc:  ldc.i4.0
    IL_00dd:  stloc.s    V_5
    IL_00df:  br.s       IL_010b

    IL_00e1:  ldloc.s    V_5
    IL_00e3:  ldc.i4.0
    IL_00e4:  ble.s      IL_00f2

    IL_00e6:  ldloc.0
    IL_00e7:  ldstr      ","
    IL_00ec:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_00f1:  pop
    IL_00f2:  ldloc.1
    IL_00f3:  ldloc.s    V_5
    IL_00f5:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_00fa:  stloc.s    V_6
    IL_00fc:  ldloc.0
    IL_00fd:  ldloc.s    V_6
    IL_00ff:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_0104:  pop
    IL_0105:  ldloc.s    V_5
    IL_0107:  ldc.i4.1
    IL_0108:  add
    IL_0109:  stloc.s    V_5
    IL_010b:  ldloc.s    V_5
    IL_010d:  ldloc.2
    IL_010e:  blt.s      IL_00e1

    IL_0110:  ldloc.0
    IL_0111:  ldstr      ";"
    IL_0116:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_011b:  pop
    IL_011c:  ldloc.0
    IL_011d:  ldstr      "CheckAll="
    IL_0122:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_0127:  pop
    IL_0128:  ldloc.0
    IL_0129:  ldarg.0
    IL_012a:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_012f:  callvirt   instance bool [WpfPLControls]WpfPLControls.CurvesSelectorControl::get_IsCheckAll()
    IL_0134:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(bool)
    IL_0139:  pop
    IL_013a:  ldloc.0
    IL_013b:  ldstr      ";"
    IL_0140:  callvirt   instance class [mscorlib]System.Text.StringBuilder [mscorlib]System.Text.StringBuilder::Append(string)
    IL_0145:  pop
    IL_0146:  ldloc.0
    IL_0147:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_014c:  ret
  } // end of method DataCurve::SaveConfigValue

  .method private hidebysig instance void 
          RestoreConfigValue(string ConfigString) cil managed
  {
    // Code size       304 (0x130)
    .maxstack  5
    .locals init (string[] V_0,
             int32 V_1,
             string V_2,
             class [mscorlib]System.Collections.Generic.List`1<string> V_3,
             string[] V_4,
             int32 V_5,
             string V_6)
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  newarr     [mscorlib]System.Char
    IL_0007:  dup
    IL_0008:  ldc.i4.0
    IL_0009:  ldc.i4.s   59
    IL_000b:  stelem.i2
    IL_000c:  callvirt   instance string[] [mscorlib]System.String::Split(char[])
    IL_0011:  stloc.0
    IL_0012:  ldc.i4.0
    IL_0013:  stloc.1
    IL_0014:  ldloc.0
    IL_0015:  ldloc.1
    IL_0016:  ldelem.ref
    IL_0017:  ldloc.0
    IL_0018:  ldloc.1
    IL_0019:  ldelem.ref
    IL_001a:  ldc.i4.s   61
    IL_001c:  callvirt   instance int32 [mscorlib]System.String::IndexOf(char)
    IL_0021:  ldc.i4.1
    IL_0022:  add
    IL_0023:  callvirt   instance string [mscorlib]System.String::Substring(int32)
    IL_0028:  stloc.2
    IL_0029:  ldarg.0
    IL_002a:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_002f:  ldloc.2
    IL_0030:  callvirt   instance void [PresentationFramework]System.Windows.Controls.ComboBox::set_Text(string)
    IL_0035:  ldloc.1
    IL_0036:  ldc.i4.1
    IL_0037:  add
    IL_0038:  stloc.1
    IL_0039:  ldloc.0
    IL_003a:  ldloc.1
    IL_003b:  ldelem.ref
    IL_003c:  ldloc.0
    IL_003d:  ldloc.1
    IL_003e:  ldelem.ref
    IL_003f:  ldc.i4.s   61
    IL_0041:  callvirt   instance int32 [mscorlib]System.String::IndexOf(char)
    IL_0046:  ldc.i4.1
    IL_0047:  add
    IL_0048:  callvirt   instance string [mscorlib]System.String::Substring(int32)
    IL_004d:  stloc.2
    IL_004e:  ldloc.2
    IL_004f:  call       int16 [mscorlib]System.Convert::ToInt16(string)
    IL_0054:  ldc.i4.1
    IL_0055:  bne.un.s   IL_006a

    IL_0057:  ldarg.0
    IL_0058:  ldfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_005d:  ldc.i4.1
    IL_005e:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_0063:  callvirt   instance void [PresentationFramework]System.Windows.Controls.Primitives.ToggleButton::set_IsChecked(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_0068:  br.s       IL_007b

    IL_006a:  ldarg.0
    IL_006b:  ldfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_0070:  ldc.i4.0
    IL_0071:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_0076:  callvirt   instance void [PresentationFramework]System.Windows.Controls.Primitives.ToggleButton::set_IsChecked(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_007b:  ldloc.1
    IL_007c:  ldc.i4.1
    IL_007d:  add
    IL_007e:  stloc.1
    IL_007f:  ldloc.0
    IL_0080:  ldloc.1
    IL_0081:  ldelem.ref
    IL_0082:  ldloc.0
    IL_0083:  ldloc.1
    IL_0084:  ldelem.ref
    IL_0085:  ldc.i4.s   61
    IL_0087:  callvirt   instance int32 [mscorlib]System.String::IndexOf(char)
    IL_008c:  ldc.i4.1
    IL_008d:  add
    IL_008e:  callvirt   instance string [mscorlib]System.String::Substring(int32)
    IL_0093:  stloc.2
    IL_0094:  ldarg.0
    IL_0095:  ldfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxParaVar
    IL_009a:  ldloc.2
    IL_009b:  callvirt   instance void [PresentationFramework]System.Windows.Controls.ComboBox::set_Text(string)
    IL_00a0:  ldloc.1
    IL_00a1:  ldc.i4.1
    IL_00a2:  add
    IL_00a3:  stloc.1
    IL_00a4:  ldloc.0
    IL_00a5:  ldloc.1
    IL_00a6:  ldelem.ref
    IL_00a7:  ldloc.0
    IL_00a8:  ldloc.1
    IL_00a9:  ldelem.ref
    IL_00aa:  ldc.i4.s   61
    IL_00ac:  callvirt   instance int32 [mscorlib]System.String::IndexOf(char)
    IL_00b1:  ldc.i4.1
    IL_00b2:  add
    IL_00b3:  callvirt   instance string [mscorlib]System.String::Substring(int32)
    IL_00b8:  stloc.2
    IL_00b9:  ldloc.2
    IL_00ba:  ldc.i4.1
    IL_00bb:  newarr     [mscorlib]System.Char
    IL_00c0:  dup
    IL_00c1:  ldc.i4.0
    IL_00c2:  ldc.i4.s   44
    IL_00c4:  stelem.i2
    IL_00c5:  callvirt   instance string[] [mscorlib]System.String::Split(char[])
    IL_00ca:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_00cf:  stloc.3
    IL_00d0:  stloc.s    V_4
    IL_00d2:  ldc.i4.0
    IL_00d3:  stloc.s    V_5
    IL_00d5:  br.s       IL_00ec

    IL_00d7:  ldloc.s    V_4
    IL_00d9:  ldloc.s    V_5
    IL_00db:  ldelem.ref
    IL_00dc:  stloc.s    V_6
    IL_00de:  ldloc.3
    IL_00df:  ldloc.s    V_6
    IL_00e1:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_00e6:  ldloc.s    V_5
    IL_00e8:  ldc.i4.1
    IL_00e9:  add
    IL_00ea:  stloc.s    V_5
    IL_00ec:  ldloc.s    V_5
    IL_00ee:  ldloc.s    V_4
    IL_00f0:  ldlen
    IL_00f1:  conv.i4
    IL_00f2:  blt.s      IL_00d7

    IL_00f4:  ldarg.0
    IL_00f5:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_00fa:  ldloc.3
    IL_00fb:  callvirt   instance !0[] class [mscorlib]System.Collections.Generic.List`1<string>::ToArray()
    IL_0100:  callvirt   instance void [WpfPLControls]WpfPLControls.CurvesSelectorControl::SetSelectedCurves(string[])
    IL_0105:  ldloc.1
    IL_0106:  ldc.i4.1
    IL_0107:  add
    IL_0108:  stloc.1
    IL_0109:  ldloc.0
    IL_010a:  ldloc.1
    IL_010b:  ldelem.ref
    IL_010c:  ldloc.0
    IL_010d:  ldloc.1
    IL_010e:  ldelem.ref
    IL_010f:  ldc.i4.s   61
    IL_0111:  callvirt   instance int32 [mscorlib]System.String::IndexOf(char)
    IL_0116:  ldc.i4.1
    IL_0117:  add
    IL_0118:  callvirt   instance string [mscorlib]System.String::Substring(int32)
    IL_011d:  stloc.2
    IL_011e:  ldarg.0
    IL_011f:  ldfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_0124:  ldloc.2
    IL_0125:  call       bool [mscorlib]System.Convert::ToBoolean(string)
    IL_012a:  callvirt   instance void [WpfPLControls]WpfPLControls.CurvesSelectorControl::set_IsCheckAll(bool)
    IL_012f:  ret
  } // end of method DataCurve::RestoreConfigValue

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool WpfPLData.DataCurve::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool WpfPLData.DataCurve::_contentLoaded
    IL_0010:  ldstr      "/WpfPLData;component/datacurve.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method DataCurve::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       177 (0xb1)
    .maxstack  3
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_002a,
                          IL_0037,
                          IL_0044,
                          IL_0051,
                          IL_0075,
                          IL_0082,
                          IL_008f,
                          IL_009c)
    IL_0028:  br.s       IL_00a9

    IL_002a:  ldarg.0
    IL_002b:  ldarg.2
    IL_002c:  castclass  [PresentationFramework]System.Windows.Controls.GroupBox
    IL_0031:  stfld      class [PresentationFramework]System.Windows.Controls.GroupBox WpfPLData.DataCurve::groupBoxOption
    IL_0036:  ret

    IL_0037:  ldarg.0
    IL_0038:  ldarg.2
    IL_0039:  castclass  [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesLabel
    IL_003e:  stfld      class [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesLabel WpfPLData.DataCurve::lblXAxis
    IL_0043:  ret

    IL_0044:  ldarg.0
    IL_0045:  ldarg.2
    IL_0046:  castclass  [PresentationFramework]System.Windows.Controls.ComboBox
    IL_004b:  stfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxXAxis
    IL_0050:  ret

    IL_0051:  ldarg.0
    IL_0052:  ldarg.2
    IL_0053:  castclass  [PresentationFramework]System.Windows.Controls.CheckBox
    IL_0058:  stfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_005d:  ldarg.0
    IL_005e:  ldfld      class [PresentationFramework]System.Windows.Controls.CheckBox WpfPLData.DataCurve::chkParaVar
    IL_0063:  ldarg.0
    IL_0064:  ldftn      instance void WpfPLData.DataCurve::chkParaVar_Click(object,
                                                                             class [PresentationCore]System.Windows.RoutedEventArgs)
    IL_006a:  newobj     instance void [PresentationCore]System.Windows.RoutedEventHandler::.ctor(object,
                                                                                                  native int)
    IL_006f:  callvirt   instance void [PresentationFramework]System.Windows.Controls.Primitives.ButtonBase::add_Click(class [PresentationCore]System.Windows.RoutedEventHandler)
    IL_0074:  ret

    IL_0075:  ldarg.0
    IL_0076:  ldarg.2
    IL_0077:  castclass  [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesLabel
    IL_007c:  stfld      class [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesLabel WpfPLData.DataCurve::lblParaVar
    IL_0081:  ret

    IL_0082:  ldarg.0
    IL_0083:  ldarg.2
    IL_0084:  castclass  [PresentationFramework]System.Windows.Controls.ComboBox
    IL_0089:  stfld      class [PresentationFramework]System.Windows.Controls.ComboBox WpfPLData.DataCurve::ComboBoxParaVar
    IL_008e:  ret

    IL_008f:  ldarg.0
    IL_0090:  ldarg.2
    IL_0091:  castclass  [WpfPLControls]WpfPLControls.CurvesSelectorControl
    IL_0096:  stfld      class [WpfPLControls]WpfPLControls.CurvesSelectorControl WpfPLData.DataCurve::CurveList
    IL_009b:  ret

    IL_009c:  ldarg.0
    IL_009d:  ldarg.2
    IL_009e:  castclass  [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesCmdButton
    IL_00a3:  stfld      class [AspenTech.WpfControls.Engineering]AspenTech.WpfControls.Engineering.AesCmdButton WpfPLData.DataCurve::btnClear
    IL_00a8:  ret

    IL_00a9:  ldarg.0
    IL_00aa:  ldc.i4.1
    IL_00ab:  stfld      bool WpfPLData.DataCurve::_contentLoaded
    IL_00b0:  ret
  } // end of method DataCurve::System.Windows.Markup.IComponentConnector.Connect

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  newobj     instance void [PresentationCore]System.Windows.Input.RoutedCommand::.ctor()
    IL_0005:  stsfld     class [PresentationCore]System.Windows.Input.RoutedCommand WpfPLData.DataCurve::OKCommand
    IL_000a:  newobj     instance void [PresentationCore]System.Windows.Input.RoutedCommand::.ctor()
    IL_000f:  stsfld     class [PresentationCore]System.Windows.Input.RoutedCommand WpfPLData.DataCurve::CancelCommand
    IL_0014:  newobj     instance void [PresentationCore]System.Windows.Input.RoutedCommand::.ctor()
    IL_0019:  stsfld     class [PresentationCore]System.Windows.Input.RoutedCommand WpfPLData.DataCurve::ClearCommand
    IL_001e:  ret
  } // end of method DataCurve::.cctor

  .property instance callconv(8) string TooltipContentForRibbonItem()
  {
    .get instance string WpfPLData.DataCurve::get_TooltipContentForRibbonItem()
  } // end of property DataCurve::TooltipContentForRibbonItem
  .property instance callconv(8) string TooltipHeaderForRibbonItem()
  {
    .get instance string WpfPLData.DataCurve::get_TooltipHeaderForRibbonItem()
  } // end of property DataCurve::TooltipHeaderForRibbonItem
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TagID()
  {
    .get instance string WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TagID()
    .set instance void WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_TagID(string)
  } // end of property DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TagID
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Name()
  {
    .get instance string WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_Name()
    .set instance void WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_Name(string)
  } // end of property DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Name
  .property instance callconv(8) object AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.WizardPlot()
  {
    .get instance object WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_WizardPlot()
    .set instance void WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_WizardPlot(object)
  } // end of property DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.WizardPlot
  .property instance callconv(8) object AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.CxsNode()
  {
    .get instance object WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_CxsNode()
    .set instance void WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_CxsNode(object)
  } // end of property DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.CxsNode
  .property instance callconv(8) class [System.Drawing]System.Drawing.Image
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ImageIcon()
  {
    .get instance class [System.Drawing]System.Drawing.Image WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_ImageIcon()
  } // end of property DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ImageIcon
  .property instance callconv(8) bool AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HasInputDialog()
  {
    .get instance bool WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HasInputDialog()
  } // end of property DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HasInputDialog
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpFile()
  {
    .get instance string WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpFile()
  } // end of property DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpFile
  .property instance callconv(8) int64 AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpID()
  {
    .get instance int64 WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpID()
  } // end of property DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpID
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.List`1<string>
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedDataFields()
  {
    .get instance class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedDataFields()
  } // end of property DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedDataFields
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.List`1<string>
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedStyleFields()
  {
    .get instance class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedStyleFields()
  } // end of property DataCurve::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedStyleFields
  .property instance callconv(8) bool CheckDataOnly()
  {
    .get instance bool WpfPLData.DataCurve::get_CheckDataOnly()
    .set instance void WpfPLData.DataCurve::set_CheckDataOnly(bool)
  } // end of property DataCurve::CheckDataOnly
} // end of class WpfPLData.DataCurve

.class public auto ansi beforefieldinit WpfPLData.PLDataHelper
       extends [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper
{
  .class abstract auto ansi sealed nested private beforefieldinit '<>o__5'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__0'
  } // end of class '<>o__5'

  .class abstract auto ansi sealed nested private beforefieldinit '<>o__6'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__0'
  } // end of class '<>o__6'

  .class abstract auto ansi sealed nested private beforefieldinit '<>o__7'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__0'
  } // end of class '<>o__7'

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string HelpFileName,
                               int64 HelpFileId) cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldarg.2
    IL_0003:  call       instance void [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper::.ctor(string,
                                                                                                   int64)
    IL_0008:  ret
  } // end of method PLDataHelper::.ctor

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper::.ctor()
    IL_0006:  ret
  } // end of method PLDataHelper::.ctor

  .method public hidebysig instance string 
          GetIconResource(string 'type') cil managed
  {
    // Code size       455 (0x1c7)
    .maxstack  2
    .locals init (int32 V_0,
             char V_1)
    IL_0000:  ldarg.1
    IL_0001:  brfalse    IL_01c1

    IL_0006:  ldarg.1
    IL_0007:  call       instance int32 [mscorlib]System.String::get_Length()
    IL_000c:  stloc.0
    IL_000d:  ldloc.0
    IL_000e:  ldc.i4.3
    IL_000f:  sub
    IL_0010:  switch     ( 
                          IL_0049,
                          IL_002f,
                          IL_01c1,
                          IL_006e)
    IL_0025:  ldloc.0
    IL_0026:  ldc.i4.s   10
    IL_0028:  beq.s      IL_008b

    IL_002a:  br         IL_01c1

    IL_002f:  ldarg.1
    IL_0030:  ldc.i4.0
    IL_0031:  call       instance char [mscorlib]System.String::get_Chars(int32)
    IL_0036:  stloc.1
    IL_0037:  ldloc.1
    IL_0038:  ldc.i4.s   80
    IL_003a:  beq        IL_00d6

    IL_003f:  ldloc.1
    IL_0040:  ldc.i4.s   84
    IL_0042:  beq.s      IL_00b1

    IL_0044:  br         IL_01c1

    IL_0049:  ldarg.1
    IL_004a:  ldc.i4.0
    IL_004b:  call       instance char [mscorlib]System.String::get_Chars(int32)
    IL_0050:  stloc.1
    IL_0051:  ldloc.1
    IL_0052:  ldc.i4.s   80
    IL_0054:  beq        IL_0110

    IL_0059:  ldloc.1
    IL_005a:  ldc.i4.s   84
    IL_005c:  beq        IL_00fb

    IL_0061:  ldloc.1
    IL_0062:  ldc.i4.s   121
    IL_0064:  beq        IL_0122

    IL_0069:  br         IL_01c1

    IL_006e:  ldarg.1
    IL_006f:  ldc.i4.5
    IL_0070:  call       instance char [mscorlib]System.String::get_Chars(int32)
    IL_0075:  stloc.1
    IL_0076:  ldloc.1
    IL_0077:  ldc.i4.s   84
    IL_0079:  beq        IL_0143

    IL_007e:  ldloc.1
    IL_007f:  ldc.i4.s   120
    IL_0081:  beq        IL_0134

    IL_0086:  br         IL_01c1

    IL_008b:  ldarg.1
    IL_008c:  ldc.i4.s   9
    IL_008e:  call       instance char [mscorlib]System.String::get_Chars(int32)
    IL_0093:  stloc.1
    IL_0094:  ldloc.1
    IL_0095:  ldc.i4.s   80
    IL_0097:  beq        IL_0170

    IL_009c:  ldloc.1
    IL_009d:  ldc.i4.s   84
    IL_009f:  beq        IL_0161

    IL_00a4:  ldloc.1
    IL_00a5:  ldc.i4.s   114
    IL_00a7:  beq        IL_0152

    IL_00ac:  br         IL_01c1

    IL_00b1:  ldarg.1
    IL_00b2:  ldstr      "T-xy"
    IL_00b7:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00bc:  brtrue     IL_017f

    IL_00c1:  ldarg.1
    IL_00c2:  ldstr      "T-xx"
    IL_00c7:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00cc:  brtrue     IL_019d

    IL_00d1:  br         IL_01c1

    IL_00d6:  ldarg.1
    IL_00d7:  ldstr      "P-xy"
    IL_00dc:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00e1:  brtrue     IL_0185

    IL_00e6:  ldarg.1
    IL_00e7:  ldstr      "P-xx"
    IL_00ec:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00f1:  brtrue     IL_019d

    IL_00f6:  br         IL_01c1

    IL_00fb:  ldarg.1
    IL_00fc:  ldstr      "T-x"
    IL_0101:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0106:  brtrue     IL_018b

    IL_010b:  br         IL_01c1

    IL_0110:  ldarg.1
    IL_0111:  ldstr      "P-x"
    IL_0116:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_011b:  brtrue.s   IL_0191

    IL_011d:  br         IL_01c1

    IL_0122:  ldarg.1
    IL_0123:  ldstr      "y-x"
    IL_0128:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_012d:  brtrue.s   IL_0197

    IL_012f:  br         IL_01c1

    IL_0134:  ldarg.1
    IL_0135:  ldstr      "Prop-x"
    IL_013a:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_013f:  brtrue.s   IL_01a3

    IL_0141:  br.s       IL_01c1

    IL_0143:  ldarg.1
    IL_0144:  ldstr      "Prop-T"
    IL_0149:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_014e:  brtrue.s   IL_01a9

    IL_0150:  br.s       IL_01c1

    IL_0152:  ldarg.1
    IL_0153:  ldstr      "Triangular"
    IL_0158:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_015d:  brtrue.s   IL_01af

    IL_015f:  br.s       IL_01c1

    IL_0161:  ldarg.1
    IL_0162:  ldstr      "Property-T"
    IL_0167:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_016c:  brtrue.s   IL_01b5

    IL_016e:  br.s       IL_01c1

    IL_0170:  ldarg.1
    IL_0171:  ldstr      "Property-P"
    IL_0176:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_017b:  brtrue.s   IL_01bb

    IL_017d:  br.s       IL_01c1

    IL_017f:  ldstr      "WpfPLData.Images.DataTXY.ico"
    IL_0184:  ret

    IL_0185:  ldstr      "WpfPLData.Images.DataPxy.ico"
    IL_018a:  ret

    IL_018b:  ldstr      "WpfPLData.Images.DataTX.ico"
    IL_0190:  ret

    IL_0191:  ldstr      "WpfPLData.Images.DataPx.ico"
    IL_0196:  ret

    IL_0197:  ldstr      "WpfPLData.Images.DataYX.ico"
    IL_019c:  ret

    IL_019d:  ldstr      "WpfPLData.Images.DataXX.ico"
    IL_01a2:  ret

    IL_01a3:  ldstr      "WpfPLData.Images.DataPropx.ico"
    IL_01a8:  ret

    IL_01a9:  ldstr      "WpfPLData.Images.DataPropt.ico"
    IL_01ae:  ret

    IL_01af:  ldstr      "WpfPLData.Images.DataTri.ico"
    IL_01b4:  ret

    IL_01b5:  ldstr      "WpfPLData.Images.DataPropt.ico"
    IL_01ba:  ret

    IL_01bb:  ldstr      "WpfPLData.Images.DataPropt.ico"
    IL_01c0:  ret

    IL_01c1:  ldstr      "WpfPLData.Images.DataTri.ico"
    IL_01c6:  ret
  } // end of method PLDataHelper::GetIconResource

  .method public hidebysig instance int32 
          GetElementCount(class AspenTech.AspenPlus.Happ.IHNode Context,
                          string varName,
                          string elemName,
                          [out] int32& element,
                          [out] string& unit) cil managed
  {
    // Code size       175 (0xaf)
    .maxstack  5
    .locals init (class AspenTech.AspenPlus.Happ.IHNode V_0,
             class AspenTech.AspenPlus.Happ.IHNodeCol V_1,
             int32 V_2,
             int32 V_3,
             int32 V_4,
             string V_5)
    IL_0000:  ldarg.s    element
    IL_0002:  ldc.i4.0
    IL_0003:  stind.i4
    IL_0004:  ldarg.s    unit
    IL_0006:  ldsfld     string [mscorlib]System.String::Empty
    IL_000b:  stind.ref
    IL_000c:  ldarg.1
    IL_000d:  brtrue.s   IL_0011

    IL_000f:  ldc.i4.0
    IL_0010:  ret

    IL_0011:  ldarg.1
    IL_0012:  ldarg.2
    IL_0013:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_0018:  stloc.0
    IL_0019:  ldloc.0
    IL_001a:  brtrue.s   IL_001e

    IL_001c:  ldc.i4.0
    IL_001d:  ret

    IL_001e:  ldloc.0
    IL_001f:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0024:  stloc.1
    IL_0025:  ldloc.1
    IL_0026:  ldc.i4.1
    IL_0027:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHNodeCol::get_RowCount(int32)
    IL_002c:  stloc.2
    IL_002d:  ldc.i4.0
    IL_002e:  stloc.3
    IL_002f:  ldc.i4.0
    IL_0030:  stloc.s    V_4
    IL_0032:  br.s       IL_00a8

    IL_0034:  ldloc.1
    IL_0035:  ldc.i4.1
    IL_0036:  ldloc.s    V_4
    IL_0038:  ldsfld     object [mscorlib]System.Type::Missing
    IL_003d:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_0042:  stloc.s    V_5
    IL_0044:  ldloc.s    V_5
    IL_0046:  ldarg.3
    IL_0047:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_004c:  brfalse.s  IL_00a2

    IL_004e:  ldloc.3
    IL_004f:  ldc.i4.1
    IL_0050:  add
    IL_0051:  stloc.3
    IL_0052:  ldloc.s    V_5
    IL_0054:  ldstr      "TEMPERATURE"
    IL_0059:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_005e:  brtrue.s   IL_008a

    IL_0060:  ldloc.s    V_5
    IL_0062:  ldstr      "PRESSURE"
    IL_0067:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_006c:  brtrue.s   IL_008a

    IL_006e:  ldloc.s    V_5
    IL_0070:  ldstr      "TEMP1"
    IL_0075:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_007a:  brtrue.s   IL_008a

    IL_007c:  ldloc.s    V_5
    IL_007e:  ldstr      "TEMP2"
    IL_0083:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0088:  brfalse.s  IL_00a2

    IL_008a:  ldarg.s    element
    IL_008c:  ldloc.s    V_4
    IL_008e:  stind.i4
    IL_008f:  ldarg.s    unit
    IL_0091:  ldloc.1
    IL_0092:  ldc.i4.2
    IL_0093:  ldloc.s    V_4
    IL_0095:  ldsfld     object [mscorlib]System.Type::Missing
    IL_009a:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_009f:  stind.ref
    IL_00a0:  br.s       IL_00ad

    IL_00a2:  ldloc.s    V_4
    IL_00a4:  ldc.i4.1
    IL_00a5:  add
    IL_00a6:  stloc.s    V_4
    IL_00a8:  ldloc.s    V_4
    IL_00aa:  ldloc.2
    IL_00ab:  blt.s      IL_0034

    IL_00ad:  ldloc.3
    IL_00ae:  ret
  } // end of method PLDataHelper::GetElementCount

  .method public hidebysig instance bool 
          IsMixture(class AspenTech.AspenPlus.Happ.IHNode Context,
                    string varName) cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  2
    .locals init (bool V_0,
             class AspenTech.AspenPlus.Happ.IHNode V_1)
    IL_0000:  ldc.i4.0
    IL_0001:  stloc.0
    IL_0002:  ldarg.1
    IL_0003:  ldarg.2
    IL_0004:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_0009:  stloc.1
    IL_000a:  ldloc.1
    IL_000b:  brfalse.s  IL_001d

    IL_000d:  ldloc.1
    IL_000e:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0013:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHNodeCol::get_Count()
    IL_0018:  ldc.i4.0
    IL_0019:  ble.s      IL_001d

    IL_001b:  ldc.i4.1
    IL_001c:  stloc.0
    IL_001d:  ldloc.0
    IL_001e:  ret
  } // end of method PLDataHelper::IsMixture

  .method public hidebysig instance int32[] 
          GetDataElementsArray(class AspenTech.AspenPlus.Happ.IHNode Context,
                               string varName) cil managed
  {
    // Code size       186 (0xba)
    .maxstack  8
    .locals init (class [mscorlib]System.Collections.Generic.List`1<int32> V_0,
             class AspenTech.AspenPlus.Happ.IHNode V_1,
             int32 V_2,
             int32 V_3)
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<int32>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.1
    IL_0007:  ldarg.2
    IL_0008:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_000d:  stloc.1
    IL_000e:  ldloc.1
    IL_000f:  brfalse    IL_00b3

    IL_0014:  ldloc.1
    IL_0015:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_001a:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHNodeCol::get_Count()
    IL_001f:  stloc.2
    IL_0020:  ldc.i4.0
    IL_0021:  stloc.3
    IL_0022:  br         IL_00ac

    IL_0027:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__5'::'<>p__0'
    IL_002c:  brtrue.s   IL_0052

    IL_002e:  ldc.i4.0
    IL_002f:  ldtoken    [mscorlib]System.String
    IL_0034:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0039:  ldtoken    WpfPLData.PLDataHelper
    IL_003e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0043:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_0048:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_004d:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__5'::'<>p__0'
    IL_0052:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__5'::'<>p__0'
    IL_0057:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_005c:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__5'::'<>p__0'
    IL_0061:  ldloc.1
    IL_0062:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0067:  ldloc.3
    IL_0068:  box        [mscorlib]System.Int32
    IL_006d:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0072:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0077:  ldsfld     object [mscorlib]System.Type::Missing
    IL_007c:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0081:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_0086:  ldsfld     object [mscorlib]System.Type::Missing
    IL_008b:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_0090:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_0095:  ldstr      "DATA"
    IL_009a:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_009f:  brfalse.s  IL_00a8

    IL_00a1:  ldloc.0
    IL_00a2:  ldloc.3
    IL_00a3:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<int32>::Add(!0)
    IL_00a8:  ldloc.3
    IL_00a9:  ldc.i4.1
    IL_00aa:  add
    IL_00ab:  stloc.3
    IL_00ac:  ldloc.3
    IL_00ad:  ldloc.2
    IL_00ae:  blt        IL_0027

    IL_00b3:  ldloc.0
    IL_00b4:  callvirt   instance !0[] class [mscorlib]System.Collections.Generic.List`1<int32>::ToArray()
    IL_00b9:  ret
  } // end of method PLDataHelper::GetDataElementsArray

  .method public hidebysig instance class [mscorlib]System.Collections.Generic.List`1<string> 
          GetComponentList(class AspenTech.AspenPlus.Happ.IHNode Context,
                           string varName) cil managed
  {
    // Code size       182 (0xb6)
    .maxstack  8
    .locals init (class [mscorlib]System.Collections.Generic.List`1<string> V_0,
             class AspenTech.AspenPlus.Happ.IHNode V_1,
             int32 V_2,
             int32 V_3,
             string V_4)
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.1
    IL_0007:  ldarg.2
    IL_0008:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_000d:  stloc.1
    IL_000e:  ldloc.1
    IL_000f:  brfalse    IL_00b4

    IL_0014:  ldloc.1
    IL_0015:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_001a:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHNodeCol::get_Count()
    IL_001f:  stloc.2
    IL_0020:  ldc.i4.0
    IL_0021:  stloc.3
    IL_0022:  br         IL_00ad

    IL_0027:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__6'::'<>p__0'
    IL_002c:  brtrue.s   IL_0052

    IL_002e:  ldc.i4.0
    IL_002f:  ldtoken    [mscorlib]System.String
    IL_0034:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0039:  ldtoken    WpfPLData.PLDataHelper
    IL_003e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0043:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_0048:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_004d:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__6'::'<>p__0'
    IL_0052:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__6'::'<>p__0'
    IL_0057:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_005c:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__6'::'<>p__0'
    IL_0061:  ldloc.1
    IL_0062:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0067:  ldloc.3
    IL_0068:  box        [mscorlib]System.Int32
    IL_006d:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0072:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0077:  ldsfld     object [mscorlib]System.Type::Missing
    IL_007c:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0081:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object,
                                                                                                                     object)
    IL_0086:  ldsfld     object [mscorlib]System.Type::Missing
    IL_008b:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_0090:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_0095:  stloc.s    V_4
    IL_0097:  ldloc.0
    IL_0098:  ldloc.s    V_4
    IL_009a:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<string>::Contains(!0)
    IL_009f:  brtrue.s   IL_00a9

    IL_00a1:  ldloc.0
    IL_00a2:  ldloc.s    V_4
    IL_00a4:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_00a9:  ldloc.3
    IL_00aa:  ldc.i4.1
    IL_00ab:  add
    IL_00ac:  stloc.3
    IL_00ad:  ldloc.3
    IL_00ae:  ldloc.2
    IL_00af:  blt        IL_0027

    IL_00b4:  ldloc.0
    IL_00b5:  ret
  } // end of method PLDataHelper::GetComponentList

  .method public hidebysig instance void 
          DetermineMoleType(class AspenTech.AspenPlus.Happ.IHNode Context,
                            [out] string& moleType) cil managed
  {
    // Code size       183 (0xb7)
    .maxstack  4
    .locals init (class AspenTech.AspenPlus.Happ.IHNode V_0,
             string V_1)
    IL_0000:  ldarg.2
    IL_0001:  ldstr      ""
    IL_0006:  stind.ref
    IL_0007:  ldarg.1
    IL_0008:  ldstr      "Input/COMPOSITION"
    IL_000d:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_0012:  stloc.0
    IL_0013:  ldloc.0
    IL_0014:  brtrue.s   IL_0017

    IL_0016:  ret

    IL_0017:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__7'::'<>p__0'
    IL_001c:  brtrue.s   IL_0042

    IL_001e:  ldc.i4.0
    IL_001f:  ldtoken    [mscorlib]System.String
    IL_0024:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0029:  ldtoken    WpfPLData.PLDataHelper
    IL_002e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0033:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_0038:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_003d:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__7'::'<>p__0'
    IL_0042:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__7'::'<>p__0'
    IL_0047:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_004c:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.PLDataHelper/'<>o__7'::'<>p__0'
    IL_0051:  ldloc.0
    IL_0052:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0057:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_005c:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_0061:  stloc.1
    IL_0062:  ldloc.1
    IL_0063:  ldstr      "MOLE-FRAC"
    IL_0068:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_006d:  brtrue.s   IL_0097

    IL_006f:  ldloc.1
    IL_0070:  ldstr      "MASS-FRAC"
    IL_0075:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_007a:  brtrue.s   IL_009f

    IL_007c:  ldloc.1
    IL_007d:  ldstr      "MOLE-PCT"
    IL_0082:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0087:  brtrue.s   IL_00a7

    IL_0089:  ldloc.1
    IL_008a:  ldstr      "MASS-PCT"
    IL_008f:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0094:  brtrue.s   IL_00af

    IL_0096:  ret

    IL_0097:  ldarg.2
    IL_0098:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_MoleFraction()
    IL_009d:  stind.ref
    IL_009e:  ret

    IL_009f:  ldarg.2
    IL_00a0:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_MassFraction()
    IL_00a5:  stind.ref
    IL_00a6:  ret

    IL_00a7:  ldarg.2
    IL_00a8:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_MolePercent()
    IL_00ad:  stind.ref
    IL_00ae:  ret

    IL_00af:  ldarg.2
    IL_00b0:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_MassPercent()
    IL_00b5:  stind.ref
    IL_00b6:  ret
  } // end of method PLDataHelper::DetermineMoleType

  .method public hidebysig instance string 
          Join(class [mscorlib]System.Collections.Generic.List`1<string> xW,
               string sFill,
               bool bTrail) cil managed
  {
    // Code size       111 (0x6f)
    .maxstack  3
    .locals init (string V_0,
             int32 V_1)
    IL_0000:  ldstr      ""
    IL_0005:  stloc.0
    IL_0006:  ldc.i4.0
    IL_0007:  stloc.1
    IL_0008:  br.s       IL_0064

    IL_000a:  ldarg.1
    IL_000b:  ldloc.1
    IL_000c:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_0011:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0016:  brtrue.s   IL_0047

    IL_0018:  ldloc.0
    IL_0019:  ldarg.1
    IL_001a:  ldloc.1
    IL_001b:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_0020:  callvirt   instance string [mscorlib]System.String::ToUpper()
    IL_0025:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_002a:  stloc.0
    IL_002b:  ldloc.1
    IL_002c:  ldarg.1
    IL_002d:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_0032:  ldc.i4.1
    IL_0033:  sub
    IL_0034:  ceq
    IL_0036:  ldc.i4.0
    IL_0037:  ceq
    IL_0039:  ldarg.3
    IL_003a:  or
    IL_003b:  brfalse.s  IL_0060

    IL_003d:  ldloc.0
    IL_003e:  ldarg.2
    IL_003f:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0044:  stloc.0
    IL_0045:  br.s       IL_0060

    IL_0047:  ldloc.1
    IL_0048:  ldarg.1
    IL_0049:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_004e:  ldc.i4.1
    IL_004f:  sub
    IL_0050:  ceq
    IL_0052:  ldarg.3
    IL_0053:  and
    IL_0054:  brfalse.s  IL_0060

    IL_0056:  ldloc.0
    IL_0057:  callvirt   instance int32 [mscorlib]System.String::get_Length()
    IL_005c:  brtrue.s   IL_0060

    IL_005e:  ldarg.2
    IL_005f:  stloc.0
    IL_0060:  ldloc.1
    IL_0061:  ldc.i4.1
    IL_0062:  add
    IL_0063:  stloc.1
    IL_0064:  ldloc.1
    IL_0065:  ldarg.1
    IL_0066:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_006b:  blt.s      IL_000a

    IL_006d:  ldloc.0
    IL_006e:  ret
  } // end of method PLDataHelper::Join

} // end of class WpfPLData.PLDataHelper

.class public auto ansi beforefieldinit WpfPLData.DataPlotWizardModule
       extends [WpfPlotWizardsHelper]WpfPlotWizardsHelper.PlotModuleBase
{
  .custom instance void [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.RibbonPlotWizardMgrAttribute::.ctor(string,
                                                                                                                                   class [mscorlib]System.Type) = ( 01 00 1D 57 70 66 50 4C 44 41 54 41 2E 52 69 62   // ...WpfPLDATA.Rib
                                                                                                                                                                    62 6F 6E 50 6C 6F 74 57 69 7A 61 72 64 4D 67 72   // bonPlotWizardMgr
                                                                                                                                                                    1D 57 70 66 50 4C 44 61 74 61 2E 52 69 62 62 6F   // .WpfPLData.Ribbo
                                                                                                                                                                    6E 50 6C 6F 74 57 69 7A 61 72 64 4D 67 72 00 00 ) // nPlotWizardMgr..
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [WpfPlotWizardsHelper]WpfPlotWizardsHelper.PlotModuleBase::.ctor()
    IL_0006:  ret
  } // end of method DataPlotWizardModule::.ctor

} // end of class WpfPLData.DataPlotWizardModule

.class public auto ansi beforefieldinit WpfPLData.Triangle
       extends [mscorlib]System.Object
       implements [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 12 57 70 66 50 4C 44 61 74 61 2E 54 72 69   // ...WpfPLData.Tri
                                                                                                    61 6E 67 6C 65 00 00 )                            // angle..
  .class abstract auto ansi sealed nested private beforefieldinit '<>o__67'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__0'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__1'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__2'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__3'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__4'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__5'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__6'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> '<>p__7'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__8'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__9'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> '<>p__10'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__11'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__12'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> '<>p__13'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__14'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__15'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__16'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__17'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__18'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__19'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__20'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__21'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> '<>p__22'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__23'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__24'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> '<>p__25'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__26'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> '<>p__27'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> '<>p__28'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> '<>p__29'
  } // end of class '<>o__67'

  .class abstract auto ansi sealed nested private beforefieldinit '<>o__72'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> '<>p__0'
  } // end of class '<>o__72'

  .field private class AspenTech.AspenPlus.Happ.IHNode _context
  .field private class AspenTech.AspenPlus.Happ.IHWizardPlot _wizardPlot
  .field private class WpfPLData.PLDataHelper _help
  .field private string _uniqueId
  .field private string _plotName
  .field private object _nodeCxs
  .field private class [System.Drawing]System.Drawing.Image _imgIcon
  .field private bool _bHasInputDialog
  .field private string _component1
  .field private string _component2
  .field private string _component3
  .field private string[] VarNames
  .field private int32[] DataElement
  .field private string MoleMass
  .field private string MoleType
  .field private int32 TempElement
  .field private string TempUnit
  .field private int32 PresElement
  .field private string PresUnit
  .field private int32 PlotType
  .field private class [mscorlib]System.Collections.Generic.List`1<string> ComponentList
  .field private int32[] Xc
  .field private int32[] X2c
  .field private int32[] Yc
  .field private bool _bCheckDataOnly
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       97 (0x61)
    .maxstack  3
    .locals init (class [mscorlib]System.IO.Stream V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "PlotWiz.hlp"
    IL_0006:  ldc.i4.s   108
    IL_0008:  conv.i8
    IL_0009:  newobj     instance void WpfPLData.PLDataHelper::.ctor(string,
                                                                     int64)
    IL_000e:  stfld      class WpfPLData.PLDataHelper WpfPLData.Triangle::_help
    IL_0013:  ldarg.0
    IL_0014:  ldstr      "Data_Triangle"
    IL_0019:  stfld      string WpfPLData.Triangle::_uniqueId
    IL_001e:  ldarg.0
    IL_001f:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0024:  ldarg.0
    IL_0025:  ldc.i4.0
    IL_0026:  stfld      bool WpfPLData.Triangle::_bHasInputDialog
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class [System.Drawing]System.Drawing.Image WpfPLData.Triangle::_imgIcon
    IL_0031:  brtrue.s   IL_0060

    IL_0033:  call       class [mscorlib]System.Reflection.Assembly [mscorlib]System.Reflection.Assembly::GetExecutingAssembly()
    IL_0038:  pop
    IL_0039:  call       class [mscorlib]System.Reflection.Assembly [mscorlib]System.Reflection.Assembly::GetExecutingAssembly()
    IL_003e:  ldarg.0
    IL_003f:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Triangle::_help
    IL_0044:  ldstr      ""
    IL_0049:  callvirt   instance string WpfPLData.PLDataHelper::GetIconResource(string)
    IL_004e:  callvirt   instance class [mscorlib]System.IO.Stream [mscorlib]System.Reflection.Assembly::GetManifestResourceStream(string)
    IL_0053:  stloc.0
    IL_0054:  ldarg.0
    IL_0055:  ldloc.0
    IL_0056:  newobj     instance void [System.Drawing]System.Drawing.Bitmap::.ctor(class [mscorlib]System.IO.Stream)
    IL_005b:  stfld      class [System.Drawing]System.Drawing.Image WpfPLData.Triangle::_imgIcon
    IL_0060:  ret
  } // end of method Triangle::.ctor

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipContentForRibbonItem() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_TooltipContentForRibbonItem
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipContentForRibbonItem_Triangular()
    IL_0005:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipContentForRibbonItem

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipHeaderForRibbonItem() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_TooltipHeaderForRibbonItem
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TooltipHeaderForRibbonItem_Triangular()
    IL_0005:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipHeaderForRibbonItem

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TagID() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_TagID
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string WpfPLData.Triangle::_uniqueId
    IL_0006:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TagID

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_TagID(string 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_TagID
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string WpfPLData.Triangle::_uniqueId
    IL_0007:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_TagID

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_Name() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_Name
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string WpfPLData.Triangle::_plotName
    IL_0006:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_Name

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_Name(string 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_Name
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string WpfPLData.Triangle::_plotName
    IL_0007:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_Name

  .method private hidebysig newslot specialname virtual final 
          instance object  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_WizardPlot() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_WizardPlot
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_0006:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_WizardPlot

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_WizardPlot(object 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_WizardPlot
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  isinst     AspenTech.AspenPlus.Happ.IHWizardPlot
    IL_0007:  stfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_000c:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_WizardPlot

  .method private hidebysig newslot specialname virtual final 
          instance object  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_CxsNode() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_CxsNode
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object WpfPLData.Triangle::_nodeCxs
    IL_0006:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_CxsNode

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_CxsNode(object 'value') cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::set_CxsNode
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      object WpfPLData.Triangle::_nodeCxs
    IL_0007:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_CxsNode

  .method private hidebysig newslot specialname virtual final 
          instance class [System.Drawing]System.Drawing.Image 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_ImageIcon() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_ImageIcon
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System.Drawing]System.Drawing.Image WpfPLData.Triangle::_imgIcon
    IL_0006:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_ImageIcon

  .method private hidebysig newslot specialname virtual final 
          instance bool  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HasInputDialog() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_HasInputDialog
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool WpfPLData.Triangle::_bHasInputDialog
    IL_0006:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HasInputDialog

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpFile() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_HelpFile
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Triangle::_help
    IL_0006:  callvirt   instance string [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper::GetHelpFileName()
    IL_000b:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpFile

  .method private hidebysig newslot specialname virtual final 
          instance int64  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpID() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_HelpID
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Triangle::_help
    IL_0006:  callvirt   instance int64 [WpfPlotWizardsHelper]WpfPlotwizard.PlotwizardHelper::GetHelpID()
    IL_000b:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpID

  .method private hidebysig newslot specialname virtual final 
          instance class [mscorlib]System.Collections.Generic.List`1<string> 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedDataFields() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_SupportedDataFields
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0005:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedDataFields

  .method private hidebysig newslot specialname virtual final 
          instance class [mscorlib]System.Collections.Generic.List`1<string> 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedStyleFields() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::get_SupportedStyleFields
    // Code size       39 (0x27)
    .maxstack  8
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0005:  dup
    IL_0006:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component1_Title()
    IL_000b:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0010:  dup
    IL_0011:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component2_Title()
    IL_0016:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_001b:  dup
    IL_001c:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component3_Title()
    IL_0021:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0026:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedStyleFields

  .method private hidebysig newslot virtual final 
          instance class [mscorlib]System.Collections.Generic.List`1<string> 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.FieldDataOptionList(string sFieldName) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::FieldDataOptionList
    // Code size       2 (0x2)
    .maxstack  8
    IL_0000:  ldnull
    IL_0001:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.FieldDataOptionList

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldData(string sFieldName,
                                                                                               string& sCurrentVal) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetFieldData
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldData(string sFieldName,
                                                                                               string sValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::SetFieldData
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ShowInputDialog() cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::ShowInputDialog
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ShowInputDialog

  .method private hidebysig newslot virtual final 
          instance valuetype [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.RibbonControlType 
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldCtrlType(string sField) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetFieldCtrlType
    // Code size       47 (0x2f)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component1_Title()
    IL_0006:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_000b:  brtrue.s   IL_000f

    IL_000d:  ldc.i4.3
    IL_000e:  ret

    IL_000f:  ldarg.1
    IL_0010:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component2_Title()
    IL_0015:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_001a:  brtrue.s   IL_001e

    IL_001c:  ldc.i4.3
    IL_001d:  ret

    IL_001e:  ldarg.1
    IL_001f:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component3_Title()
    IL_0024:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_0029:  brtrue.s   IL_002d

    IL_002b:  ldc.i4.3
    IL_002c:  ret

    IL_002d:  ldc.i4.0
    IL_002e:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldCtrlType

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldStyle(string sFieldName,
                                                                                                string& sCurrentVal) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetFieldStyle
    // Code size       64 (0x40)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component1_Title()
    IL_0006:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_000b:  brtrue.s   IL_0015

    IL_000d:  ldarg.2
    IL_000e:  ldarg.0
    IL_000f:  ldfld      string WpfPLData.Triangle::_component1
    IL_0014:  stind.ref
    IL_0015:  ldarg.1
    IL_0016:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component2_Title()
    IL_001b:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_0020:  brtrue.s   IL_002a

    IL_0022:  ldarg.2
    IL_0023:  ldarg.0
    IL_0024:  ldfld      string WpfPLData.Triangle::_component2
    IL_0029:  stind.ref
    IL_002a:  ldarg.1
    IL_002b:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component3_Title()
    IL_0030:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_0035:  brtrue.s   IL_003f

    IL_0037:  ldarg.2
    IL_0038:  ldarg.0
    IL_0039:  ldfld      string WpfPLData.Triangle::_component3
    IL_003e:  stind.ref
    IL_003f:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetFieldStyle

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldStyle(string sFieldName,
                                                                                                string sValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::SetFieldStyle
    // Code size       70 (0x46)
    .maxstack  3
    IL_0000:  ldc.i4.0
    IL_0001:  ldarg.1
    IL_0002:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component1_Title()
    IL_0007:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_000c:  brtrue.s   IL_0015

    IL_000e:  ldarg.0
    IL_000f:  ldarg.2
    IL_0010:  stfld      string WpfPLData.Triangle::_component1
    IL_0015:  ldarg.1
    IL_0016:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component2_Title()
    IL_001b:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_0020:  brtrue.s   IL_0029

    IL_0022:  ldarg.0
    IL_0023:  ldarg.2
    IL_0024:  stfld      string WpfPLData.Triangle::_component2
    IL_0029:  ldarg.1
    IL_002a:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Component3_Title()
    IL_002f:  callvirt   instance int32 [mscorlib]System.String::CompareTo(string)
    IL_0034:  brtrue.s   IL_003d

    IL_0036:  ldarg.0
    IL_0037:  ldarg.2
    IL_0038:  stfld      string WpfPLData.Triangle::_component3
    IL_003d:  brfalse.s  IL_0045

    IL_003f:  ldarg.0
    IL_0040:  call       instance void WpfPLData.Triangle::UpdateWizardData()
    IL_0045:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetFieldStyle

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetConfigData(string& sConfigValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::GetConfigData
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.GetConfigData

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetConfigData(string sValue) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::SetConfigData
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SetConfigData

  .method public hidebysig newslot specialname virtual final 
          instance bool  get_CheckDataOnly() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool WpfPLData.Triangle::_bCheckDataOnly
    IL_0006:  ret
  } // end of method Triangle::get_CheckDataOnly

  .method public hidebysig newslot specialname virtual final 
          instance void  set_CheckDataOnly(bool 'value') cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool WpfPLData.Triangle::_bCheckDataOnly
    IL_0007:  ret
  } // end of method Triangle::set_CheckDataOnly

  .method private hidebysig newslot virtual final 
          instance void  AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Context(object HNode,
                                                                                          object& HWizardPlot,
                                                                                          int32& ierror) cil managed
  {
    .override [AspenTech.AspenPlus.Infrastructure]AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType::Context
    // Code size       313 (0x139)
    .maxstack  5
    .locals init (string V_0,
             valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<string> V_1,
             string V_2)
    IL_0000:  ldarg.2
    IL_0001:  ldind.ref
    IL_0002:  brfalse.s  IL_0007

    IL_0004:  ldarg.1
    IL_0005:  brtrue.s   IL_000b

    IL_0007:  ldarg.3
    IL_0008:  ldc.i4.1
    IL_0009:  stind.i4
    IL_000a:  ret

    IL_000b:  ldarg.0
    IL_000c:  ldarg.1
    IL_000d:  isinst     AspenTech.AspenPlus.Happ.IHNode
    IL_0012:  stfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_0017:  ldarg.0
    IL_0018:  ldarg.2
    IL_0019:  ldind.ref
    IL_001a:  isinst     AspenTech.AspenPlus.Happ.IHWizardPlot
    IL_001f:  stfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_0024:  ldarg.0
    IL_0025:  ldc.i4.3
    IL_0026:  newarr     [mscorlib]System.String
    IL_002b:  dup
    IL_002c:  ldc.i4.0
    IL_002d:  ldstr      "Input/CIDS"
    IL_0032:  stelem.ref
    IL_0033:  dup
    IL_0034:  ldc.i4.1
    IL_0035:  ldstr      "Input/USE"
    IL_003a:  stelem.ref
    IL_003b:  dup
    IL_003c:  ldc.i4.2
    IL_003d:  ldstr      "Input/VALUE"
    IL_0042:  stelem.ref
    IL_0043:  stfld      string[] WpfPLData.Triangle::VarNames
    IL_0048:  ldarg.0
    IL_0049:  call       instance bool WpfPLData.Triangle::Build_CandidateList()
    IL_004e:  brtrue.s   IL_0054

    IL_0050:  ldarg.3
    IL_0051:  ldc.i4.1
    IL_0052:  stind.i4
    IL_0053:  ret

    IL_0054:  ldarg.0
    IL_0055:  call       instance bool WpfPLData.Triangle::IsMixture()
    IL_005a:  brfalse.s  IL_0074

    IL_005c:  ldarg.0
    IL_005d:  ldarg.0
    IL_005e:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_0063:  ldarg.0
    IL_0064:  ldflda     string WpfPLData.Triangle::MoleMass
    IL_0069:  ldarg.0
    IL_006a:  ldflda     string WpfPLData.Triangle::MoleType
    IL_006f:  call       instance void WpfPLData.Triangle::DetermineMoleType(class AspenTech.AspenPlus.Happ.IHNode,
                                                                             string&,
                                                                             string&)
    IL_0074:  ldarg.0
    IL_0075:  call       instance void WpfPLData.Triangle::Build_Node_Lookup()
    IL_007a:  ldarg.0
    IL_007b:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_0080:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0085:  ldc.i4.0
    IL_0086:  ldc.i4.0
    IL_0087:  ldsfld     object [mscorlib]System.Type::Missing
    IL_008c:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_0091:  pop
    IL_0092:  ldstr      ""
    IL_0097:  stloc.0
    IL_0098:  ldarg.0
    IL_0099:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::ComponentList
    IL_009e:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<string>::GetEnumerator()
    IL_00a3:  stloc.1
    .try
    {
      IL_00a4:  br.s       IL_00c3

      IL_00a6:  ldloca.s   V_1
      IL_00a8:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<string>::get_Current()
      IL_00ad:  stloc.2
      IL_00ae:  ldloc.2
      IL_00af:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
      IL_00b4:  brtrue.s   IL_00c3

      IL_00b6:  ldloc.0
      IL_00b7:  ldloc.2
      IL_00b8:  ldstr      " "
      IL_00bd:  call       string [mscorlib]System.String::Concat(string,
                                                                  string,
                                                                  string)
      IL_00c2:  stloc.0
      IL_00c3:  ldloca.s   V_1
      IL_00c5:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<string>::MoveNext()
      IL_00ca:  brtrue.s   IL_00a6

      IL_00cc:  leave.s    IL_00dc

    }  // end .try
    finally
    {
      IL_00ce:  ldloca.s   V_1
      IL_00d0:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<string>
      IL_00d6:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_00db:  endfinally
    }  // end handler
    IL_00dc:  ldarg.0
    IL_00dd:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_00e2:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_00e7:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_TriangularTitle()
    IL_00ec:  ldloc.0
    IL_00ed:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_00f2:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
    IL_00f7:  ldarg.0
    IL_00f8:  ldarg.0
    IL_00f9:  ldfld      string WpfPLData.Triangle::MoleType
    IL_00fe:  ldarg.0
    IL_00ff:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::ComponentList
    IL_0104:  ldc.i4.0
    IL_0105:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_010a:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_010f:  stfld      string WpfPLData.Triangle::_component1
    IL_0114:  ldarg.0
    IL_0115:  ldarg.0
    IL_0116:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::ComponentList
    IL_011b:  ldc.i4.1
    IL_011c:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_0121:  stfld      string WpfPLData.Triangle::_component2
    IL_0126:  ldarg.0
    IL_0127:  ldarg.0
    IL_0128:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::ComponentList
    IL_012d:  ldc.i4.2
    IL_012e:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.List`1<string>::get_Item(int32)
    IL_0133:  stfld      string WpfPLData.Triangle::_component3
    IL_0138:  ret
  } // end of method Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Context

  .method public hidebysig newslot virtual final 
          instance void  UpdateWizardData() cil managed
  {
    // Code size       4460 (0x116c)
    .maxstack  13
    .locals init (class AspenTech.AspenPlus.Happ.IHNode V_0,
             int32 V_1,
             int32 V_2,
             int32 V_3,
             bool[] V_4,
             int32 V_5,
             int32 V_6,
             int32 V_7,
             class AspenTech.AspenPlus.Happ.IHNode V_8,
             float64 V_9,
             float64 V_10,
             float64 V_11,
             class AspenTech.AspenPlus.Happ.IHNode V_12,
             float64 V_13,
             float64 V_14,
             float64 V_15,
             int32 V_16,
             int32 V_17,
             class AspenTech.AspenPlus.Happ.IHNode V_18,
             float64 V_19,
             float64 V_20,
             float64 V_21,
             class AspenTech.AspenPlus.Happ.IHNode V_22,
             float64 V_23,
             float64 V_24,
             float64 V_25)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_0006:  ldarg.0
    IL_0007:  ldfld      string[] WpfPLData.Triangle::VarNames
    IL_000c:  ldc.i4.2
    IL_000d:  ldelem.ref
    IL_000e:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_0013:  stloc.0
    IL_0014:  ldloc.0
    IL_0015:  brtrue.s   IL_0018

    IL_0017:  ret

    IL_0018:  ldc.i4.0
    IL_0019:  stloc.1
    IL_001a:  ldc.i4.0
    IL_001b:  stloc.2
    IL_001c:  ldarg.0
    IL_001d:  ldfld      int32[] WpfPLData.Triangle::Xc
    IL_0022:  ldc.i4.0
    IL_0023:  ldelem.i4
    IL_0024:  ldc.i4.m1
    IL_0025:  beq.s      IL_0034

    IL_0027:  ldloc.1
    IL_0028:  ldc.i4.1
    IL_0029:  add
    IL_002a:  stloc.1
    IL_002b:  ldarg.0
    IL_002c:  ldfld      int32[] WpfPLData.Triangle::DataElement
    IL_0031:  ldlen
    IL_0032:  conv.i4
    IL_0033:  stloc.2
    IL_0034:  ldarg.0
    IL_0035:  ldfld      int32[] WpfPLData.Triangle::X2c
    IL_003a:  ldc.i4.0
    IL_003b:  ldelem.i4
    IL_003c:  ldc.i4.m1
    IL_003d:  beq.s      IL_004c

    IL_003f:  ldloc.1
    IL_0040:  ldc.i4.1
    IL_0041:  add
    IL_0042:  stloc.1
    IL_0043:  ldarg.0
    IL_0044:  ldfld      int32[] WpfPLData.Triangle::DataElement
    IL_0049:  ldlen
    IL_004a:  conv.i4
    IL_004b:  stloc.2
    IL_004c:  ldarg.0
    IL_004d:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_0052:  callvirt   instance void AspenTech.AspenPlus.Happ.IHWizardPlot::RemoveAllDependentVariable()
    IL_0057:  ldarg.0
    IL_0058:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_005d:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0062:  ldloc.1
    IL_0063:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NVariables(int32)
    IL_0068:  ldarg.0
    IL_0069:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_006e:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0073:  ldloc.1
    IL_0074:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NXVariables(int32)
    IL_0079:  ldarg.0
    IL_007a:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_007f:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0084:  ldloc.2
    IL_0085:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NPoints(int32)
    IL_008a:  ldarg.0
    IL_008b:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_0090:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0095:  ldc.i4.2
    IL_0096:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_PlotType(int32)
    IL_009b:  ldc.i4.0
    IL_009c:  stloc.3
    IL_009d:  ldloc.1
    IL_009e:  newarr     [mscorlib]System.Boolean
    IL_00a3:  stloc.s    V_4
    IL_00a5:  ldc.i4.0
    IL_00a6:  stloc.s    V_5
    IL_00a8:  br.s       IL_00b6

    IL_00aa:  ldloc.s    V_4
    IL_00ac:  ldloc.s    V_5
    IL_00ae:  ldc.i4.0
    IL_00af:  stelem.i1
    IL_00b0:  ldloc.s    V_5
    IL_00b2:  ldc.i4.1
    IL_00b3:  add
    IL_00b4:  stloc.s    V_5
    IL_00b6:  ldloc.s    V_5
    IL_00b8:  ldloc.1
    IL_00b9:  blt.s      IL_00aa

    IL_00bb:  ldarg.0
    IL_00bc:  ldfld      int32[] WpfPLData.Triangle::Xc
    IL_00c1:  ldc.i4.0
    IL_00c2:  ldelem.i4
    IL_00c3:  ldc.i4.m1
    IL_00c4:  beq        IL_08ec

    IL_00c9:  ldloc.s    V_4
    IL_00cb:  ldloc.3
    IL_00cc:  ldelem.u1
    IL_00cd:  brtrue.s   IL_00fd

    IL_00cf:  ldarg.0
    IL_00d0:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_00d5:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_00da:  ldloc.3
    IL_00db:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_X1()
    IL_00e0:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_00e5:  ldarg.0
    IL_00e6:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_00eb:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_00f0:  ldloc.3
    IL_00f1:  ldc.i4.s   15
    IL_00f3:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_00f8:  ldloc.s    V_4
    IL_00fa:  ldloc.3
    IL_00fb:  ldc.i4.1
    IL_00fc:  stelem.i1
    IL_00fd:  ldc.i4.0
    IL_00fe:  stloc.s    V_6
    IL_0100:  br         IL_08d9

    IL_0105:  ldloc.s    V_6
    IL_0107:  stloc.s    V_7
    .try
    {
      IL_0109:  ldarg.0
      IL_010a:  ldfld      string WpfPLData.Triangle::MoleMass
      IL_010f:  ldstr      "fraction"
      IL_0114:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                     string)
      IL_0119:  brfalse    IL_047c

      IL_011e:  ldloc.0
      IL_011f:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0124:  ldarg.0
      IL_0125:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_012a:  ldloc.s    V_7
      IL_012c:  ldelem.i4
      IL_012d:  box        [mscorlib]System.Int32
      IL_0132:  ldarg.0
      IL_0133:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_0138:  ldc.i4.0
      IL_0139:  ldelem.i4
      IL_013a:  box        [mscorlib]System.Int32
      IL_013f:  ldarg.0
      IL_0140:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_0145:  ldc.i4.0
      IL_0146:  ldelem.i4
      IL_0147:  box        [mscorlib]System.Int32
      IL_014c:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0151:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0156:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_015b:  stloc.s    V_8
      IL_015d:  ldloc.s    V_8
      IL_015f:  brfalse    IL_023b

      IL_0164:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__1'
      IL_0169:  brtrue.s   IL_018f

      IL_016b:  ldc.i4.0
      IL_016c:  ldtoken    [mscorlib]System.Double
      IL_0171:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0176:  ldtoken    WpfPLData.Triangle
      IL_017b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0180:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_0185:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_018a:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__1'
      IL_018f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__1'
      IL_0194:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_0199:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__1'
      IL_019e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__0'
      IL_01a3:  brtrue.s   IL_01ea

      IL_01a5:  ldc.i4.0
      IL_01a6:  ldstr      "Parse"
      IL_01ab:  ldnull
      IL_01ac:  ldtoken    WpfPLData.Triangle
      IL_01b1:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_01b6:  ldc.i4.3
      IL_01b7:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_01bc:  dup
      IL_01bd:  ldc.i4.0
      IL_01be:  ldc.i4.s   33
      IL_01c0:  ldnull
      IL_01c1:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_01c6:  stelem.ref
      IL_01c7:  dup
      IL_01c8:  ldc.i4.1
      IL_01c9:  ldc.i4.0
      IL_01ca:  ldnull
      IL_01cb:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_01d0:  stelem.ref
      IL_01d1:  dup
      IL_01d2:  ldc.i4.2
      IL_01d3:  ldc.i4.1
      IL_01d4:  ldnull
      IL_01d5:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_01da:  stelem.ref
      IL_01db:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_01e0:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_01e5:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__0'
      IL_01ea:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__0'
      IL_01ef:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_01f4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__0'
      IL_01f9:  ldtoken    [mscorlib]System.Double
      IL_01fe:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0203:  ldloc.s    V_8
      IL_0205:  ldsfld     object [mscorlib]System.Type::Missing
      IL_020a:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_020f:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_0214:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_0219:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_021e:  stloc.s    V_9
      IL_0220:  ldarg.0
      IL_0221:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_0226:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_022b:  ldloc.3
      IL_022c:  ldloc.s    V_7
      IL_022e:  ldc.i4.0
      IL_022f:  ldloc.s    V_9
      IL_0231:  box        [mscorlib]System.Double
      IL_0236:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_023b:  ldloc.0
      IL_023c:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0241:  ldarg.0
      IL_0242:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_0247:  ldloc.s    V_7
      IL_0249:  ldelem.i4
      IL_024a:  box        [mscorlib]System.Int32
      IL_024f:  ldarg.0
      IL_0250:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_0255:  ldc.i4.1
      IL_0256:  ldelem.i4
      IL_0257:  box        [mscorlib]System.Int32
      IL_025c:  ldarg.0
      IL_025d:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_0262:  ldc.i4.1
      IL_0263:  ldelem.i4
      IL_0264:  box        [mscorlib]System.Int32
      IL_0269:  ldsfld     object [mscorlib]System.Type::Missing
      IL_026e:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0273:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0278:  stloc.s    V_8
      IL_027a:  ldloc.s    V_8
      IL_027c:  brfalse    IL_0358

      IL_0281:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__3'
      IL_0286:  brtrue.s   IL_02ac

      IL_0288:  ldc.i4.0
      IL_0289:  ldtoken    [mscorlib]System.Double
      IL_028e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0293:  ldtoken    WpfPLData.Triangle
      IL_0298:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_029d:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_02a2:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_02a7:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__3'
      IL_02ac:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__3'
      IL_02b1:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_02b6:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__3'
      IL_02bb:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__2'
      IL_02c0:  brtrue.s   IL_0307

      IL_02c2:  ldc.i4.0
      IL_02c3:  ldstr      "Parse"
      IL_02c8:  ldnull
      IL_02c9:  ldtoken    WpfPLData.Triangle
      IL_02ce:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_02d3:  ldc.i4.3
      IL_02d4:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_02d9:  dup
      IL_02da:  ldc.i4.0
      IL_02db:  ldc.i4.s   33
      IL_02dd:  ldnull
      IL_02de:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_02e3:  stelem.ref
      IL_02e4:  dup
      IL_02e5:  ldc.i4.1
      IL_02e6:  ldc.i4.0
      IL_02e7:  ldnull
      IL_02e8:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_02ed:  stelem.ref
      IL_02ee:  dup
      IL_02ef:  ldc.i4.2
      IL_02f0:  ldc.i4.1
      IL_02f1:  ldnull
      IL_02f2:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_02f7:  stelem.ref
      IL_02f8:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_02fd:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0302:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__2'
      IL_0307:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__2'
      IL_030c:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_0311:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__2'
      IL_0316:  ldtoken    [mscorlib]System.Double
      IL_031b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0320:  ldloc.s    V_8
      IL_0322:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0327:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_032c:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_0331:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_0336:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_033b:  stloc.s    V_10
      IL_033d:  ldarg.0
      IL_033e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_0343:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_0348:  ldloc.3
      IL_0349:  ldloc.s    V_7
      IL_034b:  ldc.i4.0
      IL_034c:  ldloc.s    V_10
      IL_034e:  box        [mscorlib]System.Double
      IL_0353:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_0358:  ldloc.0
      IL_0359:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_035e:  ldarg.0
      IL_035f:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_0364:  ldloc.s    V_7
      IL_0366:  ldelem.i4
      IL_0367:  box        [mscorlib]System.Int32
      IL_036c:  ldarg.0
      IL_036d:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_0372:  ldc.i4.2
      IL_0373:  ldelem.i4
      IL_0374:  box        [mscorlib]System.Int32
      IL_0379:  ldarg.0
      IL_037a:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_037f:  ldc.i4.2
      IL_0380:  ldelem.i4
      IL_0381:  box        [mscorlib]System.Int32
      IL_0386:  ldsfld     object [mscorlib]System.Type::Missing
      IL_038b:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0390:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0395:  stloc.s    V_8
      IL_0397:  ldloc.s    V_8
      IL_0399:  brfalse    IL_08ce

      IL_039e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__5'
      IL_03a3:  brtrue.s   IL_03c9

      IL_03a5:  ldc.i4.0
      IL_03a6:  ldtoken    [mscorlib]System.Double
      IL_03ab:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_03b0:  ldtoken    WpfPLData.Triangle
      IL_03b5:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_03ba:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_03bf:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_03c4:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__5'
      IL_03c9:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__5'
      IL_03ce:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_03d3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__5'
      IL_03d8:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__4'
      IL_03dd:  brtrue.s   IL_0424

      IL_03df:  ldc.i4.0
      IL_03e0:  ldstr      "Parse"
      IL_03e5:  ldnull
      IL_03e6:  ldtoken    WpfPLData.Triangle
      IL_03eb:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_03f0:  ldc.i4.3
      IL_03f1:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_03f6:  dup
      IL_03f7:  ldc.i4.0
      IL_03f8:  ldc.i4.s   33
      IL_03fa:  ldnull
      IL_03fb:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0400:  stelem.ref
      IL_0401:  dup
      IL_0402:  ldc.i4.1
      IL_0403:  ldc.i4.0
      IL_0404:  ldnull
      IL_0405:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_040a:  stelem.ref
      IL_040b:  dup
      IL_040c:  ldc.i4.2
      IL_040d:  ldc.i4.1
      IL_040e:  ldnull
      IL_040f:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0414:  stelem.ref
      IL_0415:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_041a:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_041f:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__4'
      IL_0424:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__4'
      IL_0429:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_042e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__4'
      IL_0433:  ldtoken    [mscorlib]System.Double
      IL_0438:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_043d:  ldloc.s    V_8
      IL_043f:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0444:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_0449:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_044e:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_0453:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_0458:  stloc.s    V_11
      IL_045a:  ldarg.0
      IL_045b:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_0460:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_0465:  ldloc.3
      IL_0466:  ldc.i4.1
      IL_0467:  add
      IL_0468:  ldloc.s    V_7
      IL_046a:  ldc.i4.0
      IL_046b:  ldloc.s    V_11
      IL_046d:  box        [mscorlib]System.Double
      IL_0472:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_0477:  br         IL_08ce

      IL_047c:  ldloc.0
      IL_047d:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0482:  ldarg.0
      IL_0483:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_0488:  ldloc.s    V_7
      IL_048a:  ldelem.i4
      IL_048b:  box        [mscorlib]System.Int32
      IL_0490:  ldarg.0
      IL_0491:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_0496:  ldc.i4.0
      IL_0497:  ldelem.i4
      IL_0498:  box        [mscorlib]System.Int32
      IL_049d:  ldarg.0
      IL_049e:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_04a3:  ldc.i4.0
      IL_04a4:  ldelem.i4
      IL_04a5:  box        [mscorlib]System.Int32
      IL_04aa:  ldsfld     object [mscorlib]System.Type::Missing
      IL_04af:  ldsfld     object [mscorlib]System.Type::Missing
      IL_04b4:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_04b9:  stloc.s    V_12
      IL_04bb:  ldloc.s    V_12
      IL_04bd:  brfalse    IL_05ec

      IL_04c2:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__8'
      IL_04c7:  brtrue.s   IL_04ed

      IL_04c9:  ldc.i4.0
      IL_04ca:  ldtoken    [mscorlib]System.Double
      IL_04cf:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_04d4:  ldtoken    WpfPLData.Triangle
      IL_04d9:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_04de:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_04e3:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_04e8:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__8'
      IL_04ed:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__8'
      IL_04f2:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_04f7:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__8'
      IL_04fc:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__7'
      IL_0501:  brtrue.s   IL_0539

      IL_0503:  ldc.i4.0
      IL_0504:  ldc.i4.s   12
      IL_0506:  ldtoken    WpfPLData.Triangle
      IL_050b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0510:  ldc.i4.2
      IL_0511:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0516:  dup
      IL_0517:  ldc.i4.0
      IL_0518:  ldc.i4.0
      IL_0519:  ldnull
      IL_051a:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_051f:  stelem.ref
      IL_0520:  dup
      IL_0521:  ldc.i4.1
      IL_0522:  ldc.i4.3
      IL_0523:  ldnull
      IL_0524:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0529:  stelem.ref
      IL_052a:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_052f:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0534:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__7'
      IL_0539:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__7'
      IL_053e:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Target
      IL_0543:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__7'
      IL_0548:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__6'
      IL_054d:  brtrue.s   IL_0594

      IL_054f:  ldc.i4.0
      IL_0550:  ldstr      "Parse"
      IL_0555:  ldnull
      IL_0556:  ldtoken    WpfPLData.Triangle
      IL_055b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0560:  ldc.i4.3
      IL_0561:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0566:  dup
      IL_0567:  ldc.i4.0
      IL_0568:  ldc.i4.s   33
      IL_056a:  ldnull
      IL_056b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0570:  stelem.ref
      IL_0571:  dup
      IL_0572:  ldc.i4.1
      IL_0573:  ldc.i4.0
      IL_0574:  ldnull
      IL_0575:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_057a:  stelem.ref
      IL_057b:  dup
      IL_057c:  ldc.i4.2
      IL_057d:  ldc.i4.1
      IL_057e:  ldnull
      IL_057f:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0584:  stelem.ref
      IL_0585:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_058a:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_058f:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__6'
      IL_0594:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__6'
      IL_0599:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_059e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__6'
      IL_05a3:  ldtoken    [mscorlib]System.Double
      IL_05a8:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_05ad:  ldloc.s    V_12
      IL_05af:  ldsfld     object [mscorlib]System.Type::Missing
      IL_05b4:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_05b9:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_05be:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_05c3:  ldc.i4.s   100
      IL_05c5:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>::Invoke(!0,
                                                                                                                                                              !1,
                                                                                                                                                              !2)
      IL_05ca:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_05cf:  stloc.s    V_13
      IL_05d1:  ldarg.0
      IL_05d2:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_05d7:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_05dc:  ldloc.3
      IL_05dd:  ldloc.s    V_7
      IL_05df:  ldc.i4.0
      IL_05e0:  ldloc.s    V_13
      IL_05e2:  box        [mscorlib]System.Double
      IL_05e7:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_05ec:  ldloc.0
      IL_05ed:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_05f2:  ldarg.0
      IL_05f3:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_05f8:  ldloc.s    V_7
      IL_05fa:  ldelem.i4
      IL_05fb:  box        [mscorlib]System.Int32
      IL_0600:  ldarg.0
      IL_0601:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_0606:  ldc.i4.1
      IL_0607:  ldelem.i4
      IL_0608:  box        [mscorlib]System.Int32
      IL_060d:  ldarg.0
      IL_060e:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_0613:  ldc.i4.1
      IL_0614:  ldelem.i4
      IL_0615:  box        [mscorlib]System.Int32
      IL_061a:  ldsfld     object [mscorlib]System.Type::Missing
      IL_061f:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0624:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0629:  stloc.s    V_12
      IL_062b:  ldloc.s    V_12
      IL_062d:  brfalse    IL_075c

      IL_0632:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__11'
      IL_0637:  brtrue.s   IL_065d

      IL_0639:  ldc.i4.0
      IL_063a:  ldtoken    [mscorlib]System.Double
      IL_063f:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0644:  ldtoken    WpfPLData.Triangle
      IL_0649:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_064e:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_0653:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0658:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__11'
      IL_065d:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__11'
      IL_0662:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_0667:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__11'
      IL_066c:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__10'
      IL_0671:  brtrue.s   IL_06a9

      IL_0673:  ldc.i4.0
      IL_0674:  ldc.i4.s   12
      IL_0676:  ldtoken    WpfPLData.Triangle
      IL_067b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0680:  ldc.i4.2
      IL_0681:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0686:  dup
      IL_0687:  ldc.i4.0
      IL_0688:  ldc.i4.0
      IL_0689:  ldnull
      IL_068a:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_068f:  stelem.ref
      IL_0690:  dup
      IL_0691:  ldc.i4.1
      IL_0692:  ldc.i4.3
      IL_0693:  ldnull
      IL_0694:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0699:  stelem.ref
      IL_069a:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_069f:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_06a4:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__10'
      IL_06a9:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__10'
      IL_06ae:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Target
      IL_06b3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__10'
      IL_06b8:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__9'
      IL_06bd:  brtrue.s   IL_0704

      IL_06bf:  ldc.i4.0
      IL_06c0:  ldstr      "Parse"
      IL_06c5:  ldnull
      IL_06c6:  ldtoken    WpfPLData.Triangle
      IL_06cb:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_06d0:  ldc.i4.3
      IL_06d1:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_06d6:  dup
      IL_06d7:  ldc.i4.0
      IL_06d8:  ldc.i4.s   33
      IL_06da:  ldnull
      IL_06db:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_06e0:  stelem.ref
      IL_06e1:  dup
      IL_06e2:  ldc.i4.1
      IL_06e3:  ldc.i4.0
      IL_06e4:  ldnull
      IL_06e5:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_06ea:  stelem.ref
      IL_06eb:  dup
      IL_06ec:  ldc.i4.2
      IL_06ed:  ldc.i4.1
      IL_06ee:  ldnull
      IL_06ef:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_06f4:  stelem.ref
      IL_06f5:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_06fa:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_06ff:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__9'
      IL_0704:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__9'
      IL_0709:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_070e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__9'
      IL_0713:  ldtoken    [mscorlib]System.Double
      IL_0718:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_071d:  ldloc.s    V_12
      IL_071f:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0724:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_0729:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_072e:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_0733:  ldc.i4.s   100
      IL_0735:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>::Invoke(!0,
                                                                                                                                                              !1,
                                                                                                                                                              !2)
      IL_073a:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_073f:  stloc.s    V_14
      IL_0741:  ldarg.0
      IL_0742:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_0747:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_074c:  ldloc.3
      IL_074d:  ldloc.s    V_7
      IL_074f:  ldc.i4.0
      IL_0750:  ldloc.s    V_14
      IL_0752:  box        [mscorlib]System.Double
      IL_0757:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_075c:  ldloc.0
      IL_075d:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0762:  ldarg.0
      IL_0763:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_0768:  ldloc.s    V_7
      IL_076a:  ldelem.i4
      IL_076b:  box        [mscorlib]System.Int32
      IL_0770:  ldarg.0
      IL_0771:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_0776:  ldc.i4.2
      IL_0777:  ldelem.i4
      IL_0778:  box        [mscorlib]System.Int32
      IL_077d:  ldarg.0
      IL_077e:  ldfld      int32[] WpfPLData.Triangle::Xc
      IL_0783:  ldc.i4.2
      IL_0784:  ldelem.i4
      IL_0785:  box        [mscorlib]System.Int32
      IL_078a:  ldsfld     object [mscorlib]System.Type::Missing
      IL_078f:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0794:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0799:  stloc.s    V_12
      IL_079b:  ldloc.s    V_12
      IL_079d:  brfalse    IL_08ce

      IL_07a2:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__14'
      IL_07a7:  brtrue.s   IL_07cd

      IL_07a9:  ldc.i4.0
      IL_07aa:  ldtoken    [mscorlib]System.Double
      IL_07af:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_07b4:  ldtoken    WpfPLData.Triangle
      IL_07b9:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_07be:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_07c3:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_07c8:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__14'
      IL_07cd:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__14'
      IL_07d2:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_07d7:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__14'
      IL_07dc:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__13'
      IL_07e1:  brtrue.s   IL_0819

      IL_07e3:  ldc.i4.0
      IL_07e4:  ldc.i4.s   12
      IL_07e6:  ldtoken    WpfPLData.Triangle
      IL_07eb:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_07f0:  ldc.i4.2
      IL_07f1:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_07f6:  dup
      IL_07f7:  ldc.i4.0
      IL_07f8:  ldc.i4.0
      IL_07f9:  ldnull
      IL_07fa:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_07ff:  stelem.ref
      IL_0800:  dup
      IL_0801:  ldc.i4.1
      IL_0802:  ldc.i4.3
      IL_0803:  ldnull
      IL_0804:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0809:  stelem.ref
      IL_080a:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_080f:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0814:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__13'
      IL_0819:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__13'
      IL_081e:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Target
      IL_0823:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__13'
      IL_0828:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__12'
      IL_082d:  brtrue.s   IL_0874

      IL_082f:  ldc.i4.0
      IL_0830:  ldstr      "Parse"
      IL_0835:  ldnull
      IL_0836:  ldtoken    WpfPLData.Triangle
      IL_083b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0840:  ldc.i4.3
      IL_0841:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0846:  dup
      IL_0847:  ldc.i4.0
      IL_0848:  ldc.i4.s   33
      IL_084a:  ldnull
      IL_084b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0850:  stelem.ref
      IL_0851:  dup
      IL_0852:  ldc.i4.1
      IL_0853:  ldc.i4.0
      IL_0854:  ldnull
      IL_0855:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_085a:  stelem.ref
      IL_085b:  dup
      IL_085c:  ldc.i4.2
      IL_085d:  ldc.i4.1
      IL_085e:  ldnull
      IL_085f:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0864:  stelem.ref
      IL_0865:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_086a:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_086f:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__12'
      IL_0874:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__12'
      IL_0879:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_087e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__12'
      IL_0883:  ldtoken    [mscorlib]System.Double
      IL_0888:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_088d:  ldloc.s    V_12
      IL_088f:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0894:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_0899:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_089e:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_08a3:  ldc.i4.s   100
      IL_08a5:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>::Invoke(!0,
                                                                                                                                                              !1,
                                                                                                                                                              !2)
      IL_08aa:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_08af:  stloc.s    V_15
      IL_08b1:  ldarg.0
      IL_08b2:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_08b7:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_08bc:  ldloc.3
      IL_08bd:  ldc.i4.1
      IL_08be:  add
      IL_08bf:  ldloc.s    V_7
      IL_08c1:  ldc.i4.0
      IL_08c2:  ldloc.s    V_15
      IL_08c4:  box        [mscorlib]System.Double
      IL_08c9:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_08ce:  leave.s    IL_08d3

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_08d0:  pop
      IL_08d1:  leave.s    IL_08d3

    }  // end handler
    IL_08d3:  ldloc.s    V_6
    IL_08d5:  ldc.i4.1
    IL_08d6:  add
    IL_08d7:  stloc.s    V_6
    IL_08d9:  ldloc.s    V_6
    IL_08db:  ldarg.0
    IL_08dc:  ldfld      int32[] WpfPLData.Triangle::DataElement
    IL_08e1:  ldlen
    IL_08e2:  conv.i4
    IL_08e3:  blt        IL_0105

    IL_08e8:  ldloc.3
    IL_08e9:  ldc.i4.1
    IL_08ea:  add
    IL_08eb:  stloc.3
    IL_08ec:  ldarg.0
    IL_08ed:  ldfld      int32[] WpfPLData.Triangle::X2c
    IL_08f2:  ldc.i4.0
    IL_08f3:  ldelem.i4
    IL_08f4:  ldc.i4.m1
    IL_08f5:  beq        IL_111d

    IL_08fa:  ldloc.s    V_4
    IL_08fc:  ldloc.3
    IL_08fd:  ldelem.u1
    IL_08fe:  brtrue.s   IL_092e

    IL_0900:  ldarg.0
    IL_0901:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_0906:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_090b:  ldloc.3
    IL_090c:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_Exp_X2()
    IL_0911:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                                     string)
    IL_0916:  ldarg.0
    IL_0917:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_091c:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_0921:  ldloc.3
    IL_0922:  ldc.i4.s   15
    IL_0924:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                                          int32)
    IL_0929:  ldloc.s    V_4
    IL_092b:  ldloc.3
    IL_092c:  ldc.i4.1
    IL_092d:  stelem.i1
    IL_092e:  ldc.i4.0
    IL_092f:  stloc.s    V_16
    IL_0931:  br         IL_110a

    IL_0936:  ldloc.s    V_16
    IL_0938:  stloc.s    V_17
    .try
    {
      IL_093a:  ldarg.0
      IL_093b:  ldfld      string WpfPLData.Triangle::MoleMass
      IL_0940:  ldstr      "fraction"
      IL_0945:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                     string)
      IL_094a:  brfalse    IL_0cad

      IL_094f:  ldloc.0
      IL_0950:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0955:  ldarg.0
      IL_0956:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_095b:  ldloc.s    V_17
      IL_095d:  ldelem.i4
      IL_095e:  box        [mscorlib]System.Int32
      IL_0963:  ldarg.0
      IL_0964:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0969:  ldc.i4.0
      IL_096a:  ldelem.i4
      IL_096b:  box        [mscorlib]System.Int32
      IL_0970:  ldarg.0
      IL_0971:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0976:  ldc.i4.0
      IL_0977:  ldelem.i4
      IL_0978:  box        [mscorlib]System.Int32
      IL_097d:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0982:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0987:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_098c:  stloc.s    V_18
      IL_098e:  ldloc.s    V_18
      IL_0990:  brfalse    IL_0a6c

      IL_0995:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__16'
      IL_099a:  brtrue.s   IL_09c0

      IL_099c:  ldc.i4.0
      IL_099d:  ldtoken    [mscorlib]System.Double
      IL_09a2:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_09a7:  ldtoken    WpfPLData.Triangle
      IL_09ac:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_09b1:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_09b6:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_09bb:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__16'
      IL_09c0:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__16'
      IL_09c5:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_09ca:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__16'
      IL_09cf:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__15'
      IL_09d4:  brtrue.s   IL_0a1b

      IL_09d6:  ldc.i4.0
      IL_09d7:  ldstr      "Parse"
      IL_09dc:  ldnull
      IL_09dd:  ldtoken    WpfPLData.Triangle
      IL_09e2:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_09e7:  ldc.i4.3
      IL_09e8:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_09ed:  dup
      IL_09ee:  ldc.i4.0
      IL_09ef:  ldc.i4.s   33
      IL_09f1:  ldnull
      IL_09f2:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_09f7:  stelem.ref
      IL_09f8:  dup
      IL_09f9:  ldc.i4.1
      IL_09fa:  ldc.i4.0
      IL_09fb:  ldnull
      IL_09fc:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0a01:  stelem.ref
      IL_0a02:  dup
      IL_0a03:  ldc.i4.2
      IL_0a04:  ldc.i4.1
      IL_0a05:  ldnull
      IL_0a06:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0a0b:  stelem.ref
      IL_0a0c:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0a11:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0a16:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__15'
      IL_0a1b:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__15'
      IL_0a20:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_0a25:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__15'
      IL_0a2a:  ldtoken    [mscorlib]System.Double
      IL_0a2f:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0a34:  ldloc.s    V_18
      IL_0a36:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0a3b:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_0a40:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_0a45:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_0a4a:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_0a4f:  stloc.s    V_19
      IL_0a51:  ldarg.0
      IL_0a52:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_0a57:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_0a5c:  ldloc.3
      IL_0a5d:  ldloc.s    V_17
      IL_0a5f:  ldc.i4.0
      IL_0a60:  ldloc.s    V_19
      IL_0a62:  box        [mscorlib]System.Double
      IL_0a67:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_0a6c:  ldloc.0
      IL_0a6d:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0a72:  ldarg.0
      IL_0a73:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_0a78:  ldloc.s    V_17
      IL_0a7a:  ldelem.i4
      IL_0a7b:  box        [mscorlib]System.Int32
      IL_0a80:  ldarg.0
      IL_0a81:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0a86:  ldc.i4.1
      IL_0a87:  ldelem.i4
      IL_0a88:  box        [mscorlib]System.Int32
      IL_0a8d:  ldarg.0
      IL_0a8e:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0a93:  ldc.i4.1
      IL_0a94:  ldelem.i4
      IL_0a95:  box        [mscorlib]System.Int32
      IL_0a9a:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0a9f:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0aa4:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0aa9:  stloc.s    V_18
      IL_0aab:  ldloc.s    V_18
      IL_0aad:  brfalse    IL_0b89

      IL_0ab2:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__18'
      IL_0ab7:  brtrue.s   IL_0add

      IL_0ab9:  ldc.i4.0
      IL_0aba:  ldtoken    [mscorlib]System.Double
      IL_0abf:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0ac4:  ldtoken    WpfPLData.Triangle
      IL_0ac9:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0ace:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_0ad3:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0ad8:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__18'
      IL_0add:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__18'
      IL_0ae2:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_0ae7:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__18'
      IL_0aec:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__17'
      IL_0af1:  brtrue.s   IL_0b38

      IL_0af3:  ldc.i4.0
      IL_0af4:  ldstr      "Parse"
      IL_0af9:  ldnull
      IL_0afa:  ldtoken    WpfPLData.Triangle
      IL_0aff:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0b04:  ldc.i4.3
      IL_0b05:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0b0a:  dup
      IL_0b0b:  ldc.i4.0
      IL_0b0c:  ldc.i4.s   33
      IL_0b0e:  ldnull
      IL_0b0f:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0b14:  stelem.ref
      IL_0b15:  dup
      IL_0b16:  ldc.i4.1
      IL_0b17:  ldc.i4.0
      IL_0b18:  ldnull
      IL_0b19:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0b1e:  stelem.ref
      IL_0b1f:  dup
      IL_0b20:  ldc.i4.2
      IL_0b21:  ldc.i4.1
      IL_0b22:  ldnull
      IL_0b23:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0b28:  stelem.ref
      IL_0b29:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0b2e:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0b33:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__17'
      IL_0b38:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__17'
      IL_0b3d:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_0b42:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__17'
      IL_0b47:  ldtoken    [mscorlib]System.Double
      IL_0b4c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0b51:  ldloc.s    V_18
      IL_0b53:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0b58:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_0b5d:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_0b62:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_0b67:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_0b6c:  stloc.s    V_20
      IL_0b6e:  ldarg.0
      IL_0b6f:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_0b74:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_0b79:  ldloc.3
      IL_0b7a:  ldloc.s    V_17
      IL_0b7c:  ldc.i4.0
      IL_0b7d:  ldloc.s    V_20
      IL_0b7f:  box        [mscorlib]System.Double
      IL_0b84:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_0b89:  ldloc.0
      IL_0b8a:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0b8f:  ldarg.0
      IL_0b90:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_0b95:  ldloc.s    V_17
      IL_0b97:  ldelem.i4
      IL_0b98:  box        [mscorlib]System.Int32
      IL_0b9d:  ldarg.0
      IL_0b9e:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0ba3:  ldc.i4.2
      IL_0ba4:  ldelem.i4
      IL_0ba5:  box        [mscorlib]System.Int32
      IL_0baa:  ldarg.0
      IL_0bab:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0bb0:  ldc.i4.2
      IL_0bb1:  ldelem.i4
      IL_0bb2:  box        [mscorlib]System.Int32
      IL_0bb7:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0bbc:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0bc1:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0bc6:  stloc.s    V_18
      IL_0bc8:  ldloc.s    V_18
      IL_0bca:  brfalse    IL_10ff

      IL_0bcf:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__20'
      IL_0bd4:  brtrue.s   IL_0bfa

      IL_0bd6:  ldc.i4.0
      IL_0bd7:  ldtoken    [mscorlib]System.Double
      IL_0bdc:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0be1:  ldtoken    WpfPLData.Triangle
      IL_0be6:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0beb:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_0bf0:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0bf5:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__20'
      IL_0bfa:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__20'
      IL_0bff:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_0c04:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__20'
      IL_0c09:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__19'
      IL_0c0e:  brtrue.s   IL_0c55

      IL_0c10:  ldc.i4.0
      IL_0c11:  ldstr      "Parse"
      IL_0c16:  ldnull
      IL_0c17:  ldtoken    WpfPLData.Triangle
      IL_0c1c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0c21:  ldc.i4.3
      IL_0c22:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0c27:  dup
      IL_0c28:  ldc.i4.0
      IL_0c29:  ldc.i4.s   33
      IL_0c2b:  ldnull
      IL_0c2c:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0c31:  stelem.ref
      IL_0c32:  dup
      IL_0c33:  ldc.i4.1
      IL_0c34:  ldc.i4.0
      IL_0c35:  ldnull
      IL_0c36:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0c3b:  stelem.ref
      IL_0c3c:  dup
      IL_0c3d:  ldc.i4.2
      IL_0c3e:  ldc.i4.1
      IL_0c3f:  ldnull
      IL_0c40:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0c45:  stelem.ref
      IL_0c46:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0c4b:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0c50:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__19'
      IL_0c55:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__19'
      IL_0c5a:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_0c5f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__19'
      IL_0c64:  ldtoken    [mscorlib]System.Double
      IL_0c69:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0c6e:  ldloc.s    V_18
      IL_0c70:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0c75:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_0c7a:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_0c7f:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_0c84:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_0c89:  stloc.s    V_21
      IL_0c8b:  ldarg.0
      IL_0c8c:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_0c91:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_0c96:  ldloc.3
      IL_0c97:  ldc.i4.1
      IL_0c98:  add
      IL_0c99:  ldloc.s    V_17
      IL_0c9b:  ldc.i4.0
      IL_0c9c:  ldloc.s    V_21
      IL_0c9e:  box        [mscorlib]System.Double
      IL_0ca3:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_0ca8:  br         IL_10ff

      IL_0cad:  ldloc.0
      IL_0cae:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0cb3:  ldarg.0
      IL_0cb4:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_0cb9:  ldloc.s    V_17
      IL_0cbb:  ldelem.i4
      IL_0cbc:  box        [mscorlib]System.Int32
      IL_0cc1:  ldarg.0
      IL_0cc2:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0cc7:  ldc.i4.0
      IL_0cc8:  ldelem.i4
      IL_0cc9:  box        [mscorlib]System.Int32
      IL_0cce:  ldarg.0
      IL_0ccf:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0cd4:  ldc.i4.0
      IL_0cd5:  ldelem.i4
      IL_0cd6:  box        [mscorlib]System.Int32
      IL_0cdb:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0ce0:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0ce5:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0cea:  stloc.s    V_22
      IL_0cec:  ldloc.s    V_22
      IL_0cee:  brfalse    IL_0e1d

      IL_0cf3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__23'
      IL_0cf8:  brtrue.s   IL_0d1e

      IL_0cfa:  ldc.i4.0
      IL_0cfb:  ldtoken    [mscorlib]System.Double
      IL_0d00:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0d05:  ldtoken    WpfPLData.Triangle
      IL_0d0a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0d0f:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_0d14:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0d19:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__23'
      IL_0d1e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__23'
      IL_0d23:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_0d28:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__23'
      IL_0d2d:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__22'
      IL_0d32:  brtrue.s   IL_0d6a

      IL_0d34:  ldc.i4.0
      IL_0d35:  ldc.i4.s   12
      IL_0d37:  ldtoken    WpfPLData.Triangle
      IL_0d3c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0d41:  ldc.i4.2
      IL_0d42:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0d47:  dup
      IL_0d48:  ldc.i4.0
      IL_0d49:  ldc.i4.0
      IL_0d4a:  ldnull
      IL_0d4b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0d50:  stelem.ref
      IL_0d51:  dup
      IL_0d52:  ldc.i4.1
      IL_0d53:  ldc.i4.3
      IL_0d54:  ldnull
      IL_0d55:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0d5a:  stelem.ref
      IL_0d5b:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0d60:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0d65:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__22'
      IL_0d6a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__22'
      IL_0d6f:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Target
      IL_0d74:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__22'
      IL_0d79:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__21'
      IL_0d7e:  brtrue.s   IL_0dc5

      IL_0d80:  ldc.i4.0
      IL_0d81:  ldstr      "Parse"
      IL_0d86:  ldnull
      IL_0d87:  ldtoken    WpfPLData.Triangle
      IL_0d8c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0d91:  ldc.i4.3
      IL_0d92:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0d97:  dup
      IL_0d98:  ldc.i4.0
      IL_0d99:  ldc.i4.s   33
      IL_0d9b:  ldnull
      IL_0d9c:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0da1:  stelem.ref
      IL_0da2:  dup
      IL_0da3:  ldc.i4.1
      IL_0da4:  ldc.i4.0
      IL_0da5:  ldnull
      IL_0da6:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0dab:  stelem.ref
      IL_0dac:  dup
      IL_0dad:  ldc.i4.2
      IL_0dae:  ldc.i4.1
      IL_0daf:  ldnull
      IL_0db0:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0db5:  stelem.ref
      IL_0db6:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0dbb:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0dc0:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__21'
      IL_0dc5:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__21'
      IL_0dca:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_0dcf:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__21'
      IL_0dd4:  ldtoken    [mscorlib]System.Double
      IL_0dd9:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0dde:  ldloc.s    V_22
      IL_0de0:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0de5:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_0dea:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_0def:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_0df4:  ldc.i4.s   100
      IL_0df6:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>::Invoke(!0,
                                                                                                                                                              !1,
                                                                                                                                                              !2)
      IL_0dfb:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_0e00:  stloc.s    V_23
      IL_0e02:  ldarg.0
      IL_0e03:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_0e08:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_0e0d:  ldloc.3
      IL_0e0e:  ldloc.s    V_17
      IL_0e10:  ldc.i4.0
      IL_0e11:  ldloc.s    V_23
      IL_0e13:  box        [mscorlib]System.Double
      IL_0e18:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_0e1d:  ldloc.0
      IL_0e1e:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0e23:  ldarg.0
      IL_0e24:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_0e29:  ldloc.s    V_17
      IL_0e2b:  ldelem.i4
      IL_0e2c:  box        [mscorlib]System.Int32
      IL_0e31:  ldarg.0
      IL_0e32:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0e37:  ldc.i4.1
      IL_0e38:  ldelem.i4
      IL_0e39:  box        [mscorlib]System.Int32
      IL_0e3e:  ldarg.0
      IL_0e3f:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0e44:  ldc.i4.1
      IL_0e45:  ldelem.i4
      IL_0e46:  box        [mscorlib]System.Int32
      IL_0e4b:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0e50:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0e55:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0e5a:  stloc.s    V_22
      IL_0e5c:  ldloc.s    V_22
      IL_0e5e:  brfalse    IL_0f8d

      IL_0e63:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__26'
      IL_0e68:  brtrue.s   IL_0e8e

      IL_0e6a:  ldc.i4.0
      IL_0e6b:  ldtoken    [mscorlib]System.Double
      IL_0e70:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0e75:  ldtoken    WpfPLData.Triangle
      IL_0e7a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0e7f:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_0e84:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0e89:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__26'
      IL_0e8e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__26'
      IL_0e93:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_0e98:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__26'
      IL_0e9d:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__25'
      IL_0ea2:  brtrue.s   IL_0eda

      IL_0ea4:  ldc.i4.0
      IL_0ea5:  ldc.i4.s   12
      IL_0ea7:  ldtoken    WpfPLData.Triangle
      IL_0eac:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0eb1:  ldc.i4.2
      IL_0eb2:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0eb7:  dup
      IL_0eb8:  ldc.i4.0
      IL_0eb9:  ldc.i4.0
      IL_0eba:  ldnull
      IL_0ebb:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0ec0:  stelem.ref
      IL_0ec1:  dup
      IL_0ec2:  ldc.i4.1
      IL_0ec3:  ldc.i4.3
      IL_0ec4:  ldnull
      IL_0ec5:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0eca:  stelem.ref
      IL_0ecb:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0ed0:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0ed5:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__25'
      IL_0eda:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__25'
      IL_0edf:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Target
      IL_0ee4:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__25'
      IL_0ee9:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__24'
      IL_0eee:  brtrue.s   IL_0f35

      IL_0ef0:  ldc.i4.0
      IL_0ef1:  ldstr      "Parse"
      IL_0ef6:  ldnull
      IL_0ef7:  ldtoken    WpfPLData.Triangle
      IL_0efc:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0f01:  ldc.i4.3
      IL_0f02:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_0f07:  dup
      IL_0f08:  ldc.i4.0
      IL_0f09:  ldc.i4.s   33
      IL_0f0b:  ldnull
      IL_0f0c:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0f11:  stelem.ref
      IL_0f12:  dup
      IL_0f13:  ldc.i4.1
      IL_0f14:  ldc.i4.0
      IL_0f15:  ldnull
      IL_0f16:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0f1b:  stelem.ref
      IL_0f1c:  dup
      IL_0f1d:  ldc.i4.2
      IL_0f1e:  ldc.i4.1
      IL_0f1f:  ldnull
      IL_0f20:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_0f25:  stelem.ref
      IL_0f26:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_0f2b:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0f30:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__24'
      IL_0f35:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__24'
      IL_0f3a:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_0f3f:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__24'
      IL_0f44:  ldtoken    [mscorlib]System.Double
      IL_0f49:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0f4e:  ldloc.s    V_22
      IL_0f50:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0f55:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_0f5a:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_0f5f:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_0f64:  ldc.i4.s   100
      IL_0f66:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>::Invoke(!0,
                                                                                                                                                              !1,
                                                                                                                                                              !2)
      IL_0f6b:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_0f70:  stloc.s    V_24
      IL_0f72:  ldarg.0
      IL_0f73:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_0f78:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_0f7d:  ldloc.3
      IL_0f7e:  ldloc.s    V_17
      IL_0f80:  ldc.i4.0
      IL_0f81:  ldloc.s    V_24
      IL_0f83:  box        [mscorlib]System.Double
      IL_0f88:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_0f8d:  ldloc.0
      IL_0f8e:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
      IL_0f93:  ldarg.0
      IL_0f94:  ldfld      int32[] WpfPLData.Triangle::DataElement
      IL_0f99:  ldloc.s    V_17
      IL_0f9b:  ldelem.i4
      IL_0f9c:  box        [mscorlib]System.Int32
      IL_0fa1:  ldarg.0
      IL_0fa2:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0fa7:  ldc.i4.2
      IL_0fa8:  ldelem.i4
      IL_0fa9:  box        [mscorlib]System.Int32
      IL_0fae:  ldarg.0
      IL_0faf:  ldfld      int32[] WpfPLData.Triangle::X2c
      IL_0fb4:  ldc.i4.2
      IL_0fb5:  ldelem.i4
      IL_0fb6:  box        [mscorlib]System.Int32
      IL_0fbb:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0fc0:  ldsfld     object [mscorlib]System.Type::Missing
      IL_0fc5:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object,
                                                                                                                       object)
      IL_0fca:  stloc.s    V_22
      IL_0fcc:  ldloc.s    V_22
      IL_0fce:  brfalse    IL_10ff

      IL_0fd3:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__29'
      IL_0fd8:  brtrue.s   IL_0ffe

      IL_0fda:  ldc.i4.0
      IL_0fdb:  ldtoken    [mscorlib]System.Double
      IL_0fe0:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0fe5:  ldtoken    WpfPLData.Triangle
      IL_0fea:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0fef:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                              class [mscorlib]System.Type,
                                                                                                                                                              class [mscorlib]System.Type)
      IL_0ff4:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_0ff9:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__29'
      IL_0ffe:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__29'
      IL_1003:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>>::Target
      IL_1008:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>> WpfPLData.Triangle/'<>o__67'::'<>p__29'
      IL_100d:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__28'
      IL_1012:  brtrue.s   IL_104a

      IL_1014:  ldc.i4.0
      IL_1015:  ldc.i4.s   12
      IL_1017:  ldtoken    WpfPLData.Triangle
      IL_101c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_1021:  ldc.i4.2
      IL_1022:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_1027:  dup
      IL_1028:  ldc.i4.0
      IL_1029:  ldc.i4.0
      IL_102a:  ldnull
      IL_102b:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_1030:  stelem.ref
      IL_1031:  dup
      IL_1032:  ldc.i4.1
      IL_1033:  ldc.i4.3
      IL_1034:  ldnull
      IL_1035:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_103a:  stelem.ref
      IL_103b:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::BinaryOperation(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                      valuetype [System.Core]System.Linq.Expressions.ExpressionType,
                                                                                                                                                                      class [mscorlib]System.Type,
                                                                                                                                                                      class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_1040:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_1045:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__28'
      IL_104a:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__28'
      IL_104f:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>>::Target
      IL_1054:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>> WpfPLData.Triangle/'<>o__67'::'<>p__28'
      IL_1059:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__27'
      IL_105e:  brtrue.s   IL_10a5

      IL_1060:  ldc.i4.0
      IL_1061:  ldstr      "Parse"
      IL_1066:  ldnull
      IL_1067:  ldtoken    WpfPLData.Triangle
      IL_106c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_1071:  ldc.i4.3
      IL_1072:  newarr     [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo
      IL_1077:  dup
      IL_1078:  ldc.i4.0
      IL_1079:  ldc.i4.s   33
      IL_107b:  ldnull
      IL_107c:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_1081:  stelem.ref
      IL_1082:  dup
      IL_1083:  ldc.i4.1
      IL_1084:  ldc.i4.0
      IL_1085:  ldnull
      IL_1086:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_108b:  stelem.ref
      IL_108c:  dup
      IL_108d:  ldc.i4.2
      IL_108e:  ldc.i4.1
      IL_108f:  ldnull
      IL_1090:  call       class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo::Create(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfoFlags,
                                                                                                                                                                                 string)
      IL_1095:  stelem.ref
      IL_1096:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::InvokeMember(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                                   string,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [mscorlib]System.Type>,
                                                                                                                                                                   class [mscorlib]System.Type,
                                                                                                                                                                   class [mscorlib]System.Collections.Generic.IEnumerable`1<class [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpArgumentInfo>)
      IL_109b:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
      IL_10a0:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__27'
      IL_10a5:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__27'
      IL_10aa:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>>::Target
      IL_10af:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>> WpfPLData.Triangle/'<>o__67'::'<>p__27'
      IL_10b4:  ldtoken    [mscorlib]System.Double
      IL_10b9:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_10be:  ldloc.s    V_22
      IL_10c0:  ldsfld     object [mscorlib]System.Type::Missing
      IL_10c5:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
      IL_10ca:  call       class [mscorlib]System.Globalization.CultureInfo [mscorlib]System.Globalization.CultureInfo::get_InvariantCulture()
      IL_10cf:  callvirt   instance !4 class [mscorlib]System.Func`5<class [System.Core]System.Runtime.CompilerServices.CallSite,class [mscorlib]System.Type,object,class [mscorlib]System.Globalization.CultureInfo,object>::Invoke(!0,
                                                                                                                                                                                                                                     !1,
                                                                                                                                                                                                                                     !2,
                                                                                                                                                                                                                                     !3)
      IL_10d4:  ldc.i4.s   100
      IL_10d6:  callvirt   instance !3 class [mscorlib]System.Func`4<class [System.Core]System.Runtime.CompilerServices.CallSite,object,int32,object>::Invoke(!0,
                                                                                                                                                              !1,
                                                                                                                                                              !2)
      IL_10db:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,float64>::Invoke(!0,
                                                                                                                                                         !1)
      IL_10e0:  stloc.s    V_25
      IL_10e2:  ldarg.0
      IL_10e3:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
      IL_10e8:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
      IL_10ed:  ldloc.3
      IL_10ee:  ldc.i4.1
      IL_10ef:  add
      IL_10f0:  ldloc.s    V_17
      IL_10f2:  ldc.i4.0
      IL_10f3:  ldloc.s    V_25
      IL_10f5:  box        [mscorlib]System.Double
      IL_10fa:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                                       int32,
                                                                                       int16,
                                                                                       object)
      IL_10ff:  leave.s    IL_1104

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_1101:  pop
      IL_1102:  leave.s    IL_1104

    }  // end handler
    IL_1104:  ldloc.s    V_16
    IL_1106:  ldc.i4.1
    IL_1107:  add
    IL_1108:  stloc.s    V_16
    IL_110a:  ldloc.s    V_16
    IL_110c:  ldarg.0
    IL_110d:  ldfld      int32[] WpfPLData.Triangle::DataElement
    IL_1112:  ldlen
    IL_1113:  conv.i4
    IL_1114:  blt        IL_0936

    IL_1119:  ldloc.3
    IL_111a:  ldc.i4.1
    IL_111b:  add
    IL_111c:  stloc.3
    IL_111d:  ldarg.0
    IL_111e:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_1123:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_1128:  ldarg.0
    IL_1129:  ldfld      string WpfPLData.Triangle::_component1
    IL_112e:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
    IL_1133:  ldarg.0
    IL_1134:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_1139:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_113e:  ldc.i4.1
    IL_113f:  box        [mscorlib]System.Int32
    IL_1144:  ldarg.0
    IL_1145:  ldfld      string WpfPLData.Triangle::_component2
    IL_114a:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_114f:  ldarg.0
    IL_1150:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_1155:  callvirt   instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
    IL_115a:  ldc.i4.0
    IL_115b:  box        [mscorlib]System.Int32
    IL_1160:  ldarg.0
    IL_1161:  ldfld      string WpfPLData.Triangle::_component3
    IL_1166:  callvirt   instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                                          string)
    IL_116b:  ret
  } // end of method Triangle::UpdateWizardData

  .method private hidebysig instance int32 
          CountFor(string sName) cil managed
  {
    // Code size       143 (0x8f)
    .maxstack  6
    .locals init (int32 V_0,
             string V_1)
    IL_0000:  ldc.i4.0
    IL_0001:  stloc.0
    IL_0002:  ldsfld     string [mscorlib]System.String::Empty
    IL_0007:  stloc.1
    IL_0008:  ldarg.1
    IL_0009:  ldstr      "TEMPERATURE"
    IL_000e:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0013:  brfalse.s  IL_003c

    IL_0015:  ldarg.0
    IL_0016:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Triangle::_help
    IL_001b:  ldarg.0
    IL_001c:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_0021:  ldarg.0
    IL_0022:  ldfld      string[] WpfPLData.Triangle::VarNames
    IL_0027:  ldc.i4.2
    IL_0028:  ldelem.ref
    IL_0029:  ldarg.1
    IL_002a:  ldarg.0
    IL_002b:  ldflda     int32 WpfPLData.Triangle::TempElement
    IL_0030:  ldarg.0
    IL_0031:  ldflda     string WpfPLData.Triangle::TempUnit
    IL_0036:  callvirt   instance int32 WpfPLData.PLDataHelper::GetElementCount(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                string,
                                                                                string,
                                                                                int32&,
                                                                                string&)
    IL_003b:  ret

    IL_003c:  ldarg.1
    IL_003d:  ldstr      "PRESSURE"
    IL_0042:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0047:  brfalse.s  IL_0070

    IL_0049:  ldarg.0
    IL_004a:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Triangle::_help
    IL_004f:  ldarg.0
    IL_0050:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_0055:  ldarg.0
    IL_0056:  ldfld      string[] WpfPLData.Triangle::VarNames
    IL_005b:  ldc.i4.2
    IL_005c:  ldelem.ref
    IL_005d:  ldarg.1
    IL_005e:  ldarg.0
    IL_005f:  ldflda     int32 WpfPLData.Triangle::PresElement
    IL_0064:  ldarg.0
    IL_0065:  ldflda     string WpfPLData.Triangle::PresUnit
    IL_006a:  callvirt   instance int32 WpfPLData.PLDataHelper::GetElementCount(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                string,
                                                                                string,
                                                                                int32&,
                                                                                string&)
    IL_006f:  ret

    IL_0070:  ldarg.0
    IL_0071:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Triangle::_help
    IL_0076:  ldarg.0
    IL_0077:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_007c:  ldarg.0
    IL_007d:  ldfld      string[] WpfPLData.Triangle::VarNames
    IL_0082:  ldc.i4.2
    IL_0083:  ldelem.ref
    IL_0084:  ldarg.1
    IL_0085:  ldloca.s   V_0
    IL_0087:  ldloca.s   V_1
    IL_0089:  callvirt   instance int32 WpfPLData.PLDataHelper::GetElementCount(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                string,
                                                                                string,
                                                                                int32&,
                                                                                string&)
    IL_008e:  ret
  } // end of method Triangle::CountFor

  .method private hidebysig instance bool 
          IsMixture() cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Triangle::_help
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_000c:  ldarg.0
    IL_000d:  ldfld      string[] WpfPLData.Triangle::VarNames
    IL_0012:  ldc.i4.0
    IL_0013:  ldelem.ref
    IL_0014:  callvirt   instance bool WpfPLData.PLDataHelper::IsMixture(class AspenTech.AspenPlus.Happ.IHNode,
                                                                         string)
    IL_0019:  ret
  } // end of method Triangle::IsMixture

  .method private hidebysig instance bool 
          Build_CandidateList() cil managed
  {
    // Code size       164 (0xa4)
    .maxstack  5
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldstr      ""
    IL_0006:  stfld      string WpfPLData.Triangle::TempUnit
    IL_000b:  ldarg.0
    IL_000c:  ldc.i4.m1
    IL_000d:  stfld      int32 WpfPLData.Triangle::TempElement
    IL_0012:  ldarg.0
    IL_0013:  ldstr      ""
    IL_0018:  stfld      string WpfPLData.Triangle::PresUnit
    IL_001d:  ldarg.0
    IL_001e:  ldc.i4.m1
    IL_001f:  stfld      int32 WpfPLData.Triangle::PresElement
    IL_0024:  ldarg.0
    IL_0025:  ldarg.0
    IL_0026:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Triangle::_help
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_0031:  ldarg.0
    IL_0032:  ldfld      string[] WpfPLData.Triangle::VarNames
    IL_0037:  ldc.i4.1
    IL_0038:  ldelem.ref
    IL_0039:  callvirt   instance int32[] WpfPLData.PLDataHelper::GetDataElementsArray(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                       string)
    IL_003e:  stfld      int32[] WpfPLData.Triangle::DataElement
    IL_0043:  ldarg.0
    IL_0044:  ldfld      int32[] WpfPLData.Triangle::DataElement
    IL_0049:  ldlen
    IL_004a:  brtrue.s   IL_004e

    IL_004c:  ldc.i4.0
    IL_004d:  ret

    IL_004e:  ldarg.0
    IL_004f:  ldarg.0
    IL_0050:  ldfld      class AspenTech.AspenPlus.Happ.IHWizardPlot WpfPLData.Triangle::_wizardPlot
    IL_0055:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    IL_005a:  stfld      int32 WpfPLData.Triangle::PlotType
    IL_005f:  ldarg.0
    IL_0060:  ldarg.0
    IL_0061:  ldfld      class WpfPLData.PLDataHelper WpfPLData.Triangle::_help
    IL_0066:  ldarg.0
    IL_0067:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_006c:  ldarg.0
    IL_006d:  ldfld      string[] WpfPLData.Triangle::VarNames
    IL_0072:  ldc.i4.0
    IL_0073:  ldelem.ref
    IL_0074:  callvirt   instance class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.PLDataHelper::GetComponentList(class AspenTech.AspenPlus.Happ.IHNode,
                                                                                                                                     string)
    IL_0079:  stfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::ComponentList
    IL_007e:  ldc.i4.1
    IL_007f:  stloc.0
    IL_0080:  ldarg.0
    IL_0081:  ldstr      "X1"
    IL_0086:  call       instance int32 WpfPLData.Triangle::CountFor(string)
    IL_008b:  ldc.i4.3
    IL_008c:  bne.un.s   IL_00a0

    IL_008e:  ldarg.0
    IL_008f:  ldstr      "X2"
    IL_0094:  call       instance int32 WpfPLData.Triangle::CountFor(string)
    IL_0099:  ldc.i4.3
    IL_009a:  bne.un.s   IL_00a0

    IL_009c:  ldc.i4.1
    IL_009d:  stloc.0
    IL_009e:  br.s       IL_00a2

    IL_00a0:  ldc.i4.0
    IL_00a1:  stloc.0
    IL_00a2:  ldloc.0
    IL_00a3:  ret
  } // end of method Triangle::Build_CandidateList

  .method private hidebysig instance void 
          Build_Node_Lookup() cil managed
  {
    // Code size       440 (0x1b8)
    .maxstack  4
    .locals init (int32 V_0,
             class AspenTech.AspenPlus.Happ.IHNode V_1,
             int32 V_2,
             int32 V_3,
             int32 V_4,
             string V_5,
             string V_6,
             int32 V_7)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::ComponentList
    IL_0006:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::get_Count()
    IL_000b:  stloc.0
    IL_000c:  ldarg.0
    IL_000d:  ldloc.0
    IL_000e:  newarr     [mscorlib]System.Int32
    IL_0013:  stfld      int32[] WpfPLData.Triangle::Xc
    IL_0018:  ldarg.0
    IL_0019:  ldloc.0
    IL_001a:  newarr     [mscorlib]System.Int32
    IL_001f:  stfld      int32[] WpfPLData.Triangle::X2c
    IL_0024:  ldarg.0
    IL_0025:  ldloc.0
    IL_0026:  newarr     [mscorlib]System.Int32
    IL_002b:  stfld      int32[] WpfPLData.Triangle::Yc
    IL_0030:  ldc.i4.0
    IL_0031:  stloc.2
    IL_0032:  br.s       IL_0053

    IL_0034:  ldarg.0
    IL_0035:  ldfld      int32[] WpfPLData.Triangle::Xc
    IL_003a:  ldloc.2
    IL_003b:  ldc.i4.m1
    IL_003c:  stelem.i4
    IL_003d:  ldarg.0
    IL_003e:  ldfld      int32[] WpfPLData.Triangle::X2c
    IL_0043:  ldloc.2
    IL_0044:  ldc.i4.m1
    IL_0045:  stelem.i4
    IL_0046:  ldarg.0
    IL_0047:  ldfld      int32[] WpfPLData.Triangle::Yc
    IL_004c:  ldloc.2
    IL_004d:  ldc.i4.m1
    IL_004e:  stelem.i4
    IL_004f:  ldloc.2
    IL_0050:  ldc.i4.1
    IL_0051:  add
    IL_0052:  stloc.2
    IL_0053:  ldloc.2
    IL_0054:  ldloc.0
    IL_0055:  blt.s      IL_0034

    IL_0057:  ldarg.0
    IL_0058:  ldfld      class AspenTech.AspenPlus.Happ.IHNode WpfPLData.Triangle::_context
    IL_005d:  ldarg.0
    IL_005e:  ldfld      string[] WpfPLData.Triangle::VarNames
    IL_0063:  ldc.i4.2
    IL_0064:  ldelem.ref
    IL_0065:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_006a:  stloc.1
    IL_006b:  ldloc.1
    IL_006c:  brfalse    IL_01b7

    IL_0071:  ldloc.1
    IL_0072:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_0077:  ldc.i4.1
    IL_0078:  callvirt   instance int32 AspenTech.AspenPlus.Happ.IHNodeCol::get_RowCount(int32)
    IL_007d:  stloc.3
    IL_007e:  ldc.i4.0
    IL_007f:  stloc.s    V_4
    IL_0081:  br         IL_01af

    IL_0086:  ldloc.1
    IL_0087:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_008c:  ldc.i4.1
    IL_008d:  ldloc.s    V_4
    IL_008f:  ldsfld     object [mscorlib]System.Type::Missing
    IL_0094:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_0099:  stloc.s    V_5
    IL_009b:  ldloc.1
    IL_009c:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
    IL_00a1:  ldc.i4.2
    IL_00a2:  ldloc.s    V_4
    IL_00a4:  ldsfld     object [mscorlib]System.Type::Missing
    IL_00a9:  callvirt   instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                                       int32,
                                                                                       object)
    IL_00ae:  stloc.s    V_6
    IL_00b0:  ldc.i4.m1
    IL_00b1:  stloc.s    V_7
    IL_00b3:  ldloc.s    V_5
    IL_00b5:  ldstr      "TEMPERATURE"
    IL_00ba:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00bf:  brtrue.s   IL_010f

    IL_00c1:  ldloc.s    V_5
    IL_00c3:  ldstr      "PRESSURE"
    IL_00c8:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00cd:  brtrue.s   IL_012d

    IL_00cf:  ldloc.s    V_5
    IL_00d1:  ldstr      "X"
    IL_00d6:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00db:  brtrue.s   IL_0148

    IL_00dd:  ldloc.s    V_5
    IL_00df:  ldstr      "X1"
    IL_00e4:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00e9:  brtrue.s   IL_0148

    IL_00eb:  ldloc.s    V_5
    IL_00ed:  ldstr      "X2"
    IL_00f2:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00f7:  brtrue.s   IL_0169

    IL_00f9:  ldloc.s    V_5
    IL_00fb:  ldstr      "Y"
    IL_0100:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0105:  brtrue     IL_018a

    IL_010a:  br         IL_01a9

    IL_010f:  ldarg.0
    IL_0110:  ldfld      int32 WpfPLData.Triangle::TempElement
    IL_0115:  ldc.i4.m1
    IL_0116:  bne.un     IL_01a9

    IL_011b:  ldarg.0
    IL_011c:  ldloc.s    V_6
    IL_011e:  stfld      string WpfPLData.Triangle::TempUnit
    IL_0123:  ldarg.0
    IL_0124:  ldloc.s    V_4
    IL_0126:  stfld      int32 WpfPLData.Triangle::TempElement
    IL_012b:  br.s       IL_01a9

    IL_012d:  ldarg.0
    IL_012e:  ldfld      int32 WpfPLData.Triangle::PresElement
    IL_0133:  ldc.i4.m1
    IL_0134:  bne.un.s   IL_01a9

    IL_0136:  ldarg.0
    IL_0137:  ldloc.s    V_6
    IL_0139:  stfld      string WpfPLData.Triangle::PresUnit
    IL_013e:  ldarg.0
    IL_013f:  ldloc.s    V_4
    IL_0141:  stfld      int32 WpfPLData.Triangle::PresElement
    IL_0146:  br.s       IL_01a9

    IL_0148:  ldarg.0
    IL_0149:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::ComponentList
    IL_014e:  ldloc.s    V_6
    IL_0150:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::IndexOf(!0)
    IL_0155:  stloc.s    V_7
    IL_0157:  ldloc.s    V_7
    IL_0159:  ldc.i4.0
    IL_015a:  blt.s      IL_01a9

    IL_015c:  ldarg.0
    IL_015d:  ldfld      int32[] WpfPLData.Triangle::Xc
    IL_0162:  ldloc.s    V_7
    IL_0164:  ldloc.s    V_4
    IL_0166:  stelem.i4
    IL_0167:  br.s       IL_01a9

    IL_0169:  ldarg.0
    IL_016a:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::ComponentList
    IL_016f:  ldloc.s    V_6
    IL_0171:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::IndexOf(!0)
    IL_0176:  stloc.s    V_7
    IL_0178:  ldloc.s    V_7
    IL_017a:  ldc.i4.0
    IL_017b:  blt.s      IL_01a9

    IL_017d:  ldarg.0
    IL_017e:  ldfld      int32[] WpfPLData.Triangle::X2c
    IL_0183:  ldloc.s    V_7
    IL_0185:  ldloc.s    V_4
    IL_0187:  stelem.i4
    IL_0188:  br.s       IL_01a9

    IL_018a:  ldarg.0
    IL_018b:  ldfld      class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::ComponentList
    IL_0190:  ldloc.s    V_6
    IL_0192:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<string>::IndexOf(!0)
    IL_0197:  stloc.s    V_7
    IL_0199:  ldloc.s    V_7
    IL_019b:  ldc.i4.0
    IL_019c:  blt.s      IL_01a9

    IL_019e:  ldarg.0
    IL_019f:  ldfld      int32[] WpfPLData.Triangle::Yc
    IL_01a4:  ldloc.s    V_7
    IL_01a6:  ldloc.s    V_4
    IL_01a8:  stelem.i4
    IL_01a9:  ldloc.s    V_4
    IL_01ab:  ldc.i4.1
    IL_01ac:  add
    IL_01ad:  stloc.s    V_4
    IL_01af:  ldloc.s    V_4
    IL_01b1:  ldloc.3
    IL_01b2:  blt        IL_0086

    IL_01b7:  ret
  } // end of method Triangle::Build_Node_Lookup

  .method private hidebysig instance void 
          DetermineMoleType(class AspenTech.AspenPlus.Happ.IHNode Context,
                            [out] string& moleMass,
                            [out] string& moleType) cil managed
  {
    // Code size       218 (0xda)
    .maxstack  4
    .locals init (class AspenTech.AspenPlus.Happ.IHNode V_0,
             string V_1)
    IL_0000:  ldarg.2
    IL_0001:  ldstr      ""
    IL_0006:  stind.ref
    IL_0007:  ldarg.3
    IL_0008:  ldstr      ""
    IL_000d:  stind.ref
    IL_000e:  ldarg.1
    IL_000f:  ldstr      "Input/COMPOSITION"
    IL_0014:  callvirt   instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNode::FindNode(string)
    IL_0019:  stloc.0
    IL_001a:  ldloc.0
    IL_001b:  brtrue.s   IL_001e

    IL_001d:  ret

    IL_001e:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Triangle/'<>o__72'::'<>p__0'
    IL_0023:  brtrue.s   IL_0049

    IL_0025:  ldc.i4.0
    IL_0026:  ldtoken    [mscorlib]System.String
    IL_002b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0030:  ldtoken    WpfPLData.Triangle
    IL_0035:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_003a:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_003f:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0044:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Triangle/'<>o__72'::'<>p__0'
    IL_0049:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Triangle/'<>o__72'::'<>p__0'
    IL_004e:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>>::Target
    IL_0053:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>> WpfPLData.Triangle/'<>o__72'::'<>p__0'
    IL_0058:  ldloc.0
    IL_0059:  ldsfld     object [mscorlib]System.Type::Missing
    IL_005e:  callvirt   instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    IL_0063:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,string>::Invoke(!0,
                                                                                                                                                      !1)
    IL_0068:  stloc.1
    IL_0069:  ldloc.1
    IL_006a:  ldstr      "MOLE-FRAC"
    IL_006f:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0074:  brtrue.s   IL_009e

    IL_0076:  ldloc.1
    IL_0077:  ldstr      "MASS-FRAC"
    IL_007c:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0081:  brtrue.s   IL_00ad

    IL_0083:  ldloc.1
    IL_0084:  ldstr      "MOLE-PCT"
    IL_0089:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_008e:  brtrue.s   IL_00bc

    IL_0090:  ldloc.1
    IL_0091:  ldstr      "MASS-PCT"
    IL_0096:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_009b:  brtrue.s   IL_00cb

    IL_009d:  ret

    IL_009e:  ldarg.3
    IL_009f:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_MoleFraction()
    IL_00a4:  stind.ref
    IL_00a5:  ldarg.2
    IL_00a6:  ldstr      "fraction"
    IL_00ab:  stind.ref
    IL_00ac:  ret

    IL_00ad:  ldarg.3
    IL_00ae:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_MassFraction()
    IL_00b3:  stind.ref
    IL_00b4:  ldarg.2
    IL_00b5:  ldstr      "fraction"
    IL_00ba:  stind.ref
    IL_00bb:  ret

    IL_00bc:  ldarg.3
    IL_00bd:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_MoleFraction()
    IL_00c2:  stind.ref
    IL_00c3:  ldarg.2
    IL_00c4:  ldstr      ""
    IL_00c9:  stind.ref
    IL_00ca:  ret

    IL_00cb:  ldarg.3
    IL_00cc:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.WpfPlotWizards.WpfPLDataResources::get_MassFraction()
    IL_00d1:  stind.ref
    IL_00d2:  ldarg.2
    IL_00d3:  ldstr      ""
    IL_00d8:  stind.ref
    IL_00d9:  ret
  } // end of method Triangle::DetermineMoleType

  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TooltipContentForRibbonItem()
  {
    .get instance string WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipContentForRibbonItem()
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TooltipContentForRibbonItem
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TooltipHeaderForRibbonItem()
  {
    .get instance string WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TooltipHeaderForRibbonItem()
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TooltipHeaderForRibbonItem
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TagID()
  {
    .get instance string WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_TagID()
    .set instance void WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_TagID(string)
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.TagID
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Name()
  {
    .get instance string WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_Name()
    .set instance void WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_Name(string)
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.Name
  .property instance callconv(8) object AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.WizardPlot()
  {
    .get instance object WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_WizardPlot()
    .set instance void WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_WizardPlot(object)
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.WizardPlot
  .property instance callconv(8) object AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.CxsNode()
  {
    .get instance object WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_CxsNode()
    .set instance void WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.set_CxsNode(object)
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.CxsNode
  .property instance callconv(8) class [System.Drawing]System.Drawing.Image
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ImageIcon()
  {
    .get instance class [System.Drawing]System.Drawing.Image WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_ImageIcon()
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.ImageIcon
  .property instance callconv(8) bool AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HasInputDialog()
  {
    .get instance bool WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HasInputDialog()
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HasInputDialog
  .property instance callconv(8) string AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpFile()
  {
    .get instance string WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpFile()
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpFile
  .property instance callconv(8) int64 AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpID()
  {
    .get instance int64 WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_HelpID()
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.HelpID
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.List`1<string>
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedDataFields()
  {
    .get instance class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedDataFields()
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedDataFields
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.List`1<string>
          AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedStyleFields()
  {
    .get instance class [mscorlib]System.Collections.Generic.List`1<string> WpfPLData.Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.get_SupportedStyleFields()
  } // end of property Triangle::AspenTech.AspenPlus.Infrastructure.IRibbonPlotWizardType.SupportedStyleFields
  .property instance callconv(8) bool CheckDataOnly()
  {
    .get instance bool WpfPLData.Triangle::get_CheckDataOnly()
    .set instance void WpfPLData.Triangle::set_CheckDataOnly(bool)
  } // end of property Triangle::CheckDataOnly
} // end of class WpfPLData.Triangle

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.CHPlotVal
       implements AspenTech.AspenPlus.Happ.IHPlotVal
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 31 36 37 37 37 38 30 2D 42 37 32 42   // ..$11677780-B72B
                                                                                                  2D 31 31 44 30 2D 41 39 34 33 2D 30 30 30 30 43   // -11D0-A943-0000C
                                                                                                  30 41 31 31 38 44 42 00 00 )                      // 0A118DB..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 5A 53 79 73 74 65 6D 2E 4F 62 6A 65 63 74   // ..ZSystem.Object
                                                                                                                          2C 20 6D 73 63 6F 72 6C 69 62 2C 20 56 65 72 73   // , mscorlib, Vers
                                                                                                                          69 6F 6E 3D 34 2E 30 2E 30 2E 30 2C 20 43 75 6C   // ion=4.0.0.0, Cul
                                                                                                                          74 75 72 65 3D 6E 65 75 74 72 61 6C 2C 20 50 75   // ture=neutral, Pu
                                                                                                                          62 6C 69 63 4B 65 79 54 6F 6B 65 6E 3D 62 37 37   // blicKeyToken=b77
                                                                                                                          61 35 63 35 36 31 39 33 34 65 30 38 39 00 00 )    // a5c561934e089..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.Happ.CHPlotVal

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.CHWizardPlot
       implements AspenTech.AspenPlus.Happ.IHWizardPlot
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 38 30 30 38 43 37 33 30 2D 31 41 33 45   // ..$8008C730-1A3E
                                                                                                  2D 31 31 44 31 2D 38 41 34 44 2D 30 30 30 30 43   // -11D1-8A4D-0000C
                                                                                                  30 32 33 37 44 46 39 00 00 )                      // 0237DF9..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 5A 53 79 73 74 65 6D 2E 4F 62 6A 65 63 74   // ..ZSystem.Object
                                                                                                                          2C 20 6D 73 63 6F 72 6C 69 62 2C 20 56 65 72 73   // , mscorlib, Vers
                                                                                                                          69 6F 6E 3D 34 2E 30 2E 30 2E 30 2C 20 43 75 6C   // ion=4.0.0.0, Cul
                                                                                                                          74 75 72 65 3D 6E 65 75 74 72 61 6C 2C 20 50 75   // ture=neutral, Pu
                                                                                                                          62 6C 69 63 4B 65 79 54 6F 6B 65 6E 3D 62 37 37   // blicKeyToken=b77
                                                                                                                          61 35 63 35 36 31 39 33 34 65 30 38 39 00 00 )    // a5c561934e089..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class AspenTech.AspenPlus.Happ.CHWizardPlot

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.IHNode
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 38 45 35 36 37 35 32 32 2D 46 39 42 41   // ..$8E567522-F9BA
                                                                                                  2D 31 31 43 46 2D 39 30 42 32 2D 30 30 30 30 43   // -11CF-90B2-0000C
                                                                                                  30 41 38 31 30 43 34 00 00 )                      // 0A810C4..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_4() runtime managed
  {
  } // end of method IHNode::_VtblGap1_4

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Dimension() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IHNode::get_Dimension

  .method public specialname rtspecialname 
          instance void  _VtblGap2_1() runtime managed
  {
  } // end of method IHNode::_VtblGap2_1

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Value([in][opt] object  marshal( struct) force) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IHNode::get_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Value([in][opt] object  marshal( struct) force,
                                   [in] object  marshal( struct) Value) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IHNode::set_Value

  .method public specialname rtspecialname 
          instance void  _VtblGap3_10() runtime managed
  {
  } // end of method IHNode::_VtblGap3_10

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.Happ.IHNodeCol 
          marshal( interface ) 
          get_Elements() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
  } // end of method IHNode::get_Elements

  .method public specialname rtspecialname 
          instance void  _VtblGap4_8() runtime managed
  {
  } // end of method IHNode::_VtblGap4_8

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.Happ.IHNode 
          marshal( interface ) 
          FindNode([in] string  marshal( bstr) path) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1B 00 02 60 00 00 )                         // .....`..
  } // end of method IHNode::FindNode

  .property callconv(8) int32 Dimension()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHNode::get_Dimension()
  } // end of property IHNode::Dimension
  .property callconv(8) object Value(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.Happ.IHNode::get_Value(object)
    .set instance void AspenTech.AspenPlus.Happ.IHNode::set_Value(object,
                                                                  object)
  } // end of property IHNode::Value
  .property callconv(8) class AspenTech.AspenPlus.Happ.IHNodeCol
          Elements()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.Happ.IHNodeCol AspenTech.AspenPlus.Happ.IHNode::get_Elements()
  } // end of property IHNode::Elements
} // end of class AspenTech.AspenPlus.Happ.IHNode

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.IHNodeCol
       implements [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 38 39 45 38 31 46 36 30 2D 30 31 39 41   // ..$89E81F60-019A
                                                                                                  2D 31 31 44 30 2D 39 42 45 37 2D 30 30 30 30 43   // -11D0-9BE7-0000C
                                                                                                  30 35 33 37 35 44 35 00 00 )                      // 05375D5..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_2() runtime managed
  {
  } // end of method IHNodeCol::_VtblGap1_2

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IHNodeCol::get_Count

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_RowCount([in] int32 Dimension) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IHNodeCol::get_RowCount

  .method public specialname rtspecialname 
          instance void  _VtblGap2_2() runtime managed
  {
  } // end of method IHNodeCol::_VtblGap2_2

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.Happ.IHNode 
          marshal( interface ) 
          get_Item([in] object  marshal( struct) loc_or_name,
                   [in][opt] object  marshal( struct) loc_or_name2,
                   [in][opt] object  marshal( struct) loc_or_name3,
                   [in][opt] object  marshal( struct) loc_or_name4,
                   [in][opt] object  marshal( struct) loc_or_name5) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IHNodeCol::get_Item

  .method public specialname rtspecialname 
          instance void  _VtblGap3_2() runtime managed
  {
  } // end of method IHNodeCol::_VtblGap3_2

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Label([in] int32 Dimension,
                    [in] int32 location,
                    [in][opt] object  marshal( struct) force) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
  } // end of method IHNodeCol::get_Label

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Label([in] int32 Dimension,
                                   [in] int32 location,
                                   [in][opt] object  marshal( struct) force,
                                   [in] string  marshal( bstr) Label) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
  } // end of method IHNodeCol::set_Label

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHNodeCol::get_Count()
  } // end of property IHNodeCol::Count
  .property callconv(8) int32 RowCount(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHNodeCol::get_RowCount(int32)
  } // end of property IHNodeCol::RowCount
  .property callconv(8) class AspenTech.AspenPlus.Happ.IHNode
          Item(object,
               object,
               object,
               object,
               object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.Happ.IHNode AspenTech.AspenPlus.Happ.IHNodeCol::get_Item(object,
                                                                                                     object,
                                                                                                     object,
                                                                                                     object,
                                                                                                     object)
  } // end of property IHNodeCol::Item
  .property callconv(8) string Label(int32,
                                     int32,
                                     object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.Happ.IHNodeCol::get_Label(int32,
                                                                       int32,
                                                                       object)
    .set instance void AspenTech.AspenPlus.Happ.IHNodeCol::set_Label(int32,
                                                                     int32,
                                                                     object,
                                                                     string)
  } // end of property IHNodeCol::Label
} // end of class AspenTech.AspenPlus.Happ.IHNodeCol

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.IHPlotVal
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 31 36 37 37 37 38 30 2D 42 37 32 42   // ..$11677780-B72B
                                                                                                  2D 31 31 44 30 2D 41 39 34 33 2D 30 30 30 30 43   // -11D0-A943-0000C
                                                                                                  30 41 31 31 38 44 42 00 00 )                      // 0A118DB..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_2() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap1_2

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Title() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::get_Title

  .method public specialname rtspecialname 
          instance void  _VtblGap2_1() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap2_1

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Title([in] string  marshal( bstr) Title) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::set_Title

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_XAxisTitle() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::get_XAxisTitle

  .method public specialname rtspecialname 
          instance void  _VtblGap3_1() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap3_1

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_XAxisTitle([in] string  marshal( bstr) xtitle) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::set_XAxisTitle

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_YAxisTitle([in][opt] object  marshal( struct) nAxis) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::get_YAxisTitle

  .method public specialname rtspecialname 
          instance void  _VtblGap4_1() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap4_1

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_YAxisTitle([in][opt] object  marshal( struct) nAxis,
                                        [in] string  marshal( bstr) ytitle) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::set_YAxisTitle

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Label([in] int32 index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::get_Label

  .method public specialname rtspecialname 
          instance void  _VtblGap5_1() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap5_1

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Label([in] int32 index,
                                   [in] string  marshal( bstr) Label) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::set_Label

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NPoints() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::get_NPoints

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_NPoints([in] int32 NPoints) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::set_NPoints

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NVariables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::get_NVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_NVariables([in] int32 nvar) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::set_NVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NXVariables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::get_NXVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_NXVariables([in] int32 nvar) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::set_NXVariables

  .method public specialname rtspecialname 
          instance void  _VtblGap6_1() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap6_1

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_XData([in] int32 index,
                                   [in] int32 datano,
                                   [in] int16 attr,
                                   [in] object  marshal( struct) A_4) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::set_XData

  .method public specialname rtspecialname 
          instance void  _VtblGap7_1() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap7_1

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_YData([in] int32 index,
                                   [in] int32 datano,
                                   [in] int16 attr,
                                   [in] object  marshal( struct) A_4) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
  } // end of method IHPlotVal::set_YData

  .method public specialname rtspecialname 
          instance void  _VtblGap8_11() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap8_11

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_PlotType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 23 00 02 60 00 00 )                         // ..#..`..
  } // end of method IHPlotVal::get_PlotType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_PlotType([in] int32 pPlotType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 23 00 02 60 00 00 )                         // ..#..`..
  } // end of method IHPlotVal::set_PlotType

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Parametric() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 25 00 02 60 00 00 )                         // ..%..`..
  } // end of method IHPlotVal::get_Parametric

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Parametric([in] bool pbParametric) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 25 00 02 60 00 00 )                         // ..%..`..
  } // end of method IHPlotVal::set_Parametric

  .method public specialname rtspecialname 
          instance void  _VtblGap9_12() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap9_12

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_ShowDiagonalLine() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 33 00 02 60 00 00 )                         // ..3..`..
  } // end of method IHPlotVal::get_ShowDiagonalLine

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ShowDiagonalLine([in] bool pbDiagonal) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 33 00 02 60 00 00 )                         // ..3..`..
  } // end of method IHPlotVal::set_ShowDiagonalLine

  .method public hidebysig newslot specialname abstract virtual 
          instance int16  get_LineStyle() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 35 00 02 60 00 00 )                         // ..5..`..
  } // end of method IHPlotVal::get_LineStyle

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_LineStyle([in] int16 line) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 35 00 02 60 00 00 )                         // ..5..`..
  } // end of method IHPlotVal::set_LineStyle

  .method public specialname rtspecialname 
          instance void  _VtblGap10_3() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap10_3

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_AxisMap([in] int32 index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 3A 00 02 60 00 00 )                         // ..:..`..
  } // end of method IHPlotVal::get_AxisMap

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_AxisMap([in] int32 index,
                                     [in] int32 pAxis) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 3A 00 02 60 00 00 )                         // ..:..`..
  } // end of method IHPlotVal::set_AxisMap

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_CurveStyle([in] int32 index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 3C 00 02 60 00 00 )                         // ..<..`..
  } // end of method IHPlotVal::get_CurveStyle

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_CurveStyle([in] int32 index,
                                        [in] int32 pStyle) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 3C 00 02 60 00 00 )                         // ..<..`..
  } // end of method IHPlotVal::set_CurveStyle

  .method public specialname rtspecialname 
          instance void  _VtblGap11_1() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap11_1

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_SquarePlot() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 3F 00 02 60 00 00 )                         // ..?..`..
  } // end of method IHPlotVal::get_SquarePlot

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_SquarePlot([in] bool pbSquare) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 3F 00 02 60 00 00 )                         // ..?..`..
  } // end of method IHPlotVal::set_SquarePlot

  .method public specialname rtspecialname 
          instance void  _VtblGap12_2() runtime managed
  {
  } // end of method IHPlotVal::_VtblGap12_2

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_AxisScale([in] int32 VarNo) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 43 00 02 60 00 00 )                         // ..C..`..
  } // end of method IHPlotVal::get_AxisScale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_AxisScale([in] int32 VarNo,
                                       [in] int32 pScale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 43 00 02 60 00 00 )                         // ..C..`..
  } // end of method IHPlotVal::set_AxisScale

  .property callconv(8) string Title()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.Happ.IHPlotVal::get_Title()
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Title(string)
  } // end of property IHPlotVal::Title
  .property callconv(8) string XAxisTitle()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.Happ.IHPlotVal::get_XAxisTitle()
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XAxisTitle(string)
  } // end of property IHPlotVal::XAxisTitle
  .property callconv(8) string YAxisTitle(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.Happ.IHPlotVal::get_YAxisTitle(object)
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YAxisTitle(object,
                                                                          string)
  } // end of property IHPlotVal::YAxisTitle
  .property callconv(8) string Label(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.Happ.IHPlotVal::get_Label(int32)
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Label(int32,
                                                                     string)
  } // end of property IHPlotVal::Label
  .property callconv(8) int32 NPoints()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHPlotVal::get_NPoints()
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NPoints(int32)
  } // end of property IHPlotVal::NPoints
  .property callconv(8) int32 NVariables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHPlotVal::get_NVariables()
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NVariables(int32)
  } // end of property IHPlotVal::NVariables
  .property callconv(8) int32 NXVariables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHPlotVal::get_NXVariables()
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_NXVariables(int32)
  } // end of property IHPlotVal::NXVariables
  .property callconv(8) object XData(int32,
                                     int32,
                                     int16)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_XData(int32,
                                                                     int32,
                                                                     int16,
                                                                     object)
  } // end of property IHPlotVal::XData
  .property callconv(8) object YData(int32,
                                     int32,
                                     int16)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_YData(int32,
                                                                     int32,
                                                                     int16,
                                                                     object)
  } // end of property IHPlotVal::YData
  .property callconv(8) int32 PlotType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 23 00 02 60 00 00 )                         // ..#..`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHPlotVal::get_PlotType()
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_PlotType(int32)
  } // end of property IHPlotVal::PlotType
  .property callconv(8) bool Parametric()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 25 00 02 60 00 00 )                         // ..%..`..
    .get instance bool AspenTech.AspenPlus.Happ.IHPlotVal::get_Parametric()
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_Parametric(bool)
  } // end of property IHPlotVal::Parametric
  .property callconv(8) bool ShowDiagonalLine()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 33 00 02 60 00 00 )                         // ..3..`..
    .get instance bool AspenTech.AspenPlus.Happ.IHPlotVal::get_ShowDiagonalLine()
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_ShowDiagonalLine(bool)
  } // end of property IHPlotVal::ShowDiagonalLine
  .property callconv(8) int16 LineStyle()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 35 00 02 60 00 00 )                         // ..5..`..
    .get instance int16 AspenTech.AspenPlus.Happ.IHPlotVal::get_LineStyle()
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_LineStyle(int16)
  } // end of property IHPlotVal::LineStyle
  .property callconv(8) int32 AxisMap(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 3A 00 02 60 00 00 )                         // ..:..`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHPlotVal::get_AxisMap(int32)
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_AxisMap(int32,
                                                                       int32)
  } // end of property IHPlotVal::AxisMap
  .property callconv(8) int32 CurveStyle(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 3C 00 02 60 00 00 )                         // ..<..`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHPlotVal::get_CurveStyle(int32)
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_CurveStyle(int32,
                                                                          int32)
  } // end of property IHPlotVal::CurveStyle
  .property callconv(8) bool SquarePlot()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 3F 00 02 60 00 00 )                         // ..?..`..
    .get instance bool AspenTech.AspenPlus.Happ.IHPlotVal::get_SquarePlot()
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_SquarePlot(bool)
  } // end of property IHPlotVal::SquarePlot
  .property callconv(8) int32 AxisScale(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 43 00 02 60 00 00 )                         // ..C..`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHPlotVal::get_AxisScale(int32)
    .set instance void AspenTech.AspenPlus.Happ.IHPlotVal::set_AxisScale(int32,
                                                                         int32)
  } // end of property IHPlotVal::AxisScale
} // end of class AspenTech.AspenPlus.Happ.IHPlotVal

.class interface public abstract auto ansi import AspenTech.AspenPlus.Happ.IHWizardPlot
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 38 30 30 38 43 37 33 30 2D 31 41 33 45   // ..$8008C730-1A3E
                                                                                                  2D 31 31 44 31 2D 38 41 34 44 2D 30 30 30 30 43   // -11D1-8A4D-0000C
                                                                                                  30 32 33 37 44 46 39 00 00 )                      // 0237DF9..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.Happ.CHPlotVal 
          marshal( interface ) 
          get_PlotVal() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 02 60 00 00 )                         // .....`..
  } // end of method IHWizardPlot::get_PlotVal

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_basis() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IHWizardPlot::get_basis

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_basis([in] int32 basis) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IHWizardPlot::set_basis

  .method public specialname rtspecialname 
          instance void  _VtblGap1_7() runtime managed
  {
  } // end of method IHWizardPlot::_VtblGap1_7

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveAllDependentVariable() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IHWizardPlot::RemoveAllDependentVariable

  .property callconv(8) class AspenTech.AspenPlus.Happ.CHPlotVal
          PlotVal()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.Happ.CHPlotVal AspenTech.AspenPlus.Happ.IHWizardPlot::get_PlotVal()
  } // end of property IHWizardPlot::PlotVal
  .property callconv(8) int32 basis()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.Happ.IHWizardPlot::get_basis()
    .set instance void AspenTech.AspenPlus.Happ.IHWizardPlot::set_basis(int32)
  } // end of property IHWizardPlot::basis
} // end of class AspenTech.AspenPlus.Happ.IHWizardPlot


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file orig.ildasm.res
