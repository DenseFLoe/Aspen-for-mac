; .reloc PE metadata and initialized data.
bits 64

    dd 0x2000                                                  ; +0x0000 Relocation page.VirtualAddress
    dd 0x2c                                                    ; +0x0004 Relocation page.SizeOfBlock
    dw 0xa0e8                                                  ; +0x0008 Base relocation RVA 0x20e8, type 10.Data
    dw 0xa0f0                                                  ; +0x000a Base relocation RVA 0x20f0, type 10.Data
    dw 0xa0f8                                                  ; +0x000c Base relocation RVA 0x20f8, type 10.Data
    dw 0xa100                                                  ; +0x000e Base relocation RVA 0x2100, type 10.Data
    dw 0xa108                                                  ; +0x0010 Base relocation RVA 0x2108, type 10.Data
    dw 0xa118                                                  ; +0x0012 Base relocation RVA 0x2118, type 10.Data
    dw 0xa168                                                  ; +0x0014 Base relocation RVA 0x2168, type 10.Data
    dw 0xa170                                                  ; +0x0016 Base relocation RVA 0x2170, type 10.Data
    dw 0xa1e8                                                  ; +0x0018 Base relocation RVA 0x21e8, type 10.Data
    dw 0xa200                                                  ; +0x001a Base relocation RVA 0x2200, type 10.Data
    dw 0xa208                                                  ; +0x001c Base relocation RVA 0x2208, type 10.Data
    dw 0xa290                                                  ; +0x001e Base relocation RVA 0x2290, type 10.Data
    dw 0xa2a8                                                  ; +0x0020 Base relocation RVA 0x22a8, type 10.Data
    dw 0xa2b0                                                  ; +0x0022 Base relocation RVA 0x22b0, type 10.Data
    dw 0xa2b8                                                  ; +0x0024 Base relocation RVA 0x22b8, type 10.Data
    dw 0xa2c0                                                  ; +0x0026 Base relocation RVA 0x22c0, type 10.Data
    dw 0xa2c8                                                  ; +0x0028 Base relocation RVA 0x22c8, type 10.Data
    dw 0x0                                                     ; +0x002a Base relocation RVA 0x2000, type 0.Data
    times 0x1d4 db 0  ; zero fill at +0x2c
