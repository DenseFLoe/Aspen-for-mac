"""Compile the recovered C# and original embedded resources into a fresh assembly."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def validate(path, expected):
    actual = sha(path)
    if actual != expected:
        raise ValueError(f"SHA-256 mismatch for {path}: {actual}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csc", type=Path, required=True,
                        help="Roslyn 3.8.0 csc.exe from Microsoft.Net.Compilers")
    parser.add_argument("--framework", type=Path, required=True,
                        help=".NET Framework 4.8 reference assemblies directory")
    parser.add_argument("--xeq", type=Path, required=True,
                        help="Aspen AprSystem V15.0 GUI/Xeq installation directory")
    parser.add_argument("--out", type=Path, required=True,
                        help="New output directory for the compiler result")
    options = parser.parse_args()

    package = Path(__file__).resolve().parent
    data = json.loads((package / "build-inputs.json").read_bytes())
    compiler = options.csc.resolve(strict=True)
    validate(compiler, data["compiler_sha256"])
    for name, expected in data["compiler_dependencies"].items():
        validate(compiler.parent / name, expected)
    roots = {"framework": options.framework.resolve(), "xeq": options.xeq.resolve()}

    output = options.out.resolve()
    output.mkdir(parents=True, exist_ok=False)
    response = output / "compile.rsp"
    artifact = output / "WpfPLRPlug.dll"
    flags = list(data["compile_flags"]) + [f'/out:"{artifact}"']
    win32 = data["win32_resource"]
    validate(package / win32["path"], win32["sha256"])
    flags.append(f'/win32res:"{win32["path"]}"')
    for reference in data["references"]:
        path = roots[reference["root"]] / reference["path"]
        validate(path, reference["sha256"])
        action = "link" if reference["link"] else "reference"
        flags.append(f'/{action}:"{path}"')
    for resource in data["managed_resources"]:
        validate(package / resource["path"], resource["sha256"])
        flags.append(f'/resource:"{resource["path"]}","{resource["name"]}",{resource["visibility"]}')
    flags.extend(f'"{source}"' for source in data["sources"])
    response.write_text("\n".join(flags) + "\n", encoding="utf-8-sig")
    run = subprocess.run([str(compiler), "/noconfig", "@" + str(response)],
                         cwd=package, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (output / "compile.log").write_bytes(run.stdout)
    if run.returncode != 0:
        sys.stderr.buffer.write(run.stdout)
        return run.returncode
    receipt = {"output": artifact.name, "sha256": sha(artifact),
               "source_sha256": {source: sha(package / source) for source in data["sources"]}}
    (output / "build.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt))
    return 0


if __name__ == "__main__":
    sys.exit(main())
