; .rdata PE metadata and initialized data.
bits 64

    dq 0x2b74                                                  ; +0x0000 IAT GetCurrentThreadId
    dq 0x2ab2                                                  ; +0x0008 IAT RtlVirtualUnwind
    dq 0x2a98                                                  ; +0x0010 IAT RtlLookupFunctionEntry
    dq 0x2a84                                                  ; +0x0018 IAT RtlCaptureContext
    dq 0x2ae2                                                  ; +0x0020 IAT SetUnhandledExceptionFilter
    dq 0x2b00                                                  ; +0x0028 IAT GetCurrentProcess
    dq 0x2bba                                                  ; +0x0030 IAT IsDebuggerPresent
    dq 0x2ba4                                                  ; +0x0038 IAT InitializeSListHead
    dq 0x2b8a                                                  ; +0x0040 IAT GetSystemTimeAsFileTime
    dq 0x2ac6                                                  ; +0x0048 IAT UnhandledExceptionFilter
    dq 0x2b5e                                                  ; +0x0050 IAT GetCurrentProcessId
    dq 0x2b44                                                  ; +0x0058 IAT QueryPerformanceCounter
    dq 0x2b28                                                  ; +0x0060 IAT IsProcessorFeaturePresent
    dq 0x2b14                                                  ; +0x0068 IAT TerminateProcess
    times 0x8 db 0  ; zero fill at +0x70
    dq 0x2bdc                                                  ; +0x0078 IAT memcpy
    dq 0x2980                                                  ; +0x0080 IAT __std_type_info_destroy_list
    dq 0x2968                                                  ; +0x0088 IAT __C_specific_handler
    dq 0x29a0                                                  ; +0x0090 IAT memset
    times 0x8 db 0  ; zero fill at +0x98
    dq 0x2a58                                                  ; +0x00a0 IAT _cexit
    dq 0x2a40                                                  ; +0x00a8 IAT _execute_onexit_table
    dq 0x2a24                                                  ; +0x00b0 IAT _initialize_onexit_table
    dq 0x2a02                                                  ; +0x00b8 IAT _initialize_narrow_environment
    dq 0x29e8                                                  ; +0x00c0 IAT _configure_narrow_argv
    dq 0x29d6                                                  ; +0x00c8 IAT _seh_filter_dll
    dq 0x29c8                                                  ; +0x00d0 IAT _initterm_e
    dq 0x29bc                                                  ; +0x00d8 IAT _initterm
    times 0x8 db 0  ; zero fill at +0xe0
    dq 0x180001b10                                             ; +0x00e8 GuardCFCheckFunctionPointer initial slot
    dq 0x180001b10                                             ; +0x00f0 GuardXFGCheckFunctionPointer initial slot
    dq 0x180001d40                                             ; +0x00f8 GuardCFDispatchFunctionPointer initial slot
    dq 0x180001d60                                             ; +0x0100 GuardXFGDispatchFunctionPointer initial slot
    dq 0x180001d60                                             ; +0x0108 GuardXFGTableDispatchFunctionPointer initial slot
    dq 0x0                                                     ; +0x0110 CastGuardOsDeterminedFailureMode initial slot
    dq 0x180001d1b                                             ; +0x0118 GuardMemcpyFunctionPointer initial slot
    times 16 db 0  ; constant data at +0x120
    times 16 db 0  ; constant data at +0x130
    times 16 db 0  ; constant data at +0x140
    times 16 db 0  ; constant data at +0x150
    db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x30, 0x00, 0x80, 0x01, 0x00, 0x00, 0x00  ; constant data at +0x160
    db 0xf0, 0x30, 0x00, 0x80, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x170
    db 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff  ; constant data at +0x180
    dd 0x140                                                   ; +0x0190 LoadConfig.Size
    dd 0x0                                                     ; +0x0194 LoadConfig.TimeDateStamp
    dw 0x0                                                     ; +0x0198 LoadConfig.MajorVersion
    dw 0x0                                                     ; +0x019a LoadConfig.MinorVersion
    dd 0x0                                                     ; +0x019c LoadConfig.GlobalFlagsClear
    dd 0x0                                                     ; +0x01a0 LoadConfig.GlobalFlagsSet
    dd 0x0                                                     ; +0x01a4 LoadConfig.CriticalSectionDefaultTimeout
    dq 0x0                                                     ; +0x01a8 LoadConfig.DeCommitFreeBlockThreshold
    dq 0x0                                                     ; +0x01b0 LoadConfig.DeCommitTotalFreeThreshold
    dq 0x0                                                     ; +0x01b8 LoadConfig.LockPrefixTable
    dq 0x0                                                     ; +0x01c0 LoadConfig.MaximumAllocationSize
    dq 0x0                                                     ; +0x01c8 LoadConfig.VirtualMemoryThreshold
    dq 0x0                                                     ; +0x01d0 LoadConfig.ProcessAffinityMask
    dd 0x0                                                     ; +0x01d8 LoadConfig.ProcessHeapFlags
    dw 0x0                                                     ; +0x01dc LoadConfig.CSDVersion
    dw 0x0                                                     ; +0x01de LoadConfig.DependentLoadFlags
    dq 0x0                                                     ; +0x01e0 LoadConfig.EditList
    dq 0x180003008                                             ; +0x01e8 LoadConfig.SecurityCookie
    dq 0x0                                                     ; +0x01f0 LoadConfig.SEHandlerTable
    dq 0x0                                                     ; +0x01f8 LoadConfig.SEHandlerCount
    dq 0x1800020e8                                             ; +0x0200 LoadConfig.GuardCFCheckFunctionPointer
    dq 0x1800020f8                                             ; +0x0208 LoadConfig.GuardCFDispatchFunctionPointer
    dq 0x0                                                     ; +0x0210 LoadConfig.GuardCFFunctionTable
    dq 0x0                                                     ; +0x0218 LoadConfig.GuardCFFunctionCount
    dd 0x100                                                   ; +0x0220 LoadConfig.GuardFlags
    dw 0x0                                                     ; +0x0224 LoadConfig.CodeIntegrityFlags
    dw 0x0                                                     ; +0x0226 LoadConfig.CodeIntegrityCatalog
    dd 0x0                                                     ; +0x0228 LoadConfig.CodeIntegrityCatalogOffset
    dd 0x0                                                     ; +0x022c LoadConfig.CodeIntegrityReserved
    dq 0x0                                                     ; +0x0230 LoadConfig.GuardAddressTakenIatEntryTable
    dq 0x0                                                     ; +0x0238 LoadConfig.GuardAddressTakenIatEntryCount
    dq 0x0                                                     ; +0x0240 LoadConfig.GuardLongJumpTargetTable
    dq 0x0                                                     ; +0x0248 LoadConfig.GuardLongJumpTargetCount
    dq 0x0                                                     ; +0x0250 LoadConfig.DynamicValueRelocTable
    dq 0x0                                                     ; +0x0258 LoadConfig.CHPEMetadataPointer
    dq 0x0                                                     ; +0x0260 LoadConfig.GuardRFFailureRoutine
    dq 0x0                                                     ; +0x0268 LoadConfig.GuardRFFailureRoutineFunctionPointer
    dd 0x0                                                     ; +0x0270 LoadConfig.DynamicValueRelocTableOffset
    dw 0x0                                                     ; +0x0274 LoadConfig.DynamicValueRelocTableSection
    dw 0x0                                                     ; +0x0276 LoadConfig.Reserved2
    dq 0x0                                                     ; +0x0278 LoadConfig.GuardRFVerifyStackPointerFunctionPointer
    dd 0x0                                                     ; +0x0280 LoadConfig.HotPatchTableOffset
    dd 0x0                                                     ; +0x0284 LoadConfig.Reserved3
    dq 0x0                                                     ; +0x0288 LoadConfig.EnclaveConfigurationPointer
    dq 0x180002380                                             ; +0x0290 LoadConfig.VolatileMetadataPointer
    dq 0x0                                                     ; +0x0298 LoadConfig.GuardEHContinuationTable
    dq 0x0                                                     ; +0x02a0 LoadConfig.GuardEHContinuationCount
    dq 0x1800020f0                                             ; +0x02a8 LoadConfig.GuardXFGCheckFunctionPointer
    dq 0x180002100                                             ; +0x02b0 LoadConfig.GuardXFGDispatchFunctionPointer
    dq 0x180002108                                             ; +0x02b8 LoadConfig.GuardXFGTableDispatchFunctionPointer
    dq 0x180002110                                             ; +0x02c0 LoadConfig.CastGuardOsDeterminedFailureMode
    dq 0x180002118                                             ; +0x02c8 LoadConfig.GuardMemcpyFunctionPointer
    dd 0x0                                                     ; +0x02d0 Debug directory type 2.Characteristics
    dd 0x67fd0853                                              ; +0x02d4 Debug directory type 2.TimeDateStamp
    dw 0x0                                                     ; +0x02d8 Debug directory type 2.MajorVersion
    dw 0x0                                                     ; +0x02da Debug directory type 2.MinorVersion
    dd 0x2                                                     ; +0x02dc Debug directory type 2.Type
    dd 0x4b                                                    ; +0x02e0 Debug directory type 2.SizeOfData
    dd 0x23dc                                                  ; +0x02e4 Debug directory type 2.AddressOfRawData
    dd 0x15dc                                                  ; +0x02e8 Debug directory type 2.PointerToRawData
    dd 0x0                                                     ; +0x02ec Debug directory type 12.Characteristics
    dd 0x67fd0853                                              ; +0x02f0 Debug directory type 12.TimeDateStamp
    dw 0x0                                                     ; +0x02f4 Debug directory type 12.MajorVersion
    dw 0x0                                                     ; +0x02f6 Debug directory type 12.MinorVersion
    dd 0xc                                                     ; +0x02f8 Debug directory type 12.Type
    dd 0x14                                                    ; +0x02fc Debug directory type 12.SizeOfData
    dd 0x2428                                                  ; +0x0300 Debug directory type 12.AddressOfRawData
    dd 0x1628                                                  ; +0x0304 Debug directory type 12.PointerToRawData
    dd 0x0                                                     ; +0x0308 Debug directory type 13.Characteristics
    dd 0x67fd0853                                              ; +0x030c Debug directory type 13.TimeDateStamp
    dw 0x0                                                     ; +0x0310 Debug directory type 13.MajorVersion
    dw 0x0                                                     ; +0x0312 Debug directory type 13.MinorVersion
    dd 0xd                                                     ; +0x0314 Debug directory type 13.Type
    dd 0x248                                                   ; +0x0318 Debug directory type 13.SizeOfData
    dd 0x243c                                                  ; +0x031c Debug directory type 13.AddressOfRawData
    dd 0x163c                                                  ; +0x0320 Debug directory type 13.PointerToRawData
    dd 0x0                                                     ; +0x0324 Debug directory type 14.Characteristics
    dd 0x67fd0853                                              ; +0x0328 Debug directory type 14.TimeDateStamp
    dw 0x0                                                     ; +0x032c Debug directory type 14.MajorVersion
    dw 0x0                                                     ; +0x032e Debug directory type 14.MinorVersion
    dd 0xe                                                     ; +0x0330 Debug directory type 14.Type
    dd 0x0                                                     ; +0x0334 Debug directory type 14.SizeOfData
    dd 0x0                                                     ; +0x0338 Debug directory type 14.AddressOfRawData
    dd 0x0                                                     ; +0x033c Debug directory type 14.PointerToRawData
    times 0x40 db 0  ; zero fill at +0x340
    dd 0x18                                                    ; +0x0380 VolatileMetadata.Size
    dd 0x80028002                                              ; +0x0384 VolatileMetadata.Version
    dd 0x2398                                                  ; +0x0388 VolatileMetadata.AccessTable
    dd 0x2c                                                    ; +0x038c VolatileMetadata.AccessTableSize
    dd 0x23c4                                                  ; +0x0390 VolatileMetadata.InfoRangeTable
    dd 0x18                                                    ; +0x0394 VolatileMetadata.InfoRangeTableSize
    dd 0x13ff                                                  ; +0x0398 Volatile access instruction RVA
    dd 0x147b                                                  ; +0x039c Volatile access instruction RVA
    dd 0x1490                                                  ; +0x03a0 Volatile access instruction RVA
    dd 0x161d                                                  ; +0x03a4 Volatile access instruction RVA
    dd 0x1633                                                  ; +0x03a8 Volatile access instruction RVA
    dd 0x1903                                                  ; +0x03ac Volatile access instruction RVA
    dd 0x19f6                                                  ; +0x03b0 Volatile access instruction RVA
    dd 0x1a28                                                  ; +0x03b4 Volatile access instruction RVA
    dd 0x1c47                                                  ; +0x03b8 Volatile access instruction RVA
    dd 0x1c4c                                                  ; +0x03bc Volatile access instruction RVA
    dd 0x1c96                                                  ; +0x03c0 Volatile access instruction RVA
    dd 0x1040                                                  ; +0x03c4 Volatile code range start RVA
    dd 0xc90                                                   ; +0x03c8 Volatile code range size
    dd 0x1d14                                                  ; +0x03cc Volatile code range start RVA
    dd 0x7                                                     ; +0x03d0 Volatile code range size
    dd 0x1d66                                                  ; +0x03d4 Volatile code range start RVA
    dd 0x92                                                    ; +0x03d8 Volatile code range size
    db 0x52, 0x53, 0x44, 0x53, 0x9b, 0xdf, 0xa1, 0x00, 0xe5, 0x62, 0x65, 0x46, 0xa6, 0x91, 0x35, 0x1c  ; constant data at +0x3dc
    db 0xe1, 0x87, 0x56, 0xf0, 0x01, 0x00, 0x00, 0x00, 0x47, 0x3a, 0x5c, 0x41, 0x67, 0x65, 0x6e, 0x74  ; constant data at +0x3ec
    db 0x5c, 0x77, 0x6f, 0x72, 0x6b, 0x5c, 0x32, 0x5c, 0x73, 0x5c, 0x73, 0x72, 0x63, 0x5c, 0x6d, 0x6d  ; constant data at +0x3fc
    db 0x5c, 0x41, 0x50, 0x72, 0x73, 0x79, 0x73, 0x74, 0x65, 0x6d, 0x5c, 0x78, 0x65, 0x71, 0x5c, 0x41  ; constant data at +0x40c
    db 0x70, 0x77, 0x6e, 0x52, 0x65, 0x73, 0x2e, 0x70, 0x64, 0x62, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x41c
    db 0x15, 0x00, 0x00, 0x00, 0x15, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00  ; constant data at +0x42c
    db 0x47, 0x43, 0x54, 0x4c, 0x00, 0x10, 0x00, 0x00, 0x30, 0x0d, 0x00, 0x00, 0x2e, 0x74, 0x65, 0x78  ; constant data at +0x43c
    db 0x74, 0x24, 0x6d, 0x6e, 0x00, 0x00, 0x00, 0x00, 0x30, 0x1d, 0x00, 0x00, 0x36, 0x00, 0x00, 0x00  ; constant data at +0x44c
    db 0x2e, 0x74, 0x65, 0x78, 0x74, 0x24, 0x6d, 0x6e, 0x24, 0x30, 0x30, 0x00, 0x66, 0x1d, 0x00, 0x00  ; constant data at +0x45c
    db 0x92, 0x00, 0x00, 0x00, 0x2e, 0x74, 0x65, 0x78, 0x74, 0x24, 0x78, 0x00, 0x00, 0x20, 0x00, 0x00  ; constant data at +0x46c
    db 0xe8, 0x00, 0x00, 0x00, 0x2e, 0x69, 0x64, 0x61, 0x74, 0x61, 0x24, 0x35, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x47c
    db 0xe8, 0x20, 0x00, 0x00, 0x38, 0x00, 0x00, 0x00, 0x2e, 0x30, 0x30, 0x63, 0x66, 0x67, 0x00, 0x00  ; constant data at +0x48c
    db 0x20, 0x21, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x2e, 0x43, 0x52, 0x54, 0x24, 0x58, 0x43, 0x41  ; constant data at +0x49c
    db 0x00, 0x00, 0x00, 0x00, 0x28, 0x21, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x2e, 0x43, 0x52, 0x54  ; constant data at +0x4ac
    db 0x24, 0x58, 0x43, 0x5a, 0x00, 0x00, 0x00, 0x00, 0x30, 0x21, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00  ; constant data at +0x4bc
    db 0x2e, 0x43, 0x52, 0x54, 0x24, 0x58, 0x49, 0x41, 0x00, 0x00, 0x00, 0x00, 0x38, 0x21, 0x00, 0x00  ; constant data at +0x4cc
    db 0x08, 0x00, 0x00, 0x00, 0x2e, 0x43, 0x52, 0x54, 0x24, 0x58, 0x49, 0x5a, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x4dc
    db 0x40, 0x21, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x2e, 0x43, 0x52, 0x54, 0x24, 0x58, 0x50, 0x41  ; constant data at +0x4ec
    db 0x00, 0x00, 0x00, 0x00, 0x48, 0x21, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x2e, 0x43, 0x52, 0x54  ; constant data at +0x4fc
    db 0x24, 0x58, 0x50, 0x5a, 0x00, 0x00, 0x00, 0x00, 0x50, 0x21, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00  ; constant data at +0x50c
    db 0x2e, 0x43, 0x52, 0x54, 0x24, 0x58, 0x54, 0x41, 0x00, 0x00, 0x00, 0x00, 0x58, 0x21, 0x00, 0x00  ; constant data at +0x51c
    db 0x08, 0x00, 0x00, 0x00, 0x2e, 0x43, 0x52, 0x54, 0x24, 0x58, 0x54, 0x5a, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x52c
    db 0x60, 0x21, 0x00, 0x00, 0x20, 0x02, 0x00, 0x00, 0x2e, 0x72, 0x64, 0x61, 0x74, 0x61, 0x00, 0x00  ; constant data at +0x53c
    db 0x80, 0x23, 0x00, 0x00, 0x5c, 0x00, 0x00, 0x00, 0x2e, 0x72, 0x64, 0x61, 0x74, 0x61, 0x24, 0x76  ; constant data at +0x54c
    db 0x6f, 0x6c, 0x74, 0x6d, 0x64, 0x00, 0x00, 0x00, 0xdc, 0x23, 0x00, 0x00, 0xac, 0x02, 0x00, 0x00  ; constant data at +0x55c
    db 0x2e, 0x72, 0x64, 0x61, 0x74, 0x61, 0x24, 0x7a, 0x7a, 0x7a, 0x64, 0x62, 0x67, 0x00, 0x00, 0x00  ; constant data at +0x56c
    db 0x88, 0x26, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x2e, 0x72, 0x74, 0x63, 0x24, 0x49, 0x41, 0x41  ; constant data at +0x57c
    db 0x00, 0x00, 0x00, 0x00, 0x90, 0x26, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x2e, 0x72, 0x74, 0x63  ; constant data at +0x58c
    db 0x24, 0x49, 0x5a, 0x5a, 0x00, 0x00, 0x00, 0x00, 0x98, 0x26, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00  ; constant data at +0x59c
    db 0x2e, 0x72, 0x74, 0x63, 0x24, 0x54, 0x41, 0x41, 0x00, 0x00, 0x00, 0x00, 0xa0, 0x26, 0x00, 0x00  ; constant data at +0x5ac
    db 0x08, 0x00, 0x00, 0x00, 0x2e, 0x72, 0x74, 0x63, 0x24, 0x54, 0x5a, 0x5a, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x5bc
    db 0xa8, 0x26, 0x00, 0x00, 0x84, 0x01, 0x00, 0x00, 0x2e, 0x78, 0x64, 0x61, 0x74, 0x61, 0x00, 0x00  ; constant data at +0x5cc
    db 0x2c, 0x28, 0x00, 0x00, 0x3c, 0x00, 0x00, 0x00, 0x2e, 0x69, 0x64, 0x61, 0x74, 0x61, 0x24, 0x32  ; constant data at +0x5dc
    db 0x00, 0x00, 0x00, 0x00, 0x68, 0x28, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x2e, 0x69, 0x64, 0x61  ; constant data at +0x5ec
    db 0x74, 0x61, 0x24, 0x33, 0x00, 0x00, 0x00, 0x00, 0x80, 0x28, 0x00, 0x00, 0xe8, 0x00, 0x00, 0x00  ; constant data at +0x5fc
    db 0x2e, 0x69, 0x64, 0x61, 0x74, 0x61, 0x24, 0x34, 0x00, 0x00, 0x00, 0x00, 0x68, 0x29, 0x00, 0x00  ; constant data at +0x60c
    db 0x7e, 0x02, 0x00, 0x00, 0x2e, 0x69, 0x64, 0x61, 0x74, 0x61, 0x24, 0x36, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x61c
    db 0x00, 0x30, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x2e, 0x64, 0x61, 0x74, 0x61, 0x00, 0x00, 0x00  ; constant data at +0x62c
    db 0x40, 0x30, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x2e, 0x62, 0x73, 0x73, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x63c
    db 0x00, 0x40, 0x00, 0x00, 0xa4, 0x01, 0x00, 0x00, 0x2e, 0x70, 0x64, 0x61, 0x74, 0x61, 0x00, 0x00  ; constant data at +0x64c
    db 0x00, 0x50, 0x00, 0x00, 0x40, 0x2c, 0x00, 0x00, 0x2e, 0x72, 0x73, 0x72, 0x63, 0x24, 0x30, 0x31  ; constant data at +0x65c
    db 0x00, 0x00, 0x00, 0x00, 0x40, 0x7c, 0x00, 0x00, 0xc0, 0x5a, 0x56, 0x00, 0x2e, 0x72, 0x73, 0x72  ; constant data at +0x66c
    db 0x63, 0x24, 0x30, 0x32, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00  ; constant data at +0x67c
    times 16 db 0  ; constant data at +0x68c
    times 12 db 0  ; constant data at +0x69c
    db 0x1                                                     ; +0x06a8 UNWIND_INFO Version and flags
    db 0x0                                                     ; +0x06a9 UNWIND_INFO Prologue bytes
    db 0x0                                                     ; +0x06aa UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x06ab UNWIND_INFO Frame register and scaled offset
    db 0x11                                                    ; +0x06ac UNWIND_INFO Version and flags
    db 0x15                                                    ; +0x06ad UNWIND_INFO Prologue bytes
    db 0x8                                                     ; +0x06ae UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x06af UNWIND_INFO Frame register and scaled offset
    dw 0x7415                                                  ; +0x06b0 Unwind operation slot
    dw 0x9                                                     ; +0x06b2 Unwind operation slot
    dw 0x6415                                                  ; +0x06b4 Unwind operation slot
    dw 0x7                                                     ; +0x06b6 Unwind operation slot
    dw 0x3415                                                  ; +0x06b8 Unwind operation slot
    dw 0x6                                                     ; +0x06ba Unwind operation slot
    dw 0x3215                                                  ; +0x06bc Unwind operation slot
    dw 0xe011                                                  ; +0x06be Unwind operation slot
    dd 0x1cd0                                                  ; +0x06c0 __C_specific_handler RVA
    dd 0x2                                                     ; +0x06c4 Scope record count
    dd 0x10c8                                                  ; +0x06c8 Scope 1 Begin RVA
    dd 0x1137                                                  ; +0x06cc Scope 1 End RVA
    dd 0x1d66                                                  ; +0x06d0 Scope 1 Handler RVA
    dd 0x0                                                     ; +0x06d4 Scope 1 Continue RVA
    dd 0x119a                                                  ; +0x06d8 Scope 2 Begin RVA
    dd 0x11a5                                                  ; +0x06dc Scope 2 End RVA
    dd 0x1d66                                                  ; +0x06e0 Scope 2 Handler RVA
    dd 0x0                                                     ; +0x06e4 Scope 2 Continue RVA
    db 0x1                                                     ; +0x06e8 UNWIND_INFO Version and flags
    db 0x6                                                     ; +0x06e9 UNWIND_INFO Prologue bytes
    db 0x2                                                     ; +0x06ea UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x06eb UNWIND_INFO Frame register and scaled offset
    dw 0x3206                                                  ; +0x06ec Unwind operation slot
    dw 0x5002                                                  ; +0x06ee Unwind operation slot
    db 0x11                                                    ; +0x06f0 UNWIND_INFO Version and flags
    db 0xa                                                     ; +0x06f1 UNWIND_INFO Prologue bytes
    db 0x4                                                     ; +0x06f2 UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x06f3 UNWIND_INFO Frame register and scaled offset
    dw 0x340a                                                  ; +0x06f4 Unwind operation slot
    dw 0x8                                                     ; +0x06f6 Unwind operation slot
    dw 0x520a                                                  ; +0x06f8 Unwind operation slot
    dw 0x7006                                                  ; +0x06fa Unwind operation slot
    dd 0x1cd0                                                  ; +0x06fc __C_specific_handler RVA
    dd 0x4                                                     ; +0x0700 Scope record count
    dd 0x11df                                                  ; +0x0704 Scope 1 Begin RVA
    dd 0x11fe                                                  ; +0x0708 Scope 1 End RVA
    dd 0x1d7d                                                  ; +0x070c Scope 1 Handler RVA
    dd 0x0                                                     ; +0x0710 Scope 1 Continue RVA
    dd 0x11d4                                                  ; +0x0714 Scope 2 Begin RVA
    dd 0x1216                                                  ; +0x0718 Scope 2 End RVA
    dd 0x1d96                                                  ; +0x071c Scope 2 Handler RVA
    dd 0x0                                                     ; +0x0720 Scope 2 Continue RVA
    dd 0x121f                                                  ; +0x0724 Scope 3 Begin RVA
    dd 0x122a                                                  ; +0x0728 Scope 3 End RVA
    dd 0x1d7d                                                  ; +0x072c Scope 3 Handler RVA
    dd 0x0                                                     ; +0x0730 Scope 3 Continue RVA
    dd 0x121f                                                  ; +0x0734 Scope 4 Begin RVA
    dd 0x122b                                                  ; +0x0738 Scope 4 End RVA
    dd 0x1d96                                                  ; +0x073c Scope 4 Handler RVA
    dd 0x0                                                     ; +0x0740 Scope 4 Continue RVA
    db 0x1                                                     ; +0x0744 UNWIND_INFO Version and flags
    db 0x4                                                     ; +0x0745 UNWIND_INFO Prologue bytes
    db 0x1                                                     ; +0x0746 UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x0747 UNWIND_INFO Frame register and scaled offset
    dw 0x4204                                                  ; +0x0748 Unwind operation slot
    dw 0x0                                                     ; +0x074a Unwind alignment
    db 0x9                                                     ; +0x074c UNWIND_INFO Version and flags
    db 0x1a                                                    ; +0x074d UNWIND_INFO Prologue bytes
    db 0x6                                                     ; +0x074e UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x074f UNWIND_INFO Frame register and scaled offset
    dw 0x341a                                                  ; +0x0750 Unwind operation slot
    dw 0xf                                                     ; +0x0752 Unwind operation slot
    dw 0x721a                                                  ; +0x0754 Unwind operation slot
    dw 0xe016                                                  ; +0x0756 Unwind operation slot
    dw 0x7014                                                  ; +0x0758 Unwind operation slot
    dw 0x6013                                                  ; +0x075a Unwind operation slot
    dd 0x1cd0                                                  ; +0x075c __C_specific_handler RVA
    dd 0x1                                                     ; +0x0760 Scope record count
    dd 0x1261                                                  ; +0x0764 Scope 1 Begin RVA
    dd 0x1347                                                  ; +0x0768 Scope 1 End RVA
    dd 0x1daa                                                  ; +0x076c Scope 1 Handler RVA
    dd 0x1347                                                  ; +0x0770 Scope 1 Continue RVA
    db 0x1                                                     ; +0x0774 UNWIND_INFO Version and flags
    db 0x6                                                     ; +0x0775 UNWIND_INFO Prologue bytes
    db 0x2                                                     ; +0x0776 UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x0777 UNWIND_INFO Frame register and scaled offset
    dw 0x5206                                                  ; +0x0778 Unwind operation slot
    dw 0x5002                                                  ; +0x077a Unwind operation slot
    db 0x1                                                     ; +0x077c UNWIND_INFO Version and flags
    db 0xf                                                     ; +0x077d UNWIND_INFO Prologue bytes
    db 0x6                                                     ; +0x077e UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x077f UNWIND_INFO Frame register and scaled offset
    dw 0x640f                                                  ; +0x0780 Unwind operation slot
    dw 0x7                                                     ; +0x0782 Unwind operation slot
    dw 0x340f                                                  ; +0x0784 Unwind operation slot
    dw 0x6                                                     ; +0x0786 Unwind operation slot
    dw 0x320f                                                  ; +0x0788 Unwind operation slot
    dw 0x700b                                                  ; +0x078a Unwind operation slot
    db 0x1                                                     ; +0x078c UNWIND_INFO Version and flags
    db 0x9                                                     ; +0x078d UNWIND_INFO Prologue bytes
    db 0x1                                                     ; +0x078e UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x078f UNWIND_INFO Frame register and scaled offset
    dw 0x6209                                                  ; +0x0790 Unwind operation slot
    dw 0x0                                                     ; +0x0792 Unwind alignment
    db 0x1                                                     ; +0x0794 UNWIND_INFO Version and flags
    db 0x8                                                     ; +0x0795 UNWIND_INFO Prologue bytes
    db 0x4                                                     ; +0x0796 UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x0797 UNWIND_INFO Frame register and scaled offset
    dw 0x7208                                                  ; +0x0798 Unwind operation slot
    dw 0x7004                                                  ; +0x079a Unwind operation slot
    dw 0x6003                                                  ; +0x079c Unwind operation slot
    dw 0x3002                                                  ; +0x079e Unwind operation slot
    db 0x1                                                     ; +0x07a0 UNWIND_INFO Version and flags
    db 0x6                                                     ; +0x07a1 UNWIND_INFO Prologue bytes
    db 0x2                                                     ; +0x07a2 UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x07a3 UNWIND_INFO Frame register and scaled offset
    dw 0x3206                                                  ; +0x07a4 Unwind operation slot
    dw 0x3002                                                  ; +0x07a6 Unwind operation slot
    db 0x1                                                     ; +0x07a8 UNWIND_INFO Version and flags
    db 0xd                                                     ; +0x07a9 UNWIND_INFO Prologue bytes
    db 0x4                                                     ; +0x07aa UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x07ab UNWIND_INFO Frame register and scaled offset
    dw 0x340d                                                  ; +0x07ac Unwind operation slot
    dw 0xa                                                     ; +0x07ae Unwind operation slot
    dw 0x520d                                                  ; +0x07b0 Unwind operation slot
    dw 0x5006                                                  ; +0x07b2 Unwind operation slot
    db 0x9                                                     ; +0x07b4 UNWIND_INFO Version and flags
    db 0x4                                                     ; +0x07b5 UNWIND_INFO Prologue bytes
    db 0x1                                                     ; +0x07b6 UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x07b7 UNWIND_INFO Frame register and scaled offset
    dw 0x2204                                                  ; +0x07b8 Unwind operation slot
    dw 0x0                                                     ; +0x07ba Unwind alignment
    dd 0x1cd0                                                  ; +0x07bc __C_specific_handler RVA
    dd 0x1                                                     ; +0x07c0 Scope record count
    dd 0x185b                                                  ; +0x07c4 Scope 1 Begin RVA
    dd 0x18e5                                                  ; +0x07c8 Scope 1 End RVA
    dd 0x1de0                                                  ; +0x07cc Scope 1 Handler RVA
    dd 0x18e5                                                  ; +0x07d0 Scope 1 Continue RVA
    db 0x1                                                     ; +0x07d4 UNWIND_INFO Version and flags
    db 0x2                                                     ; +0x07d5 UNWIND_INFO Prologue bytes
    db 0x1                                                     ; +0x07d6 UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x07d7 UNWIND_INFO Frame register and scaled offset
    dw 0x5002                                                  ; +0x07d8 Unwind operation slot
    dw 0x0                                                     ; +0x07da Unwind alignment
    db 0x1                                                     ; +0x07dc UNWIND_INFO Version and flags
    db 0x14                                                    ; +0x07dd UNWIND_INFO Prologue bytes
    db 0x8                                                     ; +0x07de UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x07df UNWIND_INFO Frame register and scaled offset
    dw 0x6414                                                  ; +0x07e0 Unwind operation slot
    dw 0x8                                                     ; +0x07e2 Unwind operation slot
    dw 0x5414                                                  ; +0x07e4 Unwind operation slot
    dw 0x7                                                     ; +0x07e6 Unwind operation slot
    dw 0x3414                                                  ; +0x07e8 Unwind operation slot
    dw 0x6                                                     ; +0x07ea Unwind operation slot
    dw 0x3214                                                  ; +0x07ec Unwind operation slot
    dw 0x7010                                                  ; +0x07ee Unwind operation slot
    db 0x1                                                     ; +0x07f0 UNWIND_INFO Version and flags
    db 0x15                                                    ; +0x07f1 UNWIND_INFO Prologue bytes
    db 0x5                                                     ; +0x07f2 UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x07f3 UNWIND_INFO Frame register and scaled offset
    dw 0x3415                                                  ; +0x07f4 Unwind operation slot
    dw 0xba                                                    ; +0x07f6 Unwind operation slot
    dw 0x115                                                   ; +0x07f8 Unwind operation slot
    dw 0xb8                                                    ; +0x07fa Unwind operation slot
    dw 0x5006                                                  ; +0x07fc Unwind operation slot
    dw 0x0                                                     ; +0x07fe Unwind alignment
    db 0x1                                                     ; +0x0800 UNWIND_INFO Version and flags
    db 0xa                                                     ; +0x0801 UNWIND_INFO Prologue bytes
    db 0x4                                                     ; +0x0802 UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x0803 UNWIND_INFO Frame register and scaled offset
    dw 0x340a                                                  ; +0x0804 Unwind operation slot
    dw 0x6                                                     ; +0x0806 Unwind operation slot
    dw 0x320a                                                  ; +0x0808 Unwind operation slot
    dw 0x7006                                                  ; +0x080a Unwind operation slot
    db 0x1                                                     ; +0x080c UNWIND_INFO Version and flags
    db 0xf                                                     ; +0x080d UNWIND_INFO Prologue bytes
    db 0x6                                                     ; +0x080e UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x080f UNWIND_INFO Frame register and scaled offset
    dw 0x640f                                                  ; +0x0810 Unwind operation slot
    dw 0x6                                                     ; +0x0812 Unwind operation slot
    dw 0x340f                                                  ; +0x0814 Unwind operation slot
    dw 0x5                                                     ; +0x0816 Unwind operation slot
    dw 0x120f                                                  ; +0x0818 Unwind operation slot
    dw 0x700b                                                  ; +0x081a Unwind operation slot
    times 0x4 db 0  ; zero fill at +0x81c
    db 0x1                                                     ; +0x0820 UNWIND_INFO Version and flags
    db 0x0                                                     ; +0x0821 UNWIND_INFO Prologue bytes
    db 0x0                                                     ; +0x0822 UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x0823 UNWIND_INFO Frame register and scaled offset
    times 0x4 db 0  ; zero fill at +0x824
    db 0x1                                                     ; +0x0828 UNWIND_INFO Version and flags
    db 0x0                                                     ; +0x0829 UNWIND_INFO Prologue bytes
    db 0x0                                                     ; +0x082a UNWIND_INFO Unwind code slots
    db 0x0                                                     ; +0x082b UNWIND_INFO Frame register and scaled offset
    dd 0x28f8                                                  ; +0x082c Import VCRUNTIME140.dll.OriginalFirstThunk
    dd 0x0                                                     ; +0x0830 Import VCRUNTIME140.dll.TimeDateStamp
    dd 0x0                                                     ; +0x0834 Import VCRUNTIME140.dll.ForwarderChain
    dd 0x29aa                                                  ; +0x0838 Import VCRUNTIME140.dll.Name
    dd 0x2078                                                  ; +0x083c Import VCRUNTIME140.dll.FirstThunk
    dd 0x2920                                                  ; +0x0840 Import api-ms-win-crt-runtime-l1-1-0.dll.OriginalFirstThunk
    dd 0x0                                                     ; +0x0844 Import api-ms-win-crt-runtime-l1-1-0.dll.TimeDateStamp
    dd 0x0                                                     ; +0x0848 Import api-ms-win-crt-runtime-l1-1-0.dll.ForwarderChain
    dd 0x2a62                                                  ; +0x084c Import api-ms-win-crt-runtime-l1-1-0.dll.Name
    dd 0x20a0                                                  ; +0x0850 Import api-ms-win-crt-runtime-l1-1-0.dll.FirstThunk
    dd 0x2880                                                  ; +0x0854 Import KERNEL32.dll.OriginalFirstThunk
    dd 0x0                                                     ; +0x0858 Import KERNEL32.dll.TimeDateStamp
    dd 0x0                                                     ; +0x085c Import KERNEL32.dll.ForwarderChain
    dd 0x2bce                                                  ; +0x0860 Import KERNEL32.dll.Name
    dd 0x2000                                                  ; +0x0864 Import KERNEL32.dll.FirstThunk
    times 0x18 db 0  ; zero fill at +0x868
    dq 0x2b74                                                  ; +0x0880 Import lookup GetCurrentThreadId
    dq 0x2ab2                                                  ; +0x0888 Import lookup RtlVirtualUnwind
    dq 0x2a98                                                  ; +0x0890 Import lookup RtlLookupFunctionEntry
    dq 0x2a84                                                  ; +0x0898 Import lookup RtlCaptureContext
    dq 0x2ae2                                                  ; +0x08a0 Import lookup SetUnhandledExceptionFilter
    dq 0x2b00                                                  ; +0x08a8 Import lookup GetCurrentProcess
    dq 0x2bba                                                  ; +0x08b0 Import lookup IsDebuggerPresent
    dq 0x2ba4                                                  ; +0x08b8 Import lookup InitializeSListHead
    dq 0x2b8a                                                  ; +0x08c0 Import lookup GetSystemTimeAsFileTime
    dq 0x2ac6                                                  ; +0x08c8 Import lookup UnhandledExceptionFilter
    dq 0x2b5e                                                  ; +0x08d0 Import lookup GetCurrentProcessId
    dq 0x2b44                                                  ; +0x08d8 Import lookup QueryPerformanceCounter
    dq 0x2b28                                                  ; +0x08e0 Import lookup IsProcessorFeaturePresent
    dq 0x2b14                                                  ; +0x08e8 Import lookup TerminateProcess
    times 0x8 db 0  ; zero fill at +0x8f0
    dq 0x2bdc                                                  ; +0x08f8 Import lookup memcpy
    dq 0x2980                                                  ; +0x0900 Import lookup __std_type_info_destroy_list
    dq 0x2968                                                  ; +0x0908 Import lookup __C_specific_handler
    dq 0x29a0                                                  ; +0x0910 Import lookup memset
    times 0x8 db 0  ; zero fill at +0x918
    dq 0x2a58                                                  ; +0x0920 Import lookup _cexit
    dq 0x2a40                                                  ; +0x0928 Import lookup _execute_onexit_table
    dq 0x2a24                                                  ; +0x0930 Import lookup _initialize_onexit_table
    dq 0x2a02                                                  ; +0x0938 Import lookup _initialize_narrow_environment
    dq 0x29e8                                                  ; +0x0940 Import lookup _configure_narrow_argv
    dq 0x29d6                                                  ; +0x0948 Import lookup _seh_filter_dll
    dq 0x29c8                                                  ; +0x0950 Import lookup _initterm_e
    dq 0x29bc                                                  ; +0x0958 Import lookup _initterm
    times 0x8 db 0  ; zero fill at +0x960
    dw 0x8                                                     ; +0x0968 Import hint __C_specific_handler
    db '__C_specific_handler', 0                               ; +0x096a Import symbol
    times 0x1 db 0  ; zero fill at +0x97f
    dw 0x25                                                    ; +0x0980 Import hint __std_type_info_destroy_list
    db '__std_type_info_destroy_list', 0                       ; +0x0982 Import symbol
    times 0x1 db 0  ; zero fill at +0x99f
    dw 0x3e                                                    ; +0x09a0 Import hint memset
    db 'memset', 0                                             ; +0x09a2 Import symbol
    times 0x1 db 0  ; zero fill at +0x9a9
    db 'VCRUNTIME140.dll', 0                                   ; +0x09aa Import DLL name
    times 0x1 db 0  ; zero fill at +0x9bb
    dw 0x36                                                    ; +0x09bc Import hint _initterm
    db '_initterm', 0                                          ; +0x09be Import symbol
    dw 0x37                                                    ; +0x09c8 Import hint _initterm_e
    db '_initterm_e', 0                                        ; +0x09ca Import symbol
    dw 0x3f                                                    ; +0x09d6 Import hint _seh_filter_dll
    db '_seh_filter_dll', 0                                    ; +0x09d8 Import symbol
    dw 0x18                                                    ; +0x09e8 Import hint _configure_narrow_argv
    db '_configure_narrow_argv', 0                             ; +0x09ea Import symbol
    times 0x1 db 0  ; zero fill at +0xa01
    dw 0x33                                                    ; +0x0a02 Import hint _initialize_narrow_environment
    db '_initialize_narrow_environment', 0                     ; +0x0a04 Import symbol
    times 0x1 db 0  ; zero fill at +0xa23
    dw 0x34                                                    ; +0x0a24 Import hint _initialize_onexit_table
    db '_initialize_onexit_table', 0                           ; +0x0a26 Import symbol
    times 0x1 db 0  ; zero fill at +0xa3f
    dw 0x22                                                    ; +0x0a40 Import hint _execute_onexit_table
    db '_execute_onexit_table', 0                              ; +0x0a42 Import symbol
    dw 0x16                                                    ; +0x0a58 Import hint _cexit
    db '_cexit', 0                                             ; +0x0a5a Import symbol
    times 0x1 db 0  ; zero fill at +0xa61
    db 'api-ms-win-crt-runtime-l1-1-0.dll', 0                  ; +0x0a62 Import DLL name
    dw 0x4f5                                                   ; +0x0a84 Import hint RtlCaptureContext
    db 'RtlCaptureContext', 0                                  ; +0x0a86 Import symbol
    dw 0x4fd                                                   ; +0x0a98 Import hint RtlLookupFunctionEntry
    db 'RtlLookupFunctionEntry', 0                             ; +0x0a9a Import symbol
    times 0x1 db 0  ; zero fill at +0xab1
    dw 0x504                                                   ; +0x0ab2 Import hint RtlVirtualUnwind
    db 'RtlVirtualUnwind', 0                                   ; +0x0ab4 Import symbol
    times 0x1 db 0  ; zero fill at +0xac5
    dw 0x5e6                                                   ; +0x0ac6 Import hint UnhandledExceptionFilter
    db 'UnhandledExceptionFilter', 0                           ; +0x0ac8 Import symbol
    times 0x1 db 0  ; zero fill at +0xae1
    dw 0x5a4                                                   ; +0x0ae2 Import hint SetUnhandledExceptionFilter
    db 'SetUnhandledExceptionFilter', 0                        ; +0x0ae4 Import symbol
    dw 0x232                                                   ; +0x0b00 Import hint GetCurrentProcess
    db 'GetCurrentProcess', 0                                  ; +0x0b02 Import symbol
    dw 0x5c4                                                   ; +0x0b14 Import hint TerminateProcess
    db 'TerminateProcess', 0                                   ; +0x0b16 Import symbol
    times 0x1 db 0  ; zero fill at +0xb27
    dw 0x3a8                                                   ; +0x0b28 Import hint IsProcessorFeaturePresent
    db 'IsProcessorFeaturePresent', 0                          ; +0x0b2a Import symbol
    dw 0x470                                                   ; +0x0b44 Import hint QueryPerformanceCounter
    db 'QueryPerformanceCounter', 0                            ; +0x0b46 Import symbol
    dw 0x233                                                   ; +0x0b5e Import hint GetCurrentProcessId
    db 'GetCurrentProcessId', 0                                ; +0x0b60 Import symbol
    dw 0x237                                                   ; +0x0b74 Import hint GetCurrentThreadId
    db 'GetCurrentThreadId', 0                                 ; +0x0b76 Import symbol
    times 0x1 db 0  ; zero fill at +0xb89
    dw 0x30a                                                   ; +0x0b8a Import hint GetSystemTimeAsFileTime
    db 'GetSystemTimeAsFileTime', 0                            ; +0x0b8c Import symbol
    dw 0x38a                                                   ; +0x0ba4 Import hint InitializeSListHead
    db 'InitializeSListHead', 0                                ; +0x0ba6 Import symbol
    dw 0x3a0                                                   ; +0x0bba Import hint IsDebuggerPresent
    db 'IsDebuggerPresent', 0                                  ; +0x0bbc Import symbol
    db 'KERNEL32.dll', 0                                       ; +0x0bce Import DLL name
    times 0x1 db 0  ; zero fill at +0xbdb
    dw 0x3c                                                    ; +0x0bdc Import hint memcpy
    db 'memcpy', 0                                             ; +0x0bde Import symbol
    times 0x1b db 0  ; zero fill at +0xbe5
