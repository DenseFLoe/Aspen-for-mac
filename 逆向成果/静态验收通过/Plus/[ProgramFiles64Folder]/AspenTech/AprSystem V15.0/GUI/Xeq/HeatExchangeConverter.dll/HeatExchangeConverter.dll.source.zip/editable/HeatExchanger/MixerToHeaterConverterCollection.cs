using System.Runtime.InteropServices;

namespace HeatExchanger;

[ComVisible(true)]
[Guid("E6E84FBD-BDD4-42D7-9108-BE0DFF473902")]
[ProgId("HeatExchanger.MixerToHeaterConverterCollection.41.0")]
[ClassInterface(ClassInterfaceType.None)]
public class MixerToHeaterConverterCollection : ConverterCollection
{
	public MixerToHeaterConverterCollection()
		: base("Mixer")
	{
	}
}
