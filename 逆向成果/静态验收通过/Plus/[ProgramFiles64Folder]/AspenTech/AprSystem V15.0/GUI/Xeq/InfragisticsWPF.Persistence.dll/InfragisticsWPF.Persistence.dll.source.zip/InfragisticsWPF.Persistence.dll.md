# InfragisticsWPF.Persistence.dll

## 原件与交付

- 产品 Aspen Plus，安装 Aspen V15.0。文件和程序集版本均为 21.2.20212.9。
- 原件 `C:\Program Files\AspenTech\AprSystem V15.0\GUI\Xeq\InfragisticsWPF.Persistence.dll`，57,384 字节，SHA-256 `dd19c93a74c439a27e214e36e2532b63b7dc5053925b02b80065ff477f84283e`。
- 对象位于主干固定提交 `adbe73b517acac25da87598cce46de033f630ccb` 待静态验收目录，安装相对路径为 `[ProgramFiles64Folder]/AspenTech/AprSystem V15.0/GUI/Xeq/InfragisticsWPF.Persistence.dll`。
- 可编辑 C#、程序集公钥和两项编译资源取自登记的 v9，旧 ZIP SHA-256 `bdd0b71b9f5ab031b1a94fd993ab8b4e6441c681ebfbbe155d3aa9bab73f22d8`。直接编译仅使用这四项旧输入。逐成员指纹见 `MANIFEST.sha256`。

## 从空目录复现

把本包解至空目录并进入解包根。准备 Windows、Python 3.12、Roslyn `csc.exe` 及其随附运行组件、八个 .NET Framework 4.0 引用程序集，以及本机安装的 `InfragisticsWPF.dll` 21.2.20212.9。编译器的 `/version` 实测为 `3.4.0-beta4-19568-04 (82f2e254)`，配置要求 .NET Framework 4.7.2 运行时。具体文件名、依赖版本与输入指纹见 `evidence/build-inputs.json`。验证阶段的 PE 解析源码随包提供。编译与验证均可离线，编译无需安装的 Persistence 原件，也无需 dotnet SDK。

PowerShell 示例中的 `$csc` 指向上述编译器，`$framework` 指向 .NET 4.0 引用目录，`$infragistics` 指向 `InfragisticsWPF.dll`，`$original` 指向安装原件。输出目录由命令创建。

```powershell
python -B .\build.py --csc $csc --framework $framework --infragistics $infragistics --out .\out
python -B .\evidence\compare.py $original .\out\InfragisticsWPF.Persistence.dll .\out\static.json
```

直接编译产物为 `out/InfragisticsWPF.Persistence.dll`，SHA-256 `d6f03f543ce438fb993ae9e2a3837e9a3163bed886df588cf94761252f3979c0`。编译器报告 CS0436，选择源码中定义的 `SR`、`InternalDynamicResourceString`。回编后的调用目标由相同绑定元数据和方法体核实。比较要求第一个输入为安装原件，输出 `out/static.json`，所有比较项真时返回 0。

## 制作核验

- 归一化整块 CLR 元数据后相同，唯一屏蔽项为 232 行的物理 RVA 和 Module 的 MVID 槽。候选有 159 项非零方法 RVA 变动。完整元数据包含全部类型、字段、成员定义、签名、事件语义、程序集引用、常量、定制属性、局部签名、标记绑定和字符串堆。配合 231 个完整方法体逐 token 的相等指纹，可核对所有指令、操作数、分支、调用、局部变量与 29 个异常子句。唯一无体项是原件的抽象声明 `PropertyPersistenceInfoBase.DoesPropertyMeetCriteria`（`0x06000097`）。例如恢复稿的 `FixAssemblyQualifiedName` 返回 null，与原件同 token 方法体相同。
- 两边 CLR `ImplMap` 和 `PinvokeImpl` 标志各为 0。PE 启动导入均为 `mscoree.dll!_CorDllMain`，入口桩和启动重定位关系相同。
- 托管资源目录相同。唯一成员 `Infragistics.Persistence.strings.resources` 316 字节，SHA-256 `569fdd801ba790320bf18a9d9f448928cf043e01ff3b57b6036d4fd0a350870d`。唯一 Win32 叶为 `VERSIONINFO/1/0`，1,138 字节，SHA-256 `c1dedd06890406ea85b79c6a6177b784580b02816e0e779ce4cfe5961f69ced7`，版本 21.2.20212.9。资源叶路径、语言、代码页与内容相同。
- 本件是 WPF 持久化库。资源表仅含字符串资源与 Win32 版本，类型和源码检查也未见本件自带的页面、控件模板、XAML、BAML、RCDATA、`InitializeComponent`、连接器或独立界面绑定定义。程序集保有 `XmlnsPrefix` 和 `XmlnsDefinition`。原有 WPF 交互由全方法及绑定核对覆盖，具体包括三个 attached property（`Settings`、`PersistenceGroup`、`Identifier`），对应 `DependencyObject.GetValue/SetValue` 与 `PersistenceGroupChanged` 注册回调。四个持久化事件 `SavePropertyPersistence`、`LoadPropertyPersistence`、`PersistenceLoaded`、`PersistenceSaved` 的声明、访问器和触发调用一致。属性树走 `BuildPropertyTree` 等反射递归，保留 `FrameworkElement` 的 `Name` 筛选和 `DataContext` 跳过逻辑。
- `evidence/producer-static.json` 保存实测。比较脚本按各自 RVA 读取完整方法体并检查每个 token，通过元数据共同的令牌空间核对绑定。PE 资源沿用现有严格目录遍历。脚本接受原件和直接产物，不拼接也不写回任何 PE 数据。

## 构建差异与验收状态

源码编译结果使用原程序集公开密钥作 public-sign。128 字节强命名留位为空，原带 10,280 字节 Authenticode 表，候选无该表。独立 MVID、方法布局、PE 时间戳、校验和、重定位的绝对地址与调试指针随编译变化。v9 历史路线曾回放原版 MVID、PE 布局、调试/认证记录与签名，本包不含回放脚本、原 PE 片段或历史占位回执。

制作阶段静态核对六项均通过，整件待独立复核。正式供应商签名和 Windows 实际加载、序列化行为留待 Windows 重建对照。
