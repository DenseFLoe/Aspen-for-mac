using System.Collections;
using System.Runtime.InteropServices;
using AspenTech.AspenPlus.APConvert;

namespace HeatExchanger;

[ComVisible(false)]
public class ConverterCollection : IAPConverterCollection
{
	private ArrayList convertCollection;

	private HeatExchangeConverter hConvert1;

	private MixerConverter hConvert2;

	private HeaterConverter hConvert3;

	public string convertType;

	public object this[int i] => convertCollection[i - 1];

	public int Count => convertCollection.Count;

	public ConverterCollection(string type)
	{
		convertType = type;
		convertCollection = new ArrayList();
		if (type.ToUpper() == "MIXER")
		{
			hConvert2 = new MixerConverter(convertType);
			convertCollection.Add(hConvert2);
		}
		else if (type.ToUpper() == "HEATER")
		{
			hConvert3 = new HeaterConverter(convertType);
			convertCollection.Add(hConvert3);
		}
		else
		{
			hConvert1 = new HeatExchangeConverter(convertType);
			convertCollection.Add(hConvert1);
		}
	}

	public IEnumerator GetEnumerator()
	{
		return (this as IEnumerable).GetEnumerator();
	}
}
