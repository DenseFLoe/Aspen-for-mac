#!/usr/bin/env python3
"""declaration_restore2.py variant that pins rules to an exact MethodDef row.

declaration_restore2.py selects the single row whose name ends in the target and
whose flags equal expected_flags.  When one owner has overloads sharing a name
(e.g. GetProperty(int,...) and GetProperty(ref byte,...)), both can be eligible.
This variant accepts `candidate_row` from derive_rules2.py, verifies the row's
name and flags against the rule, and edits only that row.  Rules without a row
fall back to the original owner+name+flags selection.

Usage: declaration_restore3.py --image X --rules R --out Y
"""
import argparse
import json
import struct
import sys
from hashlib import sha256
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / ".." / "managed-override-1"))
sys.path.insert(0, str(HERE.parents[1] / "managed"))
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")
import clr_meta  # noqa: E402
import declaration_restore2 as dr  # noqa: E402

MD_TABLE = 0x06


def restore(image_bytes, rules):
    pe, cli, root = clr_meta.read_image(image_bytes)
    tables = root["tables"]
    layout = tables["layout"][MD_TABLE]
    content = bytearray(root["bytes"])
    md_file = pe.get_offset_from_rva(cli["metadata_rva"])
    heap_width = 4 if tables["heap_sizes"] & 1 else 2
    strings_map, _ = dr._string_map(pe, cli, root)
    report = []
    touched = set()
    for rule in rules:
        target = rule["target_name"]
        pinned = rule.get("candidate_row")
        if pinned is not None:
            row = clr_meta.read_row(content, tables, MD_TABLE, pinned)
            name = clr_meta.strings(pe, cli, root, row[3])
            if not (name == target or name.endswith("." + target)):
                raise ValueError("row %d name %r does not end in %r" % (pinned, name, target))
            if row[2] != rule["expected_flags"]:
                raise ValueError("row %d flags %#x != expected %#x" % (pinned, row[2], rule["expected_flags"]))
            if pinned in touched:
                raise ValueError("row %d restored twice" % pinned)
            matched = [(pinned, row, name)]
        else:
            matched = []
            for index in range(1, layout["rows"] + 1):
                row = clr_meta.read_row(content, tables, MD_TABLE, index)
                name = clr_meta.strings(pe, cli, root, row[3])
                if ((name == target or name.endswith("." + target)) and row[2] == rule["expected_flags"]
                        and index not in touched):
                    matched.append((index, row, name))
            if len(matched) != 1:
                raise ValueError("MethodDef for %r matched %d rows" % (target, len(matched)))
        index, row, old_name = matched[0]
        touched.add(index)
        new_index = row[3] + (len(old_name) - len(target))
        heap = root["streams"]["#Strings"]
        if not 0 <= new_index < heap["size"]:
            raise ValueError("suffix name of %r falls outside #Strings" % target)
        probe = pe.get_data(cli["metadata_rva"] + heap["offset"] + new_index,
                            min(len(target) + 1, heap["size"] - new_index))
        if probe != target.encode("utf-8") + b"\0":
            raise ValueError("%r is not the suffix of the explicit-impl name" % target)
        strings_map[target] = new_index
        owner = dr._owner_typedef(content, tables, index)
        if owner is None:
            raise ValueError("%s has no owning TypeDef" % target)
        for j in owner:
            if j == index:
                continue
            other = clr_meta.read_row(content, tables, MD_TABLE, j)
            if clr_meta.strings(pe, cli, root, other[3]) == target:
                raise ValueError("renaming %s would collide inside its TypeDef" % target)
        base = layout["offset"] + (index - 1) * layout["row_size"]
        content[base + 6:base + 8] = struct.pack("<H", rule["target_flags"])
        content[base + 8:base + 8 + heap_width] = strings_map[target].to_bytes(heap_width, "little")
        report.append({"methoddef_row": index, "token": 0x06000000 | index,
                       "old_name": old_name, "new_name": target,
                       "old_flags": row[2], "new_flags": rule["target_flags"],
                       "name_string_index": strings_map[target]})
    result = bytearray(image_bytes)
    result[md_file:md_file + len(content)] = content
    return bytes(result), report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True, type=Path)
    ap.add_argument("--rules", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    a = ap.parse_args()
    rules = json.loads(a.rules.read_text("utf-8"))
    if isinstance(rules, dict):
        rules = rules["rules"]
    data, report = restore(a.image.read_bytes(), rules)
    a.out.write_bytes(data)
    print(json.dumps({"in": sha256(a.image.read_bytes()).hexdigest(),
                      "out": sha256(data).hexdigest(), "edits": len(report),
                      "detail": report[:5]}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
