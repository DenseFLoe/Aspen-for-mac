using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using AspenTech.Visualisation.CommonShell;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("Aspentech.ExchangerDesign.Infrastructure")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc")]
[assembly: AssemblyProduct("Aspentech.ExchangerDesign.Infrastructure")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyFileVersion("41.0.0")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace Aspentech.ExchangerDesign.Infrastructure
{
	public static class EDRScreenFactoryKeys
	{
		public static string EDRFormContentFactoryKey = "EDRFormScreenFactory";

		public static string EDRBrowserFactoryKey = "EDRBrowserScreenFactory";

		public static string SimulatorRunStatusScreenFactory = "SimulatorRunStatusScreenFactory";
	}
	public interface IEDRBrowserActiveChanged
	{
		void BrowserActive();

		void BrowserDeactived();
	}
	public interface IExchangerDesignFactory
	{
		object EDRDocument { get; }

		ScreenSubject CreateScreenSubject(string header, string formKey, string objectType, string objectName, string objectKey, bool consoleMode);

		ScreenSubject CreateScreenSubject(string header, string formKey, string objectType, string objectName, string objectKey, bool consoleMode, string program_mode);

		FrameworkElement CreateUserControl(string controlKey, string objectType, string objectKey, bool runOnLoad);

		FrameworkElement CreateEDRFormControl(object edrProvidedScreenSubbject, string objectType, string objectKey);

		void Dispose();
	}
	public interface IExchangerDesignProvider
	{
		string CompatibleExchangerVersionString { get; }

		IntPtr GetATVInterface(string objectType, string objectKey);
	}
}
namespace Aspentech.ExchangerDesign.Infrastructure.Properties
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (resourceMan == null)
				{
					resourceMan = new ResourceManager("Aspentech.ExchangerDesign.Infrastructure.Properties.Resources", typeof(Resources).Assembly);
				}
				return resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return resourceCulture;
			}
			set
			{
				resourceCulture = value;
			}
		}

		internal Resources()
		{
		}
	}
}
namespace Aspentech.ExchangerDesign.Infrastructure.Events
{
	public class ConsoleEvent : RoutedCompositePresentationEvent<ConsoleEventArgs>
	{
		public ConsoleEvent()
		{
			base.RoutingStrategy = CompositeEventRoutingStrategy.FirstOfParents;
		}
	}
	public class ConsoleEventArgs
	{
		private bool _ConsoleMode;

		public string ObjectKey { get; set; }

		public string Event { get; set; }

		public bool InConsoleMode
		{
			get
			{
				return _ConsoleMode;
			}
			set
			{
				_ConsoleMode = value;
			}
		}
	}
	public class EngineUpdateEvent : RoutedCompositePresentationEvent<EngineUpdateEventArgs>
	{
	}
	public class EngineUpdateEventArgs : EventArgs
	{
		public string ObjectKey { get; set; }

		public string Action { get; set; }

		public string[] Args { get; set; }
	}
	public class HysysCloseCaseChangedEvent : RoutedCompositePresentationEvent<HysysCloseCaseChangedArgs>
	{
	}
	public class HysysCloseCaseChangedArgs : EventArgs
	{
		private bool _HysysCaseClosing;

		public bool HysysCaseClosing
		{
			get
			{
				return _HysysCaseClosing;
			}
			set
			{
				_HysysCaseClosing = value;
			}
		}

		public HysysCloseCaseChangedArgs(bool isHysysCaseClosing)
		{
			_HysysCaseClosing = isHysysCaseClosing;
		}
	}
	public class SizeCancelEvent : RoutedCompositePresentationEvent<SizeCancelEventArgs>
	{
	}
	public class SizeCancelEventArgs : EventArgs
	{
	}
	public class DeletedEvent : RoutedCompositePresentationEvent<DeletedEventArgs>
	{
	}
	public class DeletedEventArgs : EventArgs
	{
		public string ObjectKey { get; set; }
	}
	public class RenameEvent : RoutedCompositePresentationEvent<RenameEventArgs>
	{
	}
	public class RenameEventArgs : EventArgs
	{
		public string OldName { get; set; }

		public string NewName { get; set; }

		public string OldKey { get; set; }

		public string NewKey { get; set; }
	}
}
