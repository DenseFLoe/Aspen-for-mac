# RibbonPlotWizardMgr.cs

Source: editable/WpfPLCompr/RibbonPlotWizardMgr.cs

Source SHA-256: dc0657d88f5fd084803ef131b7292f6c3cdb132f385382efb8a0f89e0aa20647
