
//  .NET IL Disassembler.  Version 9.0.23



// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly AdvancedFileDialogLib
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ImportedFromTypeLibAttribute::.ctor(string) = ( 01 00 15 41 64 76 61 6E 63 65 64 46 69 6C 65 44   // ...AdvancedFileD
                                                                                                                 69 61 6C 6F 67 4C 69 62 00 00 )                   // ialogLib..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 45 31 38 37 35 43 43 34 2D 38 35 30 32   // ..$E1875CC4-8502
                                                                                                  2D 34 42 46 46 2D 39 32 33 43 2D 36 30 41 44 36   // -4BFF-923C-60AD6
                                                                                                  45 45 34 45 34 33 32 00 00 )                      // EE4E432..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibVersionAttribute::.ctor(int32,
                                                                                                int32) = ( 01 00 0A 00 00 00 00 00 00 00 00 00 ) 
  .publickey = (00 24 00 00 04 80 00 00 94 00 00 00 06 02 00 00   // .$..............
                00 24 00 00 52 53 41 31 00 04 00 00 01 00 01 00   // .$..RSA1........
                31 CE F7 DF 85 4A 51 60 93 9C 58 8A 09 81 30 D8   // 1....JQ`..X...0.
                3B 58 C6 41 43 FE 98 DE 4F EA 84 44 85 EE C0 F8   // ;X.AC...O..D....
                BF 75 0A 6A 39 BA 8A 55 2E 37 20 73 B6 95 3A 09   // .u.j9..U.7 s..:.
                53 17 FB FB A3 6E B8 37 F2 D0 14 D6 2D 52 2D 2C   // S....n.7....-R-,
                B2 4F 39 B6 12 E0 DA 27 6D BF 15 4A 5D 0F 84 0D   // .O9....'m..J]...
                59 7F 81 E6 0E 83 1D 25 B6 EB C3 47 9D 69 C3 A6   // Y......%...G.i..
                6A 21 E7 D3 A8 62 09 D1 D3 50 BB 90 86 82 98 3C   // j!...b...P.....<
                80 C0 F7 D4 3B 60 C3 48 79 73 35 A7 33 B2 61 C8 ) // ....;`.Hys5.3.a.
  .hash algorithm 0x00008004
  .ver 10:0:0:0
}
.module AdvancedFileDialogLib.dll
// MVID: {b46bf6db-df6f-4363-a0d0-6f8cabc00a2d}
.imagebase 0x00400000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000009    //  ILONLY
// Image base: 0x0000020BF1C40000


// =============== CLASS MEMBERS DECLARATION ===================

.class interface public abstract auto ansi import AdvancedFileDialogLib._DAdvancedFileDialog
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 10 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 34 37 41 38 42 33 43 34 2D 41 34 35 36   // ..$47A8B3C4-A456
                                                                                                  2D 34 34 41 36 2D 41 42 41 46 2D 35 45 39 41 44   // -44A6-ABAF-5E9AD
                                                                                                  38 42 46 33 43 46 32 00 00 )                      // 8BF3CF2..
  .method public hidebysig newslot abstract virtual 
          instance void  AboutBox() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 D8 FD FF FF 00 00 ) 
  } // end of method _DAdvancedFileDialog::AboutBox

  .method public hidebysig newslot abstract virtual 
          instance int32  ShowOpenFileDialog(int32 bShowHierarchy) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::ShowOpenFileDialog

  .method public hidebysig newslot abstract virtual 
          instance int32  ShowSaveFileDialog(int32 bShowHierarchy) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::ShowSaveFileDialog

  .method public hidebysig newslot abstract virtual 
          instance void  SetFileName(string  marshal( lpwstr) lpszFileName) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::SetFileName

  .method public hidebysig newslot abstract virtual 
          instance void  SetFilter(string  marshal( lpwstr) lpszFilter) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::SetFilter

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetFileName() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::GetFileName

  .method public hidebysig newslot abstract virtual 
          instance void  SetInitialDir(string  marshal( lpwstr) lpszInitialDir) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::SetInitialDir

  .method public hidebysig newslot abstract virtual 
          instance int32  GetFilterIndex() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::GetFilterIndex

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetPathName() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::GetPathName

  .method public hidebysig newslot abstract virtual 
          instance void  SetTitle(string  marshal( lpwstr) lpszTitle) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::SetTitle

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetHierarchyName() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::GetHierarchyName

  .method public hidebysig newslot abstract virtual 
          instance void  AddHierarchy(string  marshal( lpwstr) lpszHierarchy) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::AddHierarchy

  .method public hidebysig newslot abstract virtual 
          instance void  SetProductType(int32 iProductType) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::SetProductType

  .method public hidebysig newslot abstract virtual 
          instance void  SetImportOrExportPrompt(string  marshal( lpwstr) lpszImportOrExportPrompt) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::SetImportOrExportPrompt

  .method public hidebysig newslot abstract virtual 
          instance void  SetFavoritesPath(string  marshal( lpwstr) lpszFavoritesPath) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::SetFavoritesPath

  .method public hidebysig newslot abstract virtual 
          instance void  SetChangeDir(int32 bChangeDir) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::SetChangeDir

  .method public hidebysig newslot abstract virtual 
          instance void  SetFilterIndex(int32 iFilterIndex) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::SetFilterIndex

  .method public hidebysig newslot abstract virtual 
          instance void  SetDefaultExt(string  marshal( lpwstr) lpszDefaultExt) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 00 00 00 00 ) 
  } // end of method _DAdvancedFileDialog::SetDefaultExt

} // end of class AdvancedFileDialogLib._DAdvancedFileDialog

.class interface public abstract auto ansi import AdvancedFileDialogLib._DAdvancedFileDialogEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 37 39 31 31 36 43 44 36 2D 39 35 36 31   // ..$79116CD6-9561
                                                                                                  2D 34 45 46 35 2D 41 35 37 33 2D 32 36 34 30 43   // -4EF5-A573-2640C
                                                                                                  33 41 43 34 38 31 35 00 00 )                      // 3AC4815..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 10 00 00 00 00 ) 
} // end of class AdvancedFileDialogLib._DAdvancedFileDialogEvents

.class interface public abstract auto ansi AdvancedFileDialogLib._DAdvancedFileDialogEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComEventInterfaceAttribute::.ctor(class [mscorlib]System.Type,
                                                                                                   class [mscorlib]System.Type) = ( 01 00 30 41 64 76 61 6E 63 65 64 46 69 6C 65 44   // ..0AdvancedFileD
                                                                                                                                    69 61 6C 6F 67 4C 69 62 2E 5F 44 41 64 76 61 6E   // ialogLib._DAdvan
                                                                                                                                    63 65 64 46 69 6C 65 44 69 61 6C 6F 67 45 76 65   // cedFileDialogEve
                                                                                                                                    6E 74 73 3E 41 64 76 61 6E 63 65 64 46 69 6C 65   // nts>AdvancedFile
                                                                                                                                    44 69 61 6C 6F 67 4C 69 62 2E 5F 44 41 64 76 61   // DialogLib._DAdva
                                                                                                                                    6E 63 65 64 46 69 6C 65 44 69 61 6C 6F 67 45 76   // ncedFileDialogEv
                                                                                                                                    65 6E 74 73 5F 45 76 65 6E 74 50 72 6F 76 69 64   // ents_EventProvid
                                                                                                                                    65 72 00 00 )                                     // er..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
} // end of class AdvancedFileDialogLib._DAdvancedFileDialogEvents_Event

.class interface public abstract auto ansi import AdvancedFileDialogLib.AdvancedFileDialog
       implements AdvancedFileDialogLib._DAdvancedFileDialog,
                  AdvancedFileDialogLib._DAdvancedFileDialogEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 34 37 41 38 42 33 43 34 2D 41 34 35 36   // ..$47A8B3C4-A456
                                                                                                  2D 34 34 41 36 2D 41 42 41 46 2D 35 45 39 41 44   // -44A6-ABAF-5E9AD
                                                                                                  38 42 46 33 43 46 32 00 00 )                      // 8BF3CF2..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 2D 41 64 76 61 6E 63 65 64 46 69 6C 65 44   // ..-AdvancedFileD
                                                                                                                          69 61 6C 6F 67 4C 69 62 2E 41 64 76 61 6E 63 65   // ialogLib.Advance
                                                                                                                          64 46 69 6C 65 44 69 61 6C 6F 67 43 6C 61 73 73   // dFileDialogClass
                                                                                                                          00 00 ) 
} // end of class AdvancedFileDialogLib.AdvancedFileDialog

.class public auto ansi import AdvancedFileDialogLib.AdvancedFileDialogClass
       extends [mscorlib]System.Object
       implements AdvancedFileDialogLib._DAdvancedFileDialog,
                  AdvancedFileDialogLib.AdvancedFileDialog,
                  AdvancedFileDialogLib._DAdvancedFileDialogEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 39 42 30 44 37 33 34 2D 39 30 30 36   // ..$69B0D734-9006
                                                                                                  2D 34 34 41 41 2D 38 30 44 34 2D 39 45 43 33 38   // -44AA-80D4-9EC38
                                                                                                  44 30 34 38 31 37 33 00 00 )                      // D048173..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComSourceInterfacesAttribute::.ctor(string) = ( 01 00 32 41 64 76 61 6E 63 65 64 46 69 6C 65 44   // ..2AdvancedFileD
                                                                                                                 69 61 6C 6F 67 4C 69 62 2E 5F 44 41 64 76 61 6E   // ialogLib._DAdvan
                                                                                                                 63 65 64 46 69 6C 65 44 69 61 6C 6F 67 45 76 65   // cedFileDialogEve
                                                                                                                 6E 74 73 00 00 00 00 )                            // nts....
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method AdvancedFileDialogClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  AboutBox() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 D8 FD FF FF 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::AboutBox
  } // end of method AdvancedFileDialogClass::AboutBox

  .method public hidebysig newslot virtual 
          instance int32  ShowOpenFileDialog(int32 bShowHierarchy) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::ShowOpenFileDialog
  } // end of method AdvancedFileDialogClass::ShowOpenFileDialog

  .method public hidebysig newslot virtual 
          instance int32  ShowSaveFileDialog(int32 bShowHierarchy) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::ShowSaveFileDialog
  } // end of method AdvancedFileDialogClass::ShowSaveFileDialog

  .method public hidebysig newslot virtual 
          instance void  SetFileName(string  marshal( lpwstr) lpszFileName) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::SetFileName
  } // end of method AdvancedFileDialogClass::SetFileName

  .method public hidebysig newslot virtual 
          instance void  SetFilter(string  marshal( lpwstr) lpszFilter) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::SetFilter
  } // end of method AdvancedFileDialogClass::SetFilter

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetFileName() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::GetFileName
  } // end of method AdvancedFileDialogClass::GetFileName

  .method public hidebysig newslot virtual 
          instance void  SetInitialDir(string  marshal( lpwstr) lpszInitialDir) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::SetInitialDir
  } // end of method AdvancedFileDialogClass::SetInitialDir

  .method public hidebysig newslot virtual 
          instance int32  GetFilterIndex() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::GetFilterIndex
  } // end of method AdvancedFileDialogClass::GetFilterIndex

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetPathName() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::GetPathName
  } // end of method AdvancedFileDialogClass::GetPathName

  .method public hidebysig newslot virtual 
          instance void  SetTitle(string  marshal( lpwstr) lpszTitle) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::SetTitle
  } // end of method AdvancedFileDialogClass::SetTitle

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetHierarchyName() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::GetHierarchyName
  } // end of method AdvancedFileDialogClass::GetHierarchyName

  .method public hidebysig newslot virtual 
          instance void  AddHierarchy(string  marshal( lpwstr) lpszHierarchy) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::AddHierarchy
  } // end of method AdvancedFileDialogClass::AddHierarchy

  .method public hidebysig newslot virtual 
          instance void  SetProductType(int32 iProductType) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::SetProductType
  } // end of method AdvancedFileDialogClass::SetProductType

  .method public hidebysig newslot virtual 
          instance void  SetImportOrExportPrompt(string  marshal( lpwstr) lpszImportOrExportPrompt) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::SetImportOrExportPrompt
  } // end of method AdvancedFileDialogClass::SetImportOrExportPrompt

  .method public hidebysig newslot virtual 
          instance void  SetFavoritesPath(string  marshal( lpwstr) lpszFavoritesPath) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::SetFavoritesPath
  } // end of method AdvancedFileDialogClass::SetFavoritesPath

  .method public hidebysig newslot virtual 
          instance void  SetChangeDir(int32 bChangeDir) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::SetChangeDir
  } // end of method AdvancedFileDialogClass::SetChangeDir

  .method public hidebysig newslot virtual 
          instance void  SetFilterIndex(int32 iFilterIndex) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::SetFilterIndex
  } // end of method AdvancedFileDialogClass::SetFilterIndex

  .method public hidebysig newslot virtual 
          instance void  SetDefaultExt(string  marshal( lpwstr) lpszDefaultExt) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 00 00 00 00 ) 
    .override AdvancedFileDialogLib._DAdvancedFileDialog::SetDefaultExt
  } // end of method AdvancedFileDialogClass::SetDefaultExt

} // end of class AdvancedFileDialogLib.AdvancedFileDialogClass

.class public auto ansi sealed AdvancedFileDialogLib._DAdvancedFileDialogEvents_SinkHelper
       extends [mscorlib]System.Object
       implements AdvancedFileDialogLib._DAdvancedFileDialogEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .field public int32 m_dwCookie
  .method assembly specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       24 (0x18)
    .maxstack  4
    IL_0000:  ldarg      0
    IL_0004:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0009:  ldarg      0
    IL_000d:  ldc.i4     0x0
    IL_0012:  stfld      int32 AdvancedFileDialogLib._DAdvancedFileDialogEvents_SinkHelper::m_dwCookie
    IL_0017:  ret
  } // end of method _DAdvancedFileDialogEvents_SinkHelper::.ctor

} // end of class AdvancedFileDialogLib._DAdvancedFileDialogEvents_SinkHelper

.class private auto ansi sealed AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider
       extends [mscorlib]System.Object
       implements AdvancedFileDialogLib._DAdvancedFileDialogEvents_Event,
                  [mscorlib]System.IDisposable
{
  .field private class [mscorlib]System.WeakReference m_wkConnectionPointContainer
  .field private class [mscorlib]System.Collections.ArrayList m_aEventSinkHelpers
  .field private class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint m_ConnectionPoint
  .method private instance void  Init() cil managed
  {
    // Code size       271 (0x10f)
    .maxstack  5
    .locals init (class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint V_0,
             valuetype [mscorlib]System.Guid V_1,
             uint8[] V_2)
    IL_0000:  ldnull
    IL_0001:  stloc.0
    IL_0002:  ldc.i4     0x10
    IL_0007:  newarr     [mscorlib]System.Byte
    IL_000c:  stloc.2
    IL_000d:  ldloc.2
    IL_000e:  ldc.i4     0x0
    IL_0013:  ldc.i4     0xd6
    IL_0018:  stelem.i1
    IL_0019:  ldloc.2
    IL_001a:  ldc.i4     0x1
    IL_001f:  ldc.i4     0x6c
    IL_0024:  stelem.i1
    IL_0025:  ldloc.2
    IL_0026:  ldc.i4     0x2
    IL_002b:  ldc.i4     0x11
    IL_0030:  stelem.i1
    IL_0031:  ldloc.2
    IL_0032:  ldc.i4     0x3
    IL_0037:  ldc.i4     0x79
    IL_003c:  stelem.i1
    IL_003d:  ldloc.2
    IL_003e:  ldc.i4     0x4
    IL_0043:  ldc.i4     0x61
    IL_0048:  stelem.i1
    IL_0049:  ldloc.2
    IL_004a:  ldc.i4     0x5
    IL_004f:  ldc.i4     0x95
    IL_0054:  stelem.i1
    IL_0055:  ldloc.2
    IL_0056:  ldc.i4     0x6
    IL_005b:  ldc.i4     0xf5
    IL_0060:  stelem.i1
    IL_0061:  ldloc.2
    IL_0062:  ldc.i4     0x7
    IL_0067:  ldc.i4     0x4e
    IL_006c:  stelem.i1
    IL_006d:  ldloc.2
    IL_006e:  ldc.i4     0x8
    IL_0073:  ldc.i4     0xa5
    IL_0078:  stelem.i1
    IL_0079:  ldloc.2
    IL_007a:  ldc.i4     0x9
    IL_007f:  ldc.i4     0x73
    IL_0084:  stelem.i1
    IL_0085:  ldloc.2
    IL_0086:  ldc.i4     0xa
    IL_008b:  ldc.i4     0x26
    IL_0090:  stelem.i1
    IL_0091:  ldloc.2
    IL_0092:  ldc.i4     0xb
    IL_0097:  ldc.i4     0x40
    IL_009c:  stelem.i1
    IL_009d:  ldloc.2
    IL_009e:  ldc.i4     0xc
    IL_00a3:  ldc.i4     0xc3
    IL_00a8:  stelem.i1
    IL_00a9:  ldloc.2
    IL_00aa:  ldc.i4     0xd
    IL_00af:  ldc.i4     0xac
    IL_00b4:  stelem.i1
    IL_00b5:  ldloc.2
    IL_00b6:  ldc.i4     0xe
    IL_00bb:  ldc.i4     0x48
    IL_00c0:  stelem.i1
    IL_00c1:  ldloc.2
    IL_00c2:  ldc.i4     0xf
    IL_00c7:  ldc.i4     0x15
    IL_00cc:  stelem.i1
    IL_00cd:  ldloca.s   V_1
    IL_00cf:  ldloc.2
    IL_00d0:  call       instance void [mscorlib]System.Guid::.ctor(uint8[])
    IL_00d5:  ldarg      0
    IL_00d9:  ldfld      class [mscorlib]System.WeakReference AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider::m_wkConnectionPointContainer
    IL_00de:  callvirt   instance object [mscorlib]System.WeakReference::get_Target()
    IL_00e3:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer
    IL_00e8:  ldloca.s   V_1
    IL_00ea:  ldloca.s   V_0
    IL_00ec:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer::FindConnectionPoint(valuetype [mscorlib]System.Guid&,
                                                                                                                                        class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint&)
    IL_00f1:  ldarg      0
    IL_00f5:  ldloc.0
    IL_00f6:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint
    IL_00fb:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider::m_ConnectionPoint
    IL_0100:  ldarg      0
    IL_0104:  newobj     instance void [mscorlib]System.Collections.ArrayList::.ctor()
    IL_0109:  stfld      class [mscorlib]System.Collections.ArrayList AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider::m_aEventSinkHelpers
    IL_010e:  ret
  } // end of method _DAdvancedFileDialogEvents_EventProvider::Init

  // Preserve the missing constructor parameter name from the original metadata.
  // Build directive: unnamed-event-provider-constructor-argument
  .method public specialname rtspecialname 
          instance void  .ctor(object) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  6
    IL_0000:  ldarg      0
    IL_0004:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0009:  ldarg      0
    IL_000d:  ldarg      1
    IL_0011:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer
    IL_0016:  ldc.i4.0
    IL_0017:  newobj     instance void [mscorlib]System.WeakReference::.ctor(object,
                                                                             bool)
    IL_001c:  stfld      class [mscorlib]System.WeakReference AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider::m_wkConnectionPointContainer
    IL_0021:  ret
  } // end of method _DAdvancedFileDialogEvents_EventProvider::.ctor

  .method public virtual instance void  Finalize() cil managed
  {
    // Code size       158 (0x9e)
    .maxstack  5
    .locals init (int32 V_0,
             int32 V_1,
             class AdvancedFileDialogLib._DAdvancedFileDialogEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      .try
      {
        IL_0000:  ldarg      0
        IL_0004:  ldloca.s   V_3
        IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                            bool&)
        IL_000b:  ldarg      0
        IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider::m_ConnectionPoint
        IL_0014:  brfalse    IL_0080

        IL_0019:  ldarg      0
        IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider::m_aEventSinkHelpers
        IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
        IL_0027:  stloc.0
        IL_0028:  ldc.i4     0x0
        IL_002d:  stloc.1
        IL_002e:  ldc.i4     0x0
        IL_0033:  ldloc.0
        IL_0034:  bge        IL_0071

        IL_0039:  ldarg      0
        IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider::m_aEventSinkHelpers
        IL_0042:  ldloc.1
        IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
        IL_0048:  castclass  AdvancedFileDialogLib._DAdvancedFileDialogEvents_SinkHelper
        IL_004d:  stloc.2
        IL_004e:  ldarg      0
        IL_0052:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider::m_ConnectionPoint
        IL_0057:  ldloc.2
        IL_0058:  ldfld      int32 AdvancedFileDialogLib._DAdvancedFileDialogEvents_SinkHelper::m_dwCookie
        IL_005d:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
        IL_0062:  ldloc.1
        IL_0063:  ldc.i4     0x1
        IL_0068:  add
        IL_0069:  stloc.1
        IL_006a:  ldloc.1
        IL_006b:  ldloc.0
        IL_006c:  blt        IL_0039

        IL_0071:  ldarg      0
        IL_0075:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider::m_ConnectionPoint
        IL_007a:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
        IL_007f:  pop
        IL_0080:  leave      IL_008b

      }  // end .try
      catch [mscorlib]System.Exception 
      {
        IL_0085:  pop
        IL_0086:  leave      IL_008b

      }  // end handler
      IL_008b:  leave      IL_009d

    }  // end .try
    finally
    {
      IL_0090:  ldloc.3
      IL_0091:  brfalse.s  IL_009c

      IL_0093:  ldarg      0
      IL_0097:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_009c:  endfinally
    }  // end handler
    IL_009d:  ret
  } // end of method _DAdvancedFileDialogEvents_EventProvider::Finalize

  .method public virtual instance void  Dispose() cil managed
  {
    // Code size       19 (0x13)
    .maxstack  2
    IL_0000:  ldarg      0
    IL_0004:  callvirt   instance void AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider::Finalize()
    IL_0009:  ldarg      0
    IL_000d:  call       void [mscorlib]System.GC::SuppressFinalize(object)
    IL_0012:  ret
  } // end of method _DAdvancedFileDialogEvents_EventProvider::Dispose

} // end of class AdvancedFileDialogLib._DAdvancedFileDialogEvents_EventProvider


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
