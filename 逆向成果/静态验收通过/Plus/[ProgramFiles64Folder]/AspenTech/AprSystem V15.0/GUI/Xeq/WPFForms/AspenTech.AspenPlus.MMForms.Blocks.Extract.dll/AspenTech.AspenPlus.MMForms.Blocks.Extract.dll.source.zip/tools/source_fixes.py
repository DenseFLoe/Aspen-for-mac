"""WPF-source shape restore: early-return guards and ctor/cctor order.

Usage: source_fixes.py <file.cs>

1. `if (!_contentLoaded) { <body> }` -> `if (_contentLoaded) { return; } <body>`
   (the original compiler emitted an early-return guard; the two forms differ in
   IL branch shape and code size).
2. Insert an explicit parameterless instance constructor before each explicit
   static constructor so that the MethodDef order is `.ctor` then `.cctor`
   (Roslyn otherwise emits the static constructor first).
"""
import re
import sys
from pathlib import Path

p = Path(sys.argv[1])
text = p.read_text(encoding="utf-8")

# 1) InitializeComponent guard form
pattern = re.compile(
    r"(\t\tpublic void InitializeComponent\(\)\n\t\t\{\n)"
    r"\t\t\tif \(!_contentLoaded\)\n\t\t\t\{\n"
    r"((?:\t\t\t\t[^\n]*\n)+)"
    r"\t\t\t\}\n\t\t\}\n")
count_guard = 0
def guard(match):
    global count_guard
    body = "".join("\t\t\t" + line[4:] + "\n" for line in match.group(2).splitlines())
    count_guard += 1
    return (match.group(1) +
            "\t\t\tif (_contentLoaded)\n\t\t\t{\n\t\t\t\treturn;\n\t\t\t}\n" + body + "\t\t}\n")
text = pattern.sub(guard, text)

# 2) explicit instance ctor before each static ctor.
#    Skip static classes (CS0710) and classes that already declare a
#    parameterless instance constructor (CS0111).
pattern2 = re.compile(r"(\n)(\t\tstatic (\w+)\(\)\n)")

count_ctor = 0
count_skip = 0


def ctor(match):
    global count_ctor, count_skip
    cls = match.group(3)
    head = text[:match.start()]
    decl = list(re.finditer(r"(?m)^\t*(?:public|internal|private|protected)?\s*(static\s+)?(?:partial\s+)?"
                            r"(?:class|struct)\s+" + re.escape(cls) + r"\b", head))
    if decl:
        last = decl[-1]
        if last.group(1):
            count_skip += 1
            return match.group(0)
        # parameterless instance ctor already present anywhere in this type?
        segment = text[last.end():]
        if re.search(r"(?m)^\t*public\s+" + re.escape(cls) + r"\s*\(\s*\)", segment):
            count_skip += 1
            return match.group(0)
    count_ctor += 1
    return (match.group(1) + "\t\tpublic %s()\n\t\t{\n\t\t}\n\n" % cls + match.group(2))


text = pattern2.sub(ctor, text)

p.write_text(text, encoding="utf-8")
print("guards", count_guard, "ctors", count_ctor, "skip", count_skip)
