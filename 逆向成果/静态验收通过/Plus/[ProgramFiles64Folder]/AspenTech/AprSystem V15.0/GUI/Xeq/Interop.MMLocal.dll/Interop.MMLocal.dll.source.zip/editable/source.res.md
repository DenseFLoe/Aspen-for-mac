# source.res

The native RT_VERSION resource was compared byte for byte with the installed original and fresh ILAsm DLL.
