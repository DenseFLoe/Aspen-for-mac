# ApwnRes.dll 源码与资源

原件为 Aspen Plus 与 Aspen Properties V15.0 共用组件 `AprSystem V15.0/GUI/Xeq/ApwnRes.dll`。文件版本 `41.0 Build 614`，原件 SHA-256 为 `1ef6c43d2f4f4846d6279db0ce1ac2ad8c19157f3db8bcce4b3218a1fdd9bdae`。

使用 NASM 3.02 和 Python 3.12 在空目录复编。`ApwnRes.dll.x64.asm` 保留 Win64 函数、内部跳转、导入槽及数据引用。辅助宏选择与原件相同的寄存器编码。`pe-header.asm` 含 DOS 消息桩和 PE 头，`pdata.asm`、`rdata.asm` 和 `reloc.asm` 含展开记录、作用域、导入、加载配置及重定位。`resources.json` 的目录与数据项由 `build.py` 根据 `payload/` 重建。

```powershell
python build.py <nasm.exe> <输出路径>/ApwnRes.dll
```

重建交付为无签名 PE。与安装原件的差异仅为 Authenticode 证书及其目录项和重新计算的 PE 校验和。六个节的完整文件内容均一致。此处仅进行静态比较，Windows 启动与运行对照留待重建阶段。
