using System;
using System.CodeDom.Compiler;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Threading;
using AspenTech.AspenCxs;
using AspenTech.AspenCxs.CxsViewModel;
using AspenTech.AspenCxs.CxsViewModel.ViewData;
using AspenTech.AspenPlus.Localization;
using AspenTech.AspenPlus.Localization.Properties;
using AspenTech.AspenPlus.MMControls;
using AspenTech.AspenPlus.MMControls.CompositeEvents;
using Infragistics.Windows;
using Microsoft.Practices.Unity;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.MMForms.Blocks.ConSep")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.MMForms.Blocks.ConSep")]
[assembly: AssemblyCopyright("Copyright ©  2010 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/consep", "AspenTech.AspenPlus.MMForms.Blocks.ConSep")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]

namespace AspenTech.AspenPlus.MMForms.Blocks.ConSep
{
	public class MMConSep_BlockO_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration entblksib_Property = CxvPropertyDeclaration.Register("entblksib", typeof(MMConSep_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKSIB"
		});

		public static readonly CxvPropertyDeclaration entblkdg_Property = CxvPropertyDeclaration.Register("entblkdg", typeof(MMConSep_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKDG"
		});

		public static readonly CxvPropertyDeclaration entblkrp_Property = CxvPropertyDeclaration.Register("entblkrp", typeof(MMConSep_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKRP"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMConSep_BlockO_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@entblksib" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMConSep_BlockO_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@entblkdg" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMConSep_BlockO_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@entblkrp" }
		});

		public static readonly CxvPropertyDeclaration tab3_var_Property = CxvPropertyDeclaration.Register("tab3_var", typeof(MMConSep_BlockO_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@blkops", "@genblk" },
			EnteredDataPaths = { "@entpro" }
		});

		public static readonly CxvPropertyDeclaration blkops_Property = CxvPropertyDeclaration.Register("blkops", typeof(MMConSep_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.BKOP"
		});

		public static readonly CxvPropertyDeclaration genblk_Property = CxvPropertyDeclaration.Register("genblk", typeof(MMConSep_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.GENBLKOP"
		});

		public static readonly CxvPropertyDeclaration entpro_Property = CxvPropertyDeclaration.Register("entpro", typeof(MMConSep_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKPR"
		});

		public object entblksib => ((CxvViewModel)this).GetValue(entblksib_Property);

		public object entblkdg => ((CxvViewModel)this).GetValue(entblkdg_Property);

		public object entblkrp => ((CxvViewModel)this).GetValue(entblkrp_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);

		public object tab3_var => ((CxvViewModel)this).GetValue(tab3_var_Property);

		public object blkops => ((CxvViewModel)this).GetValue(blkops_Property);

		public object genblk => ((CxvViewModel)this).GetValue(genblk_Property);

		public object entpro => ((CxvViewModel)this).GetValue(entpro_Property);
	}
	[ProgId("MMConSep.MMConSep_BlockO")]
	public class MMConSep_BlockO : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMTabStrip1;

		internal MMTabItem tab3;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		private bool _contentLoaded;

		public MMConSep_BlockO()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_BlockO_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_blocko.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Expected O, but got Unknown
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Expected O, but got Unknown
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Expected O, but got Unknown
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMTabStrip1 = (MMTabStrip)target;
				break;
			case 2:
				tab3 = (MMTabItem)target;
				break;
			case 3:
				tab0 = (MMTabItem)target;
				break;
			case 4:
				tab1 = (MMTabItem)target;
				break;
			case 5:
				tab2 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMConSep_BlockO_Proper_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration cboFreeWatProp_var1_Property = CxvPropertyDeclaration.Register("cboFreeWatProp_var1", typeof(MMConSep_BlockO_Proper_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.FRWATEROPSET"
		});

		public static readonly CxvPropertyDeclaration cboWaterSol_MultiMap_Property;

		public static readonly CxvPropertyDeclaration cboPropMethod_var1_Property;

		public static readonly CxvPropertyDeclaration cboHenryComps_var1_Property;

		public static readonly CxvPropertyDeclaration cboSimApp_MultiMap_Property;

		public static readonly CxvPropertyDeclaration cboChemId_var1_Property;

		private Visibility _electrolytesVisibility;

		private Visibility _petroleumVisibility;

		public object cboFreeWatProp_var1 => ((CxvViewModel)this).GetValue(cboFreeWatProp_var1_Property);

		public object cboWaterSol_MultiMap => ((CxvViewModel)this).GetValue(cboWaterSol_MultiMap_Property);

		public object cboPropMethod_var1 => ((CxvViewModel)this).GetValue(cboPropMethod_var1_Property);

		public object cboHenryComps_var1 => ((CxvViewModel)this).GetValue(cboHenryComps_var1_Property);

		public object cboSimApp_MultiMap => ((CxvViewModel)this).GetValue(cboSimApp_MultiMap_Property);

		public object cboChemId_var1 => ((CxvViewModel)this).GetValue(cboChemId_var1_Property);

		public Visibility ElectrolytesVisibility
		{
			get
			{
				return _electrolytesVisibility;
			}
			set
			{
				_electrolytesVisibility = value;
				OnPropertyChanged("ElectrolytesVisibility");
			}
		}

		public Visibility PetroleumVisibility
		{
			get
			{
				return _petroleumVisibility;
			}
			set
			{
				_petroleumVisibility = value;
				OnPropertyChanged("PetroleumVisibility");
			}
		}

		protected override void OnUpdateData()
		{
			base.OnUpdateData();
			if (((CxvViewModel)this).IsInitialUpdate)
			{
				if (CxsConverter.ValueToInt32(((CxvViewModel)this).ResolveParameter("ElecCal_Frame")) == 0)
				{
					ElectrolytesVisibility = Visibility.Collapsed;
				}
				if (CxsConverter.ValueToInt32(((CxvViewModel)this).ResolveParameter("PetroOptions_Frame")) == 0)
				{
					PetroleumVisibility = Visibility.Collapsed;
				}
			}
		}

		public MMConSep_BlockO_Proper_ViewModel()
		{
		}

		static MMConSep_BlockO_Proper_ViewModel()
		{
	cboWaterSol_MultiMap_Property = CxvPropertyDeclaration.Register("cboWaterSol_MultiMap", typeof(MMConSep_BlockO_Proper_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboWaterSol_var1",
				DataPath = "@main.Input.SOLU_WATER"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "0 - Saturated steam table",
				DisplayResourceKey = "MMConSep_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_0___Saturated_steam_table",
				Value = "cboWaterSol_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboWaterSol_var1",
				Value = "0"
			} }
				}, new CxvMultiMapOption
			{
				Display = "1 - Saturated primary package",
				DisplayResourceKey = "MMConSep_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_1___Saturated_primary_package",
				Value = "cboWaterSol_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboWaterSol_var1",
				Value = "1"
			} }
				}, new CxvMultiMapOption
			{
				Display = "2 - Unsaturated primary package",
				DisplayResourceKey = "MMConSep_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_2___Unsaturated_primary_package",
				Value = "cboWaterSol_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboWaterSol_var1",
				Value = "2"
			} }
				}, new CxvMultiMapOption
			{
				Display = "3 - No correction",
				DisplayResourceKey = "MMConSep_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_3___No_correction",
				Value = "cboWaterSol_MultiMapOption_4",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboWaterSol_var1",
				Value = "3"
			} }
				}, new CxvMultiMapOption
			{
				Display = "4 - Water solubility is one",
				DisplayResourceKey = "MMConSep_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_4___Water_solubility_is_one",
				Value = "cboWaterSol_MultiMapOption_5",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboWaterSol_var1",
				Value = "4"
			} }
				}, new CxvMultiMapOption
			{
				Display = "5 - Unsaturated steam",
				DisplayResourceKey = "MMConSep_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_5___Unsaturated_steam",
				Value = "cboWaterSol_MultiMapOption_6",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboWaterSol_var1",
				Value = "5"
			} }
				} }
});
	cboPropMethod_var1_Property = CxvPropertyDeclaration.Register("cboPropMethod_var1", typeof(MMConSep_BlockO_Proper_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.OPSETNAME"
			});
	cboHenryComps_var1_Property = CxvPropertyDeclaration.Register("cboHenryComps_var1", typeof(MMConSep_BlockO_Proper_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.HENRY_COMPS"
			});
	cboSimApp_MultiMap_Property = CxvPropertyDeclaration.Register("cboSimApp_MultiMap", typeof(MMConSep_BlockO_Proper_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboSimApp_var1",
				DataPath = "@main.Input.TRUE_COMPS"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "True components",
				DisplayResourceKey = "MMConSep_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_True_components",
				Value = "cboSimApp_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboSimApp_var1",
				Value = "YES"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Apparent components",
				DisplayResourceKey = "MMConSep_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_Apparent_components",
				Value = "cboSimApp_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboSimApp_var1",
				Value = "NO"
			} }
				} }
});
	cboChemId_var1_Property = CxvPropertyDeclaration.Register("cboChemId_var1", typeof(MMConSep_BlockO_Proper_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.CHEMISTRY"
			});
	}
	}
	[ProgId("MMConSep.MMConSep_BlockO_Proper")]
	public class MMConSep_BlockO_Proper : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraPropOptions;

		internal MMLabel cboPropMethod_label;

		internal MMComboEdit cboPropMethod;

		internal MMLabel cboHenryComps_label;

		internal MMComboEdit cboHenryComps;

		internal MMGroupBox fraElecCal;

		internal MMLabel cboChemId_label;

		internal MMComboEdit cboChemId;

		internal MMLabel cboSimApp_label;

		internal MMComboEdit cboSimApp;

		internal MMGroupBox fraPetroOptions;

		internal MMLabel cboFreeWatProp_label;

		internal MMComboEdit cboFreeWatProp;

		internal MMLabel cboWaterSol_label;

		internal MMComboEdit cboWaterSol;

		private bool _contentLoaded;

		public MMConSep_BlockO_Proper()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_BlockO_Proper_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_blocko_proper.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_004b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Expected O, but got Unknown
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_0062: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			//IL_007c: Expected O, but got Unknown
			//IL_007f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0089: Expected O, but got Unknown
			//IL_008c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0096: Expected O, but got Unknown
			//IL_0099: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a3: Expected O, but got Unknown
			//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b0: Expected O, but got Unknown
			//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bd: Expected O, but got Unknown
			//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ca: Expected O, but got Unknown
			//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d7: Expected O, but got Unknown
			//IL_00da: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e4: Expected O, but got Unknown
			//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f1: Expected O, but got Unknown
			//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fe: Expected O, but got Unknown
			//IL_0101: Unknown result type (might be due to invalid IL or missing references)
			//IL_010b: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraPropOptions = (MMGroupBox)target;
				break;
			case 2:
				cboPropMethod_label = (MMLabel)target;
				break;
			case 3:
				cboPropMethod = (MMComboEdit)target;
				break;
			case 4:
				cboHenryComps_label = (MMLabel)target;
				break;
			case 5:
				cboHenryComps = (MMComboEdit)target;
				break;
			case 6:
				fraElecCal = (MMGroupBox)target;
				break;
			case 7:
				cboChemId_label = (MMLabel)target;
				break;
			case 8:
				cboChemId = (MMComboEdit)target;
				break;
			case 9:
				cboSimApp_label = (MMLabel)target;
				break;
			case 10:
				cboSimApp = (MMComboEdit)target;
				break;
			case 11:
				fraPetroOptions = (MMGroupBox)target;
				break;
			case 12:
				cboFreeWatProp_label = (MMLabel)target;
				break;
			case 13:
				cboFreeWatProp = (MMComboEdit)target;
				break;
			case 14:
				cboWaterSol_label = (MMLabel)target;
				break;
			case 15:
				cboWaterSol = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMConSep.MMConSep_BlockO_Simula")]
	public class MMConSep_BlockO_Simula : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMLabel MMSpinBox1_label;

		internal MMSpinBox MMSpinBox1;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMGroupBox MMFrame3;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMLabel MMLBUText2_label;

		internal MMVariableEdit MMLBUText2;

		internal MMGroupBox MMFrame4;

		internal MMLabel MMSpinBox3_label;

		internal MMSpinBox MMSpinBox3;

		internal MMLabel MMComboBox2_label;

		internal MMComboEdit MMComboBox2;

		internal MMGroupBox MMFrame2;

		internal MMLabel MMLBUText4_label;

		internal MMVariableEdit MMLBUText4;

		internal MMLabel lbtuLLEnvTemp_label;

		internal MMVariableEdit lbtuLLEnvTemp;

		internal MMGroupBox fraCalcOptions;

		internal MMCheckBox chkBalance;

		internal MMCheckBox chkRestart;

		internal MMLabel cboFlashMethod_label;

		internal MMComboEdit cboFlashMethod;

		private bool _contentLoaded;

		public MMConSep_BlockO_Simula()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_BlockO_Simula_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_blocko_simula.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_007d: Expected O, but got Unknown
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Expected O, but got Unknown
			//IL_008d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0097: Expected O, but got Unknown
			//IL_009a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a4: Expected O, but got Unknown
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Expected O, but got Unknown
			//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00be: Expected O, but got Unknown
			//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cb: Expected O, but got Unknown
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d8: Expected O, but got Unknown
			//IL_00db: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e5: Expected O, but got Unknown
			//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f2: Expected O, but got Unknown
			//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ff: Expected O, but got Unknown
			//IL_0102: Unknown result type (might be due to invalid IL or missing references)
			//IL_010c: Expected O, but got Unknown
			//IL_010f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0119: Expected O, but got Unknown
			//IL_011c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0126: Expected O, but got Unknown
			//IL_0129: Unknown result type (might be due to invalid IL or missing references)
			//IL_0133: Expected O, but got Unknown
			//IL_0136: Unknown result type (might be due to invalid IL or missing references)
			//IL_0140: Expected O, but got Unknown
			//IL_0143: Unknown result type (might be due to invalid IL or missing references)
			//IL_014d: Expected O, but got Unknown
			//IL_0150: Unknown result type (might be due to invalid IL or missing references)
			//IL_015a: Expected O, but got Unknown
			//IL_015d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0167: Expected O, but got Unknown
			//IL_016a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0174: Expected O, but got Unknown
			//IL_0177: Unknown result type (might be due to invalid IL or missing references)
			//IL_0181: Expected O, but got Unknown
			//IL_0184: Unknown result type (might be due to invalid IL or missing references)
			//IL_018e: Expected O, but got Unknown
			//IL_0191: Unknown result type (might be due to invalid IL or missing references)
			//IL_019b: Expected O, but got Unknown
			//IL_019e: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a8: Expected O, but got Unknown
			//IL_01ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b5: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				MMSpinBox1_label = (MMLabel)target;
				break;
			case 3:
				MMSpinBox1 = (MMSpinBox)target;
				break;
			case 4:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 5:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 6:
				MMFrame3 = (MMGroupBox)target;
				break;
			case 7:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 8:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 9:
				MMLBUText2_label = (MMLabel)target;
				break;
			case 10:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			case 11:
				MMFrame4 = (MMGroupBox)target;
				break;
			case 12:
				MMSpinBox3_label = (MMLabel)target;
				break;
			case 13:
				MMSpinBox3 = (MMSpinBox)target;
				break;
			case 14:
				MMComboBox2_label = (MMLabel)target;
				break;
			case 15:
				MMComboBox2 = (MMComboEdit)target;
				break;
			case 16:
				MMFrame2 = (MMGroupBox)target;
				break;
			case 17:
				MMLBUText4_label = (MMLabel)target;
				break;
			case 18:
				MMLBUText4 = (MMVariableEdit)target;
				break;
			case 19:
				lbtuLLEnvTemp_label = (MMLabel)target;
				break;
			case 20:
				lbtuLLEnvTemp = (MMVariableEdit)target;
				break;
			case 21:
				fraCalcOptions = (MMGroupBox)target;
				break;
			case 22:
				chkBalance = (MMCheckBox)target;
				break;
			case 23:
				chkRestart = (MMCheckBox)target;
				break;
			case 24:
				cboFlashMethod_label = (MMLabel)target;
				break;
			case 25:
				cboFlashMethod = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMConSep_Input_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration setup_Property = CxvPropertyDeclaration.Register("setup", typeof(MMConSep_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SETUP"
		});

		public static readonly CxvPropertyDeclaration spec_Property = CxvPropertyDeclaration.Register("spec", typeof(MMConSep_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SPEC"
		});

		public static readonly CxvPropertyDeclaration compmap_Property = CxvPropertyDeclaration.Register("compmap", typeof(MMConSep_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.COMPMAP"
		});

		public static readonly CxvPropertyDeclaration entadv_Property = CxvPropertyDeclaration.Register("entadv", typeof(MMConSep_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTADV"
		});

		public static readonly CxvPropertyDeclaration entcmap_Property = CxvPropertyDeclaration.Register("entcmap", typeof(MMConSep_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTCMAP"
		});

		public static readonly CxvPropertyDeclaration selcomp_Property = CxvPropertyDeclaration.Register("selcomp", typeof(MMConSep_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SELCOMP"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMConSep_Input_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@setup" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMConSep_Input_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@spec", "@setup" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMConSep_Input_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@compmap" },
			AccessibleDataPaths = { "@selcomp" },
			EnteredDataPaths = { "@entcmap" }
		});

		public static readonly CxvPropertyDeclaration tab3_var_Property = CxvPropertyDeclaration.Register("tab3_var", typeof(MMConSep_Input_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@entadv" }
		});

		public object setup => ((CxvViewModel)this).GetValue(setup_Property);

		public object spec => ((CxvViewModel)this).GetValue(spec_Property);

		public object compmap => ((CxvViewModel)this).GetValue(compmap_Property);

		public object entadv => ((CxvViewModel)this).GetValue(entadv_Property);

		public object entcmap => ((CxvViewModel)this).GetValue(entcmap_Property);

		public object selcomp => ((CxvViewModel)this).GetValue(selcomp_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);

		public object tab3_var => ((CxvViewModel)this).GetValue(tab3_var_Property);
	}
	[ProgId("MMConSep.MMConSep_Input")]
	public class MMConSep_Input : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMTabStrip1;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem tabInfo;

		private bool _contentLoaded;

		public MMConSep_Input()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Input_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_input.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMTabStrip1 = (MMTabStrip)target;
				break;
			case 2:
				tab1 = (MMTabItem)target;
				break;
			case 3:
				tab2 = (MMTabItem)target;
				break;
			case 4:
				tabInfo = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMConSep_Input_AdvOpt_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMLBUText4_var1_Property = CxvPropertyDeclaration.Register("MMLBUText4_var1", typeof(MMConSep_Input_AdvOpt_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.ENVSTEP"
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMConSep_Input_AdvOpt_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.FLASHTOL"
		});

		public static readonly CxvPropertyDeclaration MMSpinBox1_var1_Property = CxvPropertyDeclaration.Register("MMSpinBox1_var1", typeof(MMConSep_Input_AdvOpt_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.FLASH_MAXIT"
		});

		public static readonly CxvPropertyDeclaration MMComboBox1_var1_Property = CxvPropertyDeclaration.Register("MMComboBox1_var1", typeof(MMConSep_Input_AdvOpt_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.CURVEALG",
			DisplayedCase = (CxsDisplayedCase)2
		});

		public static readonly CxvPropertyDeclaration MMLBUText2_var1_Property = CxvPropertyDeclaration.Register("MMLBUText2_var1", typeof(MMConSep_Input_AdvOpt_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.CURVESTEP"
		});

		public static readonly CxvPropertyDeclaration MMComboBox2_var1_Property = CxvPropertyDeclaration.Register("MMComboBox2_var1", typeof(MMConSep_Input_AdvOpt_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.DESIGNALG",
			DisplayedCase = (CxsDisplayedCase)2
		});

		public static readonly CxvPropertyDeclaration MMSpinBox3_var1_Property = CxvPropertyDeclaration.Register("MMSpinBox3_var1", typeof(MMConSep_Input_AdvOpt_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.MAXSTAGE"
		});

		public object MMLBUText4_var1 => ((CxvViewModel)this).GetValue(MMLBUText4_var1_Property);

		public object MMLBUText1_var1 => ((CxvViewModel)this).GetValue(MMLBUText1_var1_Property);

		public object MMSpinBox1_var1 => ((CxvViewModel)this).GetValue(MMSpinBox1_var1_Property);

		public object MMComboBox1_var1 => ((CxvViewModel)this).GetValue(MMComboBox1_var1_Property);

		public object MMLBUText2_var1 => ((CxvViewModel)this).GetValue(MMLBUText2_var1_Property);

		public object MMComboBox2_var1 => ((CxvViewModel)this).GetValue(MMComboBox2_var1_Property);

		public object MMSpinBox3_var1 => ((CxvViewModel)this).GetValue(MMSpinBox3_var1_Property);
	}
	[ProgId("MMConSep.MMConSep_Input_AdvOpt")]
	public class MMConSep_Input_AdvOpt : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMLabel MMSpinBox1_label;

		internal MMSpinBox MMSpinBox1;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMGroupBox MMFrame3;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMLabel MMLBUText2_label;

		internal MMVariableEdit MMLBUText2;

		internal MMGroupBox MMFrame2;

		internal MMLabel MMLBUText4_label;

		internal MMVariableEdit MMLBUText4;

		internal MMGroupBox MMFrame4;

		internal MMLabel MMSpinBox3_label;

		internal MMSpinBox MMSpinBox3;

		internal MMLabel MMComboBox2_label;

		internal MMComboEdit MMComboBox2;

		private bool _contentLoaded;

		public MMConSep_Input_AdvOpt()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Input_AdvOpt_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_input_advopt.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			//IL_0061: Expected O, but got Unknown
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Expected O, but got Unknown
			//IL_0071: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Expected O, but got Unknown
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0088: Expected O, but got Unknown
			//IL_008b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0095: Expected O, but got Unknown
			//IL_0098: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a2: Expected O, but got Unknown
			//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00af: Expected O, but got Unknown
			//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bc: Expected O, but got Unknown
			//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c9: Expected O, but got Unknown
			//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d6: Expected O, but got Unknown
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Expected O, but got Unknown
			//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f0: Expected O, but got Unknown
			//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fd: Expected O, but got Unknown
			//IL_0100: Unknown result type (might be due to invalid IL or missing references)
			//IL_010a: Expected O, but got Unknown
			//IL_010d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0117: Expected O, but got Unknown
			//IL_011a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0124: Expected O, but got Unknown
			//IL_0127: Unknown result type (might be due to invalid IL or missing references)
			//IL_0131: Expected O, but got Unknown
			//IL_0134: Unknown result type (might be due to invalid IL or missing references)
			//IL_013e: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				MMSpinBox1_label = (MMLabel)target;
				break;
			case 3:
				MMSpinBox1 = (MMSpinBox)target;
				break;
			case 4:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 5:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 6:
				MMFrame3 = (MMGroupBox)target;
				break;
			case 7:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 8:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 9:
				MMLBUText2_label = (MMLabel)target;
				break;
			case 10:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			case 11:
				MMFrame2 = (MMGroupBox)target;
				break;
			case 12:
				MMLBUText4_label = (MMLabel)target;
				break;
			case 13:
				MMLBUText4 = (MMVariableEdit)target;
				break;
			case 14:
				MMFrame4 = (MMGroupBox)target;
				break;
			case 15:
				MMSpinBox3_label = (MMLabel)target;
				break;
			case 16:
				MMSpinBox3 = (MMSpinBox)target;
				break;
			case 17:
				MMComboBox2_label = (MMLabel)target;
				break;
			case 18:
				MMComboBox2 = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMConSep_Input_CompMap_ViewModel : MMTabPageViewModel
	{
		public class grdComp1_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtFrac3_var1_Property = CxvPropertyDeclaration.Register("txtFrac3_var1", typeof(grdComp1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.COMP3MAP.@x"
			});

			public static readonly CxvPropertyDeclaration txtFrac2_var1_Property = CxvPropertyDeclaration.Register("txtFrac2_var1", typeof(grdComp1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.COMP2MAP.@x"
			});

			public static readonly CxvPropertyDeclaration cboComp1_var1_Property = CxvPropertyDeclaration.Register("cboComp1_var1", typeof(grdComp1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.COMP1MAP.@x"
			});

			public static readonly CxvPropertyDeclaration txtFrac1_var1_Property = CxvPropertyDeclaration.Register("txtFrac1_var1", typeof(grdComp1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.COMP1MAP.@x"
			});

			public object txtFrac3_var1 => ((CxvViewModel)this).GetValue(txtFrac3_var1_Property);

			public object txtFrac2_var1 => ((CxvViewModel)this).GetValue(txtFrac2_var1_Property);

			public object cboComp1_var1 => ((CxvViewModel)this).GetValue(cboComp1_var1_Property);

			public object txtFrac1_var1 => ((CxvViewModel)this).GetValue(txtFrac1_var1_Property);
		}

		public static readonly CxvPropertyDeclaration fraEditDissociation_RXNNO_Property = CxvPropertyDeclaration.Register("fraEditDissociation_RXNNO", typeof(MMConSep_Input_CompMap_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "RXNNO"
		});

		public static readonly CxvPropertyDeclaration txtSelComp3_var1_Property = CxvPropertyDeclaration.Register("txtSelComp3_var1", typeof(MMConSep_Input_CompMap_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.SELCOMP3",
			DisplayedCase = (CxsDisplayedCase)1
		});

		public static readonly CxvPropertyDeclaration txtSelComp2_var1_Property = CxvPropertyDeclaration.Register("txtSelComp2_var1", typeof(MMConSep_Input_CompMap_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.SELCOMP2",
			DisplayedCase = (CxsDisplayedCase)1
		});

		public static readonly CxvPropertyDeclaration txtSelComp1_var1_Property = CxvPropertyDeclaration.Register("txtSelComp1_var1", typeof(MMConSep_Input_CompMap_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.SELCOMP1",
			DisplayedCase = (CxsDisplayedCase)1
		});

		public static readonly CxvPropertyDeclaration grdComp1_GridData_Property = CxvPropertyDeclaration.Register("grdComp1_GridData", typeof(MMConSep_Input_CompMap_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdComp1_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.COMP1MAP",
				UseChildId = true,
				Name = "x"
			}
		});

		public object fraEditDissociation_RXNNO => ((CxvViewModel)this).GetValue(fraEditDissociation_RXNNO_Property);

		public object txtSelComp3_var1 => ((CxvViewModel)this).GetValue(txtSelComp3_var1_Property);

		public object txtSelComp2_var1 => ((CxvViewModel)this).GetValue(txtSelComp2_var1_Property);

		public object txtSelComp1_var1 => ((CxvViewModel)this).GetValue(txtSelComp1_var1_Property);

		public object grdComp1_GridData => ((CxvViewModel)this).GetValue(grdComp1_GridData_Property);
	}
	[ProgId("MMConSep.MMConSep_Input_CompMap")]
	public class MMConSep_Input_CompMap : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraEditDissociation;

		internal MMScrollArea grdComp1;

		private bool _contentLoaded;

		public MMConSep_Input_CompMap()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Input_CompMap_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_input_compmap.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraEditDissociation = (MMGroupBox)target;
				break;
			case 2:
				grdComp1 = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMConSep_Input_Setup_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMComboBox1_var1_Property = CxvPropertyDeclaration.Register("MMComboBox1_var1", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.NON_INTERACT",
			DisplayedCase = (CxsDisplayedCase)2,
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.MODEMT"
			}
		});

		public static readonly CxvPropertyDeclaration cboSelComp1_0_var1_Property = CxvPropertyDeclaration.Register("cboSelComp1_0_var1", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.SELCOMP1"
		});

		public static readonly CxvPropertyDeclaration cboSelComp2_var1_Property = CxvPropertyDeclaration.Register("cboSelComp2_var1", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.SELCOMP2"
		});

		public static readonly CxvPropertyDeclaration cboSelComp3_var1_Property = CxvPropertyDeclaration.Register("cboSelComp3_var1", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.SELCOMP3"
		});

		public static readonly CxvPropertyDeclaration lbtuPres_var1_Property = CxvPropertyDeclaration.Register("lbtuPres_var1", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.P_SPEC"
		});

		public static readonly CxvPropertyDeclaration cboTempUnit_var1_Property = CxvPropertyDeclaration.Register("cboTempUnit_var1", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.TEMPUNIT"
		});

		public static readonly CxvPropertyDeclaration cboPresUnit_var1_Property = CxvPropertyDeclaration.Register("cboPresUnit_var1", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.PRESUNIT"
		});

		public static readonly CxvPropertyDeclaration cboBasis_MultiMap_Property;

		public static readonly CxvPropertyDeclaration MMComboBox6_MultiMap_Property;

		public static readonly CxvPropertyDeclaration cboValidPhase_MultiMap_Property;

		public static readonly CxvPropertyDeclaration cboProperty_var1_Property;

		public static readonly CxvPropertyDeclaration cboConfig_MultiMap_Property;

		public object MMComboBox1_var1 => ((CxvViewModel)this).GetValue(MMComboBox1_var1_Property);

		public object cboSelComp1_0_var1 => ((CxvViewModel)this).GetValue(cboSelComp1_0_var1_Property);

		public object cboSelComp2_var1 => ((CxvViewModel)this).GetValue(cboSelComp2_var1_Property);

		public object cboSelComp3_var1 => ((CxvViewModel)this).GetValue(cboSelComp3_var1_Property);

		public object lbtuPres_var1 => ((CxvViewModel)this).GetValue(lbtuPres_var1_Property);

		public object cboTempUnit_var1 => ((CxvViewModel)this).GetValue(cboTempUnit_var1_Property);

		public object cboPresUnit_var1 => ((CxvViewModel)this).GetValue(cboPresUnit_var1_Property);

		public object cboBasis_MultiMap => ((CxvViewModel)this).GetValue(cboBasis_MultiMap_Property);

		public object MMComboBox6_MultiMap => ((CxvViewModel)this).GetValue(MMComboBox6_MultiMap_Property);

		public object cboValidPhase_MultiMap => ((CxvViewModel)this).GetValue(cboValidPhase_MultiMap_Property);

		public object cboProperty_var1 => ((CxvViewModel)this).GetValue(cboProperty_var1_Property);

		public object cboConfig_MultiMap => ((CxvViewModel)this).GetValue(cboConfig_MultiMap_Property);

		public MMConSep_Input_Setup_ViewModel()
		{
		}

		static MMConSep_Input_Setup_ViewModel()
		{
	cboBasis_MultiMap_Property = CxvPropertyDeclaration.Register("cboBasis_MultiMap", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboBasis_var1",
				DataPath = "@main.Input.IBASIS"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Mole",
				DisplayResourceKey = "MMConSep_Input_Setup_ViewModel__CxvMultiMapOption_Display_Mole",
				Value = "cboBasis_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboBasis_var1",
				Value = "MOLE"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Mass",
				DisplayResourceKey = "MMConSep_Input_Setup_ViewModel__CxvMultiMapOption_Display_Mass",
				Value = "cboBasis_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboBasis_var1",
				Value = "MASS"
			} }
				} }
});
	MMComboBox6_MultiMap_Property = CxvPropertyDeclaration.Register("MMComboBox6_MultiMap", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "MMComboBox6_var1",
				DataPath = "@main.Input.IMODE"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Material Balance",
				DisplayResourceKey = "MMConSep_Input_Setup_ViewModel__CxvMultiMapOption_Display_Material_Balance",
				Value = "MMComboBox6_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox6_var1",
				Value = "MAT-BALANCE"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Design",
				DisplayResourceKey = "MMConSep_Input_Setup_ViewModel__CxvMultiMapOption_Display_Design",
				Value = "MMComboBox6_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox6_var1",
				Value = "DESIGN"
			} }
				} }
});
	cboValidPhase_MultiMap_Property = CxvPropertyDeclaration.Register("cboValidPhase_MultiMap", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboValidPhase_var1",
				DataPath = "@main.Input.IPHASE"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Vapor-Liquid",
				DisplayResourceKey = "MMConSep_Input_Setup_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid",
				Value = "cboValidPhase_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboValidPhase_var1",
				Value = "VL"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Vapor-Liquid-Liquid",
				DisplayResourceKey = "MMConSep_Input_Setup_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_Liquid",
				Value = "cboValidPhase_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboValidPhase_var1",
				Value = "VLL"
			} }
				} }
});
	cboProperty_var1_Property = CxvPropertyDeclaration.Register("cboProperty_var1", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.OPSETNAME"
			});
	cboConfig_MultiMap_Property = CxvPropertyDeclaration.Register("cboConfig_MultiMap", typeof(MMConSep_Input_Setup_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboConfig_var1",
				DataPath = "@main.Input.ICONFIG"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Column with decanter",
				DisplayResourceKey = "MMConSep_Input_Setup_ViewModel__CxvMultiMapOption_Display_Column_with_decanter",
				Value = "cboConfig_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboConfig_var1",
				Value = "DECANTER"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Column without decanter",
				DisplayResourceKey = "MMConSep_Input_Setup_ViewModel__CxvMultiMapOption_Display_Column_without_decanter",
				Value = "cboConfig_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboConfig_var1",
				Value = "NO-DECANTER"
			} }
				} }
});
	}
	}
	[ProgId("MMConSep.MMConSep_Input_Setup")]
	public class MMConSep_Input_Setup : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame6;

		internal MMLabel cboConfig_label;

		internal MMComboEdit cboConfig;

		internal MMLabel cboSelComp1_0_label;

		internal MMComboEdit cboSelComp1_0;

		internal MMLabel cboSelComp2_label;

		internal MMComboEdit cboSelComp2;

		internal MMLabel cboSelComp3_label;

		internal MMComboEdit cboSelComp3;

		internal MMLabel cboProperty_label;

		internal MMComboEdit cboProperty;

		internal MMLabel cboValidPhase_label;

		internal MMComboEdit cboValidPhase;

		internal MMLabel MMComboBox6_label;

		internal MMComboEdit MMComboBox6;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMLabel cboBasis_label;

		internal MMComboEdit cboBasis;

		internal MMLabel cboTempUnit_label;

		internal MMComboEdit cboTempUnit;

		internal MMLabel lbtuPres_label;

		internal MMVariableEdit lbtuPres;

		internal MMComboEdit cboPresUnit;

		private bool _contentLoaded;

		public MMConSep_Input_Setup()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Input_Setup_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_input_setup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_006f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0079: Expected O, but got Unknown
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0086: Expected O, but got Unknown
			//IL_0089: Unknown result type (might be due to invalid IL or missing references)
			//IL_0093: Expected O, but got Unknown
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a0: Expected O, but got Unknown
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ad: Expected O, but got Unknown
			//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ba: Expected O, but got Unknown
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c7: Expected O, but got Unknown
			//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d4: Expected O, but got Unknown
			//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e1: Expected O, but got Unknown
			//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ee: Expected O, but got Unknown
			//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fb: Expected O, but got Unknown
			//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
			//IL_0108: Expected O, but got Unknown
			//IL_010b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0115: Expected O, but got Unknown
			//IL_0118: Unknown result type (might be due to invalid IL or missing references)
			//IL_0122: Expected O, but got Unknown
			//IL_0125: Unknown result type (might be due to invalid IL or missing references)
			//IL_012f: Expected O, but got Unknown
			//IL_0132: Unknown result type (might be due to invalid IL or missing references)
			//IL_013c: Expected O, but got Unknown
			//IL_013f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0149: Expected O, but got Unknown
			//IL_014c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0156: Expected O, but got Unknown
			//IL_0159: Unknown result type (might be due to invalid IL or missing references)
			//IL_0163: Expected O, but got Unknown
			//IL_0166: Unknown result type (might be due to invalid IL or missing references)
			//IL_0170: Expected O, but got Unknown
			//IL_0173: Unknown result type (might be due to invalid IL or missing references)
			//IL_017d: Expected O, but got Unknown
			//IL_0180: Unknown result type (might be due to invalid IL or missing references)
			//IL_018a: Expected O, but got Unknown
			//IL_018d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0197: Expected O, but got Unknown
			//IL_019a: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a4: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMFrame6 = (MMGroupBox)target;
				break;
			case 2:
				cboConfig_label = (MMLabel)target;
				break;
			case 3:
				cboConfig = (MMComboEdit)target;
				break;
			case 4:
				cboSelComp1_0_label = (MMLabel)target;
				break;
			case 5:
				cboSelComp1_0 = (MMComboEdit)target;
				break;
			case 6:
				cboSelComp2_label = (MMLabel)target;
				break;
			case 7:
				cboSelComp2 = (MMComboEdit)target;
				break;
			case 8:
				cboSelComp3_label = (MMLabel)target;
				break;
			case 9:
				cboSelComp3 = (MMComboEdit)target;
				break;
			case 10:
				cboProperty_label = (MMLabel)target;
				break;
			case 11:
				cboProperty = (MMComboEdit)target;
				break;
			case 12:
				cboValidPhase_label = (MMLabel)target;
				break;
			case 13:
				cboValidPhase = (MMComboEdit)target;
				break;
			case 14:
				MMComboBox6_label = (MMLabel)target;
				break;
			case 15:
				MMComboBox6 = (MMComboEdit)target;
				break;
			case 16:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 17:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 18:
				cboBasis_label = (MMLabel)target;
				break;
			case 19:
				cboBasis = (MMComboEdit)target;
				break;
			case 20:
				cboTempUnit_label = (MMLabel)target;
				break;
			case 21:
				cboTempUnit = (MMComboEdit)target;
				break;
			case 22:
				lbtuPres_label = (MMLabel)target;
				break;
			case 23:
				lbtuPres = (MMVariableEdit)target;
				break;
			case 24:
				cboPresUnit = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMConSep_Input_Spec_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration frmDecanter_state_Property = CxvPropertyDeclaration.Register("frmDecanter_state", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CONFIG"
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property;

		public static readonly CxvPropertyDeclaration cboColumn_var1_Property;

		public static readonly CxvPropertyDeclaration cboKeyComp_var1_Property;

		public static readonly CxvPropertyDeclaration MMComboBox1_MultiMap_Property;

		public static readonly CxvPropertyDeclaration MMFrame3_state_Property;

		public static readonly CxvPropertyDeclaration txtBotC3Mole_var1_Property;

		public static readonly CxvPropertyDeclaration txtBotReco3_var1_Property;

		public static readonly CxvPropertyDeclaration txtBotC2Mole_var1_Property;

		public static readonly CxvPropertyDeclaration txtBotReco2_var1_Property;

		public static readonly CxvPropertyDeclaration txtBotC1Mole_var1_Property;

		public static readonly CxvPropertyDeclaration txtBotReco1_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistReco1_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistC1Mole_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistReco2_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistC2Mole_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistReco3_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistC3Mole_var1_Property;

		public static readonly CxvPropertyDeclaration optDesignMo_MultiMap_Property;

		public static readonly CxvPropertyDeclaration txtMoleBR_var1_Property;

		public static readonly CxvPropertyDeclaration txtMoleRR_var1_Property;

		public static readonly CxvPropertyDeclaration optDesignMa_MultiMap_Property;

		public static readonly CxvPropertyDeclaration txtMassRR_var1_Property;

		public static readonly CxvPropertyDeclaration txtMassBR_var1_Property;

		public static readonly CxvPropertyDeclaration MMFrame1_state_Property;

		public static readonly CxvPropertyDeclaration MMTextBox5_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistC1Mass_var1_Property;

		public static readonly CxvPropertyDeclaration MMTextBox8_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistC2Mass_var1_Property;

		public static readonly CxvPropertyDeclaration MMTextBox11_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistC3Mass_var1_Property;

		public static readonly CxvPropertyDeclaration MMTextBox14_var1_Property;

		public static readonly CxvPropertyDeclaration MMTextBox10_var1_Property;

		public static readonly CxvPropertyDeclaration MMTextBox6_var1_Property;

		public static readonly CxvPropertyDeclaration txtBotC3Mass_var1_Property;

		public static readonly CxvPropertyDeclaration txtBotC2Mass_var1_Property;

		public static readonly CxvPropertyDeclaration txtBotC1Mass_var1_Property;

		public static readonly CxvPropertyDeclaration optCalculation_MultiMap_Property;

		public static readonly CxvPropertyDeclaration optCurve_MultiMap_Property;

		public static readonly CxvPropertyDeclaration txtBotComp3_var1_Property;

		public static readonly CxvPropertyDeclaration txtBotComp2_var1_Property;

		public static readonly CxvPropertyDeclaration txtBotComp1_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistComp1Mo_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistComp2Mo_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistComp3Mo_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistComp1Ma_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistComp2Ma_var1_Property;

		public static readonly CxvPropertyDeclaration txtDistComp3Ma_var1_Property;

		public static readonly CxvPropertyDeclaration MMTextBox15_var1_Property;

		public static readonly CxvPropertyDeclaration MMTextBox12_var1_Property;

		public static readonly CxvPropertyDeclaration MMTextBox7_var1_Property;

		public static readonly CxvPropertyDeclaration cboBasis_MultiMap_Property;

		public static readonly CxvPropertyDeclaration cboSelComp1_0_var1_Property;

		public static readonly CxvPropertyDeclaration cboSelComp2_var1_Property;

		public static readonly CxvPropertyDeclaration cboSelComp3_var1_Property;

		public static readonly CxvPropertyDeclaration lbtuPres_var1_Property;

		public static readonly CxvPropertyDeclaration cboPresUnit_var1_Property;

		public static readonly CxvPropertyDeclaration cboValidPhase_MultiMap_Property;

		public static readonly CxvPropertyDeclaration chkDecanter_var_Property;

		public static readonly CxvPropertyDeclaration grpDecanter_var_Property;

		private ICommand _cmdInteractiveDesign_Comand;

		public static CxvPropertyDeclaration cmdInteractiveDesign_var1_Property;

		public static CxvPropertyDeclaration cmdInteractiveDesginCanExecuteProperty;

		private CxsCase _cxsCase;

		private bool bShowPlot;

		private const int m_nComp = 3;

		private int[,] m_enabled = new int[3, 4];

		private int[,] m_entered = new int[3, 4];

		public object frmDecanter_state => ((CxvViewModel)this).GetValue(frmDecanter_state_Property);

		public object MMLBUText1_var1 => ((CxvViewModel)this).GetValue(MMLBUText1_var1_Property);

		public object cboColumn_var1 => ((CxvViewModel)this).GetValue(cboColumn_var1_Property);

		public object cboKeyComp_var1 => ((CxvViewModel)this).GetValue(cboKeyComp_var1_Property);

		public object MMComboBox1_MultiMap => ((CxvViewModel)this).GetValue(MMComboBox1_MultiMap_Property);

		public object MMFrame3_state => ((CxvViewModel)this).GetValue(MMFrame3_state_Property);

		public object txtBotC3Mole_var1 => ((CxvViewModel)this).GetValue(txtBotC3Mole_var1_Property);

		public object txtBotReco3_var1 => ((CxvViewModel)this).GetValue(txtBotReco3_var1_Property);

		public object txtBotC2Mole_var1 => ((CxvViewModel)this).GetValue(txtBotC2Mole_var1_Property);

		public object txtBotReco2_var1 => ((CxvViewModel)this).GetValue(txtBotReco2_var1_Property);

		public object txtBotC1Mole_var1 => ((CxvViewModel)this).GetValue(txtBotC1Mole_var1_Property);

		public object txtBotReco1_var1 => ((CxvViewModel)this).GetValue(txtBotReco1_var1_Property);

		public object txtDistReco1_var1 => ((CxvViewModel)this).GetValue(txtDistReco1_var1_Property);

		public object txtDistC1Mole_var1 => ((CxvViewModel)this).GetValue(txtDistC1Mole_var1_Property);

		public object txtDistReco2_var1 => ((CxvViewModel)this).GetValue(txtDistReco2_var1_Property);

		public object txtDistC2Mole_var1 => ((CxvViewModel)this).GetValue(txtDistC2Mole_var1_Property);

		public object txtDistReco3_var1 => ((CxvViewModel)this).GetValue(txtDistReco3_var1_Property);

		public object txtDistC3Mole_var1 => ((CxvViewModel)this).GetValue(txtDistC3Mole_var1_Property);

		public object optDesignMo_MultiMap => ((CxvViewModel)this).GetValue(optDesignMo_MultiMap_Property);

		public object txtMoleBR_var1 => ((CxvViewModel)this).GetValue(txtMoleBR_var1_Property);

		public object txtMoleRR_var1 => ((CxvViewModel)this).GetValue(txtMoleRR_var1_Property);

		public object optDesignMa_MultiMap => ((CxvViewModel)this).GetValue(optDesignMa_MultiMap_Property);

		public object txtMassRR_var1 => ((CxvViewModel)this).GetValue(txtMassRR_var1_Property);

		public object txtMassBR_var1 => ((CxvViewModel)this).GetValue(txtMassBR_var1_Property);

		public object MMFrame1_state => ((CxvViewModel)this).GetValue(MMFrame1_state_Property);

		public object MMTextBox5_var1 => ((CxvViewModel)this).GetValue(MMTextBox5_var1_Property);

		public object txtDistC1Mass_var1 => ((CxvViewModel)this).GetValue(txtDistC1Mass_var1_Property);

		public object MMTextBox8_var1 => ((CxvViewModel)this).GetValue(MMTextBox8_var1_Property);

		public object txtDistC2Mass_var1 => ((CxvViewModel)this).GetValue(txtDistC2Mass_var1_Property);

		public object MMTextBox11_var1 => ((CxvViewModel)this).GetValue(MMTextBox11_var1_Property);

		public object txtDistC3Mass_var1 => ((CxvViewModel)this).GetValue(txtDistC3Mass_var1_Property);

		public object MMTextBox14_var1 => ((CxvViewModel)this).GetValue(MMTextBox14_var1_Property);

		public object MMTextBox10_var1 => ((CxvViewModel)this).GetValue(MMTextBox10_var1_Property);

		public object MMTextBox6_var1 => ((CxvViewModel)this).GetValue(MMTextBox6_var1_Property);

		public object txtBotC3Mass_var1 => ((CxvViewModel)this).GetValue(txtBotC3Mass_var1_Property);

		public object txtBotC2Mass_var1 => ((CxvViewModel)this).GetValue(txtBotC2Mass_var1_Property);

		public object txtBotC1Mass_var1 => ((CxvViewModel)this).GetValue(txtBotC1Mass_var1_Property);

		public object optCalculation_MultiMap => ((CxvViewModel)this).GetValue(optCalculation_MultiMap_Property);

		public object optCurve_MultiMap => ((CxvViewModel)this).GetValue(optCurve_MultiMap_Property);

		public object txtBotComp3_var1 => ((CxvViewModel)this).GetValue(txtBotComp3_var1_Property);

		public object txtBotComp2_var1 => ((CxvViewModel)this).GetValue(txtBotComp2_var1_Property);

		public object txtBotComp1_var1 => ((CxvViewModel)this).GetValue(txtBotComp1_var1_Property);

		public object txtDistComp1Mo_var1 => ((CxvViewModel)this).GetValue(txtDistComp1Mo_var1_Property);

		public object txtDistComp2Mo_var1 => ((CxvViewModel)this).GetValue(txtDistComp2Mo_var1_Property);

		public object txtDistComp3Mo_var1 => ((CxvViewModel)this).GetValue(txtDistComp3Mo_var1_Property);

		public object txtDistComp1Ma_var1 => ((CxvViewModel)this).GetValue(txtDistComp1Ma_var1_Property);

		public object txtDistComp2Ma_var1 => ((CxvViewModel)this).GetValue(txtDistComp2Ma_var1_Property);

		public object txtDistComp3Ma_var1 => ((CxvViewModel)this).GetValue(txtDistComp3Ma_var1_Property);

		public object MMTextBox15_var1 => ((CxvViewModel)this).GetValue(MMTextBox15_var1_Property);

		public object MMTextBox12_var1 => ((CxvViewModel)this).GetValue(MMTextBox12_var1_Property);

		public object MMTextBox7_var1 => ((CxvViewModel)this).GetValue(MMTextBox7_var1_Property);

		public object cboBasis_MultiMap => ((CxvViewModel)this).GetValue(cboBasis_MultiMap_Property);

		public object cboSelComp1_0_var1 => ((CxvViewModel)this).GetValue(cboSelComp1_0_var1_Property);

		public object cboSelComp2_var1 => ((CxvViewModel)this).GetValue(cboSelComp2_var1_Property);

		public object cboSelComp3_var1 => ((CxvViewModel)this).GetValue(cboSelComp3_var1_Property);

		public object lbtuPres_var1 => ((CxvViewModel)this).GetValue(lbtuPres_var1_Property);

		public object cboPresUnit_var1 => ((CxvViewModel)this).GetValue(cboPresUnit_var1_Property);

		public object cboValidPhase_MultiMap => ((CxvViewModel)this).GetValue(cboValidPhase_MultiMap_Property);

		public object chkDecanter_var => ((CxvViewModel)this).GetValue(chkDecanter_var_Property);

		public object grpDecanter_var => ((CxvViewModel)this).GetValue(grpDecanter_var_Property);

		public ICommand cmdInteractiveDesign_Comand
		{
			get
			{
				if (_cmdInteractiveDesign_Comand == null)
				{
					_cmdInteractiveDesign_Comand = (ICommand)new CxvDelegateCommand<object>((Action<object>)cmdInteractiveDesign_ComandExecute);
				}
				return _cmdInteractiveDesign_Comand;
			}
		}

		public object cmdInteractiveDesign_var1 => ((CxvViewModel)this).GetValue(cmdInteractiveDesign_var1_Property);

		public CxvLogicalPropertyData cmdInteractiveDesginCanExecute
		{
			get
			{
				object value = ((CxvViewModel)this).GetValue(cmdInteractiveDesginCanExecuteProperty);
				return value as CxvLogicalPropertyData;
			}
		}

				private void cmdInteractiveDesign_ComandExecute(object parameter)
		{
			object obj = ((CxvViewModel)this).ResolvedCxsProvider.BatchGet(((CxvViewModel)this).ExpandDataPath("@main"), "type", (string)null);
			if (obj != null && string.Compare((string)obj, "ConSep", StringComparison.OrdinalIgnoreCase) != 0)
			{
				((MMViewModel)this).CloseForm();
				return;
			}
			string text = ((CxvViewModel)this).ExpandDataPath("@main") + ".Input.INTERACT";
			bool? flag = CxsConverter.ValueToBoolean(((CxvViewModel)this).ResolvedCxsProvider.BatchGet(text, "value", (string)null)).GetValueOrDefault(false);
			if (flag.HasValue)
			{
				((CxvViewModel)this).ResolvedCxsProvider.BatchSet(text, "value", (string)null, (object)"YES");
				if (_cxsCase == null)
				{
					_cxsCase = UnityContainerExtensions.Resolve<CxsCase>(((CxvViewModel)this).UnityContainer, Array.Empty<ResolverOverride>());
				}
				int? num = _cxsCase.InvokeAction("Top.appModelV8.Custom Actions", "InqPGC", Array.Empty<object>()) as int?;
				int? num2 = _cxsCase.InvokeAction("Top.appModelV8.Custom Actions", "GetGoodPDF_Flg", Array.Empty<object>()) as int?;
				if ((num.HasValue && num.Value != 0) || (num2.HasValue && num2.Value == 0))
				{
					if (_cxsCase != null)
					{
						_cxsCase.Message += cxsCase_Message;
					}
					((MMViewModel)this).Run();
				}
				else
				{
					OnRefresh(117);
				}
			}
		}
		
		

		public void OnRefresh(int hint)
		{
			if (hint == 117)
			{
							if (_cxsCase != null)
							{
								_cxsCase.Message -= cxsCase_Message;
								int? num = _cxsCase.InvokeAction("Top.appModelV8.Custom Actions", "GetGoodPDF_Flg", Array.Empty<object>()) as int?;
								if (num.HasValue && num.Value == 0)
								{
									return;
								}
							}
							string value = "";
							if (CxsConverter.ValueToString(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.IPHASE", "value")) == "VLL")
							{
								if ((CxsConverter.ValueToString(((CxvViewModel)this).ResolveViewPropertyPath("optCalculation_MultiMap.Value", (CxvPropertyWatch)null)) == "optCalculation_MultiMapOption_1"))
								{
									value = "VLL";
								}
								else
								{
									value = "LL";
								}
							}
							string value2 = "RES";
							if (CxsConverter.ValueToString(((CxvViewModel)this).ResolveViewPropertyPath("optCurve_MultiMap.Value", (CxvPropertyWatch)null)) == "optCurve_MultiMapOption_2")
							{
								value2 = "DIS";
							}
							DisplayFormEventArgs e = new DisplayFormEventArgs
							{
								FormProgId = "PlotForms.MMConSep_TernaryPlot",
								ShortName = AspenTech.AspenPlus.Localization.Properties.Resources.MMConSep_Input_Spec_ViewModel__TernaryPlot,
								IsRunInModalMode = true,
								ResizeMode = ResizeMode.CanResize
							};
							e.Parameters.Add("enabled_status", m_enabled);
							e.Parameters.Add("optPhase", value);
							e.Parameters.Add("optCurve", value2);
							((MMViewModel)this).DisplayForm(e);
			}
			}

		private void cxsCase_Message(object sender, CxsMessageEventArgs e)
		{
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Invalid comparison between Unknown and I4
			foreach (CxsMessage message in e.Messages)
			{
				CxsMessage current = message;
				if ((int)current.MessageType != 13)
				{
					continue;
				}
				if (current.Number != 1005)
				{
					break;
				}
				if (current.MessageDataCount <= 0)
				{
					continue;
				}
				int num = ((current.MessageData.Count > 0) ? ((int)current.MessageData[0]) : (-1));
				if (num == 118)
				{
					bShowPlot = false;
				}
				else if (num == 109 || num == 111 || num == 102)
				{
					bShowPlot = true;
				}
				if (num == 117 && bShowPlot)
				{
					if ((((MMViewModel)this).View as MMTabPage).Dispatcher != Dispatcher.CurrentDispatcher)
					{
						(((MMViewModel)this).View as MMTabPage).Dispatcher.BeginInvoke(new Action<int>(OnRefresh), num);
					}
					else
					{
						OnRefresh(num);
					}
					bShowPlot = false;
					CxsCase val = UnityContainerExtensions.Resolve<CxsCase>(((CxvViewModel)this).UnityContainer, Array.Empty<ResolverOverride>());
					if (val != null)
					{
						val.Message -= cxsCase_Message;
					}
				}
			}
		}

		private void SpecConstraint()
		{
			int[] array = new int[4];
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 4; j++)
				{
					array[j] += m_entered[i, j];
					if (m_entered[i, j] == 1)
					{
						num++;
					}
					m_enabled[i, j] = 1;
				}
			}
			switch (num)
			{
			case 1:
			{
				for (int m = 2; m < 4; m++)
				{
					if (array[m] != 1)
					{
						continue;
					}
					for (int num4 = 0; num4 < 3; num4++)
					{
						if (m_entered[num4, m] != 1)
						{
							continue;
						}
						m_enabled[num4, 5 - m] = 0;
						goto IL_00aa;
					}
				}
				IL_00aa:
				break;
			}
			case 2:
			{
				for (int n = 2; n < 4; n++)
				{
					if (array[n] <= 0)
					{
						continue;
					}
					for (int num5 = 0; num5 < 3; num5++)
					{
						if (m_entered[num5, n] == 1)
						{
							m_enabled[num5, 5 - n] = 0;
						}
					}
				}
				for (int num6 = 0; num6 < 2; num6++)
				{
					if (array[num6] != 2)
					{
						continue;
					}
					for (int num7 = 0; num7 < 3; num7++)
					{
						if (m_entered[num7, num6] != 0)
						{
							continue;
						}
						m_enabled[num7, num6] = 0;
						goto IL_END;
					}
				}
				if (array[0] == 1 && array[1] == 1)
				{
					for (int num8 = 0; num8 < 3; num8++)
					{
						if (m_entered[num8, 0] != 1)
						{
							continue;
						}
						for (int num9 = 0; num9 < 3; num9++)
						{
							if (m_entered[num9, 1] != 1)
							{
								continue;
							}
							if (num8 == num9)
							{
								m_enabled[num8, 2] = 0;
								m_enabled[num8, 3] = 0;
							}
							else
							{
								m_enabled[3 - (num8 + num9), 2] = 0;
								m_enabled[3 - (num8 + num9), 3] = 0;
							}
							goto IL_END;
						}
					}
				}
				if (array[0] + array[1] == 1)
				{
					if (array[0] == 1)
					{
						num2 = 0;
					}
					else
					{
						num2 = 1;
					}
					if (array[2] == 1)
					{
						num3 = 2;
					}
					else
					{
						num3 = 3;
					}
					for (int num10 = 0; num10 < 3; num10++)
					{
						if (m_entered[num10, num2] != 1)
						{
							continue;
						}
						for (int num11 = 0; num11 < 3; num11++)
						{
							if (m_entered[num11, num3] != 1)
							{
								continue;
							}
							if (num10 == num11)
							{
								m_enabled[num10, 1 - num2] = 0;
								goto IL_END;
							}
							for (int num16 = 0; num16 < 4; num16++)
							{
								if (num16 != num2)
								{
									m_enabled[3 - (num10 + num11), num16] = 0;
								}
							}
							goto IL_END;
						}
					}
				}
				for (int num12 = 2; num12 < 4; num12++)
				{
					if (array[num12] != 2)
					{
						continue;
					}
					for (int num13 = 0; num13 < 3; num13++)
					{
						if (m_entered[num13, num12] != 0)
						{
							continue;
						}
						m_enabled[num13, 0] = 0;
						m_enabled[num13, 1] = 0;
						goto IL_END;
					}
				}
				if (array[2] != 1 || array[3] != 1)
				{
					break;
				}
				for (int num14 = 0; num14 < 3; num14++)
				{
					if (m_entered[num14, 2] != 1)
					{
						continue;
					}
					for (int num15 = 0; num15 < 3; num15++)
					{
						if (m_entered[num15, 3] != 1)
						{
							continue;
						}
						m_enabled[3 - (num14 + num15), 0] = 0;
						m_enabled[3 - (num14 + num15), 1] = 0;
						goto IL_END;
					}
				}
				break;
			}
			case 3:
			{
				for (int k = 0; k < 4; k++)
				{
					for (int l = 0; l < 3; l++)
					{
						if (m_entered[l, k] == 0)
						{
							m_enabled[l, k] = 0;
						}
					}
				}
				break;
			}
			}
			IL_END:
			EnableDisable();
		}

		private void EnableDisable()
		{
			int num = 0;
			for (int i = 0; i < 2; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					if (m_enabled[j, i] == 0)
					{
						((CxvViewModel)this).ResolveUpdateParameter($"txtComp_{num}_Enabled", (object)"0");
					}
					else
					{
						((CxvViewModel)this).ResolveUpdateParameter($"txtComp_{num}_Enabled", (object)"1");
					}
					num++;
				}
			}
			num = 0;
			for (int k = 2; k < 4; k++)
			{
				for (int l = 0; l < 3; l++)
				{
					if (m_enabled[l, k] == 0)
					{
						((CxvViewModel)this).ResolveUpdateParameter($"txtReco_{num}_Enabled", (object)"0");
					}
					else
					{
						((CxvViewModel)this).ResolveUpdateParameter($"txtReco_{num}_Enabled", (object)"1");
					}
					num++;
				}
			}
		}

		protected override void OnSubPropertyDataChanged(CxvPropertyDeclaration pd, string subPropertyName)
		{
			double? num0;
			double? num1;
			double? num2;
			double? num3;
			double? num4;
			double? num5;
			double? num6;
			double? num7;
			double? num8;
			double? num9;
			double? num10;
			double? num11;
			double? num12;
			double? num13;
			double? num14;
			double? num15;
			double? num16;
			double? num17;
			double? num18;
			double? num19;
			double? num20;
			double? num21;
			double? num22;
			double? num23;
			if (pd.Name == "cboValidPhase_MultiMap" && subPropertyName == "Value" && CxsConverter.ValueToString(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.IPHASE", "value")) == "VL")
			{
				((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.ICONFIG", "value", (object)"NO-DECANTER");
			}
			if (CxsConverter.ValueToString(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.IBASIS", "value")) == "MASS")
			{
				if (pd.Name == "txtDistC1Mass_var1" && subPropertyName == "Value")
				{
					num0 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtDistC1Mass_var1.Value"));
					if (num0.HasValue)
					{
						m_entered[0, 0] = 1;
					}
					else
					{
						m_entered[0, 0] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "txtDistC2Mass_var1" && subPropertyName == "Value")
				{
					num1 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtDistC2Mass_var1.Value"));
					if (num1.HasValue)
					{
						m_entered[1, 0] = 1;
					}
					else
					{
						m_entered[1, 0] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "txtDistC3Mass_var1" && subPropertyName == "Value")
				{
					num2 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtDistC3Mass_var1.Value"));
					if (num2.HasValue)
					{
						m_entered[2, 0] = 1;
					}
					else
					{
						m_entered[2, 0] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "txtBotC1Mass_var1" && subPropertyName == "Value")
				{
					num3 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtBotC1Mass_var1.Value"));
					if (num3.HasValue)
					{
						m_entered[0, 1] = 1;
					}
					else
					{
						m_entered[0, 1] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "txtBotC2Mass_var1" && subPropertyName == "Value")
				{
					num4 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtBotC2Mass_var1.Value"));
					if (num4.HasValue)
					{
						m_entered[1, 1] = 1;
					}
					else
					{
						m_entered[1, 1] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "txtBotC3Mass_var1" && subPropertyName == "Value")
				{
					num5 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtBotC3Mass_var1.Value"));
					if (num5.HasValue)
					{
						m_entered[2, 1] = 1;
					}
					else
					{
						m_entered[2, 1] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "MMTextBox5_var1" && subPropertyName == "Value")
				{
					num6 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "MMTextBox5_var1.Value"));
					if (num6.HasValue)
					{
						m_entered[0, 2] = 1;
					}
					else
					{
						m_entered[0, 2] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "MMTextBox8_var1" && subPropertyName == "Value")
				{
					num7 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "MMTextBox8_var1.Value"));
					if (num7.HasValue)
					{
						m_entered[1, 2] = 1;
					}
					else
					{
						m_entered[1, 2] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "MMTextBox11_var1" && subPropertyName == "Value")
				{
					num8 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "MMTextBox11_var1.Value"));
					if (num8.HasValue)
					{
						m_entered[2, 2] = 1;
					}
					else
					{
						m_entered[2, 2] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "MMTextBox14_var1" && subPropertyName == "Value")
				{
					num9 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "MMTextBox14_var1.Value"));
					if (num9.HasValue)
					{
						m_entered[0, 3] = 1;
					}
					else
					{
						m_entered[0, 3] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "MMTextBox10_var1" && subPropertyName == "Value")
				{
					num10 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "MMTextBox10_var1.Value"));
					if (num10.HasValue)
					{
						m_entered[1, 3] = 1;
					}
					else
					{
						m_entered[1, 3] = 0;
					}
					SpecConstraint();
				}
				else if (pd.Name == "MMTextBox6_var1" && subPropertyName == "Value")
				{
					num11 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "MMTextBox6_var1.Value"));
					if (num11.HasValue)
					{
						m_entered[2, 3] = 1;
					}
					else
					{
						m_entered[2, 3] = 0;
					}
					SpecConstraint();
				}
			}
			else if (pd.Name == "txtDistC1Mole_var1" && subPropertyName == "Value")
			{
				num12 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtDistC1Mole_var1.Value"));
				if (num12.HasValue)
				{
					m_entered[0, 0] = 1;
				}
				else
				{
					m_entered[0, 0] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtDistC2Mole_var1" && subPropertyName == "Value")
			{
				num13 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtDistC2Mole_var1.Value"));
				if (num13.HasValue)
				{
					m_entered[1, 0] = 1;
				}
				else
				{
					m_entered[1, 0] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtDistC3Mole_var1" && subPropertyName == "Value")
			{
				num14 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtDistC3Mole_var1.Value"));
				if (num14.HasValue)
				{
					m_entered[2, 0] = 1;
				}
				else
				{
					m_entered[2, 0] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtBotC1Mole_var1" && subPropertyName == "Value")
			{
				num15 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtBotC1Mole_var1.Value"));
				if (num15.HasValue)
				{
					m_entered[0, 1] = 1;
				}
				else
				{
					m_entered[0, 1] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtBotC2Mole_var1" && subPropertyName == "Value")
			{
				num16 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtBotC2Mole_var1.Value"));
				if (num16.HasValue)
				{
					m_entered[1, 1] = 1;
				}
				else
				{
					m_entered[1, 1] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtBotC3Mole_var1" && subPropertyName == "Value")
			{
				num17 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtBotC3Mole_var1.Value"));
				if (num17.HasValue)
				{
					m_entered[2, 1] = 1;
				}
				else
				{
					m_entered[2, 1] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtDistReco1_var1" && subPropertyName == "Value")
			{
				num18 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtDistReco1_var1.Value"));
				if (num18.HasValue)
				{
					m_entered[0, 2] = 1;
				}
				else
				{
					m_entered[0, 2] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtDistReco2_var1" && subPropertyName == "Value")
			{
				num19 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtDistReco2_var1.Value"));
				if (num19.HasValue)
				{
					m_entered[1, 2] = 1;
				}
				else
				{
					m_entered[1, 2] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtDistReco3_var1" && subPropertyName == "Value")
			{
				num20 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtDistReco3_var1.Value"));
				if (num20.HasValue)
				{
					m_entered[2, 2] = 1;
				}
				else
				{
					m_entered[2, 2] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtBotReco1_var1" && subPropertyName == "Value")
			{
				num21 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtBotReco1_var1.Value"));
				if (num21.HasValue)
				{
					m_entered[0, 3] = 1;
				}
				else
				{
					m_entered[0, 3] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtBotReco2_var1" && subPropertyName == "Value")
			{
				num22 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtBotReco2_var1.Value"));
				if (num22.HasValue)
				{
					m_entered[1, 3] = 1;
				}
				else
				{
					m_entered[1, 3] = 0;
				}
				SpecConstraint();
			}
			else if (pd.Name == "txtBotReco3_var1" && subPropertyName == "Value")
			{
				num23 = CxsConverter.ValueToDouble(ICxvViewDataContainerExtensions.ResolveViewPropertyPath((ICxvViewDataContainer)this, "txtBotReco3_var1.Value"));
				if (num23.HasValue)
				{
					m_entered[2, 3] = 1;
				}
				else
				{
					m_entered[2, 3] = 0;
				}
				SpecConstraint();
			}
			base.OnSubPropertyDataChanged(pd, subPropertyName);
		}

		protected override void OnUpdateData()
		{
			if (((CxvViewModel)this).IsInitialUpdate)
			{
				((CxvViewModel)this).ResolveUpdateParameter("p_optPhase", (object)"VLL");
				((CxvViewModel)this).ResolveUpdateParameter("p_Curve", (object)"RES");
			}
			base.OnUpdateData();
		}

		public MMConSep_Input_Spec_ViewModel()
		{
		}

		static MMConSep_Input_Spec_ViewModel()
		{
		MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.VALUE",
				IsEnabledCondition = new CxvLogicalTest
					{
						Operator = (CxvLogicalOperator)8,
						SubConditions =
						{
							new CxvLogicalTest
							{
								DataPath = "@main.CC Nodes.VAPCOMP"
							},
							new CxvLogicalTest
							{
								DataPath = "@main.Input.ICONFIG",
								Value = "DECANTER"
							}
						}
					}
			});
	cboColumn_var1_Property = CxvPropertyDeclaration.Register("cboColumn_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.COMP",
				IsVisibleCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.VAPCOMP"
				},
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.Input.ICONFIG",
					Value = "DECANTER"
				}
			});
	cboKeyComp_var1_Property = CxvPropertyDeclaration.Register("cboKeyComp_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.COMP",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.Input.ICONFIG",
					Value = "DECANTER"
				}
			});
	MMComboBox1_MultiMap_Property = CxvPropertyDeclaration.Register("MMComboBox1_MultiMap", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "MMComboBox1_var1",
				DataPath = "@main.Input.SPECTYPE"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Vapor composition",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Column_vapor_composition",
				Value = "MMComboBox1_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox1_var1",
				Value = "VAPOR-COMP"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Reflux composition",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Reflux_composition",
				Value = "MMComboBox1_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox1_var1",
				Value = "REFLUX-COMP"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Single phase reflux",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Single_phase_reflux",
				Value = "MMComboBox1_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox1_var1",
				Value = "SP-REFLUX"
			} }
				} },
	IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.Input.ICONFIG",
				Value = "DECANTER"
			}
});
	MMFrame3_state_Property = CxvPropertyDeclaration.Register("MMFrame3_state", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
			{
				IsVisibleCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.MOLEBA"
				}
			});
	txtBotC3Mole_var1_Property = CxvPropertyDeclaration.Register("txtBotC3Mole_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTC3MO",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_5_Enabled"
				}
			});
	txtBotReco3_var1_Property = CxvPropertyDeclaration.Register("txtBotReco3_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTRECO3",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_5_Enabled"
				}
			});
	txtBotC2Mole_var1_Property = CxvPropertyDeclaration.Register("txtBotC2Mole_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTC2MO",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_4_Enabled"
				}
			});
	txtBotReco2_var1_Property = CxvPropertyDeclaration.Register("txtBotReco2_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTRECO2",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_4_Enabled"
				}
			});
	txtBotC1Mole_var1_Property = CxvPropertyDeclaration.Register("txtBotC1Mole_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTC1MO",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_3_Enabled"
				}
			});
	txtBotReco1_var1_Property = CxvPropertyDeclaration.Register("txtBotReco1_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTRECO1",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_3_Enabled"
				}
			});
	txtDistReco1_var1_Property = CxvPropertyDeclaration.Register("txtDistReco1_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTRECO1",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_0_Enabled"
				}
			});
	txtDistC1Mole_var1_Property = CxvPropertyDeclaration.Register("txtDistC1Mole_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTC1MO",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_0_Enabled",
					Value = "1"
				}
			});
	txtDistReco2_var1_Property = CxvPropertyDeclaration.Register("txtDistReco2_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTRECO2",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_1_Enabled"
				}
			});
	txtDistC2Mole_var1_Property = CxvPropertyDeclaration.Register("txtDistC2Mole_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTC2MO",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_1_Enabled",
					Value = "1"
				}
			});
	txtDistReco3_var1_Property = CxvPropertyDeclaration.Register("txtDistReco3_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTRECO3",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_2_Enabled"
				}
			});
	txtDistC3Mole_var1_Property = CxvPropertyDeclaration.Register("txtDistC3Mole_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTC3MO",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_2_Enabled",
					Value = "1"
				}
			});
	optDesignMo_MultiMap_Property = CxvPropertyDeclaration.Register("optDesignMo_MultiMap", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "optDesignMo_var1",
				DataPath = "@main.Input.OPT_RB"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Reflux ratio",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Reflux_ratio",
				Value = "optDesignMo_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "optDesignMo_var1",
				Value = "RR"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Reboil ratio",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Reboil_ratio",
				Value = "optDesignMo_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "optDesignMo_var1",
				Value = "BR"
			} }
				} },
	IsVisibleCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.MOLEBA"
			}
});
	txtMoleBR_var1_Property = CxvPropertyDeclaration.Register("txtMoleBR_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.MOLE_BR",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.OPTBR"
				}
			});
	txtMoleRR_var1_Property = CxvPropertyDeclaration.Register("txtMoleRR_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.MOLE_RR",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.OPTRR"
				}
			});
	optDesignMa_MultiMap_Property = CxvPropertyDeclaration.Register("optDesignMa_MultiMap", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "optDesignMa_var1",
				DataPath = "@main.Input.OPT_RB"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Reflux ratio",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Reflux_ratio_1",
				Value = "optDesignMa_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "optDesignMa_var1",
				Value = "RR"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Reboil ratio",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Reboil_ratio_1",
				Value = "optDesignMa_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "optDesignMa_var1",
				Value = "BR"
			} }
				} },
	IsVisibleCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.MASSBA"
			}
});
	txtMassRR_var1_Property = CxvPropertyDeclaration.Register("txtMassRR_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.MASS_RR",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.OPTRR"
				}
			});
	txtMassBR_var1_Property = CxvPropertyDeclaration.Register("txtMassBR_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.MASS_BR",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.OPTBR"
				}
			});
	MMFrame1_state_Property = CxvPropertyDeclaration.Register("MMFrame1_state", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
			{
				IsVisibleCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.MASSBA"
				}
			});
	MMTextBox5_var1_Property = CxvPropertyDeclaration.Register("MMTextBox5_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTRECO1",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_0_Enabled",
					Value = "1"
				}
			});
	txtDistC1Mass_var1_Property = CxvPropertyDeclaration.Register("txtDistC1Mass_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTC1MA",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_0_Enabled",
					Value = "1"
				}
			});
	MMTextBox8_var1_Property = CxvPropertyDeclaration.Register("MMTextBox8_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTRECO2",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_1_Enabled",
					Value = "1"
				}
			});
	txtDistC2Mass_var1_Property = CxvPropertyDeclaration.Register("txtDistC2Mass_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTC2MA",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_1_Enabled",
					Value = "1"
				}
			});
	MMTextBox11_var1_Property = CxvPropertyDeclaration.Register("MMTextBox11_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTRECO3",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_2_Enabled",
					Value = "1"
				}
			});
	txtDistC3Mass_var1_Property = CxvPropertyDeclaration.Register("txtDistC3Mass_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DISTC3MA",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_2_Enabled",
					Value = "1"
				}
			});
	MMTextBox14_var1_Property = CxvPropertyDeclaration.Register("MMTextBox14_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTRECO1",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_3_Enabled",
					Value = "1"
				}
			});
	MMTextBox10_var1_Property = CxvPropertyDeclaration.Register("MMTextBox10_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTRECO2",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_4_Enabled",
					Value = "1"
				}
			});
	MMTextBox6_var1_Property = CxvPropertyDeclaration.Register("MMTextBox6_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTRECO3",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtReco_5_Enabled",
					Value = "1"
				}
			});
	txtBotC3Mass_var1_Property = CxvPropertyDeclaration.Register("txtBotC3Mass_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTC3MA",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_5_Enabled",
					Value = "1"
				}
			});
	txtBotC2Mass_var1_Property = CxvPropertyDeclaration.Register("txtBotC2Mass_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTC2MA",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_4_Enabled",
					Value = "1"
				}
			});
	txtBotC1Mass_var1_Property = CxvPropertyDeclaration.Register("txtBotC1Mass_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.BOTC1MA",
				IsEnabledCondition = new CxvLogicalTest
				{
					Parameter = "txtComp_3_Enabled",
					Value = "1"
				}
			});
	optCalculation_MultiMap_Property = CxvPropertyDeclaration.Register("optCalculation_MultiMap", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "optCalculation_var1",
				Parameter = "p_optPhase"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Vapor-Liquid-Liquid envelope",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_Liquidenvelope",
				Value = "optCalculation_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "optCalculation_var1",
				Value = "VLL"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Liquid-Liquid envelope",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Liquid_Liquidenvelope",
				Value = "optCalculation_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "optCalculation_var1",
				Value = "LL"
			} }
				} },
	IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.Input.IPHASE",
				Value = "VLL"
			}
});
	optCurve_MultiMap_Property = CxvPropertyDeclaration.Register("optCurve_MultiMap", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "optCurve_var1",
				Parameter = "p_Curve"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Residue curve",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Residue_curve",
				Value = "optCurve_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "optCurve_var1",
				Value = "RES"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Distillation curve",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Distillation_curve",
				Value = "optCurve_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "optCurve_var1",
				Value = "DIS"
			} }
				} }
});
	txtBotComp3_var1_Property = CxvPropertyDeclaration.Register("txtBotComp3_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP3",
				IsReadOnly = true
			});
	txtBotComp2_var1_Property = CxvPropertyDeclaration.Register("txtBotComp2_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP2",
				IsReadOnly = true
			});
	txtBotComp1_var1_Property = CxvPropertyDeclaration.Register("txtBotComp1_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP1",
				IsReadOnly = true
			});
	txtDistComp1Mo_var1_Property = CxvPropertyDeclaration.Register("txtDistComp1Mo_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP1",
				IsReadOnly = true
			});
	txtDistComp2Mo_var1_Property = CxvPropertyDeclaration.Register("txtDistComp2Mo_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP2",
				IsReadOnly = true
			});
	txtDistComp3Mo_var1_Property = CxvPropertyDeclaration.Register("txtDistComp3Mo_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP3",
				IsReadOnly = true
			});
	txtDistComp1Ma_var1_Property = CxvPropertyDeclaration.Register("txtDistComp1Ma_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP1",
				IsReadOnly = true
			});
	txtDistComp2Ma_var1_Property = CxvPropertyDeclaration.Register("txtDistComp2Ma_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP2",
				IsReadOnly = true
			});
	txtDistComp3Ma_var1_Property = CxvPropertyDeclaration.Register("txtDistComp3Ma_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP3",
				IsReadOnly = true
			});
	MMTextBox15_var1_Property = CxvPropertyDeclaration.Register("MMTextBox15_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP1",
				IsReadOnly = true
			});
	MMTextBox12_var1_Property = CxvPropertyDeclaration.Register("MMTextBox12_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP2",
				IsReadOnly = true
			});
	MMTextBox7_var1_Property = CxvPropertyDeclaration.Register("MMTextBox7_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SELCOMP3",
				IsReadOnly = true
			});
	cboBasis_MultiMap_Property = CxvPropertyDeclaration.Register("cboBasis_MultiMap", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboBasis_var1",
				DataPath = "@main.Input.IBASIS"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Mole",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Mole",
				Value = "cboBasis_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboBasis_var1",
				Value = "MOLE"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Mass",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Mass",
				Value = "cboBasis_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboBasis_var1",
				Value = "MASS"
			} }
				} }
});
	cboSelComp1_0_var1_Property = CxvPropertyDeclaration.Register("cboSelComp1_0_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.SELCOMP1"
			});
	cboSelComp2_var1_Property = CxvPropertyDeclaration.Register("cboSelComp2_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.SELCOMP2"
			});
	cboSelComp3_var1_Property = CxvPropertyDeclaration.Register("cboSelComp3_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.SELCOMP3"
			});
	lbtuPres_var1_Property = CxvPropertyDeclaration.Register("lbtuPres_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.P_SPEC"
			});
	cboPresUnit_var1_Property = CxvPropertyDeclaration.Register("cboPresUnit_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.PRESUNIT"
			});
	cboValidPhase_MultiMap_Property = CxvPropertyDeclaration.Register("cboValidPhase_MultiMap", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboValidPhase_var1",
				DataPath = "@main.Input.IPHASE"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Vapor-Liquid",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid",
				Value = "cboValidPhase_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboValidPhase_var1",
				Value = "VL"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Vapor-Liquid-Liquid",
				DisplayResourceKey = "MMConSep_Input_Spec_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_Liquid",
				Value = "cboValidPhase_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboValidPhase_var1",
				Value = "VLL"
			} }
				} }
});
	chkDecanter_var_Property = CxvPropertyDeclaration.Register("chkDecanter_var", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
			{
				DataPath = "@main.Input.ICONFIG",
				TrueValue = "DECANTER",
				FalseValue = "NO-DECANTER"
			});
	grpDecanter_var_Property = CxvPropertyDeclaration.Register("grpDecanter_var", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
			{
				DataPath = "@main.Input.IPHASE",
				TrueValue = "VLL",
				FalseValue = "VL"
			});
		cmdInteractiveDesign_var1_Property = CxvPropertyDeclaration.Register("cmdInteractiveDesign_var1", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
			{
				IsEnabledCondition = new CxvLogicalTest
					{
						Operator = (CxvLogicalOperator)8,
						SubConditions =
						{
							new CxvLogicalTest
							{
								DataPath = "@main.CC Nodes.SETUP",
								Operator = (CxvLogicalOperator)0,
								Value = "1"
							},
							new CxvLogicalTest
							{
								DataPath = "@main.CC Nodes.SPEC",
								Operator = (CxvLogicalOperator)0,
								Value = "1"
							},
							new CxvLogicalTest
							{
								DataPath = "@main.CC Nodes.COMPMAP",
								Operator = (CxvLogicalOperator)0,
								Value = "1"
							},
							new CxvLogicalTest
							{
								DataPath = "Top.appModelV8",
								Operator = (CxvLogicalOperator)1,
								DataAttribute = "status",
								Value = ApwnResources.InputIncomplete
							}
						}
					},
				DisabledPrompt = AspenTech.AspenPlus.Localization.Properties.Resources.MMConSep_Input_Spec_InteractiveDesignButtonDisabledPrompt
			});
		cmdInteractiveDesginCanExecuteProperty = CxvPropertyDeclaration.Register("cmdInteractiveDesginCanExecute", typeof(MMConSep_Input_Spec_ViewModel), (CxvPropertyBase)new CxvLogicalProperty
			{
				Operator = (CxvLogicalOperator)9,
				Tests =
				{
					new CxvLogicalTest
					{
						DataPath = "@main.Output.BLKSTAT",
						Operator = (CxvLogicalOperator)0,
						Value = "1"
					},
					new CxvLogicalTest
					{
						DataPath = "@main.Output.BLKSTAT",
						Operator = (CxvLogicalOperator)0,
						Value = "0"
					}
				}
			});
	}
	}
	[ProgId("MMConSep.MMConSep_Input_Spec")]
	public class MMConSep_Input_Spec : MMTabPage, IComponentConnector
	{
		internal MMLabel cboBasis_label;

		internal MMComboEdit cboBasis;

		internal MMCmdButton cmdInteractiveDesign;

		internal MMGroupBox grpKeyComps;

		internal MMComboEdit cboSelComp2;

		internal MMComboEdit cboSelComp3;

		internal MMComboEdit cboSelComp1;

		internal MMGroupBox grpSpecifications;

		internal MMOptionGroup optDesignMo;

		internal MMOptionButton optDesignMo_opt0;

		internal MMValueEdit txtMoleRR;

		internal MMOptionButton optDesignMo_opt1;

		internal MMValueEdit txtMoleBR;

		internal MMOptionGroup optDesignMa;

		internal MMOptionButton optDesignMa_opt0;

		internal MMValueEdit txtMassRR;

		internal MMOptionButton optDesignMa_opt1;

		internal MMValueEdit txtMassBR;

		internal MMLabel lbtuPres_label;

		internal MMVariableEdit lbtuPres;

		internal MMLabel cboValidPhase_label;

		internal MMComboEdit cboValidPhase;

		internal MMGroupBox frmDistMo;

		internal MMLabel MMLabel1;

		internal MMLabel MMLabel2;

		internal MMLabel MMLabel3;

		internal MMValueEdit txtDistComp1Mo;

		internal MMValueEdit txtDistC1Mole;

		internal MMValueEdit txtDistReco1;

		internal MMValueEdit txtDistComp2Mo;

		internal MMValueEdit txtDistC2Mole;

		internal MMValueEdit txtDistReco2;

		internal MMValueEdit txtDistComp3Mo;

		internal MMValueEdit txtDistC3Mole;

		internal MMValueEdit txtDistReco3;

		internal MMGroupBox frmDistMa;

		internal MMLabel MMLabel7;

		internal MMLabel MMLabel8;

		internal MMLabel MMLabel9;

		internal MMValueEdit txtDistComp1Ma;

		internal MMValueEdit txtDistC1Mass;

		internal MMValueEdit MMTextBox5;

		internal MMValueEdit txtDistComp2Ma;

		internal MMValueEdit txtDistC2Mass;

		internal MMValueEdit MMTextBox8;

		internal MMValueEdit txtDistComp3Ma;

		internal MMValueEdit txtDistC3Mass;

		internal MMValueEdit MMTextBox11;

		internal MMGroupBox frmDecanter;

		internal MMCheckBox chkDecanter;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMLabel cboKeyComp_label;

		internal MMComboEdit cboKeyComp;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMGroupBox frmBot;

		internal MMLabel MMLabel6;

		internal MMLabel MMLabel5;

		internal MMLabel MMLabel4;

		internal MMValueEdit txtBotComp1;

		internal MMValueEdit txtBotC1Mole;

		internal MMValueEdit txtBotReco1;

		internal MMValueEdit txtBotComp2;

		internal MMValueEdit txtBotC2Mole;

		internal MMValueEdit txtBotReco2;

		internal MMValueEdit txtBotComp3;

		internal MMValueEdit txtBotC3Mole;

		internal MMValueEdit txtBotReco3;

		internal MMGroupBox MMFrame2;

		internal MMLabel MMLabel12;

		internal MMLabel MMLabel11;

		internal MMLabel MMLabel10;

		internal MMValueEdit MMTextBox15;

		internal MMValueEdit txtBotC1Mass;

		internal MMValueEdit MMTextBox14;

		internal MMValueEdit MMTextBox12;

		internal MMValueEdit txtBotC2Mass;

		internal MMValueEdit MMTextBox10;

		internal MMValueEdit MMTextBox7;

		internal MMValueEdit txtBotC3Mass;

		internal MMValueEdit MMTextBox6;

		internal MMGroupBox grpCalcOptions;

		internal MMOptionGroup grpPhase;

		internal MMOptionButton optCalclation_opt0;

		internal MMOptionButton optCalclation_opt1;

		internal MMOptionGroup grpResDisCurve;

		internal MMOptionButton optCurve_opt0;

		internal MMOptionButton optCurve_opt1;

		private bool _contentLoaded;

		public MMConSep_Input_Spec()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Input_Spec_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_input_spec.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0173: Unknown result type (might be due to invalid IL or missing references)
			//IL_017d: Expected O, but got Unknown
			//IL_0180: Unknown result type (might be due to invalid IL or missing references)
			//IL_018a: Expected O, but got Unknown
			//IL_018d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0197: Expected O, but got Unknown
			//IL_019a: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a4: Expected O, but got Unknown
			//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b1: Expected O, but got Unknown
			//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_01be: Expected O, but got Unknown
			//IL_01c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_01cb: Expected O, but got Unknown
			//IL_01ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d8: Expected O, but got Unknown
			//IL_01db: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e5: Expected O, but got Unknown
			//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f2: Expected O, but got Unknown
			//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ff: Expected O, but got Unknown
			//IL_0202: Unknown result type (might be due to invalid IL or missing references)
			//IL_020c: Expected O, but got Unknown
			//IL_020f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0219: Expected O, but got Unknown
			//IL_021c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0226: Expected O, but got Unknown
			//IL_0229: Unknown result type (might be due to invalid IL or missing references)
			//IL_0233: Expected O, but got Unknown
			//IL_0236: Unknown result type (might be due to invalid IL or missing references)
			//IL_0240: Expected O, but got Unknown
			//IL_0243: Unknown result type (might be due to invalid IL or missing references)
			//IL_024d: Expected O, but got Unknown
			//IL_0250: Unknown result type (might be due to invalid IL or missing references)
			//IL_025a: Expected O, but got Unknown
			//IL_025d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0267: Expected O, but got Unknown
			//IL_026a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0274: Expected O, but got Unknown
			//IL_0277: Unknown result type (might be due to invalid IL or missing references)
			//IL_0281: Expected O, but got Unknown
			//IL_0284: Unknown result type (might be due to invalid IL or missing references)
			//IL_028e: Expected O, but got Unknown
			//IL_0291: Unknown result type (might be due to invalid IL or missing references)
			//IL_029b: Expected O, but got Unknown
			//IL_029e: Unknown result type (might be due to invalid IL or missing references)
			//IL_02a8: Expected O, but got Unknown
			//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_02b5: Expected O, but got Unknown
			//IL_02b8: Unknown result type (might be due to invalid IL or missing references)
			//IL_02c2: Expected O, but got Unknown
			//IL_02c5: Unknown result type (might be due to invalid IL or missing references)
			//IL_02cf: Expected O, but got Unknown
			//IL_02d2: Unknown result type (might be due to invalid IL or missing references)
			//IL_02dc: Expected O, but got Unknown
			//IL_02df: Unknown result type (might be due to invalid IL or missing references)
			//IL_02e9: Expected O, but got Unknown
			//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
			//IL_02f6: Expected O, but got Unknown
			//IL_02f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0303: Expected O, but got Unknown
			//IL_0306: Unknown result type (might be due to invalid IL or missing references)
			//IL_0310: Expected O, but got Unknown
			//IL_0313: Unknown result type (might be due to invalid IL or missing references)
			//IL_031d: Expected O, but got Unknown
			//IL_0320: Unknown result type (might be due to invalid IL or missing references)
			//IL_032a: Expected O, but got Unknown
			//IL_032d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0337: Expected O, but got Unknown
			//IL_033a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0344: Expected O, but got Unknown
			//IL_0347: Unknown result type (might be due to invalid IL or missing references)
			//IL_0351: Expected O, but got Unknown
			//IL_0354: Unknown result type (might be due to invalid IL or missing references)
			//IL_035e: Expected O, but got Unknown
			//IL_0361: Unknown result type (might be due to invalid IL or missing references)
			//IL_036b: Expected O, but got Unknown
			//IL_036e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0378: Expected O, but got Unknown
			//IL_037b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0385: Expected O, but got Unknown
			//IL_0388: Unknown result type (might be due to invalid IL or missing references)
			//IL_0392: Expected O, but got Unknown
			//IL_0395: Unknown result type (might be due to invalid IL or missing references)
			//IL_039f: Expected O, but got Unknown
			//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_03ac: Expected O, but got Unknown
			//IL_03af: Unknown result type (might be due to invalid IL or missing references)
			//IL_03b9: Expected O, but got Unknown
			//IL_03bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_03c6: Expected O, but got Unknown
			//IL_03c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_03d3: Expected O, but got Unknown
			//IL_03d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_03e0: Expected O, but got Unknown
			//IL_03e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_03ed: Expected O, but got Unknown
			//IL_03f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_03fa: Expected O, but got Unknown
			//IL_03fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0407: Expected O, but got Unknown
			//IL_040a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0414: Expected O, but got Unknown
			//IL_0417: Unknown result type (might be due to invalid IL or missing references)
			//IL_0421: Expected O, but got Unknown
			//IL_0424: Unknown result type (might be due to invalid IL or missing references)
			//IL_042e: Expected O, but got Unknown
			//IL_0431: Unknown result type (might be due to invalid IL or missing references)
			//IL_043b: Expected O, but got Unknown
			//IL_043e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0448: Expected O, but got Unknown
			//IL_044b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0455: Expected O, but got Unknown
			//IL_0458: Unknown result type (might be due to invalid IL or missing references)
			//IL_0462: Expected O, but got Unknown
			//IL_0465: Unknown result type (might be due to invalid IL or missing references)
			//IL_046f: Expected O, but got Unknown
			//IL_0472: Unknown result type (might be due to invalid IL or missing references)
			//IL_047c: Expected O, but got Unknown
			//IL_047f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0489: Expected O, but got Unknown
			//IL_048c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0496: Expected O, but got Unknown
			//IL_0499: Unknown result type (might be due to invalid IL or missing references)
			//IL_04a3: Expected O, but got Unknown
			//IL_04a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_04b0: Expected O, but got Unknown
			//IL_04b3: Unknown result type (might be due to invalid IL or missing references)
			//IL_04bd: Expected O, but got Unknown
			//IL_04c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_04ca: Expected O, but got Unknown
			//IL_04cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_04d7: Expected O, but got Unknown
			//IL_04da: Unknown result type (might be due to invalid IL or missing references)
			//IL_04e4: Expected O, but got Unknown
			//IL_04e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_04f1: Expected O, but got Unknown
			//IL_04f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_04fe: Expected O, but got Unknown
			//IL_0501: Unknown result type (might be due to invalid IL or missing references)
			//IL_050b: Expected O, but got Unknown
			//IL_050e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0518: Expected O, but got Unknown
			//IL_051b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0525: Expected O, but got Unknown
			//IL_0528: Unknown result type (might be due to invalid IL or missing references)
			//IL_0532: Expected O, but got Unknown
			//IL_0535: Unknown result type (might be due to invalid IL or missing references)
			//IL_053f: Expected O, but got Unknown
			//IL_0542: Unknown result type (might be due to invalid IL or missing references)
			//IL_054c: Expected O, but got Unknown
			//IL_054f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0559: Expected O, but got Unknown
			//IL_055c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0566: Expected O, but got Unknown
			//IL_0569: Unknown result type (might be due to invalid IL or missing references)
			//IL_0573: Expected O, but got Unknown
			//IL_0576: Unknown result type (might be due to invalid IL or missing references)
			//IL_0580: Expected O, but got Unknown
			//IL_0583: Unknown result type (might be due to invalid IL or missing references)
			//IL_058d: Expected O, but got Unknown
			//IL_0590: Unknown result type (might be due to invalid IL or missing references)
			//IL_059a: Expected O, but got Unknown
			//IL_059d: Unknown result type (might be due to invalid IL or missing references)
			//IL_05a7: Expected O, but got Unknown
			//IL_05aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_05b4: Expected O, but got Unknown
			//IL_05b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_05c1: Expected O, but got Unknown
			//IL_05c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_05ce: Expected O, but got Unknown
			//IL_05d1: Unknown result type (might be due to invalid IL or missing references)
			//IL_05db: Expected O, but got Unknown
			//IL_05de: Unknown result type (might be due to invalid IL or missing references)
			//IL_05e8: Expected O, but got Unknown
			//IL_05eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_05f5: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				cboBasis_label = (MMLabel)target;
				break;
			case 2:
				cboBasis = (MMComboEdit)target;
				break;
			case 3:
				cmdInteractiveDesign = (MMCmdButton)target;
				break;
			case 4:
				grpKeyComps = (MMGroupBox)target;
				break;
			case 5:
				cboSelComp2 = (MMComboEdit)target;
				break;
			case 6:
				cboSelComp3 = (MMComboEdit)target;
				break;
			case 7:
				cboSelComp1 = (MMComboEdit)target;
				break;
			case 8:
				grpSpecifications = (MMGroupBox)target;
				break;
			case 9:
				optDesignMo = (MMOptionGroup)target;
				break;
			case 10:
				optDesignMo_opt0 = (MMOptionButton)target;
				break;
			case 11:
				txtMoleRR = (MMValueEdit)target;
				break;
			case 12:
				optDesignMo_opt1 = (MMOptionButton)target;
				break;
			case 13:
				txtMoleBR = (MMValueEdit)target;
				break;
			case 14:
				optDesignMa = (MMOptionGroup)target;
				break;
			case 15:
				optDesignMa_opt0 = (MMOptionButton)target;
				break;
			case 16:
				txtMassRR = (MMValueEdit)target;
				break;
			case 17:
				optDesignMa_opt1 = (MMOptionButton)target;
				break;
			case 18:
				txtMassBR = (MMValueEdit)target;
				break;
			case 19:
				lbtuPres_label = (MMLabel)target;
				break;
			case 20:
				lbtuPres = (MMVariableEdit)target;
				break;
			case 21:
				cboValidPhase_label = (MMLabel)target;
				break;
			case 22:
				cboValidPhase = (MMComboEdit)target;
				break;
			case 23:
				frmDistMo = (MMGroupBox)target;
				break;
			case 24:
				MMLabel1 = (MMLabel)target;
				break;
			case 25:
				MMLabel2 = (MMLabel)target;
				break;
			case 26:
				MMLabel3 = (MMLabel)target;
				break;
			case 27:
				txtDistComp1Mo = (MMValueEdit)target;
				break;
			case 28:
				txtDistC1Mole = (MMValueEdit)target;
				break;
			case 29:
				txtDistReco1 = (MMValueEdit)target;
				break;
			case 30:
				txtDistComp2Mo = (MMValueEdit)target;
				break;
			case 31:
				txtDistC2Mole = (MMValueEdit)target;
				break;
			case 32:
				txtDistReco2 = (MMValueEdit)target;
				break;
			case 33:
				txtDistComp3Mo = (MMValueEdit)target;
				break;
			case 34:
				txtDistC3Mole = (MMValueEdit)target;
				break;
			case 35:
				txtDistReco3 = (MMValueEdit)target;
				break;
			case 36:
				frmDistMa = (MMGroupBox)target;
				break;
			case 37:
				MMLabel7 = (MMLabel)target;
				break;
			case 38:
				MMLabel8 = (MMLabel)target;
				break;
			case 39:
				MMLabel9 = (MMLabel)target;
				break;
			case 40:
				txtDistComp1Ma = (MMValueEdit)target;
				break;
			case 41:
				txtDistC1Mass = (MMValueEdit)target;
				break;
			case 42:
				MMTextBox5 = (MMValueEdit)target;
				break;
			case 43:
				txtDistComp2Ma = (MMValueEdit)target;
				break;
			case 44:
				txtDistC2Mass = (MMValueEdit)target;
				break;
			case 45:
				MMTextBox8 = (MMValueEdit)target;
				break;
			case 46:
				txtDistComp3Ma = (MMValueEdit)target;
				break;
			case 47:
				txtDistC3Mass = (MMValueEdit)target;
				break;
			case 48:
				MMTextBox11 = (MMValueEdit)target;
				break;
			case 49:
				frmDecanter = (MMGroupBox)target;
				break;
			case 50:
				chkDecanter = (MMCheckBox)target;
				break;
			case 51:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 52:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 53:
				cboKeyComp_label = (MMLabel)target;
				break;
			case 54:
				cboKeyComp = (MMComboEdit)target;
				break;
			case 55:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 56:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 57:
				frmBot = (MMGroupBox)target;
				break;
			case 58:
				MMLabel6 = (MMLabel)target;
				break;
			case 59:
				MMLabel5 = (MMLabel)target;
				break;
			case 60:
				MMLabel4 = (MMLabel)target;
				break;
			case 61:
				txtBotComp1 = (MMValueEdit)target;
				break;
			case 62:
				txtBotC1Mole = (MMValueEdit)target;
				break;
			case 63:
				txtBotReco1 = (MMValueEdit)target;
				break;
			case 64:
				txtBotComp2 = (MMValueEdit)target;
				break;
			case 65:
				txtBotC2Mole = (MMValueEdit)target;
				break;
			case 66:
				txtBotReco2 = (MMValueEdit)target;
				break;
			case 67:
				txtBotComp3 = (MMValueEdit)target;
				break;
			case 68:
				txtBotC3Mole = (MMValueEdit)target;
				break;
			case 69:
				txtBotReco3 = (MMValueEdit)target;
				break;
			case 70:
				MMFrame2 = (MMGroupBox)target;
				break;
			case 71:
				MMLabel12 = (MMLabel)target;
				break;
			case 72:
				MMLabel11 = (MMLabel)target;
				break;
			case 73:
				MMLabel10 = (MMLabel)target;
				break;
			case 74:
				MMTextBox15 = (MMValueEdit)target;
				break;
			case 75:
				txtBotC1Mass = (MMValueEdit)target;
				break;
			case 76:
				MMTextBox14 = (MMValueEdit)target;
				break;
			case 77:
				MMTextBox12 = (MMValueEdit)target;
				break;
			case 78:
				txtBotC2Mass = (MMValueEdit)target;
				break;
			case 79:
				MMTextBox10 = (MMValueEdit)target;
				break;
			case 80:
				MMTextBox7 = (MMValueEdit)target;
				break;
			case 81:
				txtBotC3Mass = (MMValueEdit)target;
				break;
			case 82:
				MMTextBox6 = (MMValueEdit)target;
				break;
			case 83:
				grpCalcOptions = (MMGroupBox)target;
				break;
			case 84:
				grpPhase = (MMOptionGroup)target;
				break;
			case 85:
				optCalclation_opt0 = (MMOptionButton)target;
				break;
			case 86:
				optCalclation_opt1 = (MMOptionButton)target;
				break;
			case 87:
				grpResDisCurve = (MMOptionGroup)target;
				break;
			case 88:
				optCurve_opt0 = (MMOptionButton)target;
				break;
			case 89:
				optCurve_opt1 = (MMOptionButton)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMConSep_ProfilePlot_ViewModel : MMTabPageViewModel
	{
	}
	[ProgId("MMConSep.MMConSep_ProfilePlot")]
	public class MMConSep_ProfilePlot : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMTabStrip1;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		private bool _contentLoaded;

		public MMConSep_ProfilePlot()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_ProfilePlot_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_profileplot.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMTabStrip1 = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMConSep_Result_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration B_PRES1_Property = CxvPropertyDeclaration.Register("B_PRES1", typeof(MMConSep_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_PRES1"
		});

		public static readonly CxvPropertyDeclaration X4_Property = CxvPropertyDeclaration.Register("X4", typeof(MMConSep_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X4.1"
		});

		public static readonly CxvPropertyDeclaration ACT_STAGES2_Property = CxvPropertyDeclaration.Register("ACT_STAGES2", typeof(MMConSep_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.ACT_STAGES2"
		});

		public static readonly CxvPropertyDeclaration STAGE_NO2_Property = CxvPropertyDeclaration.Register("STAGE_NO2", typeof(MMConSep_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.STAGE_NO2"
		});

		public static readonly CxvPropertyDeclaration STAGE_NO3_Property = CxvPropertyDeclaration.Register("STAGE_NO3", typeof(MMConSep_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.STAGE_NO3"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMConSep_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@B_PRES1" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMConSep_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@X4" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMConSep_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@ACT_STAGES2" }
		});

		public static readonly CxvPropertyDeclaration tab3_var_Property = CxvPropertyDeclaration.Register("tab3_var", typeof(MMConSep_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@STAGE_NO2" }
		});

		public static readonly CxvPropertyDeclaration tab4_var_Property = CxvPropertyDeclaration.Register("tab4_var", typeof(MMConSep_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@STAGE_NO3" }
		});

		public object B_PRES1 => ((CxvViewModel)this).GetValue(B_PRES1_Property);

		public object X4 => ((CxvViewModel)this).GetValue(X4_Property);

		public object ACT_STAGES2 => ((CxvViewModel)this).GetValue(ACT_STAGES2_Property);

		public object STAGE_NO2 => ((CxvViewModel)this).GetValue(STAGE_NO2_Property);

		public object STAGE_NO3 => ((CxvViewModel)this).GetValue(STAGE_NO3_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);

		public object tab3_var => ((CxvViewModel)this).GetValue(tab3_var_Property);

		public object tab4_var => ((CxvViewModel)this).GetValue(tab4_var_Property);
	}
	[ProgId("MMConSep.MMConSep_Result")]
	public class MMConSep_Result : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMTabStrip1;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem tab3;

		internal MMTabItem tab4;

		internal MMTabItem tabStatus;

		private bool _contentLoaded;

		public MMConSep_Result()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Result_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_result.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Expected O, but got Unknown
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_003f: Expected O, but got Unknown
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_004c: Expected O, but got Unknown
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Expected O, but got Unknown
			//IL_005c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Expected O, but got Unknown
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Expected O, but got Unknown
			//IL_0076: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMTabStrip1 = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				tab3 = (MMTabItem)target;
				break;
			case 6:
				tab4 = (MMTabItem)target;
				break;
			case 7:
				tabStatus = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMConSep_Result_Decanter_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMTextBox25_var1_Property = CxvPropertyDeclaration.Register("MMTextBox25_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X9.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox24_var1_Property = CxvPropertyDeclaration.Register("MMTextBox24_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X9.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox23_var1_Property = CxvPropertyDeclaration.Register("MMTextBox23_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X8.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox22_var1_Property = CxvPropertyDeclaration.Register("MMTextBox22_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X8.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox21_var1_Property = CxvPropertyDeclaration.Register("MMTextBox21_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X7.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox20_var1_Property = CxvPropertyDeclaration.Register("MMTextBox20_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X7.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox19_var1_Property = CxvPropertyDeclaration.Register("MMTextBox19_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X6.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox18_var1_Property = CxvPropertyDeclaration.Register("MMTextBox18_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X6.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox17_var1_Property = CxvPropertyDeclaration.Register("MMTextBox17_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X5.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox16_var1_Property = CxvPropertyDeclaration.Register("MMTextBox16_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X5.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox15_var1_Property = CxvPropertyDeclaration.Register("MMTextBox15_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X4.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox14_var1_Property = CxvPropertyDeclaration.Register("MMTextBox14_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X4.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox13_var1_Property = CxvPropertyDeclaration.Register("MMTextBox13_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FRACTION.4"
		});

		public static readonly CxvPropertyDeclaration MMTextBox12_var1_Property = CxvPropertyDeclaration.Register("MMTextBox12_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FRACTION.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox11_var1_Property = CxvPropertyDeclaration.Register("MMTextBox11_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FRACTION.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox10_var1_Property = CxvPropertyDeclaration.Register("MMTextBox10_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FRACTION.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox9_var1_Property = CxvPropertyDeclaration.Register("MMTextBox9_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X9.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox8_var1_Property = CxvPropertyDeclaration.Register("MMTextBox8_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X8.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox7_var1_Property = CxvPropertyDeclaration.Register("MMTextBox7_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X7.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox4_var1_Property = CxvPropertyDeclaration.Register("MMTextBox4_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X6.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X5.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X4.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox6_var1_Property = CxvPropertyDeclaration.Register("MMTextBox6_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox5_var1_Property = CxvPropertyDeclaration.Register("MMTextBox5_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMConSep_Result_Decanter_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.1"
		});

		public object MMTextBox25_var1 => ((CxvViewModel)this).GetValue(MMTextBox25_var1_Property);

		public object MMTextBox24_var1 => ((CxvViewModel)this).GetValue(MMTextBox24_var1_Property);

		public object MMTextBox23_var1 => ((CxvViewModel)this).GetValue(MMTextBox23_var1_Property);

		public object MMTextBox22_var1 => ((CxvViewModel)this).GetValue(MMTextBox22_var1_Property);

		public object MMTextBox21_var1 => ((CxvViewModel)this).GetValue(MMTextBox21_var1_Property);

		public object MMTextBox20_var1 => ((CxvViewModel)this).GetValue(MMTextBox20_var1_Property);

		public object MMTextBox19_var1 => ((CxvViewModel)this).GetValue(MMTextBox19_var1_Property);

		public object MMTextBox18_var1 => ((CxvViewModel)this).GetValue(MMTextBox18_var1_Property);

		public object MMTextBox17_var1 => ((CxvViewModel)this).GetValue(MMTextBox17_var1_Property);

		public object MMTextBox16_var1 => ((CxvViewModel)this).GetValue(MMTextBox16_var1_Property);

		public object MMTextBox15_var1 => ((CxvViewModel)this).GetValue(MMTextBox15_var1_Property);

		public object MMTextBox14_var1 => ((CxvViewModel)this).GetValue(MMTextBox14_var1_Property);

		public object MMTextBox13_var1 => ((CxvViewModel)this).GetValue(MMTextBox13_var1_Property);

		public object MMTextBox12_var1 => ((CxvViewModel)this).GetValue(MMTextBox12_var1_Property);

		public object MMTextBox11_var1 => ((CxvViewModel)this).GetValue(MMTextBox11_var1_Property);

		public object MMTextBox10_var1 => ((CxvViewModel)this).GetValue(MMTextBox10_var1_Property);

		public object MMTextBox9_var1 => ((CxvViewModel)this).GetValue(MMTextBox9_var1_Property);

		public object MMTextBox8_var1 => ((CxvViewModel)this).GetValue(MMTextBox8_var1_Property);

		public object MMTextBox7_var1 => ((CxvViewModel)this).GetValue(MMTextBox7_var1_Property);

		public object MMTextBox4_var1 => ((CxvViewModel)this).GetValue(MMTextBox4_var1_Property);

		public object MMTextBox3_var1 => ((CxvViewModel)this).GetValue(MMTextBox3_var1_Property);

		public object MMTextBox2_var1 => ((CxvViewModel)this).GetValue(MMTextBox2_var1_Property);

		public object MMTextBox6_var1 => ((CxvViewModel)this).GetValue(MMTextBox6_var1_Property);

		public object MMTextBox5_var1 => ((CxvViewModel)this).GetValue(MMTextBox5_var1_Property);

		public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);
	}
	[ProgId("MMConSep.MMConSep_Result_Decanter")]
	public class MMConSep_Result_Decanter : MMTabPage, IComponentConnector
	{
		internal MMScrollAreaManualLayout MMScrollArea1;

		private bool _contentLoaded;

		public MMConSep_Result_Decanter()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Result_Decanter_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_result_decanter.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			if (connectionId == 1)
			{
				MMScrollArea1 = (MMScrollAreaManualLayout)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMConSep_Result_Design_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMTextBox17_var1_Property = CxvPropertyDeclaration.Register("MMTextBox17_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.VL_RATIO2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox16_var1_Property = CxvPropertyDeclaration.Register("MMTextBox16_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.VL_RATIO1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox15_var1_Property = CxvPropertyDeclaration.Register("MMTextBox15_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOT_VFLOW"
		});

		public static readonly CxvPropertyDeclaration MMTextBox14_var1_Property = CxvPropertyDeclaration.Register("MMTextBox14_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TOP_VFLOW"
		});

		public static readonly CxvPropertyDeclaration MMTextBox13_var1_Property = CxvPropertyDeclaration.Register("MMTextBox13_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOT_LFLOW"
		});

		public static readonly CxvPropertyDeclaration MMTextBox12_var1_Property = CxvPropertyDeclaration.Register("MMTextBox12_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TOP_LFLOW"
		});

		public static readonly CxvPropertyDeclaration MMTextBox11_var1_Property = CxvPropertyDeclaration.Register("MMTextBox11_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.REB_DUTY2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox10_var1_Property = CxvPropertyDeclaration.Register("MMTextBox10_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOTTOM_TEMP2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox9_var1_Property = CxvPropertyDeclaration.Register("MMTextBox9_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BR2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox8_var1_Property = CxvPropertyDeclaration.Register("MMTextBox8_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COND_DUTY2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox7_var1_Property = CxvPropertyDeclaration.Register("MMTextBox7_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.DISTIL_TEMP2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox6_var1_Property = CxvPropertyDeclaration.Register("MMTextBox6_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.RR2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox4_var1_Property = CxvPropertyDeclaration.Register("MMTextBox4_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.STAGE_NO1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.RECT_STAGES2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FEED_LOCATN2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.ACT_STAGES2"
		});

		public static readonly CxvPropertyDeclaration MMLBUText8_var1_Property = CxvPropertyDeclaration.Register("MMLBUText8_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOT_VFLOW"
		});

		public static readonly CxvPropertyDeclaration MMLBUText7_var1_Property = CxvPropertyDeclaration.Register("MMLBUText7_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TOP_VFLOW"
		});

		public static readonly CxvPropertyDeclaration MMLBUText6_var1_Property = CxvPropertyDeclaration.Register("MMLBUText6_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOT_LFLOW"
		});

		public static readonly CxvPropertyDeclaration MMLBUText5_var1_Property = CxvPropertyDeclaration.Register("MMLBUText5_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TOP_LFLOW"
		});

		public static readonly CxvPropertyDeclaration MMLBUText4_var1_Property = CxvPropertyDeclaration.Register("MMLBUText4_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.REB_DUTY2"
		});

		public static readonly CxvPropertyDeclaration MMLBUText3_var1_Property = CxvPropertyDeclaration.Register("MMLBUText3_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOTTOM_TEMP2"
		});

		public static readonly CxvPropertyDeclaration MMLBUText2_var1_Property = CxvPropertyDeclaration.Register("MMLBUText2_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COND_DUTY2"
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMConSep_Result_Design_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.DISTIL_TEMP2"
		});

		public object MMTextBox17_var1 => ((CxvViewModel)this).GetValue(MMTextBox17_var1_Property);

		public object MMTextBox16_var1 => ((CxvViewModel)this).GetValue(MMTextBox16_var1_Property);

		public object MMTextBox15_var1 => ((CxvViewModel)this).GetValue(MMTextBox15_var1_Property);

		public object MMTextBox14_var1 => ((CxvViewModel)this).GetValue(MMTextBox14_var1_Property);

		public object MMTextBox13_var1 => ((CxvViewModel)this).GetValue(MMTextBox13_var1_Property);

		public object MMTextBox12_var1 => ((CxvViewModel)this).GetValue(MMTextBox12_var1_Property);

		public object MMTextBox11_var1 => ((CxvViewModel)this).GetValue(MMTextBox11_var1_Property);

		public object MMTextBox10_var1 => ((CxvViewModel)this).GetValue(MMTextBox10_var1_Property);

		public object MMTextBox9_var1 => ((CxvViewModel)this).GetValue(MMTextBox9_var1_Property);

		public object MMTextBox8_var1 => ((CxvViewModel)this).GetValue(MMTextBox8_var1_Property);

		public object MMTextBox7_var1 => ((CxvViewModel)this).GetValue(MMTextBox7_var1_Property);

		public object MMTextBox6_var1 => ((CxvViewModel)this).GetValue(MMTextBox6_var1_Property);

		public object MMTextBox4_var1 => ((CxvViewModel)this).GetValue(MMTextBox4_var1_Property);

		public object MMTextBox3_var1 => ((CxvViewModel)this).GetValue(MMTextBox3_var1_Property);

		public object MMTextBox2_var1 => ((CxvViewModel)this).GetValue(MMTextBox2_var1_Property);

		public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);

		public object MMLBUText8_var1 => ((CxvViewModel)this).GetValue(MMLBUText8_var1_Property);

		public object MMLBUText7_var1 => ((CxvViewModel)this).GetValue(MMLBUText7_var1_Property);

		public object MMLBUText6_var1 => ((CxvViewModel)this).GetValue(MMLBUText6_var1_Property);

		public object MMLBUText5_var1 => ((CxvViewModel)this).GetValue(MMLBUText5_var1_Property);

		public object MMLBUText4_var1 => ((CxvViewModel)this).GetValue(MMLBUText4_var1_Property);

		public object MMLBUText3_var1 => ((CxvViewModel)this).GetValue(MMLBUText3_var1_Property);

		public object MMLBUText2_var1 => ((CxvViewModel)this).GetValue(MMLBUText2_var1_Property);

		public object MMLBUText1_var1 => ((CxvViewModel)this).GetValue(MMLBUText1_var1_Property);
	}
	[ProgId("MMConSep.MMConSep_Result_Design")]
	public class MMConSep_Result_Design : MMTabPage, IComponentConnector
	{
		internal MMScrollAreaManualLayout MMScrollArea1;

		private bool _contentLoaded;

		public MMConSep_Result_Design()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Result_Design_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_result_design.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			if (connectionId == 1)
			{
				MMScrollArea1 = (MMScrollAreaManualLayout)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMConSep_Result_LiqPro_ViewModel : MMTabPageViewModel
	{
		public class MMScrollArea1_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox8_var1_Property = CxvPropertyDeclaration.Register("MMTextBox8_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.X10.@y.3"
			});

			public static readonly CxvPropertyDeclaration MMTextBox7_var1_Property = CxvPropertyDeclaration.Register("MMTextBox7_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.X10.@y.2"
			});

			public static readonly CxvPropertyDeclaration MMTextBox6_var1_Property = CxvPropertyDeclaration.Register("MMTextBox6_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.X10.@y.1"
			});

			public static readonly CxvPropertyDeclaration MMTextBox5_var1_Property = CxvPropertyDeclaration.Register("MMTextBox5_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.B_TEMP4.@y"
			});

			public static readonly CxvPropertyDeclaration MMTextBox4_var1_Property = CxvPropertyDeclaration.Register("MMTextBox4_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.STAGE_NO2.@y"
			});

			public object MMTextBox8_var1 => ((CxvViewModel)this).GetValue(MMTextBox8_var1_Property);

			public object MMTextBox7_var1 => ((CxvViewModel)this).GetValue(MMTextBox7_var1_Property);

			public object MMTextBox6_var1 => ((CxvViewModel)this).GetValue(MMTextBox6_var1_Property);

			public object MMTextBox5_var1 => ((CxvViewModel)this).GetValue(MMTextBox5_var1_Property);

			public object MMTextBox4_var1 => ((CxvViewModel)this).GetValue(MMTextBox4_var1_Property);
		}

		public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(MMConSep_Result_LiqPro_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(MMConSep_Result_LiqPro_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMConSep_Result_LiqPro_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.1"
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMConSep_Result_LiqPro_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP4"
		});

		public static readonly CxvPropertyDeclaration MMScrollArea1_GridData_Property = CxvPropertyDeclaration.Register("MMScrollArea1_GridData", typeof(MMConSep_Result_LiqPro_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(MMScrollArea1_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Output.STAGE_NO2",
				UseChildId = true,
				Name = "y"
			}
		});

		public object MMTextBox3_var1 => ((CxvViewModel)this).GetValue(MMTextBox3_var1_Property);

		public object MMTextBox2_var1 => ((CxvViewModel)this).GetValue(MMTextBox2_var1_Property);

		public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);

		public object MMLBUText1_var1 => ((CxvViewModel)this).GetValue(MMLBUText1_var1_Property);

		public object MMScrollArea1_GridData => ((CxvViewModel)this).GetValue(MMScrollArea1_GridData_Property);
	}
	[ProgId("MMConSep.MMConSep_Result_LiqPro")]
	public class MMConSep_Result_LiqPro : MMTabPage, IComponentConnector
	{
		internal MMScrollArea MMScrollArea1;

		private bool _contentLoaded;

		public MMConSep_Result_LiqPro()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Result_LiqPro_ViewModel);
			InitializeComponent();
			((FrameworkElement)this).Loaded += MMConSep_Result_LiqPro_Loaded;
		}

		private void MMConSep_Result_LiqPro_Loaded(object sender, RoutedEventArgs e)
		{
			if (Utilities.GetDescendantFromType((DependencyObject)MMScrollArea1, typeof(ScrollViewer), false) is ScrollViewer scrollViewer)
			{
				scrollViewer.VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_result_liqpro.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			if (connectionId == 1)
			{
				MMScrollArea1 = (MMScrollArea)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMConSep_Result_MateriB_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMTextBox39_var1_Property = CxvPropertyDeclaration.Register("MMTextBox39_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.F3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox38_var1_Property = CxvPropertyDeclaration.Register("MMTextBox38_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox37_var1_Property = CxvPropertyDeclaration.Register("MMTextBox37_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_PRES3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox36_var1_Property = CxvPropertyDeclaration.Register("MMTextBox36_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FEED-QUALIT3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox35_var1_Property = CxvPropertyDeclaration.Register("MMTextBox35_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.F2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox34_var1_Property = CxvPropertyDeclaration.Register("MMTextBox34_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox33_var1_Property = CxvPropertyDeclaration.Register("MMTextBox33_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_PRES2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox32_var1_Property = CxvPropertyDeclaration.Register("MMTextBox32_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FEED-QUALIT2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox31_var1_Property = CxvPropertyDeclaration.Register("MMTextBox31_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.F1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox30_var1_Property = CxvPropertyDeclaration.Register("MMTextBox30_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox29_var1_Property = CxvPropertyDeclaration.Register("MMTextBox29_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_PRES1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox28_var1_Property = CxvPropertyDeclaration.Register("MMTextBox28_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FEED-QUALIT1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox27_var1_Property = CxvPropertyDeclaration.Register("MMTextBox27_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.SEPN_RECOV3.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox26_var1_Property = CxvPropertyDeclaration.Register("MMTextBox26_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.SEPN_RECOV3.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox25_var1_Property = CxvPropertyDeclaration.Register("MMTextBox25_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.SEPN_RECOV3.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox24_var1_Property = CxvPropertyDeclaration.Register("MMTextBox24_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X3.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox23_var1_Property = CxvPropertyDeclaration.Register("MMTextBox23_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X3.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox22_var1_Property = CxvPropertyDeclaration.Register("MMTextBox22_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X3.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox21_var1_Property = CxvPropertyDeclaration.Register("MMTextBox21_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.STREAMID.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox20_var1_Property = CxvPropertyDeclaration.Register("MMTextBox20_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.SEPN_RECOV2.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox19_var1_Property = CxvPropertyDeclaration.Register("MMTextBox19_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.SEPN_RECOV2.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox18_var1_Property = CxvPropertyDeclaration.Register("MMTextBox18_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.SEPN_RECOV2.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox17_var1_Property = CxvPropertyDeclaration.Register("MMTextBox17_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X2.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox16_var1_Property = CxvPropertyDeclaration.Register("MMTextBox16_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X2.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox15_var1_Property = CxvPropertyDeclaration.Register("MMTextBox15_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X2.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox14_var1_Property = CxvPropertyDeclaration.Register("MMTextBox14_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.STREAMID.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox13_var1_Property = CxvPropertyDeclaration.Register("MMTextBox13_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.SEPN_RECOV1.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox12_var1_Property = CxvPropertyDeclaration.Register("MMTextBox12_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.SEPN_RECOV1.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox11_var1_Property = CxvPropertyDeclaration.Register("MMTextBox11_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.SEPN_RECOV1.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox10_var1_Property = CxvPropertyDeclaration.Register("MMTextBox10_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X1.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X1.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X1.1"
		});

		public static readonly CxvPropertyDeclaration MMLBUText3_var1_Property = CxvPropertyDeclaration.Register("MMLBUText3_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.F1"
		});

		public static readonly CxvPropertyDeclaration MMLBUText2_var1_Property = CxvPropertyDeclaration.Register("MMLBUText2_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP1"
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_PRES1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox9_var1_Property = CxvPropertyDeclaration.Register("MMTextBox9_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox8_var1_Property = CxvPropertyDeclaration.Register("MMTextBox8_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox7_var1_Property = CxvPropertyDeclaration.Register("MMTextBox7_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox6_var1_Property = CxvPropertyDeclaration.Register("MMTextBox6_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.3"
		});

		public static readonly CxvPropertyDeclaration MMTextBox5_var1_Property = CxvPropertyDeclaration.Register("MMTextBox5_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox4_var1_Property = CxvPropertyDeclaration.Register("MMTextBox4_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMConSep_Result_MateriB_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.STREAMID.1"
		});

		public object MMTextBox39_var1 => ((CxvViewModel)this).GetValue(MMTextBox39_var1_Property);

		public object MMTextBox38_var1 => ((CxvViewModel)this).GetValue(MMTextBox38_var1_Property);

		public object MMTextBox37_var1 => ((CxvViewModel)this).GetValue(MMTextBox37_var1_Property);

		public object MMTextBox36_var1 => ((CxvViewModel)this).GetValue(MMTextBox36_var1_Property);

		public object MMTextBox35_var1 => ((CxvViewModel)this).GetValue(MMTextBox35_var1_Property);

		public object MMTextBox34_var1 => ((CxvViewModel)this).GetValue(MMTextBox34_var1_Property);

		public object MMTextBox33_var1 => ((CxvViewModel)this).GetValue(MMTextBox33_var1_Property);

		public object MMTextBox32_var1 => ((CxvViewModel)this).GetValue(MMTextBox32_var1_Property);

		public object MMTextBox31_var1 => ((CxvViewModel)this).GetValue(MMTextBox31_var1_Property);

		public object MMTextBox30_var1 => ((CxvViewModel)this).GetValue(MMTextBox30_var1_Property);

		public object MMTextBox29_var1 => ((CxvViewModel)this).GetValue(MMTextBox29_var1_Property);

		public object MMTextBox28_var1 => ((CxvViewModel)this).GetValue(MMTextBox28_var1_Property);

		public object MMTextBox27_var1 => ((CxvViewModel)this).GetValue(MMTextBox27_var1_Property);

		public object MMTextBox26_var1 => ((CxvViewModel)this).GetValue(MMTextBox26_var1_Property);

		public object MMTextBox25_var1 => ((CxvViewModel)this).GetValue(MMTextBox25_var1_Property);

		public object MMTextBox24_var1 => ((CxvViewModel)this).GetValue(MMTextBox24_var1_Property);

		public object MMTextBox23_var1 => ((CxvViewModel)this).GetValue(MMTextBox23_var1_Property);

		public object MMTextBox22_var1 => ((CxvViewModel)this).GetValue(MMTextBox22_var1_Property);

		public object MMTextBox21_var1 => ((CxvViewModel)this).GetValue(MMTextBox21_var1_Property);

		public object MMTextBox20_var1 => ((CxvViewModel)this).GetValue(MMTextBox20_var1_Property);

		public object MMTextBox19_var1 => ((CxvViewModel)this).GetValue(MMTextBox19_var1_Property);

		public object MMTextBox18_var1 => ((CxvViewModel)this).GetValue(MMTextBox18_var1_Property);

		public object MMTextBox17_var1 => ((CxvViewModel)this).GetValue(MMTextBox17_var1_Property);

		public object MMTextBox16_var1 => ((CxvViewModel)this).GetValue(MMTextBox16_var1_Property);

		public object MMTextBox15_var1 => ((CxvViewModel)this).GetValue(MMTextBox15_var1_Property);

		public object MMTextBox14_var1 => ((CxvViewModel)this).GetValue(MMTextBox14_var1_Property);

		public object MMTextBox13_var1 => ((CxvViewModel)this).GetValue(MMTextBox13_var1_Property);

		public object MMTextBox12_var1 => ((CxvViewModel)this).GetValue(MMTextBox12_var1_Property);

		public object MMTextBox11_var1 => ((CxvViewModel)this).GetValue(MMTextBox11_var1_Property);

		public object MMTextBox10_var1 => ((CxvViewModel)this).GetValue(MMTextBox10_var1_Property);

		public object MMTextBox3_var1 => ((CxvViewModel)this).GetValue(MMTextBox3_var1_Property);

		public object MMTextBox2_var1 => ((CxvViewModel)this).GetValue(MMTextBox2_var1_Property);

		public object MMLBUText3_var1 => ((CxvViewModel)this).GetValue(MMLBUText3_var1_Property);

		public object MMLBUText2_var1 => ((CxvViewModel)this).GetValue(MMLBUText2_var1_Property);

		public object MMLBUText1_var1 => ((CxvViewModel)this).GetValue(MMLBUText1_var1_Property);

		public object MMTextBox9_var1 => ((CxvViewModel)this).GetValue(MMTextBox9_var1_Property);

		public object MMTextBox8_var1 => ((CxvViewModel)this).GetValue(MMTextBox8_var1_Property);

		public object MMTextBox7_var1 => ((CxvViewModel)this).GetValue(MMTextBox7_var1_Property);

		public object MMTextBox6_var1 => ((CxvViewModel)this).GetValue(MMTextBox6_var1_Property);

		public object MMTextBox5_var1 => ((CxvViewModel)this).GetValue(MMTextBox5_var1_Property);

		public object MMTextBox4_var1 => ((CxvViewModel)this).GetValue(MMTextBox4_var1_Property);

		public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);

		protected override void OnSubPropertyDataChanged(CxvPropertyDeclaration pd, string subPropertyName)
		{
			if (pd.Name == "MMLBUText1_var1" && subPropertyName == "Units")
			{
				object obj = ((CxvViewModel)this).ResolveViewPropertyPath("MMLBUText1_var1.Units", (CxvPropertyWatch)null);
				((CxvViewModel)this).ResolveUpdateViewPropertyPath("MMTextBox33_var1.Units", obj);
				((CxvViewModel)this).ResolveUpdateViewPropertyPath("MMTextBox37_var1.Units", obj);
			}
			else if (pd.Name == "MMLBUText2_var1" && subPropertyName == "Units")
			{
				object obj2 = ((CxvViewModel)this).ResolveViewPropertyPath("MMLBUText2_var1.Units", (CxvPropertyWatch)null);
				((CxvViewModel)this).ResolveUpdateViewPropertyPath("MMTextBox34_var1.Units", obj2);
				((CxvViewModel)this).ResolveUpdateViewPropertyPath("MMTextBox38_var1.Units", obj2);
			}
			else if (pd.Name == "MMLBUText3_var1" && subPropertyName == "Units")
			{
				object obj3 = ((CxvViewModel)this).ResolveViewPropertyPath("MMLBUText3_var1.Units", (CxvPropertyWatch)null);
				((CxvViewModel)this).ResolveUpdateViewPropertyPath("MMTextBox35_var1.Units", obj3);
				((CxvViewModel)this).ResolveUpdateViewPropertyPath("MMTextBox39_var1.Units", obj3);
			}
			base.OnSubPropertyDataChanged(pd, subPropertyName);
		}
	}
	[ProgId("MMConSep.MMConSep_Result_MateriB")]
	public class MMConSep_Result_MateriB : MMTabPage, IComponentConnector
	{
		internal MMScrollAreaManualLayout MMScrollArea1;

		private bool _contentLoaded;

		public MMConSep_Result_MateriB()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Result_MateriB_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_result_materib.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			if (connectionId == 1)
			{
				MMScrollArea1 = (MMScrollAreaManualLayout)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMConSep_Result_VapPro_ViewModel : MMTabPageViewModel
	{
		public class MMScrollArea1_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox4_var1_Property = CxvPropertyDeclaration.Register("MMTextBox4_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.STAGE_NO3.@x"
			});

			public static readonly CxvPropertyDeclaration MMTextBox5_var1_Property = CxvPropertyDeclaration.Register("MMTextBox5_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.B_TEMP5.@x"
			});

			public static readonly CxvPropertyDeclaration MMTextBox6_var1_Property = CxvPropertyDeclaration.Register("MMTextBox6_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.Y.@x.1"
			});

			public static readonly CxvPropertyDeclaration MMTextBox7_var1_Property = CxvPropertyDeclaration.Register("MMTextBox7_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.Y.@x.2"
			});

			public static readonly CxvPropertyDeclaration MMTextBox8_var1_Property = CxvPropertyDeclaration.Register("MMTextBox8_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.Y.@x.3"
			});

			public object MMTextBox4_var1 => ((CxvViewModel)this).GetValue(MMTextBox4_var1_Property);

			public object MMTextBox5_var1 => ((CxvViewModel)this).GetValue(MMTextBox5_var1_Property);

			public object MMTextBox6_var1 => ((CxvViewModel)this).GetValue(MMTextBox6_var1_Property);

			public object MMTextBox7_var1 => ((CxvViewModel)this).GetValue(MMTextBox7_var1_Property);

			public object MMTextBox8_var1 => ((CxvViewModel)this).GetValue(MMTextBox8_var1_Property);
		}

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMConSep_Result_VapPro_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP5"
		});

		public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMConSep_Result_VapPro_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.1"
		});

		public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(MMConSep_Result_VapPro_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.2"
		});

		public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(MMConSep_Result_VapPro_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMPID.3"
		});

		public static readonly CxvPropertyDeclaration MMScrollArea1_GridData_Property = CxvPropertyDeclaration.Register("MMScrollArea1_GridData", typeof(MMConSep_Result_VapPro_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(MMScrollArea1_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Output.STAGE_NO3",
				UseChildId = true,
				Name = "x"
			}
		});

		public object MMLBUText1_var1 => ((CxvViewModel)this).GetValue(MMLBUText1_var1_Property);

		public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);

		public object MMTextBox2_var1 => ((CxvViewModel)this).GetValue(MMTextBox2_var1_Property);

		public object MMTextBox3_var1 => ((CxvViewModel)this).GetValue(MMTextBox3_var1_Property);

		public object MMScrollArea1_GridData => ((CxvViewModel)this).GetValue(MMScrollArea1_GridData_Property);
	}
	[ProgId("MMConSep.MMConSep_Result_VapPro")]
	public class MMConSep_Result_VapPro : MMTabPage, IComponentConnector
	{
		internal MMScrollArea MMScrollArea1;

		private bool _contentLoaded;

		public MMConSep_Result_VapPro()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMConSep_Result_VapPro_ViewModel);
			InitializeComponent();
			((FrameworkElement)this).Loaded += MMConSep_Result_VapPro_Loaded;
		}

		private void MMConSep_Result_VapPro_Loaded(object sender, RoutedEventArgs e)
		{
			if (Utilities.GetDescendantFromType((DependencyObject)MMScrollArea1, typeof(ScrollViewer), false) is ScrollViewer scrollViewer)
			{
				scrollViewer.VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ConSep;component/mmconsep_result_vappro.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			if (connectionId == 1)
			{
				MMScrollArea1 = (MMScrollArea)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMConSep_BlockO_Simula_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration cboFlashMethod_MultiMap_Property;

		public static readonly CxvPropertyDeclaration chkRestart_var1_Property;

		public static readonly CxvPropertyDeclaration chkBalance_var1_Property;

		private Visibility _chkBalanceVisibility;

		public static readonly CxvPropertyDeclaration MMSpinBox1_var1_Property;

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property;

		public static readonly CxvPropertyDeclaration MMComboBox1_var1_Property;

		public static readonly CxvPropertyDeclaration MMLBUText2_var1_Property;

		public static readonly CxvPropertyDeclaration MMComboBox2_var1_Property;

		public static readonly CxvPropertyDeclaration MMSpinBox3_var1_Property;

		public static readonly CxvPropertyDeclaration MMLBUText4_var1_Property;

		public static readonly CxvPropertyDeclaration lbtuLLEnvTemp_var1_Property;

		public object cboFlashMethod_MultiMap => ((CxvViewModel)this).GetValue(cboFlashMethod_MultiMap_Property);

		public object chkRestart_var1 => ((CxvViewModel)this).GetValue(chkRestart_var1_Property);

		public object chkBalance_var1 => ((CxvViewModel)this).GetValue(chkBalance_var1_Property);

		public Visibility chkBalanceVisibility
		{
			get
			{
				return _chkBalanceVisibility;
			}
			set
			{
				_chkBalanceVisibility = value;
				OnPropertyChanged("chkBalanceVisibility");
			}
		}

		public object MMSpinBox1_var1 => ((CxvViewModel)this).GetValue(MMSpinBox1_var1_Property);

		public object MMLBUText1_var1 => ((CxvViewModel)this).GetValue(MMLBUText1_var1_Property);

		public object MMComboBox1_var1 => ((CxvViewModel)this).GetValue(MMComboBox1_var1_Property);

		public object MMLBUText2_var1 => ((CxvViewModel)this).GetValue(MMLBUText2_var1_Property);

		public object MMComboBox2_var1 => ((CxvViewModel)this).GetValue(MMComboBox2_var1_Property);

		public object MMSpinBox3_var1 => ((CxvViewModel)this).GetValue(MMSpinBox3_var1_Property);

		public object MMLBUText4_var1 => ((CxvViewModel)this).GetValue(MMLBUText4_var1_Property);

		public object lbtuLLEnvTemp_var1 => ((CxvViewModel)this).GetValue(lbtuLLEnvTemp_var1_Property);

		protected override void OnUpdateData()
		{
			base.OnUpdateData();
			if (((CxvViewModel)this).IsInitialUpdate)
			{
				string text = CxsConverter.ValueToString(((CxvViewModel)this).ResolveParameter("Balance_ChkBox"));
				if (string.IsNullOrEmpty(text) || text == "0")
				{
					chkBalanceVisibility = Visibility.Collapsed;
				}
				else
				{
					chkBalanceVisibility = Visibility.Visible;
				}
			}
		}

		public MMConSep_BlockO_Simula_ViewModel()
		{
		}

		static MMConSep_BlockO_Simula_ViewModel()
		{
	cboFlashMethod_MultiMap_Property = CxvPropertyDeclaration.Register("cboFlashMethod_MultiMap", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboFlashMethod_var1",
				DataPath = "@main.Input.FLASH_METHOD"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Inside-Out",
				DisplayResourceKey = "MMConSep_BlockO_Simula_ViewModel__CxvMultiMapOption_Display_Inside_Out",
				Value = "cboFlashMethod_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboFlashMethod_var1",
				Value = "INSIDE-OUT"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Gibbs",
				DisplayResourceKey = "MMConSep_BlockO_Simula_ViewModel__CxvMultiMapOption_Display_Gibbs",
				Value = "cboFlashMethod_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboFlashMethod_var1",
				Value = "GIBBS"
			} }
				}, new CxvMultiMapOption
			{
				Display = "User",
				DisplayResourceKey = "MMSetup_Stratt_Subatt_ViewModel__CxvMultiMapOption_Diaplay_User",
				Value = "cboFlashMethod_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboFlashMethod_var1",
				Value = "USER"
			} }
				} }
});
	chkRestart_var1_Property = CxvPropertyDeclaration.Register("chkRestart_var1", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
			{
				DataPath = "@main.Input.RESTART",
				TrueValue = "NO",
				FalseValue = "YES"
			});
	chkBalance_var1_Property = CxvPropertyDeclaration.Register("chkBalance_var1", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
			{
				DataPath = "@main.Input.ENERGY_BAL",
				TrueValue = "YES",
				FalseValue = "NO"
			});
	MMSpinBox1_var1_Property = CxvPropertyDeclaration.Register("MMSpinBox1_var1", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.FLASH_MAXIT"
			});
	MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.FLASHTOL"
			});
	MMComboBox1_var1_Property = CxvPropertyDeclaration.Register("MMComboBox1_var1", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.CURVEALG",
				DisplayedCase = (CxsDisplayedCase)2
			});
	MMLBUText2_var1_Property = CxvPropertyDeclaration.Register("MMLBUText2_var1", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.CURVESTEP"
			});
	MMComboBox2_var1_Property = CxvPropertyDeclaration.Register("MMComboBox2_var1", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.DESIGNALG",
				DisplayedCase = (CxsDisplayedCase)2
			});
	MMSpinBox3_var1_Property = CxvPropertyDeclaration.Register("MMSpinBox3_var1", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.MAXSTAGE"
			});
	MMLBUText4_var1_Property = CxvPropertyDeclaration.Register("MMLBUText4_var1", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.ENVSTEP"
			});
	lbtuLLEnvTemp_var1_Property = CxvPropertyDeclaration.Register("lbtuLLEnvTemp_var1", typeof(MMConSep_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.LLE_TEMP"
			});
	}
	}
}
namespace XamlGeneratedNamespace
{
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class GeneratedInternalTypeHelper : InternalTypeHelper
	{
		protected override object CreateInstance(Type type, CultureInfo culture)
		{
			return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.CreateInstance, null, null, culture);
		}

		protected override object GetPropertyValue(PropertyInfo propertyInfo, object target, CultureInfo culture)
		{
			return propertyInfo.GetValue(target, BindingFlags.Default, null, null, culture);
		}

		protected override void SetPropertyValue(PropertyInfo propertyInfo, object target, object value, CultureInfo culture)
		{
			propertyInfo.SetValue(target, value, BindingFlags.Default, null, null, culture);
		}

		protected override Delegate CreateDelegate(Type delegateType, object target, string handler)
		{
			return (Delegate)target.GetType().InvokeMember("_CreateDelegate", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, target, new object[2] { delegateType, handler }, null);
		}

		protected override void AddEventHandler(EventInfo eventInfo, object target, Delegate handler)
		{
			eventInfo.AddEventHandler(target, handler);
		}
	}
}
