# AssemblyInfo.cs

Source: editable/Properties/AssemblyInfo.cs

Source SHA-256: e97b9a7f06d0b42d0fbdc25dbd5cb3fc0018244fa38fa54dcb4c2530b52b374a
