using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("WpfPLConsep")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("WpfPLConsep")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2012 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: Guid("b66741ca-a35f-4fec-aa40-75e71a9e116c")]
[assembly: AssemblyVersion("41.0.0.614")]
