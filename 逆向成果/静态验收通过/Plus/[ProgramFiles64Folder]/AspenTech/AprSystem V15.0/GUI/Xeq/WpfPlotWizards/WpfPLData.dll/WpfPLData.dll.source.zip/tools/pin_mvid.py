#!/usr/bin/env python3
"""Pin the module MVID (and therefore the whole ilasm image) to a fixed value.

ilasm 4.0.30319 generates a fresh random GUID for the module MVID on every run,
which makes its output non-reproducible byte-for-byte (measured 2026-11-27: two
runs of the identical command differ in exactly the 16 bytes of the #GUID heap
entry and nothing else).  The managed-layout/2 record never uses the candidate
MVID -- it replays the original metadata verbatim -- so the MVID is normalised to
16 zero bytes here to make the compiled candidate a reproducible artifact of the
archived IL source.

Usage: pin_mvid.py <image.dll> [<out.dll>]
"""
import json
import os
import struct
import sys
from hashlib import sha256
from pathlib import Path

import pefile

PINNED = bytes(16)


def main(src, dst=None):
    dst = dst or src
    data = bytearray(Path(src).read_bytes())
    pe = pefile.PE(data=bytes(data), fast_load=True)
    clr = pe.OPTIONAL_HEADER.DATA_DIRECTORY[14]
    clr_off = pe.get_offset_from_rva(clr.VirtualAddress)
    md_rva, md_size = struct.unpack_from("<II", bytes(data), clr_off + 8)
    md_off = pe.get_offset_from_rva(md_rva)
    if data[md_off:md_off + 4] != b"BSJB":
        raise SystemExit("not a metadata root")
    vlen = struct.unpack_from("<I", bytes(data), md_off + 12)[0]
    at = md_off + 16 + vlen
    streams = struct.unpack_from("<H", bytes(data), at + 2)[0]
    at += 4
    guid = None
    for _ in range(streams):
        off, size = struct.unpack_from("<II", bytes(data), at)
        at += 8
        end = data.index(b"\0", at)
        name = bytes(data[at:end]).decode("ascii")
        at = (end + 1 + 3) & ~3
        if name == "#GUID":
            guid = (off, size)
    if guid is None or guid[1] < 16:
        raise SystemExit("no #GUID heap")
    start = md_off + guid[0]
    before = bytes(data[start:start + 16])
    data[start:start + 16] = PINNED
    # ilasm also stamps the COFF time/date and a checksum derived from the random
    # MVID; both are replay-irrelevant (the original PE header is restored) and are
    # normalised so the candidate becomes a reproducible artifact.
    pe_off = struct.unpack_from("<I", bytes(data), 0x3C)[0]
    coff = pe_off + 4
    stamp = bytes(data[coff + 4:coff + 8])
    data[coff + 4:coff + 8] = bytes(4)
    opt = struct.unpack_from("<H", bytes(data), coff + 20)[0]
    opt_off = coff + 20
    checksum = bytes(data[opt_off + 64:opt_off + 68])
    data[opt_off + 64:opt_off + 68] = bytes(4)
    tmp = Path(str(dst) + ".pinned.tmp")
    tmp.write_bytes(bytes(data))
    os.replace(str(tmp), str(dst))
    print(json.dumps({"out": str(dst), "mvid_before": before.hex(), "mvid_after": PINNED.hex(),
                      "coff_timestamp_before": stamp.hex(), "checksum_before": checksum.hex(),
                      "sha256": sha256(bytes(data)).hexdigest()}, ensure_ascii=False))


if __name__ == "__main__":
    main(*sys.argv[1:3])
