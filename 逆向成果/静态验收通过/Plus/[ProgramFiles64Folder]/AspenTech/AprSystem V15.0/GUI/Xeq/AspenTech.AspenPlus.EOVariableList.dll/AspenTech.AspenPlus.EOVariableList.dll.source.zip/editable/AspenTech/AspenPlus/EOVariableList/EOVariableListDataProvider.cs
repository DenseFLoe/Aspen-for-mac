using System;
using System.Collections.Generic;
using System.Linq;
using AspenTech.AspenPlus.MMForms.GridForms.Controls;
using AspenTech.AspenPlus.UnmanagedWrapper;
using AspenTech.Engineering.GridControls;

namespace AspenTech.AspenPlus.EOVariableList;

internal class EOVariableListDataProvider
{
	private class EOVLDataSource : VLDataSource
	{
		private readonly EOVariableListDataProvider _provider;

		public EOVLDataSource(EOVariableListDataProvider provider, VLDataNode rootNode)
			: base(rootNode, provider._columns)
		{
			_provider = provider;
		}

		protected override void OnDataCellValueRequesting(VLDataCellValueRequestingEventArgs e)
		{
			IList<EOVariableCellValue> list = e.Row.Tag as IList<EOVariableCellValue>;
			if (list == null)
			{
				list = _provider._wrapper.GetRecordAt(e.Row.GeneralIndex, e.Row.Header);
			}
			if (list != null)
			{
				int num = base.Columns.ToList().IndexOf(e.Column);
				if (list.Count > num)
				{
					e.Value = CreateCellData(list[num], e.Column, num);
				}
			}
			base.OnDataCellValueRequesting(e);
		}

		private IDataCell CreateCellData(EOVariableCellValue cellValue, VLDataColumn column, int columnIndex)
		{
			if (column.DefaultDataType == typeof(bool) && !(cellValue.Value is bool))
			{
				if (cellValue.Value is int)
				{
					cellValue.Value = (int)cellValue.Value > 0;
				}
				else if (object.Equals(cellValue.Value, "0"))
				{
					cellValue.Value = false;
				}
				else if (object.Equals(cellValue.Value, "1"))
				{
					cellValue.Value = true;
				}
			}
			if (columnIndex == 0)
			{
				return DataRow.CreateDataCell($"(x) {cellValue.Value}", isReadOnly: false, null, CellUIType.Unknown, cellValue);
			}
			return DataRow.CreateDataCell(cellValue.Value, isReadOnly: false, null, CellUIType.Unknown, cellValue);
		}
	}

	private readonly EOVariableListWrapper _wrapper;

	private readonly IEnumerable<VLDataColumn> _columns;

	private readonly IList<VLDataRow> _rows = new List<VLDataRow>();

	public EOVariableListDataProvider(EOVariableListWrapper wrapper, IEnumerable<VLDataColumn> columns)
	{
		if (wrapper == null)
		{
			throw new ArgumentNullException("wrapper");
		}
		if (columns == null)
		{
			throw new ArgumentNullException("columns");
		}
		_wrapper = wrapper;
		_columns = columns;
	}

	public VLDataSource CreateDataSource()
	{
		EnsureData();
		string initialPath = _wrapper.InitialPath;
		Dictionary<string, VLDataNode> dataDict = new Dictionary<string, VLDataNode>();
		VLDataNode vLDataNode = new VLDataNode
		{
			Header = initialPath
		};
		AppendChildren(vLDataNode, dataDict, initialPath);
		foreach (VLDataRow row in _rows)
		{
			VLDataNode vLDataNode2 = FindVariableNode(row, dataDict, initialPath);
			if (vLDataNode2 != null)
			{
				vLDataNode2.Items.Add(row);
			}
			else
			{
				vLDataNode.Items.Add(row);
			}
		}
		return new EOVLDataSource(this, vLDataNode);
	}

	public void InvalidateData()
	{
		_rows.Clear();
	}

	private VLDataNode FindVariableNode(VLDataRow item, Dictionary<string, VLDataNode> dataDict, string rootPath)
	{
		string text = rootPath + "." + item.Header;
		string text2 = text.Substring(0, text.LastIndexOf('.'));
		while (text2.Contains('.'))
		{
			if (dataDict.ContainsKey(text2))
			{
				return dataDict[text2];
			}
			text2 = text2.Substring(0, text2.LastIndexOf('.'));
		}
		return null;
	}

	private void AppendChildren(VLDataNode data, Dictionary<string, VLDataNode> dataDict, string rootPath)
	{
		dataDict[data.Path] = data;
		string path = ((data.Parent == null) ? null : data.Path.Substring(rootPath.Length + 1));
		foreach (string subDirectory in _wrapper.GetSubDirectories(path))
		{
			VLDataNode vLDataNode = new VLDataNode
			{
				Header = subDirectory
			};
			data.Nodes.Add(vLDataNode);
			AppendChildren(vLDataNode, dataDict, rootPath);
		}
	}

	private void EnsureData()
	{
		if (_rows.Count == 0)
		{
			int recordsCount = _wrapper.GetRecordsCount();
			for (int i = 0; i < recordsCount; i++)
			{
				VLDataRow vLDataRow = new VLDataRow(_columns);
				vLDataRow.Header = _wrapper.GetRecordHeaderAt(i);
				vLDataRow.GeneralIndex = i;
				_rows.Add(vLDataRow);
			}
		}
	}

	private static string GetParentScope(string variableName)
	{
		if (!string.IsNullOrWhiteSpace(variableName))
		{
			int num = variableName.LastIndexOf('.');
			if (num > 0)
			{
				return variableName.Substring(0, num);
			}
		}
		return null;
	}

	private static string GetLocalScope(string scope)
	{
		if (!string.IsNullOrWhiteSpace(scope))
		{
			int num = scope.LastIndexOf('.');
			if (num > 0)
			{
				return scope.Substring(num + 1);
			}
			return scope;
		}
		return null;
	}
}
