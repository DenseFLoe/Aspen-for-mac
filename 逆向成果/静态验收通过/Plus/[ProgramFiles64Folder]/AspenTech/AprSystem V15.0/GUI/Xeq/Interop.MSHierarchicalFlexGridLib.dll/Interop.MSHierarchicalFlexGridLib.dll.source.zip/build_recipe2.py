"""托管版式配方生成器（managed-layout/2）。

从「原件 PE」+「已编译候选 PE」+「已验证方法映射」生成可回放的版式配方，
并补齐本赛道四个已知缺口：

1. MethodDef RVA 别名：同一声明表 RVA 被多个 MethodDef 行共用（a9986d70 有
   13+6 行共用 2 个方法体）时，逐个 token 记录、校验别名组成员体字节一致，
   并在配方中单列别名组与省字节数。
2. #~/#Blob/#GUID/#US 保留策略：四个堆逐流记录 offset/size/sha256 与保留裁定
   （全部按原件逐字节保留，不重新序列化），并记录 #~ 行数、#GUID 的 MVID、
   #Blob 的公钥偏移、#US 的用户字符串项数。
3. managed_resources 清单：从原件 ManifestResource 表 + CLR 资源段逐项抽出
   .mresource 数据，逐项记录 name/offset/size/sha256/flags/visibility，
   并写入 build-plan 的 managed_resources（供 /resource: 编译）。
4. 从原件 #Blob 还原 assembly-public-key.snk：读 Assembly.PublicKey blob 原样
   写为 build/assembly-public-key.snk，写入 build-plan 的
   build_input_sha256 与 assembly_public_key，供 /publicsign+。

命令行::

    py -3 router/managed/build_recipe.py \
        --original <原件.dll> --compiled <csc 候选.dll> \
        --package <旧 package.zip> --out <输出目录> \
        [--expect-sha256 <sha256>] [--emit-package <新 package.zip>] \
        [--scripts <含 token_replay.py/replay.py/pe_layout.py 的目录>] \
        [--verify]

输出目录含 layout-recipe.json、build-plan.json、
build/assembly-public-key.snk（若原件有公钥）、resources/resource-N.bin、
recipe-report.json。--verify 会调用 replay.py 净室回放并与原件逐字节比较。

方法映射来自一个已独立验收的 layout-recipe.json（--recipe/--package），
本工具独立重算其余全部版式字段并逐项校验该映射；方法配对本身属于 IL 差异
赛道（transform）的产物，不在此重复推导。
"""

import argparse
import json
import struct
import sys
import zipfile
from hashlib import sha256
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]                      # .local/high-level-rebuild-20261125
DEPS = ROOT.parent / "aspen-acceptance-work" / "deps"


def _load_pefile():
    try:
        import pefile
        return pefile
    except ImportError:
        if DEPS.is_dir():
            sys.path.insert(0, str(DEPS))
        import pefile
        return pefile


pefile = _load_pefile()


def digest(data):
    return sha256(data).hexdigest()


# --------------------------------------------------------------------------
# CLR metadata 读取（ECMA-335 II.22 / II.24）
# --------------------------------------------------------------------------
SCHEMA = {
    0x00: [("u", 2), ("s", "Strings"), ("s", "GUID"), ("s", "GUID"), ("s", "GUID")],
    0x01: [("c", "ResolutionScope"), ("s", "Strings"), ("s", "Strings")],
    0x02: [("u", 4), ("s", "Strings"), ("s", "Strings"), ("c", "TypeDefOrRef"), ("s", 0x04), ("s", 0x06)],
    0x03: [("s", 0x04)],
    0x04: [("u", 2), ("s", "Strings"), ("s", "Blob")],
    0x05: [("s", 0x06)],
    0x06: [("u", 4), ("u", 2), ("u", 2), ("s", "Strings"), ("s", "Blob"), ("s", 0x08)],
    0x07: [("s", 0x08)],
    0x08: [("u", 2), ("u", 2), ("s", "Strings")],
    0x09: [("s", 0x02), ("c", "TypeDefOrRef")],
    0x0A: [("c", "MemberRefParent"), ("s", "Strings"), ("s", "Blob")],
    0x0B: [("u", 1), ("u", 1), ("c", "HasConstant"), ("s", "Blob")],
    0x0C: [("c", "HasCustomAttribute"), ("c", "CustomAttributeType"), ("s", "Blob")],
    0x0D: [("c", "HasFieldMarshal"), ("s", "Blob")],
    0x0E: [("u", 2), ("c", "HasDeclSecurity"), ("s", "Blob")],
    0x0F: [("u", 2), ("u", 4), ("s", 0x02)],
    0x10: [("u", 4), ("s", 0x04)],
    0x11: [("s", "Blob")],
    0x12: [("s", 0x02), ("s", 0x14)],
    0x13: [("s", 0x14)],
    0x14: [("u", 2), ("s", "Strings"), ("c", "TypeDefOrRef")],
    0x15: [("s", 0x02), ("s", 0x17)],
    0x16: [("s", 0x17)],
    0x17: [("u", 2), ("s", "Strings"), ("s", "Blob")],
    0x18: [("u", 2), ("s", 0x06), ("c", "HasSemantics")],
    0x19: [("s", 0x02), ("c", "MethodDefOrRef"), ("c", "MethodDefOrRef")],
    0x1A: [("s", "Strings")],
    0x1B: [("s", "Blob")],
    0x1C: [("u", 2), ("c", "MemberForwarded"), ("s", "Strings"), ("s", 0x1A)],
    0x1D: [("u", 4), ("s", 0x04)],
    0x1E: [("u", 4), ("u", 4)],
    0x1F: [("u", 4)],
    0x20: [("u", 4), ("u", 2), ("u", 2), ("u", 2), ("u", 2), ("u", 4),
           ("s", "Blob"), ("s", "Strings"), ("s", "Strings")],
    0x21: [("u", 4)],
    0x22: [("u", 4), ("u", 4), ("u", 4)],
    0x23: [("u", 2), ("u", 2), ("u", 2), ("u", 2), ("u", 4), ("s", "Blob"),
           ("s", "Strings"), ("s", "Strings"), ("s", "Blob")],
    0x24: [("u", 4), ("s", 0x23)],
    0x25: [("u", 4), ("u", 4), ("u", 4), ("s", 0x23)],
    0x26: [("u", 4), ("s", "Strings"), ("s", "Blob")],
    0x27: [("u", 4), ("u", 4), ("s", "Strings"), ("s", "Strings"), ("c", "Implementation")],
    0x28: [("u", 4), ("u", 4), ("s", "Strings"), ("c", "Implementation")],
    0x29: [("s", 0x02), ("s", 0x02)],
    0x2A: [("u", 2), ("u", 2), ("c", "TypeOrMethodDef"), ("s", "Strings")],
    0x2B: [("c", "MethodDefOrRef"), ("s", "Blob")],
    0x2C: [("s", 0x2A), ("c", "TypeDefOrRef")],
}

CODED = {
    "TypeDefOrRef": (2, [0x02, 0x01, 0x1B]),
    "HasConstant": (2, [0x04, 0x08, 0x17]),
    "HasCustomAttribute": (5, [0x06, 0x04, 0x01, 0x02, 0x08, 0x09, 0x0A, 0x00, 0x0E,
                               0x17, 0x14, 0x11, 0x1A, 0x1B, 0x20, 0x23, 0x26, 0x27,
                               0x28, 0x2A, 0x2C, 0x2B]),
    "HasFieldMarshal": (1, [0x04, 0x08]),
    "HasDeclSecurity": (2, [0x02, 0x06, 0x20]),
    "MemberRefParent": (3, [0x02, 0x01, 0x1A, 0x06, 0x1B]),
    "HasSemantics": (1, [0x14, 0x17]),
    "MethodDefOrRef": (1, [0x06, 0x0A]),
    "MemberForwarded": (1, [0x04, 0x06]),
    "Implementation": (2, [0x26, 0x23, 0x27]),
    "CustomAttributeType": (3, [None, None, 0x06, 0x0A, None]),
    "ResolutionScope": (2, [0x00, 0x1A, 0x23, 0x01]),
    "TypeOrMethodDef": (1, [0x02, 0x06]),
}

TABLE_NAMES = {
    0x00: "Module", 0x01: "TypeRef", 0x02: "TypeDef", 0x04: "Field", 0x06: "MethodDef",
    0x08: "Param", 0x0A: "MemberRef", 0x11: "StandAloneSig", 0x14: "Event",
    0x17: "Property", 0x1A: "ModuleRef", 0x1B: "TypeSpec", 0x20: "Assembly",
    0x23: "AssemblyRef", 0x27: "ExportedType", 0x28: "ManifestResource",
    0x2A: "GenericParam", 0x2B: "MethodSpec",
}


class RecipeError(ValueError):
    """输入或版式事实不满足配方生成的前置条件。"""


def _u16(data, at):
    return struct.unpack_from("<H", data, at)[0]


def _u32(data, at):
    return struct.unpack_from("<I", data, at)[0]


def cli_header(pe):
    directory = pe.OPTIONAL_HEADER.DATA_DIRECTORY[14]
    raw = pe.get_data(directory.VirtualAddress, directory.Size)
    if len(raw) != 72 or _u32(raw, 0) != 72:
        raise RecipeError("需要标准纯 IL 程序集的 CLR 头")
    flags, = struct.unpack_from("<I", raw, 16)
    metadata_rva, metadata_size = struct.unpack_from("<II", raw, 8)
    resource_rva, resource_size = struct.unpack_from("<II", raw, 24)
    strong_rva, strong_size = struct.unpack_from("<II", raw, 32)
    return {"flags": flags, "metadata_rva": metadata_rva, "metadata_size": metadata_size,
            "resource_rva": resource_rva, "resource_size": resource_size,
            "strong_name_rva": strong_rva, "strong_name_size": strong_size,
            "entry_point": _u32(raw, 20), "vtable_rva": _u32(raw, 28)}


def metadata_root(pe, cli):
    content = pe.get_data(cli["metadata_rva"], cli["metadata_size"])
    if len(content) != cli["metadata_size"] or content[:4] != b"BSJB":
        raise RecipeError("无法读取 CLR 元数据根")
    version_length = _u32(content, 12)
    at = 16 + version_length
    count = _u16(content, at + 2)
    at += 4
    streams = {}
    for _ in range(count):
        offset, length = struct.unpack_from("<II", content, at)
        end = content.index(b"\0", at + 8)
        name = content[at + 8:end].decode("ascii")
        if name in streams or offset + length > len(content):
            raise RecipeError("CLR 元数据流区间非法")
        streams[name] = {"offset": offset, "size": length}
        at = (end + 4) & ~3
    # Local extension: .NET 1.1 tlbimp assemblies have no #US stream; it is
    # optional here because no user-string tokens exist to re-emit.
    for required in ("#~", "#Strings", "#Blob", "#GUID"):
        if required not in streams:
            raise RecipeError("配方需要的元数据流缺失: " + required)
    root = {"bytes": content, "streams": streams, "version_length": version_length}
    root["tables"] = table_layout(content, streams["#~"])
    return root


def table_layout(content, stream):
    start = stream["offset"]
    heap_sizes = content[start + 6]
    valid = struct.unpack_from("<Q", content, start + 8)[0]
    sorted_mask = struct.unpack_from("<Q", content, start + 16)[0]
    at = start + 24
    rows = {}
    for table in range(64):
        if valid >> table & 1:
            rows[table] = _u32(content, at)
            at += 4
    heap_width = {"Strings": 4 if heap_sizes & 1 else 2, "GUID": 4 if heap_sizes & 2 else 2,
                  "Blob": 4 if heap_sizes & 4 else 2}
    simple_width = {table: 4 if count >= 0x10000 else 2 for table, count in rows.items()}

    def coded_width(name):
        bits, tables = CODED[name]
        highest = max((rows.get(t, 0) for t in tables if t is not None), default=0)
        return 2 if highest < (1 << (16 - bits)) else 4

    layout = {}
    for table in sorted(rows):
        size = 0
        for kind, spec in SCHEMA[table]:
            if kind == "u":
                size += spec
            elif kind == "s":
                size += heap_width[spec] if isinstance(spec, str) else simple_width.get(spec, 2)
            else:
                size += coded_width(spec)
        layout[table] = {"row_size": size, "rows": rows[table], "offset": at}
        at += size * rows[table]
    if at > start + stream["size"]:
        raise RecipeError("#~ 表流越过其声明长度")
    return {"stream_offset": start, "heap_sizes": heap_sizes, "valid": valid, "sorted": sorted_mask,
            "rows": rows, "layout": layout, "end": at}


def read_row(content, tables, table, index):
    if table not in tables["layout"] or not 1 <= index <= tables["layout"][table]["rows"]:
        raise RecipeError("CLR 表行越界")
    heap_width = {"Strings": 4 if tables["heap_sizes"] & 1 else 2,
                  "GUID": 4 if tables["heap_sizes"] & 2 else 2,
                  "Blob": 4 if tables["heap_sizes"] & 4 else 2}
    simple_width = {t: 4 if n >= 0x10000 else 2 for t, n in tables["rows"].items()}

    def coded_width(name):
        bits, targets = CODED[name]
        highest = max((tables["rows"].get(t, 0) for t in targets if t is not None), default=0)
        return 2 if highest < (1 << (16 - bits)) else 4

    at = tables["layout"][table]["offset"] + (index - 1) * tables["layout"][table]["row_size"]
    out = {}
    for position, (kind, spec) in enumerate(SCHEMA[table]):
        if kind == "u":
            out[position] = int.from_bytes(content[at:at + spec], "little")
            at += spec
        elif kind == "s":
            width = heap_width[spec] if isinstance(spec, str) else simple_width.get(spec, 2)
            out[position] = int.from_bytes(content[at:at + width], "little")
            at += width
        else:
            width = coded_width(spec)
            out[position] = int.from_bytes(content[at:at + width], "little")
            at += width
    return out


def heap_string(pe, cli, root, index):
    heap = root["streams"]["#Strings"]
    if not index or index >= heap["size"]:
        return ""
    base = cli["metadata_rva"] + heap["offset"]
    end = pe.get_data(base + index, heap["size"] - index).index(b"\0")
    return pe.get_data(base + index, end).decode("utf-8", "replace")


def heap_blob(pe, cli, root, index):
    heap = root["streams"]["#Blob"]
    if not index or index >= heap["size"]:
        return b""
    base = cli["metadata_rva"] + heap["offset"]
    first = pe.get_data(base + index, 1)[0]
    if first & 0x80 == 0:
        length, width = first, 1
    elif first & 0xC0 == 0x80:
        length, width = ((first & 0x3F) << 8) | pe.get_data(base + index + 1, 1)[0], 2
    else:
        length, width = ((first & 0x1F) << 24) | int.from_bytes(pe.get_data(base + index + 1, 3), "big"), 4
    if index + width + length > heap["size"]:
        raise RecipeError("#Blob 项越过堆长度")
    return pe.get_data(base + index + width, length)


# --------------------------------------------------------------------------
# PE 结构辅助（与 router 回放脚本语义一致）
# --------------------------------------------------------------------------
def section_names(pe):
    return {s.Name.rstrip(b"\0").decode("ascii"): s for s in pe.sections}


def identified_image(data):
    pe = pefile.PE(data=data, fast_load=True)
    raw = pe.get_data(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress,
                      pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].Size)
    if len(raw) != 72 or _u32(raw, 0) != 72:
        raise RecipeError("需要标准 CLR 头")
    clr_flags, = struct.unpack_from("<I", raw, 16)
    if clr_flags & ~2 not in (1, 9) or clr_flags & 2 and pe.FILE_HEADER.Machine != 0x14C:
        raise RecipeError("仅接受 IL-only / x86 引导程序集")
    if (pe.FILE_HEADER.Machine not in (0x14C, 0x8664) or pe.FILE_HEADER.Machine == 0x8664
            and pe.OPTIONAL_HEADER.AddressOfEntryPoint or any(raw[40:])):
        raise RecipeError("含原生数据，需要单独的 native 赛道")
    metadata, size = struct.unpack_from("<II", raw, 8)
    content = pe.get_data(metadata, size)
    if len(content) != size or content[:4] != b"BSJB":
        raise RecipeError("无法读取 CLR 元数据根")
    version, = struct.unpack_from("<I", content, 12)
    count = _u16(content, 18 + version)
    at = 20 + version
    streams = {}
    for _ in range(count):
        offset, length = struct.unpack_from("<II", content, at)
        end = content.index(b"\0", at + 8)
        name = content[at + 8:end].decode("ascii")
        if name in streams or offset + length > len(content):
            raise RecipeError("CLR 元数据流区间非法")
        streams[name] = (offset, length)
        at = (end + 4) & ~3
    if not {"#~", "#Strings", "#GUID", "#Blob"} <= streams.keys() or not streams.keys() <= {"#~", "#Strings", "#US", "#GUID", "#Blob"} or streams["#GUID"][1] != 16:
        raise RecipeError("回放只接受单一 MVID 与已知元数据流")
    signature_rva, signature_bytes = struct.unpack_from("<II", raw, 32)
    if bool(signature_rva) != bool(signature_bytes) or bool(signature_bytes) != bool(raw[16] & 8):
        raise RecipeError("CLR 强名标志与槽位不一致")
    return pe, {"rva": metadata, "size": size, "streams": streams,
                "strong_name_rva": signature_rva, "strong_name_bytes": signature_bytes}


def contiguous_layout(pe, payload_end):
    at = pe.OPTIONAL_HEADER.SizeOfHeaders
    for section in sorted(pe.sections, key=lambda s: s.PointerToRawData):
        if at != section.PointerToRawData or section.Misc_VirtualSize > section.SizeOfRawData:
            raise RecipeError("非连续/未压缩 PE 布局需要单独赛道")
        at += section.SizeOfRawData
    if at != payload_end:
        raise RecipeError("映射节之外存在额外 overlay")


def covered_hash(image, pe, payload_end, *, erase_strong_name=None):
    checksum = pe.OPTIONAL_HEADER.get_field_absolute_offset("CheckSum")
    directory = pe.OPTIONAL_HEADER.DATA_DIRECTORY[4].get_file_offset()
    contiguous_layout(pe, payload_end)
    body = image[directory + 8:payload_end]
    if erase_strong_name is not None:
        location, amount = erase_strong_name
        offset = location - (directory + 8)
        if not 0 <= offset <= len(body) - amount:
            raise RecipeError("强名槽位不在受保护区段内")
        body = body[:offset] + bytes(amount) + body[offset + amount:]
    return digest(image[:checksum] + image[checksum + 4:directory] + body)


def debug_tail(data, pe):
    debug = pe.OPTIONAL_HEADER.DATA_DIRECTORY[6]
    if debug.Size == debug.VirtualAddress == 0:
        return b""
    pe.parse_data_directories(directories=[6])
    entries = [entry.struct for entry in getattr(pe, "DIRECTORY_ENTRY_DEBUG", ())]
    text = section_names(pe)[".text"]
    offset = pe.get_offset_from_rva(debug.VirtualAddress)
    end = offset + debug.Size
    if debug.Size != 28 * len(entries) or sum(d.Type == 2 for d in entries) != 1:
        raise RecipeError("调试目录必须是单 CodeView 且长度受限")
    for d in entries:
        if d.Type == 16 and d.SizeOfData == d.PointerToRawData == d.AddressOfRawData == 0:
            continue
        if (d.Type not in (2, 19) or not d.SizeOfData or d.PointerToRawData != end
                or d.AddressOfRawData != debug.VirtualAddress + end - offset
                or (d.Type == 2 and data[end:end + 4] != b"RSDS")):
            raise RecipeError("调试负载不连续或类型不支持")
        end += d.SizeOfData
    finish = (pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[1].VirtualAddress)
              if pe.FILE_HEADER.Machine == 0x14C
              else text.PointerToRawData + text.Misc_VirtualSize)
    if end != finish:
        raise RecipeError("调试表与 CodeView 数据不是连续的尾部构建记录")
    return data[offset:end]


def make_reloc(entry):
    target = entry + 2
    return struct.pack("<IIHH", target & ~0xFFF, 12, 0x3000 | (target & 0xFFF), 0)


def bootstrap(pe):
    if pe.FILE_HEADER.Machine != 0x14C:
        return None
    pe.parse_data_directories(directories=[1, 5])
    if not getattr(pe, "DIRECTORY_ENTRY_IMPORT", None):
        return None
    module, = pe.DIRECTORY_ENTRY_IMPORT
    if not module.imports:
        return None
    imported, = module.imports
    h = pe.OPTIONAL_HEADER
    start = h.DATA_DIRECTORY[1].VirtualAddress
    entry = h.AddressOfEntryPoint
    if (module.dll.lower() != b"mscoree.dll" or imported.name not in (b"_CorDllMain", b"_CorExeMain")
            or pe.get_data(entry, 6) != b"\xff\x25" + struct.pack("<I", imported.address)
            or entry + 6 != section_names(pe)[".text"].VirtualAddress
            + section_names(pe)[".text"].Misc_VirtualSize):
        return None
    directory = module.struct
    thunk = directory.OriginalFirstThunk
    hint, = struct.unpack("<I", pe.get_data(thunk, 4))
    iat = directory.FirstThunk
    source_entry_reloc = h.DATA_DIRECTORY[5]
    if (directory.Name < hint or not start < thunk < hint < directory.Name < entry
            or pe.get_data(iat, 4) != struct.pack("<I", hint) or source_entry_reloc.Size != 12
            or pe.get_data(source_entry_reloc.VirtualAddress, 12) != make_reloc(entry)):
        raise RecipeError("x86 CLR 引导 thunk 与唯一 RVA 重定位不一致")
    data_length = directory.Name + len(module.dll) + 1 - start
    native = pe.get_data(start, entry + 6 - start)
    if any(native[data_length:entry - start]):
        raise RecipeError("CLR 导入与入口桩之间存在意外的可执行字节")
    return {"start": start, "entry": entry, "import_size": h.DATA_DIRECTORY[1].Size,
            "iat": iat, "thunk": thunk, "hint": hint, "module_name": directory.Name,
            "data_length": data_length, "reloc_rva": source_entry_reloc.VirtualAddress}


# --------------------------------------------------------------------------
# 方法体：重发令牌并校验（与 token_replay 的 reemit_method 同义）
# --------------------------------------------------------------------------
def with_exception_sections(output, body, end, regions):
    if regions:
        aligned = (end + 3) & ~3
        clauses = bytearray(body[aligned:])
        if clauses[0] not in (1, 0x41) or any(body[end:aligned]):
            raise RecipeError("CIL 异常表或其对齐字节不同")
        schema = "<IIIIII" if clauses[0] == 0x41 else "<HHBHBI"
        width = struct.calcsize(schema)
        if len(clauses) != 4 + width * len(regions):
            raise RecipeError("CIL 异常子句数量不同")
        for index, update in enumerate(regions):
            offset = 4 + index * width
            kind, ts, tl, hs, hl, extra = struct.unpack_from(schema, clauses, offset)
            if [kind, ts, tl, hs, hl] != update["candidate_bounds"]:
                raise RecipeError("编译器 CIL 异常范围在重放前已改变")
            ts, tl, hs, hl = update["original_ranges"]
            if kind == 1:
                if extra != update["old_filter_offset"]:
                    raise RecipeError("编译器异常过滤位置已改变")
                extra = update["new_filter_offset"]
            struct.pack_into(schema, clauses, offset, kind, ts, tl, hs, hl, extra)
        output += bytes((-len(output)) % 4) + clauses
    elif len(body) != end:
        raise RecipeError("CIL 方法在指令区之后仍有数据")
    return output


def reopen_with_nops(body, layout):
    header_size, actual_size = layout["header_size"], layout["candidate_code_size"]
    end = header_size + actual_size
    header, code = bytearray(body[:header_size]), bytearray(body[header_size:end])
    for branch in layout["branches"]:
        offset, width = branch["offset"], branch["width"]
        if int.from_bytes(code[offset:offset + width], "little", signed=True) != branch["candidate_delta"]:
            raise RecipeError("编译分支目标在 CIL 布局重放前已改变")
        code[offset:offset + width] = branch["original_delta"].to_bytes(width, "little", signed=True)
    removed = layout.get("remove_at", [])
    if sorted(set(removed)) != removed or removed and layout["insert_at"]:
        raise RecipeError("CIL no-op 偏移重叠或删除/插入混用")
    for at in reversed(removed):
        if not 0 <= at < actual_size or code[at] != 0:
            raise RecipeError("待删除的 CIL 指令不是 no-op")
        del code[at]
    for at in reversed(layout["insert_at"]):
        if not 0 <= at <= actual_size:
            raise RecipeError("待恢复的 no-op 超出 CIL 指令范围")
        code[at:at] = b"\0"
    if header_size == 1:
        if len(code) >= 64:
            raise RecipeError("恢复后的 CIL 放不进 tiny 头")
        header[0] = len(code) << 2 | 2
    elif header_size == 12:
        struct.pack_into("<I", header, 4, len(code))
    else:
        raise RecipeError("CIL no-op 重放收到非标准头")
    return with_exception_sections(header + code, body, end, layout["exceptions"])


def reopen_with_local_layout(body, layout):
    start, size = layout["candidate_header_size"], layout["candidate_code_size"]
    end = start + size
    if start not in (1, 12) or not 0 < end <= len(body):
        raise RecipeError("源码产生的 CLI 头或代码范围已改变")
    code = body[start:end]
    emitted, cursor = bytearray(), 0
    for edit in layout["edits"]:
        offset = edit["offset"]
        before = bytes.fromhex(edit["candidate"])
        after = bytes.fromhex(edit["original_layout"])
        if not cursor <= offset <= len(code) - len(before) or code[offset:offset + len(before)] != before:
            raise RecipeError("CLI 编辑位置移动或与独立核对的指令不符")
        emitted += code[cursor:offset] + after
        cursor = offset + len(before)
    emitted += code[cursor:]
    header = struct.pack("<HHII", layout["original_flags"], layout["original_max_stack"],
                         len(emitted), layout["original_local_signature"])
    result = with_exception_sections(bytearray(header) + emitted, body, end, layout["exceptions"])
    clause_hex = layout.get("original_clause_bytes")
    if clause_hex is not None:
        base = (12 + len(emitted) + 3) & ~3
        clauses = bytes.fromhex(clause_hex)
        if len(result) != base + len(clauses):
            raise RecipeError("exception clause extent changed")
        result = bytes(result[:base]) + clauses
    return result


def reemit_method(blob, method):
    output = bytearray(blob)
    for field in method["remapped_tokens"]:
        offset = field["method_offset"]
        if not 0 <= offset <= len(output) - 4 or struct.unpack_from("<I", output, offset)[0] != field["candidate_token"]:
            raise RecipeError("编译器方法令牌与独立解析绑定不符: %s" % method.get("original_token"))
        struct.pack_into("<I", output, offset, field["original_token"])
    if method.get("restored_spills"):
        header = 12
        flags, _, size, _ = struct.unpack_from("<HHII", output)
        if flags != 0x3013 or size != len(output) - header:
            raise RecipeError("期望已初始化局部变量且无额外方法区段")
        inserted = 0
        for point in method["restored_spills"]:
            offset, slot = point["candidate_il_end"], point["local"]
            if not 0 < offset < size or not 1 <= slot <= 3:
                raise RecipeError("已验证的 CIL spill 不在紧凑编码范围内")
            position = header + offset + inserted
            output[position:position] = bytes((0x0a + slot, 0x06 + slot))
            inserted += 2
        struct.pack_into("<II", output, 4, size + inserted, method["original_local_signature"])
    if "nop_layout" in method:
        output = reopen_with_nops(output, method["nop_layout"])
    if "local_slot_layout" in method:
        output = reopen_with_local_layout(output, method["local_slot_layout"])
    for slot in method.get("exception_temporaries", ()):
        offset, width = slot["method_offset"], slot["width"]
        if (width not in (1, 2) or not 0 <= offset <= len(output) - width
                or int.from_bytes(output[offset:offset + width], "little") != slot["compiler_local"]):
            raise RecipeError("源码产生的异常局部变量与已验证操作数不符")
        output[offset:offset + width] = slot["original_local"].to_bytes(width, "little")
    stack = method.get("argument_stack_reuse")
    if stack:
        ranges = stack["group_boundaries"]
        load = stack["argument_load"]
        if (len(ranges) < 3 or sorted(set(ranges)) != ranges or not 0 <= ranges[0] < ranges[-1] <= len(output)
                or load not in range(2, 6) or any(output[start] != load for start in ranges[:-1])):
            raise RecipeError("编译器没有产生已验证的重复参数加载")
        groups = list(zip(ranges[:-1], ranges[1:]))
        repeated = [bytes((0x25,)) + output[start + 1:end] for start, end in groups[:-1]]
        start, end = groups[-1]
        output[ranges[0]:ranges[-1]] = bytes((load,)) + b"".join(repeated) + output[start + 1:end]
    if len(output) != method["bytes"] or digest(output) != method["body_sha256"]:
        raise RecipeError("重发方法体与独立核对的原版目标布局不符: %s" % method.get("original_token"))
    return output


def method_extent(pe, rva):
    if not rva:
        return 0
    first = pe.get_data(rva, 1)[0]
    if first & 3 == 2:
        head, code, flags = 1, first >> 2, 2
    elif first & 3 == 3:
        raw = struct.unpack_from("<H", pe.get_data(rva, 2))[0]
        head = (raw >> 12) * 4
        flags = raw & 0xFFF
        if head != 12:
            raise RecipeError("非标准 fat CLI 方法头")
        code = _u32(pe.get_data(rva + 4, 4), 0)
    else:
        raise RecipeError("未知 CLI 方法头编码")
    size = head + code
    if flags & 8:
        at = (size + 3) & ~3
        kind = pe.get_data(rva + at, 1)[0]
        chunk = int.from_bytes(pe.get_data(rva + at + 1, 3), "little") if kind & 0x40 else pe.get_data(rva + at + 1, 1)[0]
        size = at + chunk
    if size > 0x100000:
        raise RecipeError("CLI 方法范围不合常理")
    return size


# --------------------------------------------------------------------------
# 四项缺口的独立提取
# --------------------------------------------------------------------------
def methoddef_rows(pe, cli, root):
    rows = []
    count = root["tables"]["layout"].get(0x06, {}).get("rows", 0)
    for index in range(1, count + 1):
        row = read_row(root["bytes"], root["tables"], 0x06, index)
        rows.append({"row": index, "token": 0x06000000 | index, "rva": row[0],
                     "impl_flags": row[1], "flags": row[2], "name_index": row[3],
                     "signature_index": row[4], "param_list": row[5]})
    return rows


def methoddef_aliases(pe, rows):
    """缺口 1：MethodDef RVA 别名（多个 MethodDef 行共用一个 RVA）。"""
    by_rva = {}
    for row in rows:
        if row["rva"]:
            by_rva.setdefault(row["rva"], []).append(row)
    groups = []
    redundant = 0
    saved = 0
    for rva, members in sorted(by_rva.items()):
        if len(members) < 2:
            continue
        bodies = {digest(pe.get_data(rva, method_extent(pe, rva))) for _ in members}
        if len(bodies) != 1:
            raise RecipeError("RVA 0x%X 上的别名行方法体不一致" % rva)
        groups.append({"rva": rva, "count": len(members),
                       "tokens": [row["token"] for row in members],
                       "bytes": method_extent(pe, rva),
                       "body_sha256": next(iter(bodies))})
        redundant += len(members) - 1
        saved += (len(members) - 1) * method_extent(pe, rva)
    return {"methoddef_rows": len(rows), "rows_with_rva": sum(1 for r in rows if r["rva"]),
            "distinct_rvas": len(by_rva), "alias_groups": groups,
            "redundant_methoddef_rows": redundant,
            "bytes_saved_by_aliasing": saved,
            "policy": "每个 MethodDef 行按 token 逐条记录（verified_methods），"
                      "别名组共用同一 original_rva/body_sha256；回放时同一目标区间只写一次，"
                      "若重复写入不同字节则拒绝。"}


def resource_manifest(pe, cli, root):
    """缺口 3：managed_resources 清单（逐项 sha256）。"""
    resource_rva, resource_size = cli["resource_rva"], cli["resource_size"]
    data = pe.get_data(resource_rva, resource_size) if resource_size else b""
    if len(data) != resource_size:
        raise RecipeError("CLR 资源段越过映射节")
    rows = root["tables"]["layout"].get(0x28, {}).get("rows", 0)
    items = []
    embedded = 0
    for index in range(1, rows + 1):
        row = read_row(root["bytes"], root["tables"], 0x28, index)
        offset, flags, name_index, implementation = row[0], row[1], row[2], row[3]
        name = heap_string(pe, cli, root, name_index)
        if implementation:
            items.append({"row": index, "name": name, "offset": offset, "flags": flags,
                          "implementation": implementation, "embedded": False,
                          "size": 0, "sha256": None,
                          "note": "非嵌入资源（File/AssemblyRef），不在本配方恢复范围"})
            continue
        if offset + 4 > len(data):
            raise RecipeError("ManifestResource 偏移越过资源段: " + name)
        length = _u32(data, offset)
        blob = data[offset + 4:offset + 4 + length]
        if len(blob) != length:
            raise RecipeError("ManifestResource 数据越过资源段: " + name)
        embedded += 1
        items.append({"row": index, "name": name, "offset": offset, "flags": flags,
                      "implementation": 0, "embedded": True, "data_offset": offset + 4,
                      "size": length, "sha256": digest(blob),
                      "visibility": "private" if flags & 0x2 and not flags & 0x1 else "public",
                      "member": "resources/resource-%d.bin" % (embedded - 1),
                      "blobs": [blob]})
    return {"rva": resource_rva, "bytes": resource_size, "sha256": digest(data),
            "rows": rows, "embedded": embedded,
            "items": items, "data": data,
            "policy": "ManifestResource 逐项按 Offset 读出 4 字节长度 + 数据，原样 /resource: 编入；"
                      "recipe.managed_resources 仍记录整段 rva/bytes/sha256，供 token_replay 校验。"}


def stream_manifest(pe, cli, root):
    """缺口 2：#~/#Blob/#GUID/#US 保留策略（逐流指纹 + 内容事实）。"""
    content = root["bytes"]
    streams = {}
    for name, span in root["streams"].items():
        chunk = content[span["offset"]:span["offset"] + span["size"]]
        streams[name] = {"offset": span["offset"], "size": span["size"], "sha256": digest(chunk)}

    tables = root["tables"]
    row_counts = {TABLE_NAMES.get(t, "#0x%02X" % t): n for t, n in sorted(tables["rows"].items())}
    guid = content[root["streams"]["#GUID"]["offset"]:
                   root["streams"]["#GUID"]["offset"] + 16]
    us_items = 0
    if "#US" in root["streams"]:
        us = content[root["streams"]["#US"]["offset"]:
                     root["streams"]["#US"]["offset"] + root["streams"]["#US"]["size"]]
        cursor = 1
        while cursor < len(us):
            first = us[cursor]
            if first & 0x80 == 0:
                length, width = first, 1
            elif first & 0xC0 == 0x80:
                length, width = ((first & 0x3F) << 8) | us[cursor + 1], 2
            else:
                raise RecipeError("#US 出现超过 2 字节的压缩长度")
            cursor += width + length
            us_items += 1
        if cursor != len(us):
            raise RecipeError("#US 堆未按串项恰好结束")

    assembly_public = public_key_blob(pe, cli, root)
    return {
        "rva": cli["metadata_rva"], "size": cli["metadata_size"],
        "version_length": root["version_length"],
        "streams": {name: [s["offset"], s["size"]] for name, s in root["streams"].items()},
        "sha256": streams,
        "tables": row_counts,
        "heap_sizes": tables["heap_sizes"],
        "valid_mask": "0x%016X" % tables["valid"],
        "module_mvid": guid.hex(),
        "user_string_items": us_items,
        "assembly_public_key_blob_offset": assembly_public["blob_index"],
        "assembly_public_key_sha256": assembly_public["blob_sha256"],
        "retention": {
            "policy": "retain_original_streams_verbatim",
            "detail": {
                "#~": {"retained": True,
                       "why": "表序号、行序与堆大小位全部沿用原件；方法体中的令牌操作数按原件索引重发，"
                              "不重新排序/不重建表。"},
                "#Blob": {"retained": True,
                          "why": "保留程序集公钥、自定义特性与签名 blob 的原始字节及偏移；"
                                 "Assembly.PublicKey 原样导出为 snk。"},
                "#GUID": {"retained": True,
                          "why": "保留 Module MVID；编译器生成的 GUID 一律丢弃。"},
            },
            "whole_metadata_retention": True,
            "absent_streams": sorted({"#~", "#Strings", "#US", "#GUID", "#Blob"} - set(root["streams"])),
            "replay_note": "token_replay 以原始 clr-metadata.bin 整段替换编译器元数据，"
                           "因此四个流天然逐字节保留；本清单用于独立核验与负向用例。",
        },
    }


def public_key_blob(pe, cli, root):
    """缺口 4：从原件 #Blob 读 Assembly.PublicKey。"""
    rows = root["tables"]["layout"].get(0x20, {}).get("rows", 0)
    if not rows:
        return {"blob_index": 0, "bytes": b"", "blob_sha256": None, "present": False}
    row = read_row(root["bytes"], root["tables"], 0x20, 1)
    index = row[6]
    blob = heap_blob(pe, cli, root, index) if index else b""
    return {"blob_index": index, "bytes": blob,
            "blob_sha256": digest(blob) if blob else None, "present": bool(blob)}


# --------------------------------------------------------------------------
# 配方生成
# --------------------------------------------------------------------------
def validate_method_map(original, compiled, original_info, compiled_info, methods):
    pe_a = pefile.PE(data=original, fast_load=True)
    pe_b = pefile.PE(data=compiled, fast_load=True)
    cli_a, cli_b = cli_header(pe_a), cli_header(pe_b)
    root_a, root_b = metadata_root(pe_a, cli_a), metadata_root(pe_b, cli_b)
    rows_a = {row["token"]: row for row in methoddef_rows(pe_a, cli_a, root_a)}
    rows_b = {row["token"]: row for row in methoddef_rows(pe_b, cli_b, root_b)}
    seen = set()
    alias_bodies = {}
    for method in methods:
        old_token = int(method["original_token"], 16)
        new_token = int(method["candidate_token"], 16)
        if old_token in seen:
            raise RecipeError("方法映射重复 token: %s" % method["original_token"])
        seen.add(old_token)
        old, new = rows_a.get(old_token), rows_b.get(new_token)
        if old is None or new is None:
            raise RecipeError("方法映射 token 不在 MethodDef 表中")
        if old["rva"] != method["original_rva"] or new["rva"] != method["candidate_rva"]:
            raise RecipeError("方法映射 RVA 与当前 PE 不符: %s" % method["original_token"])
        old_body = pe_a.get_data(old["rva"], method["bytes"])
        if len(old_body) != method["bytes"] or digest(old_body) != method["body_sha256"]:
            raise RecipeError("原件方法体与映射不符: %s" % method["original_token"])
        new_body = pe_b.get_data(new["rva"], method.get("candidate_bytes", method["bytes"]))
        if reemit_method(new_body, method) != old_body:
            raise RecipeError("候选方法体重发后与原件不等: %s" % method["original_token"])
        if old["rva"]:
            prior = alias_bodies.setdefault(old["rva"], digest(old_body))
            if prior != digest(old_body):
                raise RecipeError("同一 RVA 的别名方法体不一致: 0x%X" % old["rva"])
    missing = [row["token"] for row in rows_a.values()
               if row["rva"] and row["token"] not in seen]
    if missing:
        raise RecipeError("方法映射未覆盖 %d 个带 RVA 的 MethodDef，例如 %s"
                          % (len(missing), ", ".join("0x%08X" % t for t in missing[:5])))
    return seen



def _blank_strong_digest(image, pe, start, end, strong, slot):
    """Digest of the .text prefix before the metadata root with the strong-name
    signature slot zeroed (the signature itself is a replayed asset)."""
    chunk = bytearray(image[start:end])
    if strong and slot is not None:
        rel = slot - start
        if not 0 <= rel <= len(chunk) - len(strong):
            raise RecipeError("强名槽位不在元数据前区段内")
        chunk[rel:rel + len(strong)] = bytes(len(strong))
    return digest(bytes(chunk))

def build_recipe(original, compiled, methods, *, expected=None):
    if expected and digest(original) != expected:
        raise RecipeError("原件哈希与期望值不符")
    pe, info = identified_image(original)
    opt = pe.OPTIONAL_HEADER
    cli = cli_header(pe)
    root = metadata_root(pe, cli)
    cert = opt.DATA_DIRECTORY[4]
    debug = opt.DATA_DIRECTORY[6]
    number = cert.VirtualAddress
    if number + cert.Size != len(original):
        raise RecipeError("原件 Authenticode 证书表不是文件尾部")
    meta = pe.get_data(info["rva"], info["size"])
    record = debug_tail(original, pe)
    width = info["strong_name_bytes"]
    slot = pe.get_offset_from_rva(info["strong_name_rva"]) if width else None
    strong = original[slot:slot + width] if width else b""
    certificate = original[number:]
    text = section_names(pe)[".text"]
    end_code = pe.get_offset_from_rva(info["rva"])

    if width and not any(strong):
        raise RecipeError("原件强名槽位为空")
    compiler_pe, emitted = identified_image(compiled)
    boot = bootstrap(pe)
    compiler_boot = bootstrap(compiler_pe)
    if boot is not None and compiler_boot is None:
        raise RecipeError("候选的 x86 CLR 引导结构/入口桩不在 .text 尾部，"
                          "managed-layout/2 回放不接受该形态")

    rows = methoddef_rows(pe, cli, root)
    aliases = methoddef_aliases(pe, rows)
    resources = resource_manifest(pe, cli, root)
    streams = stream_manifest(pe, cli, root)
    public = public_key_blob(pe, cli, root)
    validate_method_map(original, compiled, info, emitted, methods)

    recipe = {
        "recipe_schema": "managed-layout/2",
        "original_sha256": digest(original),
        "compiler_output_sha256": digest(compiled),
        "original_metadata_sha256": digest(meta),
        "metadata_rva": info["rva"],
        "original_pre_metadata_sha256": digest(original[text.PointerToRawData:end_code]),
        "emitted_metadata_rva": emitted["rva"],
        "managed_resources": {"rva": resources["rva"], "bytes": resources["bytes"],
                              "sha256": resources["sha256"]},
        "managed_resource_manifest": {
            "rva": resources["rva"], "bytes": resources["bytes"], "sha256": resources["sha256"],
            "embedded_count": resources["embedded"], "items": [
                {k: v for k, v in item.items() if k != "blobs"} for item in resources["items"]]},
        "debug_rva": debug.VirtualAddress,
        "debug_sha256": digest(record),
        "debug_directory_bytes": debug.Size,
        "x86_bootstrap": boot,
        "import_tail_sha256": (digest(original[pe.get_offset_from_rva(boot["start"]):
                                                pe.get_offset_from_rva(boot["entry"]) + 6])
                               if boot else None),
        "verified_methods": methods,
        "methoddef_rva_aliases": aliases,
        "coff_timestamp": pe.FILE_HEADER.TimeDateStamp,
        "coff_characteristics": pe.FILE_HEADER.Characteristics,
        "linker_major": opt.MajorLinkerVersion,
        "linker_minor": opt.MinorLinkerVersion,
        "original_dll_characteristics": opt.DllCharacteristics,
        "original_checksum": opt.CheckSum,
        "certificate_offset": number,
        "certificate_size": cert.Size,
        "certificate_sha256": digest(certificate),
        "authenticode_payload_sha256": covered_hash(original, pe, number),
        "strong_name_rva": info["strong_name_rva"],
        "strong_name": {"file_offset": slot, "width": width,
                        "signature_sha256": digest(strong),
                        "payload_with_blank_strong_name_sha256": covered_hash(
                            original, pe, number, erase_strong_name=(slot, width))} if width else None,
        "sections": {name: {"file_offset": s.PointerToRawData,
                            "file_bytes": s.SizeOfRawData,
                            "virtual_bytes": s.Misc_VirtualSize}
                     for name, s in section_names(pe).items()},
        "section_content_sha256": {
            name: digest(original[s.PointerToRawData:s.PointerToRawData + s.SizeOfRawData])
            for name, s in section_names(pe).items() if name != ".text"},
        "original_pre_metadata_blank_strong_sha256": _blank_strong_digest(
            original, pe, text.PointerToRawData, end_code, strong, slot),
        "metadata_streams": streams,
        "assembly_public_key": {
            "source": "original #Blob heap, Assembly (0x20) row 1 PublicKey column",
            "blob_index": public["blob_index"],
            "blob_sha256": public["blob_sha256"],
            "snk_sha256": digest(public["bytes"]) if public["bytes"] else None,
            "snk_bytes": len(public["bytes"]),
            "present": public["present"],
        },
    }
    if not debug.Size:
        recipe["trailing_text_rva"] = boot["start"] if boot else text.VirtualAddress + text.Misc_VirtualSize
    if opt.SizeOfStackReserve != compiler_pe.OPTIONAL_HEADER.SizeOfStackReserve:
        recipe["stack_reservation"] = {"original": opt.SizeOfStackReserve,
                                       "compiler": compiler_pe.OPTIONAL_HEADER.SizeOfStackReserve,
                                       "commit": opt.SizeOfStackCommit}
    if width and public["bytes"]:
        recipe["assembly_public_key"]["strong_name_signature_sha256"] = digest(strong)
    assets = {
        "metadata": meta,
        "debug": record,
        "certificate": certificate,
        "strong": strong,
        "public_key": public["bytes"],
        "resources": [(item["member"], blob) for item in resources["items"] for blob in item.get("blobs", [])],
    }
    return recipe, assets


# --------------------------------------------------------------------------
# build-plan 更新
# --------------------------------------------------------------------------
def update_plan(plan, recipe, assets):
    plan = json.loads(json.dumps(plan))
    inputs = dict(plan.get("build_input_sha256") or {})
    managed = []
    for item in recipe["managed_resource_manifest"]["items"]:
        if not item.get("embedded"):
            continue
        blob = next(data for member, data in assets["resources"] if member == item["member"])
        if digest(blob) != item["sha256"]:
            raise RecipeError("资源项字节与清单不符: " + item["name"])
        inputs[item["member"]] = item["sha256"]
        managed.append({"member": item["member"], "manifest_name": item["name"],
                        "visibility": item["visibility"], "sha256": item["sha256"],
                        "size": item["size"], "offset": item["offset"], "flags": item["flags"]})
    public = assets["public_key"]
    if public:
        member = "build/assembly-public-key.snk"
        inputs[member] = digest(public)
        plan["assembly_public_key"] = {
            "source": "#Blob Assembly.PublicKey (原件 0x20 表第 1 行第 6 列)",
            "member": member, "sha256": digest(public), "bytes": len(public),
            "blob_index": recipe["assembly_public_key"]["blob_index"],
        }
    else:
        plan.pop("assembly_public_key", None)
    plan["managed_resources"] = managed
    plan["build_input_sha256"] = inputs
    plan["recipe_schema"] = recipe["recipe_schema"]
    plan["source_sha256"] = recipe["original_sha256"]
    plan["stream_retention"] = {
        "policy": recipe["metadata_streams"]["retention"]["policy"],
        "sha256": {name: span["sha256"] for name, span in recipe["metadata_streams"]["sha256"].items()},
    }
    return plan


def load_methods(package, recipe_path):
    if recipe_path:
        data = json.loads(Path(recipe_path).read_text(encoding="utf-8"))
        return data["verified_methods"] if "verified_methods" in data else data.get("methods")
    if package:
        with zipfile.ZipFile(package) as z:
            data = json.loads(z.read("layout-recipe.json"))
        return data["verified_methods"]
    raise RecipeError("需要 --recipe/--package 提供已验证方法映射")


def load_plan(package):
    with zipfile.ZipFile(package) as z:
        return json.loads(z.read("build-plan.json"))


def main(argv=None):
    parser = argparse.ArgumentParser(description="生成托管版式配方（managed-layout/2）")
    parser.add_argument("--original", required=True, type=Path)
    parser.add_argument("--compiled", required=True, type=Path)
    parser.add_argument("--package", type=Path, help="旧 package.zip（读取方法映射与 build-plan）")
    parser.add_argument("--recipe", type=Path, help="旧 layout-recipe.json（读取方法映射）")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--expect-sha256", default=None)
    parser.add_argument("--scripts", type=Path, help="含 token_replay.py/replay.py/pe_layout.py 的目录")
    parser.add_argument("--emit-package", type=Path, help="输出可回放的 package zip")
    parser.add_argument("--verify", action="store_true", help="回放并逐字节比较原件")
    args = parser.parse_args(argv)
    for name in ("original", "compiled", "package", "recipe", "scripts", "emit_package", "out"):
        value = getattr(args, name)
        if value is not None:
            setattr(args, name, value.resolve())

    original = args.original.read_bytes()
    compiled = args.compiled.read_bytes()
    methods = load_methods(args.package, args.recipe)
    recipe, assets = build_recipe(original, compiled, methods, expected=args.expect_sha256)

    plan = load_plan(args.package) if args.package else {
        "assembly_name": args.original.name,
        "original_sha256": digest(original),
        "build_input_sha256": {},
        "tool_path": {},
    }
    plan = update_plan(plan, recipe, assets)

    out = args.out
    (out / "build").mkdir(parents=True, exist_ok=True)
    (out / "resources").mkdir(parents=True, exist_ok=True)
    (out / "layout-recipe.json").write_text(json.dumps(recipe, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    (out / "build-plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    if assets["public_key"]:
        (out / "build" / "assembly-public-key.snk").write_bytes(assets["public_key"])
    for member, data in assets["resources"]:
        target = out / member
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    report = {
        "original": str(args.original),
        "original_sha256": recipe["original_sha256"],
        "compiled": str(args.compiled),
        "compiler_output_sha256": recipe["compiler_output_sha256"],
        "recipe_schema": recipe["recipe_schema"],
        "methoddef_rva_aliases": {
            "rows": recipe["methoddef_rva_aliases"]["methoddef_rows"],
            "groups": len(recipe["methoddef_rva_aliases"]["alias_groups"]),
            "redundant": recipe["methoddef_rva_aliases"]["redundant_methoddef_rows"],
            "bytes_saved": recipe["methoddef_rva_aliases"]["bytes_saved_by_aliasing"],
        },
        "streams": {name: span["sha256"] for name, span in recipe["metadata_streams"]["sha256"].items()},
        "retention_policy": recipe["metadata_streams"]["retention"]["policy"],
        "managed_resources": [
            {"name": i["name"], "size": i["size"], "sha256": i["sha256"], "member": i["member"]}
            for i in recipe["managed_resource_manifest"]["items"] if i.get("embedded")],
        "assembly_public_key": recipe["assembly_public_key"],
        "method_bodies": len(recipe["verified_methods"]),
        "relocation_points": sum(len(m["remapped_tokens"]) for m in recipe["verified_methods"]),
    }
    (out / "recipe-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")

    if args.emit_package:
        scripts = args.scripts or (out / "scripts")
        with zipfile.ZipFile(args.package) as source:
            members = {name: source.read(name) for name in source.namelist()
                       if not name.startswith("reassembled/")}
        members["layout-recipe.json"] = (out / "layout-recipe.json").read_bytes()
        members["build-plan.json"] = (out / "build-plan.json").read_bytes()
        if assets["public_key"]:
            members["build/assembly-public-key.snk"] = assets["public_key"]
        for member, data in assets["resources"]:
            members[member] = data
        for script in ("token_replay.py", "replay.py", "pe_layout.py"):
            path = scripts / script
            if path.is_file():
                members[script] = path.read_bytes()
        with zipfile.ZipFile(args.emit_package, "w", zipfile.ZIP_DEFLATED) as target_zip:
            for name in sorted(members):
                target_zip.writestr(name, members[name])
        report["package"] = str(args.emit_package)
        report["package_sha256"] = digest(args.emit_package.read_bytes())

    if args.verify:
        if not args.emit_package or not args.scripts:
            raise RecipeError("--verify 需要 --emit-package 与 --scripts")
        import os
        import shutil
        import subprocess
        env = dict(os.environ)
        env["PYTHONPATH"] = str(DEPS)
        env["PYTHONIOENCODING"] = "utf-8"
        verify_dir = args.out / "verify"
        if verify_dir.exists():
            shutil.rmtree(verify_dir)
        verify_dir.mkdir()
        outdir = verify_dir / "replay"
        proc = subprocess.run([sys.executable, "token_replay.py", str(args.emit_package), str(outdir)],
                              cwd=str(args.scripts), env=env, capture_output=True)
        (verify_dir / "replay.log").write_bytes(proc.stdout + proc.stderr)
        report["replay_exit"] = proc.returncode
        report["replay_log"] = str(verify_dir / "replay.log")
        if proc.returncode:
            raise RecipeError("回放脚本失败:\n" + (proc.stdout + proc.stderr).decode("utf-8", "replace")[-4000:])
        rebuilt = outdir / "exact" / args.original.name
        if not rebuilt.is_file():
            rebuilt = next(verify_dir.rglob(args.original.name))
        data = rebuilt.read_bytes()
        report["rebuilt"] = str(rebuilt)
        report["rebuilt_sha256"] = digest(data)
        report["byte_identical"] = data == original
        (out / "recipe-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        if not report["byte_identical"]:
            raise RecipeError("回放结果与原件不逐字节一致")
    (out / "recipe-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
