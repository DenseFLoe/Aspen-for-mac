param(
    [Parameter(Mandatory=$true)][string]$Baml,
    [Parameter(Mandatory=$true)][string]$Xaml,
    [Parameter(Mandatory=$true)][string[]]$SearchDirectories
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework,System.Xaml
$script:assemblyDirs = $SearchDirectories | ForEach-Object { (Resolve-Path -LiteralPath $_).Path }
$resolver = [System.ResolveEventHandler]{
    param($sender, $eventArgs)
    $name = [Reflection.AssemblyName]::new($eventArgs.Name).Name
    foreach ($dir in $script:assemblyDirs) {
        $path = Join-Path $dir ($name + '.dll')
        if ([IO.File]::Exists($path)) { return [Reflection.Assembly]::LoadFrom($path) }
    }
    return $null
}
[AppDomain]::CurrentDomain.add_AssemblyResolve($resolver)
try {
    $settings = New-Object System.Xaml.XamlReaderSettings
    $flags = [Reflection.BindingFlags]'Public,NonPublic,Instance'
    [System.Xaml.XamlReaderSettings].GetProperty('ValuesMustBeString', $flags).SetValue($settings, $true)
    $settings.LocalAssembly = [Reflection.Assembly]::LoadFrom((Join-Path $script:assemblyDirs[0] 'WpfPLData.dll'))
    $stream = [IO.File]::OpenRead((Resolve-Path -LiteralPath $Baml).Path)
    try {
        $reader = [System.Windows.Baml2006.Baml2006Reader]::new($stream, $settings)
        $xmlSettings = [Xml.XmlWriterSettings]::new()
        $xmlSettings.Indent = $true
        $xmlSettings.Encoding = [Text.UTF8Encoding]::new($false)
        $target = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Xaml)
        $xml = [Xml.XmlWriter]::Create($target, $xmlSettings)
        try {
            $writer = [System.Xaml.XamlXmlWriter]::new($xml, $reader.SchemaContext)
            [System.Xaml.XamlServices]::Transform($reader, $writer)
        } finally {
            $xml.Dispose()
            ([IDisposable]$reader).Dispose()
        }
    } finally {
        $stream.Dispose()
    }
} finally {
    [AppDomain]::CurrentDomain.remove_AssemblyResolve($resolver)
}

