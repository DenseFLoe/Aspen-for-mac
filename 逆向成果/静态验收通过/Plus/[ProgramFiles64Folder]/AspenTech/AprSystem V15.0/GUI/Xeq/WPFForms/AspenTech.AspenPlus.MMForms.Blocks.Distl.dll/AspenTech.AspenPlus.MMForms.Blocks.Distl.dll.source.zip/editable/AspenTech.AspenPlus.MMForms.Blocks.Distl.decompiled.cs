using System;
using System.CodeDom.Compiler;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Markup;
using AspenTech.AspenCxs.CxsViewModel;
using AspenTech.AspenPlus.MMControls;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.MMForms.Blocks.Distl")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.MMForms.Blocks.Distl")]
[assembly: AssemblyCopyright("Copyright © aspentech 2010 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/dddd", "DDDD")]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/distl", "AspenTech.AspenPlus.MMForms.Blocks.Distl")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]

namespace AspenTech.AspenPlus.MMForms.Blocks.Distl
{
	public class MMDistl_Dynam_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration sht0_Property = CxvPropertyDeclaration.Register("sht0", typeof(MMDistl_Dynam_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SHT0"
		});

		public static readonly CxvPropertyDeclaration dyncsh0_Property = CxvPropertyDeclaration.Register("dyncsh0", typeof(MMDistl_Dynam_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.DYNCSH0"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMDistl_Dynam_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@dyncsh0" },
			AccessibleDataPaths = { "@sht0" }
		});

		public object sht0 => ((CxvViewModel)this).GetValue(sht0_Property);

		public object dyncsh0 => ((CxvViewModel)this).GetValue(dyncsh0_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);
	}
	[ProgId("MMDistl.MMDistl_Dynam")]
	public class MMDistl_Dynam : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabDyn;

		internal MMTabItem tab0;

		private bool _contentLoaded;

		public MMDistl_Dynam()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDistl_Dynam_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Distl;component/mmdistl_dynam.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabDyn = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDistl_Dynam_Lump_ViewModel : MMTabPageViewModel
	{
		public class MMScrollArea1_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.LUMP_HOLDUP.@stage"
			});

			public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DYN_LUMP2.@stage"
			});

			public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.DYN_LUMP1.@stage"
			});

			public object MMTextBox3_var1 => ((CxvViewModel)this).GetValue(MMTextBox3_var1_Property);

			public object MMTextBox2_var1 => ((CxvViewModel)this).GetValue(MMTextBox2_var1_Property);

			public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);
		}

		public static readonly CxvPropertyDeclaration MMTextBox5_nlump_Property = CxvPropertyDeclaration.Register("MMTextBox5_nlump", typeof(MMDistl_Dynam_Lump_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.NLUMP"
		});

		public static readonly CxvPropertyDeclaration MMTextBox4_flump_Property = CxvPropertyDeclaration.Register("MMTextBox4_flump", typeof(MMDistl_Dynam_Lump_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.FLUMP"
		});

		public static readonly CxvPropertyDeclaration MMLBUText4_lump_holdup_Property = CxvPropertyDeclaration.Register("MMLBUText4_lump_holdup", typeof(MMDistl_Dynam_Lump_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.LUMP_HOLDUP"
		});

		public static readonly CxvPropertyDeclaration MMScrollArea1_GridData_Property = CxvPropertyDeclaration.Register("MMScrollArea1_GridData", typeof(MMDistl_Dynam_Lump_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(MMScrollArea1_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.DYN_LUMP1",
				UseChildId = true,
				Name = "stage"
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_lumpsize_Property = CxvPropertyDeclaration.Register("MMLBUText1_lumpsize", typeof(MMDistl_Dynam_Lump_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.LUMPSIZE"
		});

		public object MMTextBox5_nlump => ((CxvViewModel)this).GetValue(MMTextBox5_nlump_Property);

		public object MMTextBox4_flump => ((CxvViewModel)this).GetValue(MMTextBox4_flump_Property);

		public object MMLBUText4_lump_holdup => ((CxvViewModel)this).GetValue(MMLBUText4_lump_holdup_Property);

		public object MMScrollArea1_GridData => ((CxvViewModel)this).GetValue(MMScrollArea1_GridData_Property);

		public object MMLBUText1_lumpsize => ((CxvViewModel)this).GetValue(MMLBUText1_lumpsize_Property);
	}
	[ProgId("MMDistl.MMDistl_Dynam_Lump")]
	public class MMDistl_Dynam_Lump : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMGroupBox MMFrame2;

		internal MMLabel MMLabel4;

		internal MMValueEdit MMTextBox4;

		internal MMLabel MMLabel5;

		internal MMValueEdit MMTextBox5;

		internal MMScrollArea MMScrollArea1;

		private bool _contentLoaded;

		public MMDistl_Dynam_Lump()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDistl_Dynam_Lump_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Distl;component/mmdistl_dynam_lump.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Expected O, but got Unknown
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Expected O, but got Unknown
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Expected O, but got Unknown
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			//IL_0061: Expected O, but got Unknown
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Expected O, but got Unknown
			//IL_0071: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Expected O, but got Unknown
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0088: Expected O, but got Unknown
			//IL_008b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0095: Expected O, but got Unknown
			//IL_0098: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a2: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 3:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 4:
				MMFrame2 = (MMGroupBox)target;
				break;
			case 5:
				MMLabel4 = (MMLabel)target;
				break;
			case 6:
				MMTextBox4 = (MMValueEdit)target;
				break;
			case 7:
				MMLabel5 = (MMLabel)target;
				break;
			case 8:
				MMTextBox5 = (MMValueEdit)target;
				break;
			case 9:
				MMScrollArea1 = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDistl_Input_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration SPECIN_Property = CxvPropertyDeclaration.Register("SPECIN", typeof(MMDistl_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SPECIN"
		});

		public static readonly CxvPropertyDeclaration UENTCVG1_Property = CxvPropertyDeclaration.Register("UENTCVG1", typeof(MMDistl_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCVG1"
		});

		public static readonly CxvPropertyDeclaration UENTCVG2_Property = CxvPropertyDeclaration.Register("UENTCVG2", typeof(MMDistl_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCVG2"
		});

		public static readonly CxvPropertyDeclaration UENTCVG3_Property = CxvPropertyDeclaration.Register("UENTCVG3", typeof(MMDistl_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCVG3"
		});

		public static readonly CxvPropertyDeclaration FREE2_Property = CxvPropertyDeclaration.Register("FREE2", typeof(MMDistl_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.FREE2"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMDistl_Input_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@SPECIN" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMDistl_Input_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@FREE2" },
			EnteredDataPaths = { "@UENTCVG1", "@UENTCVG2", "@UENTCVG3" }
		});

		public object SPECIN => ((CxvViewModel)this).GetValue(SPECIN_Property);

		public object UENTCVG1 => ((CxvViewModel)this).GetValue(UENTCVG1_Property);

		public object UENTCVG2 => ((CxvViewModel)this).GetValue(UENTCVG2_Property);

		public object UENTCVG3 => ((CxvViewModel)this).GetValue(UENTCVG3_Property);

		public object FREE2 => ((CxvViewModel)this).GetValue(FREE2_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);
	}
	[ProgId("MMDistl.MMDistl_Input")]
	public class MMDistl_Input : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabMMDistl_Input;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tabInfo;

		private bool _contentLoaded;

		public MMDistl_Input()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDistl_Input_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Distl;component/mmdistl_input.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabMMDistl_Input = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tabInfo = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDistl_Input_Conver_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration spnMMDistl_Maxit_MAXIT_Property = CxvPropertyDeclaration.Register("spnMMDistl_Maxit_MAXIT", typeof(MMDistl_Input_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.MAXIT"
		});

		public static readonly CxvPropertyDeclaration lbtuMMDistl_Temp_Tol_TEMP_TOL_Property = CxvPropertyDeclaration.Register("lbtuMMDistl_Temp_Tol_TEMP_TOL", typeof(MMDistl_Input_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.TEMP_TOL"
		});

		public static readonly CxvPropertyDeclaration cboVPhases_MultiMap_Property;

		public static readonly CxvPropertyDeclaration MMLBUText1_FLASH_TOL_Property;

		public static readonly CxvPropertyDeclaration spnMMDistl_Flash_Maxit_FLASH_MAXIT_Property;

		public object spnMMDistl_Maxit_MAXIT => ((CxvViewModel)this).GetValue(spnMMDistl_Maxit_MAXIT_Property);

		public object lbtuMMDistl_Temp_Tol_TEMP_TOL => ((CxvViewModel)this).GetValue(lbtuMMDistl_Temp_Tol_TEMP_TOL_Property);

		public object cboVPhases_MultiMap => ((CxvViewModel)this).GetValue(cboVPhases_MultiMap_Property);

		public object MMLBUText1_FLASH_TOL => ((CxvViewModel)this).GetValue(MMLBUText1_FLASH_TOL_Property);

		public object spnMMDistl_Flash_Maxit_FLASH_MAXIT => ((CxvViewModel)this).GetValue(spnMMDistl_Flash_Maxit_FLASH_MAXIT_Property);

		public MMDistl_Input_Conver_ViewModel()
		{
		}

		static MMDistl_Input_Conver_ViewModel()
		{
	cboVPhases_MultiMap_Property = CxvPropertyDeclaration.Register("cboVPhases_MultiMap", typeof(MMDistl_Input_Conver_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboVPhases_BLKOPFREWAT",
				DataPath = "@main.Input.BLKOPFREWAT"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Vapor-Liquid",
				DisplayResourceKey = "MMDistl_Input_Conver_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid",
				Value = "cboVPhases_MultiMapOption_1",
				Prompt = "2 phases (vapor and liquid) are considered in phase equilibrium \r\ncalculations. \r\n",
				PromptResourceKey = "MMDistl_Input_Conver_ViewModel__CxvMultiMapOption_Prompt_2_phases__vapor_and_liquid__are_considered_",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboVPhases_BLKOPFREWAT",
				Value = "NO"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Vapor-Liquid-FreeWaterCondenser",
				DisplayResourceKey = "MMDistl_Input_Conver_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_FreeWaterCondenser",
				Value = "cboVPhases_MultiMapOption_2",
				Prompt = "3 phases (vapor, organic, and pure water) are considered in  \r\ncondenser calculations. \r\n ",
				PromptResourceKey = "MMDistl_Input_Conver_ViewModel__CxvMultiMapOption_Prompt_3_phases__vapor__organic__and_pure_water__a",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboVPhases_BLKOPFREWAT",
				Value = "YES"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Vapor-Liquid-DirtyWaterCondenser",
				DisplayResourceKey = "MMDistl_Input_Conver_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_DirtyWaterCondenser",
				Value = "cboVPhases_MultiMapOption_3",
				Prompt = "3 phases (vapor, organic, and dirty water) are considered in  \r\ncondenser calculations. \r\n ",
				PromptResourceKey = "MMDistl_Input_Conver_ViewModel__CxvMultiMapOption_Prompt_3_phases__vapor__organic__and_dirty_water__",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboVPhases_BLKOPFREWAT",
				Value = "DIRTY"
			} }
				} }
});
	MMLBUText1_FLASH_TOL_Property = CxvPropertyDeclaration.Register("MMLBUText1_FLASH_TOL", typeof(MMDistl_Input_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.FLASH_TOL"
			});
	spnMMDistl_Flash_Maxit_FLASH_MAXIT_Property = CxvPropertyDeclaration.Register("spnMMDistl_Flash_Maxit_FLASH_MAXIT", typeof(MMDistl_Input_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.FLASH_MAXIT"
			});
	}
	}
	[ProgId("MMDistl.MMDistl_Input_Conver")]
	public class MMDistl_Input_Conver : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraMMDistl_Flash_Conv;

		internal MMLabel cboVPhases_label;

		internal MMComboEdit cboVPhases;

		internal MMLabel spnMMDistl_Flash_Maxit_label;

		internal MMSpinBox spnMMDistl_Flash_Maxit;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMGroupBox fraMMDistl_Model_Conv;

		internal MMLabel spnMMDistl_Maxit_label;

		internal MMSpinBox spnMMDistl_Maxit;

		internal MMLabel lbtuMMDistl_Temp_Tol_label;

		internal MMVariableEdit lbtuMMDistl_Temp_Tol;

		private bool _contentLoaded;

		public MMDistl_Input_Conver()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDistl_Input_Conver_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Distl;component/mmdistl_input_conver.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Expected O, but got Unknown
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0056: Expected O, but got Unknown
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Expected O, but got Unknown
			//IL_0066: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Expected O, but got Unknown
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_007d: Expected O, but got Unknown
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Expected O, but got Unknown
			//IL_008d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0097: Expected O, but got Unknown
			//IL_009a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a4: Expected O, but got Unknown
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Expected O, but got Unknown
			//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00be: Expected O, but got Unknown
			//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cb: Expected O, but got Unknown
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d8: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraMMDistl_Flash_Conv = (MMGroupBox)target;
				break;
			case 2:
				cboVPhases_label = (MMLabel)target;
				break;
			case 3:
				cboVPhases = (MMComboEdit)target;
				break;
			case 4:
				spnMMDistl_Flash_Maxit_label = (MMLabel)target;
				break;
			case 5:
				spnMMDistl_Flash_Maxit = (MMSpinBox)target;
				break;
			case 6:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 7:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 8:
				fraMMDistl_Model_Conv = (MMGroupBox)target;
				break;
			case 9:
				spnMMDistl_Maxit_label = (MMLabel)target;
				break;
			case 10:
				spnMMDistl_Maxit = (MMSpinBox)target;
				break;
			case 11:
				lbtuMMDistl_Temp_Tol_label = (MMLabel)target;
				break;
			case 12:
				lbtuMMDistl_Temp_Tol = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDistl_Input_Specif_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration spnFeed_Loc_FEED_LOC_Property = CxvPropertyDeclaration.Register("spnFeed_Loc_FEED_LOC", typeof(MMDistl_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.FEED_LOC"
		});

		public static readonly CxvPropertyDeclaration spnNStage_NSTAGE_Property = CxvPropertyDeclaration.Register("spnNStage_NSTAGE", typeof(MMDistl_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.NSTAGE"
		});

		public static readonly CxvPropertyDeclaration MMComboBox1_var1_Property = CxvPropertyDeclaration.Register("MMComboBox1_var1", typeof(MMDistl_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.COND_TYPE",
			DisplayedCase = (CxsDisplayedCase)2
		});

		public static readonly CxvPropertyDeclaration lbtuD_F_D_F_Property = CxvPropertyDeclaration.Register("lbtuD_F_D_F", typeof(MMDistl_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.D_F"
		});

		public static readonly CxvPropertyDeclaration lbtuRR_RR_Property = CxvPropertyDeclaration.Register("lbtuRR_RR", typeof(MMDistl_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.RR"
		});

		public static readonly CxvPropertyDeclaration lbtuPBot_PBOT_Property = CxvPropertyDeclaration.Register("lbtuPBot_PBOT", typeof(MMDistl_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.PBOT"
		});

		public static readonly CxvPropertyDeclaration lbtuPTop_PTOP_Property = CxvPropertyDeclaration.Register("lbtuPTop_PTOP", typeof(MMDistl_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.PTOP"
		});

		public object spnFeed_Loc_FEED_LOC => ((CxvViewModel)this).GetValue(spnFeed_Loc_FEED_LOC_Property);

		public object spnNStage_NSTAGE => ((CxvViewModel)this).GetValue(spnNStage_NSTAGE_Property);

		public object MMComboBox1_var1 => ((CxvViewModel)this).GetValue(MMComboBox1_var1_Property);

		public object lbtuD_F_D_F => ((CxvViewModel)this).GetValue(lbtuD_F_D_F_Property);

		public object lbtuRR_RR => ((CxvViewModel)this).GetValue(lbtuRR_RR_Property);

		public object lbtuPBot_PBOT => ((CxvViewModel)this).GetValue(lbtuPBot_PBOT_Property);

		public object lbtuPTop_PTOP => ((CxvViewModel)this).GetValue(lbtuPTop_PTOP_Property);
	}
	[ProgId("MMDistl.MMDistl_Input_Specif")]
	public class MMDistl_Input_Specif : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraColumn_Spec;

		internal MMLabel spnNStage_label;

		internal MMSpinBox spnNStage;

		internal MMLabel spnFeed_Loc_label;

		internal MMSpinBox spnFeed_Loc;

		internal MMLabel lbtuRR_label;

		internal MMVariableEdit lbtuRR;

		internal MMLabel lbtuD_F_label;

		internal MMVariableEdit lbtuD_F;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMGroupBox fraPressure_Spec;

		internal MMLabel lbtuPTop_label;

		internal MMVariableEdit lbtuPTop;

		internal MMLabel lbtuPBot_label;

		internal MMVariableEdit lbtuPBot;

		private bool _contentLoaded;

		public MMDistl_Input_Specif()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDistl_Input_Specif_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Distl;component/mmdistl_input_specif.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Expected O, but got Unknown
			//IL_005c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Expected O, but got Unknown
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Expected O, but got Unknown
			//IL_0076: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Expected O, but got Unknown
			//IL_0083: Unknown result type (might be due to invalid IL or missing references)
			//IL_008d: Expected O, but got Unknown
			//IL_0090: Unknown result type (might be due to invalid IL or missing references)
			//IL_009a: Expected O, but got Unknown
			//IL_009d: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Expected O, but got Unknown
			//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b4: Expected O, but got Unknown
			//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c1: Expected O, but got Unknown
			//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ce: Expected O, but got Unknown
			//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00db: Expected O, but got Unknown
			//IL_00de: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e8: Expected O, but got Unknown
			//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f5: Expected O, but got Unknown
			//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0102: Expected O, but got Unknown
			//IL_0105: Unknown result type (might be due to invalid IL or missing references)
			//IL_010f: Expected O, but got Unknown
			//IL_0112: Unknown result type (might be due to invalid IL or missing references)
			//IL_011c: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraColumn_Spec = (MMGroupBox)target;
				break;
			case 2:
				spnNStage_label = (MMLabel)target;
				break;
			case 3:
				spnNStage = (MMSpinBox)target;
				break;
			case 4:
				spnFeed_Loc_label = (MMLabel)target;
				break;
			case 5:
				spnFeed_Loc = (MMSpinBox)target;
				break;
			case 6:
				lbtuRR_label = (MMLabel)target;
				break;
			case 7:
				lbtuRR = (MMVariableEdit)target;
				break;
			case 8:
				lbtuD_F_label = (MMLabel)target;
				break;
			case 9:
				lbtuD_F = (MMVariableEdit)target;
				break;
			case 10:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 11:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 12:
				fraPressure_Spec = (MMGroupBox)target;
				break;
			case 13:
				lbtuPTop_label = (MMLabel)target;
				break;
			case 14:
				lbtuPTop = (MMVariableEdit)target;
				break;
			case 15:
				lbtuPBot_label = (MMLabel)target;
				break;
			case 16:
				lbtuPBot = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDistl_Result_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration COND_DUTY_Property = CxvPropertyDeclaration.Register("COND_DUTY", typeof(MMDistl_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COND_DUTY"
		});

		public static readonly CxvPropertyDeclaration REB_DUTY_Property = CxvPropertyDeclaration.Register("REB_DUTY", typeof(MMDistl_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.REB_DUTY"
		});

		public static readonly CxvPropertyDeclaration FEED_TRAY_T_Property = CxvPropertyDeclaration.Register("FEED_TRAY_T", typeof(MMDistl_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FEED_TRAY_T"
		});

		public static readonly CxvPropertyDeclaration BAL_MOLI_TFL_Property = CxvPropertyDeclaration.Register("BAL_MOLI_TFL", typeof(MMDistl_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BAL_MOLI_TFL"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMDistl_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@COND_DUTY", "@FEED_TRAY_T", "@REB_DUTY" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMDistl_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@BAL_MOLI_TFL" }
		});

		public object COND_DUTY => ((CxvViewModel)this).GetValue(COND_DUTY_Property);

		public object REB_DUTY => ((CxvViewModel)this).GetValue(REB_DUTY_Property);

		public object FEED_TRAY_T => ((CxvViewModel)this).GetValue(FEED_TRAY_T_Property);

		public object BAL_MOLI_TFL => ((CxvViewModel)this).GetValue(BAL_MOLI_TFL_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);
	}
	[ProgId("MMDistl.MMDistl_Result")]
	public class MMDistl_Result : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMSSTab1;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tabStatus;

		private bool _contentLoaded;

		public MMDistl_Result()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDistl_Result_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Distl;component/mmdistl_result.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMSSTab1 = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tabStatus = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDistl_Result_Summar_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMLBUText4_FEED_QUALITY_Property = CxvPropertyDeclaration.Register("MMLBUText4_FEED_QUALITY", typeof(MMDistl_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FEED_QUALITY"
		});

		public static readonly CxvPropertyDeclaration MMLBUText3_BOTTOM_TEMP_Property = CxvPropertyDeclaration.Register("MMLBUText3_BOTTOM_TEMP", typeof(MMDistl_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOTTOM_TEMP"
		});

		public static readonly CxvPropertyDeclaration MMLBUText2_TOP_TEMP_Property = CxvPropertyDeclaration.Register("MMLBUText2_TOP_TEMP", typeof(MMDistl_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TOP_TEMP"
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_FEED_TRAY_T_Property = CxvPropertyDeclaration.Register("MMLBUText1_FEED_TRAY_T", typeof(MMDistl_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FEED_TRAY_T"
		});

		public static readonly CxvPropertyDeclaration MMLBUText7_REB_DUTY_Property = CxvPropertyDeclaration.Register("MMLBUText7_REB_DUTY", typeof(MMDistl_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.REB_DUTY"
		});

		public static readonly CxvPropertyDeclaration MMLBUText6_COND_DUTY_Property = CxvPropertyDeclaration.Register("MMLBUText6_COND_DUTY", typeof(MMDistl_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COND_DUTY"
		});

		public object MMLBUText4_FEED_QUALITY => ((CxvViewModel)this).GetValue(MMLBUText4_FEED_QUALITY_Property);

		public object MMLBUText3_BOTTOM_TEMP => ((CxvViewModel)this).GetValue(MMLBUText3_BOTTOM_TEMP_Property);

		public object MMLBUText2_TOP_TEMP => ((CxvViewModel)this).GetValue(MMLBUText2_TOP_TEMP_Property);

		public object MMLBUText1_FEED_TRAY_T => ((CxvViewModel)this).GetValue(MMLBUText1_FEED_TRAY_T_Property);

		public object MMLBUText7_REB_DUTY => ((CxvViewModel)this).GetValue(MMLBUText7_REB_DUTY_Property);

		public object MMLBUText6_COND_DUTY => ((CxvViewModel)this).GetValue(MMLBUText6_COND_DUTY_Property);
	}
	[ProgId("MMDistl.MMDistl_Result_Summar")]
	public class MMDistl_Result_Summar : MMTabPage, IComponentConnector
	{
		internal MMLabel MMLBUText6_label;

		internal MMVariableEdit MMLBUText6;

		internal MMLabel MMLBUText7_label;

		internal MMVariableEdit MMLBUText7;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMLabel MMLBUText2_label;

		internal MMVariableEdit MMLBUText2;

		internal MMLabel MMLBUText3_label;

		internal MMVariableEdit MMLBUText3;

		internal MMLabel MMLBUText4_label;

		internal MMVariableEdit MMLBUText4;

		private bool _contentLoaded;

		public MMDistl_Result_Summar()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDistl_Result_Summar_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Distl;component/mmdistl_result_summar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Expected O, but got Unknown
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0056: Expected O, but got Unknown
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Expected O, but got Unknown
			//IL_0066: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Expected O, but got Unknown
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_007d: Expected O, but got Unknown
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Expected O, but got Unknown
			//IL_008d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0097: Expected O, but got Unknown
			//IL_009a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a4: Expected O, but got Unknown
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Expected O, but got Unknown
			//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00be: Expected O, but got Unknown
			//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cb: Expected O, but got Unknown
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d8: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMLBUText6_label = (MMLabel)target;
				break;
			case 2:
				MMLBUText6 = (MMVariableEdit)target;
				break;
			case 3:
				MMLBUText7_label = (MMLabel)target;
				break;
			case 4:
				MMLBUText7 = (MMVariableEdit)target;
				break;
			case 5:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 6:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 7:
				MMLBUText2_label = (MMLabel)target;
				break;
			case 8:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			case 9:
				MMLBUText3_label = (MMLabel)target;
				break;
			case 10:
				MMLBUText3 = (MMVariableEdit)target;
				break;
			case 11:
				MMLBUText4_label = (MMLabel)target;
				break;
			case 12:
				MMLBUText4 = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
}
namespace XamlGeneratedNamespace
{
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class GeneratedInternalTypeHelper : InternalTypeHelper
	{
		protected override object CreateInstance(Type type, CultureInfo culture)
		{
			return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.CreateInstance, null, null, culture);
		}

		protected override object GetPropertyValue(PropertyInfo propertyInfo, object target, CultureInfo culture)
		{
			return propertyInfo.GetValue(target, BindingFlags.Default, null, null, culture);
		}

		protected override void SetPropertyValue(PropertyInfo propertyInfo, object target, object value, CultureInfo culture)
		{
			propertyInfo.SetValue(target, value, BindingFlags.Default, null, null, culture);
		}

		protected override Delegate CreateDelegate(Type delegateType, object target, string handler)
		{
			return (Delegate)target.GetType().InvokeMember("_CreateDelegate", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, target, new object[2] { delegateType, handler }, null);
		}

		protected override void AddEventHandler(EventInfo eventInfo, object target, Delegate handler)
		{
			eventInfo.AddEventHandler(target, handler);
		}
	}
}
