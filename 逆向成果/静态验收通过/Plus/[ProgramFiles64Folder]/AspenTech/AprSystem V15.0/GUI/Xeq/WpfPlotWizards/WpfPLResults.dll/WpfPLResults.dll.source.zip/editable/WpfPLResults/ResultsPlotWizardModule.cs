using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLResults;

[RibbonPlotWizardMgr("WpfPLRESULTS.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class ResultsPlotWizardModule : PlotModuleBase
{
}
