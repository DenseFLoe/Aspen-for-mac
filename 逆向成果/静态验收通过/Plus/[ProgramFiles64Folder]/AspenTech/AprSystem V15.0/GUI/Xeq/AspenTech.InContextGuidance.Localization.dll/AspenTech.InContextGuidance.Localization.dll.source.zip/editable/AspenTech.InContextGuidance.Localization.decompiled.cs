using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Threading;
using System.Windows;
using Microsoft.Win32;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology 2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("15.0.0.0")]
[assembly: AssemblyTitle("AspenTech.InContextGuidance.Localization")]
[assembly: AssemblyDescription("InContextGuidance localization resources library.")]
[assembly: AssemblyProduct("AspenTech.InContextGuidance.Localization")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("15.0.0.0")]
namespace AspenTech.InContextGuidance.Localization;

public static class AspenLanguageSelector
{
	private static readonly List<string> _supportedLanguages = new List<string> { "ENG", "FRA", "ITA", "DEU", "SPA", "JPN", "CHS", "KOR", "RUS", "PTB" };

	public static void ApplyAspenLanguageSelection()
	{
		string keyName = "HKEY_CURRENT_USER\\Software\\AspenTech\\Engineering\\Language";
		string text = Registry.GetValue(keyName, null, string.Empty) as string;
		if (string.IsNullOrEmpty(text))
		{
			string text2 = Thread.CurrentThread.CurrentUICulture.ThreeLetterWindowsLanguageName;
			if (!_supportedLanguages.Contains(text2))
			{
				text2 = "ENG";
			}
			Registry.SetValue(keyName, null, text2);
			text = text2;
		}
		string text3;
		switch (text.ToUpperInvariant())
		{
			case "ENG":
				text3 = "en-US";
				break;
			case "FRA":
				text3 = "fr-FR";
				break;
			case "ITA":
				text3 = "it-IT";
				break;
			case "DEU":
				text3 = "de-DE";
				break;
			case "SPA":
				text3 = "es-ES";
				break;
			case "JPN":
				text3 = "ja-JP";
				break;
			case "CHS":
				text3 = "zh-HANS";
				break;
			case "KOR":
				text3 = "ko-KR";
				break;
			case "RUS":
				text3 = "ru-RU";
				break;
			case "PTB":
				text3 = "pt-BR";
				break;
			default:
				text3 = "en-US";
				break;
		}
		if (!string.IsNullOrEmpty(text3))
		{
			CultureInfo cultureInfo = null;
			try
			{
				cultureInfo = new CultureInfo(CultureInfo.CreateSpecificCulture(text3).Name, useUserOverride: true);
			}
			catch (CultureNotFoundException)
			{
			}
			if (cultureInfo != null)
			{
				Thread.CurrentThread.CurrentUICulture = cultureInfo;
				return;
			}
			CultureInfo currentUICulture = new CultureInfo("en-US");
			Thread.CurrentThread.CurrentUICulture = currentUICulture;
		}
	}
}
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
public class InContextGuidanceResources
{
	private static ResourceManager resourceMan;

	private static CultureInfo resourceCulture;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	public static ResourceManager ResourceManager
	{
		get
		{
			if (resourceMan == null)
			{
				resourceMan = new ResourceManager("AspenTech.InContextGuidance.Localization.InContextGuidanceResources", typeof(InContextGuidanceResources).Assembly);
			}
			return resourceMan;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	public static CultureInfo Culture
	{
		get
		{
			return resourceCulture;
		}
		set
		{
			resourceCulture = value;
		}
	}

	public static string ExchangeIntegration_ELearningChekingDialog_Question => ResourceManager.GetString("ExchangeIntegration_ELearningChekingDialog_Question", resourceCulture);

	public static string ExchangeIntegration_ELearningChekingDialog_Title => ResourceManager.GetString("ExchangeIntegration_ELearningChekingDialog_Title", resourceCulture);

	public static string ExchangeTools_AspenKnowledgeRibbon_Caption => ResourceManager.GetString("ExchangeTools_AspenKnowledgeRibbon_Caption", resourceCulture);

	public static string ExchangeTools_AspenKnowledgeRibbon_Tooltip_Disabled => ResourceManager.GetString("ExchangeTools_AspenKnowledgeRibbon_Tooltip_Disabled", resourceCulture);

	public static string ExchangeTools_AspenKnowledgeRibbon_Tooltip_Enabled => ResourceManager.GetString("ExchangeTools_AspenKnowledgeRibbon_Tooltip_Enabled", resourceCulture);

	public static string ExchangeTools_ELearningRibbon_Caption => ResourceManager.GetString("ExchangeTools_ELearningRibbon_Caption", resourceCulture);

	public static string ExchangeTools_ELearningRibbon_Tooltip_Disabled => ResourceManager.GetString("ExchangeTools_ELearningRibbon_Tooltip_Disabled", resourceCulture);

	public static string ExchangeTools_ELearningRibbon_Tooltip_Enabled => ResourceManager.GetString("ExchangeTools_ELearningRibbon_Tooltip_Enabled", resourceCulture);

	public static string ServerTool_Button_Cancel => ResourceManager.GetString("ServerTool_Button_Cancel", resourceCulture);

	public static string ServerTool_Button_OK => ResourceManager.GetString("ServerTool_Button_OK", resourceCulture);

	public static string ServerTool_Button_ValidateConnection => ResourceManager.GetString("ServerTool_Button_ValidateConnection", resourceCulture);

	public static string ServerTool_InvalidMessageBox_Message => ResourceManager.GetString("ServerTool_InvalidMessageBox_Message", resourceCulture);

	public static string ServerTool_InvalidMessageBox_Title => ResourceManager.GetString("ServerTool_InvalidMessageBox_Title", resourceCulture);

	public static string ServerTool_MainWindow_ServiceAddress => ResourceManager.GetString("ServerTool_MainWindow_ServiceAddress", resourceCulture);

	public static string ServerTool_MainWindow_Testing_Failed => ResourceManager.GetString("ServerTool_MainWindow_Testing_Failed", resourceCulture);

	public static string ServerTool_MainWindow_Testing_Succeeded => ResourceManager.GetString("ServerTool_MainWindow_Testing_Succeeded", resourceCulture);

	public static string ServerTool_MainWindow_Title => ResourceManager.GetString("ServerTool_MainWindow_Title", resourceCulture);

	public static string ServiceTool_Button_Cancel => ResourceManager.GetString("ServiceTool_Button_Cancel", resourceCulture);

	public static string ServiceTool_Button_Change => ResourceManager.GetString("ServiceTool_Button_Change", resourceCulture);

	public static string ServiceTool_Button_Close => ResourceManager.GetString("ServiceTool_Button_Close", resourceCulture);

	public static string ServiceTool_Button_LoadFromRegistry => ResourceManager.GetString("ServiceTool_Button_LoadFromRegistry", resourceCulture);

	public static string ServiceTool_Button_OK => ResourceManager.GetString("ServiceTool_Button_OK", resourceCulture);

	public static string ServiceTool_Button_Save => ResourceManager.GetString("ServiceTool_Button_Save", resourceCulture);

	public static string ServiceTool_Button_UpdateNow => ResourceManager.GetString("ServiceTool_Button_UpdateNow", resourceCulture);

	public static string ServiceTool_Button_UpdateNow_Description => ResourceManager.GetString("ServiceTool_Button_UpdateNow_Description", resourceCulture);

	public static string ServiceTool_InvalidMessageBox_Message => ResourceManager.GetString("ServiceTool_InvalidMessageBox_Message", resourceCulture);

	public static string ServiceTool_InvalidMessageBox_Title => ResourceManager.GetString("ServiceTool_InvalidMessageBox_Title", resourceCulture);

	public static string ServiceTool_MainWindow_CurrentUpdateInterval => ResourceManager.GetString("ServiceTool_MainWindow_CurrentUpdateInterval", resourceCulture);

	public static string ServiceTool_MainWindow_LastUpdateTime => ResourceManager.GetString("ServiceTool_MainWindow_LastUpdateTime", resourceCulture);

	public static string ServiceTool_MainWindow_NewUpdateInterval => ResourceManager.GetString("ServiceTool_MainWindow_NewUpdateInterval", resourceCulture);

	public static string ServiceTool_MainWindow_NextUpdateTime => ResourceManager.GetString("ServiceTool_MainWindow_NextUpdateTime", resourceCulture);

	public static string ServiceTool_MainWindow_ServiceAddress => ResourceManager.GetString("ServiceTool_MainWindow_ServiceAddress", resourceCulture);

	public static string ServiceTool_MainWindow_Title => ResourceManager.GetString("ServiceTool_MainWindow_Title", resourceCulture);

	public static string ServiceTool_ServiceAddressWindow_CurrentAddress => ResourceManager.GetString("ServiceTool_ServiceAddressWindow_CurrentAddress", resourceCulture);

	public static string ServiceTool_ServiceAddressWindow_NewAddress => ResourceManager.GetString("ServiceTool_ServiceAddressWindow_NewAddress", resourceCulture);

	public static string ServiceTool_ServiceAddressWindow_Title => ResourceManager.GetString("ServiceTool_ServiceAddressWindow_Title", resourceCulture);

	public static string ServiceTool_TextBlock_Available => ResourceManager.GetString("ServiceTool_TextBlock_Available", resourceCulture);

	public static string ServiceTool_TextBlock_NotAvailable => ResourceManager.GetString("ServiceTool_TextBlock_NotAvailable", resourceCulture);

	public static string ServiceTool_UpdatingMessage => ResourceManager.GetString("ServiceTool_UpdatingMessage", resourceCulture);

	public static string Widgets_InContextGuidanceButton_Tooltip_Disabled => ResourceManager.GetString("Widgets_InContextGuidanceButton_Tooltip_Disabled", resourceCulture);

	public static string Widgets_InContextGuidanceButton_Tooltip_Enabled => ResourceManager.GetString("Widgets_InContextGuidanceButton_Tooltip_Enabled", resourceCulture);

	public static string Widgets_Popup_Documentation => ResourceManager.GetString("Widgets_Popup_Documentation", resourceCulture);

	public static string Widgets_Popup_Feedback => ResourceManager.GetString("Widgets_Popup_Feedback", resourceCulture);

	public static string Widgets_Popup_Recommendations => ResourceManager.GetString("Widgets_Popup_Recommendations", resourceCulture);

	public static string Widgets_Popup_ViewMoreResults => ResourceManager.GetString("Widgets_Popup_ViewMoreResults", resourceCulture);

	public static string Widgets_SearchBox_Placeholder => ResourceManager.GetString("Widgets_SearchBox_Placeholder", resourceCulture);

	public static string Widgets_SearchBox_Tooltip_Disabled => ResourceManager.GetString("Widgets_SearchBox_Tooltip_Disabled", resourceCulture);

	internal InContextGuidanceResources()
	{
	}
}
