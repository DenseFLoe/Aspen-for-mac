#!/usr/bin/env python3
"""Owner+signature+base-name MethodDef pairing (derive_rules.py variant).

derive_rules.py pairs by (owner, signature blob) and breaks ties by occurrence
order.  In Interop.ApvCom.dll the empty signature `instance void ()` is shared by
`.ctor` and `Clear`, and the compiler reorders the explicit implementations, so
occurrence order mispairs them.  This variant keys on
(owner, signature, target base name) where the candidate base name is the last
dot-segment of the explicit-impl name, which is unique per (owner, signature).

Usage: derive_rules2.py <original.dll> <candidate.dll> <out.json>
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "managed"))
sys.path.insert(0, str(ROOT.parents[1] / "aspen-acceptance-work" / "deps"))
import clr_meta  # noqa: E402


def rows(path):
    data = Path(path).read_bytes()
    pe, cli, root = clr_meta.read_image(data)
    methods = clr_meta.method_defs(pe, cli, root)
    owner = {}
    trows = root["tables"]["layout"].get(0x02, {}).get("rows", 0)
    for index in range(1, trows + 1):
        row = clr_meta.read_row(root["bytes"], root["tables"], 0x02, index)
        name = clr_meta.strings(pe, cli, root, row[1])
        ns = clr_meta.strings(pe, cli, root, row[2])
        full = (ns + "." if ns else "") + name
        first = row[5]
        last = (clr_meta.read_row(root["bytes"], root["tables"], 0x02, index + 1)[5]
                if index < trows else len(methods) + 1)
        for m in range(first, last):
            owner[m] = full
    out = []
    for r in methods:
        out.append({"row": r["row"], "token": r["token"],
                    "name": clr_meta.strings(pe, cli, root, r["name_index"]),
                    "flags": r["flags"],
                    "sig": clr_meta.blob(pe, cli, root, r["signature_index"]),
                    "owner": owner.get(r["row"], "?")})
    return out


def base_name(name):
    # ".ctor" must stay ".ctor": rsplit would return "ctor".
    if name.startswith("."):
        return name
    return name.rsplit(".", 1)[-1]


def _compressed(data, at):
    b = data[at]
    if b & 0x80 == 0:
        return b, at + 1
    if b & 0xC0 == 0x80:
        return ((b & 0x3F) << 8) | data[at + 1], at + 2
    return ((b & 0x1F) << 24) | (data[at + 1] << 16) | (data[at + 2] << 8) | data[at + 3], at + 4


def param_count(sig):
    try:
        count, _ = _compressed(sig, 1)
        return count
    except IndexError:
        return None


def main(orig_path, cand_path, out_path):
    o, c = rows(orig_path), rows(cand_path)
    buckets = {}
    for row in c:
        buckets.setdefault((row["owner"], base_name(row["name"])), []).append(row)
    order = {}
    rules, pairs, problems = [], [], []
    for a in o:
        key = (a["owner"], a["name"])
        pool = buckets.get(key, [])
        n = order.get(key, 0)
        if n >= len(pool):
            problems.append({"original": a["name"], "owner": a["owner"], "reason": "no pair"})
            continue
        b = pool[n]
        order[key] = n + 1
        # Same-name overloads are paired by occurrence order; reject a pair whose
        # parameter counts disagree so a reordering cannot silently mispair.
        if param_count(a["sig"]) != param_count(b["sig"]):
            problems.append({"original": a["name"], "candidate": b["name"], "owner": a["owner"],
                             "reason": "parameter count mismatch"})
            continue
        pairs.append({"owner": a["owner"], "original_row": a["row"], "candidate_row": b["row"],
                      "original_name": a["name"], "candidate_name": b["name"],
                      "original_flags": a["flags"], "candidate_flags": b["flags"],
                      "signature_bytes_equal": a["sig"] == b["sig"],
                      "flags_equal": a["flags"] == b["flags"]})
        if a["flags"] != b["flags"]:
            rules.append({"target_name": a["name"], "expected_flags": b["flags"],
                          "target_flags": a["flags"], "candidate_row": b["row"],
                          "_candidate_name": b["name"], "_owner": a["owner"]})
    result = {"rules": rules, "pairs": pairs, "problems": problems,
              "counts": {"original": len(o), "candidate": len(c),
                         "paired": len(pairs), "rule_count": len(rules),
                         "flags_diff": sum(1 for p in pairs if not p["flags_equal"])}}
    Path(out_path).write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(result["counts"], ensure_ascii=False))
    for r in rules[:10]:
        print("  rule %-28s %-45s %#06x -> %#06x" % (r["target_name"], r["_candidate_name"],
                                                     r["expected_flags"], r["target_flags"]))
    for p in problems:
        print("  PROBLEM", p)


if __name__ == "__main__":
    main(*sys.argv[1:4])
