using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPLControls;
using WpfPlotwizard;

namespace WpfPLHeatx;

[ProgId("WpfPLHeatx.TQCurve")]
public class TQCurve : UserControl, IRibbonPlotWizardType, IPlotWizardTemplate, IComponentConnector
{
	private IHNode _context;

	private IHWizardPlot2 _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private string _uniqueId = "TQCurves";

	private string _plotName;

	private object _nodeCxs;

	private System.Drawing.Image _imgBitmap;

	private bool _bHasInputDialog;

	private string _currentConfigValue = string.Empty;

	private string _currentTempUnit = string.Empty;

	private string _currentDutyUnit = string.Empty;

	private readonly string _tempUnitFieldId = WpfPLRPlugResources.Temperature;

	private readonly string _dutyUnitFieldId = PlotPWRResource.Heatx_TQCurve_Duty;

	public static RoutedCommand OKCommand = new RoutedCommand();

	public static RoutedCommand CancelCommand = new RoutedCommand();

	private bool _bCheckDataOnly;

	internal CurvesSelectorControl CurveList;

	private bool _contentLoaded;

	public string TooltipContentForRibbonItem => ApwnResources.BrowserTQCurves;

	public string TooltipHeaderForRibbonItem => ApwnResources.BrowserTQCurves;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot2;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _tempUnitFieldId, _dutyUnitFieldId };

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public TQCurve()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		InitializeComponent();
		_bHasInputDialog = true;
		if (_imgBitmap == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLHeatx.Images.TQCurve.ico");
			_imgBitmap = new Bitmap(manifestResourceStream);
		}
		CommandBinding commandBinding = new CommandBinding(OKCommand, ExecuteOKCommand, CanExecuteOKCommand);
		CommandBinding commandBinding2 = new CommandBinding(CancelCommand, ExecuteCancelCommand);
		base.CommandBindings.Add(commandBinding);
		base.CommandBindings.Add(commandBinding2);
	}

	public void SetCaption(ref string caption)
	{
		caption = ApwnResources.BrowserTQCurves;
	}

	public void SetDefaultHeight(ref double defaultHeight)
	{
		defaultHeight = 350.0;
	}

	public void SetDefaultWidth(ref double defaultWidth)
	{
		defaultWidth = 300.0;
	}

	public void SetMinHeight(ref double minHeight)
	{
		minHeight = 350.0;
	}

	public void SetMinWidth(ref double minWidth)
	{
		minWidth = 300.0;
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		if (sFieldName.CompareTo(_tempUnitFieldId) == 0)
		{
			List<string> list = new List<string>();
			_help.LoadUnitsList(_context.Application.Tree, (IHWizardPlot)_wizardPlot, list);
			return list;
		}
		if (sFieldName.CompareTo(_dutyUnitFieldId) == 0)
		{
			List<string> list2 = new List<string>();
			_help.LoadXUnitsList(_context.Application.Tree, (IHWizardPlot)_wizardPlot, list2);
			return list2;
		}
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
		if (sFieldName.CompareTo(_tempUnitFieldId) == 0)
		{
			sCurrentVal = _help.GetUnitString(_context.Application.Tree, (IHWizardPlot)_wizardPlot);
		}
		else if (sFieldName.CompareTo(_dutyUnitFieldId) == 0)
		{
			sCurrentVal = _help.GetXUnitString(_context.Application.Tree, (IHWizardPlot)_wizardPlot);
		}
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
		if (sFieldName.CompareTo(_tempUnitFieldId) == 0)
		{
			_currentTempUnit = sValue;
		}
		else if (sFieldName.CompareTo(_dutyUnitFieldId) == 0)
		{
			_currentDutyUnit = sValue;
		}
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		if (sField.CompareTo(_tempUnitFieldId) == 0 || sField.CompareTo(_dutyUnitFieldId) == 0)
		{
			return (RibbonControlType)1;
		}
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
		sConfigValue = _currentConfigValue;
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
		_currentConfigValue = sValue;
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot2;
		IHNode iHNode = _context.FindNode("Output/DUTY_HOT");
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		List<string> list = new List<string>();
		for (int i = 0; i < iHNode.Elements.Count; i++)
		{
			list.Add(iHNode.Elements.get_Label(0, i, Type.Missing));
		}
		CurveList.SetCurves(list.ToArray());
		CurveList.Header = ApwnResources.BrowserTQCurves;
		CurveList.IsCheckAll = true;
		_bHasInputDialog = true;
		if (list.Count == 1)
		{
			_bHasInputDialog = false;
		}
		if (!string.IsNullOrEmpty(_currentConfigValue))
		{
			CurveList.IsCheckAll = false;
			RestoreConfigValue(_currentConfigValue);
			_bHasInputDialog = true;
		}
	}

	public void UpdateWizardData()
	{
		_wizardPlot.RemoveAllDependentVariable();
		List<string> list = new List<string>(CurveList.GetSelectedCurves());
		if (list.Count <= 0)
		{
			return;
		}
		int num = 0;
		for (int i = 0; i < list.Count; i++)
		{
			string text = list[i];
			_wizardPlot.SetIndependentVariable(_context, "Output/DUTY_HOT/" + text);
			_wizardPlot.AddDependentVariable(_context, "Output/TEMP_CLD/" + text);
			(_wizardPlot.PlotVal as IHPlotVal2).set_LineColor((short)num, (short)1);
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(num++, text + " " + PlotPWRResource.Heatx_TQCurve_ColdStream);
			_wizardPlot.AddDependentVariable(_context, "Output/TEMP_HOT/" + text);
			(_wizardPlot.PlotVal as IHPlotVal2).set_LineColor((short)num, (short)3);
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(num++, text + " " + PlotPWRResource.Heatx_TQCurve_HotStream);
		}
		_help.SaveUnitsComboText(_context.Application.Tree, (IHWizardPlot)_wizardPlot, _currentTempUnit);
		_help.SaveXUnitsComboText(_context.Application.Tree, (IHWizardPlot)_wizardPlot, _currentDutyUnit);
		_currentConfigValue = SaveConfigValue();
		_bHasInputDialog = true;
	}

	private void ExecuteOKCommand(object sender, ExecutedRoutedEventArgs e)
	{
		UpdateWizardData();
		_help.CloseForm((UserControl)this, (bool?)true);
	}

	private void CanExecuteOKCommand(object sender, CanExecuteRoutedEventArgs e)
	{
		int num = CurveList.GetSelectedCurves().Count();
		e.CanExecute = num != 0;
	}

	private void ExecuteCancelCommand(object sender, ExecutedRoutedEventArgs e)
	{
		if (!string.IsNullOrEmpty(_currentConfigValue))
		{
			RestoreConfigValue(_currentConfigValue);
		}
		_help.CloseForm((UserControl)this, (bool?)false);
	}

	private string SaveConfigValue()
	{
		_ = string.Empty;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("CurveSelection=");
		List<string> list = new List<string>(CurveList.GetSelectedCurves());
		int count = list.Count;
		for (int i = 0; i < count; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(",");
			}
			stringBuilder.Append(list[i]);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("CheckAll=");
		stringBuilder.Append(CurveList.IsCheckAll);
		stringBuilder.Append(";");
		return stringBuilder.ToString();
	}

	private void RestoreConfigValue(string ConfigString)
	{
		string[] array = ConfigString.Split(';');
		int num = 0;
		string text = array[num].Substring(array[num].IndexOf('=') + 1);
		string[] array2 = text.Split(',');
		List<string> list = new List<string>();
		string[] array3 = array2;
		foreach (string item in array3)
		{
			list.Add(item);
		}
		CurveList.SetSelectedCurves(list.ToArray());
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		if (list.Count != CurveList.Curves.Count)
		{
			CurveList.IsCheckAll = false;
		}
		else
		{
			CurveList.IsCheckAll = Convert.ToBoolean(text);
		}
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	public void InitializeComponent()
	{
		if (_contentLoaded)
		{
			return;
		}
		_contentLoaded = true;
		Uri resourceLocator = new Uri("/WpfPLHeatx;component/tqcurve.xaml", UriKind.Relative);
		Application.LoadComponent(this, resourceLocator);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		if (connectionId == 1)
		{
			CurveList = (CurvesSelectorControl)target;
		}
		else
		{
			_contentLoaded = true;
		}
	}
}
