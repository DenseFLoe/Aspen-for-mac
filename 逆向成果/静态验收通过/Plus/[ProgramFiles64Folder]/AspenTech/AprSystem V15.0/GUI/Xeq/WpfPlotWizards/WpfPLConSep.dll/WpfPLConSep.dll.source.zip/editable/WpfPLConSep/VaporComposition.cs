using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPlotwizard;

namespace WpfPLConSep;

[ProgId("WpfPLConSep.VaporComposition")]
public class VaporComposition : IRibbonPlotWizardType
{
	private IHNode _context;

	private IHWizardPlot _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private string _currentPresUnit = string.Empty;

	private string _uniqueId = "ConSep_VaporComposition";

	private string _plotName;

	private object _nodeCxs;

	private Image _imgBitmap;

	private bool _bHasInputDialog;

	private string _varName;

	private int _basis = 2;

	private bool _bCheckDataOnly;

	public string TooltipContentForRibbonItem => WpfPLConSepResources.TooltipContentForRibbonItem_Vapor;

	public string TooltipHeaderForRibbonItem => WpfPLConSepResources.TooltipHeaderForRibbonItem_Vapor;

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public object CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	public bool HasInputDialog => _bHasInputDialog;

	public string HelpFile => _help.GetHelpFileName();

	public long HelpID => _help.GetHelpID();

	public Image ImageIcon => _imgBitmap;

	public string Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	public List<string> SupportedDataFields => new List<string>();

	public List<string> SupportedStyleFields => new List<string>();

	public string TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	public object WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot;
		}
	}

	public VaporComposition()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		_varName = "Output\\Y";
		_bHasInputDialog = false;
		if (_imgBitmap == null)
		{
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLConSep.Images.composition.ico");
			_imgBitmap = new Bitmap(manifestResourceStream);
		}
	}

	public void Context(object oNode, ref object oPlotWizardComponent, ref int ierror)
	{
		if (oPlotWizardComponent == null || oNode == null)
		{
			ierror = 1;
			return;
		}
		_context = oNode as IHNode;
		_wizardPlot = oPlotWizardComponent as IHWizardPlot;
		IHNode iHNode = _context.FindNode(_varName);
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		_wizardPlot.RemoveAllDependentVariable();
		_wizardPlot.AddDependentVariable(_context, _varName);
		_wizardPlot.SetIndependentVariable(_context, _varName + "!Label");
	}

	public List<string> FieldDataOptionList(string sFieldName)
	{
		return new List<string>();
	}

	public void GetConfigData(ref string sConfigValue)
	{
	}

	public RibbonControlType GetFieldCtrlType(string sFieldName)
	{
		return (RibbonControlType)0;
	}

	public void GetFieldData(string sFieldName, ref string sCurrentVal)
	{
	}

	public void GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	public void SetConfigData(string sValue)
	{
	}

	public void SetFieldData(string sFieldName, string sValue)
	{
	}

	public void SetFieldStyle(string sFieldName, string sValue)
	{
	}

	public void ShowInputDialog()
	{
	}

	public void UpdateWizardData()
	{
		string text;
		IHNode iHNode2, iHNode3, iHNode;
		int count;
		if (_basis == 0)
		{
			iHNode = _context.FindNode("Input/IBASIS");
			if (iHNode != null)
			{
				_basis = (dynamic)iHNode.get_Value(Type.Missing) == "MOLE" ? 2 : 1;
			}
		}
		_wizardPlot.basis = _basis;
		text = "";
		if (_basis == 1)
		{
			text = "Mass";
		}
		else
		{
			text = "Mole";
		}
		_wizardPlot.PlotVal.Title = WpfPLConSepResources.LiquidProfile_Block + ": " + WpfPLConSepResources.LiquidProfile_Vapor_Profile + " (" + text + ")";
		_wizardPlot.basis = _basis;
		_wizardPlot.SetIndependentVariable(_context, "Output/STAGE_NO2");
		_wizardPlot.RemoveAllDependentVariable();
		iHNode2 = _context.FindNode("Output/COMPID");
		iHNode3 = _context.FindNode(_varName);
		if (iHNode2 != null && iHNode3 != null)
		{
			count = iHNode2.Elements.Count;
			_wizardPlot.PlotVal.NVariables = count;
			for (int i = 0; i < count; i++)
			{
				string label = (dynamic)iHNode2.Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
				((IHPlotVal)_wizardPlot.PlotVal).set_Label(i, label);
				int count2 = iHNode3.Elements.Count;
				for (int j = 0; j < count2; j++)
				{
					((IHPlotVal)_wizardPlot.PlotVal).set_YData(i, j, (short)1, (object)iHNode3.Elements[j, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing]);
				}
			}
		}
	}
}
