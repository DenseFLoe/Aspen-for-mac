using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLClassifier;

[RibbonPlotWizardMgr("WpfPLCLASSIFIER.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class ClassifierPlotWizardModule : PlotModuleBase
{
}
