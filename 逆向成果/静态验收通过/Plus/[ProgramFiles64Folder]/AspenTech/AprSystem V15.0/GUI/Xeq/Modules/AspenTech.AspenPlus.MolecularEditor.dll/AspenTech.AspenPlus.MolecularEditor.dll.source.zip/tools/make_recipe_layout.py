"""Generate a managed layout recipe (MethodDef RVA table + preserved CLR records).

The generated recipe is consumed by the archived token_replay.py / pe_layout.py pair:
the compiler emits the C# code, every verified method body is moved to its original
RVA, and the original #~ metadata blob, managed resource blob, debug record,
strong-name slot and certificate table are replayed onto the image.

generate() returns the recipe, the byte assets that must travel with it, and a
classification of every gap that prevents a byte-identical replay.
"""

from hashlib import sha256

import re

import pe_layout as layout
import clr_meta

GENERATED_NAME = re.compile(r"<.*>b__\d+_\d+")


class RecipeError(ValueError):
    """The pair cannot be described by the archived replay format."""


def _digest(data):
    return sha256(data).hexdigest()


def _sections(pe):
    return {section.Name.rstrip(b"\0").decode("ascii"):
            {"file_offset": section.PointerToRawData, "file_bytes": section.SizeOfRawData,
             "virtual_bytes": section.Misc_VirtualSize} for section in pe.sections}


def _body(pe, row):
    if not row["rva"]:
        return b""
    data = pe.get_data(row["rva"], row["body_bytes"])
    if len(data) != row["body_bytes"]:
        raise RecipeError("A CLI method extent exceeds the mapped PE section")
    return data


def _method_pairs(original, compiled):
    """Pair the original and compiled MethodDef RVA tables row by row."""
    pe_o, cli_o, root_o = clr_meta.read_image(original)
    pe_c, cli_c, root_c = clr_meta.read_image(compiled)
    rows_o = clr_meta.method_defs(pe_o, cli_o, root_o)
    rows_c = clr_meta.method_defs(pe_c, cli_c, root_c)
    if len(rows_o) != len(rows_c):
        raise RecipeError("MethodDef row counts differ: original %d, candidate %d"
                          % (len(rows_o), len(rows_c)))
    pairs, gaps = [], []
    for old, new in zip(rows_o, rows_c):
        old_name = clr_meta.strings(pe_o, cli_o, root_o, old["name_index"])
        new_name = clr_meta.strings(pe_c, cli_c, root_c, new["name_index"])
        same_name = old_name == new_name
        if not same_name and GENERATED_NAME.fullmatch(old_name) and GENERATED_NAME.fullmatch(new_name):
            # Roslyn numbers anonymous-method closures by source position; the source
            # export can reorder members, so require the same shape, not the same ordinal.
            same_name = True
        if not same_name or old["flags"] != new["flags"] or old["impl_flags"] != new["impl_flags"]:
            gaps.append({"kind": "declaration_gap", "token": "0x%08X" % old["token"], "name": old_name,
                         "detail": "MethodDef declaration order or flags differ"})
            continue
        if not old["rva"] and not new["rva"]:
            continue
        a, b = _body(pe_o, old), _body(pe_c, new)
        if a != b:
            first = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), min(len(a), len(b)))
            gaps.append({"kind": "source_form_gap", "token": "0x%08X" % old["token"], "name": old_name,
                         "original_bytes": len(a), "candidate_bytes": len(b),
                         "first_difference_offset": first,
                         "detail": "Compiler CIL body differs from the original body"})
            continue
        pairs.append({"original_token": "0x%08X" % old["token"], "candidate_token": "0x%08X" % new["token"],
                      "original_rva": old["rva"], "candidate_rva": new["rva"], "bytes": len(a),
                      "body_sha256": _digest(a), "remapped_tokens": []})
    return pe_o, cli_o, root_o, pe_c, cli_c, root_c, pairs, gaps


def generate(original, compiled, name=""):
    """Build the layout recipe and the preserved original records."""
    pe_o, mo = layout.identified_image(original)
    pe_c, mc = layout.identified_image(compiled)
    if pe_o.FILE_HEADER.Machine != pe_c.FILE_HEADER.Machine:
        raise RecipeError("Original and candidate machine types differ")
    sections = _sections(pe_o)
    text = layout.names(pe_o)[".text"]
    if mo["rva"] - text.VirtualAddress <= 0:
        raise RecipeError("CLR metadata is not inside the original .text section")
    prefix_size = mo["rva"] - text.VirtualAddress
    text_start = text.PointerToRawData
    original_pre = original[text_start:text_start + prefix_size]

    pe_o2, cli_o, root_o, pe_c2, cli_c, root_c, pairs, gaps = _method_pairs(original, compiled)
    metadata_offset = pe_o.get_offset_from_rva(mo["rva"])
    metadata = original[metadata_offset:metadata_offset + mo["size"]]
    if len(metadata) != mo["size"]:
        raise RecipeError("Original CLR metadata blob is not contiguous")

    resources = {"rva": cli_o["resource_rva"], "bytes": cli_o["resource_size"], "sha256": ""}
    resource_data = pe_o.get_data(cli_o["resource_rva"], cli_o["resource_size"]) if cli_o["resource_size"] else b""
    if len(resource_data) != cli_o["resource_size"]:
        raise RecipeError("Original managed resource extent exceeds its section")
    resources["sha256"] = _digest(resource_data)
    candidate_resource = (pe_c.get_data(cli_c["resource_rva"], cli_c["resource_size"])
                          if cli_c["resource_size"] else b"")
    if cli_c["resource_size"] != cli_o["resource_size"] \
            or _digest(candidate_resource) != resources["sha256"]:
        raise RecipeError("Compiler-emitted managed resources differ from the original")

    debug = layout.debug_tail(original, pe_o)
    debug_directory = pe_o.OPTIONAL_HEADER.DATA_DIRECTORY[6]
    emitted_debug = pe_c.OPTIONAL_HEADER.DATA_DIRECTORY[6]
    if emitted_debug.Size != debug_directory.Size:
        raise RecipeError("Candidate compiler debug directory size differs from the original")
    # A code-layout recipe relocates every method body and the CLR metadata blob, so the
    # compiler's debug directory sits at a different RVA; token_replay places the recorded
    # original debug record at the original RVA and finish_image validates the final bytes.

    signed = pe_o.OPTIONAL_HEADER.DATA_DIRECTORY[4]
    candidate_signed = pe_c.OPTIONAL_HEADER.DATA_DIRECTORY[4]
    if candidate_signed.Size or candidate_signed.VirtualAddress:
        raise RecipeError("Expected an unsigned compiler candidate")
    if not signed.Size or signed.VirtualAddress + signed.Size != len(original):
        raise RecipeError("Expected a single original certificate table at the end of the file")
    certificate = original[signed.VirtualAddress:]

    strong = None
    strong_name = b""
    if mo["strong_name_bytes"]:
        offset = pe_o.get_offset_from_rva(mo["strong_name_rva"])
        width = mo["strong_name_bytes"]
        strong_name = original[offset:offset + width]
        strong = {"file_offset": offset, "width": width, "signature_sha256": _digest(strong_name),
                  "payload_with_blank_strong_name_sha256":
                      layout.covered_hash(original, pe_o, signed.VirtualAddress,
                                          erase_strong_name=(offset, width))}

    stack = None
    if pe_o.OPTIONAL_HEADER.SizeOfStackReserve != pe_c.OPTIONAL_HEADER.SizeOfStackReserve:
        stack = {"compiler": pe_c.OPTIONAL_HEADER.SizeOfStackReserve,
                 "commit": pe_c.OPTIONAL_HEADER.SizeOfStackCommit,
                 "original": pe_o.OPTIONAL_HEADER.SizeOfStackReserve}

    recipe = {
        "original_sha256": _digest(original),
        "compiler_output_sha256": _digest(compiled),
        "original_metadata_sha256": _digest(metadata),
        "metadata_rva": mo["rva"],
        "emitted_metadata_rva": mc["rva"],
        "emitted_debug_rva": pe_c.OPTIONAL_HEADER.DATA_DIRECTORY[6].VirtualAddress,
        "original_pre_metadata_sha256": _digest(original_pre),
        "managed_resources": resources,
        "debug_rva": debug_directory.VirtualAddress,
        "debug_sha256": _digest(debug),
        "debug_directory_bytes": debug_directory.Size,
        "x86_bootstrap": layout.bootstrap(pe_o),
        "verified_methods": pairs,
        "strong_name_rva": mo["strong_name_rva"],
        "strong_name": strong,
        "authenticode_payload_sha256": layout.covered_hash(original, pe_o, signed.VirtualAddress),
        "certificate_sha256": _digest(certificate),
        "certificate_offset": signed.VirtualAddress,
        "certificate_size": signed.Size,
        "coff_timestamp": pe_o.FILE_HEADER.TimeDateStamp,
        "linker_major": pe_o.OPTIONAL_HEADER.MajorLinkerVersion,
        "linker_minor": pe_o.OPTIONAL_HEADER.MinorLinkerVersion,
        "original_checksum": pe_o.OPTIONAL_HEADER.CheckSum,
        "original_dll_characteristics": pe_o.OPTIONAL_HEADER.DllCharacteristics,
        "sections": sections,
        "module_guid": pe_o.get_data(mo["rva"] + mo["streams"]["#GUID"][0], 16).hex(),
        "guid_offset_inside_text": pe_o.get_offset_from_rva(mo["rva"]) + mo["streams"]["#GUID"][0] - text_start,
        "metadata_streams": {"rva": mo["rva"], "size": mo["size"],
                             "streams": {k: list(v) for k, v in mo["streams"].items()},
                             "strong_name_rva": mo["strong_name_rva"],
                             "strong_name_bytes": mo["strong_name_bytes"]},
        "methods_total": len(pairs) + len(gaps),
        "methods_matched": len(pairs),
        "replay_status": "ready" if not gaps else "blocked",
    }
    if stack:
        recipe["stack_reservation"] = stack
    assets = {"original-build/clr-metadata.bin": metadata,
              "original-build/debug-record.bin": debug,
              "original-build/certificate-table.bin": certificate}
    if strong:
        assets["original-build/strong-name.bin"] = strong_name
    public_key = clr_meta.assembly_public_key(pe_o, cli_o, root_o)
    if public_key:
        assets["build/assembly-public-key.snk"] = public_key
    report = {"name": name, "original_sha256": recipe["original_sha256"],
              "compiler_output_sha256": recipe["compiler_output_sha256"],
              "methods_total": recipe["methods_total"], "methods_matched": len(pairs),
              "gaps": gaps,
              "gap_kinds": sorted({gap["kind"] for gap in gaps})}
    return recipe, assets, report