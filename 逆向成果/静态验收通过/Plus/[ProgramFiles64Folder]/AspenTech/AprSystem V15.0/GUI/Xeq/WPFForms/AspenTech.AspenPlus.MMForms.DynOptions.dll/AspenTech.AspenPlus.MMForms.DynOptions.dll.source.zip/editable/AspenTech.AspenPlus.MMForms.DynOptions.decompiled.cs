using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using AspenTech.AspenCxs;
using AspenTech.AspenCxs.CxsViewModel;
using AspenTech.AspenPlus.MMControls;
using AspenTech.WpfControls.Engineering;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.MMForms.DynOptions")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.MMForms.DynOptions")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology 2010 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/dynoptions", "AspenTech.AspenPlus.MMForms.DynOptions")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]
namespace XamlGeneratedNamespace
{
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class GeneratedInternalTypeHelper : InternalTypeHelper
	{
		protected override object CreateInstance(Type type, CultureInfo culture)
		{
			return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.CreateInstance, null, null, culture);
		}

		protected override object GetPropertyValue(PropertyInfo propertyInfo, object target, CultureInfo culture)
		{
			return propertyInfo.GetValue(target, BindingFlags.Default, null, null, culture);
		}

		protected override void SetPropertyValue(PropertyInfo propertyInfo, object target, object value, CultureInfo culture)
		{
			propertyInfo.SetValue(target, value, BindingFlags.Default, null, null, culture);
		}

		protected override Delegate CreateDelegate(Type delegateType, object target, string handler)
		{
			return (Delegate)target.GetType().InvokeMember("_CreateDelegate", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, target, new object[2] { delegateType, handler }, null);
		}

		protected override void AddEventHandler(EventInfo eventInfo, object target, Delegate handler)
		{
			eventInfo.AddEventHandler(target, handler);
		}
	}
}
namespace AspenTech.AspenPlus.MMForms.DynOptions
{
	public class MMDynOption_Dyopti_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration ccdyn_Property = CxvPropertyDeclaration.Register("ccdyn", typeof(MMDynOption_Dyopti_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.CCDYN"
		});

		public static readonly CxvPropertyDeclaration DYNOPTENT_Property = CxvPropertyDeclaration.Register("DYNOPTENT", typeof(MMDynOption_Dyopti_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.DYNOPTENT"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMDynOption_Dyopti_ViewModel), new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@ccdyn" },
			EnteredDataPaths = { "@DYNOPTENT" }
		});

		public object ccdyn => GetValue(ccdyn_Property);

		public object DYNOPTENT => GetValue(DYNOPTENT_Property);

		public object tab0_var => GetValue(tab0_var_Property);

		protected override void OnUpdateData()
		{
			base.OnUpdateData();
			if (base.IsInitialUpdate)
			{
				ResolveUpdateParameter("NotNeedName", "NotNull");
				ResolveUpdateParameter("NotNeedType", "NotNull");
			}
		}
	}
	[ProgId("MMDynOption.MMDynOption_Dyopti")]
	public class MMDynOption_Dyopti : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabInput;

		internal MMTabItem tab0;

		internal MMTabItem tabInfo;

		private bool _contentLoaded;

		public MMDynOption_Dyopti()
		{
			base.ViewModelType = typeof(MMDynOption_Dyopti_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.DynOptions;component/mmdynoption_dyopti.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				tabInput = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tabInfo = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDynOption_Dyopti_Compon_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMOptionGroup1_MultiMap_Property = CxvPropertyDeclaration.Register("MMOptionGroup1_MultiMap", typeof(MMDynOption_Dyopti_Compon_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "MMOptionGroup1_opt_comp",
					DataPath = "@main.Input.OPT_COMP"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Use all components in dynamic simulation",
					DisplayResourceKey = "MMDynOption_Dyopti_Compon_ViewModel__CxvMultiMapOption_Display_Use_all_components_in_dynamic_simulat",
					Value = "MMOptionGroup1_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMOptionGroup1_opt_comp",
							Value = "INCLUDEALL"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Remove unused components from dynamic simulation",
					DisplayResourceKey = "MMDynOption_Dyopti_Compon_ViewModel__CxvMultiMapOption_Display_Remove_unused_components_from_dynamic",
					Value = "MMOptionGroup1_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMOptionGroup1_opt_comp",
							Value = "REMOVEUNUSED"
						}
					}
				}
			}
		});

		public static readonly CxvPropertyDeclaration lpDynComps_state_Property = CxvPropertyDeclaration.Register("lpDynComps_state", typeof(MMDynOption_Dyopti_Compon_ViewModel), new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.REMOVECOMPS"
			}
		});

		public static readonly CxvPropertyDeclaration lpDynComps_comp_Property = CxvPropertyDeclaration.Register("lpDynComps_comp", typeof(MMDynOption_Dyopti_Compon_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.List,
			DataPath = "@main.Input.COMP",
			AllowSort = false
		});

		public object MMOptionGroup1_MultiMap => GetValue(MMOptionGroup1_MultiMap_Property);

		public object lpDynComps_state => GetValue(lpDynComps_state_Property);

		public object lpDynComps_comp => GetValue(lpDynComps_comp_Property);

		protected override void OnSubPropertyDataChanged(CxvPropertyDeclaration pd, string subPropertyName)
		{
			base.OnSubPropertyDataChanged(pd, subPropertyName);
			if (pd == MMOptionGroup1_MultiMap_Property && subPropertyName == "Value" && CxsConverter.ValueToString(ExpandDataPathAndGet("@main.Input.OPT_COMP", "value")) == "INCLUDEALL" && base.View is MMDynOption_Dyopti_Compon mMDynOption_Dyopti_Compon)
			{
				AesListPicker lpDynComps = mMDynOption_Dyopti_Compon.lpDynComps;
				if (lpDynComps != null)
				{
					(lpDynComps.Template.FindName("Part_OptionsBox", lpDynComps) as ListBox).SelectedItems.Clear();
				}
			}
		}
	}
	[ProgId("MMDynOption.MMDynOption_Dyopti_Compon")]
	public class MMDynOption_Dyopti_Compon : MMTabPage, IComponentConnector
	{
		internal MMOptionGroup MMOptionGroup1;

		internal MMOptionButton MMOptionGroup1_opt0;

		internal MMOptionButton MMOptionGroup1_opt1;

		internal MMListPicker lpDynComps;

		private bool _contentLoaded;

		public MMDynOption_Dyopti_Compon()
		{
			base.ViewModelType = typeof(MMDynOption_Dyopti_Compon_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.DynOptions;component/mmdynoption_dyopti_compon.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				MMOptionGroup1 = (MMOptionGroup)target;
				break;
			case 2:
				MMOptionGroup1_opt0 = (MMOptionButton)target;
				break;
			case 3:
				MMOptionGroup1_opt1 = (MMOptionButton)target;
				break;
			case 4:
				lpDynComps = (MMListPicker)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
}
