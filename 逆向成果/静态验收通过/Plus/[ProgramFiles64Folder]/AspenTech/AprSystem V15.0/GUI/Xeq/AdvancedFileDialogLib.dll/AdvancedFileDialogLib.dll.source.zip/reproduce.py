#!/usr/bin/env python3
"""Assemble editable CIL independently, or re-emit it in the original PE layout."""
import argparse
import json
import os
import shutil
import subprocess
import sys
from hashlib import sha256
from pathlib import Path

HERE = Path(__file__).resolve().parent
TOOLS = HERE / "tools"
sys.path[:0] = [str(TOOLS), str(TOOLS / "vendor")]
import pin_mvid
import normalize_unnamed_parameter

NAME = "AdvancedFileDialogLib.dll"
PLAN = json.loads((HERE / "build-plan.json").read_text(encoding="utf-8"))


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def run(command, cwd=None):
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
    subprocess.run([str(arg) for arg in command], cwd=cwd, env=env, check=True)


def strip_public_key(text):
    """Keep the assembly public key in source, omit it in the replay intermediate."""
    output = []
    depth = 0
    for line in text.splitlines(keepends=True):
        if depth or line.lstrip().startswith(".publickey ="):
            depth += line.count("(") - line.count(")")
        else:
            output.append(line)
    if depth:
        raise ValueError("unterminated assembly public key")
    return "".join(output)


def main():
    default_ilasm = (
        Path(os.environ.get("SystemRoot", r"C:\Windows"))
        / "Microsoft.NET" / "Framework64" / "v4.0.30319" / "ilasm.exe"
    )
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("source", "replay"), default="source")
    parser.add_argument("--out", required=True, type=Path, help="new output directory")
    parser.add_argument("--ilasm", type=Path, default=default_ilasm)
    parser.add_argument("--original", type=Path, help="original DLL, required for replay only")
    args = parser.parse_args()
    if args.mode == "replay":
        if args.original is None:
            parser.error("--original is required for replay")
        original = args.original.resolve(strict=True)
        if digest(original) != PLAN["original_sha256"]:
            parser.error("original DLL SHA-256 differs from the replay record")
        for name, expected in PLAN["replay_input_sha256"].items():
            if digest(HERE / name) != expected:
                parser.error("replay input SHA-256 differs: " + name)
    elif args.original is not None:
        parser.error("source assembly takes no original DLL")
    ilasm = args.ilasm.resolve(strict=True)
    ilasm_digest = digest(ilasm)
    if args.mode == "replay" and ilasm_digest != PLAN["ilasm_sha256"]:
        parser.error("replay requires the recorded ILASM executable SHA-256")

    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    src = out / "assembly-input"
    src.mkdir()
    source = (HERE / "editable" / (NAME + ".il")).read_text(encoding="utf-8-sig")
    if args.mode == "replay":
        source = strip_public_key(source)
    (src / "AdvancedFileDialogLib.input.il").write_text(source, encoding="utf-8", newline="")
    shutil.copyfile(HERE / "resources" / "original.res", src / "original.res")
    options = (HERE / "compile.rsp").read_text(encoding="utf-8").split()
    run([ilasm, *options], cwd=src)
    assembled = out / NAME
    if args.mode == "source":
        identity = sha256((src / "AdvancedFileDialogLib.input.il").read_bytes()
                          + (src / "original.res").read_bytes()).digest()
        mvid = bytearray(identity[:16])
        mvid[7] = (mvid[7] & 0x0F) | 0x50
        mvid[8] = (mvid[8] & 0x3F) | 0x80
        pin_mvid.main(str(src / "cand-asm.dll"), str(assembled), bytes(mvid))
        unnamed = (
            "Build directive: unnamed-event-provider-constructor-argument" in source
            and normalize_unnamed_parameter.normalize(assembled)
        )
    else:
        pin_mvid.main(str(src / "cand-asm.dll"), str(assembled))
        unnamed = False

    report = {
        "mode": args.mode,
        "ilasm_sha256": ilasm_digest,
        "source_sha256": digest(HERE / "editable" / (NAME + ".il")),
        "resource_input_sha256": digest(src / "original.res"),
        "assembled": assembled.name,
        "assembled_sha256": digest(assembled),
        "removed_ilasm_synthetic_param_name": unnamed,
    }
    if args.mode == "replay":
        translated = out / "tokens-translated-for-original-metadata.dll"
        position_report = out / "position-report.json"
        run([
            sys.executable, "-B", TOOLS / "patch_by_position.py", original, assembled,
            HERE / "evidence" / "operand-positions.json", translated, position_report,
        ])
        positions = json.loads(position_report.read_text(encoding="utf-8"))
        if positions["body_mismatch_count"]:
            raise SystemExit("source-derived method bodies differ after replay token translation")
        final = out / "replayed" / NAME
        run([sys.executable, "-B", TOOLS / "replay_final.py", HERE, translated, final])
        report.update({
            "original_sha256": digest(original),
            "token_translated_sha256": digest(translated),
            "token_edits": positions["patched"],
            "replayed": final.relative_to(out).as_posix(),
            "replayed_sha256": digest(final),
        })
    (out / "build-report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()

