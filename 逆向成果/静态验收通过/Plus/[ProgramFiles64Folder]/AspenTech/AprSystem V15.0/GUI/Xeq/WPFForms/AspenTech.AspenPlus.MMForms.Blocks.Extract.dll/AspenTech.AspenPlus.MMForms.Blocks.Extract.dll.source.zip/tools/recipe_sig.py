"""Recipe generation with declaration-signature pairing (order-independent).

The stock make_recipe_layout pairs MethodDef rows by table index, so any source
member-order difference (a very common ILSpy artifact for MMForms forms) shows up
as a declaration_gap even though every body is identical.  The replay format
places each verified candidate body at the original RVA, so pairing may be done
by declaration (name + signature blob) and, for generated names (lambdas), by
body equality instead.

Usage: recipe_sig.py <sha8> [--replay]

Writes <work>/<sha8>/recipe.json, recipe-report.json, assets/, exact/<name>.
Exit 0 only when the recipe is ready and (with --replay) the replayed image is
byte-identical to the original.
"""
import json, re, sys
from hashlib import sha256
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
HOME = BASE / "managed-byte-recovery"
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE)); sys.path.insert(0, str(HOME)); sys.path.insert(0, str(TOOLS))
sys.path.insert(0, str(BASE / "router" / "managed"))
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")

import clr_meta
import make_recipe_layout as mrl
from tokens import Image, body_diff_map

WORK = TOOLS.parent
LEDGER = {}
for line in open(BASE / "per-file.jsonl", encoding="utf-8"):
    r = json.loads(line)
    LEDGER[r["sha256"]] = r


def _params(pe, cli, root, rows):
    # owner typedef full name per MethodDef row (TypeDef.FirstMethod ranges)
    tables = root["tables"]
    type_rows = tables["layout"][0x02]["rows"] if 0x02 in tables["layout"] else 0
    method_rows = tables["layout"][0x06]["rows"]
    owners = {}
    bounds = []
    for t in range(1, type_rows + 1):
        row = clr_meta.read_row(root["bytes"], tables, 0x02, t)
        bounds.append((row[5], t))
    bounds.sort()
    for idx, (first, t) in enumerate(bounds):
        last = bounds[idx + 1][0] if idx + 1 < len(bounds) else method_rows + 1
        trow = clr_meta.read_row(root["bytes"], tables, 0x02, t)
        name = clr_meta.strings(pe, cli, root, trow[1])
        ns = clr_meta.strings(pe, cli, root, trow[2])
        for m in range(first, last):
            owners[m] = (ns + "." if ns else "") + name
    out = []
    for r in rows:
        name = clr_meta.strings(pe, cli, root, r["name_index"])
        sig = clr_meta.blob(pe, cli, root, r["signature_index"])
        out.append((r, name, sig, owners.get(r["row"], "")))
    return out


def _method_pairs(original, compiled):
    pe_o, cli_o, root_o = clr_meta.read_image(original)
    pe_c, cli_c, root_c = clr_meta.read_image(compiled)
    rows_o = clr_meta.method_defs(pe_o, cli_o, root_o)
    rows_c = clr_meta.method_defs(pe_c, cli_c, root_c)
    po = _params(pe_o, cli_o, root_o, rows_o)
    pc = _params(pe_c, cli_c, root_c, rows_c)
    pairs, gaps = [], []
    owner_by_row = {r["row"]: own for r, _n, _s, own in po}

    # Phase 1: owner + name + signature blob, preserving RVA order inside a key.
    group_o, group_c = {}, {}
    for row, name, sig, owner in po:
        group_o.setdefault((owner, name, sig), []).append(row)
    for row, name, sig, owner in pc:
        group_c.setdefault((owner, name, sig), []).append(row)
    used_o, used_c = set(), set()
    token_map = {}
    key_by_row_o, key_by_row_c = {}, {}
    img_o, img_c = Image(original, "orig"), Image(compiled, "cand")

    def semantic_diff(a, b):
        rem, left = body_diff_map(img_o, img_c, a, b)
        if left or not rem:
            r2, l2 = body_diff_lenient(img_o, img_c, a, b)
            if not l2 and r2:
                return r2, []
        return rem, left

    for key, olds in group_o.items():
        news = group_c.get(key, [])
        for old in olds:
            key_by_row_o[old["row"]] = key
        for new in news:
            key_by_row_c[new["row"]] = key
        for old, new in zip(olds, news):
            a, b = mrl._body(pe_o, old), mrl._body(pe_c, new)
            if a != b:
                continue
            pairs.append(_pair(old, new, a, []))
            used_o.add(old["row"]); used_c.add(new["row"])
            token_map[new["token"]] = old["token"]

    # Phase 1b: same declaration key, body differs only in member/type token
    # operands (metadata table order).  Owner-scoped, so it cannot steal a
    # candidate that belongs to another declaring type.
    for key, olds in group_o.items():
        news = group_c.get(key, [])
        for old, new in zip(olds, news):
            if old["row"] in used_o or new["row"] in used_c:
                continue
            a, b = mrl._body(pe_o, old), mrl._body(pe_c, new)
            if len(a) != len(b):
                continue
            remaps, leftover = semantic_diff(a, b)
            if leftover or not remaps:
                continue
            pairs.append(_pair(old, new, a, remaps))
            used_o.add(old["row"]); used_c.add(new["row"])
            token_map[new["token"]] = old["token"]

    # Phase 1c: within a declaration key whose candidate order differs from the
    # original, greedy all-vs-all semantic body matching.
    for key, olds in group_o.items():
        news = group_c.get(key, [])
        if len(olds) != len(news):
            continue
        for old in olds:
            if old["row"] in used_o:
                continue
            a = mrl._body(pe_o, old)
            for new in news:
                if new["row"] in used_c:
                    continue
                b = mrl._body(pe_c, new)
                if len(a) != len(b):
                    continue
                remaps, leftover = semantic_diff(a, b)
                if leftover or not remaps:
                    continue
                pairs.append(_pair(old, new, a, remaps))
                used_o.add(old["row"]); used_c.add(new["row"])
                token_map[new["token"]] = old["token"]
                break

    # Phase 2: identical body bytes (covers generated lambda names).
    rest_o = [r for r in rows_o if r["row"] not in used_o]
    rest_c = [r for r in rows_c if r["row"] not in used_c]
    name_o = {row["row"]: (nm, owner) for row, nm, _sig, owner in po}
    name_c = {row["row"]: (nm, owner) for row, nm, _sig, owner in pc}
    # 2a: same declared name (any owner) + identical body; 2b: any name.
    by_key = {}
    for new in rest_c:
        by_key.setdefault(name_c[new["row"]], []).append(new)
    still_o = []
    for old in rest_o:
        a = mrl._body(pe_o, old)
        bucket = [n for n in by_key.get(name_o[old["row"]], [])
                  if n["row"] not in used_c and mrl._body(pe_c, n) == a]
        if bucket:
            new = bucket.pop(0)
            used_c.add(new["row"])
            pairs.append(_pair(old, new, a, []))
            token_map[new["token"]] = old["token"]
        else:
            still_o.append(old)
    rest_c = [r for r in rows_c if r["row"] not in used_c]
    by_body = {}
    for new in rest_c:
        by_body.setdefault(mrl._body(pe_c, new), []).append(new)
    phase2b = []
    for old in still_o:
        a = mrl._body(pe_o, old)
        bucket = by_body.get(a)
        if bucket:
            new = bucket.pop(0)
            used_c.add(new["row"])
            pairs.append(_pair(old, new, a, []))
            token_map[new["token"]] = old["token"]
        else:
            phase2b.append(old)
    still_o = phase2b

    # Phase 3: patch candidate MethodDef token operands through token_map, then
    # compare with the original body; remaining candidate tokens are resolved
    # through the semantic token diff.
    def remap_by_token_map(body, cmap):
        out = bytearray(body)
        remaps = []
        for at in range(0, len(out) - 3):
            val = int.from_bytes(out[at:at + 4], "little")
            if val in cmap:
                remaps.append({"method_offset": at, "candidate_token": val,
                               "original_token": cmap[val]})
                out[at:at + 4] = cmap[val].to_bytes(4, "little")
        return bytes(out), remaps

    img_o, img_c = Image(original, "orig"), Image(compiled, "cand")
    rest_c = [r for r in rows_c if r["row"] not in used_c]
    remaining = []
    for old in still_o:
        a = mrl._body(pe_o, old)
        matched = None
        for new in rest_c:
            b = mrl._body(pe_c, new)
            if len(a) != len(b):
                continue
            patched, remaps = remap_by_token_map(b, token_map)
            if patched == a and remaps:
                matched = (new, remaps)
                break
            remaps2, leftover = semantic_diff(a, b)
            if not leftover and remaps2:
                matched = (new, remaps2)
                break
        if matched:
            new, remaps = matched
            rest_c.remove(new)
            used_c.add(new["row"])
            pairs.append(_pair(old, new, a, remaps))
        else:
            # Phase 3b: same declaration key, body differs but every token
            # operand resolves semantically.  Replay still has to reproduce the
            # original bytes, so a wrong body cannot pass.
            key = key_by_row_o.get(old["row"])
            new = next((n for n in rest_c if key_by_row_c.get(n["row"]) == key), None)
            remaps2 = []
            if new is not None:
                b = mrl._body(pe_c, new)
                remaps2, _leftover = semantic_diff(a, b) if len(a) == len(b) else ([], [])
            if new is not None and remaps2:
                rest_c.remove(new)
                used_c.add(new["row"])
                pairs.append(_pair(old, new, a, remaps2))
            else:
                remaining.append({"kind": "source_form_gap", "token": "0x%08X" % old["token"],
                                  "name": clr_meta.strings(pe_o, cli_o, root_o, old["name_index"]),
                                  "owner": owner_by_row.get(old["row"]),
                                  "detail": "No candidate method body reproduces the original body"})
    pairs.sort(key=lambda p: int(p["original_token"], 16))
    return pe_o, cli_o, root_o, pe_c, cli_c, root_c, pairs, remaining


LAMBDA = re.compile(r"^(M:.*\|)([^|]*b__)(\d+)(_\d+\|.*)$")


def _lam_key(img, token):
    k = img.token_key(token)
    m = LAMBDA.match(k)
    if m:
        return m.group(1) + m.group(2) + "#" + m.group(4)
    return k


def body_diff_lenient(img_o, img_c, a, b):
    """Like tokens.body_diff_map but ignores the compiler's lambda ordinal."""
    import struct
    if len(a) != len(b):
        return [], [{"reason": "length"}]
    diffs = [i for i in range(len(a)) if a[i] != b[i]]
    if not diffs:
        return [], []
    used, remaps, leftover = set(), [], []
    for pos in diffs:
        if pos in used:
            continue
        found = False
        for start in (pos, pos - 1, pos - 2, pos - 3):
            if start < 0 or start + 4 > len(a) or start in used:
                continue
            o = struct.unpack_from("<I", a, start)[0]
            c = struct.unpack_from("<I", b, start)[0]
            if o == c:
                continue
            try:
                if not (img_o.valid_token(o) and img_c.valid_token(c)):
                    continue
                if _lam_key(img_o, o) != _lam_key(img_c, c):
                    continue
            except Exception:
                continue
            remaps.append({"method_offset": start, "candidate_token": c,
                           "original_token": o, "semantic_key": "lambda-normalized"})
            used.update(range(start, start + 4))
            found = True
            break
        if not found and pos not in used:
            leftover.append({"offset": pos})
            used.add(pos)
    return remaps, leftover


def _pair(old, new, body, remaps):
    return {"original_token": "0x%08X" % old["token"], "candidate_token": "0x%08X" % new["token"],
            "original_rva": old["rva"], "candidate_rva": new["rva"], "bytes": len(body),
            "body_sha256": sha256(body).hexdigest(), "remapped_tokens": remaps}


def _reemit_ok(body, remaps):
    import pe_layout
    pair = {"original_rva": 0, "candidate_rva": 0, "bytes": len(body),
            "remapped_tokens": remaps}
    try:
        patched = pe_layout.reemit_method(body, pair)
    except Exception:
        return False
    return len(patched) == len(body)


def run(sha8, replay):
    sha = next(s for s in LEDGER if s.startswith(sha8))
    r = LEDGER[sha]
    orig = Path(r["installed_location"]).read_bytes()
    cand = (WORK / sha8 / "out" / r["name"]).read_bytes()
    saved = mrl._method_pairs
    mrl._method_pairs = _method_pairs
    try:
        recipe, assets, report = mrl.generate(orig, cand, r["name"])
    finally:
        mrl._method_pairs = saved
    d = WORK / sha8
    (d / "recipe.json").write_text(json.dumps(recipe, ensure_ascii=False, indent=1), encoding="utf-8")
    (d / "recipe-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    adir = d / "assets"; adir.mkdir(exist_ok=True)
    for k, v in assets.items():
        (adir / k.replace("/", "__")).write_bytes(v)
    print("status", recipe["replay_status"], "matched", recipe["methods_matched"], "/", recipe["methods_total"],
          "gaps", len(report["gaps"]))
    for g in report["gaps"][:15]:
        print("  GAP", g.get("token"), g.get("owner"), g.get("name"), g.get("detail"))
    if recipe["replay_status"] != "ready":
        return 2
    if not replay:
        return 0
    import token_replay_mm as token_replay
    data = token_replay.reproduce(cand, recipe, assets["original-build/clr-metadata.bin"],
                                  assets["original-build/debug-record.bin"],
                                  assets["original-build/certificate-table.bin"],
                                  assets["original-build/strong-name.bin"] if recipe["strong_name"] else b"")
    ed = d / "exact"; ed.mkdir(exist_ok=True)
    (ed / r["name"]).write_bytes(data)
    eq = data == orig
    print("exact sha", sha256(data).hexdigest(), "len", len(data), "EQUAL", eq)
    return 0 if eq else 3


if __name__ == "__main__":
    sys.exit(run(sys.argv[1], "--replay" in sys.argv[2:]))
