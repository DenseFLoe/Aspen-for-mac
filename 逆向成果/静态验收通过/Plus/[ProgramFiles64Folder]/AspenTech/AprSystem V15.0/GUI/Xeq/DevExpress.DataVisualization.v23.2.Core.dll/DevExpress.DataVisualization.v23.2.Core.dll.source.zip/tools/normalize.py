"""Normalize a Roslyn /debug+ candidate so its SHA-256 is independent of the
build directory.

Path-dependent compiler outputs are the COFF TimeDateStamp (deterministic flag
derives it from content, which includes the PDB path), the module MVID (#GUID),
the strong-name signature and the CodeView debug record. All of these are
replayed verbatim from the original in the replay step, so the candidate's
copies are zeroed before hashing/comparing. Code, tables and the x86 import
stub are left intact.
"""
import struct
import pefile
import pe_layout


def normalize(data):
    pe, meta = pe_layout.identified_image(bytes(data))
    buf = bytearray(data)
    # COFF TimeDateStamp
    t = pe.FILE_HEADER.get_field_absolute_offset("TimeDateStamp")
    buf[t:t + 4] = bytes(4)
    # module MVID (#GUID stream)
    g_off, g_size = meta["streams"]["#GUID"]
    g_at = pe.get_offset_from_rva(meta["rva"]) + g_off
    buf[g_at:g_at + min(16, g_size)] = bytes(min(16, g_size))
    # strong-name signature
    if meta.get("strong_name_bytes"):
        off = pe.get_offset_from_rva(meta["strong_name_rva"])
        buf[off:off + meta["strong_name_bytes"]] = bytes(meta["strong_name_bytes"])
    # debug directory entries + their raw CodeView records
    d = pe.OPTIONAL_HEADER.DATA_DIRECTORY[6]
    if d.Size:
        base = pe.get_offset_from_rva(d.VirtualAddress)
        for i in range(d.Size // 28):
            e = base + i * 28
            size, raw = struct.unpack_from("<II", buf, e + 16)
            ptr = struct.unpack_from("<I", buf, e + 24)[0]
            buf[e:e + 28] = bytes(28)
            if ptr and size:
                buf[ptr:ptr + size] = bytes(size)
    return bytes(buf)
