﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  XamlGeneratedNamespace.GeneratedInternalTypeHelper
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_ViewModel
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.DyanmicAxHost
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate
  AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern PresentationFramework
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern System.Xaml
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern System
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern WindowsBase
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern AspenTech.AspenPlus.MMControls
{
  .ver 41:0:0:614
}
.assembly extern AspenTech.AspenCxs.CxsViewModel
{
  .ver 41:0:0:0
}
.assembly extern Microsoft.Practices.Composite.Presentation
{
  .publickeytoken = (8A F4 53 88 06 95 A9 B8 )                         // ..S.....
  .ver 2:0:1:0
}
.assembly extern System.Windows.Forms
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern AspenTech.AspenCxs
{
  .publickeytoken = (5D 73 34 E0 D1 73 8A D6 )                         // ]s4..s..
  .ver 41:0:0:57
}
.assembly extern WindowsFormsIntegration
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern AspenTech.AspenPlus.Localization
{
  .ver 41:0:0:614
}
.assembly extern AspenTech.AspenPlus.MMForms.Convergence
{
  .ver 41:0:0:614
}
.assembly AspenTech.AspenPlus.MMForms.Blocks.ACMModel
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.

  // --- The following custom attribute is added automatically, do not uncomment -------
  //  .custom instance void [mscorlib]System.Diagnostics.DebuggableAttribute::.ctor(valuetype [mscorlib]System.Diagnostics.DebuggableAttribute/DebuggingModes) = ( 01 00 02 00 00 00 00 00 ) 

  .custom instance void [mscorlib]System.Reflection.AssemblyFileVersionAttribute::.ctor(string) = ( 01 00 0A 34 31 2E 30 2E 30 2E 36 31 34 00 00 )    // ...41.0.0.614..
  .custom instance void [mscorlib]System.Reflection.AssemblyTitleAttribute::.ctor(string) = ( 01 00 2B 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..+AspenTech.Asp
                                                                                              65 6E 50 6C 75 73 2E 4D 4D 46 6F 72 6D 73 2E 42   // enPlus.MMForms.B
                                                                                              6C 6F 63 6B 73 2E 41 43 4D 4D 6F 64 65 6C 00 00 ) // locks.ACMModel..
  .custom instance void [mscorlib]System.Reflection.AssemblyDescriptionAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyConfigurationAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyCompanyAttribute::.ctor(string) = ( 01 00 16 41 73 70 65 6E 20 54 65 63 68 6E 6F 6C   // ...Aspen Technol
                                                                                                6F 67 79 2C 20 49 6E 63 2E 00 00 )                // ogy, Inc...
  .custom instance void [mscorlib]System.Reflection.AssemblyProductAttribute::.ctor(string) = ( 01 00 2B 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..+AspenTech.Asp
                                                                                                65 6E 50 6C 75 73 2E 4D 4D 46 6F 72 6D 73 2E 42   // enPlus.MMForms.B
                                                                                                6C 6F 63 6B 73 2E 41 43 4D 4D 6F 64 65 6C 00 00 ) // locks.ACMModel..
  .custom instance void [mscorlib]System.Reflection.AssemblyCopyrightAttribute::.ctor(string) = ( 01 00 19 43 6F 70 79 72 69 67 68 74 20 C2 A9 20   // ...Copyright .. 
                                                                                                  20 32 30 31 30 20 2D 20 32 30 32 34 00 00 )       //  2010 - 2024..
  .custom instance void [mscorlib]System.Reflection.AssemblyTrademarkAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Resources.NeutralResourcesLanguageAttribute::.ctor(string,
                                                                                            valuetype [mscorlib]System.Resources.UltimateResourceFallbackLocation) = ( 01 00 05 65 6E 2D 55 53 01 00 00 00 00 00 )       // ...en-US......
  .custom instance void [PresentationFramework]System.Windows.ThemeInfoAttribute::.ctor(valuetype [PresentationFramework]System.Windows.ResourceDictionaryLocation,
                                                                                        valuetype [PresentationFramework]System.Windows.ResourceDictionaryLocation) = ( 01 00 00 00 00 00 01 00 00 00 00 00 ) 
  .custom instance void [System.Xaml]System.Windows.Markup.XmlnsDefinitionAttribute::.ctor(string,
                                                                                           string) = ( 01 00 47 68 74 74 70 3A 2F 2F 73 63 68 65 6D 61   // ..Ghttp://schema
                                                                                                       73 2E 61 73 70 65 6E 74 65 63 68 2E 63 6F 6D 2F   // s.aspentech.com/
                                                                                                       78 61 6D 6C 2F 70 72 65 73 65 6E 74 61 74 69 6F   // xaml/presentatio
                                                                                                       6E 2F 61 73 70 65 6E 70 6C 75 73 2F 66 6F 72 6D   // n/aspenplus/form
                                                                                                       73 2F 61 63 6D 6D 6F 64 65 6C 2B 41 73 70 65 6E   // s/acmmodel+Aspen
                                                                                                       54 65 63 68 2E 41 73 70 65 6E 50 6C 75 73 2E 4D   // Tech.AspenPlus.M
                                                                                                       4D 46 6F 72 6D 73 2E 42 6C 6F 63 6B 73 2E 41 43   // MForms.Blocks.AC
                                                                                                       4D 4D 6F 64 65 6C 00 00 )                         // MModel..
  .custom instance void [mscorlib]System.Runtime.Versioning.TargetFrameworkAttribute::.ctor(string) = ( 01 00 1A 2E 4E 45 54 46 72 61 6D 65 77 6F 72 6B   // ....NETFramework
                                                                                                        2C 56 65 72 73 69 6F 6E 3D 76 34 2E 38 01 00 54   // ,Version=v4.8..T
                                                                                                        0E 14 46 72 61 6D 65 77 6F 72 6B 44 69 73 70 6C   // ..FrameworkDispl
                                                                                                        61 79 4E 61 6D 65 12 2E 4E 45 54 20 46 72 61 6D   // ayName..NET Fram
                                                                                                        65 77 6F 72 6B 20 34 2E 38 )                      // ework 4.8
  .hash algorithm 0x00008004
  .ver 41:0:0:614
}
.module AspenTech.AspenPlus.MMForms.Blocks.ACMModel.dll
// MVID: {63f1ab5f-95fa-4c08-a50c-6fcc2fdaaacf}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000001    //  ILONLY
// Image base: 0x000001D3E04B0000


// =============== CLASS MEMBERS DECLARATION ===================

.class public auto ansi sealed beforefieldinit XamlGeneratedNamespace.GeneratedInternalTypeHelper
       extends [WindowsBase]System.Windows.Markup.InternalTypeHelper
{
  .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                  75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                  30 00 00 )                                        // 0..
  .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
  .method family hidebysig virtual instance object 
          CreateInstance(class [mscorlib]System.Type 'type',
                         class [mscorlib]System.Globalization.CultureInfo culture) cil managed
  {
    // Code size       15 (0xf)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4     0x234
    IL_0006:  ldnull
    IL_0007:  ldnull
    IL_0008:  ldarg.2
    IL_0009:  call       object [mscorlib]System.Activator::CreateInstance(class [mscorlib]System.Type,
                                                                           valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                           class [mscorlib]System.Reflection.Binder,
                                                                           object[],
                                                                           class [mscorlib]System.Globalization.CultureInfo)
    IL_000e:  ret
  } // end of method GeneratedInternalTypeHelper::CreateInstance

  .method family hidebysig virtual instance object 
          GetPropertyValue(class [mscorlib]System.Reflection.PropertyInfo propertyInfo,
                           object target,
                           class [mscorlib]System.Globalization.CultureInfo culture) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldc.i4.0
    IL_0003:  ldnull
    IL_0004:  ldnull
    IL_0005:  ldarg.3
    IL_0006:  callvirt   instance object [mscorlib]System.Reflection.PropertyInfo::GetValue(object,
                                                                                            valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                                            class [mscorlib]System.Reflection.Binder,
                                                                                            object[],
                                                                                            class [mscorlib]System.Globalization.CultureInfo)
    IL_000b:  ret
  } // end of method GeneratedInternalTypeHelper::GetPropertyValue

  .method family hidebysig virtual instance void 
          SetPropertyValue(class [mscorlib]System.Reflection.PropertyInfo propertyInfo,
                           object target,
                           object 'value',
                           class [mscorlib]System.Globalization.CultureInfo culture) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  ldc.i4.0
    IL_0004:  ldnull
    IL_0005:  ldnull
    IL_0006:  ldarg.s    culture
    IL_0008:  callvirt   instance void [mscorlib]System.Reflection.PropertyInfo::SetValue(object,
                                                                                          object,
                                                                                          valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                                          class [mscorlib]System.Reflection.Binder,
                                                                                          object[],
                                                                                          class [mscorlib]System.Globalization.CultureInfo)
    IL_000d:  ret
  } // end of method GeneratedInternalTypeHelper::SetPropertyValue

  .method family hidebysig virtual instance class [mscorlib]System.Delegate 
          CreateDelegate(class [mscorlib]System.Type delegateType,
                         object target,
                         string 'handler') cil managed
  {
    // Code size       44 (0x2c)
    .maxstack  9
    IL_0000:  ldarg.2
    IL_0001:  callvirt   instance class [mscorlib]System.Type [mscorlib]System.Object::GetType()
    IL_0006:  ldstr      "_CreateDelegate"
    IL_000b:  ldc.i4     0x124
    IL_0010:  ldnull
    IL_0011:  ldarg.2
    IL_0012:  ldc.i4.2
    IL_0013:  newarr     [mscorlib]System.Object
    IL_0018:  dup
    IL_0019:  ldc.i4.0
    IL_001a:  ldarg.1
    IL_001b:  stelem.ref
    IL_001c:  dup
    IL_001d:  ldc.i4.1
    IL_001e:  ldarg.3
    IL_001f:  stelem.ref
    IL_0020:  ldnull
    IL_0021:  callvirt   instance object [mscorlib]System.Type::InvokeMember(string,
                                                                             valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                             class [mscorlib]System.Reflection.Binder,
                                                                             object,
                                                                             object[],
                                                                             class [mscorlib]System.Globalization.CultureInfo)
    IL_0026:  castclass  [mscorlib]System.Delegate
    IL_002b:  ret
  } // end of method GeneratedInternalTypeHelper::CreateDelegate

  .method family hidebysig virtual instance void 
          AddEventHandler(class [mscorlib]System.Reflection.EventInfo eventInfo,
                          object target,
                          class [mscorlib]System.Delegate 'handler') cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  callvirt   instance void [mscorlib]System.Reflection.EventInfo::AddEventHandler(object,
                                                                                              class [mscorlib]System.Delegate)
    IL_0008:  ret
  } // end of method GeneratedInternalTypeHelper::AddEventHandler

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [WindowsBase]System.Windows.Markup.InternalTypeHelper::.ctor()
    IL_0006:  ret
  } // end of method GeneratedInternalTypeHelper::.ctor

} // end of class XamlGeneratedNamespace.GeneratedInternalTypeHelper

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMACMModel_Sparse_ViewModel::.ctor

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 2A 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..*MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 53 70 61 72 73 65 00 00 )    // ptions_Sparse..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip MMSSTab1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab0
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_Sparse::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_sparse.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_Sparse::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       44 (0x2c)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  beq.s      IL_000a

    IL_0004:  ldarg.1
    IL_0005:  ldc.i4.2
    IL_0006:  beq.s      IL_0017

    IL_0008:  br.s       IL_0024

    IL_000a:  ldarg.0
    IL_000b:  ldarg.2
    IL_000c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip
    IL_0011:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse::MMSSTab1
    IL_0016:  ret

    IL_0017:  ldarg.0
    IL_0018:  ldarg.2
    IL_0019:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_001e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse::tab0
    IL_0023:  ret

    IL_0024:  ldarg.0
    IL_0025:  ldc.i4.1
    IL_0026:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse::_contentLoaded
    IL_002b:  ret
  } // end of method MMACMModel_SolverOptions_Sparse::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration ENTBLKSIM_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration INITSTAT_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration tab2_var_Property
  .method public hidebysig specialname instance object 
          get_ENTBLKSIM() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel::ENTBLKSIM_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_SolverOptions_ViewModel::get_ENTBLKSIM

  .method public hidebysig specialname instance object 
          get_INITSTAT() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel::INITSTAT_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_SolverOptions_ViewModel::get_INITSTAT

  .method public hidebysig specialname instance object 
          get_tab2_var() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel::tab2_var_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_SolverOptions_ViewModel::get_tab2_var

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMACMModel_SolverOptions_ViewModel::.ctor

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       145 (0x91)
    .maxstack  5
    IL_0000:  ldstr      "ENTBLKSIM"
    IL_0005:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel
    IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_000f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0014:  dup
    IL_0015:  ldstr      "@main.CC Nodes.ENTBLKSIM"
    IL_001a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_001f:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0024:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel::ENTBLKSIM_Property
    IL_0029:  ldstr      "INITSTAT"
    IL_002e:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel
    IL_0033:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0038:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_003d:  dup
    IL_003e:  ldstr      "@main.CC Nodes.CCINITOK"
    IL_0043:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0048:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_004d:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel::INITSTAT_Property
    IL_0052:  ldstr      "tab2_var"
    IL_0057:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel
    IL_005c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0061:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::.ctor()
    IL_0066:  dup
    IL_0067:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_CompleteDataPaths()
    IL_006c:  ldstr      "@INITSTAT"
    IL_0071:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_0076:  dup
    IL_0077:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_EnteredDataPaths()
    IL_007c:  ldstr      "@ENTBLKSIM"
    IL_0081:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_0086:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_008b:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel::tab2_var_Property
    IL_0090:  ret
  } // end of method MMACMModel_SolverOptions_ViewModel::.cctor

  .property instance callconv(8) object ENTBLKSIM()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel::get_ENTBLKSIM()
  } // end of property MMACMModel_SolverOptions_ViewModel::ENTBLKSIM
  .property instance callconv(8) object INITSTAT()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel::get_INITSTAT()
  } // end of property MMACMModel_SolverOptions_ViewModel::INITSTAT
  .property instance callconv(8) object tab2_var()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel::get_tab2_var()
  } // end of property MMACMModel_SolverOptions_ViewModel::tab2_var
} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 23 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..#MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 00 00 )                         // ptions..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip MMTabStrip1
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       25 (0x19)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  bne.un.s   IL_0011

    IL_0004:  ldarg.0
    IL_0005:  ldarg.2
    IL_0006:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip
    IL_000b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions::MMTabStrip1
    IL_0010:  ret

    IL_0011:  ldarg.0
    IL_0012:  ldc.i4.1
    IL_0013:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions::_contentLoaded
    IL_0018:  ret
  } // end of method MMACMModel_SolverOptions::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration SMSPEC_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration ENTBLKDG_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration ENTBLKRP_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration SMENT_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration ENTBLKPR_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration GENBLKOP_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration ENTBLKSIM_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration BKOP_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration ENTCOMLIS_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration INITSTAT_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration COMPLIST_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration choice_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration FLSP_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration STRE_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration tab0_var_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration tab1_var_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration tab2_var_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration tab3_var_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration tab4_var_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration tab5_var_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration tab6_var_Property
  .method public hidebysig specialname instance object 
          get_SMSPEC() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::SMSPEC_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_SMSPEC

  .method public hidebysig specialname instance object 
          get_ENTBLKDG() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::ENTBLKDG_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_ENTBLKDG

  .method public hidebysig specialname instance object 
          get_ENTBLKRP() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::ENTBLKRP_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_ENTBLKRP

  .method public hidebysig specialname instance object 
          get_SMENT() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::SMENT_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_SMENT

  .method public hidebysig specialname instance object 
          get_ENTBLKPR() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::ENTBLKPR_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_ENTBLKPR

  .method public hidebysig specialname instance object 
          get_GENBLKOP() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::GENBLKOP_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_GENBLKOP

  .method public hidebysig specialname instance object 
          get_ENTBLKSIM() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::ENTBLKSIM_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_ENTBLKSIM

  .method public hidebysig specialname instance object 
          get_BKOP() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::BKOP_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_BKOP

  .method public hidebysig specialname instance object 
          get_ENTCOMLIS() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::ENTCOMLIS_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_ENTCOMLIS

  .method public hidebysig specialname instance object 
          get_INITSTAT() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::INITSTAT_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_INITSTAT

  .method public hidebysig specialname instance object 
          get_COMPLIST() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::COMPLIST_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_COMPLIST

  .method public hidebysig specialname instance object 
          get_choice() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::choice_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_choice

  .method public hidebysig specialname instance object 
          get_FLSP() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::FLSP_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_FLSP

  .method public hidebysig specialname instance object 
          get_STRE() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::STRE_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_STRE

  .method public hidebysig specialname instance object 
          get_tab0_var() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab0_var_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_tab0_var

  .method public hidebysig specialname instance object 
          get_tab1_var() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab1_var_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_tab1_var

  .method public hidebysig specialname instance object 
          get_tab2_var() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab2_var_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_tab2_var

  .method public hidebysig specialname instance object 
          get_tab3_var() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab3_var_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_tab3_var

  .method public hidebysig specialname instance object 
          get_tab4_var() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab4_var_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_tab4_var

  .method public hidebysig specialname instance object 
          get_tab5_var() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab5_var_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_tab5_var

  .method public hidebysig specialname instance object 
          get_tab6_var() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab6_var_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_ViewModel::get_tab6_var

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMACMModel_Blocko_ViewModel::.ctor

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       993 (0x3e1)
    .maxstack  5
    IL_0000:  ldstr      "SMSPEC"
    IL_0005:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_000f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0014:  dup
    IL_0015:  ldstr      "@main.CC Nodes.SMSPEC"
    IL_001a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_001f:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0024:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::SMSPEC_Property
    IL_0029:  ldstr      "ENTBLKDG"
    IL_002e:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_0033:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0038:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_003d:  dup
    IL_003e:  ldstr      "@main.CC Nodes.ENTBLKDG"
    IL_0043:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0048:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_004d:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::ENTBLKDG_Property
    IL_0052:  ldstr      "ENTBLKRP"
    IL_0057:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_005c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0061:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0066:  dup
    IL_0067:  ldstr      "@main.CC Nodes.ENTBLKRP"
    IL_006c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0071:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0076:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::ENTBLKRP_Property
    IL_007b:  ldstr      "SMENT"
    IL_0080:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_0085:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_008a:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_008f:  dup
    IL_0090:  ldstr      "@main.CC Nodes.SMENT"
    IL_0095:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_009a:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_009f:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::SMENT_Property
    IL_00a4:  ldstr      "ENTBLKPR"
    IL_00a9:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_00ae:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_00b3:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_00b8:  dup
    IL_00b9:  ldstr      "@main.CC Nodes.ENTBLKPR"
    IL_00be:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_00c3:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_00c8:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::ENTBLKPR_Property
    IL_00cd:  ldstr      "GENBLKOP"
    IL_00d2:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_00d7:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_00dc:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_00e1:  dup
    IL_00e2:  ldstr      "@main.CC Nodes.GENBLKOP"
    IL_00e7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_00ec:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_00f1:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::GENBLKOP_Property
    IL_00f6:  ldstr      "ENTBLKSIM"
    IL_00fb:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_0100:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0105:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_010a:  dup
    IL_010b:  ldstr      "@main.CC Nodes.ENTBLKSIM"
    IL_0110:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0115:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_011a:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::ENTBLKSIM_Property
    IL_011f:  ldstr      "BKOP"
    IL_0124:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_0129:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_012e:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0133:  dup
    IL_0134:  ldstr      "@main.CC Nodes.BKOP"
    IL_0139:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_013e:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0143:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::BKOP_Property
    IL_0148:  ldstr      "ENTCOMLIS"
    IL_014d:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_0152:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0157:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_015c:  dup
    IL_015d:  ldstr      "@main.CC Nodes.ENTCOMLIS"
    IL_0162:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0167:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_016c:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::ENTCOMLIS_Property
    IL_0171:  ldstr      "INITSTAT"
    IL_0176:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_017b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0180:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0185:  dup
    IL_0186:  ldstr      "@main.CC Nodes.CCINITOK"
    IL_018b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0190:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0195:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::INITSTAT_Property
    IL_019a:  ldstr      "COMPLIST"
    IL_019f:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_01a4:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_01a9:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_01ae:  dup
    IL_01af:  ldstr      "@main.CC Nodes.COMPLIST"
    IL_01b4:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_01b9:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_01be:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::COMPLIST_Property
    IL_01c3:  ldstr      "choice"
    IL_01c8:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_01cd:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_01d2:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvParameterProperty::.ctor()
    IL_01d7:  dup
    IL_01d8:  ldstr      "choice"
    IL_01dd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvParameterProperty::set_Parameter(string)
    IL_01e2:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_01e7:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::choice_Property
    IL_01ec:  ldstr      "FLSP"
    IL_01f1:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_01f6:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_01fb:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0200:  dup
    IL_0201:  ldstr      "@main.CC Nodes.FLSP"
    IL_0206:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_020b:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0210:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::FLSP_Property
    IL_0215:  ldstr      "STRE"
    IL_021a:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_021f:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0224:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0229:  dup
    IL_022a:  ldstr      "@main.CC Nodes.STRE"
    IL_022f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0234:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0239:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::STRE_Property
    IL_023e:  ldstr      "tab0_var"
    IL_0243:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_0248:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_024d:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::.ctor()
    IL_0252:  dup
    IL_0253:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_CompleteDataPaths()
    IL_0258:  ldstr      "@BKOP"
    IL_025d:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_0262:  dup
    IL_0263:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_CompleteDataPaths()
    IL_0268:  ldstr      "@GENBLKOP"
    IL_026d:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_0272:  dup
    IL_0273:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_EnteredDataPaths()
    IL_0278:  ldstr      "@ENTBLKPR"
    IL_027d:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_0282:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0287:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab0_var_Property
    IL_028c:  ldstr      "tab1_var"
    IL_0291:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_0296:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_029b:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::.ctor()
    IL_02a0:  dup
    IL_02a1:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_CompleteDataPaths()
    IL_02a6:  ldstr      "@COMPLIST"
    IL_02ab:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_02b0:  dup
    IL_02b1:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_EnteredDataPaths()
    IL_02b6:  ldstr      "@ENTCOMLIS"
    IL_02bb:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_02c0:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_02c5:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab1_var_Property
    IL_02ca:  ldstr      "tab2_var"
    IL_02cf:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_02d4:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_02d9:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::.ctor()
    IL_02de:  dup
    IL_02df:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_CompleteDataPaths()
    IL_02e4:  ldstr      "@INITSTAT"
    IL_02e9:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_02ee:  dup
    IL_02ef:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_EnteredDataPaths()
    IL_02f4:  ldstr      "@ENTBLKSIM"
    IL_02f9:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_02fe:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0303:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab2_var_Property
    IL_0308:  ldstr      "tab3_var"
    IL_030d:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_0312:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0317:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::.ctor()
    IL_031c:  dup
    IL_031d:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_CompleteDataPaths()
    IL_0322:  ldstr      "@FLSP"
    IL_0327:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_032c:  dup
    IL_032d:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_EnteredDataPaths()
    IL_0332:  ldstr      "@STRE"
    IL_0337:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_033c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0341:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab3_var_Property
    IL_0346:  ldstr      "tab4_var"
    IL_034b:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_0350:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0355:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::.ctor()
    IL_035a:  dup
    IL_035b:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_EnteredDataPaths()
    IL_0360:  ldstr      "@ENTBLKDG"
    IL_0365:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_036a:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_036f:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab4_var_Property
    IL_0374:  ldstr      "tab5_var"
    IL_0379:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_037e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0383:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::.ctor()
    IL_0388:  dup
    IL_0389:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_CompleteDataPaths()
    IL_038e:  ldstr      "@SMSPEC"
    IL_0393:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_0398:  dup
    IL_0399:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_EnteredDataPaths()
    IL_039e:  ldstr      "@SMENT"
    IL_03a3:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_03a8:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_03ad:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab5_var_Property
    IL_03b2:  ldstr      "tab6_var"
    IL_03b7:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_03bc:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_03c1:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::.ctor()
    IL_03c6:  dup
    IL_03c7:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvTabItemProperty::get_EnteredDataPaths()
    IL_03cc:  ldstr      "@ENTBLKRP"
    IL_03d1:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_03d6:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_03db:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::tab6_var_Property
    IL_03e0:  ret
  } // end of method MMACMModel_Blocko_ViewModel::.cctor

  .property instance callconv(8) object SMSPEC()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_SMSPEC()
  } // end of property MMACMModel_Blocko_ViewModel::SMSPEC
  .property instance callconv(8) object ENTBLKDG()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_ENTBLKDG()
  } // end of property MMACMModel_Blocko_ViewModel::ENTBLKDG
  .property instance callconv(8) object ENTBLKRP()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_ENTBLKRP()
  } // end of property MMACMModel_Blocko_ViewModel::ENTBLKRP
  .property instance callconv(8) object SMENT()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_SMENT()
  } // end of property MMACMModel_Blocko_ViewModel::SMENT
  .property instance callconv(8) object ENTBLKPR()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_ENTBLKPR()
  } // end of property MMACMModel_Blocko_ViewModel::ENTBLKPR
  .property instance callconv(8) object GENBLKOP()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_GENBLKOP()
  } // end of property MMACMModel_Blocko_ViewModel::GENBLKOP
  .property instance callconv(8) object ENTBLKSIM()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_ENTBLKSIM()
  } // end of property MMACMModel_Blocko_ViewModel::ENTBLKSIM
  .property instance callconv(8) object BKOP()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_BKOP()
  } // end of property MMACMModel_Blocko_ViewModel::BKOP
  .property instance callconv(8) object ENTCOMLIS()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_ENTCOMLIS()
  } // end of property MMACMModel_Blocko_ViewModel::ENTCOMLIS
  .property instance callconv(8) object INITSTAT()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_INITSTAT()
  } // end of property MMACMModel_Blocko_ViewModel::INITSTAT
  .property instance callconv(8) object COMPLIST()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_COMPLIST()
  } // end of property MMACMModel_Blocko_ViewModel::COMPLIST
  .property instance callconv(8) object choice()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_choice()
  } // end of property MMACMModel_Blocko_ViewModel::choice
  .property instance callconv(8) object FLSP()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_FLSP()
  } // end of property MMACMModel_Blocko_ViewModel::FLSP
  .property instance callconv(8) object STRE()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_STRE()
  } // end of property MMACMModel_Blocko_ViewModel::STRE
  .property instance callconv(8) object tab0_var()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_tab0_var()
  } // end of property MMACMModel_Blocko_ViewModel::tab0_var
  .property instance callconv(8) object tab1_var()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_tab1_var()
  } // end of property MMACMModel_Blocko_ViewModel::tab1_var
  .property instance callconv(8) object tab2_var()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_tab2_var()
  } // end of property MMACMModel_Blocko_ViewModel::tab2_var
  .property instance callconv(8) object tab3_var()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_tab3_var()
  } // end of property MMACMModel_Blocko_ViewModel::tab3_var
  .property instance callconv(8) object tab4_var()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_tab4_var()
  } // end of property MMACMModel_Blocko_ViewModel::tab4_var
  .property instance callconv(8) object tab5_var()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_tab5_var()
  } // end of property MMACMModel_Blocko_ViewModel::tab5_var
  .property instance callconv(8) object tab6_var()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel::get_tab6_var()
  } // end of property MMACMModel_Blocko_ViewModel::tab6_var
} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 1C 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ...MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 42 6C 6F 63 6B 6F 00   // ACMModel_Blocko.
                                                                                                    00 ) 
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip MMTabStrip1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab0
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab4
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab5
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab6
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tabInfo
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_Blocko::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_blocko.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_Blocko::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       171 (0xab)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_002e,
                          IL_003b,
                          IL_0048,
                          IL_0055,
                          IL_0062,
                          IL_006f,
                          IL_007c,
                          IL_0089,
                          IL_0096)
    IL_002c:  br.s       IL_00a3

    IL_002e:  ldarg.0
    IL_002f:  ldarg.2
    IL_0030:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip
    IL_0035:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::MMTabStrip1
    IL_003a:  ret

    IL_003b:  ldarg.0
    IL_003c:  ldarg.2
    IL_003d:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_0042:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::tab0
    IL_0047:  ret

    IL_0048:  ldarg.0
    IL_0049:  ldarg.2
    IL_004a:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_004f:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::tab1
    IL_0054:  ret

    IL_0055:  ldarg.0
    IL_0056:  ldarg.2
    IL_0057:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_005c:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::tab2
    IL_0061:  ret

    IL_0062:  ldarg.0
    IL_0063:  ldarg.2
    IL_0064:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_0069:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::tab3
    IL_006e:  ret

    IL_006f:  ldarg.0
    IL_0070:  ldarg.2
    IL_0071:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_0076:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::tab4
    IL_007b:  ret

    IL_007c:  ldarg.0
    IL_007d:  ldarg.2
    IL_007e:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_0083:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::tab5
    IL_0088:  ret

    IL_0089:  ldarg.0
    IL_008a:  ldarg.2
    IL_008b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_0090:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::tab6
    IL_0095:  ret

    IL_0096:  ldarg.0
    IL_0097:  ldarg.2
    IL_0098:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_009d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::tabInfo
    IL_00a2:  ret

    IL_00a3:  ldarg.0
    IL_00a4:  ldc.i4.1
    IL_00a5:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko::_contentLoaded
    IL_00aa:  ret
  } // end of method MMACMModel_Blocko::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .class auto ansi nested public beforefieldinit grdFeedProducts_GridData_ItemTemplate
         extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel
  {
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMTextBox1_var1_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox5_var1_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox4_MultiMap_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox3_var1_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox2_var1_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox1_3_MultiMap_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox1_2_var1_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox1_0_var1_Property
    .method public hidebysig specialname 
            instance object  get_MMTextBox1_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMTextBox1_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdFeedProducts_GridData_ItemTemplate::get_MMTextBox1_var1

    .method public hidebysig specialname 
            instance object  get_MMComboBox5_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox5_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdFeedProducts_GridData_ItemTemplate::get_MMComboBox5_var1

    .method public hidebysig specialname 
            instance object  get_MMComboBox4_MultiMap() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox4_MultiMap_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdFeedProducts_GridData_ItemTemplate::get_MMComboBox4_MultiMap

    .method public hidebysig specialname 
            instance object  get_MMComboBox3_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox3_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdFeedProducts_GridData_ItemTemplate::get_MMComboBox3_var1

    .method public hidebysig specialname 
            instance object  get_MMComboBox2_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox2_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdFeedProducts_GridData_ItemTemplate::get_MMComboBox2_var1

    .method public hidebysig specialname 
            instance object  get_MMComboBox1_3_MultiMap() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox1_3_MultiMap_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdFeedProducts_GridData_ItemTemplate::get_MMComboBox1_3_MultiMap

    .method public hidebysig specialname 
            instance object  get_MMComboBox1_2_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox1_2_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdFeedProducts_GridData_ItemTemplate::get_MMComboBox1_2_var1

    .method public hidebysig specialname 
            instance object  get_MMComboBox1_0_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox1_0_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdFeedProducts_GridData_ItemTemplate::get_MMComboBox1_0_var1

    .method public hidebysig specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::.ctor()
      IL_0006:  ret
    } // end of method grdFeedProducts_GridData_ItemTemplate::.ctor

    .method private hidebysig specialname rtspecialname static 
            void  .cctor() cil managed
    {
      // Code size       1155 (0x483)
      .maxstack  9
      IL_0000:  ldstr      "MMTextBox1_var1"
      IL_0005:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate
      IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_000f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_0014:  dup
      IL_0015:  ldc.i4.6
      IL_0016:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_001b:  dup
      IL_001c:  ldstr      "@main.Input.COMP_GROUP.@y"
      IL_0021:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_0026:  dup
      IL_0027:  ldc.i4.1
      IL_0028:  newobj     instance void valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDisplayedCase>::.ctor(!0)
      IL_002d:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DisplayedCase(valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDisplayedCase>)
      IL_0032:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_0037:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMTextBox1_var1_Property
      IL_003c:  ldstr      "MMComboBox5_var1"
      IL_0041:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate
      IL_0046:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_004b:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_0050:  dup
      IL_0051:  ldc.i4.2
      IL_0052:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_0057:  dup
      IL_0058:  ldstr      "@main.Input.COMP_GROUP.@y"
      IL_005d:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_0062:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_0067:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox5_var1_Property
      IL_006c:  ldstr      "MMComboBox4_MultiMap"
      IL_0071:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate
      IL_0076:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_007b:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::.ctor()
      IL_0080:  dup
      IL_0081:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariableCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Variables()
      IL_0086:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::.ctor()
      IL_008b:  dup
      IL_008c:  ldstr      "MMComboBox4_var1"
      IL_0091:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_Name(string)
      IL_0096:  dup
      IL_0097:  ldstr      "@main.Input.CL_TRUECOMPS.@y"
      IL_009c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_DataPath(string)
      IL_00a1:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable>::Add(!0)
      IL_00a6:  dup
      IL_00a7:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_00ac:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_00b1:  dup
      IL_00b2:  ldstr      "True components"
      IL_00b7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_00bc:  dup
      IL_00bd:  ldstr      "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapO"
      + "ption_Display_True_components"
      IL_00c2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_00c7:  dup
      IL_00c8:  ldstr      "MMComboBox4_MultiMapOption_1"
      IL_00cd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_00d2:  dup
      IL_00d3:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_00d8:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_00dd:  dup
      IL_00de:  ldstr      "MMComboBox4_var1"
      IL_00e3:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_00e8:  dup
      IL_00e9:  ldstr      "YES"
      IL_00ee:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_00f3:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_00f8:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_00fd:  dup
      IL_00fe:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_0103:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_0108:  dup
      IL_0109:  ldstr      "Apparent components"
      IL_010e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_0113:  dup
      IL_0114:  ldstr      "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapO"
      + "ption_Display_Apparent_components"
      IL_0119:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_011e:  dup
      IL_011f:  ldstr      "MMComboBox4_MultiMapOption_2"
      IL_0124:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_0129:  dup
      IL_012a:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_012f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_0134:  dup
      IL_0135:  ldstr      "MMComboBox4_var1"
      IL_013a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_013f:  dup
      IL_0140:  ldstr      "NO"
      IL_0145:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_014a:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_014f:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_0154:  dup
      IL_0155:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
      IL_015a:  dup
      IL_015b:  ldstr      "@main.CC Nodes.CLCHEML.@y"
      IL_0160:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
      IL_0165:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
      IL_016a:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_016f:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox4_MultiMap_Property
      IL_0174:  ldstr      "MMComboBox3_var1"
      IL_0179:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate
      IL_017e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0183:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_0188:  dup
      IL_0189:  ldc.i4.2
      IL_018a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_018f:  dup
      IL_0190:  ldstr      "@main.Input.CL_CHEMISTRY.@y"
      IL_0195:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_019a:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_019f:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox3_var1_Property
      IL_01a4:  ldstr      "MMComboBox2_var1"
      IL_01a9:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate
      IL_01ae:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_01b3:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_01b8:  dup
      IL_01b9:  ldc.i4.2
      IL_01ba:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_01bf:  dup
      IL_01c0:  ldstr      "@main.Input.CL_HENRYCOMP.@y"
      IL_01c5:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_01ca:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_01cf:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox2_var1_Property
      IL_01d4:  ldstr      "MMComboBox1_3_MultiMap"
      IL_01d9:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate
      IL_01de:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_01e3:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::.ctor()
      IL_01e8:  dup
      IL_01e9:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariableCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Variables()
      IL_01ee:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::.ctor()
      IL_01f3:  dup
      IL_01f4:  ldstr      "MMComboBox1_3_var1"
      IL_01f9:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_Name(string)
      IL_01fe:  dup
      IL_01ff:  ldstr      "@main.Input.CL_SOLUWATER.@y"
      IL_0204:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_DataPath(string)
      IL_0209:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable>::Add(!0)
      IL_020e:  dup
      IL_020f:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_0214:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_0219:  dup
      IL_021a:  ldstr      "0 - Saturated steam table"
      IL_021f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_0224:  dup
      IL_0225:  ldstr      "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapO"
      + "ption_Display_0___Saturated_steam_table"
      IL_022a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_022f:  dup
      IL_0230:  ldstr      "MMComboBox1_3_MultiMapOption_1"
      IL_0235:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_023a:  dup
      IL_023b:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_0240:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_0245:  dup
      IL_0246:  ldstr      "MMComboBox1_3_var1"
      IL_024b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_0250:  dup
      IL_0251:  ldstr      "0"
      IL_0256:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_025b:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_0260:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_0265:  dup
      IL_0266:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_026b:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_0270:  dup
      IL_0271:  ldstr      "1 - Saturated primary package"
      IL_0276:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_027b:  dup
      IL_027c:  ldstr      "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapO"
      + "ption_Display_1___Saturated_primary_package"
      IL_0281:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_0286:  dup
      IL_0287:  ldstr      "MMComboBox1_3_MultiMapOption_2"
      IL_028c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_0291:  dup
      IL_0292:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_0297:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_029c:  dup
      IL_029d:  ldstr      "MMComboBox1_3_var1"
      IL_02a2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_02a7:  dup
      IL_02a8:  ldstr      "1"
      IL_02ad:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_02b2:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_02b7:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_02bc:  dup
      IL_02bd:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_02c2:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_02c7:  dup
      IL_02c8:  ldstr      "2 - Unsaturated primary package"
      IL_02cd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_02d2:  dup
      IL_02d3:  ldstr      "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapO"
      + "ption_Display_2___Unsaturated_primary_package"
      IL_02d8:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_02dd:  dup
      IL_02de:  ldstr      "MMComboBox1_3_MultiMapOption_3"
      IL_02e3:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_02e8:  dup
      IL_02e9:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_02ee:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_02f3:  dup
      IL_02f4:  ldstr      "MMComboBox1_3_var1"
      IL_02f9:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_02fe:  dup
      IL_02ff:  ldstr      "2"
      IL_0304:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_0309:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_030e:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_0313:  dup
      IL_0314:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_0319:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_031e:  dup
      IL_031f:  ldstr      "3 - No correction"
      IL_0324:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_0329:  dup
      IL_032a:  ldstr      "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapO"
      + "ption_Display_3___No_correction"
      IL_032f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_0334:  dup
      IL_0335:  ldstr      "MMComboBox1_3_MultiMapOption_4"
      IL_033a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_033f:  dup
      IL_0340:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_0345:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_034a:  dup
      IL_034b:  ldstr      "MMComboBox1_3_var1"
      IL_0350:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_0355:  dup
      IL_0356:  ldstr      "3"
      IL_035b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_0360:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_0365:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_036a:  dup
      IL_036b:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_0370:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_0375:  dup
      IL_0376:  ldstr      "4 - Water solubility is one"
      IL_037b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_0380:  dup
      IL_0381:  ldstr      "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapO"
      + "ption_Display_4___Water_solubility_is_one"
      IL_0386:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_038b:  dup
      IL_038c:  ldstr      "MMComboBox1_3_MultiMapOption_5"
      IL_0391:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_0396:  dup
      IL_0397:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_039c:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_03a1:  dup
      IL_03a2:  ldstr      "MMComboBox1_3_var1"
      IL_03a7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_03ac:  dup
      IL_03ad:  ldstr      "4"
      IL_03b2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_03b7:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_03bc:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_03c1:  dup
      IL_03c2:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_03c7:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_03cc:  dup
      IL_03cd:  ldstr      "5 - Unsaturated steam"
      IL_03d2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_03d7:  dup
      IL_03d8:  ldstr      "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapO"
      + "ption_Display_5___Unsaturated_steam"
      IL_03dd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_03e2:  dup
      IL_03e3:  ldstr      "MMComboBox1_3_MultiMapOption_6"
      IL_03e8:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_03ed:  dup
      IL_03ee:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_03f3:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_03f8:  dup
      IL_03f9:  ldstr      "MMComboBox1_3_var1"
      IL_03fe:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_0403:  dup
      IL_0404:  ldstr      "5"
      IL_0409:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_040e:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_0413:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_0418:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_041d:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox1_3_MultiMap_Property
      IL_0422:  ldstr      "MMComboBox1_2_var1"
      IL_0427:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate
      IL_042c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0431:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_0436:  dup
      IL_0437:  ldc.i4.2
      IL_0438:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_043d:  dup
      IL_043e:  ldstr      "@main.Input.CL_FREEWATER.@y"
      IL_0443:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_0448:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_044d:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox1_2_var1_Property
      IL_0452:  ldstr      "MMComboBox1_0_var1"
      IL_0457:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate
      IL_045c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0461:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_0466:  dup
      IL_0467:  ldc.i4.2
      IL_0468:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_046d:  dup
      IL_046e:  ldstr      "@main.Input.CL_OPSETNAME.@y"
      IL_0473:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_0478:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_047d:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::MMComboBox1_0_var1_Property
      IL_0482:  ret
    } // end of method grdFeedProducts_GridData_ItemTemplate::.cctor

    .property instance callconv(8) object
            MMTextBox1_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::get_MMTextBox1_var1()
    } // end of property grdFeedProducts_GridData_ItemTemplate::MMTextBox1_var1
    .property instance callconv(8) object
            MMComboBox5_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::get_MMComboBox5_var1()
    } // end of property grdFeedProducts_GridData_ItemTemplate::MMComboBox5_var1
    .property instance callconv(8) object
            MMComboBox4_MultiMap()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::get_MMComboBox4_MultiMap()
    } // end of property grdFeedProducts_GridData_ItemTemplate::MMComboBox4_MultiMap
    .property instance callconv(8) object
            MMComboBox3_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::get_MMComboBox3_var1()
    } // end of property grdFeedProducts_GridData_ItemTemplate::MMComboBox3_var1
    .property instance callconv(8) object
            MMComboBox2_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::get_MMComboBox2_var1()
    } // end of property grdFeedProducts_GridData_ItemTemplate::MMComboBox2_var1
    .property instance callconv(8) object
            MMComboBox1_3_MultiMap()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::get_MMComboBox1_3_MultiMap()
    } // end of property grdFeedProducts_GridData_ItemTemplate::MMComboBox1_3_MultiMap
    .property instance callconv(8) object
            MMComboBox1_2_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::get_MMComboBox1_2_var1()
    } // end of property grdFeedProducts_GridData_ItemTemplate::MMComboBox1_2_var1
    .property instance callconv(8) object
            MMComboBox1_0_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate::get_MMComboBox1_0_var1()
    } // end of property grdFeedProducts_GridData_ItemTemplate::MMComboBox1_0_var1
  } // end of class grdFeedProducts_GridData_ItemTemplate

  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration grdFeedProducts_GridData_Property
  .method public hidebysig specialname instance object 
          get_grdFeedProducts_GridData() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel::grdFeedProducts_GridData_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_CompList_ViewModel::get_grdFeedProducts_GridData

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMACMModel_Blocko_CompList_ViewModel::.ctor

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       87 (0x57)
    .maxstack  7
    IL_0000:  ldstr      "grdFeedProducts_GridData"
    IL_0005:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel
    IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_000f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVectorProperty::.ctor()
    IL_0014:  dup
    IL_0015:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel/grdFeedProducts_GridData_ItemTemplate
    IL_001a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_001f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVectorProperty::set_ItemType(class [mscorlib]System.Type)
    IL_0024:  dup
    IL_0025:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvChildCountIndexBasis::.ctor()
    IL_002a:  dup
    IL_002b:  ldstr      "@main.Input.COMP_GROUP"
    IL_0030:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvChildCountIndexBasis::set_DataPath(string)
    IL_0035:  dup
    IL_0036:  ldc.i4.1
    IL_0037:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvChildCountIndexBasis::set_UseChildId(bool)
    IL_003c:  dup
    IL_003d:  ldstr      "y"
    IL_0042:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvIndexBasisBase::set_Name(string)
    IL_0047:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVectorProperty::set_IndexBasis(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvIndexBasisBase)
    IL_004c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0051:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel::grdFeedProducts_GridData_Property
    IL_0056:  ret
  } // end of method MMACMModel_Blocko_CompList_ViewModel::.cctor

  .property instance callconv(8) object grdFeedProducts_GridData()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel::get_grdFeedProducts_GridData()
  } // end of property MMACMModel_Blocko_CompList_ViewModel::grdFeedProducts_GridData
} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 25 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..%MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 42 6C 6F 63 6B 6F 5F   // ACMModel_Blocko_
                                                                                                    43 6F 6D 70 4C 69 73 74 00 00 )                   // CompList..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox MMFrame1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMScrollAreaHorizontal grdFeedProducts
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_Blocko_CompList::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_blocko_complist.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_Blocko_CompList::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       44 (0x2c)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  beq.s      IL_000a

    IL_0004:  ldarg.1
    IL_0005:  ldc.i4.2
    IL_0006:  beq.s      IL_0017

    IL_0008:  br.s       IL_0024

    IL_000a:  ldarg.0
    IL_000b:  ldarg.2
    IL_000c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_0011:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList::MMFrame1
    IL_0016:  ret

    IL_0017:  ldarg.0
    IL_0018:  ldarg.2
    IL_0019:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMScrollAreaHorizontal
    IL_001e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMScrollAreaHorizontal AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList::grdFeedProducts
    IL_0023:  ret

    IL_0024:  ldarg.0
    IL_0025:  ldc.i4.1
    IL_0026:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList::_contentLoaded
    IL_002b:  ret
  } // end of method MMACMModel_Blocko_CompList::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_CompList

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .class auto ansi nested public beforefieldinit grdScMeth_GridData_ItemTemplate
         extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel
  {
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox3_var1_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox2_var1_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox4_var1_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMTextBox3_var1_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox5_var1_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration ID_Property
    .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMTextBox2_var1_Property
    .method public hidebysig specialname 
            instance object  get_MMComboBox3_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMComboBox3_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdScMeth_GridData_ItemTemplate::get_MMComboBox3_var1

    .method public hidebysig specialname 
            instance object  get_MMComboBox2_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMComboBox2_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdScMeth_GridData_ItemTemplate::get_MMComboBox2_var1

    .method public hidebysig specialname 
            instance object  get_MMComboBox4_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMComboBox4_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdScMeth_GridData_ItemTemplate::get_MMComboBox4_var1

    .method public hidebysig specialname 
            instance object  get_MMTextBox3_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMTextBox3_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdScMeth_GridData_ItemTemplate::get_MMTextBox3_var1

    .method public hidebysig specialname 
            instance object  get_MMComboBox5_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMComboBox5_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdScMeth_GridData_ItemTemplate::get_MMComboBox5_var1

    .method public hidebysig specialname 
            instance object  get_ID() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::ID_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdScMeth_GridData_ItemTemplate::get_ID

    .method public hidebysig specialname 
            instance object  get_MMTextBox2_var1() cil managed
    {
      // Code size       12 (0xc)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMTextBox2_var1_Property
      IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
      IL_000b:  ret
    } // end of method grdScMeth_GridData_ItemTemplate::get_MMTextBox2_var1

    .method public hidebysig specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::.ctor()
      IL_0006:  ret
    } // end of method grdScMeth_GridData_ItemTemplate::.ctor

    .method private hidebysig specialname rtspecialname static 
            void  .cctor() cil managed
    {
      // Code size       832 (0x340)
      .maxstack  9
      IL_0000:  ldstr      "MMComboBox3_var1"
      IL_0005:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
      IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_000f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_0014:  dup
      IL_0015:  ldc.i4.2
      IL_0016:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_001b:  dup
      IL_001c:  ldstr      "@main.Input.LOCALSCRIPT.@y"
      IL_0021:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_0026:  dup
      IL_0027:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
      IL_002c:  dup
      IL_002d:  ldstr      "@main.CC Nodes.LOCASC.@y"
      IL_0032:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
      IL_0037:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsVisibleCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
      IL_003c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_0041:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMComboBox3_var1_Property
      IL_0046:  ldstr      "MMComboBox2_var1"
      IL_004b:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
      IL_0050:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0055:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::.ctor()
      IL_005a:  dup
      IL_005b:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariableCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Variables()
      IL_0060:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::.ctor()
      IL_0065:  dup
      IL_0066:  ldstr      "MultimapOptionScriptType"
      IL_006b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_Name(string)
      IL_0070:  dup
      IL_0071:  ldstr      "@main.Input.SC_TYPE.@y"
      IL_0076:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_DataPath(string)
      IL_007b:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable>::Add(!0)
      IL_0080:  dup
      IL_0081:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_0086:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_008b:  dup
      IL_008c:  ldstr      "Localscript"
      IL_0091:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_0096:  dup
      IL_0097:  ldstr      "MMACMModel_Eoopti_Model_ViewModel__CxvMultiMapOpti"
      + "on_Display_Localscript"
      IL_009c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_00a1:  dup
      IL_00a2:  ldstr      "LOCALSCRIPT"
      IL_00a7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_00ac:  dup
      IL_00ad:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_00b2:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_00b7:  dup
      IL_00b8:  ldstr      "MultimapOptionScriptType"
      IL_00bd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_00c2:  dup
      IL_00c3:  ldstr      "LOCALSCRIPT"
      IL_00c8:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_00cd:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_00d2:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_00d7:  dup
      IL_00d8:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_00dd:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_00e2:  dup
      IL_00e3:  ldstr      "Globalscript"
      IL_00e8:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_00ed:  dup
      IL_00ee:  ldstr      "MMACMModel_Eoopti_Model_ViewModel__CxvMultiMapOpti"
      + "on_Display_Globalscript"
      IL_00f3:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_00f8:  dup
      IL_00f9:  ldstr      "GLOBALSCRIPT"
      IL_00fe:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_0103:  dup
      IL_0104:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_0109:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_010e:  dup
      IL_010f:  ldstr      "MultimapOptionScriptType"
      IL_0114:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_0119:  dup
      IL_011a:  ldstr      "GLOBALSCRIPT"
      IL_011f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_0124:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_0129:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_012e:  dup
      IL_012f:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
      IL_0134:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
      IL_0139:  dup
      IL_013a:  ldstr      "File"
      IL_013f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
      IL_0144:  dup
      IL_0145:  ldstr      "MMACMModel_Eoopti_Model_ViewModel__CxvMultiMapOpti"
      + "on_Display_File"
      IL_014a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
      IL_014f:  dup
      IL_0150:  ldstr      "FILE"
      IL_0155:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
      IL_015a:  dup
      IL_015b:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
      IL_0160:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
      IL_0165:  dup
      IL_0166:  ldstr      "MultimapOptionScriptType"
      IL_016b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
      IL_0170:  dup
      IL_0171:  ldstr      "FILE"
      IL_0176:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
      IL_017b:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
      IL_0180:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
      IL_0185:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_018a:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMComboBox2_var1_Property
      IL_018f:  ldstr      "MMComboBox4_var1"
      IL_0194:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
      IL_0199:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_019e:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_01a3:  dup
      IL_01a4:  ldc.i4.2
      IL_01a5:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_01aa:  dup
      IL_01ab:  ldstr      "@main.Input.GLOBALSCRIPT.@y"
      IL_01b0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_01b5:  dup
      IL_01b6:  ldc.i4.2
      IL_01b7:  newobj     instance void valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDisplayedCase>::.ctor(!0)
      IL_01bc:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DisplayedCase(valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDisplayedCase>)
      IL_01c1:  dup
      IL_01c2:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
      IL_01c7:  dup
      IL_01c8:  ldstr      "@main.CC Nodes.GLOBSC.@y"
      IL_01cd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
      IL_01d2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsVisibleCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
      IL_01d7:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_01dc:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMComboBox4_var1_Property
      IL_01e1:  ldstr      "MMTextBox3_var1"
      IL_01e6:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
      IL_01eb:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_01f0:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_01f5:  dup
      IL_01f6:  ldstr      "@main.Input.USER_METHOD.@y"
      IL_01fb:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_0200:  dup
      IL_0201:  ldc.i4.1
      IL_0202:  newobj     instance void valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDisplayedCase>::.ctor(!0)
      IL_0207:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DisplayedCase(valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDisplayedCase>)
      IL_020c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_0211:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMTextBox3_var1_Property
      IL_0216:  ldstr      "MMComboBox5_var1"
      IL_021b:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
      IL_0220:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0225:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_022a:  dup
      IL_022b:  ldc.i4.2
      IL_022c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_0231:  dup
      IL_0232:  ldstr      "@main.Input.SC_METHOD.@y"
      IL_0237:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_023c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_0241:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMComboBox5_var1_Property
      IL_0246:  ldstr      "ID"
      IL_024b:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
      IL_0250:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0255:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertySelector::.ctor()
      IL_025a:  dup
      IL_025b:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyChoice> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertySelector::get_Choices()
      IL_0260:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyChoice::.ctor()
      IL_0265:  dup
      IL_0266:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTestCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyChoice::get_Conditions()
      IL_026b:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
      IL_0270:  dup
      IL_0271:  ldstr      "@main.CC_Nodes.GLOBSC.@y"
      IL_0276:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
      IL_027b:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest>::Add(!0)
      IL_0280:  dup
      IL_0281:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_0286:  dup
      IL_0287:  ldc.i4.2
      IL_0288:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_028d:  dup
      IL_028e:  ldstr      "@main.Input.GLOBALSCRIPT.@y"
      IL_0293:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_0298:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyChoice::set_Property(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_029d:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyChoice>::Add(!0)
      IL_02a2:  dup
      IL_02a3:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyChoice> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertySelector::get_Choices()
      IL_02a8:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyChoice::.ctor()
      IL_02ad:  dup
      IL_02ae:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTestCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyChoice::get_Conditions()
      IL_02b3:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
      IL_02b8:  dup
      IL_02b9:  ldstr      "@main.CC_Nodes.LOCASC.@y"
      IL_02be:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
      IL_02c3:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest>::Add(!0)
      IL_02c8:  dup
      IL_02c9:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_02ce:  dup
      IL_02cf:  ldc.i4.2
      IL_02d0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
      IL_02d5:  dup
      IL_02d6:  ldstr      "@main.Input.LOCALSCRIPT.@y"
      IL_02db:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_02e0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyChoice::set_Property(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_02e5:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyChoice>::Add(!0)
      IL_02ea:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_02ef:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::ID_Property
      IL_02f4:  ldstr      "MMTextBox2_var1"
      IL_02f9:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
      IL_02fe:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0303:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
      IL_0308:  dup
      IL_0309:  ldstr      "@main.Input.FILE.@y"
      IL_030e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
      IL_0313:  dup
      IL_0314:  ldc.i4.1
      IL_0315:  newobj     instance void valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDisplayedCase>::.ctor(!0)
      IL_031a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DisplayedCase(valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDisplayedCase>)
      IL_031f:  dup
      IL_0320:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
      IL_0325:  dup
      IL_0326:  ldstr      "@main.CC Nodes.FILESC.@y"
      IL_032b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
      IL_0330:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
      IL_0335:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                           class [mscorlib]System.Type,
                                                                                                                                                                                                                           class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
      IL_033a:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::MMTextBox2_var1_Property
      IL_033f:  ret
    } // end of method grdScMeth_GridData_ItemTemplate::.cctor

    .property instance callconv(8) object
            MMComboBox3_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::get_MMComboBox3_var1()
    } // end of property grdScMeth_GridData_ItemTemplate::MMComboBox3_var1
    .property instance callconv(8) object
            MMComboBox2_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::get_MMComboBox2_var1()
    } // end of property grdScMeth_GridData_ItemTemplate::MMComboBox2_var1
    .property instance callconv(8) object
            MMComboBox4_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::get_MMComboBox4_var1()
    } // end of property grdScMeth_GridData_ItemTemplate::MMComboBox4_var1
    .property instance callconv(8) object
            MMTextBox3_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::get_MMTextBox3_var1()
    } // end of property grdScMeth_GridData_ItemTemplate::MMTextBox3_var1
    .property instance callconv(8) object
            MMComboBox5_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::get_MMComboBox5_var1()
    } // end of property grdScMeth_GridData_ItemTemplate::MMComboBox5_var1
    .property instance callconv(8) object
            ID()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::get_ID()
    } // end of property grdScMeth_GridData_ItemTemplate::ID
    .property instance callconv(8) object
            MMTextBox2_var1()
    {
      .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate::get_MMTextBox2_var1()
    } // end of property grdScMeth_GridData_ItemTemplate::MMTextBox2_var1
  } // end of class grdScMeth_GridData_ItemTemplate

  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration grdScMeth_GridData_Property
  .field private class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object> _cmdEdit_Command
  .field private class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> _selectedRowIndexes
  .method public hidebysig specialname instance object 
          get_grdScMeth_GridData() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::grdScMeth_GridData_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_EOOptions_ViewModel::get_grdScMeth_GridData

  .method public hidebysig specialname instance class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object> 
          get_cmdEdit_Command() cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_cmdEdit_Command
    IL_0006:  brtrue.s   IL_002b

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::cmdEdit_CommandExecute(object)
    IL_0010:  newobj     instance void class [mscorlib]System.Action`1<object>::.ctor(object,
                                                                                      native int)
    IL_0015:  ldarg.0
    IL_0016:  ldftn      instance bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::cmdEdit_CommandCanExecute(object)
    IL_001c:  newobj     instance void class [mscorlib]System.Func`2<object,bool>::.ctor(object,
                                                                                         native int)
    IL_0021:  newobj     instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object>::.ctor(class [mscorlib]System.Action`1<!0>,
                                                                                                                                                                              class [mscorlib]System.Func`2<!0,bool>)
    IL_0026:  stfld      class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_cmdEdit_Command
    IL_002b:  ldarg.0
    IL_002c:  ldfld      class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_cmdEdit_Command
    IL_0031:  ret
  } // end of method MMACMModel_Blocko_EOOptions_ViewModel::get_cmdEdit_Command

  .method private hidebysig instance void 
          cmdEdit_CommandExecute(object parameter) cil managed
  {
    // Code size       522 (0x20a)
    .maxstack  5
    .locals init (int32 V_0,
             string V_1,
             string V_2,
             string V_3,
             int32 V_4,
             class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs V_5,
             string V_6,
             class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs V_7,
             string V_8)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_selectedRowIndexes
    IL_0006:  callvirt   instance int32 class [mscorlib]System.Collections.ObjectModel.Collection`1<int32>::get_Count()
    IL_000b:  ldc.i4.1
    IL_000c:  bne.un     IL_0209

    IL_0011:  ldarg.0
    IL_0012:  ldfld      class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_selectedRowIndexes
    IL_0017:  ldc.i4.0
    IL_0018:  callvirt   instance !0 class [mscorlib]System.Collections.ObjectModel.Collection`1<int32>::get_Item(int32)
    IL_001d:  stloc.0
    IL_001e:  ldloc.0
    IL_001f:  ldc.i4.0
    IL_0020:  blt        IL_0209

    IL_0025:  ldarg.0
    IL_0026:  call       instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::get_grdScMeth_GridData()
    IL_002b:  isinst     [mscorlib]System.Collections.IList
    IL_0030:  ldloc.0
    IL_0031:  callvirt   instance object [mscorlib]System.Collections.IList::get_Item(int32)
    IL_0036:  isinst     AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
    IL_003b:  dup
    IL_003c:  ldstr      "MMComboBox2_var1.Value"
    IL_0041:  call       object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.ICxvViewDataContainerExtensions::ResolveViewPropertyPath(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.ICxvViewDataContainer,
                                                                                                                                                          string)
    IL_0046:  isinst     [mscorlib]System.String
    IL_004b:  stloc.1
    IL_004c:  ldstr      "ID.Value"
    IL_0051:  call       object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.ICxvViewDataContainerExtensions::ResolveViewPropertyPath(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.ICxvViewDataContainer,
                                                                                                                                                          string)
    IL_0056:  isinst     [mscorlib]System.String
    IL_005b:  stloc.2
    IL_005c:  ldarg.0
    IL_005d:  ldstr      "main"
    IL_0062:  ldnull
    IL_0063:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveParameter(string,
                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyWatch)
    IL_0068:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
    IL_006d:  stloc.3
    IL_006e:  ldloc.3
    IL_006f:  ldstr      "Data"
    IL_0074:  callvirt   instance int32 [mscorlib]System.String::LastIndexOf(string)
    IL_0079:  stloc.s    V_4
    IL_007b:  ldloc.s    V_4
    IL_007d:  ldc.i4.0
    IL_007e:  ble.s      IL_008e

    IL_0080:  ldloc.3
    IL_0081:  ldc.i4.0
    IL_0082:  ldloc.s    V_4
    IL_0084:  ldc.i4.4
    IL_0085:  add
    IL_0086:  callvirt   instance string [mscorlib]System.String::Substring(int32,
                                                                            int32)
    IL_008b:  stloc.3
    IL_008c:  br.s       IL_0094

    IL_008e:  ldstr      "Top.appModelV8"
    IL_0093:  stloc.3
    IL_0094:  ldloc.3
    IL_0095:  ldstr      ".EO Configuration."
    IL_009a:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_009f:  stloc.3
    IL_00a0:  ldloc.1
    IL_00a1:  ldstr      "LOCALSCRIPT"
    IL_00a6:  ldc.i4.5
    IL_00a7:  call       int32 [mscorlib]System.String::Compare(string,
                                                                string,
                                                                valuetype [mscorlib]System.StringComparison)
    IL_00ac:  brtrue     IL_0155

    IL_00b1:  ldloc.2
    IL_00b2:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_00b7:  brtrue.s   IL_0133

    IL_00b9:  newobj     instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::.ctor()
    IL_00be:  dup
    IL_00bf:  ldstr      "MMScMethod.MMScMethod_Setup_LocScr"
    IL_00c4:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_FormProgId(string)
    IL_00c9:  dup
    IL_00ca:  ldc.i4.0
    IL_00cb:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_LegacyFlags(int16)
    IL_00d0:  dup
    IL_00d1:  ldc.i4     0xa6
    IL_00d6:  newobj     instance void valuetype [mscorlib]System.Nullable`1<int32>::.ctor(!0)
    IL_00db:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_HelpId(valuetype [mscorlib]System.Nullable`1<int32>)
    IL_00e0:  dup
    IL_00e1:  ldstr      "eoconf.hlp"
    IL_00e6:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_HelpFile(string)
    IL_00eb:  dup
    IL_00ec:  ldc.i4.1
    IL_00ed:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_ShowPrompts(bool)
    IL_00f2:  dup
    IL_00f3:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.Properties.Resources::get_MMACMModel_Blocko_EOOptions_LocalScript()
    IL_00f8:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_ShortName(string)
    IL_00fd:  stloc.s    V_5
    IL_00ff:  ldloc.3
    IL_0100:  ldstr      "Local Scripts."
    IL_0105:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_010a:  stloc.s    V_6
    IL_010c:  ldloc.s    V_5
    IL_010e:  callvirt   instance class [mscorlib]System.Collections.Generic.Dictionary`2<string,object> [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::get_Parameters()
    IL_0113:  ldstr      "Input"
    IL_0118:  ldloc.s    V_6
    IL_011a:  ldloc.2
    IL_011b:  ldstr      ".Input"
    IL_0120:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0125:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,object>::Add(!0,
                                                                                                                   !1)
    IL_012a:  ldarg.0
    IL_012b:  ldloc.s    V_5
    IL_012d:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::DisplayForm(class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs)
    IL_0132:  ret

    IL_0133:  ldarg.0
    IL_0134:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CompositeEvents.ShowMessageBoxEventArgs::.ctor()
    IL_0139:  dup
    IL_013a:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.Properties.Resources::get_MMACMModel_Blocko_EOOptions_SpecifyGlobalScriptID()
    IL_013f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CompositeEvents.ShowMessageBoxEventArgs::set_Message(string)
    IL_0144:  dup
    IL_0145:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.Properties.Resources::get_MMACMModel_Blocko_EOOptions_EditVariable()
    IL_014a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CompositeEvents.ShowMessageBoxEventArgs::set_Title(string)
    IL_014f:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ShowMessageBox(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CompositeEvents.ShowMessageBoxEventArgs)
    IL_0154:  ret

    IL_0155:  ldloc.1
    IL_0156:  ldstr      "GLOBALSCRIPT"
    IL_015b:  ldc.i4.5
    IL_015c:  call       int32 [mscorlib]System.String::Compare(string,
                                                                string,
                                                                valuetype [mscorlib]System.StringComparison)
    IL_0161:  brtrue     IL_0209

    IL_0166:  ldloc.2
    IL_0167:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_016c:  brtrue.s   IL_01e8

    IL_016e:  newobj     instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::.ctor()
    IL_0173:  dup
    IL_0174:  ldstr      "MMScMethod.MMScMethod_Setup_GloScr"
    IL_0179:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_FormProgId(string)
    IL_017e:  dup
    IL_017f:  ldc.i4.0
    IL_0180:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_LegacyFlags(int16)
    IL_0185:  dup
    IL_0186:  ldc.i4     0xa6
    IL_018b:  newobj     instance void valuetype [mscorlib]System.Nullable`1<int32>::.ctor(!0)
    IL_0190:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_HelpId(valuetype [mscorlib]System.Nullable`1<int32>)
    IL_0195:  dup
    IL_0196:  ldstr      "eoconf.hlp"
    IL_019b:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_HelpFile(string)
    IL_01a0:  dup
    IL_01a1:  ldc.i4.1
    IL_01a2:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_ShowPrompts(bool)
    IL_01a7:  dup
    IL_01a8:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.Properties.Resources::get_MMACMModel_Blocko_EOOptions_GlobalScript()
    IL_01ad:  callvirt   instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::set_ShortName(string)
    IL_01b2:  stloc.s    V_7
    IL_01b4:  ldloc.3
    IL_01b5:  ldstr      "Global Scripts."
    IL_01ba:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_01bf:  stloc.s    V_8
    IL_01c1:  ldloc.s    V_7
    IL_01c3:  callvirt   instance class [mscorlib]System.Collections.Generic.Dictionary`2<string,object> [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs::get_Parameters()
    IL_01c8:  ldstr      "Input"
    IL_01cd:  ldloc.s    V_8
    IL_01cf:  ldloc.2
    IL_01d0:  ldstr      ".Input"
    IL_01d5:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_01da:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,object>::Add(!0,
                                                                                                                   !1)
    IL_01df:  ldarg.0
    IL_01e0:  ldloc.s    V_7
    IL_01e2:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::DisplayForm(class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.CompositeEvents.DisplayFormEventArgs)
    IL_01e7:  ret

    IL_01e8:  ldarg.0
    IL_01e9:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CompositeEvents.ShowMessageBoxEventArgs::.ctor()
    IL_01ee:  dup
    IL_01ef:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.Properties.Resources::get_MMACMModel_Blocko_EOOptions_SpecifyGlobalScriptID()
    IL_01f4:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CompositeEvents.ShowMessageBoxEventArgs::set_Message(string)
    IL_01f9:  dup
    IL_01fa:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.Properties.Resources::get_MMACMModel_Blocko_EOOptions_EditVariable()
    IL_01ff:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CompositeEvents.ShowMessageBoxEventArgs::set_Title(string)
    IL_0204:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ShowMessageBox(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CompositeEvents.ShowMessageBoxEventArgs)
    IL_0209:  ret
  } // end of method MMACMModel_Blocko_EOOptions_ViewModel::cmdEdit_CommandExecute

  .method private hidebysig instance bool 
          cmdEdit_CommandCanExecute(object parameter) cil managed
  {
    // Code size       118 (0x76)
    .maxstack  3
    .locals init (int32 V_0,
             class [mscorlib]System.Collections.IList V_1,
             string V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_selectedRowIndexes
    IL_0006:  brfalse.s  IL_0074

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_selectedRowIndexes
    IL_000e:  callvirt   instance int32 class [mscorlib]System.Collections.ObjectModel.Collection`1<int32>::get_Count()
    IL_0013:  ldc.i4.1
    IL_0014:  bne.un.s   IL_0074

    IL_0016:  ldarg.0
    IL_0017:  ldfld      class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_selectedRowIndexes
    IL_001c:  ldc.i4.0
    IL_001d:  callvirt   instance !0 class [mscorlib]System.Collections.ObjectModel.Collection`1<int32>::get_Item(int32)
    IL_0022:  stloc.0
    IL_0023:  ldarg.0
    IL_0024:  call       instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::get_grdScMeth_GridData()
    IL_0029:  isinst     [mscorlib]System.Collections.IList
    IL_002e:  stloc.1
    IL_002f:  ldloc.0
    IL_0030:  ldc.i4.0
    IL_0031:  blt.s      IL_0074

    IL_0033:  ldloc.0
    IL_0034:  ldloc.1
    IL_0035:  callvirt   instance int32 [mscorlib]System.Collections.ICollection::get_Count()
    IL_003a:  ldc.i4.1
    IL_003b:  sub
    IL_003c:  bge.s      IL_0074

    IL_003e:  ldloc.1
    IL_003f:  ldloc.0
    IL_0040:  callvirt   instance object [mscorlib]System.Collections.IList::get_Item(int32)
    IL_0045:  isinst     AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
    IL_004a:  ldstr      "MMComboBox2_var1.Value"
    IL_004f:  call       object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.ICxvViewDataContainerExtensions::ResolveViewPropertyPath(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.ICxvViewDataContainer,
                                                                                                                                                          string)
    IL_0054:  isinst     [mscorlib]System.String
    IL_0059:  stloc.2
    IL_005a:  ldloc.2
    IL_005b:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0060:  brtrue.s   IL_0072

    IL_0062:  ldloc.2
    IL_0063:  ldstr      "File"
    IL_0068:  ldc.i4.3
    IL_0069:  call       int32 [mscorlib]System.String::Compare(string,
                                                                string,
                                                                valuetype [mscorlib]System.StringComparison)
    IL_006e:  ldc.i4.0
    IL_006f:  cgt.un
    IL_0071:  ret

    IL_0072:  ldc.i4.0
    IL_0073:  ret

    IL_0074:  ldc.i4.0
    IL_0075:  ret
  } // end of method MMACMModel_Blocko_EOOptions_ViewModel::cmdEdit_CommandCanExecute

  .method public hidebysig specialname instance class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> 
          get_SelectedRowIndexes() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_selectedRowIndexes
    IL_0006:  ret
  } // end of method MMACMModel_Blocko_EOOptions_ViewModel::get_SelectedRowIndexes

  .method public hidebysig specialname instance void 
          set_SelectedRowIndexes(class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> 'value') cil managed
  {
    // Code size       63 (0x3f)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldarg.0
    IL_0002:  ldfld      class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_selectedRowIndexes
    IL_0007:  beq.s      IL_003e

    IL_0009:  ldarg.0
    IL_000a:  ldarg.1
    IL_000b:  stfld      class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_selectedRowIndexes
    IL_0010:  ldarg.0
    IL_0011:  ldfld      class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_selectedRowIndexes
    IL_0016:  ldarg.0
    IL_0017:  ldftn      instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::'<set_SelectedRowIndexes>b__12_0'(object,
                                                                                                                                                            class [System]System.Collections.Specialized.NotifyCollectionChangedEventArgs)
    IL_001d:  newobj     instance void [System]System.Collections.Specialized.NotifyCollectionChangedEventHandler::.ctor(object,
                                                                                                                         native int)
    IL_0022:  callvirt   instance void class [System]System.Collections.ObjectModel.ObservableCollection`1<int32>::remove_CollectionChanged(class [System]System.Collections.Specialized.NotifyCollectionChangedEventHandler)
    IL_0027:  ldarg.0
    IL_0028:  ldfld      class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::_selectedRowIndexes
    IL_002d:  ldarg.0
    IL_002e:  ldftn      instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::'<set_SelectedRowIndexes>b__12_1'(object,
                                                                                                                                                            class [System]System.Collections.Specialized.NotifyCollectionChangedEventArgs)
    IL_0034:  newobj     instance void [System]System.Collections.Specialized.NotifyCollectionChangedEventHandler::.ctor(object,
                                                                                                                         native int)
    IL_0039:  callvirt   instance void class [System]System.Collections.ObjectModel.ObservableCollection`1<int32>::add_CollectionChanged(class [System]System.Collections.Specialized.NotifyCollectionChangedEventHandler)
    IL_003e:  ret
  } // end of method MMACMModel_Blocko_EOOptions_ViewModel::set_SelectedRowIndexes

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMACMModel_Blocko_EOOptions_ViewModel::.ctor

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       87 (0x57)
    .maxstack  7
    IL_0000:  ldstr      "grdScMeth_GridData"
    IL_0005:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel
    IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_000f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVectorProperty::.ctor()
    IL_0014:  dup
    IL_0015:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel/grdScMeth_GridData_ItemTemplate
    IL_001a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_001f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVectorProperty::set_ItemType(class [mscorlib]System.Type)
    IL_0024:  dup
    IL_0025:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvChildCountIndexBasis::.ctor()
    IL_002a:  dup
    IL_002b:  ldstr      "@main.Input.SC_METHOD"
    IL_0030:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvChildCountIndexBasis::set_DataPath(string)
    IL_0035:  dup
    IL_0036:  ldc.i4.1
    IL_0037:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvChildCountIndexBasis::set_UseChildId(bool)
    IL_003c:  dup
    IL_003d:  ldstr      "y"
    IL_0042:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvIndexBasisBase::set_Name(string)
    IL_0047:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVectorProperty::set_IndexBasis(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvIndexBasisBase)
    IL_004c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0051:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::grdScMeth_GridData_Property
    IL_0056:  ret
  } // end of method MMACMModel_Blocko_EOOptions_ViewModel::.cctor

  .method private hidebysig instance void 
          '<set_SelectedRowIndexes>b__12_0'(object '<p0>',
                                            class [System]System.Collections.Specialized.NotifyCollectionChangedEventArgs '<p1>') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::get_cmdEdit_Command()
    IL_0006:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object>::RaiseCanExecuteChanged()
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_EOOptions_ViewModel::'<set_SelectedRowIndexes>b__12_0'

  .method private hidebysig instance void 
          '<set_SelectedRowIndexes>b__12_1'(object '<p0>',
                                            class [System]System.Collections.Specialized.NotifyCollectionChangedEventArgs '<p1>') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::get_cmdEdit_Command()
    IL_0006:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object>::RaiseCanExecuteChanged()
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_EOOptions_ViewModel::'<set_SelectedRowIndexes>b__12_1'

  .property instance callconv(8) object grdScMeth_GridData()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::get_grdScMeth_GridData()
  } // end of property MMACMModel_Blocko_EOOptions_ViewModel::grdScMeth_GridData
  .property instance callconv(8) class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object>
          cmdEdit_Command()
  {
    .get instance class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Commands.DelegateCommand`1<object> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::get_cmdEdit_Command()
  } // end of property MMACMModel_Blocko_EOOptions_ViewModel::cmdEdit_Command
  .property instance callconv(8) class [System]System.Collections.ObjectModel.ObservableCollection`1<int32>
          SelectedRowIndexes()
  {
    .get instance class [System]System.Collections.ObjectModel.ObservableCollection`1<int32> AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::get_SelectedRowIndexes()
    .set instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel::set_SelectedRowIndexes(class [System]System.Collections.ObjectModel.ObservableCollection`1<int32>)
  } // end of property MMACMModel_Blocko_EOOptions_ViewModel::SelectedRowIndexes
} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 26 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..&MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 42 6C 6F 63 6B 6F 5F   // ACMModel_Blocko_
                                                                                                    45 4F 4F 70 74 69 6F 6E 73 00 00 )                // EOOptions..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox MMFrame2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMScrollArea grdScMeth
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton cmdEdit
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_Blocko_EOOptions::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_blocko_eooptions.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_Blocko_EOOptions::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       69 (0x45)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_0016,
                          IL_0023,
                          IL_0030)
    IL_0014:  br.s       IL_003d

    IL_0016:  ldarg.0
    IL_0017:  ldarg.2
    IL_0018:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_001d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions::MMFrame2
    IL_0022:  ret

    IL_0023:  ldarg.0
    IL_0024:  ldarg.2
    IL_0025:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMScrollArea
    IL_002a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMScrollArea AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions::grdScMeth
    IL_002f:  ret

    IL_0030:  ldarg.0
    IL_0031:  ldarg.2
    IL_0032:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_0037:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions::cmdEdit
    IL_003c:  ret

    IL_003d:  ldarg.0
    IL_003e:  ldc.i4.1
    IL_003f:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions::_contentLoaded
    IL_0044:  ret
  } // end of method MMACMModel_Blocko_EOOptions::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_EOOptions

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMFrame3_state_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMLBUText9_tol_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMSpinBox1_maxit_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration frmEst_state_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMLBUText8_pest_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMLBUText7_test_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration frmFlSpec_state_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboBox2_MultiMap_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMLBUText6_vfrac_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMLBUText5_pres_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMLBUText4_temp_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMMenuButton1_target_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMMenuButton1_flashstream_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration cboKode_MultiMap_Property
  .method public hidebysig specialname instance object 
          get_MMFrame3_state() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMFrame3_state_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMFrame3_state

  .method public hidebysig specialname instance object 
          get_MMLBUText9_tol() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText9_tol_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText9_tol

  .method public hidebysig specialname instance object 
          get_MMSpinBox1_maxit() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMSpinBox1_maxit_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMSpinBox1_maxit

  .method public hidebysig specialname instance object 
          get_frmEst_state() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::frmEst_state_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_frmEst_state

  .method public hidebysig specialname instance object 
          get_MMLBUText8_pest() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText8_pest_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText8_pest

  .method public hidebysig specialname instance object 
          get_MMLBUText7_test() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText7_test_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText7_test

  .method public hidebysig specialname instance object 
          get_frmFlSpec_state() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::frmFlSpec_state_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_frmFlSpec_state

  .method public hidebysig specialname instance object 
          get_MMComboBox2_MultiMap() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMComboBox2_MultiMap_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMComboBox2_MultiMap

  .method public hidebysig specialname instance object 
          get_MMLBUText6_vfrac() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText6_vfrac_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText6_vfrac

  .method public hidebysig specialname instance object 
          get_MMLBUText5_pres() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText5_pres_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText5_pres

  .method public hidebysig specialname instance object 
          get_MMLBUText4_temp() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText4_temp_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText4_temp

  .method public hidebysig specialname instance object 
          get_MMMenuButton1_target() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMMenuButton1_target_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMMenuButton1_target

  .method public hidebysig specialname instance object 
          get_MMMenuButton1_flashstream() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMMenuButton1_flashstream_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_MMMenuButton1_flashstream

  .method public hidebysig specialname instance object 
          get_cboKode_MultiMap() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::cboKode_MultiMap_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::get_cboKode_MultiMap

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::.ctor

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       3070 (0xbfe)
    .maxstack  9
    IL_0000:  ldstr      "MMFrame3_state"
    IL_0005:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_000f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvGroupBoxProperty::.ctor()
    IL_0014:  dup
    IL_0015:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
    IL_001a:  dup
    IL_001b:  ldstr      "@main.CC Nodes.KOD.@choice"
    IL_0020:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
    IL_0025:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
    IL_002a:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_002f:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMFrame3_state_Property
    IL_0034:  ldstr      "MMLBUText9_tol"
    IL_0039:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_003e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0043:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0048:  dup
    IL_0049:  ldstr      "@main.Input.TOL.@choice"
    IL_004e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0053:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0058:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText9_tol_Property
    IL_005d:  ldstr      "MMSpinBox1_maxit"
    IL_0062:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_0067:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_006c:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0071:  dup
    IL_0072:  ldstr      "@main.Input.MAXIT.@choice"
    IL_0077:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_007c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0081:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMSpinBox1_maxit_Property
    IL_0086:  ldstr      "frmEst_state"
    IL_008b:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_0090:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0095:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvGroupBoxProperty::.ctor()
    IL_009a:  dup
    IL_009b:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
    IL_00a0:  dup
    IL_00a1:  ldstr      "@main.CC Nodes.KOD.@choice"
    IL_00a6:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
    IL_00ab:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
    IL_00b0:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_00b5:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::frmEst_state_Property
    IL_00ba:  ldstr      "MMLBUText8_pest"
    IL_00bf:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_00c4:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_00c9:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_00ce:  dup
    IL_00cf:  ldstr      "@main.Input.P_EST.@choice"
    IL_00d4:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_00d9:  dup
    IL_00da:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
    IL_00df:  dup
    IL_00e0:  ldstr      "@main.CC Nodes.PEST.@choice"
    IL_00e5:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
    IL_00ea:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
    IL_00ef:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_00f4:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText8_pest_Property
    IL_00f9:  ldstr      "MMLBUText7_test"
    IL_00fe:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_0103:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0108:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_010d:  dup
    IL_010e:  ldstr      "@main.Input.T_EST.@choice"
    IL_0113:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0118:  dup
    IL_0119:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
    IL_011e:  dup
    IL_011f:  ldstr      "@main.CC Nodes.TEST.@choice"
    IL_0124:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
    IL_0129:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
    IL_012e:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0133:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText7_test_Property
    IL_0138:  ldstr      "frmFlSpec_state"
    IL_013d:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_0142:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0147:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvGroupBoxProperty::.ctor()
    IL_014c:  dup
    IL_014d:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
    IL_0152:  dup
    IL_0153:  ldstr      "@main.CC Nodes.KOD.@choice"
    IL_0158:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
    IL_015d:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
    IL_0162:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0167:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::frmFlSpec_state_Property
    IL_016c:  ldstr      "MMComboBox2_MultiMap"
    IL_0171:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_0176:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_017b:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::.ctor()
    IL_0180:  dup
    IL_0181:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariableCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Variables()
    IL_0186:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::.ctor()
    IL_018b:  dup
    IL_018c:  ldstr      "MMComboBox2_nphase"
    IL_0191:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_Name(string)
    IL_0196:  dup
    IL_0197:  ldstr      "@main.Input.NPHASE.@choice"
    IL_019c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_DataPath(string)
    IL_01a1:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable>::Add(!0)
    IL_01a6:  dup
    IL_01a7:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariableCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Variables()
    IL_01ac:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::.ctor()
    IL_01b1:  dup
    IL_01b2:  ldstr      "MMComboBox2_phase"
    IL_01b7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_Name(string)
    IL_01bc:  dup
    IL_01bd:  ldstr      "@main.Input.PHASE.@choice"
    IL_01c2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_DataPath(string)
    IL_01c7:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable>::Add(!0)
    IL_01cc:  dup
    IL_01cd:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariableCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Variables()
    IL_01d2:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::.ctor()
    IL_01d7:  dup
    IL_01d8:  ldstr      "MMComboBox2_freewater"
    IL_01dd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_Name(string)
    IL_01e2:  dup
    IL_01e3:  ldstr      "@main.Input.FREE_WATER.@choice"
    IL_01e8:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_DataPath(string)
    IL_01ed:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable>::Add(!0)
    IL_01f2:  dup
    IL_01f3:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_01f8:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_01fd:  dup
    IL_01fe:  ldstr      "Vapor-Only"
    IL_0203:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0208:  dup
    IL_0209:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Vapor_Only"
    IL_020e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_0213:  dup
    IL_0214:  ldstr      "MMComboBox2_MultiMapOption_1"
    IL_0219:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_021e:  dup
    IL_021f:  ldstr      "Only a vapor phase exists."
    IL_0224:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Prompt(string)
    IL_0229:  dup
    IL_022a:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Prompt_Only_a_vapor_phase_exists_"
    IL_022f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_PromptResourceKey(string)
    IL_0234:  dup
    IL_0235:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_023a:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_023f:  dup
    IL_0240:  ldstr      "MMComboBox2_nphase"
    IL_0245:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_024a:  dup
    IL_024b:  ldstr      "1"
    IL_0250:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0255:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_025a:  dup
    IL_025b:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0260:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0265:  dup
    IL_0266:  ldstr      "MMComboBox2_phase"
    IL_026b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0270:  dup
    IL_0271:  ldstr      "V"
    IL_0276:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_027b:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0280:  dup
    IL_0281:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0286:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_028b:  dup
    IL_028c:  ldstr      "MMComboBox2_freewater"
    IL_0291:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0296:  dup
    IL_0297:  ldstr      "NO"
    IL_029c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_02a1:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_02a6:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_02ab:  dup
    IL_02ac:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_02b1:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_02b6:  dup
    IL_02b7:  ldstr      "Liquid-Only"
    IL_02bc:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_02c1:  dup
    IL_02c2:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Liquid_Only"
    IL_02c7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_02cc:  dup
    IL_02cd:  ldstr      "MMComboBox2_MultiMapOption_2"
    IL_02d2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_02d7:  dup
    IL_02d8:  ldstr      "Only a single liquid phase exists."
    IL_02dd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Prompt(string)
    IL_02e2:  dup
    IL_02e3:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Prompt_Only_a_single_liquid_phase_exists_"
    IL_02e8:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_PromptResourceKey(string)
    IL_02ed:  dup
    IL_02ee:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_02f3:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_02f8:  dup
    IL_02f9:  ldstr      "MMComboBox2_nphase"
    IL_02fe:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0303:  dup
    IL_0304:  ldstr      "1"
    IL_0309:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_030e:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0313:  dup
    IL_0314:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0319:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_031e:  dup
    IL_031f:  ldstr      "MMComboBox2_phase"
    IL_0324:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0329:  dup
    IL_032a:  ldstr      "L"
    IL_032f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0334:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0339:  dup
    IL_033a:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_033f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0344:  dup
    IL_0345:  ldstr      "MMComboBox2_freewater"
    IL_034a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_034f:  dup
    IL_0350:  ldstr      "NO"
    IL_0355:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_035a:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_035f:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0364:  dup
    IL_0365:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_036a:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_036f:  dup
    IL_0370:  ldstr      "Solid-Only"
    IL_0375:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_037a:  dup
    IL_037b:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Solid_Only"
    IL_0380:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_0385:  dup
    IL_0386:  ldstr      "MMComboBox2_MultiMapOption_3"
    IL_038b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_0390:  dup
    IL_0391:  ldstr      "Only pure salts (electrolytes) or solids exist."
    IL_0396:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Prompt(string)
    IL_039b:  dup
    IL_039c:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Prompt_Only_pure_salts__electrolytes__or_solid"
    IL_03a1:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_PromptResourceKey(string)
    IL_03a6:  dup
    IL_03a7:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_03ac:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_03b1:  dup
    IL_03b2:  ldstr      "MMComboBox2_nphase"
    IL_03b7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_03bc:  dup
    IL_03bd:  ldstr      "1"
    IL_03c2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_03c7:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_03cc:  dup
    IL_03cd:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_03d2:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_03d7:  dup
    IL_03d8:  ldstr      "MMComboBox2_phase"
    IL_03dd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_03e2:  dup
    IL_03e3:  ldstr      "S"
    IL_03e8:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_03ed:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_03f2:  dup
    IL_03f3:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_03f8:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_03fd:  dup
    IL_03fe:  ldstr      "MMComboBox2_freewater"
    IL_0403:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0408:  dup
    IL_0409:  ldstr      "NO"
    IL_040e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0413:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0418:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_041d:  dup
    IL_041e:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_0423:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0428:  dup
    IL_0429:  ldstr      "Vapor-Liquid"
    IL_042e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0433:  dup
    IL_0434:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Vapor_Liquid"
    IL_0439:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_043e:  dup
    IL_043f:  ldstr      "MMComboBox2_MultiMapOption_4"
    IL_0444:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_0449:  dup
    IL_044a:  ldstr      "2 phases (vapor and liquid) are considered in phas"
    + "e equilibrium calculations."
    IL_044f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Prompt(string)
    IL_0454:  dup
    IL_0455:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Prompt_2_phases__vapor_and_liquid__are_conside"
    IL_045a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_PromptResourceKey(string)
    IL_045f:  dup
    IL_0460:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0465:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_046a:  dup
    IL_046b:  ldstr      "MMComboBox2_nphase"
    IL_0470:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0475:  dup
    IL_0476:  ldstr      "2"
    IL_047b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0480:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0485:  dup
    IL_0486:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_048b:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0490:  dup
    IL_0491:  ldstr      "MMComboBox2_phase"
    IL_0496:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_049b:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_04a0:  dup
    IL_04a1:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_04a6:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_04ab:  dup
    IL_04ac:  ldstr      "MMComboBox2_freewater"
    IL_04b1:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_04b6:  dup
    IL_04b7:  ldstr      "NO"
    IL_04bc:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_04c1:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_04c6:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_04cb:  dup
    IL_04cc:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_04d1:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_04d6:  dup
    IL_04d7:  ldstr      "Vapor-Liquid-Liquid"
    IL_04dc:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_04e1:  dup
    IL_04e2:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Vapor_Liquid_Liquid"
    IL_04e7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_04ec:  dup
    IL_04ed:  ldstr      "MMComboBox2_MultiMapOption_5"
    IL_04f2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_04f7:  dup
    IL_04f8:  ldstr      "3 phases (vapor and two liquid phases) are conside"
    + "red in phase equilibrium calculations."
    IL_04fd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Prompt(string)
    IL_0502:  dup
    IL_0503:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Prompt_3_phases__vapor_and_two_liquid_phases__"
    IL_0508:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_PromptResourceKey(string)
    IL_050d:  dup
    IL_050e:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0513:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0518:  dup
    IL_0519:  ldstr      "MMComboBox2_nphase"
    IL_051e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0523:  dup
    IL_0524:  ldstr      "3"
    IL_0529:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_052e:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0533:  dup
    IL_0534:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0539:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_053e:  dup
    IL_053f:  ldstr      "MMComboBox2_phase"
    IL_0544:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0549:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_054e:  dup
    IL_054f:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0554:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0559:  dup
    IL_055a:  ldstr      "MMComboBox2_freewater"
    IL_055f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0564:  dup
    IL_0565:  ldstr      "NO"
    IL_056a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_056f:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0574:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0579:  dup
    IL_057a:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_057f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0584:  dup
    IL_0585:  ldstr      "Liquid-FreeWater"
    IL_058a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_058f:  dup
    IL_0590:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Liquid_FreeWater"
    IL_0595:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_059a:  dup
    IL_059b:  ldstr      "MMComboBox2_MultiMapOption_6"
    IL_05a0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_05a5:  dup
    IL_05a6:  ldstr      "2 liquid phases (organic and pure water) are consi"
    + "dered in phase equilibrium calculations."
    IL_05ab:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Prompt(string)
    IL_05b0:  dup
    IL_05b1:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Prompt_2_liquid_phases__organic_and_pure_water"
    IL_05b6:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_PromptResourceKey(string)
    IL_05bb:  dup
    IL_05bc:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_05c1:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_05c6:  dup
    IL_05c7:  ldstr      "MMComboBox2_nphase"
    IL_05cc:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_05d1:  dup
    IL_05d2:  ldstr      "1"
    IL_05d7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_05dc:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_05e1:  dup
    IL_05e2:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_05e7:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_05ec:  dup
    IL_05ed:  ldstr      "MMComboBox2_phase"
    IL_05f2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_05f7:  dup
    IL_05f8:  ldstr      "L"
    IL_05fd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0602:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0607:  dup
    IL_0608:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_060d:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0612:  dup
    IL_0613:  ldstr      "MMComboBox2_freewater"
    IL_0618:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_061d:  dup
    IL_061e:  ldstr      "YES"
    IL_0623:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0628:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_062d:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0632:  dup
    IL_0633:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_0638:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_063d:  dup
    IL_063e:  ldstr      "Vapor-Liquid-FreeWater"
    IL_0643:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0648:  dup
    IL_0649:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Vapor_Liquid_FreeWater"
    IL_064e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_0653:  dup
    IL_0654:  ldstr      "MMComboBox2_MultiMapOption_7"
    IL_0659:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_065e:  dup
    IL_065f:  ldstr      "3 liquid phases (vapor, organic and pure water) ar"
    + "e considered in phase equilibrium calculations."
    IL_0664:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Prompt(string)
    IL_0669:  dup
    IL_066a:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Prompt_3_liquid_phases__vapor__organic_and_pur"
    IL_066f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_PromptResourceKey(string)
    IL_0674:  dup
    IL_0675:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_067a:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_067f:  dup
    IL_0680:  ldstr      "MMComboBox2_nphase"
    IL_0685:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_068a:  dup
    IL_068b:  ldstr      "2"
    IL_0690:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0695:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_069a:  dup
    IL_069b:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_06a0:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_06a5:  dup
    IL_06a6:  ldstr      "MMComboBox2_phase"
    IL_06ab:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_06b0:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_06b5:  dup
    IL_06b6:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_06bb:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_06c0:  dup
    IL_06c1:  ldstr      "MMComboBox2_freewater"
    IL_06c6:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_06cb:  dup
    IL_06cc:  ldstr      "YES"
    IL_06d1:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_06d6:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_06db:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_06e0:  dup
    IL_06e1:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_06e6:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_06eb:  dup
    IL_06ec:  ldstr      "Liquid-DirtyWater"
    IL_06f1:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_06f6:  dup
    IL_06f7:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Liquid_DirtyWater"
    IL_06fc:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_0701:  dup
    IL_0702:  ldstr      "MMComboBox2_MultiMapOption_8"
    IL_0707:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_070c:  dup
    IL_070d:  ldstr      "2 liquid phases (organic and dirty water) are cons"
    + "idered in phase equilibrium calculations."
    IL_0712:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Prompt(string)
    IL_0717:  dup
    IL_0718:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Prompt_2_liquid_phases__organic_and_dirty_wate"
    IL_071d:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_PromptResourceKey(string)
    IL_0722:  dup
    IL_0723:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0728:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_072d:  dup
    IL_072e:  ldstr      "MMComboBox2_nphase"
    IL_0733:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0738:  dup
    IL_0739:  ldstr      "1"
    IL_073e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0743:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0748:  dup
    IL_0749:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_074e:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0753:  dup
    IL_0754:  ldstr      "MMComboBox2_phase"
    IL_0759:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_075e:  dup
    IL_075f:  ldstr      "L"
    IL_0764:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0769:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_076e:  dup
    IL_076f:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0774:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0779:  dup
    IL_077a:  ldstr      "MMComboBox2_freewater"
    IL_077f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0784:  dup
    IL_0785:  ldstr      "DIRTY"
    IL_078a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_078f:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0794:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0799:  dup
    IL_079a:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_079f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_07a4:  dup
    IL_07a5:  ldstr      "Vapor-Liquid-DirtyWater"
    IL_07aa:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_07af:  dup
    IL_07b0:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Vapor_Liquid_DirtyWater"
    IL_07b5:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_07ba:  dup
    IL_07bb:  ldstr      "MMComboBox2_MultiMapOption_9"
    IL_07c0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_07c5:  dup
    IL_07c6:  ldstr      "3 liquid phases (vapor, organic and dirty water) a"
    + "re considered in phase equilibrium calculations."
    IL_07cb:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Prompt(string)
    IL_07d0:  dup
    IL_07d1:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Prompt_3_liquid_phases__vapor__organic_and_dir"
    IL_07d6:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_PromptResourceKey(string)
    IL_07db:  dup
    IL_07dc:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_07e1:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_07e6:  dup
    IL_07e7:  ldstr      "MMComboBox2_nphase"
    IL_07ec:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_07f1:  dup
    IL_07f2:  ldstr      "2"
    IL_07f7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_07fc:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0801:  dup
    IL_0802:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0807:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_080c:  dup
    IL_080d:  ldstr      "MMComboBox2_phase"
    IL_0812:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0817:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_081c:  dup
    IL_081d:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0822:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0827:  dup
    IL_0828:  ldstr      "MMComboBox2_freewater"
    IL_082d:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0832:  dup
    IL_0833:  ldstr      "DIRTY"
    IL_0838:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_083d:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0842:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0847:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_084c:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMComboBox2_MultiMap_Property
    IL_0851:  ldstr      "MMLBUText6_vfrac"
    IL_0856:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_085b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0860:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0865:  dup
    IL_0866:  ldstr      "@main.Input.VFRAC.@choice"
    IL_086b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0870:  dup
    IL_0871:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
    IL_0876:  dup
    IL_0877:  ldstr      "@main.CC Nodes.VAPFR.@choice"
    IL_087c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
    IL_0881:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
    IL_0886:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_088b:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText6_vfrac_Property
    IL_0890:  ldstr      "MMLBUText5_pres"
    IL_0895:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_089a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_089f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_08a4:  dup
    IL_08a5:  ldstr      "@main.Input.PRES.@choice"
    IL_08aa:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_08af:  dup
    IL_08b0:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
    IL_08b5:  dup
    IL_08b6:  ldstr      "@main.CC Nodes.PRESS.@choice"
    IL_08bb:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
    IL_08c0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
    IL_08c5:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_08ca:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText5_pres_Property
    IL_08cf:  ldstr      "MMLBUText4_temp"
    IL_08d4:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_08d9:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_08de:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_08e3:  dup
    IL_08e4:  ldstr      "@main.Input.TEMP.@choice"
    IL_08e9:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_08ee:  dup
    IL_08ef:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
    IL_08f4:  dup
    IL_08f5:  ldstr      "@main.CC Nodes.TEMPR.@choice"
    IL_08fa:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
    IL_08ff:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
    IL_0904:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0909:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMLBUText4_temp_Property
    IL_090e:  ldstr      "MMMenuButton1_target"
    IL_0913:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_0918:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_091d:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvParameterProperty::.ctor()
    IL_0922:  dup
    IL_0923:  ldstr      "choice"
    IL_0928:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvParameterProperty::set_Parameter(string)
    IL_092d:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0932:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMMenuButton1_target_Property
    IL_0937:  ldstr      "MMMenuButton1_flashstream"
    IL_093c:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_0941:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0946:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvAdvCollectionProperty::.ctor()
    IL_094b:  dup
    IL_094c:  ldstr      "@main.Input.NPHASE"
    IL_0951:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvAdvCollectionProperty::set_DataPath(string)
    IL_0956:  dup
    IL_0957:  ldstr      "MMMenuButton1_target.Value"
    IL_095c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvAdvCollectionProperty::set_SelectedItemBinding(string)
    IL_0961:  dup
    IL_0962:  ldstr      "Stream:"
    IL_0967:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvAdvCollectionProperty::set_CreateNewPrompt(string)
    IL_096c:  dup
    IL_096d:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvAdvCollecti"
    + "onProperty_CreateNewPrompt_Stream_"
    IL_0972:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvAdvCollectionProperty::set_CreateNewPromptResourceKey(string)
    IL_0977:  dup
    IL_0978:  callvirt   instance class [mscorlib]System.Collections.ObjectModel.Collection`1<string> [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvAdvCollectionProperty::get_CompletePaths()
    IL_097d:  ldstr      "FLSP"
    IL_0982:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<string>::Add(!0)
    IL_0987:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_098c:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::MMMenuButton1_flashstream_Property
    IL_0991:  ldstr      "cboKode_MultiMap"
    IL_0996:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_099b:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_09a0:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::.ctor()
    IL_09a5:  dup
    IL_09a6:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariableCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Variables()
    IL_09ab:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::.ctor()
    IL_09b0:  dup
    IL_09b1:  ldstr      "cboKode_kode"
    IL_09b6:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_Name(string)
    IL_09bb:  dup
    IL_09bc:  ldstr      "@main.Input.KODE.@choice"
    IL_09c1:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_DataPath(string)
    IL_09c6:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable>::Add(!0)
    IL_09cb:  dup
    IL_09cc:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_09d1:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_09d6:  dup
    IL_09d7:  ldstr      "Temperature & pressure"
    IL_09dc:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_09e1:  dup
    IL_09e2:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Temperature___pressure"
    IL_09e7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_09ec:  dup
    IL_09ed:  ldstr      "cboKode_MultiMapOption_1"
    IL_09f2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_09f7:  dup
    IL_09f8:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_09fd:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0a02:  dup
    IL_0a03:  ldstr      "cboKode_kode"
    IL_0a08:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0a0d:  dup
    IL_0a0e:  ldstr      "TP"
    IL_0a13:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0a18:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0a1d:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0a22:  dup
    IL_0a23:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_0a28:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0a2d:  dup
    IL_0a2e:  ldstr      "Temperature & vapor fraction"
    IL_0a33:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0a38:  dup
    IL_0a39:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Temperature___vapor_fraction"
    IL_0a3e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_0a43:  dup
    IL_0a44:  ldstr      "cboKode_MultiMapOption_2"
    IL_0a49:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_0a4e:  dup
    IL_0a4f:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0a54:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0a59:  dup
    IL_0a5a:  ldstr      "cboKode_kode"
    IL_0a5f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0a64:  dup
    IL_0a65:  ldstr      "TV"
    IL_0a6a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0a6f:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0a74:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0a79:  dup
    IL_0a7a:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_0a7f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0a84:  dup
    IL_0a85:  ldstr      "Temperature & enthalpy"
    IL_0a8a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0a8f:  dup
    IL_0a90:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Temperature___enthalpy"
    IL_0a95:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_0a9a:  dup
    IL_0a9b:  ldstr      "cboKode_MultiMapOption_3"
    IL_0aa0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_0aa5:  dup
    IL_0aa6:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0aab:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0ab0:  dup
    IL_0ab1:  ldstr      "cboKode_kode"
    IL_0ab6:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0abb:  dup
    IL_0abc:  ldstr      "TH"
    IL_0ac1:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0ac6:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0acb:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0ad0:  dup
    IL_0ad1:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_0ad6:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0adb:  dup
    IL_0adc:  ldstr      "Pressure & vapor fraction"
    IL_0ae1:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0ae6:  dup
    IL_0ae7:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Pressure___vapor_fraction"
    IL_0aec:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_0af1:  dup
    IL_0af2:  ldstr      "cboKode_MultiMapOption_4"
    IL_0af7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_0afc:  dup
    IL_0afd:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0b02:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0b07:  dup
    IL_0b08:  ldstr      "cboKode_kode"
    IL_0b0d:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0b12:  dup
    IL_0b13:  ldstr      "PV"
    IL_0b18:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0b1d:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0b22:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0b27:  dup
    IL_0b28:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_0b2d:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0b32:  dup
    IL_0b33:  ldstr      "Pressure & enthalpy"
    IL_0b38:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0b3d:  dup
    IL_0b3e:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Pressure___enthalpy"
    IL_0b43:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_0b48:  dup
    IL_0b49:  ldstr      "cboKode_MultiMapOption_5"
    IL_0b4e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_0b53:  dup
    IL_0b54:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0b59:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0b5e:  dup
    IL_0b5f:  ldstr      "cboKode_kode"
    IL_0b64:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0b69:  dup
    IL_0b6a:  ldstr      "PH"
    IL_0b6f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0b74:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0b79:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0b7e:  dup
    IL_0b7f:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_0b84:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0b89:  dup
    IL_0b8a:  ldstr      "Do not flash stream"
    IL_0b8f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0b94:  dup
    IL_0b95:  ldstr      "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOpt"
    + "ion_Display_Do_not_flash_stream"
    IL_0b9a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_DisplayResourceKey(string)
    IL_0b9f:  dup
    IL_0ba0:  ldstr      "cboKode_MultiMapOption_6"
    IL_0ba5:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_0baa:  dup
    IL_0bab:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0bb0:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0bb5:  dup
    IL_0bb6:  ldstr      "cboKode_kode"
    IL_0bbb:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0bc0:  dup
    IL_0bc1:  ldstr      "NOFLASH"
    IL_0bc6:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0bcb:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0bd0:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0bd5:  dup
    IL_0bd6:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
    IL_0bdb:  dup
    IL_0bdc:  ldstr      "choice"
    IL_0be1:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_Parameter(string)
    IL_0be6:  dup
    IL_0be7:  ldc.i4.s   11
    IL_0be9:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_Operator(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalOperator)
    IL_0bee:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
    IL_0bf3:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0bf8:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::cboKode_MultiMap_Property
    IL_0bfd:  ret
  } // end of method MMACMModel_Blocko_SFlash_ViewModel::.cctor

  .property instance callconv(8) object MMFrame3_state()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMFrame3_state()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMFrame3_state
  .property instance callconv(8) object MMLBUText9_tol()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText9_tol()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMLBUText9_tol
  .property instance callconv(8) object MMSpinBox1_maxit()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMSpinBox1_maxit()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMSpinBox1_maxit
  .property instance callconv(8) object frmEst_state()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_frmEst_state()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::frmEst_state
  .property instance callconv(8) object MMLBUText8_pest()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText8_pest()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMLBUText8_pest
  .property instance callconv(8) object MMLBUText7_test()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText7_test()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMLBUText7_test
  .property instance callconv(8) object frmFlSpec_state()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_frmFlSpec_state()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::frmFlSpec_state
  .property instance callconv(8) object MMComboBox2_MultiMap()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMComboBox2_MultiMap()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMComboBox2_MultiMap
  .property instance callconv(8) object MMLBUText6_vfrac()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText6_vfrac()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMLBUText6_vfrac
  .property instance callconv(8) object MMLBUText5_pres()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText5_pres()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMLBUText5_pres
  .property instance callconv(8) object MMLBUText4_temp()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMLBUText4_temp()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMLBUText4_temp
  .property instance callconv(8) object MMMenuButton1_target()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMMenuButton1_target()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMMenuButton1_target
  .property instance callconv(8) object MMMenuButton1_flashstream()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_MMMenuButton1_flashstream()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::MMMenuButton1_flashstream
  .property instance callconv(8) object cboKode_MultiMap()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel::get_cboKode_MultiMap()
  } // end of property MMACMModel_Blocko_SFlash_ViewModel::cboKode_MultiMap
} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 23 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..#MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 42 6C 6F 63 6B 6F 5F   // ACMModel_Blocko_
                                                                                                    53 46 6C 61 73 68 00 00 )                         // SFlash..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMMenuButton1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit MMMenuButton1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel cboKode_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit cboKode
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmFlSpec
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText4_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText4
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText5_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText5
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText6_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText6
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLabel1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboBox2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmEst
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText7_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText7
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText8_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText8
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox MMFrame3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText9_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText9
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_Blocko_SFlash::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_blocko_sflash.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_Blocko_SFlash::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       412 (0x19c)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_0069,
                          IL_0076,
                          IL_0083,
                          IL_0090,
                          IL_009d,
                          IL_00aa,
                          IL_00b7,
                          IL_00c4,
                          IL_00d1,
                          IL_00de,
                          IL_00eb,
                          IL_00f8,
                          IL_0105,
                          IL_0112,
                          IL_011f,
                          IL_012c,
                          IL_0139,
                          IL_0146,
                          IL_0153,
                          IL_0160,
                          IL_016d,
                          IL_017a,
                          IL_0187)
    IL_0064:  br         IL_0194

    IL_0069:  ldarg.0
    IL_006a:  ldarg.2
    IL_006b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0070:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMMenuButton1_label
    IL_0075:  ret

    IL_0076:  ldarg.0
    IL_0077:  ldarg.2
    IL_0078:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit
    IL_007d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMMenuButton1
    IL_0082:  ret

    IL_0083:  ldarg.0
    IL_0084:  ldarg.2
    IL_0085:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_008a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::cboKode_label
    IL_008f:  ret

    IL_0090:  ldarg.0
    IL_0091:  ldarg.2
    IL_0092:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_0097:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::cboKode
    IL_009c:  ret

    IL_009d:  ldarg.0
    IL_009e:  ldarg.2
    IL_009f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_00a4:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::frmFlSpec
    IL_00a9:  ret

    IL_00aa:  ldarg.0
    IL_00ab:  ldarg.2
    IL_00ac:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00b1:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText4_label
    IL_00b6:  ret

    IL_00b7:  ldarg.0
    IL_00b8:  ldarg.2
    IL_00b9:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00be:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText4
    IL_00c3:  ret

    IL_00c4:  ldarg.0
    IL_00c5:  ldarg.2
    IL_00c6:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00cb:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText5_label
    IL_00d0:  ret

    IL_00d1:  ldarg.0
    IL_00d2:  ldarg.2
    IL_00d3:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00d8:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText5
    IL_00dd:  ret

    IL_00de:  ldarg.0
    IL_00df:  ldarg.2
    IL_00e0:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00e5:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText6_label
    IL_00ea:  ret

    IL_00eb:  ldarg.0
    IL_00ec:  ldarg.2
    IL_00ed:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00f2:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText6
    IL_00f7:  ret

    IL_00f8:  ldarg.0
    IL_00f9:  ldarg.2
    IL_00fa:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00ff:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLabel1
    IL_0104:  ret

    IL_0105:  ldarg.0
    IL_0106:  ldarg.2
    IL_0107:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_010c:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMComboBox2
    IL_0111:  ret

    IL_0112:  ldarg.0
    IL_0113:  ldarg.2
    IL_0114:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_0119:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::frmEst
    IL_011e:  ret

    IL_011f:  ldarg.0
    IL_0120:  ldarg.2
    IL_0121:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0126:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText7_label
    IL_012b:  ret

    IL_012c:  ldarg.0
    IL_012d:  ldarg.2
    IL_012e:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0133:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText7
    IL_0138:  ret

    IL_0139:  ldarg.0
    IL_013a:  ldarg.2
    IL_013b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0140:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText8_label
    IL_0145:  ret

    IL_0146:  ldarg.0
    IL_0147:  ldarg.2
    IL_0148:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_014d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText8
    IL_0152:  ret

    IL_0153:  ldarg.0
    IL_0154:  ldarg.2
    IL_0155:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_015a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMFrame3
    IL_015f:  ret

    IL_0160:  ldarg.0
    IL_0161:  ldarg.2
    IL_0162:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0167:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMSpinBox1_label
    IL_016c:  ret

    IL_016d:  ldarg.0
    IL_016e:  ldarg.2
    IL_016f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_0174:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMSpinBox1
    IL_0179:  ret

    IL_017a:  ldarg.0
    IL_017b:  ldarg.2
    IL_017c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0181:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText9_label
    IL_0186:  ret

    IL_0187:  ldarg.0
    IL_0188:  ldarg.2
    IL_0189:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_018e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::MMLBUText9
    IL_0193:  ret

    IL_0194:  ldarg.0
    IL_0195:  ldc.i4.1
    IL_0196:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash::_contentLoaded
    IL_019b:  ret
  } // end of method MMACMModel_Blocko_SFlash::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SFlash

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboAEMethod1_AEMETHOD_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMCheckBox4_Inter_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration _MMCheckBox2_user_bypass_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMLBUText1_var1_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMComboReportVarQuery_RESQUERY_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMCheckBox3_flashfeeds_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MMCheckBox1_var1_Property
  .method public hidebysig specialname instance object 
          get_MMComboAEMethod1_AEMETHOD() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMComboAEMethod1_AEMETHOD_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SimOptions_ViewModel::get_MMComboAEMethod1_AEMETHOD

  .method public hidebysig specialname instance object 
          get_MMCheckBox4_Inter() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMCheckBox4_Inter_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SimOptions_ViewModel::get_MMCheckBox4_Inter

  .method public hidebysig specialname instance object 
          get__MMCheckBox2_user_bypass() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::_MMCheckBox2_user_bypass_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SimOptions_ViewModel::get__MMCheckBox2_user_bypass

  .method public hidebysig specialname instance object 
          get_MMLBUText1_var1() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMLBUText1_var1_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SimOptions_ViewModel::get_MMLBUText1_var1

  .method public hidebysig specialname instance object 
          get_MMComboReportVarQuery_RESQUERY() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMComboReportVarQuery_RESQUERY_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SimOptions_ViewModel::get_MMComboReportVarQuery_RESQUERY

  .method public hidebysig specialname instance object 
          get_MMCheckBox3_flashfeeds() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMCheckBox3_flashfeeds_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SimOptions_ViewModel::get_MMCheckBox3_flashfeeds

  .method public hidebysig specialname instance object 
          get_MMCheckBox1_var1() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMCheckBox1_var1_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Blocko_SimOptions_ViewModel::get_MMCheckBox1_var1

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMACMModel_Blocko_SimOptions_ViewModel::.ctor

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       450 (0x1c2)
    .maxstack  5
    IL_0000:  ldstr      "MMComboAEMethod1_AEMETHOD"
    IL_0005:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel
    IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_000f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0014:  dup
    IL_0015:  ldc.i4.2
    IL_0016:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
    IL_001b:  dup
    IL_001c:  ldstr      "@main.Input.AE_METHOD"
    IL_0021:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0026:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_002b:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMComboAEMethod1_AEMETHOD_Property
    IL_0030:  ldstr      "MMCheckBox4_Inter"
    IL_0035:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel
    IL_003a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_003f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::.ctor()
    IL_0044:  dup
    IL_0045:  ldstr      "@main.Input.INTER"
    IL_004a:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DataPath(string)
    IL_004f:  dup
    IL_0050:  ldstr      "YES"
    IL_0055:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_TrueValue(object)
    IL_005a:  dup
    IL_005b:  ldstr      "NO"
    IL_0060:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_FalseValue(object)
    IL_0065:  dup
    IL_0066:  ldc.i4.0
    IL_0067:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_006c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DefaultValue(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_0071:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0076:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMCheckBox4_Inter_Property
    IL_007b:  ldstr      "_MMCheckBox2_user_bypass"
    IL_0080:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel
    IL_0085:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_008a:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::.ctor()
    IL_008f:  dup
    IL_0090:  ldstr      "@main.Input.USER_BYPASS"
    IL_0095:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DataPath(string)
    IL_009a:  dup
    IL_009b:  ldstr      "YES"
    IL_00a0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_TrueValue(object)
    IL_00a5:  dup
    IL_00a6:  ldstr      "NO"
    IL_00ab:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_FalseValue(object)
    IL_00b0:  dup
    IL_00b1:  ldc.i4.1
    IL_00b2:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_00b7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DefaultValue(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_00bc:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_00c1:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::_MMCheckBox2_user_bypass_Property
    IL_00c6:  ldstr      "MMLBUText1_var1"
    IL_00cb:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel
    IL_00d0:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_00d5:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_00da:  dup
    IL_00db:  ldstr      "@main.Input.MODEL"
    IL_00e0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_00e5:  dup
    IL_00e6:  ldc.i4.0
    IL_00e7:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_00ec:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_IsCalculated(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_00f1:  dup
    IL_00f2:  ldc.i4.1
    IL_00f3:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_00f8:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_IsReadOnly(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_00fd:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0102:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMLBUText1_var1_Property
    IL_0107:  ldstr      "MMComboReportVarQuery_RESQUERY"
    IL_010c:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel
    IL_0111:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0116:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_011b:  dup
    IL_011c:  ldc.i4.2
    IL_011d:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_ExposeAs(valuetype [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableTypeCode)
    IL_0122:  dup
    IL_0123:  ldstr      "@main.Input.RES_QUERY_ID"
    IL_0128:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_012d:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0132:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMComboReportVarQuery_RESQUERY_Property
    IL_0137:  ldstr      "MMCheckBox3_flashfeeds"
    IL_013c:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel
    IL_0141:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0146:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::.ctor()
    IL_014b:  dup
    IL_014c:  ldstr      "@main.Input.FLASH_FEEDS"
    IL_0151:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DataPath(string)
    IL_0156:  dup
    IL_0157:  ldstr      "YES"
    IL_015c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_TrueValue(object)
    IL_0161:  dup
    IL_0162:  ldstr      "NO"
    IL_0167:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_FalseValue(object)
    IL_016c:  dup
    IL_016d:  ldc.i4.0
    IL_016e:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_0173:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DefaultValue(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_0178:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_017d:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMCheckBox3_flashfeeds_Property
    IL_0182:  ldstr      "MMCheckBox1_var1"
    IL_0187:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel
    IL_018c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0191:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::.ctor()
    IL_0196:  dup
    IL_0197:  ldstr      "@main.Input.ENERGY_BAL"
    IL_019c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DataPath(string)
    IL_01a1:  dup
    IL_01a2:  ldstr      "YES"
    IL_01a7:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_TrueValue(object)
    IL_01ac:  dup
    IL_01ad:  ldstr      "NO"
    IL_01b2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_FalseValue(object)
    IL_01b7:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_01bc:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::MMCheckBox1_var1_Property
    IL_01c1:  ret
  } // end of method MMACMModel_Blocko_SimOptions_ViewModel::.cctor

  .property instance callconv(8) object MMComboAEMethod1_AEMETHOD()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::get_MMComboAEMethod1_AEMETHOD()
  } // end of property MMACMModel_Blocko_SimOptions_ViewModel::MMComboAEMethod1_AEMETHOD
  .property instance callconv(8) object MMCheckBox4_Inter()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::get_MMCheckBox4_Inter()
  } // end of property MMACMModel_Blocko_SimOptions_ViewModel::MMCheckBox4_Inter
  .property instance callconv(8) object _MMCheckBox2_user_bypass()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::get__MMCheckBox2_user_bypass()
  } // end of property MMACMModel_Blocko_SimOptions_ViewModel::_MMCheckBox2_user_bypass
  .property instance callconv(8) object MMLBUText1_var1()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::get_MMLBUText1_var1()
  } // end of property MMACMModel_Blocko_SimOptions_ViewModel::MMLBUText1_var1
  .property instance callconv(8) object MMComboReportVarQuery_RESQUERY()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::get_MMComboReportVarQuery_RESQUERY()
  } // end of property MMACMModel_Blocko_SimOptions_ViewModel::MMComboReportVarQuery_RESQUERY
  .property instance callconv(8) object MMCheckBox3_flashfeeds()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::get_MMCheckBox3_flashfeeds()
  } // end of property MMACMModel_Blocko_SimOptions_ViewModel::MMCheckBox3_flashfeeds
  .property instance callconv(8) object MMCheckBox1_var1()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel::get_MMCheckBox1_var1()
  } // end of property MMACMModel_Blocko_SimOptions_ViewModel::MMCheckBox1_var1
} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 27 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..'MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 42 6C 6F 63 6B 6F 5F   // ACMModel_Blocko_
                                                                                                    53 69 6D 4F 70 74 69 6F 6E 73 00 00 )             // SimOptions..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox MMFrame1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox MMCheckBox3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox MMCheckBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox MMCheckBox2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox MMCheckBox4
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboAEMethod1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboAEMethod1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboReportVarQuery_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboReportVarQuery
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText1
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_Blocko_SimOptions::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_blocko_simoptions.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_Blocko_SimOptions::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       208 (0xd0)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_0039,
                          IL_0046,
                          IL_0053,
                          IL_0060,
                          IL_006d,
                          IL_007a,
                          IL_0087,
                          IL_0094,
                          IL_00a1,
                          IL_00ae,
                          IL_00bb)
    IL_0034:  br         IL_00c8

    IL_0039:  ldarg.0
    IL_003a:  ldarg.2
    IL_003b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_0040:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMFrame1
    IL_0045:  ret

    IL_0046:  ldarg.0
    IL_0047:  ldarg.2
    IL_0048:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox
    IL_004d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMCheckBox3
    IL_0052:  ret

    IL_0053:  ldarg.0
    IL_0054:  ldarg.2
    IL_0055:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox
    IL_005a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMCheckBox1
    IL_005f:  ret

    IL_0060:  ldarg.0
    IL_0061:  ldarg.2
    IL_0062:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox
    IL_0067:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMCheckBox2
    IL_006c:  ret

    IL_006d:  ldarg.0
    IL_006e:  ldarg.2
    IL_006f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox
    IL_0074:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMCheckBox4
    IL_0079:  ret

    IL_007a:  ldarg.0
    IL_007b:  ldarg.2
    IL_007c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0081:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMComboAEMethod1_label
    IL_0086:  ret

    IL_0087:  ldarg.0
    IL_0088:  ldarg.2
    IL_0089:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_008e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMComboAEMethod1
    IL_0093:  ret

    IL_0094:  ldarg.0
    IL_0095:  ldarg.2
    IL_0096:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_009b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMComboReportVarQuery_label
    IL_00a0:  ret

    IL_00a1:  ldarg.0
    IL_00a2:  ldarg.2
    IL_00a3:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_00a8:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMComboReportVarQuery
    IL_00ad:  ret

    IL_00ae:  ldarg.0
    IL_00af:  ldarg.2
    IL_00b0:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00b5:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMLBUText1_label
    IL_00ba:  ret

    IL_00bb:  ldarg.0
    IL_00bc:  ldarg.2
    IL_00bd:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00c2:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::MMLBUText1
    IL_00c7:  ret

    IL_00c8:  ldarg.0
    IL_00c9:  ldc.i4.1
    IL_00ca:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions::_contentLoaded
    IL_00cf:  ret
  } // end of method MMACMModel_Blocko_SimOptions::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Blocko_SimOptions

.class private auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.DyanmicAxHost
       extends [System.Windows.Forms]System.Windows.Forms.AxHost
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string 'clsid') cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance void [System.Windows.Forms]System.Windows.Forms.AxHost::.ctor(string)
    IL_0007:  ret
  } // end of method DyanmicAxHost::.ctor

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.DyanmicAxHost

.class private auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .field private class [System.Windows.Forms]System.Windows.Forms.Control customWinForm
  .field private class [PresentationFramework]System.Windows.FrameworkElement customWPFForm
  .field private class [System.Windows.Forms]System.Windows.Forms.AxHost ocxHost
  .field private object ocxObject
  .field private class [mscorlib]System.Type controlType
  .field private object _mvarControlContext
  .method family hidebysig virtual instance void 
          OnViewChanged() cil managed
  {
    // Code size       686 (0x2ae)
    .maxstack  4
    .locals init (string V_0,
             string V_1,
             bool V_2,
             string V_3,
             string V_4,
             class [mscorlib]System.Reflection.Assembly V_5,
             string V_6,
             string V_7,
             object V_8,
             object V_9,
             string V_10)
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "Progid"
    IL_0006:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveParameter(string)
    IL_000b:  isinst     [mscorlib]System.String
    IL_0010:  stloc.0
    IL_0011:  ldarg.0
    IL_0012:  ldstr      "Clsid"
    IL_0017:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveParameter(string)
    IL_001c:  isinst     [mscorlib]System.String
    IL_0021:  stloc.1
    IL_0022:  ldc.i4.0
    IL_0023:  stloc.2
    IL_0024:  ldloc.1
    IL_0025:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_002a:  brtrue     IL_0211

    IL_002f:  ldstr      "HKEY_CLASSES_ROOT\\CLSID\\"
    IL_0034:  ldloc.1
    IL_0035:  ldstr      "\\InprocServer32"
    IL_003a:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_003f:  stloc.3
    IL_0040:  ldloc.3
    IL_0041:  ldstr      ""
    IL_0046:  ldnull
    IL_0047:  call       object [mscorlib]Microsoft.Win32.Registry::GetValue(string,
                                                                             string,
                                                                             object)
    IL_004c:  isinst     [mscorlib]System.String
    IL_0051:  brfalse    IL_0211

    IL_0056:  ldloc.3
    IL_0057:  ldstr      "Assembly"
    IL_005c:  ldnull
    IL_005d:  call       object [mscorlib]Microsoft.Win32.Registry::GetValue(string,
                                                                             string,
                                                                             object)
    IL_0062:  isinst     [mscorlib]System.String
    IL_0067:  stloc.s    V_4
    IL_0069:  ldloc.s    V_4
    IL_006b:  brfalse    IL_01ba

    IL_0070:  ldnull
    IL_0071:  stloc.s    V_5
    IL_0073:  ldc.i4.1
    IL_0074:  stloc.2
    IL_0075:  ldloc.3
    IL_0076:  ldstr      "CodeBase"
    IL_007b:  ldnull
    IL_007c:  call       object [mscorlib]Microsoft.Win32.Registry::GetValue(string,
                                                                             string,
                                                                             object)
    IL_0081:  isinst     [mscorlib]System.String
    IL_0086:  stloc.s    V_6
    IL_0088:  ldloc.3
    IL_0089:  ldstr      "Class"
    IL_008e:  ldnull
    IL_008f:  call       object [mscorlib]Microsoft.Win32.Registry::GetValue(string,
                                                                             string,
                                                                             object)
    IL_0094:  isinst     [mscorlib]System.String
    IL_0099:  stloc.s    V_7
    .try
    {
      IL_009b:  ldloc.s    V_6
      IL_009d:  brfalse.s  IL_00c2

      IL_009f:  ldloc.s    V_6
      IL_00a1:  ldstr      "file:"
      IL_00a6:  callvirt   instance bool [mscorlib]System.String::StartsWith(string)
      IL_00ab:  brfalse.s  IL_00b7

      IL_00ad:  ldloc.s    V_6
      IL_00af:  ldc.i4.5
      IL_00b0:  callvirt   instance string [mscorlib]System.String::Substring(int32)
      IL_00b5:  stloc.s    V_6
      IL_00b7:  ldloc.s    V_6
      IL_00b9:  call       class [mscorlib]System.Reflection.Assembly [mscorlib]System.Reflection.Assembly::LoadFrom(string)
      IL_00be:  stloc.s    V_5
      IL_00c0:  br.s       IL_00cb

      IL_00c2:  ldloc.s    V_4
      IL_00c4:  call       class [mscorlib]System.Reflection.Assembly [mscorlib]System.Reflection.Assembly::Load(string)
      IL_00c9:  stloc.s    V_5
      IL_00cb:  leave.s    IL_00d0

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_00cd:  pop
      IL_00ce:  leave.s    IL_00d0

    }  // end handler
    IL_00d0:  ldloc.s    V_5
    IL_00d2:  ldnull
    IL_00d3:  call       bool [mscorlib]System.Reflection.Assembly::op_Inequality(class [mscorlib]System.Reflection.Assembly,
                                                                                  class [mscorlib]System.Reflection.Assembly)
    IL_00d8:  brfalse.s  IL_00f5

    IL_00da:  ldarg.0
    IL_00db:  ldloc.s    V_5
    IL_00dd:  ldloc.s    V_7
    IL_00df:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_00e4:  brtrue.s   IL_00ea

    IL_00e6:  ldloc.s    V_7
    IL_00e8:  br.s       IL_00eb

    IL_00ea:  ldloc.0
    IL_00eb:  callvirt   instance class [mscorlib]System.Type [mscorlib]System.Reflection.Assembly::GetType(string)
    IL_00f0:  stfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
    IL_00f5:  ldarg.0
    IL_00f6:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
    IL_00fb:  ldnull
    IL_00fc:  call       bool [mscorlib]System.Type::op_Inequality(class [mscorlib]System.Type,
                                                                   class [mscorlib]System.Type)
    IL_0101:  brfalse.s  IL_0155

    IL_0103:  ldarg.0
    IL_0104:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
    IL_0109:  ldtoken    [PresentationFramework]System.Windows.FrameworkElement
    IL_010e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0113:  callvirt   instance bool [mscorlib]System.Type::IsSubclassOf(class [mscorlib]System.Type)
    IL_0118:  brfalse.s  IL_0155

    .try
    {
      IL_011a:  ldarg.0
      IL_011b:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
      IL_0120:  call       object [mscorlib]System.Activator::CreateInstance(class [mscorlib]System.Type)
      IL_0125:  stloc.s    V_8
      IL_0127:  ldarg.0
      IL_0128:  ldloc.s    V_8
      IL_012a:  isinst     [PresentationFramework]System.Windows.FrameworkElement
      IL_012f:  stfld      class [PresentationFramework]System.Windows.FrameworkElement AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::customWPFForm
      IL_0134:  ldarg.0
      IL_0135:  call       instance object [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::get_View()
      IL_013a:  isinst     [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
      IL_013f:  ldarg.0
      IL_0140:  ldfld      class [PresentationFramework]System.Windows.FrameworkElement AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::customWPFForm
      IL_0145:  callvirt   instance void [PresentationFramework]System.Windows.Controls.ContentControl::set_Content(object)
      IL_014a:  leave      IL_0211

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_014f:  pop
      IL_0150:  leave      IL_0211

    }  // end handler
    IL_0155:  ldarg.0
    IL_0156:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
    IL_015b:  ldnull
    IL_015c:  call       bool [mscorlib]System.Type::op_Inequality(class [mscorlib]System.Type,
                                                                   class [mscorlib]System.Type)
    IL_0161:  brfalse    IL_0211

    IL_0166:  ldarg.0
    IL_0167:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
    IL_016c:  ldtoken    [System.Windows.Forms]System.Windows.Forms.Control
    IL_0171:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0176:  callvirt   instance bool [mscorlib]System.Type::IsSubclassOf(class [mscorlib]System.Type)
    IL_017b:  brfalse    IL_0211

    .try
    {
      IL_0180:  ldarg.0
      IL_0181:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
      IL_0186:  call       object [mscorlib]System.Activator::CreateInstance(class [mscorlib]System.Type)
      IL_018b:  stloc.s    V_9
      IL_018d:  ldarg.0
      IL_018e:  ldloc.s    V_9
      IL_0190:  isinst     [System.Windows.Forms]System.Windows.Forms.Control
      IL_0195:  stfld      class [System.Windows.Forms]System.Windows.Forms.Control AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::customWinForm
      IL_019a:  ldarg.0
      IL_019b:  call       instance object [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::get_View()
      IL_01a0:  isinst     AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom
      IL_01a5:  ldfld      class [WindowsFormsIntegration]System.Windows.Forms.Integration.WindowsFormsHost AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom::formHost
      IL_01aa:  ldarg.0
      IL_01ab:  ldfld      class [System.Windows.Forms]System.Windows.Forms.Control AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::customWinForm
      IL_01b0:  callvirt   instance void [WindowsFormsIntegration]System.Windows.Forms.Integration.WindowsFormsHost::set_Child(class [System.Windows.Forms]System.Windows.Forms.Control)
      IL_01b5:  leave.s    IL_0211

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_01b7:  pop
      IL_01b8:  leave.s    IL_0211

    }  // end handler
    IL_01ba:  ldc.i4.1
    IL_01bb:  stloc.2
    .try
    {
      IL_01bc:  ldarg.0
      IL_01bd:  ldloc.0
      IL_01be:  ldc.i4.1
      IL_01bf:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromProgID(string,
                                                                                                bool)
      IL_01c4:  stfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
      IL_01c9:  ldarg.0
      IL_01ca:  ldloc.1
      IL_01cb:  newobj     instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.DyanmicAxHost::.ctor(string)
      IL_01d0:  stfld      class [System.Windows.Forms]System.Windows.Forms.AxHost AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::ocxHost
      IL_01d5:  ldarg.0
      IL_01d6:  call       instance object [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::get_View()
      IL_01db:  isinst     AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom
      IL_01e0:  ldfld      class [WindowsFormsIntegration]System.Windows.Forms.Integration.WindowsFormsHost AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom::formHost
      IL_01e5:  ldarg.0
      IL_01e6:  ldfld      class [System.Windows.Forms]System.Windows.Forms.AxHost AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::ocxHost
      IL_01eb:  callvirt   instance void [WindowsFormsIntegration]System.Windows.Forms.Integration.WindowsFormsHost::set_Child(class [System.Windows.Forms]System.Windows.Forms.Control)
      IL_01f0:  ldarg.0
      IL_01f1:  ldfld      class [System.Windows.Forms]System.Windows.Forms.AxHost AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::ocxHost
      IL_01f6:  callvirt   instance void [System.Windows.Forms]System.Windows.Forms.Control::CreateControl()
      IL_01fb:  ldarg.0
      IL_01fc:  ldarg.0
      IL_01fd:  ldfld      class [System.Windows.Forms]System.Windows.Forms.AxHost AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::ocxHost
      IL_0202:  callvirt   instance object [System.Windows.Forms]System.Windows.Forms.AxHost::GetOcx()
      IL_0207:  stfld      object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::ocxObject
      IL_020c:  leave.s    IL_0211

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_020e:  pop
      IL_020f:  leave.s    IL_0211

    }  // end handler
    IL_0211:  ldloc.2
    IL_0212:  pop
    IL_0213:  ldarg.0
    IL_0214:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
    IL_0219:  ldnull
    IL_021a:  call       bool [mscorlib]System.Type::op_Equality(class [mscorlib]System.Type,
                                                                 class [mscorlib]System.Type)
    IL_021f:  brfalse.s  IL_0275

    IL_0221:  ldstr      ""
    IL_0226:  stloc.s    V_10
    IL_0228:  ldloc.2
    IL_0229:  brfalse.s  IL_0234

    IL_022b:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.Properties.Resources::get_MMACMModel_Custom_LoadError()
    IL_0230:  stloc.s    V_10
    IL_0232:  br.s       IL_023b

    IL_0234:  call       string [AspenTech.AspenPlus.Localization]AspenTech.AspenPlus.Localization.Properties.Resources::get_MMACMModel_Custom_FindError()
    IL_0239:  stloc.s    V_10
    IL_023b:  ldarg.0
    IL_023c:  call       instance object [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::get_View()
    IL_0241:  isinst     [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
    IL_0246:  ldloc.s    V_10
    IL_0248:  ldloc.0
    IL_0249:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_024e:  callvirt   instance void [PresentationFramework]System.Windows.Controls.ContentControl::set_Content(object)
    IL_0253:  ldarg.0
    IL_0254:  call       instance object [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::get_View()
    IL_0259:  isinst     [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
    IL_025e:  dup
    IL_025f:  callvirt   instance float64 [PresentationFramework]System.Windows.Controls.Control::get_FontSize()
    IL_0264:  ldc.r8     2
    IL_026d:  add
    IL_026e:  callvirt   instance void [PresentationFramework]System.Windows.Controls.Control::set_FontSize(float64)
    IL_0273:  br.s       IL_02a7

    IL_0275:  ldarg.0
    IL_0276:  ldarg.0
    IL_0277:  ldstr      "@main.Data"
    IL_027c:  ldstr      "value"
    IL_0281:  call       instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ExpandDataPathAndGet(string,
                                                                                                                                             string)
    IL_0286:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::set_ControlContext(object)
    IL_028b:  ldarg.0
    IL_028c:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0291:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_0296:  ldarg.0
    IL_0297:  ldftn      instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::Case_Message(object,
                                                                                                                             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsMessageEventArgs)
    IL_029d:  newobj     instance void class [mscorlib]System.EventHandler`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsMessageEventArgs>::.ctor(object,
                                                                                                                                                      native int)
    IL_02a2:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::add_Message(class [mscorlib]System.EventHandler`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsMessageEventArgs>)
    IL_02a7:  ldarg.0
    IL_02a8:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModel::OnViewChanged()
    IL_02ad:  ret
  } // end of method MMACMModel_Custom_ViewModel::OnViewChanged

  .method private hidebysig instance void 
          Case_Message(object sender,
                       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsMessageEventArgs e) cil managed
  {
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method MMACMModel_Custom_ViewModel::Case_Message

  .method public hidebysig virtual instance void 
          Unload() cil managed
  {
    // Code size       42 (0x2a)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::get_ResolvedCxsProvider()
    IL_0006:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::get_Case()
    IL_000b:  ldarg.0
    IL_000c:  ldftn      instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::Case_Message(object,
                                                                                                                             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsMessageEventArgs)
    IL_0012:  newobj     instance void class [mscorlib]System.EventHandler`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsMessageEventArgs>::.ctor(object,
                                                                                                                                                      native int)
    IL_0017:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::remove_Message(class [mscorlib]System.EventHandler`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsMessageEventArgs>)
    IL_001c:  ldarg.0
    IL_001d:  ldnull
    IL_001e:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::set_ControlContext(object)
    IL_0023:  ldarg.0
    IL_0024:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::Unload()
    IL_0029:  ret
  } // end of method MMACMModel_Custom_ViewModel::Unload

  .method public hidebysig specialname instance object 
          get_ControlContext() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::_mvarControlContext
    IL_0006:  ret
  } // end of method MMACMModel_Custom_ViewModel::get_ControlContext

  .method public hidebysig specialname instance void 
          set_ControlContext(object 'value') cil managed
  {
    // Code size       202 (0xca)
    .maxstack  9
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::_mvarControlContext
    IL_0006:  ldarg.1
    IL_0007:  beq        IL_00c9

    IL_000c:  ldarg.0
    IL_000d:  ldarg.1
    IL_000e:  stfld      object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::_mvarControlContext
    IL_0013:  ldarg.0
    IL_0014:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
    IL_0019:  ldnull
    IL_001a:  call       bool [mscorlib]System.Type::op_Inequality(class [mscorlib]System.Type,
                                                                   class [mscorlib]System.Type)
    IL_001f:  brfalse    IL_00c9

    .try
    {
      IL_0024:  ldarg.0
      IL_0025:  ldfld      class [System.Windows.Forms]System.Windows.Forms.Control AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::customWinForm
      IL_002a:  brfalse.s  IL_005a

      IL_002c:  ldarg.0
      IL_002d:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
      IL_0032:  ldstr      "ControlContext"
      IL_0037:  ldc.i4     0x2000
      IL_003c:  ldnull
      IL_003d:  ldarg.0
      IL_003e:  ldfld      class [System.Windows.Forms]System.Windows.Forms.Control AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::customWinForm
      IL_0043:  ldc.i4.1
      IL_0044:  newarr     [mscorlib]System.Object
      IL_0049:  dup
      IL_004a:  ldc.i4.0
      IL_004b:  ldarg.0
      IL_004c:  ldfld      object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::_mvarControlContext
      IL_0051:  stelem.ref
      IL_0052:  callvirt   instance object [mscorlib]System.Type::InvokeMember(string,
                                                                               valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                               class [mscorlib]System.Reflection.Binder,
                                                                               object,
                                                                               object[])
      IL_0057:  pop
      IL_0058:  br.s       IL_00c4

      IL_005a:  ldarg.0
      IL_005b:  ldfld      class [PresentationFramework]System.Windows.FrameworkElement AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::customWPFForm
      IL_0060:  brfalse.s  IL_0090

      IL_0062:  ldarg.0
      IL_0063:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
      IL_0068:  ldstr      "ControlContext"
      IL_006d:  ldc.i4     0x2000
      IL_0072:  ldnull
      IL_0073:  ldarg.0
      IL_0074:  ldfld      class [PresentationFramework]System.Windows.FrameworkElement AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::customWPFForm
      IL_0079:  ldc.i4.1
      IL_007a:  newarr     [mscorlib]System.Object
      IL_007f:  dup
      IL_0080:  ldc.i4.0
      IL_0081:  ldarg.0
      IL_0082:  ldfld      object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::_mvarControlContext
      IL_0087:  stelem.ref
      IL_0088:  callvirt   instance object [mscorlib]System.Type::InvokeMember(string,
                                                                               valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                               class [mscorlib]System.Reflection.Binder,
                                                                               object,
                                                                               object[])
      IL_008d:  pop
      IL_008e:  br.s       IL_00c4

      IL_0090:  ldarg.0
      IL_0091:  ldfld      object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::ocxObject
      IL_0096:  brfalse.s  IL_00c4

      IL_0098:  ldarg.0
      IL_0099:  ldfld      class [mscorlib]System.Type AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::controlType
      IL_009e:  ldstr      "ControlContext"
      IL_00a3:  ldc.i4     0x2000
      IL_00a8:  ldnull
      IL_00a9:  ldarg.0
      IL_00aa:  ldfld      object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::ocxObject
      IL_00af:  ldc.i4.1
      IL_00b0:  newarr     [mscorlib]System.Object
      IL_00b5:  dup
      IL_00b6:  ldc.i4.0
      IL_00b7:  ldarg.0
      IL_00b8:  ldfld      object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::_mvarControlContext
      IL_00bd:  stelem.ref
      IL_00be:  callvirt   instance object [mscorlib]System.Type::InvokeMember(string,
                                                                               valuetype [mscorlib]System.Reflection.BindingFlags,
                                                                               class [mscorlib]System.Reflection.Binder,
                                                                               object,
                                                                               object[])
      IL_00c3:  pop
      IL_00c4:  leave.s    IL_00c9

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_00c6:  pop
      IL_00c7:  leave.s    IL_00c9

    }  // end handler
    IL_00c9:  ret
  } // end of method MMACMModel_Custom_ViewModel::set_ControlContext

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMACMModel_Custom_ViewModel::.ctor

  .property instance callconv(8) object ControlContext()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::get_ControlContext()
    .set instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel::set_ControlContext(object)
  } // end of property MMACMModel_Custom_ViewModel::ControlContext
} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 1C 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ...MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 43 75 73 74 6F 6D 00   // ACMModel_Custom.
                                                                                                    00 ) 
  .field assembly class [WindowsFormsIntegration]System.Windows.Forms.Integration.WindowsFormsHost formHost
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_Custom::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_custom.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_Custom::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       25 (0x19)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  bne.un.s   IL_0011

    IL_0004:  ldarg.0
    IL_0005:  ldarg.2
    IL_0006:  castclass  [WindowsFormsIntegration]System.Windows.Forms.Integration.WindowsFormsHost
    IL_000b:  stfld      class [WindowsFormsIntegration]System.Windows.Forms.Integration.WindowsFormsHost AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom::formHost
    IL_0010:  ret

    IL_0011:  ldarg.0
    IL_0012:  ldc.i4.1
    IL_0013:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom::_contentLoaded
    IL_0018:  ret
  } // end of method MMACMModel_Custom::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Custom

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel
{
  .field private class [System]System.Windows.Input.ICommand _CmdReset_Command
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration SparseSolverMethod_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration ConvergenceCriterion_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration DivSteps_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration StepReductions_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MaxIterations_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MaxFastNewtonSteps_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration CreepIterations_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration CreepSize_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration DoglegMethod_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration BestPoint_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MaxRange_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration MaxApproach_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AbsolutePerturbation_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration SingularityPerturbation_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration VariableStep_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration ClipFactor_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration HighestVariableSteps_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration HighestResiduals_Property
  .field public static initonly class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration PrintLinearAlgebra_Property
  .method public hidebysig specialname instance class [System]System.Windows.Input.ICommand 
          get_CmdReset_Command() cil managed
  {
    // Code size       38 (0x26)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::_CmdReset_Command
    IL_0006:  brtrue.s   IL_001f

    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::CmdReset_CommandExecute(object)
    IL_0010:  newobj     instance void class [mscorlib]System.Action`1<object>::.ctor(object,
                                                                                      native int)
    IL_0015:  newobj     instance void class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvDelegateCommand`1<object>::.ctor(class [mscorlib]System.Action`1<!0>)
    IL_001a:  stfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::_CmdReset_Command
    IL_001f:  ldarg.0
    IL_0020:  ldfld      class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::_CmdReset_Command
    IL_0025:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_CmdReset_Command

  .method private hidebysig instance void 
          CmdReset_CommandExecute(object parameter) cil managed
  {
    // Code size       229 (0xe5)
    .maxstack  3
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "AbsolutePerturbation.Value"
    IL_0006:  ldnull
    IL_0007:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_000c:  ldarg.0
    IL_000d:  ldstr      "BestPoint.Value"
    IL_0012:  ldnull
    IL_0013:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_0018:  ldarg.0
    IL_0019:  ldstr      "ClipFactor.Value"
    IL_001e:  ldnull
    IL_001f:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_0024:  ldarg.0
    IL_0025:  ldstr      "ConvergenceCriterion.Value"
    IL_002a:  ldnull
    IL_002b:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_0030:  ldarg.0
    IL_0031:  ldstr      "CreepIterations.Value"
    IL_0036:  ldnull
    IL_0037:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_003c:  ldarg.0
    IL_003d:  ldstr      "CreepSize.Value"
    IL_0042:  ldnull
    IL_0043:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_0048:  ldarg.0
    IL_0049:  ldstr      "DivergenceSteps.Value"
    IL_004e:  ldnull
    IL_004f:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_0054:  ldarg.0
    IL_0055:  ldstr      "DoglegMethod.Value"
    IL_005a:  ldnull
    IL_005b:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_0060:  ldarg.0
    IL_0061:  ldstr      "HighestResiduals.Value"
    IL_0066:  ldnull
    IL_0067:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_006c:  ldarg.0
    IL_006d:  ldstr      "HighestVariableSteps.Value"
    IL_0072:  ldnull
    IL_0073:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_0078:  ldarg.0
    IL_0079:  ldstr      "MaxApproach.Value"
    IL_007e:  ldnull
    IL_007f:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_0084:  ldarg.0
    IL_0085:  ldstr      "MaxFastNewtonSteps.Value"
    IL_008a:  ldnull
    IL_008b:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_0090:  ldarg.0
    IL_0091:  ldstr      "MaxIterations.Value"
    IL_0096:  ldnull
    IL_0097:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_009c:  ldarg.0
    IL_009d:  ldstr      "MaxRange.Value"
    IL_00a2:  ldnull
    IL_00a3:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_00a8:  ldarg.0
    IL_00a9:  ldstr      "PrintLinearAlgebra.Value"
    IL_00ae:  ldnull
    IL_00af:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_00b4:  ldarg.0
    IL_00b5:  ldstr      "SingularityPerturbation.Value"
    IL_00ba:  ldnull
    IL_00bb:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_00c0:  ldarg.0
    IL_00c1:  ldstr      "SparseSolverMethod.Value"
    IL_00c6:  ldnull
    IL_00c7:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_00cc:  ldarg.0
    IL_00cd:  ldstr      "StepReductions.Value"
    IL_00d2:  ldnull
    IL_00d3:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_00d8:  ldarg.0
    IL_00d9:  ldstr      "VariableStep.Value"
    IL_00de:  ldnull
    IL_00df:  call       instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::ResolveUpdateViewPropertyPath(string,
                                                                                                                                                    object)
    IL_00e4:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::CmdReset_CommandExecute

  .method public hidebysig specialname instance object 
          get_SparseSolverMethod() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::SparseSolverMethod_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_SparseSolverMethod

  .method public hidebysig specialname instance object 
          get_ConvergenceCriterion() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::ConvergenceCriterion_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_ConvergenceCriterion

  .method public hidebysig specialname instance object 
          get_DivergenceSteps() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::DivSteps_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_DivergenceSteps

  .method public hidebysig specialname instance object 
          get_StepReductions() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::StepReductions_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_StepReductions

  .method public hidebysig specialname instance object 
          get_MaxIterations() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::MaxIterations_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_MaxIterations

  .method public hidebysig specialname instance object 
          get_MaxFastNewtonSteps() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::MaxFastNewtonSteps_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_MaxFastNewtonSteps

  .method public hidebysig specialname instance object 
          get_CreepIterations() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::CreepIterations_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_CreepIterations

  .method public hidebysig specialname instance object 
          get_CreepSize() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::CreepSize_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_CreepSize

  .method public hidebysig specialname instance object 
          get_DoglegMethod() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::DoglegMethod_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_DoglegMethod

  .method public hidebysig specialname instance object 
          get_BestPoint() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::BestPoint_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_BestPoint

  .method public hidebysig specialname instance object 
          get_MaxRange() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::MaxRange_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_MaxRange

  .method public hidebysig specialname instance object 
          get_MaxApproach() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::MaxApproach_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_MaxApproach

  .method public hidebysig specialname instance object 
          get_AbsolutePerturbation() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::AbsolutePerturbation_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_AbsolutePerturbation

  .method public hidebysig specialname instance object 
          get_SingularityPerturbation() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::SingularityPerturbation_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_SingularityPerturbation

  .method public hidebysig specialname instance object 
          get_VariableStep() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::VariableStep_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_VariableStep

  .method public hidebysig specialname instance object 
          get_ClipFactor() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::ClipFactor_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_ClipFactor

  .method public hidebysig specialname instance object 
          get_HighestVariableSteps() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::HighestVariableSteps_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_HighestVariableSteps

  .method public hidebysig specialname instance object 
          get_HighestResiduals() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::HighestResiduals_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_HighestResiduals

  .method public hidebysig specialname instance object 
          get_PrintLinearAlgebra() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::PrintLinearAlgebra_Property
    IL_0006:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvViewModel::GetValue(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration)
    IL_000b:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::get_PrintLinearAlgebra

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPageViewModel::.ctor()
    IL_0006:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::.ctor

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       1456 (0x5b0)
    .maxstack  9
    IL_0000:  ldstr      "SparseSolverMethod"
    IL_0005:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_000a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_000f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::.ctor()
    IL_0014:  dup
    IL_0015:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariableCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Variables()
    IL_001a:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::.ctor()
    IL_001f:  dup
    IL_0020:  ldstr      "SparseSolverMethod"
    IL_0025:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_Name(string)
    IL_002a:  dup
    IL_002b:  ldstr      "@main.Input.SPRSMETHOD"
    IL_0030:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_DataPath(string)
    IL_0035:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable>::Add(!0)
    IL_003a:  dup
    IL_003b:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_0040:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0045:  dup
    IL_0046:  ldstr      "Hybrid"
    IL_004b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0050:  dup
    IL_0051:  ldstr      "SparseSolverMethodOption_1"
    IL_0056:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_005b:  dup
    IL_005c:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0061:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0066:  dup
    IL_0067:  ldstr      "SparseSolverMethod"
    IL_006c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0071:  dup
    IL_0072:  ldstr      "HYBRID"
    IL_0077:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_007c:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0081:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0086:  dup
    IL_0087:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_008c:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0091:  dup
    IL_0092:  ldstr      "Newton"
    IL_0097:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_009c:  dup
    IL_009d:  ldstr      "SparseSolverMethodOption_2"
    IL_00a2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_00a7:  dup
    IL_00a8:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_00ad:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_00b2:  dup
    IL_00b3:  ldstr      "SparseSolverMethod"
    IL_00b8:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_00bd:  dup
    IL_00be:  ldstr      "NEWTON"
    IL_00c3:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_00c8:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_00cd:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_00d2:  dup
    IL_00d3:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_00d8:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_00dd:  dup
    IL_00de:  ldstr      "Fast Newton"
    IL_00e3:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_00e8:  dup
    IL_00e9:  ldstr      "SparseSolverMethodOption_3"
    IL_00ee:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_00f3:  dup
    IL_00f4:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_00f9:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_00fe:  dup
    IL_00ff:  ldstr      "SparseSolverMethod"
    IL_0104:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0109:  dup
    IL_010a:  ldstr      "FASTNEWTON"
    IL_010f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0114:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0119:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_011e:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0123:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::SparseSolverMethod_Property
    IL_0128:  ldstr      "ConvergenceCriterion"
    IL_012d:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_0132:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0137:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::.ctor()
    IL_013c:  dup
    IL_013d:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariableCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Variables()
    IL_0142:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::.ctor()
    IL_0147:  dup
    IL_0148:  ldstr      "ConvergenceCriterion"
    IL_014d:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_Name(string)
    IL_0152:  dup
    IL_0153:  ldstr      "@main.Input.SPRSCONVERGE"
    IL_0158:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable::set_DataPath(string)
    IL_015d:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapVariable>::Add(!0)
    IL_0162:  dup
    IL_0163:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_0168:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_016d:  dup
    IL_016e:  ldstr      "Residual"
    IL_0173:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0178:  dup
    IL_0179:  ldstr      "ConvergenceCriterionOption_1"
    IL_017e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_0183:  dup
    IL_0184:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0189:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_018e:  dup
    IL_018f:  ldstr      "ConvergenceCriterion"
    IL_0194:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0199:  dup
    IL_019a:  ldstr      "RESIDUAL"
    IL_019f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_01a4:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_01a9:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_01ae:  dup
    IL_01af:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_01b4:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_01b9:  dup
    IL_01ba:  ldstr      "Variable"
    IL_01bf:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_01c4:  dup
    IL_01c5:  ldstr      "ConvergenceCriterionOption_2"
    IL_01ca:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_01cf:  dup
    IL_01d0:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_01d5:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_01da:  dup
    IL_01db:  ldstr      "ConvergenceCriterion"
    IL_01e0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_01e5:  dup
    IL_01e6:  ldstr      "VARIABLE"
    IL_01eb:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_01f0:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_01f5:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_01fa:  dup
    IL_01fb:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_0200:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0205:  dup
    IL_0206:  ldstr      "Residual and Variable"
    IL_020b:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_0210:  dup
    IL_0211:  ldstr      "ConvergenceCriterionOption_3"
    IL_0216:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_021b:  dup
    IL_021c:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_0221:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0226:  dup
    IL_0227:  ldstr      "ConvergenceCriterion"
    IL_022c:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_0231:  dup
    IL_0232:  ldstr      "RESIDUALANDV"
    IL_0237:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_023c:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_0241:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0246:  dup
    IL_0247:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOptionCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapProperty::get_Options()
    IL_024c:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::.ctor()
    IL_0251:  dup
    IL_0252:  ldstr      "Residual or Variable"
    IL_0257:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Display(string)
    IL_025c:  dup
    IL_025d:  ldstr      "ConvergenceCriterionOption_4"
    IL_0262:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::set_Value(object)
    IL_0267:  dup
    IL_0268:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValueCollection [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption::get_Values()
    IL_026d:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::.ctor()
    IL_0272:  dup
    IL_0273:  ldstr      "ConvergenceCriterion"
    IL_0278:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Variable(string)
    IL_027d:  dup
    IL_027e:  ldstr      "RESIDUALORV"
    IL_0283:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue::set_Value(object)
    IL_0288:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapValue>::Add(!0)
    IL_028d:  callvirt   instance void class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvMultiMapOption>::Add(!0)
    IL_0292:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0297:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::ConvergenceCriterion_Property
    IL_029c:  ldstr      "DivergenceSteps"
    IL_02a1:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_02a6:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_02ab:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_02b0:  dup
    IL_02b1:  ldstr      "@main.Input.SPRSDIVERGE"
    IL_02b6:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_02bb:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_02c0:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::DivSteps_Property
    IL_02c5:  ldstr      "StepReductions"
    IL_02ca:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_02cf:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_02d4:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_02d9:  dup
    IL_02da:  ldstr      "@main.Input.SPRSREDUCTN"
    IL_02df:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_02e4:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_02e9:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::StepReductions_Property
    IL_02ee:  ldstr      "MaxIterations"
    IL_02f3:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_02f8:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_02fd:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0302:  dup
    IL_0303:  ldstr      "@main.Input.SPRSMAXITER"
    IL_0308:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_030d:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0312:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::MaxIterations_Property
    IL_0317:  ldstr      "MaxFastNewtonSteps"
    IL_031c:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_0321:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0326:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_032b:  dup
    IL_032c:  ldstr      "@main.Input.SPRSFASTNWTN"
    IL_0331:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0336:  dup
    IL_0337:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::.ctor()
    IL_033c:  dup
    IL_033d:  ldstr      "@main.CC Nodes.FASTN"
    IL_0342:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest::set_DataPath(string)
    IL_0347:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvStatePropertyBase::set_IsEnabledCondition(class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvLogicalTest)
    IL_034c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0351:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::MaxFastNewtonSteps_Property
    IL_0356:  ldstr      "CreepIterations"
    IL_035b:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_0360:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0365:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_036a:  dup
    IL_036b:  ldstr      "@main.Input.SPRSCRPITER"
    IL_0370:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0375:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_037a:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::CreepIterations_Property
    IL_037f:  ldstr      "CreepSize"
    IL_0384:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_0389:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_038e:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0393:  dup
    IL_0394:  ldstr      "@main.Input.SPRSCRPSIZE"
    IL_0399:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_039e:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_03a3:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::CreepSize_Property
    IL_03a8:  ldstr      "DoglegMethod"
    IL_03ad:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_03b2:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_03b7:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::.ctor()
    IL_03bc:  dup
    IL_03bd:  ldstr      "@main.Input.SPRSDOGLEG"
    IL_03c2:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DataPath(string)
    IL_03c7:  dup
    IL_03c8:  ldstr      "YES"
    IL_03cd:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_TrueValue(object)
    IL_03d2:  dup
    IL_03d3:  ldstr      "NO"
    IL_03d8:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_FalseValue(object)
    IL_03dd:  dup
    IL_03de:  ldc.i4.0
    IL_03df:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_03e4:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DefaultValue(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_03e9:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_03ee:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::DoglegMethod_Property
    IL_03f3:  ldstr      "BestPoint"
    IL_03f8:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_03fd:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0402:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::.ctor()
    IL_0407:  dup
    IL_0408:  ldstr      "@main.Input.SPRSBESTPT"
    IL_040d:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DataPath(string)
    IL_0412:  dup
    IL_0413:  ldstr      "YES"
    IL_0418:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_TrueValue(object)
    IL_041d:  dup
    IL_041e:  ldstr      "NO"
    IL_0423:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_FalseValue(object)
    IL_0428:  dup
    IL_0429:  ldc.i4.1
    IL_042a:  newobj     instance void valuetype [mscorlib]System.Nullable`1<bool>::.ctor(!0)
    IL_042f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvBooleanProperty::set_DefaultValue(valuetype [mscorlib]System.Nullable`1<bool>)
    IL_0434:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0439:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::BestPoint_Property
    IL_043e:  ldstr      "MaxRange"
    IL_0443:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_0448:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_044d:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0452:  dup
    IL_0453:  ldstr      "@main.Input.SPRSMAXRANGE"
    IL_0458:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_045d:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0462:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::MaxRange_Property
    IL_0467:  ldstr      "MaxApproach"
    IL_046c:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_0471:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0476:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_047b:  dup
    IL_047c:  ldstr      "@main.Input.SPRSMAXAPPR"
    IL_0481:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0486:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_048b:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::MaxApproach_Property
    IL_0490:  ldstr      "AbsolutePerturbation"
    IL_0495:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_049a:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_049f:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_04a4:  dup
    IL_04a5:  ldstr      "@main.Input.SPRSABSPERT"
    IL_04aa:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_04af:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_04b4:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::AbsolutePerturbation_Property
    IL_04b9:  ldstr      "SingularityPerturbation"
    IL_04be:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_04c3:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_04c8:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_04cd:  dup
    IL_04ce:  ldstr      "@main.Input.SPRSSNGPERT"
    IL_04d3:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_04d8:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_04dd:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::SingularityPerturbation_Property
    IL_04e2:  ldstr      "VariableStep"
    IL_04e7:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_04ec:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_04f1:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_04f6:  dup
    IL_04f7:  ldstr      "@main.Input.SPRSVARSTEP"
    IL_04fc:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0501:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0506:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::VariableStep_Property
    IL_050b:  ldstr      "ClipFactor"
    IL_0510:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_0515:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_051a:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_051f:  dup
    IL_0520:  ldstr      "@main.Input.SPRSCLIPFCTR"
    IL_0525:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_052a:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_052f:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::ClipFactor_Property
    IL_0534:  ldstr      "HighestVariableSteps"
    IL_0539:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_053e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0543:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0548:  dup
    IL_0549:  ldstr      "@main.Input.SPRSHIGHVAR"
    IL_054e:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_0553:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0558:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::HighestVariableSteps_Property
    IL_055d:  ldstr      "HighestResiduals"
    IL_0562:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_0567:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_056c:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_0571:  dup
    IL_0572:  ldstr      "@main.Input.SPRSHIGHRES"
    IL_0577:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_057c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_0581:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::HighestResiduals_Property
    IL_0586:  ldstr      "PrintLinearAlgebra"
    IL_058b:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_0590:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0595:  newobj     instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::.ctor()
    IL_059a:  dup
    IL_059b:  ldstr      "@main.Input.SPRSPRINT"
    IL_05a0:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvVariableProperty::set_DataPath(string)
    IL_05a5:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration::Register(string,
                                                                                                                                                                                                                         class [mscorlib]System.Type,
                                                                                                                                                                                                                         class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyBase)
    IL_05aa:  stsfld     class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvPropertyDeclaration AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::PrintLinearAlgebra_Property
    IL_05af:  ret
  } // end of method MMACMModel_Sparse_Basic_ViewModel::.cctor

  .property instance callconv(8) class [System]System.Windows.Input.ICommand
          CmdReset_Command()
  {
    .get instance class [System]System.Windows.Input.ICommand AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_CmdReset_Command()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::CmdReset_Command
  .property instance callconv(8) object SparseSolverMethod()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_SparseSolverMethod()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::SparseSolverMethod
  .property instance callconv(8) object ConvergenceCriterion()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_ConvergenceCriterion()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::ConvergenceCriterion
  .property instance callconv(8) object DivergenceSteps()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_DivergenceSteps()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::DivergenceSteps
  .property instance callconv(8) object StepReductions()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_StepReductions()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::StepReductions
  .property instance callconv(8) object MaxIterations()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_MaxIterations()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::MaxIterations
  .property instance callconv(8) object MaxFastNewtonSteps()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_MaxFastNewtonSteps()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::MaxFastNewtonSteps
  .property instance callconv(8) object CreepIterations()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_CreepIterations()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::CreepIterations
  .property instance callconv(8) object CreepSize()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_CreepSize()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::CreepSize
  .property instance callconv(8) object DoglegMethod()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_DoglegMethod()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::DoglegMethod
  .property instance callconv(8) object BestPoint()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_BestPoint()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::BestPoint
  .property instance callconv(8) object MaxRange()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_MaxRange()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::MaxRange
  .property instance callconv(8) object MaxApproach()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_MaxApproach()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::MaxApproach
  .property instance callconv(8) object AbsolutePerturbation()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_AbsolutePerturbation()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::AbsolutePerturbation
  .property instance callconv(8) object SingularityPerturbation()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_SingularityPerturbation()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::SingularityPerturbation
  .property instance callconv(8) object VariableStep()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_VariableStep()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::VariableStep
  .property instance callconv(8) object ClipFactor()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_ClipFactor()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::ClipFactor
  .property instance callconv(8) object HighestVariableSteps()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_HighestVariableSteps()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::HighestVariableSteps
  .property instance callconv(8) object HighestResiduals()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_HighestResiduals()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::HighestResiduals
  .property instance callconv(8) object PrintLinearAlgebra()
  {
    .get instance object AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel::get_PrintLinearAlgebra()
  } // end of property MMACMModel_Sparse_Basic_ViewModel::PrintLinearAlgebra
} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 30 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..0MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 53 70 61 72 73 65 5F 42 61   // ptions_Sparse_Ba
                                                                                                    73 69 63 00 00 )                                  // sic..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton CmdReset
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmConv
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MethodComboBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MethodComboBox
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel ConvergenceComboBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit ConvergenceComboBox
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel Divergence_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit DivergenceText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel StepReductions_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit StepReductionsText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MaxIterations_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MaxIterationsText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MaxFastNewton_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MaxFastNewtonText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel CreepIterations_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit CreepIterationsText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel CreepSize_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit CreepSizeText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox DoglegCheckBox_1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox BestPointCheckBox_1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmIter
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MaxRange_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MaxRangeText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel ApproachBound_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit ApproachBoundText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AbsolutePerturbation_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AbsolutePerturbationText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel SingularityPerturbation_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit SingularityPerturbationText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MaxVariableStep_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MaxVariableStepText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel ClipFactor_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit ClipFactorText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmNewton
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel HighestVariable_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit HighestVariableText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel HighestResiduals_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit HighestResidualsText
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel PrintLinear_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit PrintLinearText
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_Sparse_Basic_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_Sparse_Basic::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_sparse_basic.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_Sparse_Basic::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       701 (0x2bd)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_00ad,
                          IL_00ba,
                          IL_00c7,
                          IL_00d4,
                          IL_00e1,
                          IL_00ee,
                          IL_00fb,
                          IL_0108,
                          IL_0115,
                          IL_0122,
                          IL_012f,
                          IL_013c,
                          IL_0149,
                          IL_0156,
                          IL_0163,
                          IL_0170,
                          IL_017d,
                          IL_018a,
                          IL_0197,
                          IL_01a4,
                          IL_01b1,
                          IL_01be,
                          IL_01cb,
                          IL_01d8,
                          IL_01e5,
                          IL_01f2,
                          IL_01ff,
                          IL_020c,
                          IL_0219,
                          IL_0226,
                          IL_0233,
                          IL_0240,
                          IL_024d,
                          IL_025a,
                          IL_0267,
                          IL_0274,
                          IL_0281,
                          IL_028e,
                          IL_029b,
                          IL_02a8)
    IL_00a8:  br         IL_02b5

    IL_00ad:  ldarg.0
    IL_00ae:  ldarg.2
    IL_00af:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_00b4:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::CmdReset
    IL_00b9:  ret

    IL_00ba:  ldarg.0
    IL_00bb:  ldarg.2
    IL_00bc:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_00c1:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::frmConv
    IL_00c6:  ret

    IL_00c7:  ldarg.0
    IL_00c8:  ldarg.2
    IL_00c9:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00ce:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::MethodComboBox1_label
    IL_00d3:  ret

    IL_00d4:  ldarg.0
    IL_00d5:  ldarg.2
    IL_00d6:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_00db:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::MethodComboBox
    IL_00e0:  ret

    IL_00e1:  ldarg.0
    IL_00e2:  ldarg.2
    IL_00e3:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00e8:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::ConvergenceComboBox1_label
    IL_00ed:  ret

    IL_00ee:  ldarg.0
    IL_00ef:  ldarg.2
    IL_00f0:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_00f5:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::ConvergenceComboBox
    IL_00fa:  ret

    IL_00fb:  ldarg.0
    IL_00fc:  ldarg.2
    IL_00fd:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0102:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::Divergence_label
    IL_0107:  ret

    IL_0108:  ldarg.0
    IL_0109:  ldarg.2
    IL_010a:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_010f:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::DivergenceText
    IL_0114:  ret

    IL_0115:  ldarg.0
    IL_0116:  ldarg.2
    IL_0117:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_011c:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::StepReductions_label
    IL_0121:  ret

    IL_0122:  ldarg.0
    IL_0123:  ldarg.2
    IL_0124:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0129:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::StepReductionsText
    IL_012e:  ret

    IL_012f:  ldarg.0
    IL_0130:  ldarg.2
    IL_0131:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0136:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::MaxIterations_label
    IL_013b:  ret

    IL_013c:  ldarg.0
    IL_013d:  ldarg.2
    IL_013e:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0143:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::MaxIterationsText
    IL_0148:  ret

    IL_0149:  ldarg.0
    IL_014a:  ldarg.2
    IL_014b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0150:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::MaxFastNewton_label
    IL_0155:  ret

    IL_0156:  ldarg.0
    IL_0157:  ldarg.2
    IL_0158:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_015d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::MaxFastNewtonText
    IL_0162:  ret

    IL_0163:  ldarg.0
    IL_0164:  ldarg.2
    IL_0165:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_016a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::CreepIterations_label
    IL_016f:  ret

    IL_0170:  ldarg.0
    IL_0171:  ldarg.2
    IL_0172:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0177:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::CreepIterationsText
    IL_017c:  ret

    IL_017d:  ldarg.0
    IL_017e:  ldarg.2
    IL_017f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0184:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::CreepSize_label
    IL_0189:  ret

    IL_018a:  ldarg.0
    IL_018b:  ldarg.2
    IL_018c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0191:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::CreepSizeText
    IL_0196:  ret

    IL_0197:  ldarg.0
    IL_0198:  ldarg.2
    IL_0199:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox
    IL_019e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::DoglegCheckBox_1
    IL_01a3:  ret

    IL_01a4:  ldarg.0
    IL_01a5:  ldarg.2
    IL_01a6:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox
    IL_01ab:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCheckBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::BestPointCheckBox_1
    IL_01b0:  ret

    IL_01b1:  ldarg.0
    IL_01b2:  ldarg.2
    IL_01b3:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_01b8:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::frmIter
    IL_01bd:  ret

    IL_01be:  ldarg.0
    IL_01bf:  ldarg.2
    IL_01c0:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_01c5:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::MaxRange_label
    IL_01ca:  ret

    IL_01cb:  ldarg.0
    IL_01cc:  ldarg.2
    IL_01cd:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_01d2:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::MaxRangeText
    IL_01d7:  ret

    IL_01d8:  ldarg.0
    IL_01d9:  ldarg.2
    IL_01da:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_01df:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::ApproachBound_label
    IL_01e4:  ret

    IL_01e5:  ldarg.0
    IL_01e6:  ldarg.2
    IL_01e7:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_01ec:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::ApproachBoundText
    IL_01f1:  ret

    IL_01f2:  ldarg.0
    IL_01f3:  ldarg.2
    IL_01f4:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_01f9:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::AbsolutePerturbation_label
    IL_01fe:  ret

    IL_01ff:  ldarg.0
    IL_0200:  ldarg.2
    IL_0201:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0206:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::AbsolutePerturbationText
    IL_020b:  ret

    IL_020c:  ldarg.0
    IL_020d:  ldarg.2
    IL_020e:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0213:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::SingularityPerturbation_label
    IL_0218:  ret

    IL_0219:  ldarg.0
    IL_021a:  ldarg.2
    IL_021b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0220:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::SingularityPerturbationText
    IL_0225:  ret

    IL_0226:  ldarg.0
    IL_0227:  ldarg.2
    IL_0228:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_022d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::MaxVariableStep_label
    IL_0232:  ret

    IL_0233:  ldarg.0
    IL_0234:  ldarg.2
    IL_0235:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_023a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::MaxVariableStepText
    IL_023f:  ret

    IL_0240:  ldarg.0
    IL_0241:  ldarg.2
    IL_0242:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0247:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::ClipFactor_label
    IL_024c:  ret

    IL_024d:  ldarg.0
    IL_024e:  ldarg.2
    IL_024f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0254:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::ClipFactorText
    IL_0259:  ret

    IL_025a:  ldarg.0
    IL_025b:  ldarg.2
    IL_025c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_0261:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::frmNewton
    IL_0266:  ret

    IL_0267:  ldarg.0
    IL_0268:  ldarg.2
    IL_0269:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_026e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::HighestVariable_label
    IL_0273:  ret

    IL_0274:  ldarg.0
    IL_0275:  ldarg.2
    IL_0276:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_027b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::HighestVariableText
    IL_0280:  ret

    IL_0281:  ldarg.0
    IL_0282:  ldarg.2
    IL_0283:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0288:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::HighestResiduals_label
    IL_028d:  ret

    IL_028e:  ldarg.0
    IL_028f:  ldarg.2
    IL_0290:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0295:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::HighestResidualsText
    IL_029a:  ret

    IL_029b:  ldarg.0
    IL_029c:  ldarg.2
    IL_029d:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_02a2:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::PrintLinear_label
    IL_02a7:  ret

    IL_02a8:  ldarg.0
    IL_02a9:  ldarg.2
    IL_02aa:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_02af:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::PrintLinearText
    IL_02b4:  ret

    IL_02b5:  ldarg.0
    IL_02b6:  ldc.i4.1
    IL_02b7:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic::_contentLoaded
    IL_02bc:  ret
  } // end of method MMACMModel_SolverOptions_Sparse_Basic::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_Sparse_Basic

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 30 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..0MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 44 4D 4F 42 61 73 5F 42 61   // ptions_DMOBas_Ba
                                                                                                    73 69 63 00 00 )                                  // sic..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLabel1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit MMAdvCombo1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton CmdReset
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmConv
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText3_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmIter
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox4_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox4
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmNewton
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox3_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel lbtuStep_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit lbtuStep
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    [AspenTech.AspenPlus.MMForms.Convergence]AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options.MMEOConv_DMOBas_Basic_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas_Basic::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_dmobas_basic.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas_Basic::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       361 (0x169)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_005d,
                          IL_006a,
                          IL_0077,
                          IL_0084,
                          IL_0091,
                          IL_009e,
                          IL_00ab,
                          IL_00b8,
                          IL_00c5,
                          IL_00d2,
                          IL_00df,
                          IL_00ec,
                          IL_00f9,
                          IL_0106,
                          IL_0113,
                          IL_0120,
                          IL_012d,
                          IL_013a,
                          IL_0147,
                          IL_0154)
    IL_0058:  br         IL_0161

    IL_005d:  ldarg.0
    IL_005e:  ldarg.2
    IL_005f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0064:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMLabel1
    IL_0069:  ret

    IL_006a:  ldarg.0
    IL_006b:  ldarg.2
    IL_006c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit
    IL_0071:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMAdvCombo1
    IL_0076:  ret

    IL_0077:  ldarg.0
    IL_0078:  ldarg.2
    IL_0079:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_007e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::CmdReset
    IL_0083:  ret

    IL_0084:  ldarg.0
    IL_0085:  ldarg.2
    IL_0086:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_008b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::frmConv
    IL_0090:  ret

    IL_0091:  ldarg.0
    IL_0092:  ldarg.2
    IL_0093:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0098:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMLBUText1_label
    IL_009d:  ret

    IL_009e:  ldarg.0
    IL_009f:  ldarg.2
    IL_00a0:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00a5:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMLBUText1
    IL_00aa:  ret

    IL_00ab:  ldarg.0
    IL_00ac:  ldarg.2
    IL_00ad:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00b2:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMLBUText3_label
    IL_00b7:  ret

    IL_00b8:  ldarg.0
    IL_00b9:  ldarg.2
    IL_00ba:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00bf:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMLBUText3
    IL_00c4:  ret

    IL_00c5:  ldarg.0
    IL_00c6:  ldarg.2
    IL_00c7:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_00cc:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::frmIter
    IL_00d1:  ret

    IL_00d2:  ldarg.0
    IL_00d3:  ldarg.2
    IL_00d4:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00d9:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMSpinBox1_label
    IL_00de:  ret

    IL_00df:  ldarg.0
    IL_00e0:  ldarg.2
    IL_00e1:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_00e6:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMSpinBox1
    IL_00eb:  ret

    IL_00ec:  ldarg.0
    IL_00ed:  ldarg.2
    IL_00ee:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00f3:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMSpinBox4_label
    IL_00f8:  ret

    IL_00f9:  ldarg.0
    IL_00fa:  ldarg.2
    IL_00fb:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_0100:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMSpinBox4
    IL_0105:  ret

    IL_0106:  ldarg.0
    IL_0107:  ldarg.2
    IL_0108:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_010d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::frmNewton
    IL_0112:  ret

    IL_0113:  ldarg.0
    IL_0114:  ldarg.2
    IL_0115:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_011a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMComboBox1_label
    IL_011f:  ret

    IL_0120:  ldarg.0
    IL_0121:  ldarg.2
    IL_0122:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_0127:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMComboBox1
    IL_012c:  ret

    IL_012d:  ldarg.0
    IL_012e:  ldarg.2
    IL_012f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0134:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMSpinBox3_label
    IL_0139:  ret

    IL_013a:  ldarg.0
    IL_013b:  ldarg.2
    IL_013c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_0141:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::MMSpinBox3
    IL_0146:  ret

    IL_0147:  ldarg.0
    IL_0148:  ldarg.2
    IL_0149:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_014e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::lbtuStep_label
    IL_0153:  ret

    IL_0154:  ldarg.0
    IL_0155:  ldarg.2
    IL_0156:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_015b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::lbtuStep
    IL_0160:  ret

    IL_0161:  ldarg.0
    IL_0162:  ldc.i4.1
    IL_0163:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic::_contentLoaded
    IL_0168:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas_Basic::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Basic

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 2A 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..*MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 44 4D 4F 42 61 73 00 00 )    // ptions_DMOBas..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip MMSSTab1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab0
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab2
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    [AspenTech.AspenPlus.MMForms.Convergence]AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options.MMEOConv_DMOBas_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_dmobas.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       86 (0x56)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_001a,
                          IL_0027,
                          IL_0034,
                          IL_0041)
    IL_0018:  br.s       IL_004e

    IL_001a:  ldarg.0
    IL_001b:  ldarg.2
    IL_001c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip
    IL_0021:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas::MMSSTab1
    IL_0026:  ret

    IL_0027:  ldarg.0
    IL_0028:  ldarg.2
    IL_0029:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_002e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas::tab0
    IL_0033:  ret

    IL_0034:  ldarg.0
    IL_0035:  ldarg.2
    IL_0036:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_003b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas::tab1
    IL_0040:  ret

    IL_0041:  ldarg.0
    IL_0042:  ldarg.2
    IL_0043:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_0048:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas::tab2
    IL_004d:  ret

    IL_004e:  ldarg.0
    IL_004f:  ldc.i4.1
    IL_0050:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas::_contentLoaded
    IL_0055:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 31 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..1MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 44 4D 4F 42 61 73 5F 52 65   // ptions_DMOBas_Re
                                                                                                    70 6F 72 74 00 00 )                               // port..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLabel1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit MMAdvCombo1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton CmdReset
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmHess
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboBox2_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboBox2
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    [AspenTech.AspenPlus.MMForms.Convergence]AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options.MMEOConv_DMOBas_Report_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas_Report::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_dmobas_report.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas_Report::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       191 (0xbf)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_0035,
                          IL_0042,
                          IL_004f,
                          IL_005c,
                          IL_0069,
                          IL_0076,
                          IL_0083,
                          IL_0090,
                          IL_009d,
                          IL_00aa)
    IL_0030:  br         IL_00b7

    IL_0035:  ldarg.0
    IL_0036:  ldarg.2
    IL_0037:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_003c:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::MMLabel1
    IL_0041:  ret

    IL_0042:  ldarg.0
    IL_0043:  ldarg.2
    IL_0044:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit
    IL_0049:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::MMAdvCombo1
    IL_004e:  ret

    IL_004f:  ldarg.0
    IL_0050:  ldarg.2
    IL_0051:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_0056:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::CmdReset
    IL_005b:  ret

    IL_005c:  ldarg.0
    IL_005d:  ldarg.2
    IL_005e:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_0063:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::frmHess
    IL_0068:  ret

    IL_0069:  ldarg.0
    IL_006a:  ldarg.2
    IL_006b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0070:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::MMComboBox1_label
    IL_0075:  ret

    IL_0076:  ldarg.0
    IL_0077:  ldarg.2
    IL_0078:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_007d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::MMComboBox1
    IL_0082:  ret

    IL_0083:  ldarg.0
    IL_0084:  ldarg.2
    IL_0085:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_008a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::MMSpinBox1_label
    IL_008f:  ret

    IL_0090:  ldarg.0
    IL_0091:  ldarg.2
    IL_0092:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_0097:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::MMSpinBox1
    IL_009c:  ret

    IL_009d:  ldarg.0
    IL_009e:  ldarg.2
    IL_009f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00a4:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::MMComboBox2_label
    IL_00a9:  ret

    IL_00aa:  ldarg.0
    IL_00ab:  ldarg.2
    IL_00ac:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_00b1:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::MMComboBox2
    IL_00b6:  ret

    IL_00b7:  ldarg.0
    IL_00b8:  ldc.i4.1
    IL_00b9:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report::_contentLoaded
    IL_00be:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas_Report::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Report

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 31 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..1MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 44 4D 4F 42 61 73 5F 53 65   // ptions_DMOBas_Se
                                                                                                    61 72 63 68 00 00 )                               // arch..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLabel1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit MMAdvCombo1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton CmdReset
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmHess
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText6_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText6
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmLine
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboBox3_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboBox3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboBox2_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboBox2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox3_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox MMFrame1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboBox4_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboBox4
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    [AspenTech.AspenPlus.MMForms.Convergence]AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options.MMEOConv_DMOBas_Search_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas_Search::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_dmobas_search.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas_Search::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       361 (0x169)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_005d,
                          IL_006a,
                          IL_0077,
                          IL_0084,
                          IL_0091,
                          IL_009e,
                          IL_00ab,
                          IL_00b8,
                          IL_00c5,
                          IL_00d2,
                          IL_00df,
                          IL_00ec,
                          IL_00f9,
                          IL_0106,
                          IL_0113,
                          IL_0120,
                          IL_012d,
                          IL_013a,
                          IL_0147,
                          IL_0154)
    IL_0058:  br         IL_0161

    IL_005d:  ldarg.0
    IL_005e:  ldarg.2
    IL_005f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0064:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMLabel1
    IL_0069:  ret

    IL_006a:  ldarg.0
    IL_006b:  ldarg.2
    IL_006c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit
    IL_0071:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMAdvCombo1
    IL_0076:  ret

    IL_0077:  ldarg.0
    IL_0078:  ldarg.2
    IL_0079:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_007e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::CmdReset
    IL_0083:  ret

    IL_0084:  ldarg.0
    IL_0085:  ldarg.2
    IL_0086:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_008b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::frmHess
    IL_0090:  ret

    IL_0091:  ldarg.0
    IL_0092:  ldarg.2
    IL_0093:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0098:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMComboBox1_label
    IL_009d:  ret

    IL_009e:  ldarg.0
    IL_009f:  ldarg.2
    IL_00a0:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_00a5:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMComboBox1
    IL_00aa:  ret

    IL_00ab:  ldarg.0
    IL_00ac:  ldarg.2
    IL_00ad:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00b2:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMLBUText6_label
    IL_00b7:  ret

    IL_00b8:  ldarg.0
    IL_00b9:  ldarg.2
    IL_00ba:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00bf:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMLBUText6
    IL_00c4:  ret

    IL_00c5:  ldarg.0
    IL_00c6:  ldarg.2
    IL_00c7:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00cc:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMSpinBox1_label
    IL_00d1:  ret

    IL_00d2:  ldarg.0
    IL_00d3:  ldarg.2
    IL_00d4:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_00d9:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMSpinBox1
    IL_00de:  ret

    IL_00df:  ldarg.0
    IL_00e0:  ldarg.2
    IL_00e1:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_00e6:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::frmLine
    IL_00eb:  ret

    IL_00ec:  ldarg.0
    IL_00ed:  ldarg.2
    IL_00ee:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00f3:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMComboBox3_label
    IL_00f8:  ret

    IL_00f9:  ldarg.0
    IL_00fa:  ldarg.2
    IL_00fb:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_0100:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMComboBox3
    IL_0105:  ret

    IL_0106:  ldarg.0
    IL_0107:  ldarg.2
    IL_0108:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_010d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMComboBox2_label
    IL_0112:  ret

    IL_0113:  ldarg.0
    IL_0114:  ldarg.2
    IL_0115:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_011a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMComboBox2
    IL_011f:  ret

    IL_0120:  ldarg.0
    IL_0121:  ldarg.2
    IL_0122:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0127:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMSpinBox3_label
    IL_012c:  ret

    IL_012d:  ldarg.0
    IL_012e:  ldarg.2
    IL_012f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_0134:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMSpinBox3
    IL_0139:  ret

    IL_013a:  ldarg.0
    IL_013b:  ldarg.2
    IL_013c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_0141:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMFrame1
    IL_0146:  ret

    IL_0147:  ldarg.0
    IL_0148:  ldarg.2
    IL_0149:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_014e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMComboBox4_label
    IL_0153:  ret

    IL_0154:  ldarg.0
    IL_0155:  ldarg.2
    IL_0156:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_015b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::MMComboBox4
    IL_0160:  ret

    IL_0161:  ldarg.0
    IL_0162:  ldc.i4.1
    IL_0163:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search::_contentLoaded
    IL_0168:  ret
  } // end of method MMACMModel_SolverOptions_DMOBas_Search::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_DMOBas_Search

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 2A 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..*MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 4C 53 53 42 61 73 00 00 )    // ptions_LSSBas..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip MMSSTab1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab0
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab2
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    [AspenTech.AspenPlus.MMForms.Convergence]AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options.MMEOConv_LSSBas_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_lssbas.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       86 (0x56)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_001a,
                          IL_0027,
                          IL_0034,
                          IL_0041)
    IL_0018:  br.s       IL_004e

    IL_001a:  ldarg.0
    IL_001b:  ldarg.2
    IL_001c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip
    IL_0021:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas::MMSSTab1
    IL_0026:  ret

    IL_0027:  ldarg.0
    IL_0028:  ldarg.2
    IL_0029:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_002e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas::tab0
    IL_0033:  ret

    IL_0034:  ldarg.0
    IL_0035:  ldarg.2
    IL_0036:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_003b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas::tab1
    IL_0040:  ret

    IL_0041:  ldarg.0
    IL_0042:  ldarg.2
    IL_0043:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_0048:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas::tab2
    IL_004d:  ret

    IL_004e:  ldarg.0
    IL_004f:  ldc.i4.1
    IL_0050:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas::_contentLoaded
    IL_0055:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 30 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..0MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 4C 53 53 42 61 73 5F 42 61   // ptions_LSSBas_Ba
                                                                                                    73 69 63 00 00 )                                  // sic..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLabel1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit MMAdvCombo1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton CmdReset
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmIter
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText2_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText4_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText4
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText5_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText5
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox MMFrame1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox2_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox3_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox4_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox4
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox MMFrame2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox5_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox5
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox6_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox6
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    [AspenTech.AspenPlus.MMForms.Convergence]AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options.MMEOConv_LSSBas_Basic_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas_Basic::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_lssbas_basic.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas_Basic::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       429 (0x1ad)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_006d,
                          IL_007a,
                          IL_0087,
                          IL_0094,
                          IL_00a1,
                          IL_00ae,
                          IL_00bb,
                          IL_00c8,
                          IL_00d5,
                          IL_00e2,
                          IL_00ef,
                          IL_00fc,
                          IL_0109,
                          IL_0116,
                          IL_0123,
                          IL_0130,
                          IL_013d,
                          IL_014a,
                          IL_0157,
                          IL_0164,
                          IL_0171,
                          IL_017e,
                          IL_018b,
                          IL_0198)
    IL_0068:  br         IL_01a5

    IL_006d:  ldarg.0
    IL_006e:  ldarg.2
    IL_006f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0074:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMLabel1
    IL_0079:  ret

    IL_007a:  ldarg.0
    IL_007b:  ldarg.2
    IL_007c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit
    IL_0081:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMAdvCombo1
    IL_0086:  ret

    IL_0087:  ldarg.0
    IL_0088:  ldarg.2
    IL_0089:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_008e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::CmdReset
    IL_0093:  ret

    IL_0094:  ldarg.0
    IL_0095:  ldarg.2
    IL_0096:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_009b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::frmIter
    IL_00a0:  ret

    IL_00a1:  ldarg.0
    IL_00a2:  ldarg.2
    IL_00a3:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00a8:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMLBUText2_label
    IL_00ad:  ret

    IL_00ae:  ldarg.0
    IL_00af:  ldarg.2
    IL_00b0:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00b5:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMLBUText2
    IL_00ba:  ret

    IL_00bb:  ldarg.0
    IL_00bc:  ldarg.2
    IL_00bd:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00c2:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMLBUText4_label
    IL_00c7:  ret

    IL_00c8:  ldarg.0
    IL_00c9:  ldarg.2
    IL_00ca:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00cf:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMLBUText4
    IL_00d4:  ret

    IL_00d5:  ldarg.0
    IL_00d6:  ldarg.2
    IL_00d7:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00dc:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMLBUText5_label
    IL_00e1:  ret

    IL_00e2:  ldarg.0
    IL_00e3:  ldarg.2
    IL_00e4:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00e9:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMLBUText5
    IL_00ee:  ret

    IL_00ef:  ldarg.0
    IL_00f0:  ldarg.2
    IL_00f1:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_00f6:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMFrame1
    IL_00fb:  ret

    IL_00fc:  ldarg.0
    IL_00fd:  ldarg.2
    IL_00fe:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0103:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox1_label
    IL_0108:  ret

    IL_0109:  ldarg.0
    IL_010a:  ldarg.2
    IL_010b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_0110:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox1
    IL_0115:  ret

    IL_0116:  ldarg.0
    IL_0117:  ldarg.2
    IL_0118:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_011d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox2_label
    IL_0122:  ret

    IL_0123:  ldarg.0
    IL_0124:  ldarg.2
    IL_0125:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_012a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox2
    IL_012f:  ret

    IL_0130:  ldarg.0
    IL_0131:  ldarg.2
    IL_0132:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0137:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox3_label
    IL_013c:  ret

    IL_013d:  ldarg.0
    IL_013e:  ldarg.2
    IL_013f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_0144:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox3
    IL_0149:  ret

    IL_014a:  ldarg.0
    IL_014b:  ldarg.2
    IL_014c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0151:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox4_label
    IL_0156:  ret

    IL_0157:  ldarg.0
    IL_0158:  ldarg.2
    IL_0159:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_015e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox4
    IL_0163:  ret

    IL_0164:  ldarg.0
    IL_0165:  ldarg.2
    IL_0166:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_016b:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMFrame2
    IL_0170:  ret

    IL_0171:  ldarg.0
    IL_0172:  ldarg.2
    IL_0173:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0178:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox5_label
    IL_017d:  ret

    IL_017e:  ldarg.0
    IL_017f:  ldarg.2
    IL_0180:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_0185:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox5
    IL_018a:  ret

    IL_018b:  ldarg.0
    IL_018c:  ldarg.2
    IL_018d:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0192:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox6_label
    IL_0197:  ret

    IL_0198:  ldarg.0
    IL_0199:  ldarg.2
    IL_019a:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_019f:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::MMSpinBox6
    IL_01a4:  ret

    IL_01a5:  ldarg.0
    IL_01a6:  ldc.i4.1
    IL_01a7:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic::_contentLoaded
    IL_01ac:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas_Basic::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Basic

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 31 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..1MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 4C 53 53 42 61 73 5F 52 65   // ptions_LSSBas_Re
                                                                                                    70 6F 72 74 00 00 )                               // port..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLabel1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit MMAdvCombo1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton CmdReset
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmHess
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox MMFrame1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox4_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox4
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox MMFrame2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox2_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox3_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox3
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    [AspenTech.AspenPlus.MMForms.Convergence]AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options.MMEOConv_LSSBas_Report_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas_Report::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_lssbas_report.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas_Report::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       259 (0x103)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_0045,
                          IL_0052,
                          IL_005f,
                          IL_006c,
                          IL_0079,
                          IL_0086,
                          IL_0093,
                          IL_00a0,
                          IL_00ad,
                          IL_00ba,
                          IL_00c7,
                          IL_00d4,
                          IL_00e1,
                          IL_00ee)
    IL_0040:  br         IL_00fb

    IL_0045:  ldarg.0
    IL_0046:  ldarg.2
    IL_0047:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_004c:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMLabel1
    IL_0051:  ret

    IL_0052:  ldarg.0
    IL_0053:  ldarg.2
    IL_0054:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit
    IL_0059:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMAdvCombo1
    IL_005e:  ret

    IL_005f:  ldarg.0
    IL_0060:  ldarg.2
    IL_0061:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_0066:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::CmdReset
    IL_006b:  ret

    IL_006c:  ldarg.0
    IL_006d:  ldarg.2
    IL_006e:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_0073:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::frmHess
    IL_0078:  ret

    IL_0079:  ldarg.0
    IL_007a:  ldarg.2
    IL_007b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_0080:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMFrame1
    IL_0085:  ret

    IL_0086:  ldarg.0
    IL_0087:  ldarg.2
    IL_0088:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_008d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMSpinBox4_label
    IL_0092:  ret

    IL_0093:  ldarg.0
    IL_0094:  ldarg.2
    IL_0095:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_009a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMSpinBox4
    IL_009f:  ret

    IL_00a0:  ldarg.0
    IL_00a1:  ldarg.2
    IL_00a2:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_00a7:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMFrame2
    IL_00ac:  ret

    IL_00ad:  ldarg.0
    IL_00ae:  ldarg.2
    IL_00af:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00b4:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMSpinBox2_label
    IL_00b9:  ret

    IL_00ba:  ldarg.0
    IL_00bb:  ldarg.2
    IL_00bc:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_00c1:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMSpinBox2
    IL_00c6:  ret

    IL_00c7:  ldarg.0
    IL_00c8:  ldarg.2
    IL_00c9:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00ce:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMSpinBox1_label
    IL_00d3:  ret

    IL_00d4:  ldarg.0
    IL_00d5:  ldarg.2
    IL_00d6:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_00db:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMSpinBox1
    IL_00e0:  ret

    IL_00e1:  ldarg.0
    IL_00e2:  ldarg.2
    IL_00e3:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00e8:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMSpinBox3_label
    IL_00ed:  ret

    IL_00ee:  ldarg.0
    IL_00ef:  ldarg.2
    IL_00f0:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_00f5:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::MMSpinBox3
    IL_00fa:  ret

    IL_00fb:  ldarg.0
    IL_00fc:  ldc.i4.1
    IL_00fd:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report::_contentLoaded
    IL_0102:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas_Report::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Report

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 31 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..1MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 4C 53 53 42 61 73 5F 53 65   // ptions_LSSBas_Se
                                                                                                    61 72 63 68 00 00 )                               // arch..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLabel1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit MMAdvCombo1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton CmdReset
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmIter
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox MMFrame1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMComboBox2_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit MMComboBox2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox2_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText3_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText2_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText4_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText4
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    [AspenTech.AspenPlus.MMForms.Convergence]AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options.MMEOConv_LSSBas_Search_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas_Search::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_lssbas_search.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas_Search::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       344 (0x158)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_0059,
                          IL_0066,
                          IL_0073,
                          IL_0080,
                          IL_008d,
                          IL_009a,
                          IL_00a7,
                          IL_00b4,
                          IL_00c1,
                          IL_00ce,
                          IL_00db,
                          IL_00e8,
                          IL_00f5,
                          IL_0102,
                          IL_010f,
                          IL_011c,
                          IL_0129,
                          IL_0136,
                          IL_0143)
    IL_0054:  br         IL_0150

    IL_0059:  ldarg.0
    IL_005a:  ldarg.2
    IL_005b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0060:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMLabel1
    IL_0065:  ret

    IL_0066:  ldarg.0
    IL_0067:  ldarg.2
    IL_0068:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit
    IL_006d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMAdvCombo1
    IL_0072:  ret

    IL_0073:  ldarg.0
    IL_0074:  ldarg.2
    IL_0075:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_007a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::CmdReset
    IL_007f:  ret

    IL_0080:  ldarg.0
    IL_0081:  ldarg.2
    IL_0082:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_0087:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::frmIter
    IL_008c:  ret

    IL_008d:  ldarg.0
    IL_008e:  ldarg.2
    IL_008f:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0094:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMComboBox1_label
    IL_0099:  ret

    IL_009a:  ldarg.0
    IL_009b:  ldarg.2
    IL_009c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_00a1:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMComboBox1
    IL_00a6:  ret

    IL_00a7:  ldarg.0
    IL_00a8:  ldarg.2
    IL_00a9:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00ae:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMLBUText1_label
    IL_00b3:  ret

    IL_00b4:  ldarg.0
    IL_00b5:  ldarg.2
    IL_00b6:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00bb:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMLBUText1
    IL_00c0:  ret

    IL_00c1:  ldarg.0
    IL_00c2:  ldarg.2
    IL_00c3:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_00c8:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMFrame1
    IL_00cd:  ret

    IL_00ce:  ldarg.0
    IL_00cf:  ldarg.2
    IL_00d0:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00d5:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMComboBox2_label
    IL_00da:  ret

    IL_00db:  ldarg.0
    IL_00dc:  ldarg.2
    IL_00dd:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit
    IL_00e2:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMComboBox2
    IL_00e7:  ret

    IL_00e8:  ldarg.0
    IL_00e9:  ldarg.2
    IL_00ea:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00ef:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMSpinBox2_label
    IL_00f4:  ret

    IL_00f5:  ldarg.0
    IL_00f6:  ldarg.2
    IL_00f7:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_00fc:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMSpinBox2
    IL_0101:  ret

    IL_0102:  ldarg.0
    IL_0103:  ldarg.2
    IL_0104:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0109:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMLBUText3_label
    IL_010e:  ret

    IL_010f:  ldarg.0
    IL_0110:  ldarg.2
    IL_0111:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0116:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMLBUText3
    IL_011b:  ret

    IL_011c:  ldarg.0
    IL_011d:  ldarg.2
    IL_011e:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0123:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMLBUText2_label
    IL_0128:  ret

    IL_0129:  ldarg.0
    IL_012a:  ldarg.2
    IL_012b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_0130:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMLBUText2
    IL_0135:  ret

    IL_0136:  ldarg.0
    IL_0137:  ldarg.2
    IL_0138:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_013d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMLBUText4_label
    IL_0142:  ret

    IL_0143:  ldarg.0
    IL_0144:  ldarg.2
    IL_0145:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_014a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::MMLBUText4
    IL_014f:  ret

    IL_0150:  ldarg.0
    IL_0151:  ldc.i4.1
    IL_0152:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search::_contentLoaded
    IL_0157:  ret
  } // end of method MMACMModel_SolverOptions_LSSBas_Search::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_LSSBas_Search

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 2A 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..*MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 4E 53 4C 42 61 73 00 00 )    // ptions_NSLBas..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip MMSSTab1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem tab0
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabTemplate::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    [AspenTech.AspenPlus.MMForms.Convergence]AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options.MMEOConv_NSLBas_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_NSLBas::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_nslbas.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_NSLBas::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       44 (0x2c)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  beq.s      IL_000a

    IL_0004:  ldarg.1
    IL_0005:  ldc.i4.2
    IL_0006:  beq.s      IL_0017

    IL_0008:  br.s       IL_0024

    IL_000a:  ldarg.0
    IL_000b:  ldarg.2
    IL_000c:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip
    IL_0011:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabStrip AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas::MMSSTab1
    IL_0016:  ret

    IL_0017:  ldarg.0
    IL_0018:  ldarg.2
    IL_0019:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem
    IL_001e:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabItem AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas::tab0
    IL_0023:  ret

    IL_0024:  ldarg.0
    IL_0025:  ldc.i4.1
    IL_0026:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas::_contentLoaded
    IL_002b:  ret
  } // end of method MMACMModel_SolverOptions_NSLBas::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas

.class public auto ansi beforefieldinit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic
       extends [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage
       implements [System.Xaml]System.Windows.Markup.IComponentConnector
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 30 4D 4D 41 43 4D 4D 6F 64 65 6C 2E 4D 4D   // ..0MMACMModel.MM
                                                                                                    41 43 4D 4D 6F 64 65 6C 5F 53 6F 6C 76 65 72 4F   // ACMModel_SolverO
                                                                                                    70 74 69 6F 6E 73 5F 4E 53 4C 42 61 73 5F 42 61   // ptions_NSLBas_Ba
                                                                                                    73 69 63 00 00 )                                  // sic..
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLabel1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit MMAdvCombo1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton CmdReset
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox frmMatrix
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox3_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox1_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox1
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMSpinBox2_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox MMSpinBox2
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText3_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText3
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel MMLBUText2_label
  .field assembly class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit MMLBUText2
  .field private bool _contentLoaded
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMTabPage::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldtoken    [AspenTech.AspenPlus.MMForms.Convergence]AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options.MMEOConv_NSLBas_Basic_ViewModel
    IL_000c:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0011:  call       instance void [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMViewModelContainer::set_ViewModelType(class [mscorlib]System.Type)
    IL_0016:  ldarg.0
    IL_0017:  call       instance void AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::InitializeComponent()
    IL_001c:  ret
  } // end of method MMACMModel_SolverOptions_NSLBas_Basic::.ctor

  .method public hidebysig newslot virtual final 
          instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    // Code size       36 (0x24)
    .maxstack  2
    .locals init (class [System]System.Uri V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::_contentLoaded
    IL_0006:  brfalse.s  IL_0009

    IL_0008:  ret

    IL_0009:  ldarg.0
    IL_000a:  ldc.i4.1
    IL_000b:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::_contentLoaded
    IL_0010:  ldstr      "/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;compo"
    + "nent/mmacmmodel_solveroptions_nslbas_basic.xaml"
    IL_0015:  ldc.i4.2
    IL_0016:  newobj     instance void [System]System.Uri::.ctor(string,
                                                                 valuetype [System]System.UriKind)
    IL_001b:  stloc.0
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  call       void [PresentationFramework]System.Windows.Application::LoadComponent(object,
                                                                                               class [System]System.Uri)
    IL_0023:  ret
  } // end of method MMACMModel_SolverOptions_NSLBas_Basic::InitializeComponent

  .method private hidebysig newslot virtual final 
          instance void  System.Windows.Markup.IComponentConnector.Connect(int32 connectionId,
                                                                           object target) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                        string) = ( 01 00 16 50 72 65 73 65 6E 74 61 74 69 6F 6E 42   // ...PresentationB
                                                                                                    75 69 6C 64 54 61 73 6B 73 07 34 2E 30 2E 30 2E   // uildTasks.4.0.0.
                                                                                                    30 00 00 )                                        // 0..
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .override [System.Xaml]System.Windows.Markup.IComponentConnector::Connect
    // Code size       259 (0x103)
    .maxstack  2
    IL_0000:  ldarg.1
    IL_0001:  ldc.i4.1
    IL_0002:  sub
    IL_0003:  switch     ( 
                          IL_0045,
                          IL_0052,
                          IL_005f,
                          IL_006c,
                          IL_0079,
                          IL_0086,
                          IL_0093,
                          IL_00a0,
                          IL_00ad,
                          IL_00ba,
                          IL_00c7,
                          IL_00d4,
                          IL_00e1,
                          IL_00ee)
    IL_0040:  br         IL_00fb

    IL_0045:  ldarg.0
    IL_0046:  ldarg.2
    IL_0047:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_004c:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMLabel1
    IL_0051:  ret

    IL_0052:  ldarg.0
    IL_0053:  ldarg.2
    IL_0054:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit
    IL_0059:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMAdvancedComboEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMAdvCombo1
    IL_005e:  ret

    IL_005f:  ldarg.0
    IL_0060:  ldarg.2
    IL_0061:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton
    IL_0066:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMCmdButton AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::CmdReset
    IL_006b:  ret

    IL_006c:  ldarg.0
    IL_006d:  ldarg.2
    IL_006e:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox
    IL_0073:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMGroupBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::frmMatrix
    IL_0078:  ret

    IL_0079:  ldarg.0
    IL_007a:  ldarg.2
    IL_007b:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_0080:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMSpinBox3_label
    IL_0085:  ret

    IL_0086:  ldarg.0
    IL_0087:  ldarg.2
    IL_0088:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_008d:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMSpinBox3
    IL_0092:  ret

    IL_0093:  ldarg.0
    IL_0094:  ldarg.2
    IL_0095:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_009a:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMSpinBox1_label
    IL_009f:  ret

    IL_00a0:  ldarg.0
    IL_00a1:  ldarg.2
    IL_00a2:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_00a7:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMSpinBox1
    IL_00ac:  ret

    IL_00ad:  ldarg.0
    IL_00ae:  ldarg.2
    IL_00af:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00b4:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMSpinBox2_label
    IL_00b9:  ret

    IL_00ba:  ldarg.0
    IL_00bb:  ldarg.2
    IL_00bc:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox
    IL_00c1:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMSpinBox AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMSpinBox2
    IL_00c6:  ret

    IL_00c7:  ldarg.0
    IL_00c8:  ldarg.2
    IL_00c9:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00ce:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMLBUText3_label
    IL_00d3:  ret

    IL_00d4:  ldarg.0
    IL_00d5:  ldarg.2
    IL_00d6:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00db:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMLBUText3
    IL_00e0:  ret

    IL_00e1:  ldarg.0
    IL_00e2:  ldarg.2
    IL_00e3:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel
    IL_00e8:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMLabel AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMLBUText2_label
    IL_00ed:  ret

    IL_00ee:  ldarg.0
    IL_00ef:  ldarg.2
    IL_00f0:  castclass  [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit
    IL_00f5:  stfld      class [AspenTech.AspenPlus.MMControls]AspenTech.AspenPlus.MMControls.MMVariableEdit AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::MMLBUText2
    IL_00fa:  ret

    IL_00fb:  ldarg.0
    IL_00fc:  ldc.i4.1
    IL_00fd:  stfld      bool AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic::_contentLoaded
    IL_0102:  ret
  } // end of method MMACMModel_SolverOptions_NSLBas_Basic::System.Windows.Markup.IComponentConnector.Connect

} // end of class AspenTech.AspenPlus.MMForms.Blocks.ACMModel.MMACMModel_SolverOptions_NSLBas_Basic


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file src/orig.ildasm.res
