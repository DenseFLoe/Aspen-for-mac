#!/usr/bin/env python3
"""Compile the editable C# into an ordinary public-signed comparison DLL."""
import argparse
import os
from pathlib import Path
import subprocess

PACKAGE = Path(__file__).resolve().parent
ASSEMBLY = "InfragisticsWPF.Persistence.dll"
FRAMEWORK = (
    "mscorlib.dll",
    "PresentationCore.dll",
    "PresentationFramework.dll",
    "System.Core.dll",
    "System.dll",
    "System.Xaml.dll",
    "System.Xml.dll",
    "WindowsBase.dll",
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csc", type=Path, required=True, help="Path to Roslyn csc.exe")
    parser.add_argument("--framework", type=Path, required=True, help=".NET Framework 4.0 reference directory")
    parser.add_argument("--infragistics", type=Path, required=True, help="Path to InfragisticsWPF.dll 21.2.20212.9")
    parser.add_argument("--out", type=Path, required=True, help="Directory for the compiler output")
    args = parser.parse_args()
    output_dir = args.out.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    output = output_dir / ASSEMBLY
    if output.exists():
        parser.error(f"Use a fresh output directory. Existing file: {output}")

    csc = args.csc.resolve(strict=True)
    references = [(args.framework / filename).resolve(strict=True) for filename in FRAMEWORK]
    references.append(args.infragistics.resolve(strict=True))
    resources = PACKAGE / "resources"
    key = PACKAGE / "build" / "assembly-public-key.snk"
    source = PACKAGE / f"{ASSEMBLY}.cs"
    argv = [
        str(csc), "/nologo", "/noconfig", "/utf8output", "/nostdlib+", "/langversion:5",
        "/optimize+", "/target:library", "/baseaddress:0x10000000", "/filealign:512",
        "/subsystemversion:4.00", "/debug-", "/deterministic+", "/publicsign+",
        f"/out:{output}", f"/win32res:{resources / 'original.res'}", f"/keyfile:{key}",
        f"/resource:{resources / 'resource-0.bin'},Infragistics.Persistence.strings.resources,public",
    ]
    argv.extend(f"/reference:{path}" for path in references)
    argv.append(str(source))
    env = dict(os.environ, TEMP=str(output_dir), TMP=str(output_dir))
    subprocess.run(argv, cwd=output_dir, env=env, check=True)
    print(output)


if __name__ == "__main__":
    main()
