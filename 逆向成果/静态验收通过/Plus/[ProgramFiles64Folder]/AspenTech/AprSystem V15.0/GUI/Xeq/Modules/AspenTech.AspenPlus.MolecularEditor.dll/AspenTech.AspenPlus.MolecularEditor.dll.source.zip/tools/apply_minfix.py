"""Apply the minimal semantic-equivalent decompiler fixes for the source-fix items.

Usage: apply_minfix.py <sha8>
Each rule is applied to every editable/*.cs under <work>/<sha8>/src and the number
of replacements is reported; a rule expected but not found is an error.
"""
import sys
from pathlib import Path

WORK = Path(__file__).resolve().parent.parent


def replace_once(text, old, new, count=1, required=True):
    hits = text.count(old)
    if hits != count:
        if required and hits == 0:
            raise SystemExit("pattern not found: %r" % old[:70])
        return text, 0
    return text.replace(old, new), hits


def fix_cxs(text):
    at = text.index("private static IEnumerable<string> GetInstalledAspenPlusVersions()")
    end = text.find("\n\t\tprivate ", at + 10)
    if end < 0:
        raise SystemExit("method end not found")
    head, body, tail = text[:at], text[at:end], text[end:]
    body, n1 = replace_once(body, "string[] subKeyNames = registryKey2.GetSubKeyNames();",
                            "string[] subKeyNames2 = registryKey2.GetSubKeyNames();")
    body, n2 = replace_once(body, "foreach (string text in subKeyNames)",
                            "foreach (string text in subKeyNames2)")
    return head + body + tail, n1 + n2


def fix_acm(text):
    old = "catch (object obj) when (obj is Exception && num3 != 0 && num == 0)"
    new = "catch (Exception obj) when (obj is Exception && num3 != 0 && num == 0)"
    return replace_once(text, old, new)


def fix_hyextn(text):
    old = "catch (object obj) when (obj is Exception && num2 != 0 && num == 0)"
    new = "catch (Exception obj) when (obj is Exception && num2 != 0 && num == 0)"
    return replace_once(text, old, new)


def fix_distl(text):
    total = 0
    for old, new in (
        ("\t\t\tEnteredDataPaths = { \"@UENTCVG1\" },\n\t\t\tEnteredDataPaths = { \"@UENTCVG2\" },\n"
         "\t\t\tEnteredDataPaths = { \"@UENTCVG3\" }",
         "\t\t\tEnteredDataPaths = { \"@UENTCVG1\", \"@UENTCVG2\", \"@UENTCVG3\" }"),
        ("\t\t\tAccessibleDataPaths = { \"@COND_DUTY\" },\n\t\t\tAccessibleDataPaths = { \"@FEED_TRAY_T\" },\n"
         "\t\t\tAccessibleDataPaths = { \"@REB_DUTY\" }",
         "\t\t\tAccessibleDataPaths = { \"@COND_DUTY\", \"@FEED_TRAY_T\", \"@REB_DUTY\" }"),
    ):
        text, n = replace_once(text, old, new)
        total += n
    return text, total


RULES = {"1855bb76": fix_cxs, "556c2495": fix_cxs, "8e5089ca": fix_cxs,
         "a5367a81": fix_cxs, "e1796121": fix_cxs,
         "8fa9d484": fix_acm, "0e63c25e": fix_hyextn,
         "2cc0e466": fix_distl}


def main(sha8):
    rule = RULES[sha8]
    changed = 0
    for p in sorted((WORK / sha8 / "src" / "editable").glob("*.cs")):
        text = p.read_text(encoding="utf-8-sig")
        new, n = rule(text)
        if n:
            p.write_text(new, encoding="utf-8")
        print(sha8, p.name, "replacements", n)
        changed += n
    if not changed:
        raise SystemExit("no replacement applied")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
