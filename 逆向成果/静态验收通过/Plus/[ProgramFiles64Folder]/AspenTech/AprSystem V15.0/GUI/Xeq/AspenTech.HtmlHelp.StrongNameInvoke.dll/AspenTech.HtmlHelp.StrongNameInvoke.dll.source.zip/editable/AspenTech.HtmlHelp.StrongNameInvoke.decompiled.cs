using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using AspenTech.HtmlHelp.StrongNameInvoke.Classes;
using AspenTech.HtmlHelp.StrongNameInvoke.Util;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("2023.15.0.2")]
[assembly: AssemblyTitle("AspenTech.HtmlHelp.StrongNameInvoke")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, INC.")]
[assembly: AssemblyProduct("AspenTech.HtmlHelp.StrongNameInvoke")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2023")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("f00a246f-7e87-4cce-a2ff-2f0f147b8af7")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("2023.15.0.2")]
namespace AspenTech.HtmlHelp.StrongNameInvoke
{
	public class HtmlHelpStrongNameInvoker
	{
		private static string htmlhelpManProgId;

		private static string HtmlHelpInit;

		private static string HtmlHelpInit2;

		private static string HtmlHelpInit3;

		private static string HtmlHelpDisplayTopic;

		private static string HtmlHelpClose;

		private static string SetVisible;

		private static string UseWinFormsBrowser;

		private static string UseAspenTechStdIcon;

		private static string CloseOpenedHelpWindow;

		private static Type htmlhelpManType;

		private static object htmlhelpManObj;

		static HtmlHelpStrongNameInvoker()
		{
			htmlhelpManProgId = "HtmlHelpLauncher.6";
			HtmlHelpInit = "HtmlHelpInit";
			HtmlHelpInit2 = "HtmlHelpInit2";
			HtmlHelpInit3 = "HtmlHelpInit3";
			HtmlHelpDisplayTopic = "HtmlHelpDisplayTopic";
			HtmlHelpClose = "HtmlHelpClose";
			SetVisible = "SetVisible";
			UseWinFormsBrowser = "UseWinFormsBrowser";
			UseAspenTechStdIcon = "UseAspenTechStdIcon";
			CloseOpenedHelpWindow = "CloseOpenedHelpWindow";
			htmlhelpManType = Type.GetTypeFromProgID(htmlhelpManProgId);
			if (htmlhelpManType != null)
			{
				try
				{
					htmlhelpManObj = Activator.CreateInstance(htmlhelpManType);
				}
				catch (Exception ex)
				{
					UtilError.WriteToEventLog(ex.Message, typeof(HtmlHelpStrongNameInvoker).Name, MethodBase.GetCurrentMethod().Name);
					Console.WriteLine(ex.Message);
					UtilError.WriteToEventLog(ex.Message, typeof(HtmlHelpStrongNameInvoker).Name, MethodBase.GetCurrentMethod().Name);
				}
			}
		}

		public void HtmlHelpInitWrap(string strProduct, string strExtVersion, string strInVersion, string strLandingPage, string strProdDisplayName)
		{
			UtilError.WriteToEventLog(MethodBase.GetCurrentMethod().Name, typeof(HtmlHelpStrongNameInvoker).Name, MethodBase.GetCurrentMethod().Name);
			if (htmlhelpManObj == null)
			{
				return;
			}
			object[] args = new object[5];
			args[0] = strProduct;
			args[1] = strExtVersion;
			args[2] = strInVersion;
			args[3] = strLandingPage;
			args[4] = strProdDisplayName;
			htmlhelpManType.InvokeMember(HtmlHelpInit, BindingFlags.InvokeMethod, null, htmlhelpManObj, args);
		}

		public void HtmlHelpInitWrap(string strProduct, string strExtVersion, string strInVersion, string strLandingPage, string strProdDisplayName, string strHelpExtractApp, bool bNoSelfExtract)
		{
			if (htmlhelpManObj == null)
			{
				return;
			}
			object[] args = new object[7];
			args[0] = strProduct;
			args[1] = strExtVersion;
			args[2] = strInVersion;
			args[3] = strLandingPage;
			args[4] = strProdDisplayName;
			args[5] = strHelpExtractApp;
			args[6] = bNoSelfExtract;
			htmlhelpManType.InvokeMember(HtmlHelpInit2, BindingFlags.InvokeMethod, null, htmlhelpManObj, args);
		}

		public void HtmlHelpInitWrapDisplay(string strProduct, string strExtVersion, string strInVersion, string strLandingPage, string strProdDisplayName, string strHelpExtractApp, bool bNoSelfExtract, bool displayMoreThanOnce)
		{
			if (htmlhelpManObj == null)
			{
				return;
			}
			object[] args = new object[8];
			args[0] = strProduct;
			args[1] = strExtVersion;
			args[2] = strInVersion;
			args[3] = strLandingPage;
			args[4] = strProdDisplayName;
			args[5] = strHelpExtractApp;
			args[6] = bNoSelfExtract;
			args[7] = displayMoreThanOnce;
			htmlhelpManType.InvokeMember(HtmlHelpInit3, BindingFlags.InvokeMethod, null, htmlhelpManObj, args);
		}

		public void HtmlHelpDisplayTopicWrap(string strHelpTopicUrl)
		{
			if (htmlhelpManObj == null)
			{
				return;
			}
			object[] args = new object[1];
			args[0] = strHelpTopicUrl;
			try
			{
				htmlhelpManType.InvokeMember(HtmlHelpDisplayTopic, BindingFlags.InvokeMethod, null, htmlhelpManObj, args);
			}
			catch (Exception ex)
			{
				UtilError.WriteToEventLog(ex.Message, typeof(HtmlHelpStrongNameInvoker).Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		public void HtmlHelpCloseWrap()
		{
			if (htmlhelpManObj == null)
			{
				return;
			}
			try
			{
				htmlhelpManType.InvokeMember(HtmlHelpClose, BindingFlags.InvokeMethod, null, htmlhelpManObj, null);
			}
			catch (Exception ex)
			{
				UtilError.WriteToEventLog(ex.Message, typeof(HtmlHelpStrongNameInvoker).Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		public void SetVisibleWrap(bool visible)
		{
			if (htmlhelpManObj == null)
			{
				return;
			}
			object[] args = new object[1];
			args[0] = visible;
			try
			{
				htmlhelpManType.InvokeMember(SetVisible, BindingFlags.InvokeMethod, null, htmlhelpManObj, args);
			}
			catch (Exception ex)
			{
				UtilError.WriteToEventLog(ex.Message, typeof(HtmlHelpStrongNameInvoker).Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		public void UseWinFormsBrowserWrap(bool useBrowser)
		{
			if (htmlhelpManObj == null)
			{
				return;
			}
			object[] args = new object[1];
			args[0] = useBrowser;
			try
			{
				htmlhelpManType.InvokeMember(UseWinFormsBrowser, BindingFlags.InvokeMethod, null, htmlhelpManObj, args);
			}
			catch (Exception ex)
			{
				UtilError.WriteToEventLog(ex.Message, typeof(HtmlHelpStrongNameInvoker).Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		public void UseAspenTechStdIconWrap(bool useATStdIcon)
		{
			if (htmlhelpManObj == null)
			{
				return;
			}
			object[] args = new object[1];
			args[0] = useATStdIcon;
			try
			{
				htmlhelpManType.InvokeMember(UseAspenTechStdIcon, BindingFlags.InvokeMethod, null, htmlhelpManObj, args);
			}
			catch (Exception ex)
			{
				UtilError.WriteToEventLog(ex.Message, typeof(HtmlHelpStrongNameInvoker).Name, MethodBase.GetCurrentMethod().Name);
			}
		}

		public void CloseOpenedHelpWindowWrap()
		{
			if (htmlhelpManObj == null)
			{
				return;
			}
			try
			{
				htmlhelpManType.InvokeMember(CloseOpenedHelpWindow, BindingFlags.InvokeMethod, null, htmlhelpManObj, null);
			}
			catch (Exception ex)
			{
				UtilError.WriteToEventLog(ex.Message, typeof(HtmlHelpStrongNameInvoker).Name, MethodBase.GetCurrentMethod().Name);
			}
		}
	}
}
namespace AspenTech.HtmlHelp.StrongNameInvoke.Util
{
	internal static class Global
	{
		public static string nameApp = "AspenTech HtmlHelp";

		internal static string GetLogFilename()
		{
			return Path.Combine(Path.GetTempPath(), nameApp + DateTime.Now.ToString("MM-dd-yyyy HH-mm-ss") + ".log");
		}
	}
	internal static class UtilError
	{
		private static LogWriter logWritter;

		public static void WriteToEventLog(string message, string className, string method)
		{
			try
			{
				if (logWritter == null)
				{
					logWritter = new LogWriter();
				}
				logWritter.WriteToLog(message, className, method);
			}
			catch (Exception)
			{
			}
		}
	}
}
namespace AspenTech.HtmlHelp.StrongNameInvoke.Classes
{
	internal interface ILogWriter
	{
		void WriteToLog(string message, string className, string method);
	}
	internal class LogWriter : ILogWriter
	{
		private string _fileName = Global.GetLogFilename();

		public string FileName
		{
			get
			{
				return _fileName;
			}
			set
			{
				_fileName = value;
			}
		}

		public void WriteToLog(string message, string className, string method)
		{
			DateTime.Now.ToString("HH-mm-ss");
			try
			{
				using StreamWriter streamWriter = File.AppendText(_fileName);
				streamWriter.Write("\r\nLog Entry : ");
				streamWriter.WriteLine(DateTime.Now.ToLongTimeString() + " " + DateTime.Now.ToLongDateString());
				streamWriter.WriteLine(className + " " + method + " :");
				streamWriter.WriteLine("  :" + message);
				streamWriter.WriteLine("-------------------------------");
			}
			catch (Exception ex)
			{
				ex.ToString();
			}
		}
	}
}
