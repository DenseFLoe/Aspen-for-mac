using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/visualisation/commonimages", "AspenTech.Visualisation.CommonImages")]
[assembly: XmlnsPrefix("http://schemas.aspentech.com/xaml/presentation/visualisation/commonimages", "atImages")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyCompany("AspenTech Inc.")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyDescription("Common images used for AspenTech applications")]
[assembly: AssemblyFileVersion("31.0.0.5")]
[assembly: AssemblyInformationalVersion("V14.0")]
[assembly: AssemblyProduct("Visualisation.Controls")]
[assembly: AssemblyTitle("AspenTech.Visualisation.CommonImages.Wpf")]
[assembly: AssemblyVersion("31.0.0.5")]
namespace AspenTech.Visualisation.CommonImages;

public class CommonImages
{
	private static CommonImages _staticInstance;

	private Dictionary<string, ImageSource> _imageCache = new Dictionary<string, ImageSource>();

	public static CommonImages Instance
	{
		get
		{
			if (_staticInstance == null)
			{
				_staticInstance = new CommonImages();
			}
			return _staticInstance;
		}
	}

	public CommonImages()
	{
	}

	public ImageSource GetImageSource(string imageName)
	{
		ImageSource value = null;
		string text = Path.GetExtension(imageName);
		if (string.IsNullOrEmpty(text))
		{
			text = (imageName.EndsWith("_Icon", StringComparison.OrdinalIgnoreCase) ? ".ico" : ".png");
			imageName += text;
		}
		if (!_imageCache.TryGetValue(imageName, out value))
		{
			try
			{
				string fullName = Assembly.GetExecutingAssembly().FullName;
				string uriString = "pack://application:,,,/" + fullName + ";component/images/" + imageName;
				if (text.Equals(".ico", StringComparison.OrdinalIgnoreCase))
				{
					value = BitmapFrame.Create(new Uri(uriString, UriKind.Absolute));
				}
				else
				{
					BitmapImage bitmapImage = new BitmapImage();
					bitmapImage.BeginInit();
					bitmapImage.UriSource = new Uri(uriString, UriKind.Absolute);
					bitmapImage.EndInit();
					if (bitmapImage.CanFreeze)
					{
						bitmapImage.Freeze();
					}
					value = bitmapImage;
				}
			}
			catch (Exception)
			{
			}
			if (value != null)
			{
				_imageCache[imageName] = value;
			}
		}
		return value;
	}

	public ImageSource Advisor_App_Icon => GetImageSource("Advisor_App.ico");

	public ImageSource AspenDiagnosticsTool_App_Icon => GetImageSource("AspenDiagnosticsTool_App.ico");

	public ImageSource AspenPetroleumScheduler_App_Icon => GetImageSource("AspenPetroleumScheduler_App.ico");

	public ImageSource IntegrationDesigner_App_Icon => GetImageSource("IntegrationDesigner_App.ico");

	public ImageSource MBO_App_Icon => GetImageSource("MBO_App.ico");

	public ImageSource SCM_App_Icon => GetImageSource("SCM_App.ico");

	public ImageSource SLMCommute_App_Icon => GetImageSource("SLMCommute_App.ico");

	public ImageSource SLMConfigWizard_App_Icon => GetImageSource("SLMConfigWizard_App.ico");

	public ImageSource SLMLicenseProfiler_App_Icon => GetImageSource("SLMLicenseProfiler_App.ico");

	public ImageSource TagRenameUtility_App_Icon => GetImageSource("TagRenameUtility_App.ico");

	public ImageSource AcceptChanges_32 => GetImageSource("AcceptChanges_32.png");

	public ImageSource Accept_16 => GetImageSource("Accept_16.png");

	public ImageSource Acol_16 => GetImageSource("Acol_16.png");

	public ImageSource Acol_32 => GetImageSource("Acol_32.png");

	public ImageSource ActionLogs_32 => GetImageSource("ActionLogs_32.png");

	public ImageSource ActivityListOpenFolder_16 => GetImageSource("ActivityListOpenFolder_16.png");

	public ImageSource ActivityList_16 => GetImageSource("ActivityList_16.png");

	public ImageSource AddApplication_16 => GetImageSource("AddApplication_16.png");

	public ImageSource AddApplication_32 => GetImageSource("AddApplication_32.png");

	public ImageSource AddCurve_32 => GetImageSource("AddCurve_32.png");

	public ImageSource AddIntermediate_16 => GetImageSource("AddIntermediate_16.png");

	public ImageSource AdditionalTools_32 => GetImageSource("AdditionalTools_32.png");

	public ImageSource AddSavedViews_16 => GetImageSource("AddSavedViews_16.png");

	public ImageSource Advisor_App => GetImageSource("Advisor_App.png");

	public ImageSource Aggregation_32 => GetImageSource("Aggregation_32.png");

	public ImageSource AgitatorAnchor_16 => GetImageSource("AgitatorAnchor_16.png");

	public ImageSource AgitatorHelicalRibbon_16 => GetImageSource("AgitatorHelicalRibbon_16.png");

	public ImageSource AgitatorPaddle_16 => GetImageSource("AgitatorPaddle_16.png");

	public ImageSource AgitatorPropellor_16 => GetImageSource("AgitatorPropellor_16.png");

	public ImageSource AgitatorTurbine_16 => GetImageSource("AgitatorTurbine_16.png");

	public ImageSource AirDry_16 => GetImageSource("AirDry_16.png");

	public ImageSource Aliases_16 => GetImageSource("Aliases_16.png");

	public ImageSource Alias_16 => GetImageSource("Alias_16.png");

	public ImageSource AlignCenterBottom_16 => GetImageSource("AlignCenterBottom_16.png");

	public ImageSource AlignCenterMiddle_16 => GetImageSource("AlignCenterMiddle_16.png");

	public ImageSource AlignCenterTop_16 => GetImageSource("AlignCenterTop_16.png");

	public ImageSource AlignCenter_16 => GetImageSource("AlignCenter_16.png");

	public ImageSource AlignChildrenCenter_16 => GetImageSource("AlignChildrenCenter_16.png");

	public ImageSource AlignLeftBottom_16 => GetImageSource("AlignLeftBottom_16.png");

	public ImageSource AlignLeftMiddle_16 => GetImageSource("AlignLeftMiddle_16.png");

	public ImageSource AlignLeftTop_16 => GetImageSource("AlignLeftTop_16.png");

	public ImageSource AlignLeft_16 => GetImageSource("AlignLeft_16.png");

	public ImageSource AlignObjectBottom_16 => GetImageSource("AlignObjectBottom_16.png");

	public ImageSource AlignObjectCenter_16 => GetImageSource("AlignObjectCenter_16.png");

	public ImageSource AlignObjectLeft_16 => GetImageSource("AlignObjectLeft_16.png");

	public ImageSource AlignObjectMiddle_16 => GetImageSource("AlignObjectMiddle_16.png");

	public ImageSource AlignObjectRight_16 => GetImageSource("AlignObjectRight_16.png");

	public ImageSource AlignObjectsLeft_32 => GetImageSource("AlignObjectsLeft_32.png");

	public ImageSource AlignObjectTop_16 => GetImageSource("AlignObjectTop_16.png");

	public ImageSource AlignParentCenter_16 => GetImageSource("AlignParentCenter_16.png");

	public ImageSource AlignRightBottom_16 => GetImageSource("AlignRightBottom_16.png");

	public ImageSource AlignRightMiddle_16 => GetImageSource("AlignRightMiddle_16.png");

	public ImageSource AlignRightTop_16 => GetImageSource("AlignRightTop_16.png");

	public ImageSource AlignRight_16 => GetImageSource("AlignRight_16.png");

	public ImageSource Align_32 => GetImageSource("Align_32.png");

	public ImageSource Alkane_32 => GetImageSource("Alkane_32.png");

	public ImageSource Analytics_32 => GetImageSource("Analytics_32.png");

	public ImageSource Aple_16 => GetImageSource("Aple_16.png");

	public ImageSource Aple_32 => GetImageSource("Aple_32.png");

	public ImageSource ApplicationExit_32 => GetImageSource("ApplicationExit_32.png");

	public ImageSource ApplyChanges_32 => GetImageSource("ApplyChanges_32.png");

	public ImageSource APSReportingTool_16 => GetImageSource("APSReportingTool_16.png");

	public ImageSource APSReportingTool_32 => GetImageSource("APSReportingTool_32.png");

	public ImageSource AreaBatch_16 => GetImageSource("AreaBatch_16.png");

	public ImageSource Areas_16 => GetImageSource("Areas_16.png");

	public ImageSource Area_16 => GetImageSource("Area_16.png");

	public ImageSource ArrangeAll_16 => GetImageSource("ArrangeAll_16.png");

	public ImageSource Arrow_16 => GetImageSource("Arrow_16.png");

	public ImageSource AskCommunityDiscuss_32 => GetImageSource("AskCommunityDiscuss_32.png");

	public ImageSource AskExpertsLiveChat_32 => GetImageSource("AskExpertsLiveChat_32.png");

	public ImageSource AskExpertsSendToSupport_32 => GetImageSource("AskExpertsSendToSupport_32.png");

	public ImageSource AspenDiagnosticsTool_App => GetImageSource("AspenDiagnosticsTool_App.png");

	public ImageSource AspenLeafOfficeButton_32 => GetImageSource("AspenLeafOfficeButton_32.png");

	public ImageSource AspenPetroleumScheduler_App => GetImageSource("AspenPetroleumScheduler_App.png");

	public ImageSource AspenPlusSamples_32 => GetImageSource("AspenPlusSamples_32.png");

	public ImageSource AspenPlus_48 => GetImageSource("AspenPlus_48.png");

	public ImageSource AspenPropertiesBackup_16 => GetImageSource("AspenPropertiesBackup_16.png");

	public ImageSource AspenPropertiesBackup_32 => GetImageSource("AspenPropertiesBackup_32.png");

	public ImageSource AspenPropertiesCompoundFile_16 => GetImageSource("AspenPropertiesCompoundFile_16.png");

	public ImageSource AspenPropertiesCompoundFile_32 => GetImageSource("AspenPropertiesCompoundFile_32.png");

	public ImageSource AspenPropertiesDoc_16 => GetImageSource("AspenPropertiesDoc_16.png");

	public ImageSource AspenPropertiesDoc_32 => GetImageSource("AspenPropertiesDoc_32.png");

	public ImageSource AspenPropertiesExamples_32 => GetImageSource("AspenPropertiesExamples_32.png");

	public ImageSource AspenPropertiesHomePage_32 => GetImageSource("AspenPropertiesHomePage_32.png");

	public ImageSource AspenPropertiesInputFile_16 => GetImageSource("AspenPropertiesInputFile_16.png");

	public ImageSource AspenPropertiesInputFile_32 => GetImageSource("AspenPropertiesInputFile_32.png");

	public ImageSource AspenPropertiesReportFile_16 => GetImageSource("AspenPropertiesReportFile_16.png");

	public ImageSource AspenPropertiesReportFile_32 => GetImageSource("AspenPropertiesReportFile_32.png");

	public ImageSource AspenPropertiesTemplate_16 => GetImageSource("AspenPropertiesTemplate_16.png");

	public ImageSource AspenPropertiesTemplate_32 => GetImageSource("AspenPropertiesTemplate_32.png");

	public ImageSource AspenPropertiesWhatsNew_16 => GetImageSource("AspenPropertiesWhatsNew_16.png");

	public ImageSource AspenPropertiesWhatsNew_32 => GetImageSource("AspenPropertiesWhatsNew_32.png");

	public ImageSource AssayManipulator_24 => GetImageSource("AssayManipulator_24.png");

	public ImageSource AssignEquipment_16 => GetImageSource("AssignEquipment_16.png");

	public ImageSource AssignMasterRecipe_16 => GetImageSource("AssignMasterRecipe_16.png");

	public ImageSource AssignParameter_16 => GetImageSource("AssignParameter_16.png");

	public ImageSource AssignParmSecurity_16 => GetImageSource("AssignParmSecurity_16.png");

	public ImageSource AssignStrategy_16 => GetImageSource("AssignStrategy_16.png");

	public ImageSource AssignTemplate_16 => GetImageSource("AssignTemplate_16.png");

	public ImageSource AttachAuto1_16 => GetImageSource("AttachAuto1_16.png");

	public ImageSource AttachAuto4_16 => GetImageSource("AttachAuto4_16.png");

	public ImageSource AttachAuto5_16 => GetImageSource("AttachAuto5_16.png");

	public ImageSource Attach_16 => GetImageSource("Attach_16.png");

	public ImageSource AutoArrange_16 => GetImageSource("AutoArrange_16.png");

	public ImageSource Autoclave_16 => GetImageSource("Autoclave_16.png");

	public ImageSource AutoRunOffNew_16 => GetImageSource("AutoRunOffNew_16.png");

	public ImageSource AutoRunOff_16 => GetImageSource("AutoRunOff_16.png");

	public ImageSource AutoRunOnNew_16 => GetImageSource("AutoRunOnNew_16.png");

	public ImageSource AutoRunOn_16 => GetImageSource("AutoRunOn_16.png");

	public ImageSource AuxiliaryInfo_16 => GetImageSource("AuxiliaryInfo_16.png");

	public ImageSource Axes_32 => GetImageSource("Axes_32.png");

	public ImageSource AzeotropeSearch_16 => GetImageSource("AzeotropeSearch_16.png");

	public ImageSource Azeotrope_16 => GetImageSource("Azeotrope_16.png");

	public ImageSource Azeo_16 => GetImageSource("Azeo_16.png");

	public ImageSource Back_16 => GetImageSource("Back_16.png");

	public ImageSource Balance_16 => GetImageSource("Balance_16.png");

	public ImageSource Batch21Administrator_16 => GetImageSource("Batch21Administrator_16.png");

	public ImageSource Batch21Administrator_32 => GetImageSource("Batch21Administrator_32.png");

	public ImageSource BatchDefinition_16 => GetImageSource("BatchDefinition_16.png");

	public ImageSource BatchDefinition_32 => GetImageSource("BatchDefinition_32.png");

	public ImageSource BatchDetailDisplay_16 => GetImageSource("BatchDetailDisplay_16.png");

	public ImageSource BatchDetailDisplay_32 => GetImageSource("BatchDetailDisplay_32.png");

	public ImageSource Batches_16 => GetImageSource("Batches_16.png");

	public ImageSource BatchListFile_16 => GetImageSource("BatchListFile_16.png");

	public ImageSource BatchNew_16 => GetImageSource("BatchNew_16.png");

	public ImageSource BatchQueryFile_16 => GetImageSource("BatchQueryFile_16.png");

	public ImageSource Batch_16 => GetImageSource("Batch_16.png");

	public ImageSource BCUAdministrator_16 => GetImageSource("BCUAdministrator_16.png");

	public ImageSource BCUAdministrator_32 => GetImageSource("BCUAdministrator_32.png");

	public ImageSource BCUConfigDoc_16 => GetImageSource("BCUConfigDoc_16.png");

	public ImageSource BCUServerManager_16 => GetImageSource("BCUServerManager_16.png");

	public ImageSource BCUServerManager_32 => GetImageSource("BCUServerManager_32.png");

	public ImageSource BCUServer_16 => GetImageSource("BCUServer_16.png");

	public ImageSource BCUServer_32 => GetImageSource("BCUServer_32.png");

	public ImageSource BeadMill_16 => GetImageSource("BeadMill_16.png");

	public ImageSource BenzeneRingEdit_16 => GetImageSource("BenzeneRingEdit_16.png");

	public ImageSource BenzeneRing_16 => GetImageSource("BenzeneRing_16.png");

	public ImageSource BenzeneRing_32 => GetImageSource("BenzeneRing_32.png");

	public ImageSource BillOfMaterials_32 => GetImageSource("BillOfMaterials_32.png");

	public ImageSource BlueFlag_16 => GetImageSource("BlueFlag_16.png");

	public ImageSource Bold_16 => GetImageSource("Bold_16.png");

	public ImageSource BreakpointInsertRemove_16 => GetImageSource("BreakpointInsertRemove_16.png");

	public ImageSource BreakpointRemoveAll_16 => GetImageSource("BreakpointRemoveAll_16.png");

	public ImageSource Break_16 => GetImageSource("Break_16.png");

	public ImageSource BringToFront_32 => GetImageSource("BringToFront_32.png");

	public ImageSource Browser_16 => GetImageSource("Browser_16.png");

	public ImageSource Bullets_16 => GetImageSource("Bullets_16.png");

	public ImageSource CalculationOpenFolder_16 => GetImageSource("CalculationOpenFolder_16.png");

	public ImageSource Calculation_16 => GetImageSource("Calculation_16.png");

	public ImageSource Calculator_16 => GetImageSource("Calculator_16.png");

	public ImageSource CalcWizard_16 => GetImageSource("CalcWizard_16.png");

	public ImageSource Calc_16 => GetImageSource("Calc_16.png");

	public ImageSource CalendarFilter_32 => GetImageSource("CalendarFilter_32.png");

	public ImageSource Calendar_32 => GetImageSource("Calendar_32.png");

	public ImageSource CancelChanges_32 => GetImageSource("CancelChanges_32.png");

	public ImageSource CancelledByUser_11 => GetImageSource("CancelledByUser_11.png");

	public ImageSource CancelMessages_16 => GetImageSource("CancelMessages_16.png");

	public ImageSource CapeOpenExport_32 => GetImageSource("CapeOpenExport_32.png");

	public ImageSource CascadeWindows_16 => GetImageSource("CascadeWindows_16.png");

	public ImageSource CaseInformationInspect_32 => GetImageSource("CaseInformationInspect_32.png");

	public ImageSource CaseInformation_32 => GetImageSource("CaseInformation_32.png");

	public ImageSource CaseLanguage_16 => GetImageSource("CaseLanguage_16.png");

	public ImageSource CaseLanguage_32 => GetImageSource("CaseLanguage_32.png");

	public ImageSource CaseOptions_32 => GetImageSource("CaseOptions_32.png");

	public ImageSource CatalogSearch_32 => GetImageSource("CatalogSearch_32.png");

	public ImageSource Catalog_32 => GetImageSource("Catalog_32.png");

	public ImageSource CatalyticReformer_24 => GetImageSource("CatalyticReformer_24.png");

	public ImageSource Category_11 => GetImageSource("Category_11.png");

	public ImageSource Category_16 => GetImageSource("Category_16.png");

	public ImageSource Caution_16 => GetImageSource("Caution_16.png");

	public ImageSource CellDisrupt_16 => GetImageSource("CellDisrupt_16.png");

	public ImageSource CellFactory_16 => GetImageSource("CellFactory_16.png");

	public ImageSource Cell_16 => GetImageSource("Cell_16.png");

	public ImageSource Cell_32 => GetImageSource("Cell_32.png");

	public ImageSource Center_24 => GetImageSource("Center_24.png");

	public ImageSource CentrifugeBySettling_16 => GetImageSource("CentrifugeBySettling_16.png");

	public ImageSource CentrifugeDecanter_16 => GetImageSource("CentrifugeDecanter_16.png");

	public ImageSource CentrifugeDiskStack_16 => GetImageSource("CentrifugeDiskStack_16.png");

	public ImageSource CentrifugeHorizontalBasket_16 => GetImageSource("CentrifugeHorizontalBasket_16.png");

	public ImageSource CentrifugeMultiChamberBowl_16 => GetImageSource("CentrifugeMultiChamberBowl_16.png");

	public ImageSource CentrifugeTubularBowl_16 => GetImageSource("CentrifugeTubularBowl_16.png");

	public ImageSource CentrifugeVerticalBasket_16 => GetImageSource("CentrifugeVerticalBasket_16.png");

	public ImageSource Centrifuge_16 => GetImageSource("Centrifuge_16.png");

	public ImageSource ChangeNodeDecision_16 => GetImageSource("ChangeNodeDecision_16.png");

	public ImageSource ChangeNodeDelay_16 => GetImageSource("ChangeNodeDelay_16.png");

	public ImageSource ChangeNodeDependency_16 => GetImageSource("ChangeNodeDependency_16.png");

	public ImageSource ChangeNodeManualOperation_16 => GetImageSource("ChangeNodeManualOperation_16.png");

	public ImageSource ChangeNodeOperation_16 => GetImageSource("ChangeNodeOperation_16.png");

	public ImageSource ChangeNodeOperatorRequest_16 => GetImageSource("ChangeNodeOperatorRequest_16.png");

	public ImageSource ChangeNodePreparation_16 => GetImageSource("ChangeNodePreparation_16.png");

	public ImageSource ChangeNodeRecipe_16 => GetImageSource("ChangeNodeRecipe_16.png");

	public ImageSource ChangeNodeTermination_16 => GetImageSource("ChangeNodeTermination_16.png");

	public ImageSource Changes_32 => GetImageSource("Changes_32.png");

	public ImageSource CharacteristicBinary_16 => GetImageSource("CharacteristicBinary_16.png");

	public ImageSource CharacteristicBrowser_16 => GetImageSource("CharacteristicBrowser_16.png");

	public ImageSource CharacteristicBrowser_32 => GetImageSource("CharacteristicBrowser_32.png");

	public ImageSource CharacteristicCharacter_16 => GetImageSource("CharacteristicCharacter_16.png");

	public ImageSource CharacteristicCompound_16 => GetImageSource("CharacteristicCompound_16.png");

	public ImageSource CharacteristicEdit_16 => GetImageSource("CharacteristicEdit_16.png");

	public ImageSource CharacteristicNew_16 => GetImageSource("CharacteristicNew_16.png");

	public ImageSource CharacteristicNumeric_16 => GetImageSource("CharacteristicNumeric_16.png");

	public ImageSource Characteristics_16 => GetImageSource("Characteristics_16.png");

	public ImageSource CharacteristicTime_16 => GetImageSource("CharacteristicTime_16.png");

	public ImageSource CharacteristicTime_32 => GetImageSource("CharacteristicTime_32.png");

	public ImageSource Characteristic_16 => GetImageSource("Characteristic_16.png");

	public ImageSource ChargeToAmount_16 => GetImageSource("ChargeToAmount_16.png");

	public ImageSource Charge_16 => GetImageSource("Charge_16.png");

	public ImageSource ChartArea_32 => GetImageSource("ChartArea_32.png");

	public ImageSource ChartAverageRange_32 => GetImageSource("ChartAverageRange_32.png");

	public ImageSource ChartAxisTitles_32 => GetImageSource("ChartAxisTitles_32.png");

	public ImageSource ChartAxis_32 => GetImageSource("ChartAxis_32.png");

	public ImageSource ChartColumn_32 => GetImageSource("ChartColumn_32.png");

	public ImageSource ChartDataLabels_32 => GetImageSource("ChartDataLabels_32.png");

	public ImageSource ChartDataTable_32 => GetImageSource("ChartDataTable_32.png");

	public ImageSource ChartDoughnut_32 => GetImageSource("ChartDoughnut_32.png");

	public ImageSource ChartErrorBars_32 => GetImageSource("ChartErrorBars_32.png");

	public ImageSource ChartFloor_32 => GetImageSource("ChartFloor_32.png");

	public ImageSource ChartGridLines_32 => GetImageSource("ChartGridLines_32.png");

	public ImageSource ChartLegend_32 => GetImageSource("ChartLegend_32.png");

	public ImageSource ChartLines_32 => GetImageSource("ChartLines_32.png");

	public ImageSource ChartLine_32 => GetImageSource("ChartLine_32.png");

	public ImageSource ChartPie_32 => GetImageSource("ChartPie_32.png");

	public ImageSource ChartPlotArea_32 => GetImageSource("ChartPlotArea_32.png");

	public ImageSource ChartSaveAs_32 => GetImageSource("ChartSaveAs_32.png");

	public ImageSource ChartScatter_32 => GetImageSource("ChartScatter_32.png");

	public ImageSource ChartSetFolder_16 => GetImageSource("ChartSetFolder_16.png");

	public ImageSource ChartShowGliderLine_16 => GetImageSource("ChartShowGliderLine_16.png");

	public ImageSource ChartShowGlider_16 => GetImageSource("ChartShowGlider_16.png");

	public ImageSource ChartStyle1_48 => GetImageSource("ChartStyle1_48.png");

	public ImageSource ChartStyle2_48 => GetImageSource("ChartStyle2_48.png");

	public ImageSource ChartStyle3_48 => GetImageSource("ChartStyle3_48.png");

	public ImageSource ChartTitle_32 => GetImageSource("ChartTitle_32.png");

	public ImageSource ChartTrendLine_32 => GetImageSource("ChartTrendLine_32.png");

	public ImageSource ChartUpDownBars_32 => GetImageSource("ChartUpDownBars_32.png");

	public ImageSource ChartWall_32 => GetImageSource("ChartWall_32.png");

	public ImageSource Chart_16 => GetImageSource("Chart_16.png");

	public ImageSource Chart_Bar_32 => GetImageSource("Chart_Bar_32.png");

	public ImageSource Chat_48 => GetImageSource("Chat_48.png");

	public ImageSource CheckboxSelected_16 => GetImageSource("CheckboxSelected_16.png");

	public ImageSource CheckboxUnselected_16 => GetImageSource("CheckboxUnselected_16.png");

	public ImageSource CheckResultsNew_16 => GetImageSource("CheckResultsNew_16.png");

	public ImageSource CheckResults_16 => GetImageSource("CheckResults_16.png");

	public ImageSource Check_16 => GetImageSource("Check_16.png");

	public ImageSource Check_32 => GetImageSource("Check_32.png");

	public ImageSource Check_48 => GetImageSource("Check_48.png");

	public ImageSource ChemicalDatabase_16 => GetImageSource("ChemicalDatabase_16.png");

	public ImageSource ChevronDown_16 => GetImageSource("ChevronDown_16.png");

	public ImageSource ChevronLeft_16 => GetImageSource("ChevronLeft_16.png");

	public ImageSource ChevronRight_16 => GetImageSource("ChevronRight_16.png");

	public ImageSource ChevronUp_16 => GetImageSource("ChevronUp_16.png");

	public ImageSource Child_16 => GetImageSource("Child_16.png");

	public ImageSource Classifier_16 => GetImageSource("Classifier_16.png");

	public ImageSource Classify_16 => GetImageSource("Classify_16.png");

	public ImageSource CleanInPlace_16 => GetImageSource("CleanInPlace_16.png");

	public ImageSource Clean_16 => GetImageSource("Clean_16.png");

	public ImageSource ClearComment_32 => GetImageSource("ClearComment_32.png");

	public ImageSource ClearControlPanel_16 => GetImageSource("ClearControlPanel_16.png");

	public ImageSource ClearSelections_16 => GetImageSource("ClearSelections_16.png");

	public ImageSource Clear_16 => GetImageSource("Clear_16.png");

	public ImageSource ClosedFolder_16 => GetImageSource("ClosedFolder_16.png");

	public ImageSource Close_32 => GetImageSource("Close_32.png");

	public ImageSource CO2_16 => GetImageSource("CO2_16.png");

	public ImageSource CO2_32 => GetImageSource("CO2_32.png");

	public ImageSource Coat_16 => GetImageSource("Coat_16.png");

	public ImageSource ColorKey_16 => GetImageSource("ColorKey_16.png");

	public ImageSource ColorPicker_32 => GetImageSource("ColorPicker_32.png");

	public ImageSource ColumnContinuousPacked_16 => GetImageSource("ColumnContinuousPacked_16.png");

	public ImageSource ColumnContinuousTray_16 => GetImageSource("ColumnContinuousTray_16.png");

	public ImageSource Column_16 => GetImageSource("Column_16.png");

	public ImageSource CommandNew_16 => GetImageSource("CommandNew_16.png");

	public ImageSource CommandPromptRun_32 => GetImageSource("CommandPromptRun_32.png");

	public ImageSource CommandPrompt_32 => GetImageSource("CommandPrompt_32.png");

	public ImageSource Command_16 => GetImageSource("Command_16.png");

	public ImageSource Comment_16 => GetImageSource("Comment_16.png");

	public ImageSource Comment_32 => GetImageSource("Comment_32.png");

	public ImageSource CompareScenarioes_32 => GetImageSource("CompareScenarioes_32.png");

	public ImageSource CompareScenariosv2_32 => GetImageSource("CompareScenariosv2_32.png");

	public ImageSource CompletedSuccessfully_11 => GetImageSource("CompletedSuccessfully_11.png");

	public ImageSource Components_16 => GetImageSource("Components_16.png");

	public ImageSource ComponentWizard_16 => GetImageSource("ComponentWizard_16.png");

	public ImageSource Compressor_16 => GetImageSource("Compressor_16.png");

	public ImageSource Computer_16 => GetImageSource("Computer_16.png");

	public ImageSource Concentrate_16 => GetImageSource("Concentrate_16.png");

	public ImageSource Condenser_16 => GetImageSource("Condenser_16.png");

	public ImageSource Connection_24 => GetImageSource("Connection_24.png");

	public ImageSource Constraints_24 => GetImageSource("Constraints_24.png");

	public ImageSource ControlNode_16 => GetImageSource("ControlNode_16.png");

	public ImageSource ControlOptions_32 => GetImageSource("ControlOptions_32.png");

	public ImageSource ControlPanel_16 => GetImageSource("ControlPanel_16.png");

	public ImageSource ControlPanel_32 => GetImageSource("ControlPanel_32.png");

	public ImageSource ControlRecipebyEquipment_16 => GetImageSource("ControlRecipebyEquipment_16.png");

	public ImageSource ControlRecipe_16 => GetImageSource("ControlRecipe_16.png");

	public ImageSource Convergence_16 => GetImageSource("Convergence_16.png");

	public ImageSource ConvertToTextRecipe_16 => GetImageSource("ConvertToTextRecipe_16.png");

	public ImageSource CoolingTower_16 => GetImageSource("CoolingTower_16.png");

	public ImageSource Cool_16 => GetImageSource("Cool_16.png");

	public ImageSource Copy_16 => GetImageSource("Copy_16.png");

	public ImageSource Copy_32 => GetImageSource("Copy_32.png");

	public ImageSource CostFactors_32 => GetImageSource("CostFactors_32.png");

	public ImageSource CostingDatabase_16 => GetImageSource("CostingDatabase_16.png");

	public ImageSource Costing_16 => GetImageSource("Costing_16.png");

	public ImageSource CostOptions_16 => GetImageSource("CostOptions_16.png");

	public ImageSource CreateSimulation_16 => GetImageSource("CreateSimulation_16.png");

	public ImageSource CREdit_16 => GetImageSource("CREdit_16.png");

	public ImageSource CROpenFolder_16 => GetImageSource("CROpenFolder_16.png");

	public ImageSource CrossReference_16 => GetImageSource("CrossReference_16.png");

	public ImageSource CrossReference_32 => GetImageSource("CrossReference_32.png");

	public ImageSource CrystallizeContinuous_16 => GetImageSource("CrystallizeContinuous_16.png");

	public ImageSource Crystallize_16 => GetImageSource("Crystallize_16.png");

	public ImageSource CurrentFlowSection_16 => GetImageSource("CurrentFlowSection_16.png");

	public ImageSource CustomEquipment_16 => GetImageSource("CustomEquipment_16.png");

	public ImageSource CustomerSupport_32 => GetImageSource("CustomerSupport_32.png");

	public ImageSource CustomPlot_32 => GetImageSource("CustomPlot_32.png");

	public ImageSource CustomUnits_16 => GetImageSource("CustomUnits_16.png");

	public ImageSource Custom_16 => GetImageSource("Custom_16.png");

	public ImageSource Custom_24 => GetImageSource("Custom_24.png");

	public ImageSource Cut_16 => GetImageSource("Cut_16.png");

	public ImageSource Cyclobutane_32 => GetImageSource("Cyclobutane_32.png");

	public ImageSource Cycloheptane_32 => GetImageSource("Cycloheptane_32.png");

	public ImageSource Cyclohexane_32 => GetImageSource("Cyclohexane_32.png");

	public ImageSource Cyclone_16 => GetImageSource("Cyclone_16.png");

	public ImageSource Cyclooctane_32 => GetImageSource("Cyclooctane_32.png");

	public ImageSource Cyclopentane_32 => GetImageSource("Cyclopentane_32.png");

	public ImageSource Cyclopropane_32 => GetImageSource("Cyclopropane_32.png");

	public ImageSource D86_16 => GetImageSource("D86_16.png");

	public ImageSource D86_32 => GetImageSource("D86_32.png");

	public ImageSource Database_16 => GetImageSource("Database_16.png");

	public ImageSource DataBrowser_32 => GetImageSource("DataBrowser_32.png");

	public ImageSource DataFitting_16 => GetImageSource("DataFitting_16.png");

	public ImageSource DataImport_32 => GetImageSource("DataImport_32.png");

	public ImageSource DataManagement_24 => GetImageSource("DataManagement_24.png");

	public ImageSource DataSheet_32 => GetImageSource("DataSheet_32.png");

	public ImageSource DataSources_16 => GetImageSource("DataSources_16.png");

	public ImageSource DataSource_16 => GetImageSource("DataSource_16.png");

	public ImageSource DateAndTime_16 => GetImageSource("DateAndTime_16.png");

	public ImageSource Date_16 => GetImageSource("Date_16.png");

	public ImageSource Date_32 => GetImageSource("Date_32.png");

	public ImageSource DeactivatedForm_16 => GetImageSource("DeactivatedForm_16.png");

	public ImageSource DecantContinuously_16 => GetImageSource("DecantContinuously_16.png");

	public ImageSource Decant_16 => GetImageSource("Decant_16.png");

	public ImageSource DecreaseHorizontalSpacing_16 => GetImageSource("DecreaseHorizontalSpacing_16.png");

	public ImageSource DecreaseIndent_16 => GetImageSource("DecreaseIndent_16.png");

	public ImageSource DecreaseVerticalSpacing_16 => GetImageSource("DecreaseVerticalSpacing_16.png");

	public ImageSource DecreaseWidth_16 => GetImageSource("DecreaseWidth_16.png");

	public ImageSource DefaultResource_16 => GetImageSource("DefaultResource_16.png");

	public ImageSource DeleteImage_16 => GetImageSource("DeleteImage_16.png");

	public ImageSource DeletePlan_16 => GetImageSource("DeletePlan_16.png");

	public ImageSource DeleteRouteSelection_16 => GetImageSource("DeleteRouteSelection_16.png");

	public ImageSource DeleteSavedView_16 => GetImageSource("DeleteSavedView_16.png");

	public ImageSource Delete_16 => GetImageSource("Delete_16.png");

	public ImageSource Delete_32 => GetImageSource("Delete_32.png");

	public ImageSource DemandProjection_16 => GetImageSource("DemandProjection_16.png");

	public ImageSource DemandSelection_16 => GetImageSource("DemandSelection_16.png");

	public ImageSource DeveloperModelLibraryAddCase_16 => GetImageSource("DeveloperModelLibraryAddCase_16.png");

	public ImageSource DeveloperModelLibraryAddLibrary_16 => GetImageSource("DeveloperModelLibraryAddLibrary_16.png");

	public ImageSource DeveloperModelLibraryAddSelected_16 => GetImageSource("DeveloperModelLibraryAddSelected_16.png");

	public ImageSource DeveloperModelLibraryEditIcons_16 => GetImageSource("DeveloperModelLibraryEditIcons_16.png");

	public ImageSource DeveloperModelLibraryManageLibraries_16 => GetImageSource("DeveloperModelLibraryManageLibraries_16.png");

	public ImageSource DeveloperModelLibraryPalletCategory_16 => GetImageSource("DeveloperModelLibraryPalletCategory_16.png");

	public ImageSource DeveloperSettingsOptions_16 => GetImageSource("DeveloperSettingsOptions_16.png");

	public ImageSource DeveloperSettingsVariableExplorer_16 => GetImageSource("DeveloperSettingsVariableExplorer_16.png");

	public ImageSource Diafilter_16 => GetImageSource("Diafilter_16.png");

	public ImageSource DimensionSets_16 => GetImageSource("DimensionSets_16.png");

	public ImageSource DisabledCheckboxSelected_16 => GetImageSource("DisabledCheckboxSelected_16.png");

	public ImageSource DisabledCheckboxUnselected_16 => GetImageSource("DisabledCheckboxUnselected_16.png");

	public ImageSource DisabledRadioSelected_16 => GetImageSource("DisabledRadioSelected_16.png");

	public ImageSource DisabledRadioUnselected_16 => GetImageSource("DisabledRadioUnselected_16.png");

	public ImageSource Disabled_16 => GetImageSource("Disabled_16.png");

	public ImageSource Disable_16 => GetImageSource("Disable_16.png");

	public ImageSource Discuss_32 => GetImageSource("Discuss_32.png");

	public ImageSource DisplayAidsGrid_16 => GetImageSource("DisplayAidsGrid_16.png");

	public ImageSource DisplayAidsRuler_16 => GetImageSource("DisplayAidsRuler_16.png");

	public ImageSource DisplayAidsSnapToGrid_16 => GetImageSource("DisplayAidsSnapToGrid_16.png");

	public ImageSource DisplayType_32 => GetImageSource("DisplayType_32.png");

	public ImageSource Display_16 => GetImageSource("Display_16.png");

	public ImageSource DistAnalysis_16 => GetImageSource("DistAnalysis_16.png");

	public ImageSource DistillationSynthesis_16 => GetImageSource("DistillationSynthesis_16.png");

	public ImageSource DistillContinuously_16 => GetImageSource("DistillContinuously_16.png");

	public ImageSource Distill_16 => GetImageSource("Distill_16.png");

	public ImageSource DistributeObjectHorizontal_16 => GetImageSource("DistributeObjectHorizontal_16.png");

	public ImageSource DistributeObjectVertically_16 => GetImageSource("DistributeObjectVertically_16.png");

	public ImageSource DOF_24 => GetImageSource("DOF_24.png");

	public ImageSource DoubleArrow_16 => GetImageSource("DoubleArrow_16.png");

	public ImageSource DoubleBond_32 => GetImageSource("DoubleBond_32.png");

	public ImageSource DownloadModelFile_16 => GetImageSource("DownloadModelFile_16.png");

	public ImageSource Downstream_16 => GetImageSource("Downstream_16.png");

	public ImageSource DrawArrow_16 => GetImageSource("DrawArrow_16.png");

	public ImageSource DrawDoubleArrow_16 => GetImageSource("DrawDoubleArrow_16.png");

	public ImageSource DrawEllipse_16 => GetImageSource("DrawEllipse_16.png");

	public ImageSource DrawFillColor_16 => GetImageSource("DrawFillColor_16.png");

	public ImageSource DrawInsertObject_16 => GetImageSource("DrawInsertObject_16.png");

	public ImageSource DrawInsertTimestamp_16 => GetImageSource("DrawInsertTimestamp_16.png");

	public ImageSource DrawInsert_16 => GetImageSource("DrawInsert_16.png");

	public ImageSource DrawLine_16 => GetImageSource("DrawLine_16.png");

	public ImageSource DrawPolygon_16 => GetImageSource("DrawPolygon_16.png");

	public ImageSource DrawPolyline_16 => GetImageSource("DrawPolyline_16.png");

	public ImageSource DrawRectangle_16 => GetImageSource("DrawRectangle_16.png");

	public ImageSource DrawSemiEllipse_16 => GetImageSource("DrawSemiEllipse_16.png");

	public ImageSource DrawStructureGrey_16 => GetImageSource("DrawStructureGrey_16.png");

	public ImageSource DrawText_16 => GetImageSource("DrawText_16.png");

	public ImageSource DrawWidth1_16 => GetImageSource("DrawWidth1_16.png");

	public ImageSource DrawWidth2_16 => GetImageSource("DrawWidth2_16.png");

	public ImageSource DrawWidth3_16 => GetImageSource("DrawWidth3_16.png");

	public ImageSource DrawWidth4_16 => GetImageSource("DrawWidth4_16.png");

	public ImageSource DrawWidth5_16 => GetImageSource("DrawWidth5_16.png");

	public ImageSource DrawWidth6_16 => GetImageSource("DrawWidth6_16.png");

	public ImageSource DrawWidth7_16 => GetImageSource("DrawWidth7_16.png");

	public ImageSource DrawWidth8_16 => GetImageSource("DrawWidth8_16.png");

	public ImageSource DrawWidthNone_16 => GetImageSource("DrawWidthNone_16.png");

	public ImageSource DryContinuously_16 => GetImageSource("DryContinuously_16.png");

	public ImageSource DryerAgitatedPan_16 => GetImageSource("DryerAgitatedPan_16.png");

	public ImageSource DryerBlender_16 => GetImageSource("DryerBlender_16.png");

	public ImageSource DryerConical_16 => GetImageSource("DryerConical_16.png");

	public ImageSource DryerFluidBedContinuous_16 => GetImageSource("DryerFluidBedContinuous_16.png");

	public ImageSource DryerFreeze_16 => GetImageSource("DryerFreeze_16.png");

	public ImageSource DryerHorizontalPaddle_16 => GetImageSource("DryerHorizontalPaddle_16.png");

	public ImageSource DryerRotary_16 => GetImageSource("DryerRotary_16.png");

	public ImageSource DryerSprayer_16 => GetImageSource("DryerSprayer_16.png");

	public ImageSource DryerTray_16 => GetImageSource("DryerTray_16.png");

	public ImageSource Dryer_16 => GetImageSource("Dryer_16.png");

	public ImageSource Dry_16 => GetImageSource("Dry_16.png");

	public ImageSource Duration_16 => GetImageSource("Duration_16.png");

	public ImageSource DynamicSimulationFlowDriven_32 => GetImageSource("DynamicSimulationFlowDriven_32.png");

	public ImageSource DynamicSimulationPressureChecker_32 => GetImageSource("DynamicSimulationPressureChecker_32.png");

	public ImageSource DynamicSimulationPressureDriven_32 => GetImageSource("DynamicSimulationPressureDriven_32.png");

	public ImageSource DynamicSimulationUpdateFlowDriven_32 => GetImageSource("DynamicSimulationUpdateFlowDriven_32.png");

	public ImageSource DynamicSimulationUpdatePressureDriven_32 => GetImageSource("DynamicSimulationUpdatePressureDriven_32.png");

	public ImageSource DynamicsSimulationDynamicMode_32 => GetImageSource("DynamicsSimulationDynamicMode_32.png");

	public ImageSource Dynamics_16 => GetImageSource("Dynamics_16.png");

	public ImageSource Earth_16 => GetImageSource("Earth_16.png");

	public ImageSource EconomicsActivateCosts_32 => GetImageSource("EconomicsActivateCosts_32.png");

	public ImageSource EconomicsCostOptions_16 => GetImageSource("EconomicsCostOptions_16.png");

	public ImageSource EconomicsCostOptions_32 => GetImageSource("EconomicsCostOptions_32.png");

	public ImageSource EconomicsDeleteScenario_16 => GetImageSource("EconomicsDeleteScenario_16.png");

	public ImageSource EconomicsDeleteScenario_32 => GetImageSource("EconomicsDeleteScenario_32.png");

	public ImageSource EconomicsEvaluate_32 => GetImageSource("EconomicsEvaluate_32.png");

	public ImageSource EconomicsInvestmentAnalysis_32 => GetImageSource("EconomicsInvestmentAnalysis_32.png");

	public ImageSource EconomicsMap_32 => GetImageSource("EconomicsMap_32.png");

	public ImageSource EconomicsMaterialCosts_16 => GetImageSource("EconomicsMaterialCosts_16.png");

	public ImageSource EconomicsModelSummary_32 => GetImageSource("EconomicsModelSummary_32.png");

	public ImageSource EconomicsProcessUtilities_16 => GetImageSource("EconomicsProcessUtilities_16.png");

	public ImageSource EconomicsRunEvaluation_32 => GetImageSource("EconomicsRunEvaluation_32.png");

	public ImageSource EconomicsShared_32 => GetImageSource("EconomicsShared_32.png");

	public ImageSource EconomicsViewEquipment_32 => GetImageSource("EconomicsViewEquipment_32.png");

	public ImageSource EcononmicsSize_32 => GetImageSource("EcononmicsSize_32.png");

	public ImageSource EditComments_32 => GetImageSource("EditComments_32.png");

	public ImageSource EditCompoundFile_32 => GetImageSource("EditCompoundFile_32.png");

	public ImageSource EditEvent_32 => GetImageSource("EditEvent_32.png");

	public ImageSource EditGroup_32 => GetImageSource("EditGroup_32.png");

	public ImageSource EditLayout_16 => GetImageSource("EditLayout_16.png");

	public ImageSource EditLegend_16 => GetImageSource("EditLegend_16.png");

	public ImageSource EditMaterial_16 => GetImageSource("EditMaterial_16.png");

	public ImageSource EditStrategy_16 => GetImageSource("EditStrategy_16.png");

	public ImageSource EditTemplateAlarmLimits_16 => GetImageSource("EditTemplateAlarmLimits_16.png");

	public ImageSource EditTemplateFormatting_16 => GetImageSource("EditTemplateFormatting_16.png");

	public ImageSource EditTemplateGroupsAndFunctions_16 => GetImageSource("EditTemplateGroupsAndFunctions_16.png");

	public ImageSource EditTemplateInformation_16 => GetImageSource("EditTemplateInformation_16.png");

	public ImageSource EditTemplateOther_16 => GetImageSource("EditTemplateOther_16.png");

	public ImageSource EditTemplate_16 => GetImageSource("EditTemplate_16.png");

	public ImageSource Edit_16 => GetImageSource("Edit_16.png");

	public ImageSource Edit_32 => GetImageSource("Edit_32.png");

	public ImageSource EDRFiredHeater_16 => GetImageSource("EDRFiredHeater_16.png");

	public ImageSource Ejector_16 => GetImageSource("Ejector_16.png");

	public ImageSource ElectrolytesWizard_48 => GetImageSource("ElectrolytesWizard_48.png");

	public ImageSource Electrolytes_32 => GetImageSource("Electrolytes_32.png");

	public ImageSource Electrolyte_48 => GetImageSource("Electrolyte_48.png");

	public ImageSource Electro_32 => GetImageSource("Electro_32.png");

	public ImageSource Emissions_16 => GetImageSource("Emissions_16.png");

	public ImageSource Encapsulate_16 => GetImageSource("Encapsulate_16.png");

	public ImageSource EnergyAnalysis_16 => GetImageSource("EnergyAnalysis_16.png");

	public ImageSource EnergyAnalysis_24 => GetImageSource("EnergyAnalysis_24.png");

	public ImageSource EnergyAnalyzer_16 => GetImageSource("EnergyAnalyzer_16.png");

	public ImageSource ENSEA_16 => GetImageSource("ENSEA_16.png");

	public ImageSource Envelope_24 => GetImageSource("Envelope_24.png");

	public ImageSource EOAnalysisConstraints_16 => GetImageSource("EOAnalysisConstraints_16.png");

	public ImageSource EOAnalysisDegreesofFreedom_16 => GetImageSource("EOAnalysisDegreesofFreedom_16.png");

	public ImageSource EOAnalysisEOSensitivity_16 => GetImageSource("EOAnalysisEOSensitivity_16.png");

	public ImageSource EOAnalysisEOVariables_32 => GetImageSource("EOAnalysisEOVariables_32.png");

	public ImageSource EOAnalysisSummary_16 => GetImageSource("EOAnalysisSummary_16.png");

	public ImageSource EOBlockStats_16 => GetImageSource("EOBlockStats_16.png");

	public ImageSource EOConfigAssignScripts_16 => GetImageSource("EOConfigAssignScripts_16.png");

	public ImageSource EOConfigConnections_16 => GetImageSource("EOConfigConnections_16.png");

	public ImageSource EOConfigEOInput_16 => GetImageSource("EOConfigEOInput_16.png");

	public ImageSource EOConfigGlobalScripts_16 => GetImageSource("EOConfigGlobalScripts_16.png");

	public ImageSource EOConfigLocalScripts_16 => GetImageSource("EOConfigLocalScripts_16.png");

	public ImageSource EOConfigObjFunction_16 => GetImageSource("EOConfigObjFunction_16.png");

	public ImageSource EOConfigPorts_16 => GetImageSource("EOConfigPorts_16.png");

	public ImageSource EOConfigSpecGroup_16 => GetImageSource("EOConfigSpecGroup_16.png");

	public ImageSource EOReportHistoryFile_16 => GetImageSource("EOReportHistoryFile_16.png");

	public ImageSource EOReportMeasurements_16 => GetImageSource("EOReportMeasurements_16.png");

	public ImageSource EOReportObjFunction_16 => GetImageSource("EOReportObjFunction_16.png");

	public ImageSource EOReportsActiveBounds_16 => GetImageSource("EOReportsActiveBounds_16.png");

	public ImageSource EOReportsEOSyncErrors_16 => GetImageSource("EOReportsEOSyncErrors_16.png");

	public ImageSource EOReportsSolver_16 => GetImageSource("EOReportsSolver_16.png");

	public ImageSource EORunControlsSolverSettings_16 => GetImageSource("EORunControlsSolverSettings_16.png");

	public ImageSource EORunGlobalScripts_16 => GetImageSource("EORunGlobalScripts_16.png");

	public ImageSource EOSensitivity_24 => GetImageSource("EOSensitivity_24.png");

	public ImageSource EOSolverReports_32 => GetImageSource("EOSolverReports_32.png");

	public ImageSource EOVariablesExport_16 => GetImageSource("EOVariablesExport_16.png");

	public ImageSource EOVariablesImport_16 => GetImageSource("EOVariablesImport_16.png");

	public ImageSource EOVariables_16 => GetImageSource("EOVariables_16.png");

	public ImageSource EqualSizeBoth_16 => GetImageSource("EqualSizeBoth_16.png");

	public ImageSource EqualSizeHeight_16 => GetImageSource("EqualSizeHeight_16.png");

	public ImageSource EqualSizeWidth_16 => GetImageSource("EqualSizeWidth_16.png");

	public ImageSource EquilibrateColumn_16 => GetImageSource("EquilibrateColumn_16.png");

	public ImageSource EquipmentDiagram_32 => GetImageSource("EquipmentDiagram_32.png");

	public ImageSource EquipmentOpenFolder_16 => GetImageSource("EquipmentOpenFolder_16.png");

	public ImageSource EquipmentSummary_16 => GetImageSource("EquipmentSummary_16.png");

	public ImageSource Equipment_16 => GetImageSource("Equipment_16.png");

	public ImageSource Equipment_32 => GetImageSource("Equipment_32.png");

	public ImageSource Erase_16 => GetImageSource("Erase_16.png");

	public ImageSource Erase_32 => GetImageSource("Erase_32.png");

	public ImageSource ErrorLog_32 => GetImageSource("ErrorLog_32.png");

	public ImageSource Error_16 => GetImageSource("Error_16.png");

	public ImageSource Ether_32 => GetImageSource("Ether_32.png");

	public ImageSource Evacuate_16 => GetImageSource("Evacuate_16.png");

	public ImageSource Evaluate_16 => GetImageSource("Evaluate_16.png");

	public ImageSource EvaporatorLongTube_16 => GetImageSource("EvaporatorLongTube_16.png");

	public ImageSource EvaporatorWipedFilm_16 => GetImageSource("EvaporatorWipedFilm_16.png");

	public ImageSource EventAddAfter_16 => GetImageSource("EventAddAfter_16.png");

	public ImageSource EventAddBefore_16 => GetImageSource("EventAddBefore_16.png");

	public ImageSource EventBringToTop_32 => GetImageSource("EventBringToTop_32.png");

	public ImageSource EventCopy_16 => GetImageSource("EventCopy_16.png");

	public ImageSource EventCopy_32 => GetImageSource("EventCopy_32.png");

	public ImageSource EventDelete_16 => GetImageSource("EventDelete_16.png");

	public ImageSource EventDelete_32 => GetImageSource("EventDelete_32.png");

	public ImageSource EventDownstream_16 => GetImageSource("EventDownstream_16.png");

	public ImageSource EventEdit_16 => GetImageSource("EventEdit_16.png");

	public ImageSource EventEdit_32 => GetImageSource("EventEdit_32.png");

	public ImageSource EventFreeze_16 => GetImageSource("EventFreeze_16.png");

	public ImageSource EventLabels_32 => GetImageSource("EventLabels_32.png");

	public ImageSource EventMerge_16 => GetImageSource("EventMerge_16.png");

	public ImageSource EventNew_16 => GetImageSource("EventNew_16.png");

	public ImageSource EventNew_32 => GetImageSource("EventNew_32.png");

	public ImageSource EventNext_16 => GetImageSource("EventNext_16.png");

	public ImageSource EventPrevious_16 => GetImageSource("EventPrevious_16.png");

	public ImageSource EventSplit_16 => GetImageSource("EventSplit_16.png");

	public ImageSource EventUnfreeze_16 => GetImageSource("EventUnfreeze_16.png");

	public ImageSource EventUpstream_16 => GetImageSource("EventUpstream_16.png");

	public ImageSource EventZoomAroundSelected_16 => GetImageSource("EventZoomAroundSelected_16.png");

	public ImageSource EventZoomAroundSelected_32 => GetImageSource("EventZoomAroundSelected_32.png");

	public ImageSource Event_16 => GetImageSource("Event_16.png");

	public ImageSource Examples_32 => GetImageSource("Examples_32.png");

	public ImageSource ExceptionMap_32 => GetImageSource("ExceptionMap_32.png");

	public ImageSource Exit_16 => GetImageSource("Exit_16.png");

	public ImageSource ExportAPDynamicsFlowDriven_32 => GetImageSource("ExportAPDynamicsFlowDriven_32.png");

	public ImageSource ExportAPDynamicsPressureDriven_32 => GetImageSource("ExportAPDynamicsPressureDriven_32.png");

	public ImageSource ExportCapeOpen_32 => GetImageSource("ExportCapeOpen_32.png");

	public ImageSource ExportData_32 => GetImageSource("ExportData_32.png");

	public ImageSource ExportEOVariables_32 => GetImageSource("ExportEOVariables_32.png");

	public ImageSource ExportModelTables_32 => GetImageSource("ExportModelTables_32.png");

	public ImageSource ExportToExcel_32 => GetImageSource("ExportToExcel_32.png");

	public ImageSource ExportToFile_16 => GetImageSource("ExportToFile_16.png");

	public ImageSource ExportVariables_24 => GetImageSource("ExportVariables_24.png");

	public ImageSource ExternalChangesAccept_32 => GetImageSource("ExternalChangesAccept_32.png");

	public ImageSource ExternalChangesReject_32 => GetImageSource("ExternalChangesReject_32.png");

	public ImageSource ExtractContinuously_16 => GetImageSource("ExtractContinuously_16.png");

	public ImageSource ExtractorContinuous_16 => GetImageSource("ExtractorContinuous_16.png");

	public ImageSource Extractor_16 => GetImageSource("Extractor_16.png");

	public ImageSource Extract_16 => GetImageSource("Extract_16.png");

	public ImageSource Extruder_16 => GetImageSource("Extruder_16.png");

	public ImageSource Extrude_16 => GetImageSource("Extrude_16.png");

	public ImageSource Eye_16 => GetImageSource("Eye_16.png");

	public ImageSource Eye_32 => GetImageSource("Eye_32.png");

	public ImageSource FacilityExplorer_16 => GetImageSource("FacilityExplorer_16.png");

	public ImageSource Factory_16 => GetImageSource("Factory_16.png");

	public ImageSource Failed_11 => GetImageSource("Failed_11.png");

	public ImageSource Fan_16 => GetImageSource("Fan_16.png");

	public ImageSource FermentContinuously_16 => GetImageSource("FermentContinuously_16.png");

	public ImageSource Fermenter_16 => GetImageSource("Fermenter_16.png");

	public ImageSource Ferment_16 => GetImageSource("Ferment_16.png");

	public ImageSource Fields_32 => GetImageSource("Fields_32.png");

	public ImageSource FileEditCompoundFile_32 => GetImageSource("FileEditCompoundFile_32.png");

	public ImageSource FileExportAPDymanicsPressureDriven_32 => GetImageSource("FileExportAPDymanicsPressureDriven_32.png");

	public ImageSource FileExportAPDynamicsFlowDriven_32 => GetImageSource("FileExportAPDynamicsFlowDriven_32.png");

	public ImageSource FileExportAspenProcessEconomicAnalyzer_32 => GetImageSource("FileExportAspenProcessEconomicAnalyzer_32.png");

	public ImageSource FileExportEDR_32 => GetImageSource("FileExportEDR_32.png");

	public ImageSource FileExportEnergyAnalyzer_32 => GetImageSource("FileExportEnergyAnalyzer_32.png");

	public ImageSource FileExportEOVariables_32 => GetImageSource("FileExportEOVariables_32.png");

	public ImageSource FileExportFile_32 => GetImageSource("FileExportFile_32.png");

	public ImageSource FileExport_32 => GetImageSource("FileExport_32.png");

	public ImageSource FileImportEOVariables_32 => GetImageSource("FileImportEOVariables_32.png");

	public ImageSource FileImportFile_32 => GetImageSource("FileImportFile_32.png");

	public ImageSource FileNew_32 => GetImageSource("FileNew_32.png");

	public ImageSource FileOpenTemplate_32 => GetImageSource("FileOpenTemplate_32.png");

	public ImageSource FileOpen_32 => GetImageSource("FileOpen_32.png");

	public ImageSource FilePrintPreview_32 => GetImageSource("FilePrintPreview_32.png");

	public ImageSource FilePrint_16 => GetImageSource("FilePrint_16.png");

	public ImageSource FilePrint_32 => GetImageSource("FilePrint_32.png");

	public ImageSource FileSaveAsAspenPlusBackup_32 => GetImageSource("FileSaveAsAspenPlusBackup_32.png");

	public ImageSource FileSaveAsAspenPlusDoc_32 => GetImageSource("FileSaveAsAspenPlusDoc_32.png");

	public ImageSource FileSaveAsCompoundFile_32 => GetImageSource("FileSaveAsCompoundFile_32.png");

	public ImageSource FileSaveAsTemplate_16 => GetImageSource("FileSaveAsTemplate_16.png");

	public ImageSource FileSaveAs_32 => GetImageSource("FileSaveAs_32.png");

	public ImageSource FileSave_16 => GetImageSource("FileSave_16.png");

	public ImageSource FillCapsule_16 => GetImageSource("FillCapsule_16.png");

	public ImageSource FillColor_16 => GetImageSource("FillColor_16.png");

	public ImageSource FillingSystem_16 => GetImageSource("FillingSystem_16.png");

	public ImageSource FilterActive_9 => GetImageSource("FilterActive_9.png");

	public ImageSource FilterAdvanced_16 => GetImageSource("FilterAdvanced_16.png");

	public ImageSource FilterAdvanced_32 => GetImageSource("FilterAdvanced_32.png");

	public ImageSource FilterAgitatedNutsche_16 => GetImageSource("FilterAgitatedNutsche_16.png");

	public ImageSource FilterBag_16 => GetImageSource("FilterBag_16.png");

	public ImageSource FilterBatch_16 => GetImageSource("FilterBatch_16.png");

	public ImageSource FilterBelt_16 => GetImageSource("FilterBelt_16.png");

	public ImageSource FilterByValue_16 => GetImageSource("FilterByValue_16.png");

	public ImageSource FilterClear_16 => GetImageSource("FilterClear_16.png");

	public ImageSource FilterContinuously_16 => GetImageSource("FilterContinuously_16.png");

	public ImageSource FilterCrossFlow_16 => GetImageSource("FilterCrossFlow_16.png");

	public ImageSource FilterDryer_16 => GetImageSource("FilterDryer_16.png");

	public ImageSource FilterFromStart_16 => GetImageSource("FilterFromStart_16.png");

	public ImageSource FilterFromStart_32 => GetImageSource("FilterFromStart_32.png");

	public ImageSource FilterGlobal_16 => GetImageSource("FilterGlobal_16.png");

	public ImageSource FilterInLine_16 => GetImageSource("FilterInLine_16.png");

	public ImageSource FilterPot_16 => GetImageSource("FilterPot_16.png");

	public ImageSource FilterPress_16 => GetImageSource("FilterPress_16.png");

	public ImageSource FilterReapply_16 => GetImageSource("FilterReapply_16.png");

	public ImageSource FilterSparkler_16 => GetImageSource("FilterSparkler_16.png");

	public ImageSource FilterTankSheet_16 => GetImageSource("FilterTankSheet_16.png");

	public ImageSource FilterToEnd_16 => GetImageSource("FilterToEnd_16.png");

	public ImageSource FilterToEnd_32 => GetImageSource("FilterToEnd_32.png");

	public ImageSource FilterView_16 => GetImageSource("FilterView_16.png");

	public ImageSource Filter_16 => GetImageSource("Filter_16.png");

	public ImageSource Filter_32 => GetImageSource("Filter_32.png");

	public ImageSource FindCommandInteractiveGuide_32 => GetImageSource("FindCommandInteractiveGuide_32.png");

	public ImageSource FindComponents_16 => GetImageSource("FindComponents_16.png");

	public ImageSource FindComps_16 => GetImageSource("FindComps_16.png");

	public ImageSource FindUnitOperation_16 => GetImageSource("FindUnitOperation_16.png");

	public ImageSource FindUnitOperation_32 => GetImageSource("FindUnitOperation_32.png");

	public ImageSource Find_16 => GetImageSource("Find_16.png");

	public ImageSource Find_32 => GetImageSource("Find_32.png");

	public ImageSource FiredHeater_16 => GetImageSource("FiredHeater_16.png");

	public ImageSource FlareAnalysis_16 => GetImageSource("FlareAnalysis_16.png");

	public ImageSource Flarenet_16 => GetImageSource("Flarenet_16.png");

	public ImageSource FlareSystemAnalysis_16 => GetImageSource("FlareSystemAnalysis_16.png");

	public ImageSource Flask_16 => GetImageSource("Flask_16.png");

	public ImageSource FlipByLineOrPoint_16 => GetImageSource("FlipByLineOrPoint_16.png");

	public ImageSource FlipHorizontal_16 => GetImageSource("FlipHorizontal_16.png");

	public ImageSource FlipLR_16 => GetImageSource("FlipLR_16.png");

	public ImageSource FlipUD_16 => GetImageSource("FlipUD_16.png");

	public ImageSource FlipVertical_16 => GetImageSource("FlipVertical_16.png");

	public ImageSource FlowsheetAlignLeft_16 => GetImageSource("FlowsheetAlignLeft_16.png");

	public ImageSource FlowsheetBreak_16 => GetImageSource("FlowsheetBreak_16.png");

	public ImageSource FlowsheetDisplayOptions_32 => GetImageSource("FlowsheetDisplayOptions_32.png");

	public ImageSource FlowsheetFlipHorizontal_16 => GetImageSource("FlowsheetFlipHorizontal_16.png");

	public ImageSource FlowsheetFlipVertical_16 => GetImageSource("FlowsheetFlipVertical_16.png");

	public ImageSource FlowsheetGrey_16 => GetImageSource("FlowsheetGrey_16.png");

	public ImageSource FlowsheetHierarchyExport_16 => GetImageSource("FlowsheetHierarchyExport_16.png");

	public ImageSource FlowsheetHierarchyImport_16 => GetImageSource("FlowsheetHierarchyImport_16.png");

	public ImageSource FlowsheetInsert_16 => GetImageSource("FlowsheetInsert_16.png");

	public ImageSource FlowsheetJoin_16 => GetImageSource("FlowsheetJoin_16.png");

	public ImageSource FlowsheetLockFlowsheet_16 => GetImageSource("FlowsheetLockFlowsheet_16.png");

	public ImageSource FlowsheetModelPalette_32 => GetImageSource("FlowsheetModelPalette_32.png");

	public ImageSource FlowsheetReconnect_16 => GetImageSource("FlowsheetReconnect_16.png");

	public ImageSource FlowsheetRerouteStream_16 => GetImageSource("FlowsheetRerouteStream_16.png");

	public ImageSource FlowsheetRotate_16 => GetImageSource("FlowsheetRotate_16.png");

	public ImageSource FlowsheetSections_16 => GetImageSource("FlowsheetSections_16.png");

	public ImageSource FlowsheetUnitOperationsShowStatus_16 => GetImageSource("FlowsheetUnitOperationsShowStatus_16.png");

	public ImageSource Flowsheet_24 => GetImageSource("Flowsheet_24.png");

	public ImageSource Flowsheet_32 => GetImageSource("Flowsheet_32.png");

	public ImageSource FluidCatCracker_16 => GetImageSource("FluidCatCracker_16.png");

	public ImageSource FolderClosedCyan_16 => GetImageSource("FolderClosedCyan_16.png");

	public ImageSource FolderClosedRequiredInputComplete_16 => GetImageSource("FolderClosedRequiredInputComplete_16.png");

	public ImageSource FolderClosedRequiredInputIncomplete_16 => GetImageSource("FolderClosedRequiredInputIncomplete_16.png");

	public ImageSource FolderClosedResultsChanged_16 => GetImageSource("FolderClosedResultsChanged_16.png");

	public ImageSource FolderClosedResultsError_16 => GetImageSource("FolderClosedResultsError_16.png");

	public ImageSource FolderClosedResultsOK_16 => GetImageSource("FolderClosedResultsOK_16.png");

	public ImageSource FolderClosedResultsWarning_16 => GetImageSource("FolderClosedResultsWarning_16.png");

	public ImageSource FolderClosed_16 => GetImageSource("FolderClosed_16.png");

	public ImageSource FolderDeactivatedResults_16 => GetImageSource("FolderDeactivatedResults_16.png");

	public ImageSource FolderDeactivated_16 => GetImageSource("FolderDeactivated_16.png");

	public ImageSource FolderOpenCyan_16 => GetImageSource("FolderOpenCyan_16.png");

	public ImageSource FolderOpenRequiredInputComplete_16 => GetImageSource("FolderOpenRequiredInputComplete_16.png");

	public ImageSource FolderOpenRequiredInputIncomplete_16 => GetImageSource("FolderOpenRequiredInputIncomplete_16.png");

	public ImageSource FolderOpenResultsChanged_16 => GetImageSource("FolderOpenResultsChanged_16.png");

	public ImageSource FolderOpenResultsError_16 => GetImageSource("FolderOpenResultsError_16.png");

	public ImageSource FolderOpenResultsOK_16 => GetImageSource("FolderOpenResultsOK_16.png");

	public ImageSource FolderOpenResultsWarning_16 => GetImageSource("FolderOpenResultsWarning_16.png");

	public ImageSource FolderOpen_16 => GetImageSource("FolderOpen_16.png");

	public ImageSource FontColor_16 => GetImageSource("FontColor_16.png");

	public ImageSource FontSizeDecrease_16 => GetImageSource("FontSizeDecrease_16.png");

	public ImageSource FontSizeDecrease_22 => GetImageSource("FontSizeDecrease_22.png");

	public ImageSource FontSizeIncrease_16 => GetImageSource("FontSizeIncrease_16.png");

	public ImageSource FontSizeIncrease_22 => GetImageSource("FontSizeIncrease_22.png");

	public ImageSource Font_16 => GetImageSource("Font_16.png");

	public ImageSource ForecastManagement_24 => GetImageSource("ForecastManagement_24.png");

	public ImageSource FormatPainter_16 => GetImageSource("FormatPainter_16.png");

	public ImageSource FormatSelection_16 => GetImageSource("FormatSelection_16.png");

	public ImageSource FormIncomplete_16 => GetImageSource("FormIncomplete_16.png");

	public ImageSource FormInputChanged_16 => GetImageSource("FormInputChanged_16.png");

	public ImageSource FormInputCompleteB_16 => GetImageSource("FormInputCompleteB_16.png");

	public ImageSource FormInputComplete_16 => GetImageSource("FormInputComplete_16.png");

	public ImageSource FormInputIncomplete_B16 => GetImageSource("FormInputIncomplete_B16.png");

	public ImageSource FormInputNeutral_16 => GetImageSource("FormInputNeutral_16.png");

	public ImageSource FormMixed_16 => GetImageSource("FormMixed_16.png");

	public ImageSource FormNode_16 => GetImageSource("FormNode_16.png");

	public ImageSource FormNoResultsPresent_16 => GetImageSource("FormNoResultsPresent_16.png");

	public ImageSource FormResultsError_16 => GetImageSource("FormResultsError_16.png");

	public ImageSource FormResultsOK_16 => GetImageSource("FormResultsOK_16.png");

	public ImageSource FormResultsWarning_16 => GetImageSource("FormResultsWarning_16.png");

	public ImageSource FormulaFolder_16 => GetImageSource("FormulaFolder_16.png");

	public ImageSource Formula_16 => GetImageSource("Formula_16.png");

	public ImageSource Forward_16 => GetImageSource("Forward_16.png");

	public ImageSource Gantt_32 => GetImageSource("Gantt_32.png");

	public ImageSource GlobalDefaults_32 => GetImageSource("GlobalDefaults_32.png");

	public ImageSource GlobalScripts_16 => GetImageSource("GlobalScripts_16.png");

	public ImageSource GranulatorFluidBed_16 => GetImageSource("GranulatorFluidBed_16.png");

	public ImageSource Grid_16 => GetImageSource("Grid_16.png");

	public ImageSource GroupItem_11 => GetImageSource("GroupItem_11.png");

	public ImageSource GroupObjects_16 => GetImageSource("GroupObjects_16.png");

	public ImageSource Group_11 => GetImageSource("Group_11.png");

	public ImageSource HeatExchangerAnalysis_16 => GetImageSource("HeatExchangerAnalysis_16.png");

	public ImageSource HeatExchangerStandards_16 => GetImageSource("HeatExchangerStandards_16.png");

	public ImageSource HeatExchangerStandards_32 => GetImageSource("HeatExchangerStandards_32.png");

	public ImageSource HeatExchanger_16 => GetImageSource("HeatExchanger_16.png");

	public ImageSource Height_16 => GetImageSource("Height_16.png");

	public ImageSource Help_16 => GetImageSource("Help_16.png");

	public ImageSource Help_32 => GetImageSource("Help_32.png");

	public ImageSource HierarchyMoveSelection_16 => GetImageSource("HierarchyMoveSelection_16.png");

	public ImageSource HierarchyViewChild_16 => GetImageSource("HierarchyViewChild_16.png");

	public ImageSource HierarchyViewParent_16 => GetImageSource("HierarchyViewParent_16.png");

	public ImageSource HistorySummary_16 => GetImageSource("HistorySummary_16.png");

	public ImageSource History_16 => GetImageSource("History_16.png");

	public ImageSource Home_16 => GetImageSource("Home_16.png");

	public ImageSource Homogenizer_16 => GetImageSource("Homogenizer_16.png");

	public ImageSource Hopper_16 => GetImageSource("Hopper_16.png");

	public ImageSource HTFSNet_16 => GetImageSource("HTFSNet_16.png");

	public ImageSource HTFSNet_32 => GetImageSource("HTFSNet_32.png");

	public ImageSource Hydrate_16 => GetImageSource("Hydrate_16.png");

	public ImageSource Hydrate_32 => GetImageSource("Hydrate_32.png");

	public ImageSource HydroCracker_24 => GetImageSource("HydroCracker_24.png");

	public ImageSource Hyperlink_16 => GetImageSource("Hyperlink_16.png");

	public ImageSource Image_16 => GetImageSource("Image_16.png");

	public ImageSource ImportFromFile_16 => GetImageSource("ImportFromFile_16.png");

	public ImageSource ImportVariables_24 => GetImageSource("ImportVariables_24.png");

	public ImageSource Incomplete_16 => GetImageSource("Incomplete_16.png");

	public ImageSource IncreaseHorizontalSpacing_16 => GetImageSource("IncreaseHorizontalSpacing_16.png");

	public ImageSource IncreaseIndent_16 => GetImageSource("IncreaseIndent_16.png");

	public ImageSource IncreaseVerticalSpacing_16 => GetImageSource("IncreaseVerticalSpacing_16.png");

	public ImageSource IncubatorShaker_16 => GetImageSource("IncubatorShaker_16.png");

	public ImageSource Incubator_16 => GetImageSource("Incubator_16.png");

	public ImageSource Information_16 => GetImageSource("Information_16.png");

	public ImageSource InitiateDownload_16 => GetImageSource("InitiateDownload_16.png");

	public ImageSource InProgress_16 => GetImageSource("InProgress_16.png");

	public ImageSource InputSummary_16 => GetImageSource("InputSummary_16.png");

	public ImageSource Input_16 => GetImageSource("Input_16.png");

	public ImageSource InsertObject_16 => GetImageSource("InsertObject_16.png");

	public ImageSource InsertRow_16 => GetImageSource("InsertRow_16.png");

	public ImageSource Insert_16 => GetImageSource("Insert_16.png");

	public ImageSource IntegrationDesigner_App => GetImageSource("IntegrationDesigner_App.png");

	public ImageSource Interactive_32 => GetImageSource("Interactive_32.png");

	public ImageSource InternalHelicalCoil_16 => GetImageSource("InternalHelicalCoil_16.png");

	public ImageSource InternetExplorer_16 => GetImageSource("InternetExplorer_16.png");

	public ImageSource InventoryLocationVapor_16 => GetImageSource("InventoryLocationVapor_16.png");

	public ImageSource InventoryLocation_16 => GetImageSource("InventoryLocation_16.png");

	public ImageSource IP21TagBrowser_32 => GetImageSource("IP21TagBrowser_32.png");

	public ImageSource Italic_16 => GetImageSource("Italic_16.png");

	public ImageSource ItemTypeFolder_16 => GetImageSource("ItemTypeFolder_16.png");

	public ImageSource ItemType_16 => GetImageSource("ItemType_16.png");

	public ImageSource Item_16 => GetImageSource("Item_16.png");

	public ImageSource JacketAgitatedConventional_16 => GetImageSource("JacketAgitatedConventional_16.png");

	public ImageSource JacketBaffledConventional_16 => GetImageSource("JacketBaffledConventional_16.png");

	public ImageSource JacketConventional_16 => GetImageSource("JacketConventional_16.png");

	public ImageSource JacketDimple_16 => GetImageSource("JacketDimple_16.png");

	public ImageSource JacketHalfPipeCoils_16 => GetImageSource("JacketHalfPipeCoils_16.png");

	public ImageSource Join_16 => GetImageSource("Join_16.png");

	public ImageSource Ketone_32 => GetImageSource("Ketone_32.png");

	public ImageSource KeyIndexFolder_16 => GetImageSource("KeyIndexFolder_16.png");

	public ImageSource KeyIndex_16 => GetImageSource("KeyIndex_16.png");

	public ImageSource Kneader_16 => GetImageSource("Kneader_16.png");

	public ImageSource Labor_32 => GetImageSource("Labor_32.png");

	public ImageSource LaminarFlowHood_16 => GetImageSource("LaminarFlowHood_16.png");

	public ImageSource Language_32 => GetImageSource("Language_32.png");

	public ImageSource LeftAlign_16 => GetImageSource("LeftAlign_16.png");

	public ImageSource LineColor_16 => GetImageSource("LineColor_16.png");

	public ImageSource LineColor_32 => GetImageSource("LineColor_32.png");

	public ImageSource LineFitting_16 => GetImageSource("LineFitting_16.png");

	public ImageSource LineStyle_16 => GetImageSource("LineStyle_16.png");

	public ImageSource LineTypeColorThumbnail_174x284 => GetImageSource("LineTypeColorThumbnail_174x284.png");

	public ImageSource LineWeight_16 => GetImageSource("LineWeight_16.png");

	public ImageSource LineWidth_16 => GetImageSource("LineWidth_16.png");

	public ImageSource Line_16 => GetImageSource("Line_16.png");

	public ImageSource LinkAND_16 => GetImageSource("LinkAND_16.png");

	public ImageSource LinkDirection_16 => GetImageSource("LinkDirection_16.png");

	public ImageSource LinkObjects_16 => GetImageSource("LinkObjects_16.png");

	public ImageSource LinkOR_16 => GetImageSource("LinkOR_16.png");

	public ImageSource LinkTypeBezier_16 => GetImageSource("LinkTypeBezier_16.png");

	public ImageSource LinkTypeHVH_16 => GetImageSource("LinkTypeHVH_16.png");

	public ImageSource LinkTypeHV_16 => GetImageSource("LinkTypeHV_16.png");

	public ImageSource LinkTypeSpline_16 => GetImageSource("LinkTypeSpline_16.png");

	public ImageSource LinkTypeVHV_16 => GetImageSource("LinkTypeVHV_16.png");

	public ImageSource LinkTypeVH_16 => GetImageSource("LinkTypeVH_16.png");

	public ImageSource LinkType_16 => GetImageSource("LinkType_16.png");

	public ImageSource Link_16 => GetImageSource("Link_16.png");

	public ImageSource LoadTemplateFromDatabase_16 => GetImageSource("LoadTemplateFromDatabase_16.png");

	public ImageSource LocalScripts_24 => GetImageSource("LocalScripts_24.png");

	public ImageSource Lock_16 => GetImageSource("Lock_16.png");

	public ImageSource LogFile_32 => GetImageSource("LogFile_32.png");

	public ImageSource Log_16 => GetImageSource("Log_16.png");

	public ImageSource Lyophilizer_16 => GetImageSource("Lyophilizer_16.png");

	public ImageSource Magnify_32 => GetImageSource("Magnify_32.png");

	public ImageSource MakeHorizontalSpacingEqual_16 => GetImageSource("MakeHorizontalSpacingEqual_16.png");

	public ImageSource MakeVerticalSpacingEqual_16 => GetImageSource("MakeVerticalSpacingEqual_16.png");

	public ImageSource ManageSavedFilter_32 => GetImageSource("ManageSavedFilter_32.png");

	public ImageSource Manifold_16 => GetImageSource("Manifold_16.png");

	public ImageSource Map2_16 => GetImageSource("Map2_16.png");

	public ImageSource MasterRecipeEdit_16 => GetImageSource("MasterRecipeEdit_16.png");

	public ImageSource MasterRecipe_16 => GetImageSource("MasterRecipe_16.png");

	public ImageSource MasterStrategyEdit_16 => GetImageSource("MasterStrategyEdit_16.png");

	public ImageSource MasterStrategy_16 => GetImageSource("MasterStrategy_16.png");

	public ImageSource Master_16 => GetImageSource("Master_16.png");

	public ImageSource MaterialDatabase_16 => GetImageSource("MaterialDatabase_16.png");

	public ImageSource MaterialDefaults_16 => GetImageSource("MaterialDefaults_16.png");

	public ImageSource MaterialsFind_16 => GetImageSource("MaterialsFind_16.png");

	public ImageSource MaterialsFind_32 => GetImageSource("MaterialsFind_32.png");

	public ImageSource Maximize_16 => GetImageSource("Maximize_16.png");

	public ImageSource MBO_App => GetImageSource("MBO_App.png");

	public ImageSource Measure_48 => GetImageSource("Measure_48.png");

	public ImageSource MergePlots_32 => GetImageSource("MergePlots_32.png");

	public ImageSource MessageLog_32 => GetImageSource("MessageLog_32.png");

	public ImageSource MessagePanel_32 => GetImageSource("MessagePanel_32.png");

	public ImageSource Messages_24 => GetImageSource("Messages_24.png");

	public ImageSource MetalPropertiesDatabank_16 => GetImageSource("MetalPropertiesDatabank_16.png");

	public ImageSource MetalPropertiesDatabank_32 => GetImageSource("MetalPropertiesDatabank_32.png");

	public ImageSource Microfilter_16 => GetImageSource("Microfilter_16.png");

	public ImageSource MillContinuous_16 => GetImageSource("MillContinuous_16.png");

	public ImageSource MillHammer_16 => GetImageSource("MillHammer_16.png");

	public ImageSource MillJet_16 => GetImageSource("MillJet_16.png");

	public ImageSource Mill_16 => GetImageSource("Mill_16.png");

	public ImageSource Minimize_16 => GetImageSource("Minimize_16.png");

	public ImageSource Mixer_16 => GetImageSource("Mixer_16.png");

	public ImageSource Modeling_24 => GetImageSource("Modeling_24.png");

	public ImageSource ModelSelection_32 => GetImageSource("ModelSelection_32.png");

	public ImageSource ModelSummary_16 => GetImageSource("ModelSummary_16.png");

	public ImageSource ModifyPlot_16 => GetImageSource("ModifyPlot_16.png");

	public ImageSource MostUsedComponents_16 => GetImageSource("MostUsedComponents_16.png");

	public ImageSource MostUsedMaterials_16 => GetImageSource("MostUsedMaterials_16.png");

	public ImageSource MoveDown_16 => GetImageSource("MoveDown_16.png");

	public ImageSource MoveIntoBatch_16 => GetImageSource("MoveIntoBatch_16.png");

	public ImageSource MoveLeft_16 => GetImageSource("MoveLeft_16.png");

	public ImageSource MoveOutofBatch_16 => GetImageSource("MoveOutofBatch_16.png");

	public ImageSource MoveRight_16 => GetImageSource("MoveRight_16.png");

	public ImageSource MoveUp_16 => GetImageSource("MoveUp_16.png");

	public ImageSource MRFolder_16 => GetImageSource("MRFolder_16.png");

	public ImageSource MSExcel_16 => GetImageSource("MSExcel_16.png");

	public ImageSource MSExcel_32 => GetImageSource("MSExcel_32.png");

	public ImageSource MSFolder_16 => GetImageSource("MSFolder_16.png");

	public ImageSource MSWord_16 => GetImageSource("MSWord_16.png");

	public ImageSource N2_24 => GetImageSource("N2_24.png");

	public ImageSource Naphthalene_48 => GetImageSource("Naphthalene_48.png");

	public ImageSource NavigateBackward_16 => GetImageSource("NavigateBackward_16.png");

	public ImageSource NavigateBackward_32 => GetImageSource("NavigateBackward_32.png");

	public ImageSource NavigateFlowsheet_16 => GetImageSource("NavigateFlowsheet_16.png");

	public ImageSource NavigateForward_16 => GetImageSource("NavigateForward_16.png");

	public ImageSource NavigateForward_32 => GetImageSource("NavigateForward_32.png");

	public ImageSource NavigateProcessUtilities_16 => GetImageSource("NavigateProcessUtilities_16.png");

	public ImageSource NavigateReactions_16 => GetImageSource("NavigateReactions_16.png");

	public ImageSource NavigateSetup_16 => GetImageSource("NavigateSetup_16.png");

	public ImageSource NavigateStreams_16 => GetImageSource("NavigateStreams_16.png");

	public ImageSource NavigateUnitOperations_16 => GetImageSource("NavigateUnitOperations_16.png");

	public ImageSource NavigationSync_16 => GetImageSource("NavigationSync_16.png");

	public ImageSource NavigationSync_32 => GetImageSource("NavigationSync_32.png");

	public ImageSource NewFilter_32 => GetImageSource("NewFilter_32.png");

	public ImageSource NewPlot_16 => GetImageSource("NewPlot_16.png");

	public ImageSource NewProcedure_16 => GetImageSource("NewProcedure_16.png");

	public ImageSource NewScenario_32 => GetImageSource("NewScenario_32.png");

	public ImageSource NewTemplate_32 => GetImageSource("NewTemplate_32.png");

	public ImageSource NewWindow_32 => GetImageSource("NewWindow_32.png");

	public ImageSource New_16 => GetImageSource("New_16.png");

	public ImageSource New_32 => GetImageSource("New_32.png");

	public ImageSource NextForm_16 => GetImageSource("NextForm_16.png");

	public ImageSource NextProduct_16 => GetImageSource("NextProduct_16.png");

	public ImageSource Next_16 => GetImageSource("Next_16.png");

	public ImageSource NIST_16 => GetImageSource("NIST_16.png");

	public ImageSource NonCondensibles_24 => GetImageSource("NonCondensibles_24.png");

	public ImageSource Nozzle_16 => GetImageSource("Nozzle_16.png");

	public ImageSource Numbering_16 => GetImageSource("Numbering_16.png");

	public ImageSource NumericConversion_16 => GetImageSource("NumericConversion_16.png");

	public ImageSource OnlineDocumentation_16 => GetImageSource("OnlineDocumentation_16.png");

	public ImageSource OnlineDocumentation_32 => GetImageSource("OnlineDocumentation_32.png");

	public ImageSource OnlineTrainingUptoSpeed_32 => GetImageSource("OnlineTrainingUptoSpeed_32.png");

	public ImageSource OpenCloseWorkspace_32 => GetImageSource("OpenCloseWorkspace_32.png");

	public ImageSource OpenFolder_16 => GetImageSource("OpenFolder_16.png");

	public ImageSource OpenTemplate_32 => GetImageSource("OpenTemplate_32.png");

	public ImageSource Open_16 => GetImageSource("Open_16.png");

	public ImageSource Open_32 => GetImageSource("Open_32.png");

	public ImageSource OperatingInstructions_32 => GetImageSource("OperatingInstructions_32.png");

	public ImageSource Optimize_32 => GetImageSource("Optimize_32.png");

	public ImageSource Options_16 => GetImageSource("Options_16.png");

	public ImageSource OrderBringForward_16 => GetImageSource("OrderBringForward_16.png");

	public ImageSource OrderBringToFront_16 => GetImageSource("OrderBringToFront_16.png");

	public ImageSource OrderSendBackward_16 => GetImageSource("OrderSendBackward_16.png");

	public ImageSource OrderSendToBack_16 => GetImageSource("OrderSendToBack_16.png");

	public ImageSource OtherApplications_16 => GetImageSource("OtherApplications_16.png");

	public ImageSource OtherApplications_32 => GetImageSource("OtherApplications_32.png");

	public ImageSource OutlineGroup_16 => GetImageSource("OutlineGroup_16.png");

	public ImageSource OutlineGroup_32 => GetImageSource("OutlineGroup_32.png");

	public ImageSource OutlineHideDetail_16 => GetImageSource("OutlineHideDetail_16.png");

	public ImageSource OutlineShowDetail_16 => GetImageSource("OutlineShowDetail_16.png");

	public ImageSource OutlineSubtotals_16 => GetImageSource("OutlineSubtotals_16.png");

	public ImageSource OutlineSubtotals_32 => GetImageSource("OutlineSubtotals_32.png");

	public ImageSource OutlineUngroup_16 => GetImageSource("OutlineUngroup_16.png");

	public ImageSource OutlineUngroup_32 => GetImageSource("OutlineUngroup_32.png");

	public ImageSource Override_32 => GetImageSource("Override_32.png");

	public ImageSource Overview_32 => GetImageSource("Overview_32.png");

	public ImageSource PackageDelete_16 => GetImageSource("PackageDelete_16.png");

	public ImageSource PackageEdit_16 => GetImageSource("PackageEdit_16.png");

	public ImageSource Package_16 => GetImageSource("Package_16.png");

	public ImageSource PageBreaksReset_32 => GetImageSource("PageBreaksReset_32.png");

	public ImageSource PageBreaksView_32 => GetImageSource("PageBreaksView_32.png");

	public ImageSource PageWidth_16 => GetImageSource("PageWidth_16.png");

	public ImageSource Palette_24 => GetImageSource("Palette_24.png");

	public ImageSource PanDown_16 => GetImageSource("PanDown_16.png");

	public ImageSource PanLeft_16 => GetImageSource("PanLeft_16.png");

	public ImageSource PanRight_16 => GetImageSource("PanRight_16.png");

	public ImageSource PanUp_16 => GetImageSource("PanUp_16.png");

	public ImageSource Pan_16 => GetImageSource("Pan_16.png");

	public ImageSource ParametricPlot_32 => GetImageSource("ParametricPlot_32.png");

	public ImageSource Parent_16 => GetImageSource("Parent_16.png");

	public ImageSource ParmSecurityOpenFolder_16 => GetImageSource("ParmSecurityOpenFolder_16.png");

	public ImageSource ParmSecurity_16 => GetImageSource("ParmSecurity_16.png");

	public ImageSource ParmSelect_16 => GetImageSource("ParmSelect_16.png");

	public ImageSource Parm_16 => GetImageSource("Parm_16.png");

	public ImageSource Paste_16 => GetImageSource("Paste_16.png");

	public ImageSource Paste_32 => GetImageSource("Paste_32.png");

	public ImageSource PetroleumDistillation_24 => GetImageSource("PetroleumDistillation_24.png");

	public ImageSource PetroleumFeeder_24 => GetImageSource("PetroleumFeeder_24.png");

	public ImageSource PhaseEnvelope_16 => GetImageSource("PhaseEnvelope_16.png");

	public ImageSource PhysicalProperties_16 => GetImageSource("PhysicalProperties_16.png");

	public ImageSource PhysicalProperties_32 => GetImageSource("PhysicalProperties_32.png");

	public ImageSource PickProducts_32 => GetImageSource("PickProducts_32.png");

	public ImageSource Picture_32 => GetImageSource("Picture_32.png");

	public ImageSource Pipe_16 => GetImageSource("Pipe_16.png");

	public ImageSource Piping_16 => GetImageSource("Piping_16.png");

	public ImageSource PlanningBoard_32 => GetImageSource("PlanningBoard_32.png");

	public ImageSource Planning_24 => GetImageSource("Planning_24.png");

	public ImageSource PlanSheet_32 => GetImageSource("PlanSheet_32.png");

	public ImageSource Plans_16 => GetImageSource("Plans_16.png");

	public ImageSource PlateFeeder_16 => GetImageSource("PlateFeeder_16.png");

	public ImageSource PlateFinHeatExchanger_16 => GetImageSource("PlateFinHeatExchanger_16.png");

	public ImageSource PlateFinHeatExchanger_32 => GetImageSource("PlateFinHeatExchanger_32.png");

	public ImageSource PlotAddCurve_16 => GetImageSource("PlotAddCurve_16.png");

	public ImageSource PlotArrowDown_16 => GetImageSource("PlotArrowDown_16.png");

	public ImageSource PlotArrowLeft_16 => GetImageSource("PlotArrowLeft_16.png");

	public ImageSource PlotArrowRight_16 => GetImageSource("PlotArrowRight_16.png");

	public ImageSource PlotArrowUp_16 => GetImageSource("PlotArrowUp_16.png");

	public ImageSource PlotBatchOverlay_16 => GetImageSource("PlotBatchOverlay_16.png");

	public ImageSource PlotDisplay_16 => GetImageSource("PlotDisplay_16.png");

	public ImageSource PlotGrey_16 => GetImageSource("PlotGrey_16.png");

	public ImageSource PlotMultipleBatch_16 => GetImageSource("PlotMultipleBatch_16.png");

	public ImageSource PlotSingleBatch_16 => GetImageSource("PlotSingleBatch_16.png");

	public ImageSource Plots_16 => GetImageSource("Plots_16.png");

	public ImageSource PlotTernary1_16 => GetImageSource("PlotTernary1_16.png");

	public ImageSource PlotTernary2_16 => GetImageSource("PlotTernary2_16.png");

	public ImageSource Plot_16 => GetImageSource("Plot_16.png");

	public ImageSource PLSetValue_16 => GetImageSource("PLSetValue_16.png");

	public ImageSource PlusGreen_16 => GetImageSource("PlusGreen_16.png");

	public ImageSource Polyline_16 => GetImageSource("Polyline_16.png");

	public ImageSource Polymers_24 => GetImageSource("Polymers_24.png");

	public ImageSource Port_24 => GetImageSource("Port_24.png");

	public ImageSource PredefinedMixture_16 => GetImageSource("PredefinedMixture_16.png");

	public ImageSource PredefinedMixture_32 => GetImageSource("PredefinedMixture_32.png");

	public ImageSource PreparePackage_16 => GetImageSource("PreparePackage_16.png");

	public ImageSource PressureChecker_16 => GetImageSource("PressureChecker_16.png");

	public ImageSource PressureReliefAnalysis_16 => GetImageSource("PressureReliefAnalysis_16.png");

	public ImageSource PreviewReport_32 => GetImageSource("PreviewReport_32.png");

	public ImageSource Preview_32 => GetImageSource("Preview_32.png");

	public ImageSource PreviousProduct_16 => GetImageSource("PreviousProduct_16.png");

	public ImageSource PrintPreviewPrintOptions_32 => GetImageSource("PrintPreviewPrintOptions_32.png");

	public ImageSource PrintPreview_16 => GetImageSource("PrintPreview_16.png");

	public ImageSource PrintPreview_32 => GetImageSource("PrintPreview_32.png");

	public ImageSource PrintSetup_32 => GetImageSource("PrintSetup_32.png");

	public ImageSource Print_16 => GetImageSource("Print_16.png");

	public ImageSource Print_32 => GetImageSource("Print_32.png");

	public ImageSource ProblemReport_32 => GetImageSource("ProblemReport_32.png");

	public ImageSource ProcessUtilities_48 => GetImageSource("ProcessUtilities_48.png");

	public ImageSource Process_32 => GetImageSource("Process_32.png");

	public ImageSource ProductBlending_24 => GetImageSource("ProductBlending_24.png");

	public ImageSource ProductCurrent_16 => GetImageSource("ProductCurrent_16.png");

	public ImageSource ProductNameToggle_16 => GetImageSource("ProductNameToggle_16.png");

	public ImageSource Product_16 => GetImageSource("Product_16 .png");

	public ImageSource Product_32 => GetImageSource("Product_32.png");

	public ImageSource Profile_32 => GetImageSource("Profile_32.png");

	public ImageSource ProgramLog_16 => GetImageSource("ProgramLog_16.png");

	public ImageSource ProgressIndicatorSet_16 => GetImageSource("ProgressIndicatorSet_16.png");

	public ImageSource ProjectionData_16 => GetImageSource("ProjectionData_16.png");

	public ImageSource ProjectionData_32 => GetImageSource("ProjectionData_32.png");

	public ImageSource ProjectionSettings_16 => GetImageSource("ProjectionSettings_16.png");

	public ImageSource ProjectionSettings_32 => GetImageSource("ProjectionSettings_32.png");

	public ImageSource ProjectionTilePanel_16 => GetImageSource("ProjectionTilePanel_16.png");

	public ImageSource ProjectionTilePanel_32 => GetImageSource("ProjectionTilePanel_32.png");

	public ImageSource ProjectionTileScreen_16 => GetImageSource("ProjectionTileScreen_16.png");

	public ImageSource ProjectionTileScreen_32 => GetImageSource("ProjectionTileScreen_32.png");

	public ImageSource ProjectionTiles_16 => GetImageSource("ProjectionTiles_16.png");

	public ImageSource ProjectionTiles_32 => GetImageSource("ProjectionTiles_32.png");

	public ImageSource PropagateMaster_16 => GetImageSource("PropagateMaster_16.png");

	public ImageSource PropertiesBinaryAnalysis_16 => GetImageSource("PropertiesBinaryAnalysis_16.png");

	public ImageSource PropertiesChemistry_16 => GetImageSource("PropertiesChemistry_16.png");

	public ImageSource PropertiesClearParameters_16 => GetImageSource("PropertiesClearParameters_16.png");

	public ImageSource PropertiesComponents_16 => GetImageSource("PropertiesComponents_16.png");

	public ImageSource PropertiesCustomize_16 => GetImageSource("PropertiesCustomize_16.png");

	public ImageSource PropertiesDataSourceDECHEMA_16 => GetImageSource("PropertiesDataSourceDECHEMA_16.png");

	public ImageSource PropertiesDataSourceTDENIST_16 => GetImageSource("PropertiesDataSourceTDENIST_16.png");

	public ImageSource PropertiesDrawStructure_32 => GetImageSource("PropertiesDrawStructure_32.png");

	public ImageSource PropertiesLog_16 => GetImageSource("PropertiesLog_16.png");

	public ImageSource PropertiesMethodSelector_16 => GetImageSource("PropertiesMethodSelector_16.png");

	public ImageSource PropertiesMethods_16 => GetImageSource("PropertiesMethods_16.png");

	public ImageSource PropertiesPropertySets_16 => GetImageSource("PropertiesPropertySets_16.png");

	public ImageSource PropertiesResidueCurveAnalysis_16 => GetImageSource("PropertiesResidueCurveAnalysis_16.png");

	public ImageSource PropertiesRetrieveParameters_16 => GetImageSource("PropertiesRetrieveParameters_16.png");

	public ImageSource PropertiesRunModeAnalysis_16 => GetImageSource("PropertiesRunModeAnalysis_16.png");

	public ImageSource PropertiesRunModeEstimation_16 => GetImageSource("PropertiesRunModeEstimation_16.png");

	public ImageSource PropertiesRunModeRegression_16 => GetImageSource("PropertiesRunModeRegression_16.png");

	public ImageSource PropertiesTernaryMapAnalysis_16 => GetImageSource("PropertiesTernaryMapAnalysis_16.png");

	public ImageSource Properties_16 => GetImageSource("Properties_16.png");

	public ImageSource Properties_32 => GetImageSource("Properties_32.png");

	public ImageSource PropertyMethods_16 => GetImageSource("PropertyMethods_16.png");

	public ImageSource PropertyMethods_24 => GetImageSource("PropertyMethods_24.png");

	public ImageSource PropertySet_32 => GetImageSource("PropertySet_32.png");

	public ImageSource Props_16 => GetImageSource("Props_16.png");

	public ImageSource Props_32 => GetImageSource("Props_32.png");

	public ImageSource PTEnvelope_16 => GetImageSource("PTEnvelope_16.png");

	public ImageSource Publish_16 => GetImageSource("Publish_16.png");

	public ImageSource PumpVacuum_16 => GetImageSource("PumpVacuum_16.png");

	public ImageSource Pump_16 => GetImageSource("Pump_16.png");

	public ImageSource PureComponent_16 => GetImageSource("PureComponent_16.png");

	public ImageSource PureComponent_32 => GetImageSource("PureComponent_32.png");

	public ImageSource Pure_16 => GetImageSource("Pure_16.png");

	public ImageSource Pure_32 => GetImageSource("Pure_32.png");

	public ImageSource PurgeMessages_16 => GetImageSource("PurgeMessages_16.png");

	public ImageSource Pyridine_32 => GetImageSource("Pyridine_32.png");

	public ImageSource QCHEX_16 => GetImageSource("QCHEX_16.png");

	public ImageSource QueryAdd_32 => GetImageSource("QueryAdd_32.png");

	public ImageSource QueryCancel_16 => GetImageSource("QueryCancel_16.png");

	public ImageSource QueryConfigure_16 => GetImageSource("QueryConfigure_16.png");

	public ImageSource QueryDelete_32 => GetImageSource("QueryDelete_32.png");

	public ImageSource QueryEdit_32 => GetImageSource("QueryEdit_32.png");

	public ImageSource QueryExecute_16 => GetImageSource("QueryExecute_16.png");

	public ImageSource QueryTool_16 => GetImageSource("QueryTool_16.png");

	public ImageSource QueryTool_32 => GetImageSource("QueryTool_32.png");

	public ImageSource QueryViewFields_16 => GetImageSource("QueryViewFields_16.png");

	public ImageSource QueryView_32 => GetImageSource("QueryView_32.png");

	public ImageSource QuickAccessNext_16 => GetImageSource("QuickAccessNext_16.png");

	public ImageSource Radar_16 => GetImageSource("Radar_16.png");

	public ImageSource RadioSelected_16 => GetImageSource("RadioSelected_16.png");

	public ImageSource RadioUnselected_16 => GetImageSource("RadioUnselected_16.png");

	public ImageSource RangeType_32 => GetImageSource("RangeType_32.png");

	public ImageSource Reactions_48 => GetImageSource("Reactions_48.png");

	public ImageSource Reaction_16 => GetImageSource("Reaction_16.png");

	public ImageSource Reaction_32 => GetImageSource("Reaction_32.png");

	public ImageSource ReactorContinuous_16 => GetImageSource("ReactorContinuous_16.png");

	public ImageSource Reactor_16 => GetImageSource("Reactor_16.png");

	public ImageSource Ready_16 => GetImageSource("Ready_16.png");

	public ImageSource ReCalculate_16 => GetImageSource("ReCalculate_16.png");

	public ImageSource RecallSavedView_16 => GetImageSource("RecallSavedView_16.png");

	public ImageSource Recipe_32 => GetImageSource("Recipe_32.png");

	public ImageSource Reconcile_16 => GetImageSource("Reconcile_16.png");

	public ImageSource Rectangle_16 => GetImageSource("Rectangle_16.png");

	public ImageSource RedFlag_16 => GetImageSource("RedFlag_16.png");

	public ImageSource Redo_16 => GetImageSource("Redo_16.png");

	public ImageSource References_16 => GetImageSource("References_16.png");

	public ImageSource References_32 => GetImageSource("References_32.png");

	public ImageSource RefluxThruDAndS_16 => GetImageSource("RefluxThruDAndS_16.png");

	public ImageSource RefreshChanges_32 => GetImageSource("RefreshChanges_32.png");

	public ImageSource RefreshDoc_16 => GetImageSource("RefreshDoc_16.png");

	public ImageSource RefreshDoc_32 => GetImageSource("RefreshDoc_32.png");

	public ImageSource Refresh_16 => GetImageSource("Refresh_16.png");

	public ImageSource RegenerateColumn_16 => GetImageSource("RegenerateColumn_16.png");

	public ImageSource RegenerateControlRecipe_16 => GetImageSource("RegenerateControlRecipe_16.png");

	public ImageSource RegeneratePackage_16 => GetImageSource("RegeneratePackage_16.png");

	public ImageSource Regenerate_16 => GetImageSource("Regenerate_16.png");

	public ImageSource RemoveApplication_16 => GetImageSource("RemoveApplication_16.png");

	public ImageSource RemoveApplication_32 => GetImageSource("RemoveApplication_32.png");

	public ImageSource RemoveHorizontalSpacing_16 => GetImageSource("RemoveHorizontalSpacing_16.png");

	public ImageSource RemoveVerticalSpacing_16 => GetImageSource("RemoveVerticalSpacing_16.png");

	public ImageSource Rename_16 => GetImageSource("Rename_16.png");

	public ImageSource RepeatingCycleTime_16 => GetImageSource("RepeatingCycleTime_16.png");

	public ImageSource ReportAdjustments_16 => GetImageSource("ReportAdjustments_16.png");

	public ImageSource ReportExceptions_16 => GetImageSource("ReportExceptions_16.png");

	public ImageSource ReportModel_16 => GetImageSource("ReportModel_16.png");

	public ImageSource ReportSummary_16 => GetImageSource("ReportSummary_16.png");

	public ImageSource Reports_16 => GetImageSource("Reports_16.png");

	public ImageSource ReportXL_16 => GetImageSource("ReportXL_16.png");

	public ImageSource Report_16 => GetImageSource("Report_16.png");

	public ImageSource Report_32 => GetImageSource("Report_32.png");

	public ImageSource RerouteConnector_16 => GetImageSource("RerouteConnector_16.png");

	public ImageSource ResetAxis_16 => GetImageSource("ResetAxis_16.png");

	public ImageSource ResetChanges_32 => GetImageSource("ResetChanges_32.png");

	public ImageSource ResetGantt_32 => GetImageSource("ResetGantt_32.png");

	public ImageSource ResetToMatchStyle_16 => GetImageSource("ResetToMatchStyle_16.png");

	public ImageSource ResetV2_16 => GetImageSource("ResetV2_16.png");

	public ImageSource Reset_16 => GetImageSource("Reset_16.png");

	public ImageSource Rewind_16 => GetImageSource("Rewind_16.png");

	public ImageSource RibbonCloseDocument_16 => GetImageSource("RibbonCloseDocument_16.png");

	public ImageSource RibbonClose_16 => GetImageSource("RibbonClose_16.png");

	public ImageSource RibbonClose_32 => GetImageSource("RibbonClose_32.png");

	public ImageSource RibbonCollapse_16 => GetImageSource("RibbonCollapse_16.png");

	public ImageSource RibbonExpand_16 => GetImageSource("RibbonExpand_16.png");

	public ImageSource RibbonMapping_32 => GetImageSource("RibbonMapping_32.png");

	public ImageSource RightAlign_16 => GetImageSource("RightAlign_16.png");

	public ImageSource RightArrow_16 => GetImageSource("RightArrow_16.png");

	public ImageSource RollerCompactor_16 => GetImageSource("RollerCompactor_16.png");

	public ImageSource RotateLeft_16 => GetImageSource("RotateLeft_16.png");

	public ImageSource Rounding_32 => GetImageSource("Rounding_32.png");

	public ImageSource RouteSelectionPref_32 => GetImageSource("RouteSelectionPref_32.png");

	public ImageSource RouteSelectionProcessStep_16 => GetImageSource("RouteSelectionProcessStep_16.png");

	public ImageSource RouteSelectionProcessTree_16 => GetImageSource("RouteSelectionProcessTree_16.png");

	public ImageSource RouteSelection_16 => GetImageSource("RouteSelection_16.png");

	public ImageSource RunActions_32 => GetImageSource("RunActions_32.png");

	public ImageSource RunBlue_16 => GetImageSource("RunBlue_16.png");

	public ImageSource Running_16 => GetImageSource("Running_16.png");

	public ImageSource RunPlanOpenFolder_16 => GetImageSource("RunPlanOpenFolder_16.png");

	public ImageSource RunPlan_16 => GetImageSource("RunPlan_16.png");

	public ImageSource RunStep_32 => GetImageSource("RunStep_32.png");

	public ImageSource RunStop_16 => GetImageSource("RunStop_16.png");

	public ImageSource RuntimeView_16 => GetImageSource("RuntimeView_16.png");

	public ImageSource Run_16 => GetImageSource("Run_16.png");

	public ImageSource Run_32 => GetImageSource("Run_32.png");

	public ImageSource Rx_16 => GetImageSource("Rx_16.png");

	public ImageSource SaveAll_16 => GetImageSource("SaveAll_16.png");

	public ImageSource SaveAs_16 => GetImageSource("SaveAs_16.png");

	public ImageSource SaveAs_32 => GetImageSource("SaveAs_32.png");

	public ImageSource SaveDefaultPlot_16 => GetImageSource("SaveDefaultPlot_16.png");

	public ImageSource SavedPlots_16 => GetImageSource("SavedPlots_16.png");

	public ImageSource SavedViewsSave_32 => GetImageSource("SavedViewsSave_32.png");

	public ImageSource SavedViewsSwitch_32 => GetImageSource("SavedViewsSwitch_32.png");

	public ImageSource SaveTemplateToDatabase_16 => GetImageSource("SaveTemplateToDatabase_16.png");

	public ImageSource SaveTemplate_32 => GetImageSource("SaveTemplate_32.png");

	public ImageSource SaveView_32 => GetImageSource("SaveView_32.png");

	public ImageSource Save_16 => GetImageSource("Save_16.png");

	public ImageSource Save_32 => GetImageSource("Save_32.png");

	public ImageSource Scale_16 => GetImageSource("Scale_16.png");

	public ImageSource ScenarioCompare_32 => GetImageSource("ScenarioCompare_32.png");

	public ImageSource ScenarioDelete_32 => GetImageSource("ScenarioDelete_32.png");

	public ImageSource ScenarioIndex_16 => GetImageSource("ScenarioIndex_16.png");

	public ImageSource ScenarioSave_32 => GetImageSource("ScenarioSave_32.png");

	public ImageSource ScenariosManage_32 => GetImageSource("ScenariosManage_32.png");

	public ImageSource ScenariosRefresh_32 => GetImageSource("ScenariosRefresh_32.png");

	public ImageSource ScenarioSwitch_32 => GetImageSource("ScenarioSwitch_32.png");

	public ImageSource Schedule_16 => GetImageSource("Schedule_16.png");

	public ImageSource SCMApp_128 => GetImageSource("SCMApp_128.png");

	public ImageSource SCMApp_16 => GetImageSource("SCMApp_16.png");

	public ImageSource SCMApp_24 => GetImageSource("SCMApp_24.png");

	public ImageSource SCMApp_32 => GetImageSource("SCMApp_32.png");

	public ImageSource SCMApp_48 => GetImageSource("SCMApp_48.png");

	public ImageSource SCMApp_64 => GetImageSource("SCMApp_64.png");

	public ImageSource SCMApp_HelpAbout_32 => GetImageSource("SCMApp_HelpAbout_32.png");

	public ImageSource ScreenLayoutSave_16 => GetImageSource("ScreenLayoutSave_16.png");

	public ImageSource ScreenLayoutSave_32 => GetImageSource("ScreenLayoutSave_32.png");

	public ImageSource ScreenLayoutSwitch_16 => GetImageSource("ScreenLayoutSwitch_16.png");

	public ImageSource ScreenLayoutSwitch_32 => GetImageSource("ScreenLayoutSwitch_32.png");

	public ImageSource ScreenSwitch_16 => GetImageSource("ScreenSwitch_16.png");

	public ImageSource ScreenSwitch_32 => GetImageSource("ScreenSwitch_32.png");

	public ImageSource Screen_16 => GetImageSource("Screen_16.png");

	public ImageSource ScrewConveyor_16 => GetImageSource("ScrewConveyor_16.png");

	public ImageSource Search_16 => GetImageSource("Search_16.png");

	public ImageSource Search_32 => GetImageSource("Search_32.png");

	public ImageSource SectionGrey_16 => GetImageSource("SectionGrey_16.png");

	public ImageSource Security_24 => GetImageSource("Security_24.png");

	public ImageSource SelectData_32 => GetImageSource("SelectData_32.png");

	public ImageSource SelectionPanel_16 => GetImageSource("SelectionPanel_16.png");

	public ImageSource SelectionPane_32 => GetImageSource("SelectionPane_32.png");

	public ImageSource Select_16 => GetImageSource("Select_16.png");

	public ImageSource Select_32 => GetImageSource("Select_32.png");

	public ImageSource SendToBack_32 => GetImageSource("SendToBack_32.png");

	public ImageSource SendToEconomics_32 => GetImageSource("SendToEconomics_32.png");

	public ImageSource SendToEDR2_16 => GetImageSource("SendToEDR2_16.png");

	public ImageSource SendTOFDDyn_16 => GetImageSource("SendTOFDDyn_16.png");

	public ImageSource SendToPDDyn_16 => GetImageSource("SendToPDDyn_16.png");

	public ImageSource SensitivityAnalysis_16 => GetImageSource("SensitivityAnalysis_16.png");

	public ImageSource SensitivityPlot_16 => GetImageSource("SensitivityPlot_16.png");

	public ImageSource Sensitivity_16 => GetImageSource("Sensitivity_16.png");

	public ImageSource Separate_16 => GetImageSource("Separate_16.png");

	public ImageSource ServerBackupRestore_16 => GetImageSource("ServerBackupRestore_16.png");

	public ImageSource ServerBackupRestore_32 => GetImageSource("ServerBackupRestore_32.png");

	public ImageSource ServerConfigure_16 => GetImageSource("ServerConfigure_16.png");

	public ImageSource ServerConfigure_32 => GetImageSource("ServerConfigure_32.png");

	public ImageSource ServerMigration_16 => GetImageSource("ServerMigration_16.png");

	public ImageSource ServerMigration_32 => GetImageSource("ServerMigration_32.png");

	public ImageSource SetState_16 => GetImageSource("SetState_16.png");

	public ImageSource Setup_16 => GetImageSource("Setup_16.png");

	public ImageSource ShapeEllipse_16 => GetImageSource("ShapeEllipse_16.png");

	public ImageSource ShapeLine_16 => GetImageSource("ShapeLine_16.png");

	public ImageSource ShapeOutline_16 => GetImageSource("ShapeOutline_16.png");

	public ImageSource ShapePolygon_16 => GetImageSource("ShapePolygon_16.png");

	public ImageSource ShapePolyline_16 => GetImageSource("ShapePolyline_16.png");

	public ImageSource ShapeSemiEllipse_16 => GetImageSource("ShapeSemiEllipse_16.png");

	public ImageSource Shapes_32 => GetImageSource("Shapes_32.png");

	public ImageSource ShiftReactor_24 => GetImageSource("ShiftReactor_24.png");

	public ImageSource ShowClaimed_16 => GetImageSource("ShowClaimed_16.png");

	public ImageSource ShowClaimed_32 => GetImageSource("ShowClaimed_32.png");

	public ImageSource ShowComponent_16 => GetImageSource("ShowComponent_16.png");

	public ImageSource ShowHighlighting_32 => GetImageSource("ShowHighlighting_32.png");

	public ImageSource ShowInventory_32 => GetImageSource("ShowInventory_32.png");

	public ImageSource ShowLabels_16 => GetImageSource("ShowLabels_16.png");

	public ImageSource Sifter_16 => GetImageSource("Sifter_16.png");

	public ImageSource SilenceTimeOut_16 => GetImageSource("SilenceTimeOut_16.png");

	public ImageSource SimulationSequence_16 => GetImageSource("SimulationSequence_16.png");

	public ImageSource SingleBond_32 => GetImageSource("SingleBond_32.png");

	public ImageSource SiteView_16 => GetImageSource("SiteView_16.png");

	public ImageSource Size_16 => GetImageSource("Size_16.png");

	public ImageSource SLMCommute_App => GetImageSource("SLMCommute_App.png");

	public ImageSource SLMConfigWizard_App => GetImageSource("SLMConfigWizard_App.png");

	public ImageSource SLMLicenseProfiler_App => GetImageSource("SLMLicenseProfiler_App.png");

	public ImageSource SortAndFilter_32 => GetImageSource("SortAndFilter_32.png");

	public ImageSource SortAscending_16 => GetImageSource("SortAscending_16.png");

	public ImageSource SortDescending_16 => GetImageSource("SortDescending_16.png");

	public ImageSource Sort_32 => GetImageSource("Sort_32.png");

	public ImageSource Speed_32 => GetImageSource("Speed_32.png");

	public ImageSource StandardStatements_16 => GetImageSource("StandardStatements_16.png");

	public ImageSource StartPage_32 => GetImageSource("StartPage_32.png");

	public ImageSource StartSweep_16 => GetImageSource("StartSweep_16.png");

	public ImageSource StartUp_11 => GetImageSource("StartUp_11.png");

	public ImageSource StatusComplete_16 => GetImageSource("StatusComplete_16.png");

	public ImageSource StatusError_16 => GetImageSource("StatusError_16.png");

	public ImageSource StatusGreenCircle_16 => GetImageSource("StatusGreenCircle_16.png");

	public ImageSource StatusIncomplete_16 => GetImageSource("StatusIncomplete_16.png");

	public ImageSource StatusInputChanged_16 => GetImageSource("StatusInputChanged_16.png");

	public ImageSource StatusOrangeSquare_16 => GetImageSource("StatusOrangeSquare_16.png");

	public ImageSource StatusRedDiamond_16 => GetImageSource("StatusRedDiamond_16.png");

	public ImageSource StatusYellowTriangle_16 => GetImageSource("StatusYellowTriangle_16.png");

	public ImageSource SteadyState_16 => GetImageSource("SteadyState_16.png");

	public ImageSource Step_16 => GetImageSource("Step_16.png");

	public ImageSource Sterilizer_16 => GetImageSource("Sterilizer_16.png");

	public ImageSource Sterilize_16 => GetImageSource("Sterilize_16.png");

	public ImageSource StopDisabled_32 => GetImageSource("StopDisabled_32.png");

	public ImageSource StopResetSimulation_16 => GetImageSource("StopResetSimulation_16.png");

	public ImageSource StopSign_32 => GetImageSource("StopSign_32.png");

	public ImageSource StopSweep_16 => GetImageSource("StopSweep_16.png");

	public ImageSource Stop_16 => GetImageSource("Stop_16.png");

	public ImageSource Stop_32 => GetImageSource("Stop_32.png");

	public ImageSource StrategyOpenFolder_16 => GetImageSource("StrategyOpenFolder_16.png");

	public ImageSource StrategyRunPlan_16 => GetImageSource("StrategyRunPlan_16.png");

	public ImageSource Strategy_16 => GetImageSource("Strategy_16.png");

	public ImageSource StreamAnalysis_16 => GetImageSource("StreamAnalysis_16.png");

	public ImageSource StreamCategories_32 => GetImageSource("StreamCategories_32.png");

	public ImageSource StreamCost_16 => GetImageSource("StreamCost_16.png");

	public ImageSource StreamReport_48 => GetImageSource("StreamReport_48.png");

	public ImageSource StreamResultsGrey_16 => GetImageSource("StreamResultsGrey_16.png");

	public ImageSource StreamSummary_16 => GetImageSource("StreamSummary_16.png");

	public ImageSource Streams_16 => GetImageSource("Streams_16.png");

	public ImageSource SubBatchDefinitions_16 => GetImageSource("SubBatchDefinitions_16.png");

	public ImageSource SubBatchDefinitions_32 => GetImageSource("SubBatchDefinitions_32.png");

	public ImageSource SubBatchNew_16 => GetImageSource("SubBatchNew_16.png");

	public ImageSource SubBatch_16 => GetImageSource("SubBatch_16.png");

	public ImageSource SubBatch_32 => GetImageSource("SubBatch_32.png");

	public ImageSource Sum_16 => GetImageSource("Sum_16.png");

	public ImageSource Sum_32 => GetImageSource("Sum_32.png");

	public ImageSource SwitchRowColumn_32 => GetImageSource("SwitchRowColumn_32.png");

	public ImageSource SwitchScreen_16 => GetImageSource("SwitchScreen_16.png");

	public ImageSource SwitchScreen_32 => GetImageSource("SwitchScreen_32.png");

	public ImageSource SwitchSelections_32 => GetImageSource("SwitchSelections_32.png");

	public ImageSource SwitchWindows_32 => GetImageSource("SwitchWindows_32.png");

	public ImageSource SwitchWindow_32 => GetImageSource("SwitchWindow_32.png");

	public ImageSource SwitchWorkspaces_16 => GetImageSource("SwitchWorkspaces_16.png");

	public ImageSource SwitchWorkspaces_32 => GetImageSource("SwitchWorkspaces_32.png");

	public ImageSource SystemOptions_16 => GetImageSource("SystemOptions_16.png");

	public ImageSource SystemOptions_32 => GetImageSource("SystemOptions_32.png");

	public ImageSource TabletingUnit_16 => GetImageSource("TabletingUnit_16.png");

	public ImageSource Tablet_16 => GetImageSource("Tablet_16.png");

	public ImageSource Table_16 => GetImageSource("Table_16.png");

	public ImageSource TagRenameUtility_App => GetImageSource("TagRenameUtility_App.png");

	public ImageSource Tags_16 => GetImageSource("Tags_16.png");

	public ImageSource Tag_16 => GetImageSource("Tag_16.png");

	public ImageSource TankBatch_16 => GetImageSource("TankBatch_16.png");

	public ImageSource TankFarm_16 => GetImageSource("TankFarm_16.png");

	public ImageSource Tank_16 => GetImageSource("Tank_16.png");

	public ImageSource Tasc_16 => GetImageSource("Tasc_16.png");

	public ImageSource Tasc_32 => GetImageSource("Tasc_32.png");

	public ImageSource TDENIST_16 => GetImageSource("TDENIST_16.png");

	public ImageSource Teamsc_16 => GetImageSource("Teamsc_16.png");

	public ImageSource Teamsc_32 => GetImageSource("Teamsc_32.png");

	public ImageSource Teams_16 => GetImageSource("Teams_16.png");

	public ImageSource Teams_32 => GetImageSource("Teams_32.png");

	public ImageSource TearOff_16 => GetImageSource("TearOff_16.png");

	public ImageSource TechSupport_16 => GetImageSource("TechSupport_16.png");

	public ImageSource TechSupport_32 => GetImageSource("TechSupport_32.png");

	public ImageSource TemplateFolder_16 => GetImageSource("TemplateFolder_16.png");

	public ImageSource Textbox_16 => GetImageSource("Textbox_16.png");

	public ImageSource Textbox_32 => GetImageSource("Textbox_32.png");

	public ImageSource TextRecipe_16 => GetImageSource("TextRecipe_16.png");

	public ImageSource Text_24 => GetImageSource("Text_24.png");

	public ImageSource TickmarkGreen_16 => GetImageSource("TickmarkGreen_16.png");

	public ImageSource TimedOut_11 => GetImageSource("TimedOut_11.png");

	public ImageSource TimedOut_16 => GetImageSource("TimedOut_16.png");

	public ImageSource Time_16 => GetImageSource("Time_16.png");

	public ImageSource Today_16 => GetImageSource("Today_16.png");

	public ImageSource TotalAmount_16 => GetImageSource("TotalAmount_16.png");

	public ImageSource TraceDownstream_16 => GetImageSource("TraceDownstream_16.png");

	public ImageSource TraceFindMaterial_32 => GetImageSource("TraceFindMaterial_32.png");

	public ImageSource TraceMaterialFlow_16 => GetImageSource("TraceMaterialFlow_16.png");

	public ImageSource TraceMaterialFlow_32 => GetImageSource("TraceMaterialFlow_32.png");

	public ImageSource TraceRemove_16 => GetImageSource("TraceRemove_16.png");

	public ImageSource TraceRemove_32 => GetImageSource("TraceRemove_32.png");

	public ImageSource TraceTimingLinks_32 => GetImageSource("TraceTimingLinks_32.png");

	public ImageSource TraceUpdstream_16 => GetImageSource("TraceUpdstream_16.png");

	public ImageSource TrackChanges_32 => GetImageSource("TrackChanges_32.png");

	public ImageSource TrafficLightGo_32 => GetImageSource("TrafficLightGo_32.png");

	public ImageSource TrafficLightStop_32 => GetImageSource("TrafficLightStop_32.png");

	public ImageSource Training_16 => GetImageSource("Training_16.png");

	public ImageSource Training_32 => GetImageSource("Training_32.png");

	public ImageSource TransferContinuously_16 => GetImageSource("TransferContinuously_16.png");

	public ImageSource TransferData_16 => GetImageSource("TransferData_16.png");

	public ImageSource TransferInfo_16 => GetImageSource("TransferInfo_16.png");

	public ImageSource TransferPanel_16 => GetImageSource("TransferPanel_16.png");

	public ImageSource TransferThruHeatExchanger_16 => GetImageSource("TransferThruHeatExchanger_16.png");

	public ImageSource TransferThruSterilizer_16 => GetImageSource("TransferThruSterilizer_16.png");

	public ImageSource Transfer_16 => GetImageSource("Transfer_16.png");

	public ImageSource Transparent_16 => GetImageSource("Transparent_16.png");

	public ImageSource Transparent_32 => GetImageSource("Transparent_32.png");

	public ImageSource TriBlender_16 => GetImageSource("TriBlender_16.png");

	public ImageSource TriggerNew_16 => GetImageSource("TriggerNew_16.png");

	public ImageSource Trigger_16 => GetImageSource("Trigger_16.png");

	public ImageSource TripleBond_32 => GetImageSource("TripleBond_32.png");

	public ImageSource TroubleshootingHelp_16 => GetImageSource("TroubleshootingHelp_16.png");

	public ImageSource TroubleshootingHelp_32 => GetImageSource("TroubleshootingHelp_32.png");

	public ImageSource Troubleshoot_16 => GetImageSource("Troubleshoot_16.png");

	public ImageSource Ultrafilter_16 => GetImageSource("Ultrafilter_16.png");

	public ImageSource Underline_16 => GetImageSource("Underline_16.png");

	public ImageSource Undo_16 => GetImageSource("Undo_16.png");

	public ImageSource UnitOperationNew_16 => GetImageSource("UnitOperationNew_16.png");

	public ImageSource UnitOperationsWarningsGrey_16 => GetImageSource("UnitOperationsWarningsGrey_16.png");

	public ImageSource UnitOperation_102x80 => GetImageSource("UnitOperation_102x80.png");

	public ImageSource UnitOperation_16 => GetImageSource("UnitOperation_16.png");

	public ImageSource UnitProcedure_16 => GetImageSource("UnitProcedure_16.png");

	public ImageSource UnitSets_16 => GetImageSource("UnitSets_16.png");

	public ImageSource UnitsOfMeasure_32 => GetImageSource("UnitsOfMeasure_32.png");

	public ImageSource Units_16 => GetImageSource("Units_16.png");

	public ImageSource Unknown_11 => GetImageSource("Unknown_11.png");

	public ImageSource Unlink_16 => GetImageSource("Unlink_16.png");

	public ImageSource UnpackColumn_16 => GetImageSource("UnpackColumn_16.png");

	public ImageSource UOM_16 => GetImageSource("UOM_16.png");

	public ImageSource UpdateFDDyn_16 => GetImageSource("UpdateFDDyn_16.png");

	public ImageSource UpdateGeometry_16 => GetImageSource("UpdateGeometry_16.png");

	public ImageSource UpdateGeometry_32 => GetImageSource("UpdateGeometry_32.png");

	public ImageSource UpdatePDDyn_16 => GetImageSource("UpdatePDDyn_16.png");

	public ImageSource UpdatePressureDrivenDyn_16 => GetImageSource("UpdatePressureDrivenDyn_16.png");

	public ImageSource UpdateTable_16 => GetImageSource("UpdateTable_16.png");

	public ImageSource Upstream_16 => GetImageSource("Upstream_16.png");

	public ImageSource UpToSpeed_32 => GetImageSource("UpToSpeed_32.png");

	public ImageSource Up_16 => GetImageSource("Up_16.png");

	public ImageSource UserDefinedParameter_16 => GetImageSource("UserDefinedParameter_16.png");

	public ImageSource User_16 => GetImageSource("User_16.png");

	public ImageSource UtilitiesSummary_16 => GetImageSource("UtilitiesSummary_16.png");

	public ImageSource Utilities_16 => GetImageSource("Utilities_16.png");

	public ImageSource Utilities_32 => GetImageSource("Utilities_32.png");

	public ImageSource Utilize_16 => GetImageSource("Utilize_16.png");

	public ImageSource VacuumPressureLock_16 => GetImageSource("VacuumPressureLock_16.png");

	public ImageSource Vacuum_Pressure_Lock_16 => GetImageSource("Vacuum_Pressure_Lock_16.png");

	public ImageSource Valve_16 => GetImageSource("Valve_16.png");

	public ImageSource VaporEmission_32 => GetImageSource("VaporEmission_32.png");

	public ImageSource VariableList_16 => GetImageSource("VariableList_16.png");

	public ImageSource VariableList_32 => GetImageSource("VariableList_32.png");

	public ImageSource Variables_24 => GetImageSource("Variables_24.png");

	public ImageSource VCRFirst_16 => GetImageSource("VCRFirst_16.png");

	public ImageSource VCRLast_16 => GetImageSource("VCRLast_16.png");

	public ImageSource VCRNext_16 => GetImageSource("VCRNext_16.png");

	public ImageSource VCRPause_16 => GetImageSource("VCRPause_16.png");

	public ImageSource VCRPrevious_16 => GetImageSource("VCRPrevious_16.png");

	public ImageSource VCRStop_16 => GetImageSource("VCRStop_16.png");

	public ImageSource Vent_16 => GetImageSource("Vent_16.png");

	public ImageSource Video_32 => GetImageSource("Video_32.png");

	public ImageSource ViewAllChanges_32 => GetImageSource("ViewAllChanges_32.png");

	public ImageSource ViewAllCommentsv2_32 => GetImageSource("ViewAllCommentsv2_32.png");

	public ImageSource ViewAllComments_32 => GetImageSource("ViewAllComments_32.png");

	public ImageSource ViewClose_11 => GetImageSource("ViewClose_11.png");

	public ImageSource ViewComments_16 => GetImageSource("ViewComments_16.png");

	public ImageSource ViewControlRecipe_16 => GetImageSource("ViewControlRecipe_16.png");

	public ImageSource ViewCurrent_16 => GetImageSource("ViewCurrent_16.png");

	public ImageSource ViewCurrent_Modified_16 => GetImageSource("ViewCurrent_Modified_16.png");

	public ImageSource ViewCurrent_Modified_Deleted_16 => GetImageSource("ViewCurrent_Modified_Deleted_16.png");

	public ImageSource ViewData_16 => GetImageSource("ViewData_16.png");

	public ImageSource ViewGrid_16 => GetImageSource("ViewGrid_16.png");

	public ImageSource ViewHomePagesAspenPlus_32 => GetImageSource("ViewHomePagesAspenPlus_32.png");

	public ImageSource ViewHomePagesTraining_32 => GetImageSource("ViewHomePagesTraining_32.png");

	public ImageSource ViewHomePagesVideoDemos_32 => GetImageSource("ViewHomePagesVideoDemos_32.png");

	public ImageSource ViewNewWindow_16 => GetImageSource("ViewNewWindow_16.png");

	public ImageSource ViewPackage_16 => GetImageSource("ViewPackage_16.png");

	public ImageSource ViewResults_16 => GetImageSource("ViewResults_16.png");

	public ImageSource ViewSettings_16 => GetImageSource("ViewSettings_16.png");

	public ImageSource ViewSettings_32 => GetImageSource("ViewSettings_32.png");

	public ImageSource ViewUpdateReadMe_32 => GetImageSource("ViewUpdateReadMe_32.png");

	public ImageSource WaitingForInput_11 => GetImageSource("WaitingForInput_11.png");

	public ImageSource Warning_16 => GetImageSource("Warning_16.png");

	public ImageSource WashCake_16 => GetImageSource("WashCake_16.png");

	public ImageSource WashColumn_16 => GetImageSource("WashColumn_16.png");

	public ImageSource WatchVideoDemosGetUpSpeed_32 => GetImageSource("WatchVideoDemosGetUpSpeed_32.png");

	public ImageSource WatchVideoDemosOverview_32 => GetImageSource("WatchVideoDemosOverview_32.png");

	public ImageSource WhatIf_32 => GetImageSource("WhatIf_32.png");

	public ImageSource WhatsNew_16 => GetImageSource("WhatsNew_16.png");

	public ImageSource WhatsNew_32 => GetImageSource("WhatsNew_32.png");

	public ImageSource WhatsThis_16 => GetImageSource("WhatsThis_16.png");

	public ImageSource WhatsThis_32 => GetImageSource("WhatsThis_32.png");

	public ImageSource White_16 => GetImageSource("White_16.png");

	public ImageSource White_32 => GetImageSource("White_32.png");

	public ImageSource Width_16 => GetImageSource("Width_16.png");

	public ImageSource WindowNew_16 => GetImageSource("WindowNew_16.png");

	public ImageSource WindowNew_32 => GetImageSource("WindowNew_32.png");

	public ImageSource WindowsArrange_32 => GetImageSource("WindowsArrange_32.png");

	public ImageSource WindowsCascade_16 => GetImageSource("WindowsCascade_16.png");

	public ImageSource Workflow_32 => GetImageSource("Workflow_32.png");

	public ImageSource WorkspaceWide_16 => GetImageSource("WorkspaceWide_16.png");

	public ImageSource WorkspaceWide_32 => GetImageSource("WorkspaceWide_32.png");

	public ImageSource YAxisMap_16 => GetImageSource("YAxisMap_16.png");

	public ImageSource YieldReact_16 => GetImageSource("YieldReact_16.png");

	public ImageSource Zoom100Pct_16 => GetImageSource("Zoom100Pct_16.png");

	public ImageSource Zoom100Pct_32 => GetImageSource("Zoom100Pct_32.png");

	public ImageSource ZoomFitToWindow_16 => GetImageSource("ZoomFitToWindow_16.png");

	public ImageSource ZoomIn_16 => GetImageSource("ZoomIn_16.png");

	public ImageSource ZoomIn_32 => GetImageSource("ZoomIn_32.png");

	public ImageSource ZoomOut_16 => GetImageSource("ZoomOut_16.png");

	public ImageSource ZoomOut_32 => GetImageSource("ZoomOut_32.png");

	public ImageSource ZoomPageWidth_16 => GetImageSource("ZoomPageWidth_16.png");

	public ImageSource ZoomSliderZoomToFit_16 => GetImageSource("ZoomSliderZoomToFit_16.png");

	public ImageSource ZoomToFit_16 => GetImageSource("ZoomToFit_16.png");

	public ImageSource ZoomToFit_32 => GetImageSource("ZoomToFit_32.png");

	public ImageSource ZoomView_16 => GetImageSource("ZoomView_16.png");

	public ImageSource Zoom_16 => GetImageSource("Zoom_16.png");

	public ImageSource Zoom_32 => GetImageSource("Zoom_32.png");


	public ImageSource GetCustomImageSource(string imageName, int? pixelHeight = null, int? bitsPerPixel = null)
	{
		string text = (imageName.EndsWith("_Icon", StringComparison.OrdinalIgnoreCase) ? (imageName + ".ico") : (imageName + ".png"));
		string fullName = Assembly.GetExecutingAssembly().FullName;
		string uriString = "pack://application:,,,/" + fullName + ";component/images/" + text;
		if (text.EndsWith(".ico", StringComparison.OrdinalIgnoreCase))
		{
			BitmapFrame bitmapFrame = BitmapFrame.Create(new Uri(uriString, UriKind.Absolute));
			if (bitmapFrame == null)
			{
				return null;
			}
			BitmapFrame bitmapFrame2 = null;
			{
				foreach (BitmapFrame frame in bitmapFrame.Decoder.Frames)
				{
					if (bitmapFrame2 == null)
					{
						bitmapFrame2 = frame;
						continue;
					}
					if (pixelHeight.HasValue)
					{
						if (frame.PixelHeight != pixelHeight)
						{
							continue;
						}
					}
					else if (frame.PixelHeight < bitmapFrame2.PixelHeight)
					{
						continue;
					}
					if (bitsPerPixel.HasValue)
					{
						int num = Math.Abs(bitmapFrame2.Format.BitsPerPixel - bitsPerPixel.Value);
						if (Math.Abs(frame.Format.BitsPerPixel - bitsPerPixel.Value) < num)
						{
							bitmapFrame2 = frame;
						}
					}
					else if (bitmapFrame2.Format.BitsPerPixel < frame.Format.BitsPerPixel)
					{
						bitmapFrame2 = frame;
					}
				}
				return bitmapFrame2;
			}
		}
		BitmapImage bitmapImage = new BitmapImage();
		bitmapImage.BeginInit();
		bitmapImage.UriSource = new Uri(uriString, UriKind.Absolute);
		if (pixelHeight.HasValue)
		{
			bitmapImage.DecodePixelHeight = pixelHeight.Value;
		}
		bitmapImage.EndInit();
		if (bitmapImage.CanFreeze)
		{
			bitmapImage.Freeze();
		}
		return bitmapImage;
	}
}
