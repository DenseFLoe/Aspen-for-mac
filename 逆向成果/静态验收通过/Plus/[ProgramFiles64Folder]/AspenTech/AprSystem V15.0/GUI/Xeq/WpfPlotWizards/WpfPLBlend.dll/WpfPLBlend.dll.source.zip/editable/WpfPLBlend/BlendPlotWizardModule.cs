using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLBlend;

[RibbonPlotWizardMgr("WpfPLBLEND.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class BlendPlotWizardModule : PlotModuleBase
{
}
