# Interop.MMLocal.dll IL 源码交付

Aspen V15.0 的 COM 互操作程序集。可编辑源为 [source.il](editable/source.il)，包含 118 个无方法体的运行时声明。资源为 [source.res](editable/source.res)。

在 editable 目录用 .NET Framework ILAsm 汇编。

    ilasm source.il /dll /quiet /resource=source.res /output=Interop.MMLocal.dll

重新导出安装原件的 IL 可用 .NET IL Disassembler 9.0.23。

    ildasm <installed-original.dll> /utf8 /typelist

[逐件核验](evidence/static-review.json)记录原件、实际汇编结果、语义比较、必要资源和汇编器指纹。original-build 目录保留原版 CLR 元数据、头和强名区域，供查核布局、物理元数据及原签名字段。直接汇编结果的 CLR 强名标志、证书、冗余元数据行和文件指纹存在差异。Windows 运行行为属于后续重建对照。
