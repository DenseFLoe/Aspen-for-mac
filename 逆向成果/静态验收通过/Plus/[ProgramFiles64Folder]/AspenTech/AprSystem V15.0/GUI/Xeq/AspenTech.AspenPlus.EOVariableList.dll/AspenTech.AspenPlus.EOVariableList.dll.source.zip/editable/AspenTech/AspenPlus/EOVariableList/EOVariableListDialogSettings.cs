using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Xml.Linq;
using AspenTech.AspenPlus.Infrastructure;

namespace AspenTech.AspenPlus.EOVariableList;

public static class EOVariableListDialogSettings
{
	private static List<string> _additionalColumnEngineNamesList;

	public static ReadOnlyCollection<string> AdditionalColumnEngineNames { get; private set; }

	public static readonly IEnumerable<string> MustColumnEngineNames;

	static EOVariableListDialogSettings()
	{
		_additionalColumnEngineNamesList = new List<string> { "UOM", "PHYSICAL_TYPE", "SPEC" };
		MustColumnEngineNames = new string[2] { "NAME", "VALUE" };
		AdditionalColumnEngineNames = new ReadOnlyCollection<string>(_additionalColumnEngineNamesList);
	}

	public static void InitializeSettings()
	{
		string eOSearchDialogSettings = CaseFileSettings.Default.EOSearchDialogSettings;
		if (!string.IsNullOrEmpty(eOSearchDialogSettings))
		{
			XElement xElement = null;
			try
			{
				xElement = XElement.Parse(eOSearchDialogSettings);
			}
			catch
			{
			}
			if (xElement != null)
			{
				InitializeColumnEngineNames(xElement);
			}
		}
	}

	public static void SaveSettings()
	{
		string text = CaseFileSettings.Default.EOSearchDialogSettings;
		if (string.IsNullOrEmpty(text))
		{
			text = "<settings/>";
		}
		XElement xElement = null;
		try
		{
			xElement = XElement.Parse(text);
		}
		catch
		{
		}
		if (xElement == null)
		{
			xElement = new XElement("settings");
		}
		SaveColumnEngineNames(xElement);
		CaseFileSettings.Default.EOSearchDialogSettings = xElement.ToString();
	}

	public static void UpdateVisibleColumns(IEnumerable<string> columnEngineNames)
	{
		if (columnEngineNames == null)
		{
			throw new ArgumentNullException("columnEngineNames");
		}
		_additionalColumnEngineNamesList.Clear();
		foreach (string columnEngineName in columnEngineNames)
		{
			TryAppendAdditionalColumn(columnEngineName);
		}
	}

	private static void InitializeColumnEngineNames(XElement root)
	{
		_additionalColumnEngineNamesList.Clear();
		XElement xElement = root.Element("Columns");
		if (xElement != null)
		{
			foreach (XElement item in xElement.Elements("Column"))
			{
				TryAppendAdditionalColumn(item.Value);
			}
		}
	}

	private static void SaveColumnEngineNames(XElement root)
	{
		XElement xElement = root.Element("Columns");
		if (xElement == null)
		{
			xElement = new XElement("Columns");
			root.Add(xElement);
		}
		xElement.RemoveNodes();
		foreach (string additionalColumnEngineNames in _additionalColumnEngineNamesList)
		{
			xElement.Add(new XElement("Column", additionalColumnEngineNames));
		}
	}

	private static void TryAppendAdditionalColumn(string columnEngineName)
	{
		if (string.IsNullOrEmpty(columnEngineName))
		{
			return;
		}
		if (MustColumnEngineNames.Contains(columnEngineName))
		{
			return;
		}
		if (_additionalColumnEngineNamesList.Contains(columnEngineName))
		{
			return;
		}
		_additionalColumnEngineNamesList.Add(columnEngineName);
	}
}
