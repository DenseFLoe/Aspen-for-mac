# SummaryGrid IL 源码与静态验收证据

从可编辑 IL 和原始版本资源构建。复现需要 Python、pefile 和 .NET Framework ILAsm。

    py -3 rebuild.py --ilasm <path-to-ilasm.exe> --output <new-output-directory>

IL 源码保留原始声明、程序集调试属性和方法头的局部变量初始化标志。ILAsm 在两个无方法体的 COM 虚表占位声明上自动增加 abstract 和 virtual 标志。构建脚本按 IL 声明将这两行恢复到原标志，保留可编辑源码所生成的全部方法体。

逐件比较覆盖 200 个方法定义、187 个 CIL 方法体、13 个无体声明、22 个异常处理区、21 个程序集引用，以及类型、属性、字段、事件和版本资源。二进制回编用于静态核对，运行行为留待 Windows 重建对照。

- [源码修订记录](evidence/source-lineage.json)
- [逐方法及结构比较](evidence/static-comparison.json)
- [独立复验记录](evidence/independent-review.json)
