# -*- coding: utf-8 -*-
"""Assemble the base package (build-plan + verified candidate + original CLR assets).

Usage: make_base_pkg.py <original.dll> <compiled.dll> <out.zip>
"""
import json
import struct
import sys
import zipfile
from hashlib import sha256
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
sys.path.insert(0, str(BASE / "router" / "work" / "m-near-partial" / "axil" / "df5c39b2"))
sys.path.insert(0, str(Path(r"C:\temp\d70\dftools")))
sys.path.insert(0, str(BASE / "router" / "managed"))
import pe_layout2 as pe_layout


def main(original_path, compiled_path, out_zip):
    original = Path(original_path).read_bytes()
    compiled = Path(compiled_path).read_bytes()
    pe, info = pe_layout.identified_image(original)
    cli = pe.OPTIONAL_HEADER.DATA_DIRECTORY[14]
    clr = original[pe.get_offset_from_rva(cli.VirtualAddress):][:72]
    md_rva, md_size = struct.unpack_from("<II", clr, 8)
    metadata = original[pe.get_offset_from_rva(md_rva):][:md_size]
    debug = pe_layout.debug_tail(original, pe)
    cert = pe.OPTIONAL_HEADER.DATA_DIRECTORY[4]
    certificate = original[cert.VirtualAddress:cert.VirtualAddress + cert.Size]
    name = Path(original_path).name
    plan = {
        "assembly_name": name,
        "original_sha256": sha256(original).hexdigest(),
        "build_input_sha256": {},
        "tool_path": {},
        "source": "IL-source reassembly: candidate is ilasm 4.0.30319 output of the "
                  "C#-compiled candidate's ildasm text with OnViewChanged's body taken "
                  "from the original ildasm text, then InitLocals restored",
    }
    members = {
        "build-plan.json": (json.dumps(plan, ensure_ascii=False, indent=1) + "\n").encode(),
        "compiled/" + name: compiled,
        "original-build/clr-metadata.bin": metadata,
        "original-build/clr-header.bin": clr,
        "original-build/debug-record.bin": debug,
        "original-build/certificate-table.bin": certificate,
    }
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for member in sorted(members):
            z.writestr(member, members[member])
    print(json.dumps({"package": out_zip, "sha256": sha256(Path(out_zip).read_bytes()).hexdigest(),
                      "members": {k: len(v) for k, v in members.items()}}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:4]))
