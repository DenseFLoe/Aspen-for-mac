using System;
using System.ComponentModel;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using AdvancedFileDialogLib;

[assembly: AxHost.TypeLibraryTimeStamp("04/14/2025 09:07:36")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: AssemblyKeyFile("..\\packages\\AspenTech.StrongName.SNK.1.0.0\\content\\Aspentech.snk")]
[assembly: CompilationRelaxations(8)]
[assembly: AssemblyVersion("10.0.0.0")]
namespace AxAdvancedFileDialogLib;

[DesignTimeVisible(true)]
[Clsid("{69b0d734-9006-44aa-80d4-9ec38d048173}")]
public class AxAdvancedFileDialog : AxHost
{
	private _DAdvancedFileDialog ocx;

	private AxAdvancedFileDialogEventMulticaster eventMulticaster;

	private ConnectionPointCookie cookie;

	public AxAdvancedFileDialog()
		: base("69b0d734-9006-44aa-80d4-9ec38d048173")
	{
		SetAboutBoxDelegate(AboutBox);
	}

	public virtual void AboutBox()
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("AboutBox", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.AboutBox();
	}

	public virtual int ShowOpenFileDialog(int bShowHierarchy)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("ShowOpenFileDialog", ActiveXInvokeKind.MethodInvoke);
		}
		return ocx.ShowOpenFileDialog(bShowHierarchy);
	}

	public virtual int ShowSaveFileDialog(int bShowHierarchy)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("ShowSaveFileDialog", ActiveXInvokeKind.MethodInvoke);
		}
		return ocx.ShowSaveFileDialog(bShowHierarchy);
	}

	public virtual void SetFileName(string lpszFileName)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("SetFileName", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.SetFileName(lpszFileName);
	}

	public virtual void SetFilter(string lpszFilter)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("SetFilter", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.SetFilter(lpszFilter);
	}

	public virtual string GetFileName()
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("GetFileName", ActiveXInvokeKind.MethodInvoke);
		}
		return ocx.GetFileName();
	}

	public virtual void SetInitialDir(string lpszInitialDir)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("SetInitialDir", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.SetInitialDir(lpszInitialDir);
	}

	public virtual int GetFilterIndex()
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("GetFilterIndex", ActiveXInvokeKind.MethodInvoke);
		}
		return ocx.GetFilterIndex();
	}

	public virtual string GetPathName()
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("GetPathName", ActiveXInvokeKind.MethodInvoke);
		}
		return ocx.GetPathName();
	}

	public virtual void SetTitle(string lpszTitle)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("SetTitle", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.SetTitle(lpszTitle);
	}

	public virtual string GetHierarchyName()
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("GetHierarchyName", ActiveXInvokeKind.MethodInvoke);
		}
		return ocx.GetHierarchyName();
	}

	public virtual void AddHierarchy(string lpszHierarchy)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("AddHierarchy", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.AddHierarchy(lpszHierarchy);
	}

	public virtual void SetProductType(int iProductType)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("SetProductType", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.SetProductType(iProductType);
	}

	public virtual void SetImportOrExportPrompt(string lpszImportOrExportPrompt)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("SetImportOrExportPrompt", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.SetImportOrExportPrompt(lpszImportOrExportPrompt);
	}

	public virtual void SetFavoritesPath(string lpszFavoritesPath)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("SetFavoritesPath", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.SetFavoritesPath(lpszFavoritesPath);
	}

	public virtual void SetChangeDir(int bChangeDir)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("SetChangeDir", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.SetChangeDir(bChangeDir);
	}

	public virtual void SetFilterIndex(int iFilterIndex)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("SetFilterIndex", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.SetFilterIndex(iFilterIndex);
	}

	public virtual void SetDefaultExt(string lpszDefaultExt)
	{
		if (ocx == null)
		{
			throw new InvalidActiveXStateException("SetDefaultExt", ActiveXInvokeKind.MethodInvoke);
		}
		ocx.SetDefaultExt(lpszDefaultExt);
	}

	protected override void CreateSink()
	{
		try
		{
			eventMulticaster = new AxAdvancedFileDialogEventMulticaster(this);
			cookie = new ConnectionPointCookie(ocx, eventMulticaster, typeof(_DAdvancedFileDialogEvents));
		}
		catch (Exception)
		{
		}
	}

	protected override void DetachSink()
	{
		try
		{
			cookie.Disconnect();
		}
		catch (Exception)
		{
		}
	}

	protected override void AttachInterfaces()
	{
		try
		{
			ocx = (_DAdvancedFileDialog)GetOcx();
		}
		catch (Exception)
		{
		}
	}
}
[ClassInterface(ClassInterfaceType.None)]
public class AxAdvancedFileDialogEventMulticaster : _DAdvancedFileDialogEvents
{
	private AxAdvancedFileDialog parent;

	public AxAdvancedFileDialogEventMulticaster(AxAdvancedFileDialog parent)
	{
		this.parent = parent;
	}
}
