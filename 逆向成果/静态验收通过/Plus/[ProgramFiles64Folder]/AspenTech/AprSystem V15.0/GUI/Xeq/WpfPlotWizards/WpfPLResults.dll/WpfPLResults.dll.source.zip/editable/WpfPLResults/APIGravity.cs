using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPlotwizard;

namespace WpfPLResults;

[ProgId("WpfPLResults.APIGravity")]
public class APIGravity : IRibbonPlotWizardType
{
	private IHNode _context;

	private IHWizardPlot _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper("PlotWiz.hlp", 295L);

	private string _uniqueId = "Results_APIGravity";

	private string _plotName;

	private object _nodeCxs;

	private Image _imgIcon;

	private bool _bHasInputDialog;

	private bool _bCheckDataOnly;

	public string TooltipContentForRibbonItem => WpfPLResultsResources.TooltipContentForRibbonItem_API_Gravity;

	public string TooltipHeaderForRibbonItem => WpfPLResultsResources.TooltipHeaderForRibbonItem_API_Gravity;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	Image IRibbonPlotWizardType.ImageIcon => _imgIcon;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string>();

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public APIGravity()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Expected O, but got Unknown
		_bHasInputDialog = false;
		if (_imgIcon == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLResults.Images.BinaryTX.ico");
			_imgIcon = new Bitmap(manifestResourceStream);
		}
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot;
		string path = "PetroCharacterization/Results/Output/COMP_NAMES";
		IHNode iHNode = _context.FindNode(path);
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		path = "PetroCharacterization/Results/Output/API";
		_wizardPlot.RemoveAllDependentVariable();
		_wizardPlot.AddDependentVariable(_context, path);
	}

	public void UpdateWizardData()
	{
		string depvar = "PetroCharacterization/Results/Output/API";
		_wizardPlot.RemoveAllDependentVariable();
		_wizardPlot.AddDependentVariable(_context, depvar);
	}
}
