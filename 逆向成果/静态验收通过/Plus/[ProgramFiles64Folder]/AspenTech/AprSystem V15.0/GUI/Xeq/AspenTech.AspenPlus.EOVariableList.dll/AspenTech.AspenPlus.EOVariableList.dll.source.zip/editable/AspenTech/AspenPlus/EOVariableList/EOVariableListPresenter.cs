using System;
using System.Windows;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.WpfControls.Engineering;

namespace AspenTech.AspenPlus.EOVariableList;

public class EOVariableListPresenter : DependencyObject, IEOVariableListPresenter
{
	public static readonly DependencyProperty VariableListManagerProperty = DependencyProperty.RegisterAttached("VariableListManager", typeof(EOVariableListExecuteManager), typeof(EOVariableListPresenter));

	private readonly IApwnApplication _application;

	public static EOVariableListExecuteManager GetVariableListManager(AesXamValueEdit editor)
	{
		if (editor == null)
		{
			throw new ArgumentNullException("editor");
		}
		return (EOVariableListExecuteManager)editor.GetValue(VariableListManagerProperty);
	}

	public static void SetVariableListManager(AesXamValueEdit editor, EOVariableListExecuteManager value)
	{
		if (editor == null)
		{
			throw new ArgumentNullException("editor");
		}
		editor.SetValue(VariableListManagerProperty, (object)value);
	}

	public EOVariableListPresenter(IApwnApplication application)
	{
		if (application == null)
		{
			throw new ArgumentNullException("application");
		}
		_application = application;
	}

	public bool CanExecuteListVariables(UIElement inputElement, bool isUpdateRequired = false)
	{
		if (inputElement is AesXamValueEdit editor)
		{
			EOVariableListExecuteManager eOVariableListExecuteManager = ResolveVarListManager(editor);
			if (isUpdateRequired)
			{
				eOVariableListExecuteManager.RefreshDefaultObjectType();
			}
			return eOVariableListExecuteManager.CanExecuteListVariables();
		}
		return false;
	}

	public bool? ExecuteListVariables(UIElement inputElement)
	{
		if (inputElement is AesXamValueEdit editor)
		{
			return ResolveVarListManager(editor).ExecuteListVariables();
		}
		return false;
	}

	private EOVariableListExecuteManager ResolveVarListManager(AesXamValueEdit editor)
	{
		EOVariableListExecuteManager eOVariableListExecuteManager = GetVariableListManager(editor);
		if (eOVariableListExecuteManager == null)
		{
			eOVariableListExecuteManager = new EOVariableListExecuteManager(_application, editor);
			SetVariableListManager(editor, eOVariableListExecuteManager);
		}
		return eOVariableListExecuteManager;
	}
}
