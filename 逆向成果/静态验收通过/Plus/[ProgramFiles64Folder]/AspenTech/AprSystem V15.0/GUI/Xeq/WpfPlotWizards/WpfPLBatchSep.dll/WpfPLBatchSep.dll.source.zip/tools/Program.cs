using System.Buffers.Binary;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;

if (args.Length != 3)
    throw new ArgumentException("Usage: Patch <ilasm DLL> <output DLL> <method intent JSON | ->");

byte[] data = File.ReadAllBytes(args[0]);
using var pe = new PEReader(new MemoryStream(data, false));
var headers = pe.PEHeaders;
var md = pe.GetMetadataReader();
int metadata = headers.MetadataStartOffset;
int BlobOffset(BlobHandle blob) => metadata + md.GetHeapMetadataOffset(HeapIndex.Blob)
    + MetadataTokens.GetHeapOffset(blob);
ushort U16(int at) => BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(at, 2));
void Put16(int at, ushort value) => BinaryPrimitives.WriteUInt16LittleEndian(data.AsSpan(at, 2), value);
void Require(bool test, string detail)
{
    if (!test) throw new InvalidDataException(detail);
}

int init = 0;
int vtable = 0;
int debugAttribute = 0;
int parameterNames = 0;
if (args[2] != "-")
{
    var intent = JsonSerializer.Deserialize<MethodIntent>(File.ReadAllText(args[2]))
        ?? throw new InvalidDataException("Missing IL method intent.");
    var methods = md.TypeDefinitions.SelectMany(typeHandle =>
    {
        var t = md.GetTypeDefinition(typeHandle);
        var owner = md.GetString(t.Namespace) + "." + md.GetString(t.Name);
        return t.GetMethods().Select(mh => (Handle: mh, Method: md.GetMethodDefinition(mh)))
            .Select(m => (Key: owner + "::" + md.GetString(m.Method.Name), m.Handle, m.Method, Owner: t));
    }).ToLookup(item => item.Key, StringComparer.Ordinal);
    var initSet = new HashSet<string>(StringComparer.Ordinal);
    foreach (string key in intent.InitLocals)
    {
        Require(initSet.Add(key), "Duplicate InitLocals intent: " + key);
        var row = methods[key].Single();
        int rva = row.Method.RelativeVirtualAddress;
        var body = pe.GetMethodBody(rva);
        Require(rva != 0 && body.LocalSignature.IsNil, "Expected an emitted body without locals: " + key);
        if (body.LocalVariablesInitialized) continue;
        Require(headers.TryGetDirectoryOffset(new DirectoryEntry(rva, 2), out int offset), "Method RVA: " + key);
        Require((U16(offset) & 0xF013) == 0x3003, "Expected fat body and clear InitLocals: " + key);
        Put16(offset, (ushort)(U16(offset) | 0x0010));
        init++;
    }
    var gapSet = new HashSet<string>(StringComparer.Ordinal);
    foreach (string key in intent.ComGaps)
    {
        Require(gapSet.Add(key), "Duplicate COM gap: " + key);
        var row = methods[key].Single();
        const System.Reflection.TypeAttributes comInterface =
            System.Reflection.TypeAttributes.Interface | System.Reflection.TypeAttributes.Import;
        Require((row.Owner.Attributes & comInterface) == comInterface
            && md.GetString(row.Method.Name).StartsWith("_VtblGap", StringComparison.Ordinal)
            && row.Method.RelativeVirtualAddress == 0 && (int)row.Method.ImplAttributes == 3,
            "Expected an embedded COM interface runtime slot gap: " + key);
        int at = metadata + md.GetTableMetadataOffset(TableIndex.MethodDef)
            + (MetadataTokens.GetRowNumber(row.Handle) - 1) * md.GetTableRowSize(TableIndex.MethodDef) + 6;
        Require(U16(at) == 0x1C46, "Unexpected flags for generated COM gap: " + key);
        Put16(at, 0x1806);
        vtable++;
    }

    var emptyNames = new HashSet<string>(StringComparer.Ordinal);
    foreach (string key in intent.EmptyLastParameterNames)
    {
        Require(emptyNames.Add(key), "Duplicate empty parameter name correction: " + key);
        var row = methods[key].Single();
        Require(row.Method.RelativeVirtualAddress == 0 && (int)row.Method.ImplAttributes == 0x1003,
            "Expected an embedded COM runtime setter: " + key);
        var parameter = row.Method.GetParameters().Last();
        var definition = md.GetParameter(parameter);
        Require(definition.SequenceNumber == 4 && md.GetString(definition.Name) == "A_3"
            && (int)definition.Attributes == 0x2001, "Unexpected generated COM parameter: " + key);
        int rowSize = md.GetTableRowSize(TableIndex.Param);
        int at = metadata + md.GetTableMetadataOffset(TableIndex.Param)
            + (MetadataTokens.GetRowNumber(parameter) - 1) * rowSize + 4;
        data.AsSpan(at, rowSize - 4).Clear();
        parameterNames++;
    }

    var debug = md.GetAssemblyDefinition().GetCustomAttributes().Select(md.GetCustomAttribute).Single(attribute =>
    {
        if (attribute.Constructor.Kind != HandleKind.MemberReference) return false;
        var ctor = md.GetMemberReference((MemberReferenceHandle)attribute.Constructor);
        if (ctor.Parent.Kind != HandleKind.TypeReference || md.GetString(ctor.Name) != ".ctor") return false;
        var type = md.GetTypeReference((TypeReferenceHandle)ctor.Parent);
        return md.GetString(type.Namespace) == "System.Diagnostics"
            && md.GetString(type.Name) == "DebuggableAttribute";
    });
    byte[] expected = [1, 0, 3, 0, 0, 0, 0, 0];
    Require(md.GetBlobBytes(debug.Value).AsSpan().SequenceEqual(expected), "Unexpected ILAsm debug attribute.");
    int blobOffset = BlobOffset(debug.Value);
    Require(data[blobOffset] == 8, "Unexpected debug blob length.");
    data[blobOffset + 3] = 2;
    debugAttribute++;
}

int coff = headers.CoffHeaderStartOffset;
int optional = coff + 20;
int directories = optional + (headers.PEHeader!.Magic == PEMagic.PE32 ? 96 : 112);
var debugTable = headers.PEHeader.DebugTableDirectory;
if (debugTable.Size != 0)
{
    foreach (var record in pe.ReadDebugDirectory())
    {
        Require(record.DataSize == 0 || record.DataPointer > 0, "Invalid debug record.");
        data.AsSpan(record.DataPointer, record.DataSize).Clear();
    }
    Require(headers.TryGetDirectoryOffset(debugTable, out int table), "Invalid debug directory.");
    data.AsSpan(table, debugTable.Size).Clear();
    data.AsSpan(directories + 6 * 8, 8).Clear();
}
data.AsSpan(coff + 4, 4).Clear();      // COFF timestamp
data.AsSpan(optional + 64, 4).Clear(); // PE checksum
int guid = metadata + md.GetHeapMetadataOffset(HeapIndex.Guid)
    + 16 * (MetadataTokens.GetHeapOffset(md.GetModuleDefinition().Mvid) - 1);
data.AsSpan(guid, 16).Clear();
SHA256.HashData(data).AsSpan(0, 16).CopyTo(data.AsSpan(guid, 16));
File.WriteAllBytes(args[1], data);
Console.WriteLine(JsonSerializer.Serialize(new { initLocals = init, comGapFlags = vtable, debuggableMode = debugAttribute, emptyParameterNames = parameterNames }));

record MethodIntent(string[] InitLocals, string[] ComGaps, string[] EmptyLastParameterNames);
