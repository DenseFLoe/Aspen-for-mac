using System.Text.Json;
using System.Security.Cryptography;
using Mono.Cecil;
using Mono.Cecil.Cil;

static class Audit
{
    static readonly JsonSerializerOptions Print = new() { WriteIndented = true };
    static string Json(object value) => JsonSerializer.Serialize(value);
    static string Sha(byte[] value) => Convert.ToHexString(SHA256.HashData(value)).ToLowerInvariant();
    static string Scope(IMetadataScope scope) => scope switch
    {
        AssemblyNameReference assembly => assembly.FullName,
        ModuleDefinition => "self",
        ModuleReference module => module.Name,
        _ => ""
    };

    static string T(TypeReference type)
    {
        return type switch
        {
            null => "",
            GenericParameter p => (p.Type == GenericParameterType.Method ? "!!" : "!") + p.Position,
            GenericInstanceType g => T(g.ElementType) + "<" + Join(g.GenericArguments.Select(T)) + ">",
            OptionalModifierType m => T(m.ElementType) + " modopt(" + T(m.ModifierType) + ")",
            RequiredModifierType m => T(m.ElementType) + " modreq(" + T(m.ModifierType) + ")",
            ArrayType a => T(a.ElementType) + "[" + Join(a.Dimensions) + "]",
            FunctionPointerType f => "fp(" + Signature(f) + ")",
            TypeSpecification s => s.GetType().Name + "(" + T(s.ElementType) + ")",
            _ => "[" + Scope(type.Scope) + "]" + type.FullName
        };
    }

    static string Join<A>(IEnumerable<A> values) => string.Join("|", values);
    static string Signature(IMethodSignature s) =>
        Json(new { s.HasThis, s.ExplicitThis, convention = (int)s.CallingConvention,
            returns = T(s.ReturnType), args = s.Parameters.Select(p => T(p.ParameterType)).ToArray() });
    static string M(MethodReference method)
    {
        if (method == null) return "";
        if (method is GenericInstanceMethod g)
            return M(g.ElementMethod) + "<" + Join(g.GenericArguments.Select(T)) + ">";
        return T(method.DeclaringType) + "::" + method.Name + "'" +
            method.GenericParameters.Count + ":" + Signature(method);
    }
    static string F(FieldReference field) => T(field.DeclaringType) + "::" + field.Name + ":" + T(field.FieldType);
    static string[] Attributes(ICustomAttributeProvider p) => p.CustomAttributes
        .Select(a => M(a.Constructor) + "=" + Convert.ToHexString(a.GetBlob()))
        .Order(StringComparer.Ordinal).ToArray();
    static string[] Security(ISecurityDeclarationProvider p) => p.SecurityDeclarations
        .Select(d => d.Action + "=" + Convert.ToHexString(d.GetBlob()))
        .Order(StringComparer.Ordinal).ToArray();
    static object[] Generics(IGenericParameterProvider p) => p.GenericParameters
        .Select(g => (object)new { g.Name, attrs = (int)g.Attributes,
            constraints = g.Constraints.Select(c => new { type = T(c.ConstraintType), attributes = Attributes(c) }).ToArray(),
            attributes = Attributes(g) }).ToArray();

    static object Marshal(MarshalInfo m) => m switch
    {
        ArrayMarshalInfo a => new { a.NativeType, a.ElementType, a.Size, a.SizeParameterIndex, a.SizeParameterMultiplier },
        CustomMarshalInfo a => new { a.NativeType, a.Guid, a.UnmanagedType, managedType = T(a.ManagedType), a.Cookie },
        FixedArrayMarshalInfo a => new { a.NativeType, a.ElementType, a.Size },
        FixedSysStringMarshalInfo a => new { a.NativeType, a.Size },
        SafeArrayMarshalInfo a => new { a.NativeType, a.ElementType },
        null => null,
        _ => new { m.NativeType }
    };

    static object Param(ParameterDefinition p) => new
    {
        p.Name, flags = (int)p.Attributes, type = T(p.ParameterType), p.HasConstant, p.Constant,
        marshal = Marshal(p.MarshalInfo), attributes = Attributes(p)
    };

    static object Operand(object x) => x switch
    {
        Instruction b => b.Offset,
        Instruction[] arms => arms.Select(a => a.Offset).ToArray(),
        VariableReference v => v.Index,
        ParameterReference p => p.Index,
        MethodReference m => M(m),
        FieldReference f => F(f),
        TypeReference t => T(t),
        CallSite c => Signature(c),
        double d => "double:" + BitConverter.DoubleToInt64Bits(d).ToString("x16"),
        float f => "float:" + BitConverter.SingleToInt32Bits(f).ToString("x8"),
        _ => x
    };

    static object Body(MethodDefinition m, bool includeInit, bool includeStack)
    {
        if (!m.HasBody) return null;
        var body = m.Body;
        return new {
            init = includeInit && body.InitLocals,
            stack = includeStack ? body.MaxStackSize : 0,
            locals = body.Variables.Select(v => T(v.VariableType)).ToArray(),
            instructions = body.Instructions.Select(i => new { i.Offset, op = i.OpCode.Name, arg = Operand(i.Operand) }).ToArray(),
            handlers = body.ExceptionHandlers.Select(e => new { type = (int)e.HandlerType,
                start = e.TryStart?.Offset, end = e.TryEnd?.Offset ?? body.CodeSize,
                handler = e.HandlerStart?.Offset, handEnd = e.HandlerEnd?.Offset ?? body.CodeSize,
                filter = e.FilterStart?.Offset, catchType = T(e.CatchType) }).ToArray()
        };
    }

    static object Definition(MethodDefinition m)
    {
        var r = m.MethodReturnType;
        return new {
            key = M(m), flags = (int)m.Attributes, impl = (int)m.ImplAttributes,
            semantics = (int)m.SemanticsAttributes, attributes = Attributes(m), security = Security(m),
            generics = Generics(m), overrides = m.Overrides.Select(M).Order(StringComparer.Ordinal).ToArray(),
            returns = new { r.Name, flags = (int)r.Attributes, r.HasConstant, r.Constant,
                marshal = Marshal(r.MarshalInfo), attributes = Attributes(r) },
            parameters = m.Parameters.Select(Param).ToArray(), pinvoke = !m.HasPInvokeInfo ? null : new {
                module = m.PInvokeInfo.Module.Name, m.PInvokeInfo.EntryPoint, flags = (int)m.PInvokeInfo.Attributes}
        };
    }

    static object Resource(Resource r) => r switch
    {
        EmbeddedResource e => new { flags = (int)r.Attributes, sha256 = Sha(e.GetResourceData()) },
        LinkedResource l => new { flags = (int)r.Attributes, l.File, hash = Convert.ToHexString(l.Hash) },
        AssemblyLinkedResource a => new { flags = (int)r.Attributes, assembly = a.Assembly.FullName },
        _ => throw new InvalidOperationException(r.Name)
    };

    static Dictionary<string, object> Overview(ModuleDefinition module)
    {
        var info = new Dictionary<string, object>(StringComparer.Ordinal);
        void Add(string key, object value) => info.Add(key, value);
        Add("module", new { module.Name, runtime = module.RuntimeVersion, flags = (int)module.Attributes,
            arch = (int)module.Architecture, kind = (int)module.Kind, entry = M(module.EntryPoint),
            attributes = Attributes(module) });
        Add("assembly", new { module.Assembly.Name.FullName, flags = (int)module.Assembly.Name.Attributes,
            hash = (int)module.Assembly.Name.HashAlgorithm, attributes = Attributes(module.Assembly),
            security = Security(module.Assembly) });
        foreach (var a in module.AssemblyReferences)
            Add("reference:" + a.Name, new { a.FullName, flags = (int)a.Attributes,
                hash = Convert.ToHexString(a.Hash ?? []), hashAlgorithm = (int)a.HashAlgorithm });
        foreach (var r in module.Resources) Add("resource:" + r.Name, Resource(r));
        foreach (var e in module.ExportedTypes)
            Add("export:" + e.FullName, new {flags = (int)e.Attributes, scope = Scope(e.Scope)});
        foreach (var p in module.ModuleReferences) Add("modref:" + p.Name, "");
        foreach (var t in module.GetTypes())
        {
            Add("type:" + t.FullName, new { flags = (int)t.Attributes, parent = T(t.BaseType),
                t.ClassSize, t.PackingSize, attributes = Attributes(t), security = Security(t),
                generics = Generics(t), interfaces = t.Interfaces.Select(i => new {
                    type = T(i.InterfaceType), attributes = Attributes(i) }).ToArray() });
            if (t.IsInterface || t.IsExplicitLayout || t.IsSequentialLayout)
                Add("order:" + t.FullName, new { fields = t.Fields.Select(F).ToArray(),
                    methods = t.Methods.Select(M).ToArray() });
            foreach (var f in t.Fields)
                Add("field:" + f.FullName, new { key = F(f), flags = (int)f.Attributes,
                    f.Offset, f.HasConstant, f.Constant, marshal = Marshal(f.MarshalInfo),
                    data = Convert.ToHexString(f.InitialValue), attributes = Attributes(f) });
            foreach (var p in t.Properties)
                Add("property:" + p.FullName, new { flags = (int)p.Attributes, type = T(p.PropertyType),
                    p.HasThis, p.HasConstant, p.Constant, attributes = Attributes(p),
                    parameters = p.Parameters.Select(Param).ToArray(), get = M(p.GetMethod), set = M(p.SetMethod),
                    others = p.OtherMethods.Select(M).Order(StringComparer.Ordinal).ToArray() });
            foreach (var e in t.Events)
                Add("event:" + e.FullName, new { flags = (int)e.Attributes, type = T(e.EventType),
                    attributes = Attributes(e), add = M(e.AddMethod), remove = M(e.RemoveMethod),
                    invoke = M(e.InvokeMethod), others = e.OtherMethods.Select(M).Order(StringComparer.Ordinal).ToArray() });
        }
        return info;
    }

    public static void Main(string[] args)
    {
        using var a = ModuleDefinition.ReadModule(args[0]);
        using var b = ModuleDefinition.ReadModule(args[1]);
        var old = a.GetTypes().SelectMany(t => t.Methods).ToDictionary(m => m.FullName);
        var fresh = b.GetTypes().SelectMany(t => t.Methods).ToDictionary(m => m.FullName);
        var defs = new List<object>();
        var bodies = new List<object>();
        var init = new List<object>();
        var stack = new List<object>();
        foreach (var (key, left) in old)
        {
            if (!fresh.TryGetValue(key, out var right)) continue;
            var oldDef = Definition(left);
            var newDef = Definition(right);
            if (Json(oldDef) != Json(newDef)) defs.Add(new {
                name = key, originalToken = left.MetadataToken.ToInt32(), outputToken = right.MetadataToken.ToInt32(),
                oldDef, newDef
            });
            if (Json(Body(left, false, false)) != Json(Body(right, false, false)))
                bodies.Add(new { name = key, original = Body(left, false, false), candidate = Body(right, false, false) });
            if (!left.HasBody || !right.HasBody) continue;
            if (left.Body.InitLocals != right.Body.InitLocals)
                init.Add(new { name = key, value = left.Body.InitLocals, actual = right.Body.InitLocals,
                    originalToken = left.MetadataToken.ToInt32(), outputToken = right.MetadataToken.ToInt32(), rva = right.RVA, originalRva = left.RVA, locals = left.Body.Variables.Count });
            if (left.Body.MaxStackSize != right.Body.MaxStackSize)
                stack.Add(new { name = key, value = left.Body.MaxStackSize, actual = right.Body.MaxStackSize });
        }
        var original = Overview(a);
        var candidate = Overview(b);
        var diffs = original.Keys.Concat(candidate.Keys).Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal)
            .Where(k => !original.ContainsKey(k) || !candidate.ContainsKey(k) || Json(original[k]) != Json(candidate[k]))
            .Select(k => new { key = k, original = original.GetValueOrDefault(k), candidate = candidate.GetValueOrDefault(k) });
        var result = new {
            original_count = old.Count, candidate_count = fresh.Count,
            original_with_body = old.Values.Count(m => m.HasBody), candidate_with_body = fresh.Values.Count(m => m.HasBody),
            eh_clauses = old.Values.Where(m => m.HasBody).Sum(m => m.Body.ExceptionHandlers.Count),
            instruction_count = old.Values.Where(m => m.HasBody).Sum(m => m.Body.Instructions.Count),
            original_overview_count = original.Count, candidate_overview_count = candidate.Count,
            original_overview_keys = original.Keys.GroupBy(k => k.Split(':')[0]).ToDictionary(k => k.Key, v => v.Count()),
            only_original = old.Keys.Except(fresh.Keys), only_candidate = fresh.Keys.Except(old.Keys),
            body_differences_without_init_and_stack = bodies, definition_differences = defs,
            init_differences = init, stack_differences = stack, overview_differences = diffs
        };
        File.WriteAllText(args[2], JsonSerializer.Serialize(result, Print));
    }
}
