# HeaterConverter.cs

Source: editable/HeatExchanger/HeaterConverter.cs

Source SHA-256: d771eb3f30ea2f586f0d5e6b838151326329e4e63ed00e5d54116a75fed8ccde
