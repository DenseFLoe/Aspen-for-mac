# -*- coding: utf-8 -*-
"""Per-MethodDef body comparison between two managed images.

Usage: compare_bodies_local.py <a.dll> <b.dll>
Pairs MethodDefs by (owner TypeDef full name, method name, signature blob) and
reports equal / differing / only counts, plus first-difference details.
"""
import sys
from hashlib import sha256
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
sys.path.insert(0, str(BASE / "router" / "managed"))
import clr_meta


def rows(data):
    pe, cli, root = clr_meta.read_image(data)
    out = []
    tcount = root["tables"]["rows"].get(0x02, 0)
    names = {}
    nested = {}
    for i in range(1, tcount + 1):
        r = clr_meta.read_row(root["bytes"], root["tables"], 0x02, i)
        names[i] = (clr_meta.strings(pe, cli, root, r[2]), clr_meta.strings(pe, cli, root, r[1]))
    for i in range(1, root["tables"]["rows"].get(0x29, 0) + 1):
        r = clr_meta.read_row(root["bytes"], root["tables"], 0x29, i)
        nested[r[0]] = r[1]

    def tkey(i):
        if i in nested:
            return tkey(nested[i]) + "/" + names[i][1]
        ns, n = names[i]
        return (ns + "." if ns else "") + n

    owners = {}
    total = root["tables"]["rows"].get(0x06, 0)
    for t in range(1, tcount + 1):
        start = clr_meta.read_row(root["bytes"], root["tables"], 0x02, t)[5]
        end = (clr_meta.read_row(root["bytes"], root["tables"], 0x02, t + 1)[5]
               if t < tcount else total + 1)
        for m in range(start, end):
            owners[m] = t
    for m in clr_meta.method_defs(pe, cli, root):
        rva = m["rva"]
        body = pe.get_data(rva, m["body_bytes"]) if rva else b""
        name = clr_meta.strings(pe, cli, root, m["name_index"])
        sig = clr_meta.blob(pe, cli, root, m["signature_index"]) if "signature_index" in m else None
        out.append({"token": m["token"], "owner": tkey(owners.get(m["token"] & 0xFFFFFF, 0)),
                    "name": name, "rva": rva, "bytes": len(body), "body": body,
                    "sha": sha256(body).hexdigest()})
    return out


def main(a_path, b_path):
    a = Path(a_path).read_bytes()
    b = Path(b_path).read_bytes()
    ra, rb = rows(a), rows(b)
    print(json_line({"a": a_path, "b": b_path, "sha_a": sha256(a).hexdigest(),
                     "sha_b": sha256(b).hexdigest(), "methods_a": len(ra),
                     "methods_b": len(rb), "byte_equal": a == b}))
    # pair by owner+name+order
    from collections import defaultdict
    groups_a, groups_b = defaultdict(list), defaultdict(list)
    for r in ra:
        groups_a[(r["owner"], r["name"])].append(r)
    for r in rb:
        groups_b[(r["owner"], r["name"])].append(r)
    equal = diff = only_a = only_b = 0
    details = []
    for key in sorted(set(groups_a) | set(groups_b)):
        la, lb = groups_a.get(key, []), groups_b.get(key, [])
        for i in range(max(len(la), len(lb))):
            if i >= len(la):
                only_b += 1
                details.append({"key": key, "only_b": lb[i]["sha"]})
                continue
            if i >= len(lb):
                only_a += 1
                details.append({"key": key, "only_a": la[i]["sha"]})
                continue
            x, y = la[i], lb[i]
            if x["body"] == y["body"]:
                equal += 1
            else:
                diff += 1
                first = next((k for k in range(min(len(x["body"]), len(y["body"])))
                              if x["body"][k] != y["body"][k]), min(len(x["body"]), len(y["body"])))
                details.append({"key": key, "body_diff": True, "bytes": [len(x["body"]), len(y["body"])],
                                "first": first, "sha_a": x["sha"], "sha_b": y["sha"]})
    print(json_line({"equal": equal, "differ": diff, "only_a": only_a, "only_b": only_b}))
    for d in details[:40]:
        print(json_line(d))
    return 0


def json_line(o):
    import json
    return json.dumps(o, ensure_ascii=False)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
