using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using AspenTech.AspenPlus.APConvert;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Localization;

namespace ColumnConverters;

[ComVisible(false)]
internal class User2toConSep : IAPBlockConverter2, IAPBlockConverter
{
	private class StreamConnection
	{
		public string streamName;

		public string streamPort;

		public string blockName;

		public string blockPort;
	}

	private class ConvertData
	{
		public string varName;

		public object Value;

		public short Units;
	}

	private const int HAP_UNITCOL = 3;

	private const int HAP_RESULTS_ERRORS = 32;

	private const int HAP_INPUT_INCOMPLETE = 64;

	private const int HAP_COMPSTATUS = 12;

	private string _comp1 = "";

	private string _comp2 = "";

	private string _comp3 = "";

	private int _ibasis = 2;

	private int _iconfig = 2;

	private List<string> _compList;

	private List<double> _comp1Map;

	private List<double> _comp2Map;

	private List<double> _comp3Map;

	private List<StreamConnection> streamList;

	private List<ConvertData> _valueList;

	private string title = WpfMMDialogResources.ConvertTo_Title;

	public string BaseDestinationType => "CONSEP";

	public string BaseSourceType => "USER2";

	public string Description => WpfMMDialogResources.ConvertTo_This + " " + BaseSourceType + " " + WpfMMDialogResources.ConvertTo_ConverTo + " " + BaseDestinationType + " " + WpfMMDialogResources.ConvertTo_Model;

	public string DestLibraryFile => "";

	public string DestLibraryModelType => "";

	public string DestLibraryName => "";

	public string DisplayName => "Aspen ConSep";

	public User2toConSep()
	{
		streamList = new List<StreamConnection>();
		_valueList = new List<ConvertData>();
		_compList = new List<string>();
		_comp1Map = new List<double>();
		_comp2Map = new List<double>();
		_comp3Map = new List<double>();
	}

	public void PreConvert(IHNode pNode)
	{
	}

	public int PreConvert2(IHNode pNode)
	{
		if (pNode == null)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Node, title);
			return 1;
		}
		int inputStatus = (dynamic)pNode.get_AttributeValue((short)12, Type.Missing);
		if (inputStatus == 64)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Input_Incomplete, title);
			return 1;
		}
		if (inputStatus == 32)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_ErrorsArePresent, title);
			return 1;
		}
		try
		{
			IHNode iHNode = pNode.FindNode("Connections");
			IHNodeCol elements = iHNode.Elements;
			if (elements != null)
			{
				string text = pNode.get_Name(Type.Missing);
				streamList.Clear();
				for (int i = 0; i < elements.Count; i++)
				{
					string text2 = elements.get_Label(0, i, Type.Missing);
					IHNode iHNode2 = pNode.FindNode("../../Streams/" + text2 + "/Connections/" + text);
					if (iHNode2 != null)
					{
						StreamConnection streamConnection = new StreamConnection();
						IHNode iHNode3 = iHNode.FindNode(text2);
						streamConnection.streamName = text2;
						streamConnection.blockName = text;
						streamConnection.streamPort = (string)(dynamic)iHNode2.get_Value(Type.Missing);
						string text3 = (string)(dynamic)iHNode3.get_Value(Type.Missing);
						if (text3 == "F1(IN)" || text3 == "F2(IN)")
						{
							text3 = "F(IN)";
						}
						else if (text3 == "P1(OUT)")
						{
							text3 = "D(OUT)";
						}
						else if (text3 == "P2(OUT)")
						{
							text3 = "B(OUT)";
						}
						streamConnection.blockPort = text3;
						streamList.Add(streamConnection);
					}
				}
			}
			IHNode iHNode4 = pNode.FindNode("Input/User Table");
			_valueList.Clear();
			IHNode iHNode5 = iHNode4.FindNode("IBASIS");
			if (iHNode5 != null)
			{
				_ibasis = (dynamic)iHNode5.get_Value(Type.Missing);
				ConvertData convertData = new ConvertData();
				convertData.varName = "IBASIS";
				if ((dynamic)iHNode5.get_Value(Type.Missing) == 1)
				{
					convertData.Value = "MASS";
				}
				else
				{
					convertData.Value = "MOLE";
				}
				_valueList.Add(convertData);
			}
			iHNode5 = iHNode4.FindNode("IPHASE");
			if (iHNode5 != null)
			{
				ConvertData convertData2 = new ConvertData();
				convertData2.varName = "IPHASE";
				if ((dynamic)iHNode5.get_Value(Type.Missing) == 2)
				{
					convertData2.Value = "VL";
				}
				else
				{
					convertData2.Value = "VLL";
				}
				_valueList.Add(convertData2);
			}
			iHNode5 = iHNode4.FindNode("ICONFIG");
			if (iHNode5 != null)
			{
				ConvertData convertData3 = new ConvertData();
				convertData3.varName = "ICONFIG";
				_iconfig = (dynamic)iHNode5.get_Value(Type.Missing);
				if (_iconfig == 1)
				{
					convertData3.Value = "NO-DECANTER";
				}
				else
				{
					convertData3.Value = "DECANTER";
				}
				_valueList.Add(convertData3);
			}
			iHNode5 = iHNode4.FindNode("SELCOMP(1)");
			if (iHNode5 != null)
			{
				ConvertData convertData4 = new ConvertData();
				convertData4.varName = "SELCOMP1";
				convertData4.Value = (_comp1 = (dynamic)iHNode5.get_Value(Type.Missing));
				_valueList.Add(convertData4);
			}
			iHNode5 = iHNode4.FindNode("SELCOMP(2)");
			if (iHNode5 != null)
			{
				ConvertData convertData5 = new ConvertData();
				convertData5.varName = "SELCOMP2";
				convertData5.Value = (_comp2 = (dynamic)iHNode5.get_Value(Type.Missing));
				_valueList.Add(convertData5);
			}
			iHNode5 = iHNode4.FindNode("SELCOMP(3)");
			if (iHNode5 != null)
			{
				ConvertData convertData6 = new ConvertData();
				convertData6.varName = "SELCOMP3";
				convertData6.Value = (_comp3 = (dynamic)iHNode5.get_Value(Type.Missing));
				_valueList.Add(convertData6);
			}
			iHNode5 = iHNode4.FindNode("PROPSET");
			if (iHNode5 != null)
			{
				ConvertData convertData7 = new ConvertData();
				convertData7.varName = "PROPSET";
				convertData7.Value = iHNode5.get_Value(Type.Missing);
				_valueList.Add(convertData7);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP1(1)");
			IHNode iHNode6 = iHNode4.FindNode("DISTCOMP(1)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData8 = new ConvertData();
				if (_ibasis == 1)
				{
					convertData8.varName = "DISTC1MA";
				}
				else
				{
					convertData8.varName = "DISTC1MO";
				}
				convertData8.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData8);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP2(1)");
			iHNode6 = iHNode4.FindNode("DISTCOMP(2)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData9 = new ConvertData();
				if (_ibasis == 1)
				{
					convertData9.varName = "DISTC2MA";
				}
				else
				{
					convertData9.varName = "DISTC2MO";
				}
				convertData9.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData9);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP3(1)");
			iHNode6 = iHNode4.FindNode("DISTCOMP(3)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData10 = new ConvertData();
				if (_ibasis == 1)
				{
					convertData10.varName = "DISTC3MA";
				}
				else
				{
					convertData10.varName = "DISTC3MO";
				}
				convertData10.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData10);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP1(3)");
			iHNode6 = iHNode4.FindNode("DISTRECO(1)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData11 = new ConvertData();
				convertData11.varName = "DISTRECO1";
				convertData11.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData11);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP2(3)");
			iHNode6 = iHNode4.FindNode("DISTRECO(2)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData12 = new ConvertData();
				convertData12.varName = "DISTRECO2";
				convertData12.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData12);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP3(3)");
			iHNode6 = iHNode4.FindNode("DISTRECO(3)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData13 = new ConvertData();
				convertData13.varName = "DISTRECO3";
				convertData13.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData13);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP1(2)");
			iHNode6 = iHNode4.FindNode("BOTCOMP(1)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData14 = new ConvertData();
				if (_ibasis == 1)
				{
					convertData14.varName = "BOTC1MA";
				}
				else
				{
					convertData14.varName = "BOTC1MO";
				}
				convertData14.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData14);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP2(2)");
			iHNode6 = iHNode4.FindNode("BOTCOMP(2)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData15 = new ConvertData();
				if (_ibasis == 1)
				{
					convertData15.varName = "BOTC2MA";
				}
				else
				{
					convertData15.varName = "BOTC2MO";
				}
				convertData15.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData15);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP3(2)");
			iHNode6 = iHNode4.FindNode("BOTCOMP(3)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData16 = new ConvertData();
				if (_ibasis == 1)
				{
					convertData16.varName = "BOTC3MA";
				}
				else
				{
					convertData16.varName = "BOTC3MO";
				}
				convertData16.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData16);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP1(4)");
			iHNode6 = iHNode4.FindNode("BOTRECO(1)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData17 = new ConvertData();
				convertData17.varName = "BOTRECO1";
				convertData17.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData17);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP2(4)");
			iHNode6 = iHNode4.FindNode("BOTRECO(2)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData18 = new ConvertData();
				convertData18.varName = "BOTRECO2";
				convertData18.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData18);
			}
			iHNode5 = iHNode4.FindNode("SPCOMP3(4)");
			iHNode6 = iHNode4.FindNode("BOTRECO(3)");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData19 = new ConvertData();
				convertData19.varName = "BOTRECO3";
				convertData19.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData19);
			}
			iHNode5 = iHNode4.FindNode("REFREB");
			if (iHNode5 != null)
			{
				ConvertData convertData20 = new ConvertData();
				convertData20.varName = "OPT_RB";
				if ((dynamic)iHNode5.get_Value(Type.Missing) == 0)
				{
					convertData20.Value = "RR";
				}
				else
				{
					convertData20.Value = "BR";
				}
				_valueList.Add(convertData20);
			}
			iHNode5 = iHNode4.FindNode("REFREB");
			iHNode6 = iHNode4.FindNode("REFRATIO");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 0 && iHNode6 != null)
			{
				ConvertData convertData21 = new ConvertData();
				if (_ibasis == 1)
				{
					convertData21.varName = "MASS_RR";
				}
				else
				{
					convertData21.varName = "MOLE_RR";
				}
				convertData21.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData21);
			}
			iHNode5 = iHNode4.FindNode("REFREB");
			iHNode6 = iHNode4.FindNode("REBRATIO");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) == 1 && iHNode6 != null)
			{
				ConvertData convertData22 = new ConvertData();
				if (_ibasis == 1)
				{
					convertData22.varName = "MASS_BR";
				}
				else
				{
					convertData22.varName = "MOLE_BR";
				}
				convertData22.Value = iHNode6.get_Value(Type.Missing);
				_valueList.Add(convertData22);
			}
			if (_iconfig == 2)
			{
				iHNode5 = iHNode4.FindNode("DECSPEC(1)");
				if (iHNode5 != null)
				{
					ConvertData convertData23 = new ConvertData();
					convertData23.varName = "SPECTYPE";
					if ((dynamic)iHNode5.get_Value(Type.Missing) == 1)
					{
						convertData23.Value = "VAPOR-COMP";
					}
					else if ((dynamic)iHNode5.get_Value(Type.Missing) == 2)
					{
						convertData23.Value = "REFLUX-COMP";
					}
					else
					{
						convertData23.Value = "SP-REFLUX";
					}
					_valueList.Add(convertData23);
				}
				iHNode5 = iHNode4.FindNode("DECSPEC(2)");
				if (iHNode5 != null)
				{
					ConvertData convertData24 = new ConvertData();
					convertData24.varName = "COMP";
					if ((dynamic)iHNode5.get_Value(Type.Missing) == 1)
					{
						convertData24.Value = _comp1;
					}
					else if ((dynamic)iHNode5.get_Value(Type.Missing) == 2)
					{
						convertData24.Value = _comp2;
					}
					else
					{
						convertData24.Value = _comp3;
					}
					_valueList.Add(convertData24);
				}
				iHNode5 = iHNode4.FindNode("DECVAL");
				if (iHNode5 != null)
				{
					ConvertData convertData25 = new ConvertData();
					convertData25.varName = "VALUE";
					convertData25.Value = iHNode5.get_Value(Type.Missing);
					_valueList.Add(convertData25);
				}
			}
			iHNode5 = iHNode4.FindNode("MAXITER");
			if (iHNode5 != null)
			{
				ConvertData convertData26 = new ConvertData();
				convertData26.varName = "FLASH_MAXIT";
				convertData26.Value = iHNode5.get_Value(Type.Missing);
				_valueList.Add(convertData26);
			}
			iHNode5 = iHNode4.FindNode("FLASHTOL");
			if (iHNode5 != null)
			{
				ConvertData convertData27 = new ConvertData();
				convertData27.varName = "FLASHTOL";
				convertData27.Value = iHNode5.get_Value(Type.Missing);
				_valueList.Add(convertData27);
			}
			iHNode5 = iHNode4.FindNode("CURVECALC");
			if (iHNode5 != null)
			{
				ConvertData convertData28 = new ConvertData();
				convertData28.varName = "CURVEALG";
				if ((dynamic)iHNode5.get_Value(Type.Missing) == 1)
				{
					convertData28.Value = "STANDARD";
				}
				else
				{
					convertData28.Value = "AZEOTROPIC";
				}
				_valueList.Add(convertData28);
			}
			iHNode5 = iHNode4.FindNode("CURVESTEP");
			if (iHNode5 != null)
			{
				ConvertData convertData29 = new ConvertData();
				convertData29.varName = "CURVESTEP";
				convertData29.Value = iHNode5.get_Value(Type.Missing);
				_valueList.Add(convertData29);
			}
			iHNode5 = iHNode4.FindNode("ENVSTEP");
			if (iHNode5 != null)
			{
				ConvertData convertData30 = new ConvertData();
				convertData30.varName = "ENVSTEP";
				convertData30.Value = iHNode5.get_Value(Type.Missing);
				_valueList.Add(convertData30);
			}
			iHNode5 = iHNode4.FindNode("MAXSTAGE");
			if (iHNode5 != null)
			{
				ConvertData convertData31 = new ConvertData();
				convertData31.varName = "MAXSTAGE";
				convertData31.Value = iHNode5.get_Value(Type.Missing);
				_valueList.Add(convertData31);
			}
			iHNode5 = iHNode4.FindNode("STOPCRIT");
			if (iHNode5 != null)
			{
				ConvertData convertData32 = new ConvertData();
				convertData32.varName = "DESIGNALG";
				if ((dynamic)iHNode5.get_Value(Type.Missing) == 1)
				{
					convertData32.Value = "STANDARD";
				}
				else
				{
					convertData32.Value = "ADVANCED";
				}
				_valueList.Add(convertData32);
			}
			iHNode5 = iHNode4.FindNode("PRES");
			if (iHNode5 != null)
			{
				ConvertData convertData33 = new ConvertData();
				convertData33.varName = "P_SPEC";
				convertData33.Value = iHNode5.get_Value(Type.Missing);
				IHNode iHNode7 = iHNode4.FindNode("PRESUNIT");
				if (iHNode7 != null)
				{
					string pressureUnit = (dynamic)iHNode7.get_Value(Type.Missing);
					switch (pressureUnit)
					{
					case "N/SQM":
						convertData33.Units = 1;
						break;
					case "PSI":
						convertData33.Units = 35;
						break;
					case "ATM":
						convertData33.Units = 3;
						break;
					case "LBF/SQFT":
						convertData33.Units = 4;
						break;
					case "BAR":
						convertData33.Units = 5;
						break;
					case "MMHG, TORR":
						convertData33.Units = 6;
						break;
					case "IN-WATER":
						convertData33.Units = 7;
						break;
					case "KG/SQCM":
						convertData33.Units = 8;
						break;
					case "KPA":
						convertData33.Units = 10;
						break;
					case "MM-WATER":
						convertData33.Units = 11;
						break;
					case "MBAR":
						convertData33.Units = 12;
						break;
					case "LB/FT-SQSEC":
						convertData33.Units = 17;
						break;
					case "LB/M-SQSEC":
						convertData33.Units = 18;
						break;
					}
					_valueList.Add(convertData33);
				}
			}
			IHNode iHNode8 = (pNode.Parent as IHNode).FindNode("Data/Components/Specifications/Input/ANAME1");
			if (iHNode8 != null)
			{
				foreach (IHNode element in iHNode8.Elements)
				{
					_compList.Add(element.get_Name(Type.Missing));
				}
			}
			for (int j = 1; j <= _compList.Count(); j++)
			{
				iHNode5 = iHNode4.FindNode("COMPMAP(1).CMAP(" + j + ")");
				if (iHNode5 != null)
				{
					if ((dynamic)iHNode5.get_Value(Type.Missing) == null)
					{
						iHNode5.set_Value(Type.Missing, (object)0.0);
					}
					_comp1Map.Add((dynamic)iHNode5.get_Value(Type.Missing));
				}
				iHNode5 = iHNode4.FindNode("COMPMAP(2).CMAP(" + j + ")");
				if (iHNode5 != null)
				{
					if ((dynamic)iHNode5.get_Value(Type.Missing) == null)
					{
						iHNode5.set_Value(Type.Missing, (object)0.0);
					}
					_comp2Map.Add((dynamic)iHNode5.get_Value(Type.Missing));
				}
				iHNode5 = iHNode4.FindNode("COMPMAP(3).CMAP(" + j + ")");
				if (iHNode5 != null)
				{
					if ((dynamic)iHNode5.get_Value(Type.Missing) == null)
					{
						iHNode5.set_Value(Type.Missing, (object)0.0);
					}
					_comp3Map.Add((dynamic)iHNode5.get_Value(Type.Missing));
				}
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_CannotBeConverted, title);
			throw new Exception(ex.Message.ToString());
		}
		return 0;
	}

	public void PostConvert(IHNode pNode)
	{
		IHNode iHNode = pNode.FindNode("Ports");
		IHNodeCol elements = iHNode.Elements;
		pNode?.HoldNotifies(hold: true);
		if (elements != null)
		{
			for (int i = 0; i < streamList.Count; i++)
			{
				StreamConnection streamConnection = streamList[i];
				for (int j = 0; j < elements.Count; j++)
				{
					string text = elements.get_Label(0, j, Type.Missing);
					if (text.CompareTo(streamConnection.blockPort) == 0)
					{
						string streamName = streamConnection.streamName;
						IHNodeCol destinationElements = iHNode.FindNode(text).Elements;
						if (destinationElements != null)
						{
							destinationElements.Add(streamName, null, null, null, null);
						}
						break;
					}
				}
			}
		}
		for (int k = 0; k < _valueList.Count(); k++)
		{
			string varName = _valueList[k].varName;
			if (!(varName != ""))
			{
				continue;
			}
			IHNode iHNode2 = pNode.FindNode("Input/" + varName);
			if (iHNode2 != null)
			{
				if (_valueList[k].Units > 0)
				{
					iHNode2.SetValueAndUnit(_valueList[k].Value, _valueList[k].Units, Type.Missing);
				}
				else
				{
					iHNode2.set_Value(Type.Missing, _valueList[k].Value);
				}
			}
		}
		IHNode iHNode3 = pNode.FindNode("Input/COMP1MAP");
		IHNode iHNode4 = pNode.FindNode("Input/COMP2MAP");
		IHNode iHNode5 = pNode.FindNode("Input/COMP3MAP");
		int num = 0;
		for (int l = 0; l < _compList.Count(); l++)
		{
			if (_compList[l] != _comp1 && _compList[l] != _comp2 && _compList[l] != _comp3 && ((_comp1Map[l] > 0.0 && _comp1Map[l] <= 1.0) || (_comp2Map[l] > 0.0 && _comp2Map[l] <= 1.0) || (_comp3Map[l] > 0.0 && _comp3Map[l] <= 1.0)))
			{
				iHNode3.Elements.InsertRow(0, num);
				iHNode3.Elements.set_Label(0, num, Type.Missing, _compList[l]);
				if (_comp1Map[l] > 0.0 && _comp1Map[l] <= 1.0)
				{
					iHNode3.Elements[num, Type.Missing, Type.Missing, Type.Missing, Type.Missing].set_Value(Type.Missing, (object)_comp1Map[l]);
				}
				if (_comp2Map[l] > 0.0 && _comp2Map[l] <= 1.0)
				{
					iHNode4.Elements[num, Type.Missing, Type.Missing, Type.Missing, Type.Missing].set_Value(Type.Missing, (object)_comp2Map[l]);
				}
				if (_comp3Map[l] > 0.0 && _comp3Map[l] <= 1.0)
				{
					iHNode5.Elements[num, Type.Missing, Type.Missing, Type.Missing, Type.Missing].set_Value(Type.Missing, (object)_comp3Map[l]);
				}
				num++;
			}
		}
	}
}
