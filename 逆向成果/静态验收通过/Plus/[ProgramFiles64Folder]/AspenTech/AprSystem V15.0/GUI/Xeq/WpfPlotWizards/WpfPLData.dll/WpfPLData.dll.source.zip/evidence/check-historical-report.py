#!/usr/bin/env python3
"""Verify that history mismatch and a failed historical probe cannot reject a current build."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parents[1]
SURROGATE = "0" * 64

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def change_expected(source):
    text, count = re.subn(r'^HISTORICAL_PATCHED_SHA = "[0-9a-f]{64}"$',
                          f'HISTORICAL_PATCHED_SHA = "{SURROGATE}"', source, flags=re.MULTILINE)
    if count != 1:
        raise ValueError("unable to locate exactly one historical expected digest")
    return text

def interrupt_probe(source):
    marker = '    expected = HISTORICAL_PATCHED_SHA\n    try:\n'
    if source.count(marker) != 1:
        raise ValueError("unable to locate the historical probe")
    return source.replace(marker, marker + '        raise ValueError("synthetic historical probe failure")\n')

def run_check(out, inputs, original_sha, case, mutate, status, matches):
    source_root = out / f"{case}-source"
    result_dir = out / case
    shutil.copytree(HERE, source_root)
    script = source_root / "reproduce.py"
    original_script_sha = digest(script)
    script.write_text(mutate(script.read_text(encoding="utf-8")), encoding="utf-8", newline="\n")
    manifest_path = source_root / "SHA256SUMS.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest["reproduce.py"] != original_script_sha:
        raise ValueError("source fingerprint differs from the sealed manifest")
    manifest["reproduce.py"] = digest(script)
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    command = [sys.executable, str(script), *inputs, "--out-dir", str(result_dir)]
    done = subprocess.run(command, cwd=source_root, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", check=False)
    if done.returncode:
        raise RuntimeError(f"{case} failed ({done.returncode})\n{done.stdout}{done.stderr}")
    report_path = result_dir / "build-report.json"
    report = json.loads(report_path.read_text(encoding="utf-8"))
    actual = report["historical"]
    if (actual["status"], actual["matches"]) != (status, matches):
        raise ValueError(f"{case} diagnostic differs: {actual!r}")
    final = digest(result_dir / "WpfPLData.dll")
    if final != original_sha or final != report["final_sha256"]:
        raise ValueError(f"{case} output differs")
    return {"case": case, "exit": done.returncode, "historical": actual, "final_sha256": final,
            "patched_manifest_sha256": digest(manifest_path), "build_report_sha256": digest(report_path)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("original", "ilasm", "dotnet", "cecil", "out-dir"):
        parser.add_argument("--" + key, required=True, type=Path)
    args = parser.parse_args()
    out = args.out_dir.resolve()
    if out == HERE or HERE in out.parents:
        raise ValueError("choose an output directory outside this archive")
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise ValueError("choose a new or empty output directory")
    out.mkdir(parents=True, exist_ok=True)
    inputs = [part for key in ("original", "ilasm", "dotnet", "cecil")
              for part in ("--" + key, str(getattr(args, key).resolve(strict=True)))]
    original_sha = digest(args.original)
    checks = [run_check(out, inputs, original_sha, "mismatch", change_expected, "computed", False),
              run_check(out, inputs, original_sha, "unavailable", interrupt_probe, "unavailable", None)]
    result = json.dumps({"checks": checks}, indent=2) + "\n"
    (out / "probe-receipt.json").write_text(result, encoding="utf-8")
    print(result, end="")

if __name__ == "__main__":
    main()
