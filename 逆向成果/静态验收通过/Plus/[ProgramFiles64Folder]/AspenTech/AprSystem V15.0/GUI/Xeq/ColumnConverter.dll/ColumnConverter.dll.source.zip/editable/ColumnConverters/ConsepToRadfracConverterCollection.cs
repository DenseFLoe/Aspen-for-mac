using System.Runtime.InteropServices;

namespace ColumnConverters;

[ComVisible(true)]
[Guid("41E5C181-356B-4594-8487-A35101007C73")]
[ProgId("Column.ConsepToRadfracConverterCollection.41.0")]
[ClassInterface(ClassInterfaceType.None)]
public class ConsepToRadfracConverterCollection : ConverterCollection
{
	public ConsepToRadfracConverterCollection()
		: base("Consep")
	{
	}
}
