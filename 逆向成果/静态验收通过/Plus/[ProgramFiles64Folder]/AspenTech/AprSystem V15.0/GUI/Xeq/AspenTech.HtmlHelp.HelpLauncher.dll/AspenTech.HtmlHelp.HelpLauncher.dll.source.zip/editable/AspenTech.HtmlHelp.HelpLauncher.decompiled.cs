using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using System.Windows;
using AspenTech.HtmlHelp.HelpIntegration;
using Microsoft.Practices.Composite.Events;
using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Composite.Presentation.Events;
using Microsoft.Practices.Composite.UnityExtensions;
using Microsoft.Practices.ObjectBuilder2;
using Microsoft.Practices.Unity;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("2023.15.0.2")]
[assembly: AssemblyTitle("AspenTech.HtmlHelp.HelpLauncher")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, INC.")]
[assembly: AssemblyProduct("AspenTech.HtmlHelp.HelpLauncher")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2023")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("ba23ef00-8397-4faf-bb38-e770ba1d9926")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("2023.15.0.2")]
namespace AspenTech.HtmlHelp.HelpLauncher;

[ProgId("HtmlHelpLauncher.6")]
[ClassInterface(ClassInterfaceType.None)]
[Guid("D990F5AB-9824-4DF4-B896-03F4A0C25BAB")]
[ComVisible(true)]
public class HtmlHelpLauncher : IHtmlHelpPresenter
{
	private HtmlHelpLauncherUnityBootstrapper htmlHelpStrapper;

	private IHtmlHelpHelper htmlHelpHelper;

	private void MakePathInEnv()
	{
		string location = GetType().Assembly.Location;
		FileInfo fileInfo = new FileInfo(location);
		if (fileInfo == null)
		{
			return;
		}
		location = fileInfo.DirectoryName;
		if (string.IsNullOrWhiteSpace(location))
		{
			return;
		}
		string environmentVariable = Environment.GetEnvironmentVariable("path");
		if (string.IsNullOrWhiteSpace(environmentVariable))
		{
			return;
		}
		if (environmentVariable.IndexOf(location, StringComparison.InvariantCultureIgnoreCase) >= 0)
		{
			return;
		}
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendFormat("{0};{1}", location, environmentVariable);
		environmentVariable = stringBuilder.ToString();
		Environment.SetEnvironmentVariable("path", environmentVariable);
	}

	public HtmlHelpLauncher()
	{
		MakePathInEnv();
		htmlHelpStrapper = HtmlHelpLauncherUnityBootstrapper.GetBootstrapper();
		htmlHelpStrapper.Run();
	}

	public void HtmlHelpInit(string strProduct, string strExtVersion, string strInVersion, string strLandingPage, string strProdDisplayName)
	{
		if (htmlHelpHelper == null)
		{
			htmlHelpHelper = htmlHelpStrapper.Container.Resolve<IHtmlHelpHelper>(Array.Empty<ResolverOverride>());
			htmlHelpHelper.InitHtmlHelpSystem(strProduct, strExtVersion, strInVersion, strLandingPage, strProdDisplayName, string.Empty, bNoSelfExtract: false);
		}
	}

	public void HtmlHelpInit2(string strProduct, string strExtVersion, string strInVersion, string strLandingPage, string strProdDisplayName, string strHelpExtAppName, bool bNoSelfExtract)
	{
		if (htmlHelpHelper == null)
		{
			htmlHelpHelper = htmlHelpStrapper.Container.Resolve<IHtmlHelpHelper>(Array.Empty<ResolverOverride>());
			htmlHelpHelper.InitHtmlHelpSystem(strProduct, strExtVersion, strInVersion, strLandingPage, strProdDisplayName, strHelpExtAppName, bNoSelfExtract);
		}
	}

	public void HtmlHelpInit3(string strProduct, string strExtVersion, string strInVersion, string strLandingPage, string strProdDisplayName, string strHelpExtAppName, bool bNoSelfExtract, bool displayMoreThanOnce)
	{
		if (displayMoreThanOnce)
		{
			htmlHelpHelper = htmlHelpStrapper.Container.Resolve<IHtmlHelpHelper>(Array.Empty<ResolverOverride>());
			htmlHelpHelper.InitHtmlHelpSystem(strProduct, strExtVersion, strInVersion, strLandingPage, strProdDisplayName, strHelpExtAppName, bNoSelfExtract, displayMoreThanOnce);
		}
	}

	public void HtmlHelpClose()
	{
		if (htmlHelpHelper != null)
		{
			htmlHelpHelper.HtmlHelpDispose();
			htmlHelpHelper = null;
		}
	}

	public void HtmlHelpDisplayTopic(string strHelpTopicUrl)
	{
		if (htmlHelpHelper != null)
		{
			htmlHelpHelper.HtmlHelpDisplayF1Link(strHelpTopicUrl);
		}
	}

	public void SetVisible(bool visible)
	{
		if (htmlHelpHelper != null)
		{
			htmlHelpHelper.SetVisible(visible);
		}
	}

	public void UseWinFormsBrowser(bool useBrowser)
	{
		if (htmlHelpHelper != null)
		{
			htmlHelpHelper.UseWinFormsBrowser = useBrowser;
		}
	}

	public void UseAspenTechStdIcon(bool useATStdIcon)
	{
		if (htmlHelpHelper != null)
		{
			htmlHelpHelper.UseAspenTechStdIcon = useATStdIcon;
		}
	}

	public void CloseOpenedHelpWindow()
	{
		if (htmlHelpHelper != null)
		{
			htmlHelpHelper.CloseOpenedHelpWindow();
		}
	}
}
[Module(ModuleName = "AspenTech.HtmlHelp.HtmlHelpLauncherModule")]
public class HtmlHelpLauncherModule : IModule
{
	public const string ModuleName = "AspenTech.HtmlHelp.HtmlHelpLauncherModule";

	private readonly IUnityContainer _unityContainer;

	public IUnityContainer Container => _unityContainer;

	public HtmlHelpLauncherModule(IUnityContainer unityContainer)
	{
		if (unityContainer == null)
		{
			throw new ArgumentNullException("unityContainer");
		}
		_unityContainer = unityContainer;
	}

	public void Initialize()
	{
		IUnityContainer container = _unityContainer.CreateChildContainer();
		container.AddNewExtension<UnityBootstrapperExtension>();
		container.AddNewExtension<RoutingEventAggregatorUnityExtension>();
		container.RegisterType<IEventAggregator, RoutingEventAggregator>(new ContainerControlledLifetimeManager(), Array.Empty<InjectionMember>());
	}
}
internal class HtmlHelpLauncherModuleCatalog : ModuleCatalog
{
	public HtmlHelpLauncherModuleCatalog()
	{
	}

	protected override void InnerLoad()
	{
		foreach (ModuleInfo item in from t in GetType().Assembly.GetExportedTypes().Where(typeof(IModule).IsAssignableFrom)
			where t != typeof(IModule)
			where !t.IsAbstract
			select CreateModuleInfo(t))
		{
			AddModule(item);
		}
		AddModule("AspenTech.HtmlHelp.HelpIntegration.HtmlHelpIntegrationModule", typeof(HtmlHelpIntegrationModule).AssemblyQualifiedName);
	}

	private ModuleInfo CreateModuleInfo(Type type)
	{
		if (type == null)
		{
			return null;
		}
		string name = type.Name;
		bool flag = false;
		CustomAttributeData customAttributeData = CustomAttributeData.GetCustomAttributes(type).FirstOrDefault((CustomAttributeData cad) => cad.Constructor.DeclaringType.FullName == typeof(ModuleAttribute).FullName);
		if (customAttributeData != null)
		{
			foreach (CustomAttributeNamedArgument namedArgument in customAttributeData.NamedArguments)
			{
				switch (namedArgument.MemberInfo.Name)
				{
				case "ModuleName":
					name = (string)namedArgument.TypedValue.Value;
					break;
				case "OnDemand":
					flag = (bool)namedArgument.TypedValue.Value;
					break;
				case "StartupLoaded":
					flag = !(bool)namedArgument.TypedValue.Value;
					break;
				}
			}
		}
		ModuleInfo moduleInfo = new ModuleInfo(name, type.AssemblyQualifiedName)
		{
			InitializationMode = (flag ? InitializationMode.OnDemand : InitializationMode.WhenAvailable),
			Ref = type.Assembly.CodeBase
		};
		foreach (CustomAttributeData item in from cad in CustomAttributeData.GetCustomAttributes(type)
			where cad.Constructor.DeclaringType.FullName == typeof(ModuleDependencyAttribute).FullName
			select cad)
		{
			moduleInfo.DependsOn.Add((string)item.ConstructorArguments[0].Value);
		}
		return moduleInfo;
	}
}
public class HtmlHelpLauncherUnityBootstrapper : UnityBootstrapper
{
	private static HtmlHelpLauncherUnityBootstrapper _HelpBootStrapperInstance = null;

	private static object _Locker = new object();

	private IEventAggregator _IEventAggregator;

	public IEventAggregator EventAggregator
	{
		get
		{
			if (_IEventAggregator == null)
			{
				_IEventAggregator = base.Container.TryResolve<RoutingEventAggregator>();
			}
			return _IEventAggregator;
		}
	}

	private HtmlHelpLauncherUnityBootstrapper()
	{
	}

	public static HtmlHelpLauncherUnityBootstrapper GetBootstrapper()
	{
		if (_HelpBootStrapperInstance == null)
		{
			lock (_Locker)
			{
				if (_HelpBootStrapperInstance == null)
				{
					_HelpBootStrapperInstance = new HtmlHelpLauncherUnityBootstrapper();
				}
			}
		}
		return _HelpBootStrapperInstance;
	}

	protected override void ConfigureContainer()
	{
		base.Container.AddNewExtension<RoutingEventAggregatorUnityExtension>();
		RegisterTypeIfMissing(typeof(IEventAggregator), typeof(RoutingEventAggregator), registerAsSingleton: true);
		base.ConfigureContainer();
	}

	protected sealed override DependencyObject CreateShell()
	{
		return null;
	}

	protected override IModuleCatalog GetModuleCatalog()
	{
		return new HtmlHelpLauncherModuleCatalog();
	}
}
[InterfaceType(ComInterfaceType.InterfaceIsDual)]
[Guid("700A86C2-EF93-4406-9AEA-92C70A52530B")]
[ComVisible(true)]
public interface IHtmlHelpPresenter
{
	void HtmlHelpInit2(string strProduct, string strExtVersion, string strInVersion, string strLandingPage, string strProdDisplayName, string strHelpExtAppName, bool bNoSelfExtract);

	void HtmlHelpInit(string strProduct, string strExtVersion, string strInVersion, string strLandingPage, string strProdDisplayName);

	void HtmlHelpInit3(string strProduct, string strExtVersion, string strInVersion, string strLandingPage, string strProdDisplayName, string strHelpExtAppName, bool bNoSelfExtract, bool displayMoreThanOnce);

	void HtmlHelpDisplayTopic(string strHelpTopicUrl);

	void HtmlHelpClose();

	void SetVisible(bool visible);

	void CloseOpenedHelpWindow();
}
public enum CompositeEventRoutingStrategy
{
	Children,
	Parents,
	ChildrenThenParents,
	ParentsThenChildren,
	FirstOfParentsThenChildren,
	FirstOfChildrenThenParents,
	FirstOfParents,
	AllTopDown
}
public class RoutingEventAggregatorUnityExtension : UnityContainerExtension
{
	protected override void Initialize()
	{
	}

	private IEnumerable<IUnityContainer> EnumerateContainerChildren()
	{
		ILifetimeContainer lifetime = base.Context.Lifetime;
		if (lifetime != null)
		{
			foreach (object item in lifetime)
			{
				if (item is IUnityContainer unityContainer)
				{
					yield return unityContainer;
				}
			}
		}
	}

	public static IEnumerable<IUnityContainer> EnumerateContainerChildren(IUnityContainer container)
	{
		RoutingEventAggregatorUnityExtension routingEventAggregatorUnityExtension = container.Configure<RoutingEventAggregatorUnityExtension>();
		if (routingEventAggregatorUnityExtension != null)
		{
			foreach (IUnityContainer item in routingEventAggregatorUnityExtension.EnumerateContainerChildren())
			{
				yield return item;
			}
		}
	}
}
public class RoutingEventAggregator : IEventAggregator
{
	private readonly List<EventBase> _events = new List<EventBase>();

	public IUnityContainer Container { get; private set; }

	public RoutingEventAggregator(IUnityContainer container)
	{
		Container = container;
	}

	public TEventType GetEvent<TEventType>() where TEventType : EventBase
	{
		TEventType val = _events.FirstOrDefault((EventBase evt) => evt.GetType() == typeof(TEventType)) as TEventType;
		if (val == null)
		{
			val = Container.Resolve<TEventType>(Array.Empty<ResolverOverride>());
			_events.Add(val);
		}
		return val;
	}

	internal void RoutedPublish<TPayload>(CompositeEventRoutingStrategy strategy, RoutedCompositePresentationEvent<TPayload> eventInstance, TPayload payload)
	{
		Type type = eventInstance.GetType();
		if (strategy == CompositeEventRoutingStrategy.AllTopDown)
		{
			IUnityContainer unityContainer = Container;
			while (unityContainer.Parent != null)
			{
				unityContainer = unityContainer.Parent;
			}
			PublishToContainer(unityContainer, type, payload);
			PublishToChildren(unityContainer, type, payload, stopAtFirstSubscriber: false);
			return;
		}
		bool flag = false;
		if (eventInstance.PublishToPeers(payload))
		{
			flag = true;
		}
		switch (strategy)
		{
		case CompositeEventRoutingStrategy.Children:
			PublishToChildren(Container, type, payload, stopAtFirstSubscriber: false);
			break;
		case CompositeEventRoutingStrategy.Parents:
			PublishToParents(Container, type, payload, stopAtFirstSubscriber: false);
			break;
		case CompositeEventRoutingStrategy.ChildrenThenParents:
			PublishToChildren(Container, type, payload, stopAtFirstSubscriber: false);
			PublishToParents(Container, type, payload, stopAtFirstSubscriber: false);
			break;
		case CompositeEventRoutingStrategy.ParentsThenChildren:
			PublishToParents(Container, type, payload, stopAtFirstSubscriber: false);
			PublishToChildren(Container, type, payload, stopAtFirstSubscriber: false);
			break;
		case CompositeEventRoutingStrategy.FirstOfChildrenThenParents:
			if (!flag && !PublishToChildren(Container, type, payload, stopAtFirstSubscriber: true))
			{
				PublishToParents(Container, type, payload, stopAtFirstSubscriber: true);
			}
			break;
		case CompositeEventRoutingStrategy.FirstOfParentsThenChildren:
			if (!flag && !PublishToParents(Container, type, payload, stopAtFirstSubscriber: true))
			{
				PublishToChildren(Container, type, payload, stopAtFirstSubscriber: true);
			}
			break;
		case CompositeEventRoutingStrategy.FirstOfParents:
			if (!flag)
			{
				PublishToParents(Container, type, payload, stopAtFirstSubscriber: true);
			}
			break;
		}
	}

	private bool PublishToParents<TPayload>(IUnityContainer container, Type eventType, TPayload payload, bool stopAtFirstSubscriber)
	{
		bool result = false;
		IUnityContainer parent = container.Parent;
		if (parent != null)
		{
			RoutingEventAggregator routingEventAggregator = null;
			try
			{
				routingEventAggregator = parent.Resolve<IEventAggregator>(Array.Empty<ResolverOverride>()) as RoutingEventAggregator;
			}
			catch (Exception)
			{
			}
			if (routingEventAggregator != null && routingEventAggregator._events.FirstOrDefault((EventBase evt) => evt.GetType() == eventType) is RoutedCompositePresentationEvent<TPayload> routedCompositePresentationEvent && routedCompositePresentationEvent.PublishToPeers(payload))
			{
				result = true;
				if (stopAtFirstSubscriber)
				{
					return result;
				}
			}
			if (PublishToParents(parent, eventType, payload, stopAtFirstSubscriber))
			{
				result = true;
			}
		}
		return result;
	}

	private bool PublishToContainer<TPayload>(IUnityContainer container, Type eventType, TPayload payload)
	{
		bool result = false;
		RoutingEventAggregator routingEventAggregator = null;
		try
		{
			routingEventAggregator = container.Resolve<IEventAggregator>(Array.Empty<ResolverOverride>()) as RoutingEventAggregator;
		}
		catch (Exception)
		{
		}
		if (routingEventAggregator != null && routingEventAggregator._events.FirstOrDefault((EventBase evt) => evt.GetType() == eventType) is RoutedCompositePresentationEvent<TPayload> routedCompositePresentationEvent && routedCompositePresentationEvent.PublishToPeers(payload))
		{
			result = true;
		}
		return result;
	}

	private bool PublishToChildren<TPayload>(IUnityContainer container, Type eventType, TPayload payload, bool stopAtFirstSubscriber)
	{
		bool result = false;
		foreach (IUnityContainer item in RoutingEventAggregatorUnityExtension.EnumerateContainerChildren(container))
		{
			RoutingEventAggregator routingEventAggregator = null;
			try
			{
				routingEventAggregator = item.Resolve<IEventAggregator>(Array.Empty<ResolverOverride>()) as RoutingEventAggregator;
			}
			catch (Exception)
			{
			}
			if (routingEventAggregator != null && routingEventAggregator._events.FirstOrDefault((EventBase evt) => evt.GetType() == eventType) is RoutedCompositePresentationEvent<TPayload> routedCompositePresentationEvent && routedCompositePresentationEvent.PublishToPeers(payload))
			{
				result = true;
				if (stopAtFirstSubscriber)
				{
					break;
				}
			}
			if (PublishToChildren(item, eventType, payload, stopAtFirstSubscriber))
			{
				result = true;
				if (stopAtFirstSubscriber)
				{
					break;
				}
			}
		}
		return result;
	}
}
public class RoutedCompositePresentationEvent<TPayload> : CompositePresentationEvent<TPayload>
{
	public CompositeEventRoutingStrategy RoutingStrategy { get; set; }

	[Microsoft.Practices.Unity.Dependency]
	public IEventAggregator EventAggregator { get; set; }

	public RoutedCompositePresentationEvent()
	{
		RoutingStrategy = CompositeEventRoutingStrategy.ChildrenThenParents;
	}

	public override void Publish(TPayload payload)
	{
		Publish(RoutingStrategy, payload);
	}

	public void Publish(CompositeEventRoutingStrategy strategy, TPayload payload)
	{
		if (EventAggregator is RoutingEventAggregator routingEventAggregator)
		{
			routingEventAggregator.RoutedPublish(strategy, this, payload);
		}
		else
		{
			PublishToPeers(payload);
		}
	}

	public bool PublishToPeers(TPayload payload)
	{
		if (base.Subscriptions.Count == 0)
		{
			return false;
		}
		base.InternalPublish(payload);
		return true;
	}
}
