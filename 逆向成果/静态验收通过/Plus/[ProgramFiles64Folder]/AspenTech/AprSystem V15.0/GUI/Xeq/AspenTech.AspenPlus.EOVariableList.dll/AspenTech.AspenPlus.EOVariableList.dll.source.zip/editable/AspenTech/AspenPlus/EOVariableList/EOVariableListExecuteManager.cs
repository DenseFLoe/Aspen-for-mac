using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using AspenTech.AspenCxs;
using AspenTech.AspenCxs.CxsViewModel;
using AspenTech.AspenCxs.CxsViewModel.ViewData;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.MMControls;
using AspenTech.AspenPlus.UnmanagedWrapper;
using AspenTech.Engineering.GridControls.Bindings;
using AspenTech.WpfControls.Engineering;
using Infragistics.Windows;

namespace AspenTech.AspenPlus.EOVariableList;

public class EOVariableListExecuteManager
{
	private const int AR_EOSYNC = 16384;

	private const int A_COMPSTATUS = 12;

	private const int HAP_ENABLED = 8192;

	private const int HAP_DISABLED = 4096;

	public IApwnApplication Application { get; private set; }

	public AesXamValueEdit SourceEditor { get; private set; }

	public MMScrollArea SourceScrollArea { get; private set; }

	public MMScrollAreaMS SourceScrollAreaMS { get; private set; }

	public MMTabPage SourcePage { get; private set; }

	public MMViewModel SourceViewModel => SourcePage?.ViewModel as MMViewModel;

	public CxvVariableData SourceVariable { get; private set; }

	private IHNode _eoNode;

	private IHNode _currentNode;

	private int? _defaultObjectType;

	public CxsCase CurrentCxsCase
	{
		get
		{
			if (Application.ActiveDocument != null)
			{
				return Application.ActiveDocument.Case;
			}
			return null;
		}
	}

	private IHNode EONode
	{
		get
		{
			if (_eoNode == null)
			{
				_eoNode = CurrentCxsCase?.InvokeAction("Top.appModelV8.Custom Actions", "HappNode", "Top.appModelV8.EO Configuration") as IHNode;
			}
			return _eoNode;
		}
	}

	public IHNode CurrentNode
	{
		get
		{
			if (_currentNode == null && SourceViewModel != null && CurrentCxsCase != null)
			{
				if (SourceEditor.Variable != null)
				{
					if (SourceEditor.Variable is CxvVariableData cxvVariableData && !string.IsNullOrEmpty(cxvVariableData.DataPath))
					{
						string parentNodePath = GetParentNodePath(cxvVariableData.DataPath);
						_currentNode = CurrentCxsCase.InvokeAction("Top.appModelV8.Custom Actions", "HappNode", parentNodePath) as IHNode;
					}
				}
				else if (SourceVariable != null && !string.IsNullOrEmpty(SourceVariable.DataPath))
				{
					string parentNodePath2 = GetParentNodePath(SourceVariable.DataPath);
					_currentNode = CurrentCxsCase.InvokeAction("Top.appModelV8.Custom Actions", "HappNode", parentNodePath2) as IHNode;
				}
			}
			return _currentNode;
		}
	}

	public int DefaultObjectType
	{
		get
		{
			if (!_defaultObjectType.HasValue && SourceViewModel != null && CurrentCxsCase != null)
			{
				if (SourceEditor.Variable != null)
				{
					if (SourceEditor.Variable is CxvVariableData cxvVariableData && !string.IsNullOrEmpty(cxvVariableData.DataPath))
					{
						IHNode iHNode = CurrentCxsCase.InvokeAction("Top.appModelV8.Custom Actions", "HappNode", cxvVariableData.DataPath) as IHNode;
						short attrnumber = 80;
						if (iHNode != null)
						{
							_defaultObjectType = iHNode.get_AttributeType(attrnumber);
						}
					}
				}
				else if (SourceVariable != null && !string.IsNullOrEmpty(SourceVariable.DataPath))
				{
					IHNode iHNode2 = CurrentCxsCase.InvokeAction("Top.appModelV8.Custom Actions", "HappNode", SourceVariable.DataPath) as IHNode;
					short attrnumber2 = 80;
					if (iHNode2 != null)
					{
						_defaultObjectType = iHNode2.get_AttributeType(attrnumber2);
					}
				}
			}
			if (_defaultObjectType.HasValue)
			{
				return _defaultObjectType.Value;
			}
			return 0;
		}
	}

	public SelectionMode SelectionMode
	{
		get
		{
			if (SourceEditor.IsInScrollArea)
			{
				return SelectionMode.Extended;
			}
			return SelectionMode.Single;
		}
	}

	public EOVariableListExecuteManager(IApwnApplication application, AesXamValueEdit sourceEditor)
	{
		Application = application ?? throw new ArgumentNullException("application");
		SourceEditor = sourceEditor ?? throw new ArgumentNullException("sourceEditor");
		SourceVariable = sourceEditor.Variable as CxvVariableData;
		if (SourceEditor.IsInScrollArea)
		{
			SourceScrollArea = Utilities.GetAncestorFromType(SourceEditor, typeof(MMScrollArea), allowSubclassOfType: true) as MMScrollArea;
			if (SourceScrollArea == null)
			{
				SourceScrollAreaMS = Utilities.GetAncestorFromType(SourceEditor, typeof(MMScrollAreaMS), allowSubclassOfType: true) as MMScrollAreaMS;
			}
		}
		SourcePage = GetAncestorTabPage(sourceEditor);
	}

	public void RefreshDefaultObjectType()
	{
		_defaultObjectType = null;
	}

	public bool CanExecuteListVariables()
	{
		if (SourceEditor.Variable == null)
		{
			return false;
		}
		if (SourcePage == null)
		{
			return false;
		}
		if (SourceViewModel == null)
		{
			return false;
		}
		if (HelperFuncs.MMHierClrflag() == 3)
		{
			return false;
		}
		if (!GetIsBlockActive())
		{
			return false;
		}
		if (GetConfigObject() == null)
		{
			return false;
		}
		if (!EoVariableIOHelp.CanEoVariableIO())
		{
			return DefaultObjectType == 6;
		}
		return true;
	}

	private bool GetIsBlockActive()
	{
		int? num = CxsConverter.ValueToInt32(SourceViewModel.ExpandDataPathAndGet("@main", "status_code"));
		if (num.HasValue && (num.Value & 0x1000) != 0)
		{
			return false;
		}
		return true;
	}

	public bool? ExecuteListVariables()
	{
		EOVariableListDialogManager dialog = new EOVariableListDialogManager(this);
		return dialog.OpenDialog();
	}

	public void SaveSelectedVariables(List<string> selectedVariables, List<string> physicalTypes, List<string> units)
	{
		if (selectedVariables == null)
		{
			return;
		}
		if (selectedVariables.Count == 0)
		{
			return;
		}
		CxvVariableData cxvVariableData = SourceEditor.Variable as CxvVariableData;
		if (cxvVariableData == null)
		{
			cxvVariableData = SourceVariable;
		}
		string dataAttributeResolved = (cxvVariableData.Property as CxvVariableProperty).DataAttributeResolved;
		string dataPath = cxvVariableData.DataPath;
		string text = dataPath.Replace("VARIABLE", "PHYS_QTY");
		string text2 = dataPath.Replace("VARIABLE", "UOM");
		if (selectedVariables.Count == 1)
		{
			SourceViewModel.ExpandDataPathAndSet(dataPath, dataAttributeResolved, selectedVariables[0]);
			if (text != dataPath && text2 != dataPath)
			{
				if (!string.IsNullOrEmpty(physicalTypes[0]) && physicalTypes[0] != "UNTYPED")
				{
					if (SourceViewModel.ExpandDataPathAndSet(text, "value", physicalTypes[0]))
					{
						SourceViewModel.ExpandDataPathAndSet(text2, "value", units[0]);
					}
				}
				else if (SourceViewModel.ExpandDataPathAndSet(text, "value", ""))
				{
					SourceViewModel.ExpandDataPathAndSet(text2, "value", "");
				}
			}
			return;
		}
		CxvVectorPropertyData parentVectorData = GetParentVectorData();
		if (parentVectorData != null)
		{
			string parentNodePath = GetParentNodePath(dataPath);
			int currentNodeIndex = GetCurrentNodeIndex(parentVectorData, dataPath);
			SourceViewModel.ExpandDataPathAndSet(dataPath, dataAttributeResolved, selectedVariables[0]);
			int num = 1;
			CxvPropertyWatch dependencies = new CxvPropertyWatch();
			for (int i = currentNodeIndex + 1; i < parentVectorData.Count; i++)
			{
				if (num < selectedVariables.Count)
				{
					object indexSubstitution = parentVectorData.IndexBasis.GetIndexSubstitution(i, dependencies);
					string value = selectedVariables[num];
					string dataPath2 = $"{parentNodePath}.{indexSubstitution}";
					SourceViewModel.ExpandDataPathAndSet(dataPath2, dataAttributeResolved, value);
					num++;
				}
			}
			for (int j = num; j < selectedVariables.Count; j++)
			{
				int num2 = parentVectorData.Count - 1 + j;
				SourceViewModel.AddChild(parentNodePath, num2);
				string dataPath3 = $"{parentNodePath}.#{num2}";
				SourceViewModel.ExpandDataPathAndSet(dataPath3, dataAttributeResolved, selectedVariables[j]);
			}
		}
	}

	public object GetConfigObject()
	{
		if (CurrentNode == null)
		{
			return null;
		}
		try
		{
			short num = 80;
			object obj = CurrentNode.get_AttributeValue(num, Type.Missing);
			if (obj == null && DefaultObjectType == 6)
			{
				if (SourceEditor.Variable is CxvVariableData cxvVariableData && !string.IsNullOrEmpty(cxvVariableData.DataPath))
				{
					if (CurrentCxsCase.InvokeAction("Top.appModelV8.Custom Actions", "HappNode", cxvVariableData.DataPath) is IHNode iHNode)
					{
						obj = iHNode.get_AttributeValue(num, Type.Missing);
					}
				}
				else if (SourceVariable != null && !string.IsNullOrEmpty(SourceVariable.DataPath) && CurrentCxsCase.InvokeAction("Top.appModelV8.Custom Actions", "HappNode", SourceVariable.DataPath) is IHNode iHNode2)
				{
					obj = iHNode2.get_AttributeValue(num, Type.Missing);
				}
			}
			if (obj == null)
			{
				IHNodeCol elements = CurrentNode.Elements;
				if (elements != null)
				{
					int location = -1;
					int dimension = 0;
					object force = true;
					elements.get_RowCount(dimension);
					obj = elements.get_LabelAttribute(dimension, location, num, force);
				}
			}
			return obj;
		}
		catch (Exception)
		{
			return null;
		}
	}

	private CxvVectorPropertyData GetParentVectorData()
	{
		if (SourceScrollArea != null && SourceScrollArea.DataGrid != null)
		{
			return SourceScrollArea.DataGrid.DataSource as CxvVectorPropertyData;
		}
		if (SourceScrollAreaMS != null && SourceScrollAreaMS.DataGrid != null && SourceScrollAreaMS.DataGrid.DataSource is BindingDataTable bindingDataTable)
		{
			return bindingDataTable.ItemsSource as CxvVectorPropertyData;
		}
		return null;
	}

	private static string GetParentNodePath(string path)
	{
		if (!string.IsNullOrEmpty(path))
		{
			int num = path.LastIndexOf('#');
			if (num > 0)
			{
				return path.Substring(0, num - 1);
			}
			int num2 = path.LastIndexOf('"');
			if (num2 > 1)
			{
				string text = path.Substring(0, num2);
				int num3 = text.LastIndexOf('"');
				if (num3 > 1)
				{
					return text.Substring(0, num3 - 1);
				}
			}
			int num4 = path.LastIndexOf('.');
			if (num4 > 0)
			{
				return path.Substring(0, num4);
			}
		}
		return null;
	}

	private static int GetCurrentNodeIndex(CxvVectorPropertyData parentVector, string path)
	{
		string currentNodeKey = GetCurrentNodeKey(path);
		for (int i = 0; i < parentVector.Count; i++)
		{
			object indexSubstitution = parentVector.IndexBasis.GetIndexSubstitution(i, null);
			if (object.Equals(currentNodeKey, indexSubstitution))
			{
				return i;
			}
		}
		return -1;
	}

	private static string GetCurrentNodeKey(string path)
	{
		if (!string.IsNullOrEmpty(path))
		{
			int num = path.LastIndexOf('#');
			if (num > 0)
			{
				return path.Substring(num);
			}
			int num2 = path.LastIndexOf('"');
			if (num2 > 1)
			{
				int num3 = path.Substring(0, num2).LastIndexOf('"');
				if (num3 > 1)
				{
					return path.Substring(num3, num2 - num3 + 1);
				}
			}
			int num4 = path.LastIndexOf('.');
			if (num4 > 0)
			{
				return path.Substring(num4 + 1);
			}
		}
		return null;
	}

	private bool HasEOVariables(int eoFlag)
	{
		if (SourceViewModel != null)
		{
			if (eoFlag == 2)
			{
				int? num = (CurrentCxsCase.InvokeAction("Top.appModelV8.Custom Actions", "HappNode", SourceViewModel.ExpandDataPath("@main")) as IHNode).get_AttributeValue((short)12, Type.Missing) as int?;
				if (num.HasValue)
				{
					return (num.Value & 0x4000) == 16384;
				}
			}
			else
			{
				int? num2 = SourceViewModel.ExpandDataPathAndGet("Top.appModelV8.EO Flowsheet", "has_children") as int?;
				if (num2.HasValue)
				{
					return num2.Value == 1;
				}
			}
		}
		return false;
	}

	private static MMTabPage GetAncestorTabPage(AesXamValueEdit sourceEditor)
	{
		return Utilities.GetAncestorFromType(sourceEditor, typeof(MMTabPage), allowSubclassOfType: true) as MMTabPage;
	}

	private int IsAnEOVariable()
	{
		object obj = null;
		int result = 0;
		if (CurrentNode != null)
		{
			short num = 71;
			IHNodeCol elements = CurrentNode.Elements;
			if (elements != null)
			{
				int location = -1;
				int dimension = 0;
				object force = true;
				elements.get_RowCount(dimension);
				obj = elements.get_LabelAttribute(dimension, location, num, force);
				if (obj == null || Convert.ToInt32(obj) == 0)
				{
					obj = CurrentNode.get_AttributeValue(num, Type.Missing);
				}
			}
			else
			{
				obj = CurrentNode.get_AttributeValue(num, Type.Missing);
			}
		}
		if (obj != null && obj.GetType() == typeof(int))
		{
			result = Convert.ToInt32(obj);
		}
		return result;
	}
}
