﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  AspenTech.AspenPlus.APServer.IAPServer
  AspenTech.AspenPlus.APServer._IAPServerSimEvents
  AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event
  AspenTech.AspenPlus.APServer.APServer
  AspenTech.AspenPlus.APServer.IAPServer2
  AspenTech.AspenPlus.APServer.IAPServer3
  AspenTech.AspenPlus.APServer.IAPServerRte
  AspenTech.AspenPlus.APServer.IAPServerScripting
  AspenTech.AspenPlus.APServer.IAPServerScripting2
  AspenTech.AspenPlus.APServer.IAPServer4
  AspenTech.AspenPlus.APServer.IAPServerDispatch
  AspenTech.AspenPlus.APServer.APServerClass
  AspenTech.AspenPlus.APServer.IAPBlockCollection
  AspenTech.AspenPlus.APServer.APServerBlockCollection
  AspenTech.AspenPlus.APServer.APServerBlockCollectionClass
  AspenTech.AspenPlus.APServer.IAPACMExpCollection
  AspenTech.AspenPlus.APServer.APACMExpCollection
  AspenTech.AspenPlus.APServer.APACMExpCollectionClass
  AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter
  AspenTech.AspenPlus.APServer.APCapeUnitAdapter
  AspenTech.AspenPlus.APServer.APCapeUnitAdapterClass
  AspenTech.AspenPlus.APServer.IAPBlock
  AspenTech.AspenPlus.APServer.IAPBlock2
  AspenTech.AspenPlus.APServer.IAPACMModelAdapter
  AspenTech.AspenPlus.APServer.APACMModelAdapter
  AspenTech.AspenPlus.APServer.IAPACMModelAdapter2
  AspenTech.AspenPlus.APServer.IAPACMModelAdapter3
  AspenTech.AspenPlus.APServer.IAPDynBlock
  AspenTech.AspenPlus.APServer.IAPDynBlock2
  AspenTech.AspenPlus.APServer.APACMModelAdapterClass
  AspenTech.AspenPlus.APServer.APServerEventSink
  AspenTech.AspenPlus.APServer.APServerEventSinkClass
  AspenTech.AspenPlus.APServer.IAPServerSim
  AspenTech.AspenPlus.APServer.APServerSim
  AspenTech.AspenPlus.APServer.APServerSimClass
  AspenTech.AspenPlus.APServer.IAPProperties
  AspenTech.AspenPlus.APServer.APSHostCompList
  AspenTech.AspenPlus.APServer.IAPPolymerProperties
  AspenTech.AspenPlus.APServer.APSHostCompListClass
  AspenTech.AspenPlus.APServer.IAPPropertiesCollection
  AspenTech.AspenPlus.APServer.APSHostCompListMgr
  AspenTech.AspenPlus.APServer.APSHostCompListMgrClass
  AspenTech.AspenPlus.APServer.ICatalogXMLManager
  AspenTech.AspenPlus.APServer.CatalogXMLManager
  AspenTech.AspenPlus.APServer.CatalogXMLManagerClass
  AspenTech.AspenPlus.APServer.ICatObjectCollection
  AspenTech.AspenPlus.APServer.CatObjectCollection
  AspenTech.AspenPlus.APServer.CatObjectCollectionClass
  AspenTech.AspenPlus.APServer.ICatObject
  AspenTech.AspenPlus.APServer.CatObject
  AspenTech.AspenPlus.APServer.CatObjectClass
  AspenTech.AspenPlus.APServer.ICatObjectModelCollection
  AspenTech.AspenPlus.APServer.CatObjectModelCollection
  AspenTech.AspenPlus.APServer.CatObjectModelCollectionClass
  AspenTech.AspenPlus.APServer.ICatObjectModel
  AspenTech.AspenPlus.APServer.CatObjectModel
  AspenTech.AspenPlus.APServer.CatObjectModelClass
  AspenTech.AspenPlus.APServer.ICatObjectDLL
  AspenTech.AspenPlus.APServer.CatObjectDLL
  AspenTech.AspenPlus.APServer.CatObjectDLLClass
  AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler
  AspenTech.AspenPlus.APServer.eCatalogObjectClassType
  AspenTech.AspenPlus.APServer.eACMComponentManagerEventType
  AspenTech.AspenPlus.APServer.APPropertyOption
  AspenTech.AspenPlus.APServer.ISequentialStream
  AspenTech.AspenPlus.APServer.IStream
  AspenTech.AspenPlus.APServer.eModelStrmType
  AspenTech.AspenPlus.APServer.APServerRetVMask
  AspenTech.AspenPlus.APServer.eAPCapeOpenIdOption
  AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0010
  AspenTech.AspenPlus.APServer.ApServerRteBlockStatus
  AspenTech.AspenPlus.APServer.ApServerRteParamType
  AspenTech.AspenPlus.APServer._LARGE_INTEGER
  AspenTech.AspenPlus.APServer._ULARGE_INTEGER
  AspenTech.AspenPlus.APServer.tagSTATSTG
  AspenTech.AspenPlus.APServer._FILETIME
  AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0007
  AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0003
  AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0002
  AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004
  AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0006
  AspenTech.AspenPlus.APServer.eResetTypes
  AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0009
  AspenTech.AspenPlus.APServer.APPolymerOption
  AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005
  AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008
  AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper
  AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern ASCClassLib380
{
  .ver 38:0:0:0
}
.assembly Interop.APServer
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibVersionAttribute::.ctor(int32,
                                                                                                int32) = ( 01 00 26 00 00 00 00 00 00 00 00 00 )             // ..&.........
  .custom instance void [mscorlib]System.Runtime.InteropServices.ImportedFromTypeLibAttribute::.ctor(string) = ( 01 00 0E 41 50 53 45 52 56 45 52 44 4C 4C 4C 69   // ...APSERVERDLLLi
                                                                                                                 62 00 00 )                                        // b..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 30 2D 45 31 31 31   // ..$6CCB1440-E111
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .hash algorithm 0x00008004
  .ver 38:0:0:0
}
.module Interop.APServer.dll
// MVID: {ad7cb09f-dd07-4d33-b590-fb66bfaddd1a}
.imagebase 0x00400000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000001    //  ILONLY
// Image base: 0x0000015CE68C0000


// =============== CLASS MEMBERS DECLARATION ===================

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPServer
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 43 2D 35 43 32 36   // ..$6CCB144C-5C26
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer::ResolveBlock

  .method public hidebysig newslot abstract virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer::TriggerCancel

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_EOSimulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer::get_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer::set_EOSimulation

  .property callconv(8) object EOSimulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServer::get_EOSimulation()
    .set instance void AspenTech.AspenPlus.APServer.IAPServer::set_EOSimulation(object)
  } // end of property IAPServer::EOSimulation
} // end of class AspenTech.AspenPlus.APServer.IAPServer

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer._IAPServerSimEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 44 34 37 45 37 33 32 2D 33 38 32 36   // ..$0D47E732-3826
                                                                                                  2D 31 31 44 35 2D 38 33 30 31 2D 30 30 43 30 34   // -11D5-8301-00C04
                                                                                                  46 32 39 38 37 35 36 00 00 )                      // F298756..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 10 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 02 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  OnEvent([in] int32 lEventId,
                                 [in] object  marshal( struct) Hint1,
                                 [in] object  marshal( struct) Hint2) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method _IAPServerSimEvents::OnEvent

} // end of class AspenTech.AspenPlus.APServer._IAPServerSimEvents

.class interface public abstract auto ansi AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComEventInterfaceAttribute::.ctor(class [mscorlib]System.Type,
                                                                                                   class [mscorlib]System.Type) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                                                    65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                                    5F 49 41 50 53 65 72 76 65 72 53 69 6D 45 76 65   // _IAPServerSimEve
                                                                                                                                    6E 74 73 3E 41 73 70 65 6E 54 65 63 68 2E 41 73   // nts>AspenTech.As
                                                                                                                                    70 65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72   // penPlus.APServer
                                                                                                                                    2E 5F 49 41 50 53 65 72 76 65 72 53 69 6D 45 76   // ._IAPServerSimEv
                                                                                                                                    65 6E 74 73 5F 45 76 65 6E 74 50 72 6F 76 69 64   // ents_EventProvid
                                                                                                                                    65 72 00 00 )                                     // er..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  add_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler A_1) runtime managed internalcall
  {
  } // end of method _IAPServerSimEvents_Event::add_OnEvent

  .method public hidebysig newslot abstract virtual 
          instance void  remove_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler A_1) runtime managed internalcall
  {
  } // end of method _IAPServerSimEvents_Event::remove_OnEvent

  .event AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler OnEvent
  {
    .addon instance void AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event::add_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler)
    .removeon instance void AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event::remove_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler)
  } // end of event _IAPServerSimEvents_Event::OnEvent
} // end of class AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.APServer
       implements AspenTech.AspenPlus.APServer.IAPServer,
                  AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 2A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..*AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          41 50 53 65 72 76 65 72 43 6C 61 73 73 00 00 )    // APServerClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 43 2D 35 43 32 36   // ..$6CCB144C-5C26
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
} // end of class AspenTech.AspenPlus.APServer.APServer

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPServer2
       implements AspenTech.AspenPlus.APServer.IAPServer
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 30 32 38 32 38 36 31 2D 43 32 30 44   // ..$F0282861-C20D
                                                                                                  2D 34 35 35 31 2D 41 42 44 36 2D 33 46 42 46 43   // -4551-ABD6-3FBFC
                                                                                                  39 34 31 31 41 33 38 00 00 )                      // 9411A38..
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer2::ResolveBlock

  .method public hidebysig newslot abstract virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer2::TriggerCancel

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_EOSimulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer2::get_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer2::set_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APServerBlockCollection 
          marshal( interface ) 
          get_Blocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer2::get_Blocks

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          get_FileStream([in] string  marshal( bstr) Name,
                         [in] int32 dwDesiredAccess,
                         [in] int32 dwShareMode,
                         [in] int32 dwCreationDisposition) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
  } // end of method IAPServer2::get_FileStream

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer2::get_DefaultProperties

  .property callconv(8) object EOSimulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.APServer.IAPServer2::set_EOSimulation(object)
    .get instance object AspenTech.AspenPlus.APServer.IAPServer2::get_EOSimulation()
  } // end of property IAPServer2::EOSimulation
  .property callconv(8) class AspenTech.AspenPlus.APServer.APServerBlockCollection
          Blocks()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APServerBlockCollection AspenTech.AspenPlus.APServer.IAPServer2::get_Blocks()
  } // end of property IAPServer2::Blocks
  .property callconv(8) class AspenTech.AspenPlus.APServer.IStream
          FileStream(string,
                     int32,
                     int32,
                     int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.IStream AspenTech.AspenPlus.APServer.IAPServer2::get_FileStream(string,
                                                                                                                     int32,
                                                                                                                     int32,
                                                                                                                     int32)
  } // end of property IAPServer2::FileStream
  .property callconv(8) object DefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServer2::get_DefaultProperties(string)
  } // end of property IAPServer2::DefaultProperties
} // end of class AspenTech.AspenPlus.APServer.IAPServer2

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPServer3
       implements AspenTech.AspenPlus.APServer.IAPServer2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 45 36 45 30 38 41 30 2D 41 38 42 44   // ..$6E6E08A0-A8BD
                                                                                                  2D 34 37 31 37 2D 42 37 41 36 2D 33 30 39 33 32   // -4717-B7A6-30932
                                                                                                  44 39 30 43 35 46 35 00 00 )                      // D90C5F5..
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer3::ResolveBlock

  .method public hidebysig newslot abstract virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer3::TriggerCancel

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_EOSimulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer3::get_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer3::set_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APServerBlockCollection 
          marshal( interface ) 
          get_Blocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer3::get_Blocks

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          get_FileStream([in] string  marshal( bstr) Name,
                         [in] int32 dwDesiredAccess,
                         [in] int32 dwShareMode,
                         [in] int32 dwCreationDisposition) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer3::get_FileStream

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
  } // end of method IAPServer3::get_DefaultProperties

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DupDefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServer3::get_DupDefaultProperties

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_CatalogXMLMgr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServer3::get_CatalogXMLMgr

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APACMExpCollection 
          marshal( interface ) 
          get_ACMExpModels() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServer3::get_ACMExpModels

  .property callconv(8) object EOSimulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServer3::get_EOSimulation()
    .set instance void AspenTech.AspenPlus.APServer.IAPServer3::set_EOSimulation(object)
  } // end of property IAPServer3::EOSimulation
  .property callconv(8) class AspenTech.AspenPlus.APServer.APServerBlockCollection
          Blocks()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APServerBlockCollection AspenTech.AspenPlus.APServer.IAPServer3::get_Blocks()
  } // end of property IAPServer3::Blocks
  .property callconv(8) class AspenTech.AspenPlus.APServer.IStream
          FileStream(string,
                     int32,
                     int32,
                     int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.IStream AspenTech.AspenPlus.APServer.IAPServer3::get_FileStream(string,
                                                                                                                     int32,
                                                                                                                     int32,
                                                                                                                     int32)
  } // end of property IAPServer3::FileStream
  .property callconv(8) object DefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServer3::get_DefaultProperties(string)
  } // end of property IAPServer3::DefaultProperties
  .property callconv(8) object DupDefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 01 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServer3::get_DupDefaultProperties(string)
  } // end of property IAPServer3::DupDefaultProperties
  .property callconv(8) object CatalogXMLMgr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 01 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServer3::get_CatalogXMLMgr()
  } // end of property IAPServer3::CatalogXMLMgr
  .property callconv(8) class AspenTech.AspenPlus.APServer.APACMExpCollection
          ACMExpModels()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 01 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APACMExpCollection AspenTech.AspenPlus.APServer.IAPServer3::get_ACMExpModels()
  } // end of property IAPServer3::ACMExpModels
} // end of class AspenTech.AspenPlus.APServer.IAPServer3

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPServerRte
       implements AspenTech.AspenPlus.APServer.IAPServer3
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 44 34 37 45 37 33 34 2D 33 38 32 36   // ..$0D47E734-3826
                                                                                                  2D 31 31 44 35 2D 38 33 30 31 2D 30 30 43 30 34   // -11D5-8301-00C04
                                                                                                  46 32 39 38 37 35 36 00 00 )                      // F298756..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::ResolveBlock

  .method public hidebysig newslot abstract virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::TriggerCancel

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_EOSimulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::get_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::set_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APServerBlockCollection 
          marshal( interface ) 
          get_Blocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::get_Blocks

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          get_FileStream([in] string  marshal( bstr) Name,
                         [in] int32 dwDesiredAccess,
                         [in] int32 dwShareMode,
                         [in] int32 dwCreationDisposition) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::get_FileStream

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
  } // end of method IAPServerRte::get_DefaultProperties

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DupDefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::get_DupDefaultProperties

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_CatalogXMLMgr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::get_CatalogXMLMgr

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APACMExpCollection 
          marshal( interface ) 
          get_ACMExpModels() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::get_ACMExpModels

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus 
          get_BlockStatus([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
  } // end of method IAPServerRte::get_BlockStatus

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NumberIter() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::get_NumberIter

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Converged([out] string&  marshal( bstr) failure) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::get_Converged

  .method public hidebysig newslot abstract virtual 
          instance void  WriteHistory([in] string  marshal( bstr) line) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::WriteHistory

  .method public hidebysig newslot abstract virtual 
          instance void  JournalComment([in] string  marshal( bstr) comment) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::JournalComment

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType 
          get_ParamType([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 02 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
  } // end of method IAPServerRte::get_ParamType

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_ParamStringValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::get_ParamStringValue

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ParamStringValue([in] string  marshal( bstr) Param,
                                              [in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::set_ParamStringValue

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_ParamIntValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::get_ParamIntValue

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ParamIntValue([in] string  marshal( bstr) Param,
                                           [in] int32 retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::set_ParamIntValue

  .method public hidebysig newslot abstract virtual 
          instance void  GetParamRealValue([in] string  marshal( bstr) Param,
                                           [out] string&  marshal( bstr) uom,
                                           [out] float64& retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::GetParamRealValue

  .method public hidebysig newslot abstract virtual 
          instance void  SetParamRealValue([in] string  marshal( bstr) Param,
                                           [in] string  marshal( bstr) uom,
                                           [in] float64 newVal) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerRte::SetParamRealValue

  .method public hidebysig newslot abstract virtual 
          instance void  ProcessVarQuality() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 02 60 00 00 )                         // .. ..`..
  } // end of method IAPServerRte::ProcessVarQuality

  .method public hidebysig newslot abstract virtual 
          instance void  SaveVariables([in] string  marshal( bstr) filename,
                                       [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 02 60 00 00 )                         // ..!..`..
  } // end of method IAPServerRte::SaveVariables

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateVariables([in] string  marshal( bstr) filename,
                                         [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 22 00 02 60 00 00 )                         // .."..`..
  } // end of method IAPServerRte::UpdateVariables

  .method public hidebysig newslot abstract virtual 
          instance void  RestoreVariables([in] string  marshal( bstr) filename,
                                          [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 23 00 02 60 00 00 )                         // ..#..`..
  } // end of method IAPServerRte::RestoreVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Rmiss() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 02 60 00 00 )                         // ..$..`..
  } // end of method IAPServerRte::get_Rmiss

  .method public hidebysig newslot abstract virtual 
          instance void  JournalLine([in] string  marshal( bstr) s) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 26 00 02 60 00 00 )                         // ..&..`..
  } // end of method IAPServerRte::JournalLine

  .method public hidebysig newslot abstract virtual 
          instance int32  SetVarAttr(string  marshal( bstr) Name,
                                     int32& ID,
                                     int32 attr,
                                     float64 val,
                                     string  marshal( bstr) unit,
                                     int32 spec) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 27 00 02 60 00 00 )                         // ..'..`..
  } // end of method IAPServerRte::SetVarAttr

  .method public hidebysig newslot abstract virtual 
          instance int32  Solve() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 28 00 02 60 00 00 )                         // ..(..`..
  } // end of method IAPServerRte::Solve

  .method public hidebysig newslot abstract virtual 
          instance void  SetInt(int32 iin) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 29 00 02 60 00 00 )                         // ..)..`..
  } // end of method IAPServerRte::SetInt

  .method public hidebysig newslot abstract virtual 
          instance int32  InqEnabledInactiveSpecGroups(string&  marshal( bstr) sOut,
                                                       int32 bDestroy) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 30 00 02 60 00 00 )                         // ..0..`..
  } // end of method IAPServerRte::InqEnabledInactiveSpecGroups

  .property callconv(8) object EOSimulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerRte::get_EOSimulation()
    .set instance void AspenTech.AspenPlus.APServer.IAPServerRte::set_EOSimulation(object)
  } // end of property IAPServerRte::EOSimulation
  .property callconv(8) class AspenTech.AspenPlus.APServer.APServerBlockCollection
          Blocks()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APServerBlockCollection AspenTech.AspenPlus.APServer.IAPServerRte::get_Blocks()
  } // end of property IAPServerRte::Blocks
  .property callconv(8) class AspenTech.AspenPlus.APServer.IStream
          FileStream(string,
                     int32,
                     int32,
                     int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.IStream AspenTech.AspenPlus.APServer.IAPServerRte::get_FileStream(string,
                                                                                                                       int32,
                                                                                                                       int32,
                                                                                                                       int32)
  } // end of property IAPServerRte::FileStream
  .property callconv(8) object DefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerRte::get_DefaultProperties(string)
  } // end of property IAPServerRte::DefaultProperties
  .property callconv(8) object DupDefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 01 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerRte::get_DupDefaultProperties(string)
  } // end of property IAPServerRte::DupDefaultProperties
  .property callconv(8) object CatalogXMLMgr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 01 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerRte::get_CatalogXMLMgr()
  } // end of property IAPServerRte::CatalogXMLMgr
  .property callconv(8) class AspenTech.AspenPlus.APServer.APACMExpCollection
          ACMExpModels()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 01 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APACMExpCollection AspenTech.AspenPlus.APServer.IAPServerRte::get_ACMExpModels()
  } // end of property IAPServerRte::ACMExpModels
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus
          BlockStatus(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus AspenTech.AspenPlus.APServer.IAPServerRte::get_BlockStatus(string)
  } // end of property IAPServerRte::BlockStatus
  .property callconv(8) int32 NumberIter()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServerRte::get_NumberIter()
  } // end of property IAPServerRte::NumberIter
  .property callconv(8) int32 Converged(string&)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServerRte::get_Converged(string&)
  } // end of property IAPServerRte::Converged
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType
          ParamType(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 02 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType AspenTech.AspenPlus.APServer.IAPServerRte::get_ParamType(string)
  } // end of property IAPServerRte::ParamType
  .property callconv(8) string ParamStringValue(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.APServer.IAPServerRte::set_ParamStringValue(string,
                                                                                       string)
    .get instance string AspenTech.AspenPlus.APServer.IAPServerRte::get_ParamStringValue(string)
  } // end of property IAPServerRte::ParamStringValue
  .property callconv(8) int32 ParamIntValue(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServerRte::get_ParamIntValue(string)
    .set instance void AspenTech.AspenPlus.APServer.IAPServerRte::set_ParamIntValue(string,
                                                                                    int32)
  } // end of property IAPServerRte::ParamIntValue
  .property callconv(8) float64 Rmiss()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 02 60 00 00 )                         // ..$..`..
    .get instance float64 AspenTech.AspenPlus.APServer.IAPServerRte::get_Rmiss()
  } // end of property IAPServerRte::Rmiss
} // end of class AspenTech.AspenPlus.APServer.IAPServerRte

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPServerScripting
       implements AspenTech.AspenPlus.APServer.IAPServerRte
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 39 2D 35 43 32 36   // ..$6CCB1449-5C26
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::ResolveBlock

  .method public hidebysig newslot abstract virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::TriggerCancel

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_EOSimulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::get_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::set_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APServerBlockCollection 
          marshal( interface ) 
          get_Blocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::get_Blocks

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          get_FileStream([in] string  marshal( bstr) Name,
                         [in] int32 dwDesiredAccess,
                         [in] int32 dwShareMode,
                         [in] int32 dwCreationDisposition) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
  } // end of method IAPServerScripting::get_FileStream

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
  } // end of method IAPServerScripting::get_DefaultProperties

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DupDefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::get_DupDefaultProperties

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_CatalogXMLMgr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::get_CatalogXMLMgr

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APACMExpCollection 
          marshal( interface ) 
          get_ACMExpModels() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::get_ACMExpModels

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus 
          get_BlockStatus([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
  } // end of method IAPServerScripting::get_BlockStatus

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NumberIter() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::get_NumberIter

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Converged([out] string&  marshal( bstr) failure) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::get_Converged

  .method public hidebysig newslot abstract virtual 
          instance void  WriteHistory([in] string  marshal( bstr) line) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::WriteHistory

  .method public hidebysig newslot abstract virtual 
          instance void  JournalComment([in] string  marshal( bstr) comment) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::JournalComment

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType 
          get_ParamType([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 02 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
  } // end of method IAPServerScripting::get_ParamType

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_ParamStringValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::get_ParamStringValue

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ParamStringValue([in] string  marshal( bstr) Param,
                                              [in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::set_ParamStringValue

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_ParamIntValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::get_ParamIntValue

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ParamIntValue([in] string  marshal( bstr) Param,
                                           [in] int32 retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::set_ParamIntValue

  .method public hidebysig newslot abstract virtual 
          instance void  GetParamRealValue([in] string  marshal( bstr) Param,
                                           [out] string&  marshal( bstr) uom,
                                           [out] float64& retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::GetParamRealValue

  .method public hidebysig newslot abstract virtual 
          instance void  SetParamRealValue([in] string  marshal( bstr) Param,
                                           [in] string  marshal( bstr) uom,
                                           [in] float64 newVal) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting::SetParamRealValue

  .method public hidebysig newslot abstract virtual 
          instance void  ProcessVarQuality() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 02 60 00 00 )                         // .. ..`..
  } // end of method IAPServerScripting::ProcessVarQuality

  .method public hidebysig newslot abstract virtual 
          instance void  SaveVariables([in] string  marshal( bstr) filename,
                                       [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 02 60 00 00 )                         // ..!..`..
  } // end of method IAPServerScripting::SaveVariables

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateVariables([in] string  marshal( bstr) filename,
                                         [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 22 00 02 60 00 00 )                         // .."..`..
  } // end of method IAPServerScripting::UpdateVariables

  .method public hidebysig newslot abstract virtual 
          instance void  RestoreVariables([in] string  marshal( bstr) filename,
                                          [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 23 00 02 60 00 00 )                         // ..#..`..
  } // end of method IAPServerScripting::RestoreVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Rmiss() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 02 60 00 00 )                         // ..$..`..
  } // end of method IAPServerScripting::get_Rmiss

  .method public hidebysig newslot abstract virtual 
          instance void  JournalLine([in] string  marshal( bstr) s) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 26 00 02 60 00 00 )                         // ..&..`..
  } // end of method IAPServerScripting::JournalLine

  .method public hidebysig newslot abstract virtual 
          instance int32  SetVarAttr(string  marshal( bstr) Name,
                                     int32& ID,
                                     int32 attr,
                                     float64 val,
                                     string  marshal( bstr) unit,
                                     int32 spec) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 27 00 02 60 00 00 )                         // ..'..`..
  } // end of method IAPServerScripting::SetVarAttr

  .method public hidebysig newslot abstract virtual 
          instance int32  Solve() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 28 00 02 60 00 00 )                         // ..(..`..
  } // end of method IAPServerScripting::Solve

  .method public hidebysig newslot abstract virtual 
          instance void  SetInt(int32 iin) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 29 00 02 60 00 00 )                         // ..)..`..
  } // end of method IAPServerScripting::SetInt

  .method public hidebysig newslot abstract virtual 
          instance int32  InqEnabledInactiveSpecGroups(string&  marshal( bstr) sOut,
                                                       int32 bDestroy) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 30 00 02 60 00 00 )                         // ..0..`..
  } // end of method IAPServerScripting::InqEnabledInactiveSpecGroups

  .method public hidebysig newslot abstract virtual 
          instance void  ExecuteScript([in] string  marshal( bstr) commandString) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 25 00 02 60 00 00 )                         // ..%..`..
  } // end of method IAPServerScripting::ExecuteScript

  .property callconv(8) object EOSimulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerScripting::get_EOSimulation()
    .set instance void AspenTech.AspenPlus.APServer.IAPServerScripting::set_EOSimulation(object)
  } // end of property IAPServerScripting::EOSimulation
  .property callconv(8) class AspenTech.AspenPlus.APServer.APServerBlockCollection
          Blocks()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APServerBlockCollection AspenTech.AspenPlus.APServer.IAPServerScripting::get_Blocks()
  } // end of property IAPServerScripting::Blocks
  .property callconv(8) class AspenTech.AspenPlus.APServer.IStream
          FileStream(string,
                     int32,
                     int32,
                     int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.IStream AspenTech.AspenPlus.APServer.IAPServerScripting::get_FileStream(string,
                                                                                                                             int32,
                                                                                                                             int32,
                                                                                                                             int32)
  } // end of property IAPServerScripting::FileStream
  .property callconv(8) object DefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerScripting::get_DefaultProperties(string)
  } // end of property IAPServerScripting::DefaultProperties
  .property callconv(8) object DupDefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 01 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerScripting::get_DupDefaultProperties(string)
  } // end of property IAPServerScripting::DupDefaultProperties
  .property callconv(8) object CatalogXMLMgr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 01 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerScripting::get_CatalogXMLMgr()
  } // end of property IAPServerScripting::CatalogXMLMgr
  .property callconv(8) class AspenTech.AspenPlus.APServer.APACMExpCollection
          ACMExpModels()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 01 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APACMExpCollection AspenTech.AspenPlus.APServer.IAPServerScripting::get_ACMExpModels()
  } // end of property IAPServerScripting::ACMExpModels
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus
          BlockStatus(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus AspenTech.AspenPlus.APServer.IAPServerScripting::get_BlockStatus(string)
  } // end of property IAPServerScripting::BlockStatus
  .property callconv(8) int32 NumberIter()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServerScripting::get_NumberIter()
  } // end of property IAPServerScripting::NumberIter
  .property callconv(8) int32 Converged(string&)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServerScripting::get_Converged(string&)
  } // end of property IAPServerScripting::Converged
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType
          ParamType(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 02 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType AspenTech.AspenPlus.APServer.IAPServerScripting::get_ParamType(string)
  } // end of property IAPServerScripting::ParamType
  .property callconv(8) string ParamStringValue(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.IAPServerScripting::get_ParamStringValue(string)
    .set instance void AspenTech.AspenPlus.APServer.IAPServerScripting::set_ParamStringValue(string,
                                                                                             string)
  } // end of property IAPServerScripting::ParamStringValue
  .property callconv(8) int32 ParamIntValue(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.APServer.IAPServerScripting::set_ParamIntValue(string,
                                                                                          int32)
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServerScripting::get_ParamIntValue(string)
  } // end of property IAPServerScripting::ParamIntValue
  .property callconv(8) float64 Rmiss()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 02 60 00 00 )                         // ..$..`..
    .get instance float64 AspenTech.AspenPlus.APServer.IAPServerScripting::get_Rmiss()
  } // end of property IAPServerScripting::Rmiss
} // end of class AspenTech.AspenPlus.APServer.IAPServerScripting

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPServerScripting2
       implements AspenTech.AspenPlus.APServer.IAPServerScripting
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 41 31 31 37 38 31 35 2D 32 36 38 32   // ..$0A117815-2682
                                                                                                  2D 34 41 39 41 2D 39 41 34 39 2D 45 35 44 45 33   // -4A9A-9A49-E5DE3
                                                                                                  33 44 38 30 35 43 45 00 00 )                      // 3D805CE..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::ResolveBlock

  .method public hidebysig newslot abstract virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::TriggerCancel

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_EOSimulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::get_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::set_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APServerBlockCollection 
          marshal( interface ) 
          get_Blocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::get_Blocks

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          get_FileStream([in] string  marshal( bstr) Name,
                         [in] int32 dwDesiredAccess,
                         [in] int32 dwShareMode,
                         [in] int32 dwCreationDisposition) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
  } // end of method IAPServerScripting2::get_FileStream

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
  } // end of method IAPServerScripting2::get_DefaultProperties

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DupDefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::get_DupDefaultProperties

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_CatalogXMLMgr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::get_CatalogXMLMgr

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APACMExpCollection 
          marshal( interface ) 
          get_ACMExpModels() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::get_ACMExpModels

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus 
          get_BlockStatus([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
  } // end of method IAPServerScripting2::get_BlockStatus

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NumberIter() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::get_NumberIter

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Converged([out] string&  marshal( bstr) failure) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::get_Converged

  .method public hidebysig newslot abstract virtual 
          instance void  WriteHistory([in] string  marshal( bstr) line) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::WriteHistory

  .method public hidebysig newslot abstract virtual 
          instance void  JournalComment([in] string  marshal( bstr) comment) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::JournalComment

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType 
          get_ParamType([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 02 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
  } // end of method IAPServerScripting2::get_ParamType

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_ParamStringValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::get_ParamStringValue

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ParamStringValue([in] string  marshal( bstr) Param,
                                              [in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::set_ParamStringValue

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_ParamIntValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::get_ParamIntValue

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ParamIntValue([in] string  marshal( bstr) Param,
                                           [in] int32 retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::set_ParamIntValue

  .method public hidebysig newslot abstract virtual 
          instance void  GetParamRealValue([in] string  marshal( bstr) Param,
                                           [out] string&  marshal( bstr) uom,
                                           [out] float64& retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::GetParamRealValue

  .method public hidebysig newslot abstract virtual 
          instance void  SetParamRealValue([in] string  marshal( bstr) Param,
                                           [in] string  marshal( bstr) uom,
                                           [in] float64 newVal) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerScripting2::SetParamRealValue

  .method public hidebysig newslot abstract virtual 
          instance void  ProcessVarQuality() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 02 60 00 00 )                         // .. ..`..
  } // end of method IAPServerScripting2::ProcessVarQuality

  .method public hidebysig newslot abstract virtual 
          instance void  SaveVariables([in] string  marshal( bstr) filename,
                                       [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 02 60 00 00 )                         // ..!..`..
  } // end of method IAPServerScripting2::SaveVariables

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateVariables([in] string  marshal( bstr) filename,
                                         [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 22 00 02 60 00 00 )                         // .."..`..
  } // end of method IAPServerScripting2::UpdateVariables

  .method public hidebysig newslot abstract virtual 
          instance void  RestoreVariables([in] string  marshal( bstr) filename,
                                          [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 23 00 02 60 00 00 )                         // ..#..`..
  } // end of method IAPServerScripting2::RestoreVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Rmiss() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 02 60 00 00 )                         // ..$..`..
  } // end of method IAPServerScripting2::get_Rmiss

  .method public hidebysig newslot abstract virtual 
          instance void  JournalLine([in] string  marshal( bstr) s) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 26 00 02 60 00 00 )                         // ..&..`..
  } // end of method IAPServerScripting2::JournalLine

  .method public hidebysig newslot abstract virtual 
          instance int32  SetVarAttr(string  marshal( bstr) Name,
                                     int32& ID,
                                     int32 attr,
                                     float64 val,
                                     string  marshal( bstr) unit,
                                     int32 spec) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 27 00 02 60 00 00 )                         // ..'..`..
  } // end of method IAPServerScripting2::SetVarAttr

  .method public hidebysig newslot abstract virtual 
          instance int32  Solve() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 28 00 02 60 00 00 )                         // ..(..`..
  } // end of method IAPServerScripting2::Solve

  .method public hidebysig newslot abstract virtual 
          instance void  SetInt(int32 iin) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 29 00 02 60 00 00 )                         // ..)..`..
  } // end of method IAPServerScripting2::SetInt

  .method public hidebysig newslot abstract virtual 
          instance int32  InqEnabledInactiveSpecGroups(string&  marshal( bstr) sOut,
                                                       int32 bDestroy) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 30 00 02 60 00 00 )                         // ..0..`..
  } // end of method IAPServerScripting2::InqEnabledInactiveSpecGroups

  .method public hidebysig newslot abstract virtual 
          instance void  ExecuteScript([in] string  marshal( bstr) commandString) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 25 00 02 60 00 00 )                         // ..%..`..
  } // end of method IAPServerScripting2::ExecuteScript

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_ConvergenceFailureText() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 31 00 02 60 00 00 )                         // ..1..`..
  } // end of method IAPServerScripting2::get_ConvergenceFailureText

  .property callconv(8) object EOSimulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerScripting2::get_EOSimulation()
    .set instance void AspenTech.AspenPlus.APServer.IAPServerScripting2::set_EOSimulation(object)
  } // end of property IAPServerScripting2::EOSimulation
  .property callconv(8) class AspenTech.AspenPlus.APServer.APServerBlockCollection
          Blocks()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APServerBlockCollection AspenTech.AspenPlus.APServer.IAPServerScripting2::get_Blocks()
  } // end of property IAPServerScripting2::Blocks
  .property callconv(8) class AspenTech.AspenPlus.APServer.IStream
          FileStream(string,
                     int32,
                     int32,
                     int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.IStream AspenTech.AspenPlus.APServer.IAPServerScripting2::get_FileStream(string,
                                                                                                                              int32,
                                                                                                                              int32,
                                                                                                                              int32)
  } // end of property IAPServerScripting2::FileStream
  .property callconv(8) object DefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerScripting2::get_DefaultProperties(string)
  } // end of property IAPServerScripting2::DefaultProperties
  .property callconv(8) object DupDefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 01 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerScripting2::get_DupDefaultProperties(string)
  } // end of property IAPServerScripting2::DupDefaultProperties
  .property callconv(8) object CatalogXMLMgr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 01 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerScripting2::get_CatalogXMLMgr()
  } // end of property IAPServerScripting2::CatalogXMLMgr
  .property callconv(8) class AspenTech.AspenPlus.APServer.APACMExpCollection
          ACMExpModels()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 01 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APACMExpCollection AspenTech.AspenPlus.APServer.IAPServerScripting2::get_ACMExpModels()
  } // end of property IAPServerScripting2::ACMExpModels
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus
          BlockStatus(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus AspenTech.AspenPlus.APServer.IAPServerScripting2::get_BlockStatus(string)
  } // end of property IAPServerScripting2::BlockStatus
  .property callconv(8) int32 NumberIter()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServerScripting2::get_NumberIter()
  } // end of property IAPServerScripting2::NumberIter
  .property callconv(8) int32 Converged(string&)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServerScripting2::get_Converged(string&)
  } // end of property IAPServerScripting2::Converged
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType
          ParamType(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 02 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType AspenTech.AspenPlus.APServer.IAPServerScripting2::get_ParamType(string)
  } // end of property IAPServerScripting2::ParamType
  .property callconv(8) string ParamStringValue(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.IAPServerScripting2::get_ParamStringValue(string)
    .set instance void AspenTech.AspenPlus.APServer.IAPServerScripting2::set_ParamStringValue(string,
                                                                                              string)
  } // end of property IAPServerScripting2::ParamStringValue
  .property callconv(8) int32 ParamIntValue(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServerScripting2::get_ParamIntValue(string)
    .set instance void AspenTech.AspenPlus.APServer.IAPServerScripting2::set_ParamIntValue(string,
                                                                                           int32)
  } // end of property IAPServerScripting2::ParamIntValue
  .property callconv(8) float64 Rmiss()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 02 60 00 00 )                         // ..$..`..
    .get instance float64 AspenTech.AspenPlus.APServer.IAPServerScripting2::get_Rmiss()
  } // end of property IAPServerScripting2::Rmiss
  .property callconv(8) string ConvergenceFailureText()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 31 00 02 60 00 00 )                         // ..1..`..
    .get instance string AspenTech.AspenPlus.APServer.IAPServerScripting2::get_ConvergenceFailureText()
  } // end of property IAPServerScripting2::ConvergenceFailureText
} // end of class AspenTech.AspenPlus.APServer.IAPServerScripting2

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPServer4
       implements AspenTech.AspenPlus.APServer.IAPServerScripting2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 35 37 42 39 34 30 36 45 2D 46 39 31 39   // ..$57B9406E-F919
                                                                                                  2D 34 37 37 38 2D 39 35 36 46 2D 33 38 36 31 32   // -4778-956F-38612
                                                                                                  39 34 42 34 46 41 31 00 00 )                      // 94B4FA1..
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::ResolveBlock

  .method public hidebysig newslot abstract virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::TriggerCancel

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_EOSimulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::set_EOSimulation

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APServerBlockCollection 
          marshal( interface ) 
          get_Blocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_Blocks

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          get_FileStream([in] string  marshal( bstr) Name,
                         [in] int32 dwDesiredAccess,
                         [in] int32 dwShareMode,
                         [in] int32 dwCreationDisposition) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_FileStream

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
  } // end of method IAPServer4::get_DefaultProperties

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_DupDefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_DupDefaultProperties

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_CatalogXMLMgr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_CatalogXMLMgr

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APACMExpCollection 
          marshal( interface ) 
          get_ACMExpModels() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 01 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_ACMExpModels

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus 
          get_BlockStatus([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
  } // end of method IAPServer4::get_BlockStatus

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NumberIter() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_NumberIter

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Converged([out] string&  marshal( bstr) failure) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_Converged

  .method public hidebysig newslot abstract virtual 
          instance void  WriteHistory([in] string  marshal( bstr) line) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::WriteHistory

  .method public hidebysig newslot abstract virtual 
          instance void  JournalComment([in] string  marshal( bstr) comment) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::JournalComment

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType 
          get_ParamType([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 02 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
  } // end of method IAPServer4::get_ParamType

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_ParamStringValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_ParamStringValue

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ParamStringValue([in] string  marshal( bstr) Param,
                                              [in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::set_ParamStringValue

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_ParamIntValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_ParamIntValue

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ParamIntValue([in] string  marshal( bstr) Param,
                                           [in] int32 retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::set_ParamIntValue

  .method public hidebysig newslot abstract virtual 
          instance void  GetParamRealValue([in] string  marshal( bstr) Param,
                                           [out] string&  marshal( bstr) uom,
                                           [out] float64& retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::GetParamRealValue

  .method public hidebysig newslot abstract virtual 
          instance void  SetParamRealValue([in] string  marshal( bstr) Param,
                                           [in] string  marshal( bstr) uom,
                                           [in] float64 newVal) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::SetParamRealValue

  .method public hidebysig newslot abstract virtual 
          instance void  ProcessVarQuality() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 02 60 00 00 )                         // .. ..`..
  } // end of method IAPServer4::ProcessVarQuality

  .method public hidebysig newslot abstract virtual 
          instance void  SaveVariables([in] string  marshal( bstr) filename,
                                       [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 02 60 00 00 )                         // ..!..`..
  } // end of method IAPServer4::SaveVariables

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateVariables([in] string  marshal( bstr) filename,
                                         [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 22 00 02 60 00 00 )                         // .."..`..
  } // end of method IAPServer4::UpdateVariables

  .method public hidebysig newslot abstract virtual 
          instance void  RestoreVariables([in] string  marshal( bstr) filename,
                                          [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 23 00 02 60 00 00 )                         // ..#..`..
  } // end of method IAPServer4::RestoreVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Rmiss() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 02 60 00 00 )                         // ..$..`..
  } // end of method IAPServer4::get_Rmiss

  .method public hidebysig newslot abstract virtual 
          instance void  JournalLine([in] string  marshal( bstr) s) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 26 00 02 60 00 00 )                         // ..&..`..
  } // end of method IAPServer4::JournalLine

  .method public hidebysig newslot abstract virtual 
          instance int32  SetVarAttr(string  marshal( bstr) Name,
                                     int32& ID,
                                     int32 attr,
                                     float64 val,
                                     string  marshal( bstr) unit,
                                     int32 spec) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 27 00 02 60 00 00 )                         // ..'..`..
  } // end of method IAPServer4::SetVarAttr

  .method public hidebysig newslot abstract virtual 
          instance int32  Solve() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 28 00 02 60 00 00 )                         // ..(..`..
  } // end of method IAPServer4::Solve

  .method public hidebysig newslot abstract virtual 
          instance void  SetInt(int32 iin) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 29 00 02 60 00 00 )                         // ..)..`..
  } // end of method IAPServer4::SetInt

  .method public hidebysig newslot abstract virtual 
          instance int32  InqEnabledInactiveSpecGroups(string&  marshal( bstr) sOut,
                                                       int32 bDestroy) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 30 00 02 60 00 00 )                         // ..0..`..
  } // end of method IAPServer4::InqEnabledInactiveSpecGroups

  .method public hidebysig newslot abstract virtual 
          instance void  ExecuteScript([in] string  marshal( bstr) commandString) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 25 00 02 60 00 00 )                         // ..%..`..
  } // end of method IAPServer4::ExecuteScript

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_ConvergenceFailureText() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 31 00 02 60 00 00 )                         // ..1..`..
  } // end of method IAPServer4::get_ConvergenceFailureText

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_SolvingFlowsheet([in] int32 fsBead) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 10 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::set_SolvingFlowsheet

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_SolvingFlowsheet() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 10 02 60 00 00 )                         // .....`..
  } // end of method IAPServer4::get_SolvingFlowsheet

  .property callconv(8) object EOSimulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.APServer.IAPServer4::set_EOSimulation(object)
    .get instance object AspenTech.AspenPlus.APServer.IAPServer4::get_EOSimulation()
  } // end of property IAPServer4::EOSimulation
  .property callconv(8) class AspenTech.AspenPlus.APServer.APServerBlockCollection
          Blocks()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APServerBlockCollection AspenTech.AspenPlus.APServer.IAPServer4::get_Blocks()
  } // end of property IAPServer4::Blocks
  .property callconv(8) class AspenTech.AspenPlus.APServer.IStream
          FileStream(string,
                     int32,
                     int32,
                     int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.IStream AspenTech.AspenPlus.APServer.IAPServer4::get_FileStream(string,
                                                                                                                     int32,
                                                                                                                     int32,
                                                                                                                     int32)
  } // end of property IAPServer4::FileStream
  .property callconv(8) object DefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServer4::get_DefaultProperties(string)
  } // end of property IAPServer4::DefaultProperties
  .property callconv(8) object DupDefaultProperties(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 01 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServer4::get_DupDefaultProperties(string)
  } // end of property IAPServer4::DupDefaultProperties
  .property callconv(8) object CatalogXMLMgr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 01 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServer4::get_CatalogXMLMgr()
  } // end of property IAPServer4::CatalogXMLMgr
  .property callconv(8) class AspenTech.AspenPlus.APServer.APACMExpCollection
          ACMExpModels()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 01 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APACMExpCollection AspenTech.AspenPlus.APServer.IAPServer4::get_ACMExpModels()
  } // end of property IAPServer4::ACMExpModels
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus
          BlockStatus(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 02 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus AspenTech.AspenPlus.APServer.IAPServer4::get_BlockStatus(string)
  } // end of property IAPServer4::BlockStatus
  .property callconv(8) int32 NumberIter()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServer4::get_NumberIter()
  } // end of property IAPServer4::NumberIter
  .property callconv(8) int32 Converged(string&)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServer4::get_Converged(string&)
  } // end of property IAPServer4::Converged
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType
          ParamType(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 02 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType AspenTech.AspenPlus.APServer.IAPServer4::get_ParamType(string)
  } // end of property IAPServer4::ParamType
  .property callconv(8) string ParamStringValue(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.IAPServer4::get_ParamStringValue(string)
    .set instance void AspenTech.AspenPlus.APServer.IAPServer4::set_ParamStringValue(string,
                                                                                     string)
  } // end of property IAPServer4::ParamStringValue
  .property callconv(8) int32 ParamIntValue(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServer4::get_ParamIntValue(string)
    .set instance void AspenTech.AspenPlus.APServer.IAPServer4::set_ParamIntValue(string,
                                                                                  int32)
  } // end of property IAPServer4::ParamIntValue
  .property callconv(8) float64 Rmiss()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 02 60 00 00 )                         // ..$..`..
    .get instance float64 AspenTech.AspenPlus.APServer.IAPServer4::get_Rmiss()
  } // end of property IAPServer4::Rmiss
  .property callconv(8) string ConvergenceFailureText()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 31 00 02 60 00 00 )                         // ..1..`..
    .get instance string AspenTech.AspenPlus.APServer.IAPServer4::get_ConvergenceFailureText()
  } // end of property IAPServer4::ConvergenceFailureText
  .property callconv(8) int32 SolvingFlowsheet()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 10 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.APServer.IAPServer4::set_SolvingFlowsheet(int32)
    .get instance int32 AspenTech.AspenPlus.APServer.IAPServer4::get_SolvingFlowsheet()
  } // end of property IAPServer4::SolvingFlowsheet
} // end of class AspenTech.AspenPlus.APServer.IAPServer4

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPServerDispatch
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 10 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 33 31 43 44 30 31 44 41 2D 30 43 37 36   // ..$31CD01DA-0C76
                                                                                                  2D 34 46 45 39 2D 42 44 37 42 2D 39 36 32 44 33   // -4FE9-BD7B-962D3
                                                                                                  30 30 42 45 43 41 46 00 00 )                      // 00BECAF..
  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_EOUnits() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::get_EOUnits

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_EOUnits(object  marshal( struct) A_1) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::set_EOUnits

  .method public hidebysig newslot abstract virtual 
          instance void  GetService([in] string  marshal( bstr) bService,
                                    [out] object&  marshal( iunknown ) ppUnk) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::GetService

  .method public hidebysig newslot abstract virtual 
          instance void  SimExecuteScript([in] string  marshal( bstr) commandString,
                                          [in] object  marshal( struct) vtVal) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::SimExecuteScript

  .method public hidebysig newslot abstract virtual 
          instance void  ToggleEOSimEvents(int32 iMask,
                                           bool bEnable) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::ToggleEOSimEvents

  .method public hidebysig newslot abstract virtual 
          instance void  AddCapeOpenBlk([in] string  marshal( bstr) bsDisplayName,
                                        [in] string  marshal( bstr) capeId,
                                        [in] valuetype AspenTech.AspenPlus.APServer.eAPCapeOpenIdOption eIdType,
                                        [out] object&  marshal( iunknown ) ppUnk) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .param [3]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 41 50 43 61 70 65 4F 70 65 6E 49 64 4F 70 74   // eAPCapeOpenIdOpt
                                                                                                            69 6F 6E 00 00 )                                  // ion..
  } // end of method IAPServerDispatch::AddCapeOpenBlk

  .method public hidebysig newslot abstract virtual 
          instance void  GetCapeBlockService([in] object  marshal( iunknown ) pBlkIUnk,
                                             [in] string  marshal( bstr) bsServiceId,
                                             [out] object&  marshal( iunknown ) ppUnk) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::GetCapeBlockService

  .method public hidebysig newslot abstract virtual 
          instance void  SaveCOBlkToStg([in] object  marshal( struct) bsCapefullId,
                                        [in] object  marshal( iunknown ) pUnk) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::SaveCOBlkToStg

  .method public hidebysig newslot abstract virtual 
          instance void  LoadCOBlkToStg([in] object  marshal( struct) bsCapefullId,
                                        [in] object  marshal( iunknown ) pUnk) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::LoadCOBlkToStg

  .method public hidebysig newslot abstract virtual 
          instance void  StreamSummary([in] object  marshal( struct) vtXMLTFF,
                                       [in] object  marshal( struct) vtScope,
                                       [in] object  marshal( struct) vtScopeType,
                                       [out] object&  marshal( struct) vtXMLResult) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::StreamSummary

  .method public hidebysig newslot abstract virtual 
          instance void  GetValidAPStreams([in] object  marshal( struct) vtScope,
                                           [out] object&  marshal( struct) vtXMLStreams) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::GetValidAPStreams

  .method public hidebysig newslot abstract virtual 
          instance void  GetLicenseInfo([out] string&  marshal( bstr) bstrLicInfo) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 04 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::GetLicenseInfo

  .method public hidebysig newslot abstract virtual 
          instance void  CheckFeatureLicense([in] object  marshal( struct) vtFeature,
                                             [out] object&  marshal( struct) vtCookie) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 04 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::CheckFeatureLicense

  .method public hidebysig newslot abstract virtual 
          instance void  GetSpDistilAnalysis([out] object&  marshal( iunknown ) ppUnk) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 04 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::GetSpDistilAnalysis

  .method public hidebysig newslot abstract virtual 
          instance void  GetASCDDistil([out] object&  marshal( iunknown ) ppUnk) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
  } // end of method IAPServerDispatch::GetASCDDistil

  .property callconv(8) object EOUnits()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPServerDispatch::get_EOUnits()
    .set instance void AspenTech.AspenPlus.APServer.IAPServerDispatch::set_EOUnits(object)
  } // end of property IAPServerDispatch::EOUnits
} // end of class AspenTech.AspenPlus.APServer.IAPServerDispatch

.class public auto ansi import AspenTech.AspenPlus.APServer.APServerClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.IAPServer,
                  AspenTech.AspenPlus.APServer.APServer,
                  AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event,
                  AspenTech.AspenPlus.APServer.IAPServerRte,
                  AspenTech.AspenPlus.APServer.IAPServerScripting,
                  AspenTech.AspenPlus.APServer.IAPServerScripting2,
                  AspenTech.AspenPlus.APServer.IAPServer4,
                  AspenTech.AspenPlus.APServer.IAPServerDispatch
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComSourceInterfacesAttribute::.ctor(string) = ( 01 00 32 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..2AspenTech.Asp
                                                                                                                 65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                 5F 49 41 50 53 65 72 76 65 72 53 69 6D 45 76 65   // _IAPServerSimEve
                                                                                                                 6E 74 73 00 00 00 00 )                            // nts....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 44 2D 45 31 31 31   // ..$6CCB144D-E111
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method APServerClass::.ctor

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPServer::ResolveBlock
  } // end of method APServerClass::ResolveBlock

  .method public hidebysig newslot virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPServer::TriggerCancel
  } // end of method APServerClass::TriggerCancel

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          get_EOSimulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPServer::get_EOSimulation
  } // end of method APServerClass::get_EOSimulation

  .method public hidebysig newslot specialname virtual 
          instance void  set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPServer::set_EOSimulation
  } // end of method APServerClass::set_EOSimulation

  .method public hidebysig newslot virtual 
          instance void  add_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event::add_OnEvent
  } // end of method APServerClass::add_OnEvent

  .method public hidebysig newslot virtual 
          instance void  remove_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event::remove_OnEvent
  } // end of method APServerClass::remove_OnEvent

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerRte_ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::ResolveBlock
  } // end of method APServerClass::IAPServerRte_ResolveBlock

  .method public hidebysig newslot virtual 
          instance void  IAPServerRte_TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::TriggerCancel
  } // end of method APServerClass::IAPServerRte_TriggerCancel

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerRte_get_EOSimulation() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_EOSimulation
  } // end of method APServerClass::IAPServerRte_get_EOSimulation

  .method public hidebysig newslot specialname virtual 
          instance void  IAPServerRte_set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::set_EOSimulation
  } // end of method APServerClass::IAPServerRte_set_EOSimulation

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APServerBlockCollection 
          marshal( interface ) 
          get_Blocks() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_Blocks
  } // end of method APServerClass::get_Blocks

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          get_FileStream([in] string  marshal( bstr) Name,
                         [in] int32 dwDesiredAccess,
                         [in] int32 dwShareMode,
                         [in] int32 dwCreationDisposition) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_FileStream
  } // end of method APServerClass::get_FileStream

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          get_DefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_DefaultProperties
  } // end of method APServerClass::get_DefaultProperties

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          get_DupDefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_DupDefaultProperties
  } // end of method APServerClass::get_DupDefaultProperties

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          get_CatalogXMLMgr() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_CatalogXMLMgr
  } // end of method APServerClass::get_CatalogXMLMgr

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APACMExpCollection 
          marshal( interface ) 
          get_ACMExpModels() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_ACMExpModels
  } // end of method APServerClass::get_ACMExpModels

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus 
          get_BlockStatus([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_BlockStatus
  } // end of method APServerClass::get_BlockStatus

  .method public hidebysig newslot specialname virtual 
          instance int32  get_NumberIter() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_NumberIter
  } // end of method APServerClass::get_NumberIter

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Converged([out] string&  marshal( bstr) failure) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_Converged
  } // end of method APServerClass::get_Converged

  .method public hidebysig newslot virtual 
          instance void  WriteHistory([in] string  marshal( bstr) line) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::WriteHistory
  } // end of method APServerClass::WriteHistory

  .method public hidebysig newslot virtual 
          instance void  JournalComment([in] string  marshal( bstr) comment) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::JournalComment
  } // end of method APServerClass::JournalComment

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType 
          get_ParamType([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_ParamType
  } // end of method APServerClass::get_ParamType

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_ParamStringValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_ParamStringValue
  } // end of method APServerClass::get_ParamStringValue

  .method public hidebysig newslot specialname virtual 
          instance void  set_ParamStringValue([in] string  marshal( bstr) Param,
                                              [in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::set_ParamStringValue
  } // end of method APServerClass::set_ParamStringValue

  .method public hidebysig newslot specialname virtual 
          instance int32  get_ParamIntValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_ParamIntValue
  } // end of method APServerClass::get_ParamIntValue

  .method public hidebysig newslot specialname virtual 
          instance void  set_ParamIntValue([in] string  marshal( bstr) Param,
                                           [in] int32 retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::set_ParamIntValue
  } // end of method APServerClass::set_ParamIntValue

  .method public hidebysig newslot virtual 
          instance void  GetParamRealValue([in] string  marshal( bstr) Param,
                                           [out] string&  marshal( bstr) uom,
                                           [out] float64& retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::GetParamRealValue
  } // end of method APServerClass::GetParamRealValue

  .method public hidebysig newslot virtual 
          instance void  SetParamRealValue([in] string  marshal( bstr) Param,
                                           [in] string  marshal( bstr) uom,
                                           [in] float64 newVal) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::SetParamRealValue
  } // end of method APServerClass::SetParamRealValue

  .method public hidebysig newslot virtual 
          instance void  ProcessVarQuality() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::ProcessVarQuality
  } // end of method APServerClass::ProcessVarQuality

  .method public hidebysig newslot virtual 
          instance void  SaveVariables([in] string  marshal( bstr) filename,
                                       [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::SaveVariables
  } // end of method APServerClass::SaveVariables

  .method public hidebysig newslot virtual 
          instance void  UpdateVariables([in] string  marshal( bstr) filename,
                                         [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::UpdateVariables
  } // end of method APServerClass::UpdateVariables

  .method public hidebysig newslot virtual 
          instance void  RestoreVariables([in] string  marshal( bstr) filename,
                                          [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::RestoreVariables
  } // end of method APServerClass::RestoreVariables

  .method public hidebysig newslot specialname virtual 
          instance float64  get_Rmiss() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::get_Rmiss
  } // end of method APServerClass::get_Rmiss

  .method public hidebysig newslot virtual 
          instance void  JournalLine([in] string  marshal( bstr) s) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::JournalLine
  } // end of method APServerClass::JournalLine

  .method public hidebysig newslot virtual 
          instance int32  SetVarAttr(string  marshal( bstr) Name,
                                     int32& ID,
                                     int32 attr,
                                     float64 val,
                                     string  marshal( bstr) unit,
                                     int32 spec) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::SetVarAttr
  } // end of method APServerClass::SetVarAttr

  .method public hidebysig newslot virtual 
          instance int32  Solve() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::Solve
  } // end of method APServerClass::Solve

  .method public hidebysig newslot virtual 
          instance void  SetInt(int32 iin) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::SetInt
  } // end of method APServerClass::SetInt

  .method public hidebysig newslot virtual 
          instance int32  InqEnabledInactiveSpecGroups(string&  marshal( bstr) sOut,
                                                       int32 bDestroy) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerRte::InqEnabledInactiveSpecGroups
  } // end of method APServerClass::InqEnabledInactiveSpecGroups

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerScripting_ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::ResolveBlock
  } // end of method APServerClass::IAPServerScripting_ResolveBlock

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::TriggerCancel
  } // end of method APServerClass::IAPServerScripting_TriggerCancel

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerScripting_get_EOSimulation() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_EOSimulation
  } // end of method APServerClass::IAPServerScripting_get_EOSimulation

  .method public hidebysig newslot specialname virtual 
          instance void  IAPServerScripting_set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::set_EOSimulation
  } // end of method APServerClass::IAPServerScripting_set_EOSimulation

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APServerBlockCollection 
          marshal( interface ) 
          IAPServerScripting_get_Blocks() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_Blocks
  } // end of method APServerClass::IAPServerScripting_get_Blocks

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          IAPServerScripting_get_FileStream([in] string  marshal( bstr) Name,
                                            [in] int32 dwDesiredAccess,
                                            [in] int32 dwShareMode,
                                            [in] int32 dwCreationDisposition) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_FileStream
  } // end of method APServerClass::IAPServerScripting_get_FileStream

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerScripting_get_DefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_DefaultProperties
  } // end of method APServerClass::IAPServerScripting_get_DefaultProperties

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerScripting_get_DupDefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_DupDefaultProperties
  } // end of method APServerClass::IAPServerScripting_get_DupDefaultProperties

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerScripting_get_CatalogXMLMgr() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_CatalogXMLMgr
  } // end of method APServerClass::IAPServerScripting_get_CatalogXMLMgr

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APACMExpCollection 
          marshal( interface ) 
          IAPServerScripting_get_ACMExpModels() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_ACMExpModels
  } // end of method APServerClass::IAPServerScripting_get_ACMExpModels

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus 
          IAPServerScripting_get_BlockStatus([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_BlockStatus
  } // end of method APServerClass::IAPServerScripting_get_BlockStatus

  .method public hidebysig newslot specialname virtual 
          instance int32  IAPServerScripting_get_NumberIter() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_NumberIter
  } // end of method APServerClass::IAPServerScripting_get_NumberIter

  .method public hidebysig newslot specialname virtual 
          instance int32  IAPServerScripting_get_Converged([out] string&  marshal( bstr) failure) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_Converged
  } // end of method APServerClass::IAPServerScripting_get_Converged

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_WriteHistory([in] string  marshal( bstr) line) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::WriteHistory
  } // end of method APServerClass::IAPServerScripting_WriteHistory

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_JournalComment([in] string  marshal( bstr) comment) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::JournalComment
  } // end of method APServerClass::IAPServerScripting_JournalComment

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType 
          IAPServerScripting_get_ParamType([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_ParamType
  } // end of method APServerClass::IAPServerScripting_get_ParamType

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          IAPServerScripting_get_ParamStringValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_ParamStringValue
  } // end of method APServerClass::IAPServerScripting_get_ParamStringValue

  .method public hidebysig newslot specialname virtual 
          instance void  IAPServerScripting_set_ParamStringValue([in] string  marshal( bstr) Param,
                                                                 [in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::set_ParamStringValue
  } // end of method APServerClass::IAPServerScripting_set_ParamStringValue

  .method public hidebysig newslot specialname virtual 
          instance int32  IAPServerScripting_get_ParamIntValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_ParamIntValue
  } // end of method APServerClass::IAPServerScripting_get_ParamIntValue

  .method public hidebysig newslot specialname virtual 
          instance void  IAPServerScripting_set_ParamIntValue([in] string  marshal( bstr) Param,
                                                              [in] int32 retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::set_ParamIntValue
  } // end of method APServerClass::IAPServerScripting_set_ParamIntValue

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_GetParamRealValue([in] string  marshal( bstr) Param,
                                                              [out] string&  marshal( bstr) uom,
                                                              [out] float64& retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::GetParamRealValue
  } // end of method APServerClass::IAPServerScripting_GetParamRealValue

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_SetParamRealValue([in] string  marshal( bstr) Param,
                                                              [in] string  marshal( bstr) uom,
                                                              [in] float64 newVal) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::SetParamRealValue
  } // end of method APServerClass::IAPServerScripting_SetParamRealValue

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_ProcessVarQuality() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::ProcessVarQuality
  } // end of method APServerClass::IAPServerScripting_ProcessVarQuality

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_SaveVariables([in] string  marshal( bstr) filename,
                                                          [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::SaveVariables
  } // end of method APServerClass::IAPServerScripting_SaveVariables

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_UpdateVariables([in] string  marshal( bstr) filename,
                                                            [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::UpdateVariables
  } // end of method APServerClass::IAPServerScripting_UpdateVariables

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_RestoreVariables([in] string  marshal( bstr) filename,
                                                             [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::RestoreVariables
  } // end of method APServerClass::IAPServerScripting_RestoreVariables

  .method public hidebysig newslot specialname virtual 
          instance float64  IAPServerScripting_get_Rmiss() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::get_Rmiss
  } // end of method APServerClass::IAPServerScripting_get_Rmiss

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_JournalLine([in] string  marshal( bstr) s) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::JournalLine
  } // end of method APServerClass::IAPServerScripting_JournalLine

  .method public hidebysig newslot virtual 
          instance int32  IAPServerScripting_SetVarAttr(string  marshal( bstr) Name,
                                                        int32& ID,
                                                        int32 attr,
                                                        float64 val,
                                                        string  marshal( bstr) unit,
                                                        int32 spec) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::SetVarAttr
  } // end of method APServerClass::IAPServerScripting_SetVarAttr

  .method public hidebysig newslot virtual 
          instance int32  IAPServerScripting_Solve() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::Solve
  } // end of method APServerClass::IAPServerScripting_Solve

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting_SetInt(int32 iin) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::SetInt
  } // end of method APServerClass::IAPServerScripting_SetInt

  .method public hidebysig newslot virtual 
          instance int32  IAPServerScripting_InqEnabledInactiveSpecGroups(string&  marshal( bstr) sOut,
                                                                          int32 bDestroy) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::InqEnabledInactiveSpecGroups
  } // end of method APServerClass::IAPServerScripting_InqEnabledInactiveSpecGroups

  .method public hidebysig newslot virtual 
          instance void  ExecuteScript([in] string  marshal( bstr) commandString) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting::ExecuteScript
  } // end of method APServerClass::ExecuteScript

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerScripting2_ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::ResolveBlock
  } // end of method APServerClass::IAPServerScripting2_ResolveBlock

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::TriggerCancel
  } // end of method APServerClass::IAPServerScripting2_TriggerCancel

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerScripting2_get_EOSimulation() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_EOSimulation
  } // end of method APServerClass::IAPServerScripting2_get_EOSimulation

  .method public hidebysig newslot specialname virtual 
          instance void  IAPServerScripting2_set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::set_EOSimulation
  } // end of method APServerClass::IAPServerScripting2_set_EOSimulation

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APServerBlockCollection 
          marshal( interface ) 
          IAPServerScripting2_get_Blocks() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_Blocks
  } // end of method APServerClass::IAPServerScripting2_get_Blocks

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          IAPServerScripting2_get_FileStream([in] string  marshal( bstr) Name,
                                             [in] int32 dwDesiredAccess,
                                             [in] int32 dwShareMode,
                                             [in] int32 dwCreationDisposition) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_FileStream
  } // end of method APServerClass::IAPServerScripting2_get_FileStream

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerScripting2_get_DefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_DefaultProperties
  } // end of method APServerClass::IAPServerScripting2_get_DefaultProperties

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerScripting2_get_DupDefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_DupDefaultProperties
  } // end of method APServerClass::IAPServerScripting2_get_DupDefaultProperties

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServerScripting2_get_CatalogXMLMgr() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_CatalogXMLMgr
  } // end of method APServerClass::IAPServerScripting2_get_CatalogXMLMgr

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APACMExpCollection 
          marshal( interface ) 
          IAPServerScripting2_get_ACMExpModels() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_ACMExpModels
  } // end of method APServerClass::IAPServerScripting2_get_ACMExpModels

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus 
          IAPServerScripting2_get_BlockStatus([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_BlockStatus
  } // end of method APServerClass::IAPServerScripting2_get_BlockStatus

  .method public hidebysig newslot specialname virtual 
          instance int32  IAPServerScripting2_get_NumberIter() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_NumberIter
  } // end of method APServerClass::IAPServerScripting2_get_NumberIter

  .method public hidebysig newslot specialname virtual 
          instance int32  IAPServerScripting2_get_Converged([out] string&  marshal( bstr) failure) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_Converged
  } // end of method APServerClass::IAPServerScripting2_get_Converged

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_WriteHistory([in] string  marshal( bstr) line) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::WriteHistory
  } // end of method APServerClass::IAPServerScripting2_WriteHistory

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_JournalComment([in] string  marshal( bstr) comment) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::JournalComment
  } // end of method APServerClass::IAPServerScripting2_JournalComment

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType 
          IAPServerScripting2_get_ParamType([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_ParamType
  } // end of method APServerClass::IAPServerScripting2_get_ParamType

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          IAPServerScripting2_get_ParamStringValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_ParamStringValue
  } // end of method APServerClass::IAPServerScripting2_get_ParamStringValue

  .method public hidebysig newslot specialname virtual 
          instance void  IAPServerScripting2_set_ParamStringValue([in] string  marshal( bstr) Param,
                                                                  [in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::set_ParamStringValue
  } // end of method APServerClass::IAPServerScripting2_set_ParamStringValue

  .method public hidebysig newslot specialname virtual 
          instance int32  IAPServerScripting2_get_ParamIntValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_ParamIntValue
  } // end of method APServerClass::IAPServerScripting2_get_ParamIntValue

  .method public hidebysig newslot specialname virtual 
          instance void  IAPServerScripting2_set_ParamIntValue([in] string  marshal( bstr) Param,
                                                               [in] int32 retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::set_ParamIntValue
  } // end of method APServerClass::IAPServerScripting2_set_ParamIntValue

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_GetParamRealValue([in] string  marshal( bstr) Param,
                                                               [out] string&  marshal( bstr) uom,
                                                               [out] float64& retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::GetParamRealValue
  } // end of method APServerClass::IAPServerScripting2_GetParamRealValue

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_SetParamRealValue([in] string  marshal( bstr) Param,
                                                               [in] string  marshal( bstr) uom,
                                                               [in] float64 newVal) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::SetParamRealValue
  } // end of method APServerClass::IAPServerScripting2_SetParamRealValue

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_ProcessVarQuality() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::ProcessVarQuality
  } // end of method APServerClass::IAPServerScripting2_ProcessVarQuality

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_SaveVariables([in] string  marshal( bstr) filename,
                                                           [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::SaveVariables
  } // end of method APServerClass::IAPServerScripting2_SaveVariables

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_UpdateVariables([in] string  marshal( bstr) filename,
                                                             [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::UpdateVariables
  } // end of method APServerClass::IAPServerScripting2_UpdateVariables

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_RestoreVariables([in] string  marshal( bstr) filename,
                                                              [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::RestoreVariables
  } // end of method APServerClass::IAPServerScripting2_RestoreVariables

  .method public hidebysig newslot specialname virtual 
          instance float64  IAPServerScripting2_get_Rmiss() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_Rmiss
  } // end of method APServerClass::IAPServerScripting2_get_Rmiss

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_JournalLine([in] string  marshal( bstr) s) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::JournalLine
  } // end of method APServerClass::IAPServerScripting2_JournalLine

  .method public hidebysig newslot virtual 
          instance int32  IAPServerScripting2_SetVarAttr(string  marshal( bstr) Name,
                                                         int32& ID,
                                                         int32 attr,
                                                         float64 val,
                                                         string  marshal( bstr) unit,
                                                         int32 spec) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::SetVarAttr
  } // end of method APServerClass::IAPServerScripting2_SetVarAttr

  .method public hidebysig newslot virtual 
          instance int32  IAPServerScripting2_Solve() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::Solve
  } // end of method APServerClass::IAPServerScripting2_Solve

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_SetInt(int32 iin) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::SetInt
  } // end of method APServerClass::IAPServerScripting2_SetInt

  .method public hidebysig newslot virtual 
          instance int32  IAPServerScripting2_InqEnabledInactiveSpecGroups(string&  marshal( bstr) sOut,
                                                                           int32 bDestroy) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::InqEnabledInactiveSpecGroups
  } // end of method APServerClass::IAPServerScripting2_InqEnabledInactiveSpecGroups

  .method public hidebysig newslot virtual 
          instance void  IAPServerScripting2_ExecuteScript([in] string  marshal( bstr) commandString) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::ExecuteScript
  } // end of method APServerClass::IAPServerScripting2_ExecuteScript

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_ConvergenceFailureText() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerScripting2::get_ConvergenceFailureText
  } // end of method APServerClass::get_ConvergenceFailureText

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          IAPServer4_ResolveBlock([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::ResolveBlock
  } // end of method APServerClass::IAPServer4_ResolveBlock

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::TriggerCancel
  } // end of method APServerClass::IAPServer4_TriggerCancel

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServer4_get_EOSimulation() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_EOSimulation
  } // end of method APServerClass::IAPServer4_get_EOSimulation

  .method public hidebysig newslot specialname virtual 
          instance void  IAPServer4_set_EOSimulation([in] object  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::set_EOSimulation
  } // end of method APServerClass::IAPServer4_set_EOSimulation

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APServerBlockCollection 
          marshal( interface ) 
          IAPServer4_get_Blocks() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_Blocks
  } // end of method APServerClass::IAPServer4_get_Blocks

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          IAPServer4_get_FileStream([in] string  marshal( bstr) Name,
                                    [in] int32 dwDesiredAccess,
                                    [in] int32 dwShareMode,
                                    [in] int32 dwCreationDisposition) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_FileStream
  } // end of method APServerClass::IAPServer4_get_FileStream

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServer4_get_DefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 41 00 00 00 00 00 )                         // ..A.....
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_DefaultProperties
  } // end of method APServerClass::IAPServer4_get_DefaultProperties

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServer4_get_DupDefaultProperties([in] string  marshal( bstr) bQualifier) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_DupDefaultProperties
  } // end of method APServerClass::IAPServer4_get_DupDefaultProperties

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPServer4_get_CatalogXMLMgr() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_CatalogXMLMgr
  } // end of method APServerClass::IAPServer4_get_CatalogXMLMgr

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APACMExpCollection 
          marshal( interface ) 
          IAPServer4_get_ACMExpModels() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_ACMExpModels
  } // end of method APServerClass::IAPServer4_get_ACMExpModels

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus 
          IAPServer4_get_BlockStatus([in] string  marshal( bstr) blockname) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_BlockStatus
  } // end of method APServerClass::IAPServer4_get_BlockStatus

  .method public hidebysig newslot specialname virtual 
          instance int32  IAPServer4_get_NumberIter() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_NumberIter
  } // end of method APServerClass::IAPServer4_get_NumberIter

  .method public hidebysig newslot specialname virtual 
          instance int32  IAPServer4_get_Converged([out] string&  marshal( bstr) failure) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_Converged
  } // end of method APServerClass::IAPServer4_get_Converged

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_WriteHistory([in] string  marshal( bstr) line) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::WriteHistory
  } // end of method APServerClass::IAPServer4_WriteHistory

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_JournalComment([in] string  marshal( bstr) comment) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::JournalComment
  } // end of method APServerClass::IAPServer4_JournalComment

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType 
          IAPServer4_get_ParamType([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_ParamType
  } // end of method APServerClass::IAPServer4_get_ParamType

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          IAPServer4_get_ParamStringValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_ParamStringValue
  } // end of method APServerClass::IAPServer4_get_ParamStringValue

  .method public hidebysig newslot specialname virtual 
          instance void  IAPServer4_set_ParamStringValue([in] string  marshal( bstr) Param,
                                                         [in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::set_ParamStringValue
  } // end of method APServerClass::IAPServer4_set_ParamStringValue

  .method public hidebysig newslot specialname virtual 
          instance int32  IAPServer4_get_ParamIntValue([in] string  marshal( bstr) Param) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_ParamIntValue
  } // end of method APServerClass::IAPServer4_get_ParamIntValue

  .method public hidebysig newslot specialname virtual 
          instance void  IAPServer4_set_ParamIntValue([in] string  marshal( bstr) Param,
                                                      [in] int32 retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::set_ParamIntValue
  } // end of method APServerClass::IAPServer4_set_ParamIntValue

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_GetParamRealValue([in] string  marshal( bstr) Param,
                                                      [out] string&  marshal( bstr) uom,
                                                      [out] float64& retval) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::GetParamRealValue
  } // end of method APServerClass::IAPServer4_GetParamRealValue

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_SetParamRealValue([in] string  marshal( bstr) Param,
                                                      [in] string  marshal( bstr) uom,
                                                      [in] float64 newVal) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::SetParamRealValue
  } // end of method APServerClass::IAPServer4_SetParamRealValue

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_ProcessVarQuality() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::ProcessVarQuality
  } // end of method APServerClass::IAPServer4_ProcessVarQuality

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_SaveVariables([in] string  marshal( bstr) filename,
                                                  [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::SaveVariables
  } // end of method APServerClass::IAPServer4_SaveVariables

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_UpdateVariables([in] string  marshal( bstr) filename,
                                                    [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::UpdateVariables
  } // end of method APServerClass::IAPServer4_UpdateVariables

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_RestoreVariables([in] string  marshal( bstr) filename,
                                                     [in] int32[]  marshal( safearray int32) vmask) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::RestoreVariables
  } // end of method APServerClass::IAPServer4_RestoreVariables

  .method public hidebysig newslot specialname virtual 
          instance float64  IAPServer4_get_Rmiss() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_Rmiss
  } // end of method APServerClass::IAPServer4_get_Rmiss

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_JournalLine([in] string  marshal( bstr) s) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::JournalLine
  } // end of method APServerClass::IAPServer4_JournalLine

  .method public hidebysig newslot virtual 
          instance int32  IAPServer4_SetVarAttr(string  marshal( bstr) Name,
                                                int32& ID,
                                                int32 attr,
                                                float64 val,
                                                string  marshal( bstr) unit,
                                                int32 spec) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::SetVarAttr
  } // end of method APServerClass::IAPServer4_SetVarAttr

  .method public hidebysig newslot virtual 
          instance int32  IAPServer4_Solve() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::Solve
  } // end of method APServerClass::IAPServer4_Solve

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_SetInt(int32 iin) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::SetInt
  } // end of method APServerClass::IAPServer4_SetInt

  .method public hidebysig newslot virtual 
          instance int32  IAPServer4_InqEnabledInactiveSpecGroups(string&  marshal( bstr) sOut,
                                                                  int32 bDestroy) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::InqEnabledInactiveSpecGroups
  } // end of method APServerClass::IAPServer4_InqEnabledInactiveSpecGroups

  .method public hidebysig newslot virtual 
          instance void  IAPServer4_ExecuteScript([in] string  marshal( bstr) commandString) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::ExecuteScript
  } // end of method APServerClass::IAPServer4_ExecuteScript

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          IAPServer4_get_ConvergenceFailureText() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_ConvergenceFailureText
  } // end of method APServerClass::IAPServer4_get_ConvergenceFailureText

  .method public hidebysig newslot specialname virtual 
          instance void  set_SolvingFlowsheet([in] int32 fsBead) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::set_SolvingFlowsheet
  } // end of method APServerClass::set_SolvingFlowsheet

  .method public hidebysig newslot specialname virtual 
          instance int32  get_SolvingFlowsheet() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServer4::get_SolvingFlowsheet
  } // end of method APServerClass::get_SolvingFlowsheet

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_EOUnits() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::get_EOUnits
  } // end of method APServerClass::get_EOUnits

  .method public hidebysig newslot specialname virtual 
          instance void  set_EOUnits(object  marshal( struct) A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::set_EOUnits
  } // end of method APServerClass::set_EOUnits

  .method public hidebysig newslot virtual 
          instance void  GetService([in] string  marshal( bstr) bService,
                                    [out] object&  marshal( iunknown ) ppUnk) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::GetService
  } // end of method APServerClass::GetService

  .method public hidebysig newslot virtual 
          instance void  SimExecuteScript([in] string  marshal( bstr) commandString,
                                          [in] object  marshal( struct) vtVal) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::SimExecuteScript
  } // end of method APServerClass::SimExecuteScript

  .method public hidebysig newslot virtual 
          instance void  ToggleEOSimEvents(int32 iMask,
                                           bool bEnable) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::ToggleEOSimEvents
  } // end of method APServerClass::ToggleEOSimEvents

  .method public hidebysig newslot virtual 
          instance void  AddCapeOpenBlk([in] string  marshal( bstr) bsDisplayName,
                                        [in] string  marshal( bstr) capeId,
                                        [in] valuetype AspenTech.AspenPlus.APServer.eAPCapeOpenIdOption eIdType,
                                        [out] object&  marshal( iunknown ) ppUnk) runtime managed preservesig internalcall
  {
    .param [3]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 41 50 43 61 70 65 4F 70 65 6E 49 64 4F 70 74   // eAPCapeOpenIdOpt
                                                                                                            69 6F 6E 00 00 )                                  // ion..
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::AddCapeOpenBlk
  } // end of method APServerClass::AddCapeOpenBlk

  .method public hidebysig newslot virtual 
          instance void  GetCapeBlockService([in] object  marshal( iunknown ) pBlkIUnk,
                                             [in] string  marshal( bstr) bsServiceId,
                                             [out] object&  marshal( iunknown ) ppUnk) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::GetCapeBlockService
  } // end of method APServerClass::GetCapeBlockService

  .method public hidebysig newslot virtual 
          instance void  SaveCOBlkToStg([in] object  marshal( struct) bsCapefullId,
                                        [in] object  marshal( iunknown ) pUnk) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::SaveCOBlkToStg
  } // end of method APServerClass::SaveCOBlkToStg

  .method public hidebysig newslot virtual 
          instance void  LoadCOBlkToStg([in] object  marshal( struct) bsCapefullId,
                                        [in] object  marshal( iunknown ) pUnk) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::LoadCOBlkToStg
  } // end of method APServerClass::LoadCOBlkToStg

  .method public hidebysig newslot virtual 
          instance void  StreamSummary([in] object  marshal( struct) vtXMLTFF,
                                       [in] object  marshal( struct) vtScope,
                                       [in] object  marshal( struct) vtScopeType,
                                       [out] object&  marshal( struct) vtXMLResult) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::StreamSummary
  } // end of method APServerClass::StreamSummary

  .method public hidebysig newslot virtual 
          instance void  GetValidAPStreams([in] object  marshal( struct) vtScope,
                                           [out] object&  marshal( struct) vtXMLStreams) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::GetValidAPStreams
  } // end of method APServerClass::GetValidAPStreams

  .method public hidebysig newslot virtual 
          instance void  GetLicenseInfo([out] string&  marshal( bstr) bstrLicInfo) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::GetLicenseInfo
  } // end of method APServerClass::GetLicenseInfo

  .method public hidebysig newslot virtual 
          instance void  CheckFeatureLicense([in] object  marshal( struct) vtFeature,
                                             [out] object&  marshal( struct) vtCookie) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::CheckFeatureLicense
  } // end of method APServerClass::CheckFeatureLicense

  .method public hidebysig newslot virtual 
          instance void  GetSpDistilAnalysis([out] object&  marshal( iunknown ) ppUnk) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::GetSpDistilAnalysis
  } // end of method APServerClass::GetSpDistilAnalysis

  .method public hidebysig newslot virtual 
          instance void  GetASCDDistil([out] object&  marshal( iunknown ) ppUnk) runtime managed preservesig internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPServerDispatch::GetASCDDistil
  } // end of method APServerClass::GetASCDDistil

  .event AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler OnEvent
  {
    .addon instance void AspenTech.AspenPlus.APServer.APServerClass::add_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler)
    .removeon instance void AspenTech.AspenPlus.APServer.APServerClass::remove_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler)
  } // end of event APServerClass::OnEvent
  .property callconv(8) object EOSimulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::get_EOSimulation()
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::set_EOSimulation(object)
  } // end of property APServerClass::EOSimulation
  .property callconv(8) object IAPServerRte_EOSimulation()
  {
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::IAPServerRte_set_EOSimulation(object)
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServerRte_get_EOSimulation()
  } // end of property APServerClass::IAPServerRte_EOSimulation
  .property callconv(8) class AspenTech.AspenPlus.APServer.APServerBlockCollection
          Blocks()
  {
    .get instance class AspenTech.AspenPlus.APServer.APServerBlockCollection AspenTech.AspenPlus.APServer.APServerClass::get_Blocks()
  } // end of property APServerClass::Blocks
  .property callconv(8) class AspenTech.AspenPlus.APServer.IStream
          FileStream(string,
                     int32,
                     int32,
                     int32)
  {
    .get instance class AspenTech.AspenPlus.APServer.IStream AspenTech.AspenPlus.APServer.APServerClass::get_FileStream(string,
                                                                                                                        int32,
                                                                                                                        int32,
                                                                                                                        int32)
  } // end of property APServerClass::FileStream
  .property callconv(8) object DefaultProperties(string)
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::get_DefaultProperties(string)
  } // end of property APServerClass::DefaultProperties
  .property callconv(8) object DupDefaultProperties(string)
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::get_DupDefaultProperties(string)
  } // end of property APServerClass::DupDefaultProperties
  .property callconv(8) object CatalogXMLMgr()
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::get_CatalogXMLMgr()
  } // end of property APServerClass::CatalogXMLMgr
  .property callconv(8) class AspenTech.AspenPlus.APServer.APACMExpCollection
          ACMExpModels()
  {
    .get instance class AspenTech.AspenPlus.APServer.APACMExpCollection AspenTech.AspenPlus.APServer.APServerClass::get_ACMExpModels()
  } // end of property APServerClass::ACMExpModels
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus
          BlockStatus(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus AspenTech.AspenPlus.APServer.APServerClass::get_BlockStatus(string)
  } // end of property APServerClass::BlockStatus
  .property callconv(8) int32 NumberIter()
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::get_NumberIter()
  } // end of property APServerClass::NumberIter
  .property callconv(8) int32 Converged(string&)
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::get_Converged(string&)
  } // end of property APServerClass::Converged
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType
          ParamType(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType AspenTech.AspenPlus.APServer.APServerClass::get_ParamType(string)
  } // end of property APServerClass::ParamType
  .property callconv(8) string ParamStringValue(string)
  {
    .get instance string AspenTech.AspenPlus.APServer.APServerClass::get_ParamStringValue(string)
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::set_ParamStringValue(string,
                                                                                        string)
  } // end of property APServerClass::ParamStringValue
  .property callconv(8) int32 ParamIntValue(string)
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::get_ParamIntValue(string)
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::set_ParamIntValue(string,
                                                                                     int32)
  } // end of property APServerClass::ParamIntValue
  .property callconv(8) float64 Rmiss()
  {
    .get instance float64 AspenTech.AspenPlus.APServer.APServerClass::get_Rmiss()
  } // end of property APServerClass::Rmiss
  .property callconv(8) object IAPServerScripting_EOSimulation()
  {
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_set_EOSimulation(object)
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_EOSimulation()
  } // end of property APServerClass::IAPServerScripting_EOSimulation
  .property callconv(8) class AspenTech.AspenPlus.APServer.APServerBlockCollection
          IAPServerScripting_Blocks()
  {
    .get instance class AspenTech.AspenPlus.APServer.APServerBlockCollection AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_Blocks()
  } // end of property APServerClass::IAPServerScripting_Blocks
  .property callconv(8) class AspenTech.AspenPlus.APServer.IStream
          IAPServerScripting_FileStream(string,
                                        int32,
                                        int32,
                                        int32)
  {
    .get instance class AspenTech.AspenPlus.APServer.IStream AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_FileStream(string,
                                                                                                                                           int32,
                                                                                                                                           int32,
                                                                                                                                           int32)
  } // end of property APServerClass::IAPServerScripting_FileStream
  .property callconv(8) object IAPServerScripting_DefaultProperties(string)
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_DefaultProperties(string)
  } // end of property APServerClass::IAPServerScripting_DefaultProperties
  .property callconv(8) object IAPServerScripting_DupDefaultProperties(string)
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_DupDefaultProperties(string)
  } // end of property APServerClass::IAPServerScripting_DupDefaultProperties
  .property callconv(8) object IAPServerScripting_CatalogXMLMgr()
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_CatalogXMLMgr()
  } // end of property APServerClass::IAPServerScripting_CatalogXMLMgr
  .property callconv(8) class AspenTech.AspenPlus.APServer.APACMExpCollection
          IAPServerScripting_ACMExpModels()
  {
    .get instance class AspenTech.AspenPlus.APServer.APACMExpCollection AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_ACMExpModels()
  } // end of property APServerClass::IAPServerScripting_ACMExpModels
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus
          IAPServerScripting_BlockStatus(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_BlockStatus(string)
  } // end of property APServerClass::IAPServerScripting_BlockStatus
  .property callconv(8) int32 IAPServerScripting_NumberIter()
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_NumberIter()
  } // end of property APServerClass::IAPServerScripting_NumberIter
  .property callconv(8) int32 IAPServerScripting_Converged(string&)
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_Converged(string&)
  } // end of property APServerClass::IAPServerScripting_Converged
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType
          IAPServerScripting_ParamType(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_ParamType(string)
  } // end of property APServerClass::IAPServerScripting_ParamType
  .property callconv(8) string IAPServerScripting_ParamStringValue(string)
  {
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_set_ParamStringValue(string,
                                                                                                           string)
    .get instance string AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_ParamStringValue(string)
  } // end of property APServerClass::IAPServerScripting_ParamStringValue
  .property callconv(8) int32 IAPServerScripting_ParamIntValue(string)
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_ParamIntValue(string)
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_set_ParamIntValue(string,
                                                                                                        int32)
  } // end of property APServerClass::IAPServerScripting_ParamIntValue
  .property callconv(8) float64 IAPServerScripting_Rmiss()
  {
    .get instance float64 AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting_get_Rmiss()
  } // end of property APServerClass::IAPServerScripting_Rmiss
  .property callconv(8) object IAPServerScripting2_EOSimulation()
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_EOSimulation()
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_set_EOSimulation(object)
  } // end of property APServerClass::IAPServerScripting2_EOSimulation
  .property callconv(8) class AspenTech.AspenPlus.APServer.APServerBlockCollection
          IAPServerScripting2_Blocks()
  {
    .get instance class AspenTech.AspenPlus.APServer.APServerBlockCollection AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_Blocks()
  } // end of property APServerClass::IAPServerScripting2_Blocks
  .property callconv(8) class AspenTech.AspenPlus.APServer.IStream
          IAPServerScripting2_FileStream(string,
                                         int32,
                                         int32,
                                         int32)
  {
    .get instance class AspenTech.AspenPlus.APServer.IStream AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_FileStream(string,
                                                                                                                                            int32,
                                                                                                                                            int32,
                                                                                                                                            int32)
  } // end of property APServerClass::IAPServerScripting2_FileStream
  .property callconv(8) object IAPServerScripting2_DefaultProperties(string)
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_DefaultProperties(string)
  } // end of property APServerClass::IAPServerScripting2_DefaultProperties
  .property callconv(8) object IAPServerScripting2_DupDefaultProperties(string)
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_DupDefaultProperties(string)
  } // end of property APServerClass::IAPServerScripting2_DupDefaultProperties
  .property callconv(8) object IAPServerScripting2_CatalogXMLMgr()
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_CatalogXMLMgr()
  } // end of property APServerClass::IAPServerScripting2_CatalogXMLMgr
  .property callconv(8) class AspenTech.AspenPlus.APServer.APACMExpCollection
          IAPServerScripting2_ACMExpModels()
  {
    .get instance class AspenTech.AspenPlus.APServer.APACMExpCollection AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_ACMExpModels()
  } // end of property APServerClass::IAPServerScripting2_ACMExpModels
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus
          IAPServerScripting2_BlockStatus(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_BlockStatus(string)
  } // end of property APServerClass::IAPServerScripting2_BlockStatus
  .property callconv(8) int32 IAPServerScripting2_NumberIter()
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_NumberIter()
  } // end of property APServerClass::IAPServerScripting2_NumberIter
  .property callconv(8) int32 IAPServerScripting2_Converged(string&)
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_Converged(string&)
  } // end of property APServerClass::IAPServerScripting2_Converged
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType
          IAPServerScripting2_ParamType(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_ParamType(string)
  } // end of property APServerClass::IAPServerScripting2_ParamType
  .property callconv(8) string IAPServerScripting2_ParamStringValue(string)
  {
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_set_ParamStringValue(string,
                                                                                                            string)
    .get instance string AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_ParamStringValue(string)
  } // end of property APServerClass::IAPServerScripting2_ParamStringValue
  .property callconv(8) int32 IAPServerScripting2_ParamIntValue(string)
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_ParamIntValue(string)
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_set_ParamIntValue(string,
                                                                                                         int32)
  } // end of property APServerClass::IAPServerScripting2_ParamIntValue
  .property callconv(8) float64 IAPServerScripting2_Rmiss()
  {
    .get instance float64 AspenTech.AspenPlus.APServer.APServerClass::IAPServerScripting2_get_Rmiss()
  } // end of property APServerClass::IAPServerScripting2_Rmiss
  .property callconv(8) string ConvergenceFailureText()
  {
    .get instance string AspenTech.AspenPlus.APServer.APServerClass::get_ConvergenceFailureText()
  } // end of property APServerClass::ConvergenceFailureText
  .property callconv(8) object IAPServer4_EOSimulation()
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_EOSimulation()
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_set_EOSimulation(object)
  } // end of property APServerClass::IAPServer4_EOSimulation
  .property callconv(8) class AspenTech.AspenPlus.APServer.APServerBlockCollection
          IAPServer4_Blocks()
  {
    .get instance class AspenTech.AspenPlus.APServer.APServerBlockCollection AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_Blocks()
  } // end of property APServerClass::IAPServer4_Blocks
  .property callconv(8) class AspenTech.AspenPlus.APServer.IStream
          IAPServer4_FileStream(string,
                                int32,
                                int32,
                                int32)
  {
    .get instance class AspenTech.AspenPlus.APServer.IStream AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_FileStream(string,
                                                                                                                                   int32,
                                                                                                                                   int32,
                                                                                                                                   int32)
  } // end of property APServerClass::IAPServer4_FileStream
  .property callconv(8) object IAPServer4_DefaultProperties(string)
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_DefaultProperties(string)
  } // end of property APServerClass::IAPServer4_DefaultProperties
  .property callconv(8) object IAPServer4_DupDefaultProperties(string)
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_DupDefaultProperties(string)
  } // end of property APServerClass::IAPServer4_DupDefaultProperties
  .property callconv(8) object IAPServer4_CatalogXMLMgr()
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_CatalogXMLMgr()
  } // end of property APServerClass::IAPServer4_CatalogXMLMgr
  .property callconv(8) class AspenTech.AspenPlus.APServer.APACMExpCollection
          IAPServer4_ACMExpModels()
  {
    .get instance class AspenTech.AspenPlus.APServer.APACMExpCollection AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_ACMExpModels()
  } // end of property APServerClass::IAPServer4_ACMExpModels
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus
          IAPServer4_BlockStatus(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 42 6C 6F 63 6B   // ApServerRteBlock
                                                                                                            53 74 61 74 75 73 00 00 )                         // Status..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_BlockStatus(string)
  } // end of property APServerClass::IAPServer4_BlockStatus
  .property callconv(8) int32 IAPServer4_NumberIter()
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_NumberIter()
  } // end of property APServerClass::IAPServer4_NumberIter
  .property callconv(8) int32 IAPServer4_Converged(string&)
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_Converged(string&)
  } // end of property APServerClass::IAPServer4_Converged
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType
          IAPServer4_ParamType(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 70 53 65 72 76 65 72 52 74 65 50 61 72 61 6D   // ApServerRteParam
                                                                                                            54 79 70 65 00 00 )                               // Type..
    .get instance valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_ParamType(string)
  } // end of property APServerClass::IAPServer4_ParamType
  .property callconv(8) string IAPServer4_ParamStringValue(string)
  {
    .get instance string AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_ParamStringValue(string)
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_set_ParamStringValue(string,
                                                                                                   string)
  } // end of property APServerClass::IAPServer4_ParamStringValue
  .property callconv(8) int32 IAPServer4_ParamIntValue(string)
  {
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_set_ParamIntValue(string,
                                                                                                int32)
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_ParamIntValue(string)
  } // end of property APServerClass::IAPServer4_ParamIntValue
  .property callconv(8) float64 IAPServer4_Rmiss()
  {
    .get instance float64 AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_Rmiss()
  } // end of property APServerClass::IAPServer4_Rmiss
  .property callconv(8) string IAPServer4_ConvergenceFailureText()
  {
    .get instance string AspenTech.AspenPlus.APServer.APServerClass::IAPServer4_get_ConvergenceFailureText()
  } // end of property APServerClass::IAPServer4_ConvergenceFailureText
  .property callconv(8) int32 SolvingFlowsheet()
  {
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::set_SolvingFlowsheet(int32)
    .get instance int32 AspenTech.AspenPlus.APServer.APServerClass::get_SolvingFlowsheet()
  } // end of property APServerClass::SolvingFlowsheet
  .property callconv(8) object EOUnits()
  {
    .get instance object AspenTech.AspenPlus.APServer.APServerClass::get_EOUnits()
    .set instance void AspenTech.AspenPlus.APServer.APServerClass::set_EOUnits(object)
  } // end of property APServerClass::EOUnits
} // end of class AspenTech.AspenPlus.APServer.APServerClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPBlockCollection
       implements [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 33 2D 45 31 31 31   // ..$6CCB1443-E111
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IAPBlock 
          marshal( interface ) 
          Add([in] string  marshal( bstr) Name,
              [in] object  marshal( struct) 'type') runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlockCollection::Add

  .method public hidebysig newslot abstract virtual 
          instance void  Remove([in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlockCollection::Remove

  .method public hidebysig newslot abstract virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlockCollection::Rename

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlockCollection::get_Count

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IAPBlock 
          marshal( interface ) 
          get_Item([in] object  marshal( struct) index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IAPBlockCollection::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IAPBlockCollection::GetEnumerator

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPBlockCollection::get_Count()
  } // end of property IAPBlockCollection::Count
  .property callconv(8) class AspenTech.AspenPlus.APServer.IAPBlock
          Item(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.APServer.IAPBlock AspenTech.AspenPlus.APServer.IAPBlockCollection::get_Item(object)
  } // end of property IAPBlockCollection::Item
} // end of class AspenTech.AspenPlus.APServer.IAPBlockCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.APServerBlockCollection
       implements AspenTech.AspenPlus.APServer.IAPBlockCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 39 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..9AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          41 50 53 65 72 76 65 72 42 6C 6F 63 6B 43 6F 6C   // APServerBlockCol
                                                                                                                          6C 65 63 74 69 6F 6E 43 6C 61 73 73 00 00 )       // lectionClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 33 2D 45 31 31 31   // ..$6CCB1443-E111
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
} // end of class AspenTech.AspenPlus.APServer.APServerBlockCollection

.class public auto ansi import AspenTech.AspenPlus.APServer.APServerBlockCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.IAPBlockCollection,
                  AspenTech.AspenPlus.APServer.APServerBlockCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 36 2D 45 31 31 31   // ..$6CCB1446-E111
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method APServerBlockCollectionClass::.ctor

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.APServer.IAPBlock 
          marshal( interface ) 
          Add([in] string  marshal( bstr) Name,
              [in] object  marshal( struct) 'type') runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPBlockCollection::Add
  } // end of method APServerBlockCollectionClass::Add

  .method public hidebysig newslot virtual 
          instance void  Remove([in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPBlockCollection::Remove
  } // end of method APServerBlockCollectionClass::Remove

  .method public hidebysig newslot virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPBlockCollection::Rename
  } // end of method APServerBlockCollectionClass::Rename

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPBlockCollection::get_Count
  } // end of method APServerBlockCollectionClass::get_Count

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.IAPBlock 
          marshal( interface ) 
          get_Item([in] object  marshal( struct) index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.IAPBlockCollection::get_Item
  } // end of method APServerBlockCollectionClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.APServer.IAPBlockCollection::GetEnumerator
  } // end of method APServerBlockCollectionClass::GetEnumerator

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.APServerBlockCollectionClass::get_Count()
  } // end of property APServerBlockCollectionClass::Count
  .property callconv(8) class AspenTech.AspenPlus.APServer.IAPBlock
          Item(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.APServer.IAPBlock AspenTech.AspenPlus.APServer.APServerBlockCollectionClass::get_Item(object)
  } // end of property APServerBlockCollectionClass::Item
} // end of class AspenTech.AspenPlus.APServer.APServerBlockCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPACMExpCollection
       implements [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 34 36 39 33 41 37 38 2D 30 39 42 42   // ..$14693A78-09BB
                                                                                                  2D 34 33 45 39 2D 42 46 34 34 2D 41 33 35 32 33   // -43E9-BF44-A3523
                                                                                                  35 43 44 30 42 33 43 00 00 )                      // 5CD0B3C..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IAPBlock 
          marshal( interface ) 
          Add([in] valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
              [in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
  } // end of method IAPACMExpCollection::Add

  .method public hidebysig newslot abstract virtual 
          instance void  Remove([in] valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                                [in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
  } // end of method IAPACMExpCollection::Remove

  .method public hidebysig newslot abstract virtual 
          instance void  Rename([in] valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                                [in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
  } // end of method IAPACMExpCollection::Rename

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMExpCollection::get_Count

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IAPBlock 
          marshal( interface ) 
          get_Item([in] valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                   [in] object  marshal( struct) index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
  } // end of method IAPACMExpCollection::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IAPACMExpCollection::GetEnumerator

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPACMExpCollection::get_Count()
  } // end of property IAPACMExpCollection::Count
  .property callconv(8) class AspenTech.AspenPlus.APServer.IAPBlock
          Item(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType,
               object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.APServer.IAPBlock AspenTech.AspenPlus.APServer.IAPACMExpCollection::get_Item(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType,
                                                                                                                         object)
  } // end of property IAPACMExpCollection::Item
} // end of class AspenTech.AspenPlus.APServer.IAPACMExpCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.APACMExpCollection
       implements AspenTech.AspenPlus.APServer.IAPACMExpCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 34 36 39 33 41 37 38 2D 30 39 42 42   // ..$14693A78-09BB
                                                                                                  2D 34 33 45 39 2D 42 46 34 34 2D 41 33 35 32 33   // -43E9-BF44-A3523
                                                                                                  35 43 44 30 42 33 43 00 00 )                      // 5CD0B3C..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          41 50 41 43 4D 45 78 70 43 6F 6C 6C 65 63 74 69   // APACMExpCollecti
                                                                                                                          6F 6E 43 6C 61 73 73 00 00 )                      // onClass..
} // end of class AspenTech.AspenPlus.APServer.APACMExpCollection

.class public auto ansi import AspenTech.AspenPlus.APServer.APACMExpCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.IAPACMExpCollection,
                  AspenTech.AspenPlus.APServer.APACMExpCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 45 43 46 35 38 32 37 41 2D 43 41 43 42   // ..$ECF5827A-CACB
                                                                                                  2D 34 36 38 38 2D 39 42 37 32 2D 31 42 43 44 32   // -4688-9B72-1BCD2
                                                                                                  32 44 45 44 32 42 30 00 00 )                      // 2DED2B0..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method APACMExpCollectionClass::.ctor

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.APServer.IAPBlock 
          marshal( interface ) 
          Add([in] valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
              [in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .override AspenTech.AspenPlus.APServer.IAPACMExpCollection::Add
  } // end of method APACMExpCollectionClass::Add

  .method public hidebysig newslot virtual 
          instance void  Remove([in] valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                                [in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .override AspenTech.AspenPlus.APServer.IAPACMExpCollection::Remove
  } // end of method APACMExpCollectionClass::Remove

  .method public hidebysig newslot virtual 
          instance void  Rename([in] valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                                [in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .override AspenTech.AspenPlus.APServer.IAPACMExpCollection::Rename
  } // end of method APACMExpCollectionClass::Rename

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMExpCollection::get_Count
  } // end of method APACMExpCollectionClass::get_Count

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.IAPBlock 
          marshal( interface ) 
          get_Item([in] valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                   [in] object  marshal( struct) index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .override AspenTech.AspenPlus.APServer.IAPACMExpCollection::get_Item
  } // end of method APACMExpCollectionClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.APServer.IAPACMExpCollection::GetEnumerator
  } // end of method APACMExpCollectionClass::GetEnumerator

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.APACMExpCollectionClass::get_Count()
  } // end of property APACMExpCollectionClass::Count
  .property callconv(8) class AspenTech.AspenPlus.APServer.IAPBlock
          Item(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType,
               object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.APServer.IAPBlock AspenTech.AspenPlus.APServer.APACMExpCollectionClass::get_Item(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType,
                                                                                                                             object)
  } // end of property APACMExpCollectionClass::Item
} // end of class AspenTech.AspenPlus.APServer.APACMExpCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 31 2D 35 43 32 36   // ..$6CCB1441-5C26
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPCapeUnitAdapter::Rename

  .method public hidebysig newslot abstract virtual 
          instance void  Destroy([in] string  marshal( bstr) fqBlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPCapeUnitAdapter::Destroy

  .method public hidebysig newslot abstract virtual 
          instance void  Connect([in] string  marshal( bstr) portname,
                                 [in] string  marshal( bstr) streamname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPCapeUnitAdapter::Connect

  .method public hidebysig newslot abstract virtual 
          instance void  LaunchGUI() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPCapeUnitAdapter::LaunchGUI

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IAPCapeUnitAdapter::get_Ports

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IAPCapeUnitAdapter::get_Parameters

  .method public hidebysig newslot specialname abstract virtual 
          instance int32 
          marshal( error) 
          get_StatusCode() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
  } // end of method IAPCapeUnitAdapter::get_StatusCode

  .property callconv(8) object Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter::get_Ports()
  } // end of property IAPCapeUnitAdapter::Ports
  .property callconv(8) object Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter::get_Parameters()
  } // end of property IAPCapeUnitAdapter::Parameters
  .property callconv(8) int32 StatusCode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter::get_StatusCode()
  } // end of property IAPCapeUnitAdapter::StatusCode
} // end of class AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.APCapeUnitAdapter
       implements AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 31 2D 35 43 32 36   // ..$6CCB1441-5C26
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          41 50 43 61 70 65 55 6E 69 74 41 64 61 70 74 65   // APCapeUnitAdapte
                                                                                                                          72 43 6C 61 73 73 00 00 )                         // rClass..
} // end of class AspenTech.AspenPlus.APServer.APCapeUnitAdapter

.class public auto ansi import AspenTech.AspenPlus.APServer.APCapeUnitAdapterClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter,
                  AspenTech.AspenPlus.APServer.APCapeUnitAdapter
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 32 2D 45 31 31 31   // ..$6CCB1442-E111
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method APCapeUnitAdapterClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter::Rename
  } // end of method APCapeUnitAdapterClass::Rename

  .method public hidebysig newslot virtual 
          instance void  Destroy([in] string  marshal( bstr) fqBlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter::Destroy
  } // end of method APCapeUnitAdapterClass::Destroy

  .method public hidebysig newslot virtual 
          instance void  Connect([in] string  marshal( bstr) portname,
                                 [in] string  marshal( bstr) streamname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter::Connect
  } // end of method APCapeUnitAdapterClass::Connect

  .method public hidebysig newslot virtual 
          instance void  LaunchGUI() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter::LaunchGUI
  } // end of method APCapeUnitAdapterClass::LaunchGUI

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter::get_Ports
  } // end of method APCapeUnitAdapterClass::get_Ports

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter::get_Parameters
  } // end of method APCapeUnitAdapterClass::get_Parameters

  .method public hidebysig newslot specialname virtual 
          instance int32 
          marshal( error) 
          get_StatusCode() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPCapeUnitAdapter::get_StatusCode
  } // end of method APCapeUnitAdapterClass::get_StatusCode

  .property callconv(8) object Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.APCapeUnitAdapterClass::get_Ports()
  } // end of property APCapeUnitAdapterClass::Ports
  .property callconv(8) object Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.APCapeUnitAdapterClass::get_Parameters()
  } // end of property APCapeUnitAdapterClass::Parameters
  .property callconv(8) int32 StatusCode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.APCapeUnitAdapterClass::get_StatusCode()
  } // end of property APCapeUnitAdapterClass::StatusCode
} // end of class AspenTech.AspenPlus.APServer.APCapeUnitAdapterClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPBlock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 37 2D 45 31 31 31   // ..$6CCB1447-E111
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::Rename

  .method public hidebysig newslot abstract virtual 
          instance void  Destroy([in] string  marshal( bstr) fqBlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::Destroy

  .method public hidebysig newslot abstract virtual 
          instance void  Connect([in] string  marshal( bstr) portname,
                                 [in] string  marshal( bstr) streamname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::Connect

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::get_Ports

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::get_Parameters

  .method public hidebysig newslot specialname abstract virtual 
          instance int32 
          marshal( error) 
          get_StatusCode() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::get_StatusCode

  .method public hidebysig newslot abstract virtual 
          instance void  Validate() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::Validate

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) Service) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Param([in] string  marshal( bstr) parameterName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::get_Param

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Param([in] string  marshal( bstr) parameterName,
                                   [in] object  marshal( struct) parameterValue) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock::set_Param

  .property callconv(8) object Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPBlock::get_Ports()
  } // end of property IAPBlock::Ports
  .property callconv(8) object Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPBlock::get_Parameters()
  } // end of property IAPBlock::Parameters
  .property callconv(8) int32 StatusCode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPBlock::get_StatusCode()
  } // end of property IAPBlock::StatusCode
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.IAPBlock::get_Name()
  } // end of property IAPBlock::Name
  .property callconv(8) object Param(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.APServer.IAPBlock::set_Param(string,
                                                                        object)
    .get instance object AspenTech.AspenPlus.APServer.IAPBlock::get_Param(string)
  } // end of property IAPBlock::Param
} // end of class AspenTech.AspenPlus.APServer.IAPBlock

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPBlock2
       implements AspenTech.AspenPlus.APServer.IAPBlock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 42 34 36 37 42 35 42 44 2D 32 34 32 36   // ..$B467B5BD-2426
                                                                                                  2D 34 32 43 36 2D 39 34 46 33 2D 41 30 33 41 41   // -42C6-94F3-A03AA
                                                                                                  45 35 43 30 44 35 45 00 00 )                      // E5C0D5E..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::Rename

  .method public hidebysig newslot abstract virtual 
          instance void  Destroy([in] string  marshal( bstr) fqBlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::Destroy

  .method public hidebysig newslot abstract virtual 
          instance void  Connect([in] string  marshal( bstr) portname,
                                 [in] string  marshal( bstr) streamname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::Connect

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::get_Ports

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::get_Parameters

  .method public hidebysig newslot specialname abstract virtual 
          instance int32 
          marshal( error) 
          get_StatusCode() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::get_StatusCode

  .method public hidebysig newslot abstract virtual 
          instance void  Validate() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::Validate

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) Service) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Param([in] string  marshal( bstr) parameterName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::get_Param

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Param([in] string  marshal( bstr) parameterName,
                                   [in] object  marshal( struct) parameterValue) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::set_Param

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::get_type

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_type([in] object  marshal( struct) pVar) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
  } // end of method IAPBlock2::set_type

  .property callconv(8) object Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPBlock2::get_Ports()
  } // end of property IAPBlock2::Ports
  .property callconv(8) object Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPBlock2::get_Parameters()
  } // end of property IAPBlock2::Parameters
  .property callconv(8) int32 StatusCode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPBlock2::get_StatusCode()
  } // end of property IAPBlock2::StatusCode
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.IAPBlock2::get_Name()
  } // end of property IAPBlock2::Name
  .property callconv(8) object Param(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.APServer.IAPBlock2::set_Param(string,
                                                                         object)
    .get instance object AspenTech.AspenPlus.APServer.IAPBlock2::get_Param(string)
  } // end of property IAPBlock2::Param
  .property callconv(8) object 'type'()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPBlock2::get_type()
    .set instance void AspenTech.AspenPlus.APServer.IAPBlock2::set_type(object)
  } // end of property IAPBlock2::'type'
} // end of class AspenTech.AspenPlus.APServer.IAPBlock2

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPACMModelAdapter
       implements AspenTech.AspenPlus.APServer.IAPBlock2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 34 41 36 39 32 31 42 2D 32 46 32 35   // ..$04A6921B-2F25
                                                                                                  2D 34 42 38 43 2D 39 36 37 32 2D 32 31 33 31 38   // -4B8C-9672-21318
                                                                                                  34 42 35 38 30 41 35 00 00 )                      // 4B580A5..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::Rename

  .method public hidebysig newslot abstract virtual 
          instance void  Destroy([in] string  marshal( bstr) fqBlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::Destroy

  .method public hidebysig newslot abstract virtual 
          instance void  Connect([in] string  marshal( bstr) portname,
                                 [in] string  marshal( bstr) streamname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::Connect

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::get_Ports

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::get_Parameters

  .method public hidebysig newslot specialname abstract virtual 
          instance int32 
          marshal( error) 
          get_StatusCode() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::get_StatusCode

  .method public hidebysig newslot abstract virtual 
          instance void  Validate() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::Validate

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) Service) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Param([in] string  marshal( bstr) parameterName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::get_Param

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Param([in] string  marshal( bstr) parameterName,
                                   [in] object  marshal( struct) parameterValue) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::set_Param

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::get_type

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_type([in] object  marshal( struct) pVar) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::set_type

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Queries() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::get_Queries

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_VBScripts() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::get_VBScripts

  .method public hidebysig newslot abstract virtual 
          instance void  Initialize(string  marshal( bstr) Path,
                                    string  marshal( bstr) Library) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::Initialize

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr 
          marshal( interface ) 
          get_Properties() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::get_Properties

  .method public hidebysig newslot abstract virtual 
          instance void  OnComponentManagerEvent(valuetype AspenTech.AspenPlus.APServer.eACMComponentManagerEventType event,
                                                 string  marshal( bstr) NewName,
                                                 string  marshal( bstr) OldName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 04 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 3A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..:AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 41 43 4D 43 6F 6D 70 6F 6E 65 6E 74 4D 61 6E   // eACMComponentMan
                                                                                                            61 67 65 72 45 76 65 6E 74 54 79 70 65 00 00 )    // agerEventType..
  } // end of method IAPACMModelAdapter::OnComponentManagerEvent

  .method public hidebysig newslot specialname abstract virtual 
          instance int64  get_Blkptr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter::get_Blkptr

  .property callconv(8) object Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Ports()
  } // end of property IAPACMModelAdapter::Ports
  .property callconv(8) object Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Parameters()
  } // end of property IAPACMModelAdapter::Parameters
  .property callconv(8) int32 StatusCode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_StatusCode()
  } // end of property IAPACMModelAdapter::StatusCode
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Name()
  } // end of property IAPACMModelAdapter::Name
  .property callconv(8) object Param(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.APServer.IAPACMModelAdapter::set_Param(string,
                                                                                  object)
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Param(string)
  } // end of property IAPACMModelAdapter::Param
  .property callconv(8) object 'type'()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_type()
    .set instance void AspenTech.AspenPlus.APServer.IAPACMModelAdapter::set_type(object)
  } // end of property IAPACMModelAdapter::'type'
  .property callconv(8) object Queries()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 04 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Queries()
  } // end of property IAPACMModelAdapter::Queries
  .property callconv(8) object VBScripts()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_VBScripts()
  } // end of property IAPACMModelAdapter::VBScripts
  .property callconv(8) class AspenTech.AspenPlus.APServer.APSHostCompListMgr
          Properties()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 04 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Properties()
  } // end of property IAPACMModelAdapter::Properties
  .property callconv(8) int64 Blkptr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
    .get instance int64 AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Blkptr()
  } // end of property IAPACMModelAdapter::Blkptr
} // end of class AspenTech.AspenPlus.APServer.IAPACMModelAdapter

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.APACMModelAdapter
       implements AspenTech.AspenPlus.APServer.IAPACMModelAdapter
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          41 50 41 43 4D 4D 6F 64 65 6C 41 64 61 70 74 65   // APACMModelAdapte
                                                                                                                          72 43 6C 61 73 73 00 00 )                         // rClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 34 41 36 39 32 31 42 2D 32 46 32 35   // ..$04A6921B-2F25
                                                                                                  2D 34 42 38 43 2D 39 36 37 32 2D 32 31 33 31 38   // -4B8C-9672-21318
                                                                                                  34 42 35 38 30 41 35 00 00 )                      // 4B580A5..
} // end of class AspenTech.AspenPlus.APServer.APACMModelAdapter

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPACMModelAdapter2
       implements AspenTech.AspenPlus.APServer.IAPACMModelAdapter
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 32 36 33 32 45 42 39 38 2D 39 45 30 45   // ..$2632EB98-9E0E
                                                                                                  2D 34 36 31 36 2D 38 31 31 44 2D 43 39 41 41 32   // -4616-811D-C9AA2
                                                                                                  30 33 41 33 43 38 38 00 00 )                      // 03A3C88..
  .method public hidebysig newslot abstract virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::Rename

  .method public hidebysig newslot abstract virtual 
          instance void  Destroy([in] string  marshal( bstr) fqBlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::Destroy

  .method public hidebysig newslot abstract virtual 
          instance void  Connect([in] string  marshal( bstr) portname,
                                 [in] string  marshal( bstr) streamname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::Connect

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_Ports

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_Parameters

  .method public hidebysig newslot specialname abstract virtual 
          instance int32 
          marshal( error) 
          get_StatusCode() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_StatusCode

  .method public hidebysig newslot abstract virtual 
          instance void  Validate() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::Validate

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) Service) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Param([in] string  marshal( bstr) parameterName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_Param

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Param([in] string  marshal( bstr) parameterName,
                                   [in] object  marshal( struct) parameterValue) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::set_Param

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_type

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_type([in] object  marshal( struct) pVar) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::set_type

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Queries() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_Queries

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_VBScripts() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_VBScripts

  .method public hidebysig newslot abstract virtual 
          instance void  Initialize(string  marshal( bstr) Path,
                                    string  marshal( bstr) Library) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::Initialize

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr 
          marshal( interface ) 
          get_Properties() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_Properties

  .method public hidebysig newslot abstract virtual 
          instance void  OnComponentManagerEvent(valuetype AspenTech.AspenPlus.APServer.eACMComponentManagerEventType event,
                                                 string  marshal( bstr) NewName,
                                                 string  marshal( bstr) OldName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 04 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 3A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..:AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 41 43 4D 43 6F 6D 70 6F 6E 65 6E 74 4D 61 6E   // eACMComponentMan
                                                                                                            61 67 65 72 45 76 65 6E 74 54 79 70 65 00 00 )    // agerEventType..
  } // end of method IAPACMModelAdapter2::OnComponentManagerEvent

  .method public hidebysig newslot specialname abstract virtual 
          instance int64  get_Blkptr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_Blkptr

  .method public hidebysig newslot abstract virtual 
          instance void  InitializeByModelName(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                                               string  marshal( bstr) bsModelName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 05 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
  } // end of method IAPACMModelAdapter2::InitializeByModelName

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_DegreesOfFreedom() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 05 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::get_DegreesOfFreedom

  .method public hidebysig newslot abstract virtual 
          instance void  ResetSM(string  marshal( bstr) pszProperty,
                                 valuetype AspenTech.AspenPlus.APServer.eResetTypes iResetType,
                                 uint32 iOOMFAttributes,
                                 bool bKeepUserAssigns) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 05 60 00 00 )                         // .....`..
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 28 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..(AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 52 65 73 65 74 54 79 70 65 73 00 00 )          // eResetTypes..
  } // end of method IAPACMModelAdapter2::ResetSM

  .method public hidebysig newslot abstract virtual 
          instance void  ReconcileEOToSM(string  marshal( bstr) pszProperty,
                                         int32 iReconType,
                                         uint32 iOOMFAttributes) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 05 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter2::ReconcileEOToSM

  .property callconv(8) object Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Ports()
  } // end of property IAPACMModelAdapter2::Ports
  .property callconv(8) object Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Parameters()
  } // end of property IAPACMModelAdapter2::Parameters
  .property callconv(8) int32 StatusCode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_StatusCode()
  } // end of property IAPACMModelAdapter2::StatusCode
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Name()
  } // end of property IAPACMModelAdapter2::Name
  .property callconv(8) object Param(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::set_Param(string,
                                                                                   object)
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Param(string)
  } // end of property IAPACMModelAdapter2::Param
  .property callconv(8) object 'type'()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_type()
    .set instance void AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::set_type(object)
  } // end of property IAPACMModelAdapter2::'type'
  .property callconv(8) object Queries()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 04 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Queries()
  } // end of property IAPACMModelAdapter2::Queries
  .property callconv(8) object VBScripts()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_VBScripts()
  } // end of property IAPACMModelAdapter2::VBScripts
  .property callconv(8) class AspenTech.AspenPlus.APServer.APSHostCompListMgr
          Properties()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 04 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Properties()
  } // end of property IAPACMModelAdapter2::Properties
  .property callconv(8) int64 Blkptr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
    .get instance int64 AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Blkptr()
  } // end of property IAPACMModelAdapter2::Blkptr
  .property callconv(8) object DegreesOfFreedom()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 05 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_DegreesOfFreedom()
  } // end of property IAPACMModelAdapter2::DegreesOfFreedom
} // end of class AspenTech.AspenPlus.APServer.IAPACMModelAdapter2

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPACMModelAdapter3
       implements AspenTech.AspenPlus.APServer.IAPACMModelAdapter2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 41 45 31 38 32 46 43 2D 41 31 37 30   // ..$FAE182FC-A170
                                                                                                  2D 34 39 38 35 2D 42 34 31 34 2D 30 32 37 36 36   // -4985-B414-02766
                                                                                                  35 33 38 36 33 35 41 00 00 )                      // 538635A..
  .method public hidebysig newslot abstract virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::Rename

  .method public hidebysig newslot abstract virtual 
          instance void  Destroy([in] string  marshal( bstr) fqBlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::Destroy

  .method public hidebysig newslot abstract virtual 
          instance void  Connect([in] string  marshal( bstr) portname,
                                 [in] string  marshal( bstr) streamname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::Connect

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_Ports

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_Parameters

  .method public hidebysig newslot specialname abstract virtual 
          instance int32 
          marshal( error) 
          get_StatusCode() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_StatusCode

  .method public hidebysig newslot abstract virtual 
          instance void  Validate() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::Validate

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) Service) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Param([in] string  marshal( bstr) parameterName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_Param

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Param([in] string  marshal( bstr) parameterName,
                                   [in] object  marshal( struct) parameterValue) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::set_Param

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_type

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_type([in] object  marshal( struct) pVar) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::set_type

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_Queries() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_Queries

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_VBScripts() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_VBScripts

  .method public hidebysig newslot abstract virtual 
          instance void  Initialize(string  marshal( bstr) Path,
                                    string  marshal( bstr) Library) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::Initialize

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr 
          marshal( interface ) 
          get_Properties() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_Properties

  .method public hidebysig newslot abstract virtual 
          instance void  OnComponentManagerEvent(valuetype AspenTech.AspenPlus.APServer.eACMComponentManagerEventType event,
                                                 string  marshal( bstr) NewName,
                                                 string  marshal( bstr) OldName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 04 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 3A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..:AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 41 43 4D 43 6F 6D 70 6F 6E 65 6E 74 4D 61 6E   // eACMComponentMan
                                                                                                            61 67 65 72 45 76 65 6E 74 54 79 70 65 00 00 )    // agerEventType..
  } // end of method IAPACMModelAdapter3::OnComponentManagerEvent

  .method public hidebysig newslot specialname abstract virtual 
          instance int64  get_Blkptr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_Blkptr

  .method public hidebysig newslot abstract virtual 
          instance void  InitializeByModelName(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                                               string  marshal( bstr) bsModelName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 05 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
  } // end of method IAPACMModelAdapter3::InitializeByModelName

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_DegreesOfFreedom() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 05 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::get_DegreesOfFreedom

  .method public hidebysig newslot abstract virtual 
          instance void  ResetSM(string  marshal( bstr) pszProperty,
                                 valuetype AspenTech.AspenPlus.APServer.eResetTypes iResetType,
                                 uint32 iOOMFAttributes,
                                 bool bKeepUserAssigns) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 05 60 00 00 )                         // .....`..
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 28 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..(AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 52 65 73 65 74 54 79 70 65 73 00 00 )          // eResetTypes..
  } // end of method IAPACMModelAdapter3::ResetSM

  .method public hidebysig newslot abstract virtual 
          instance void  ReconcileEOToSM(string  marshal( bstr) pszProperty,
                                         int32 iReconType,
                                         uint32 iOOMFAttributes) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 05 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::ReconcileEOToSM

  .method public hidebysig newslot abstract virtual 
          instance void  AddReportVar(string  marshal( bstr) varName,
                                      string  marshal( bstr) varGUID) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 06 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::AddReportVar

  .method public hidebysig newslot abstract virtual 
          instance void  AddReportArray(string  marshal( bstr) ID,
                                        string  marshal( bstr) valGuid,
                                        string[]  marshal( safearray bstr) instanceGUIDInfo,
                                        string[]  marshal( safearray bstr) classGUIDInfo,
                                        object[]  marshal( safearray variant) wcReplaceInfo) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 06 60 00 00 )                         // .....`..
  } // end of method IAPACMModelAdapter3::AddReportArray

  .property callconv(8) object Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Ports()
  } // end of property IAPACMModelAdapter3::Ports
  .property callconv(8) object Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Parameters()
  } // end of property IAPACMModelAdapter3::Parameters
  .property callconv(8) int32 StatusCode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_StatusCode()
  } // end of property IAPACMModelAdapter3::StatusCode
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Name()
  } // end of property IAPACMModelAdapter3::Name
  .property callconv(8) object Param(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Param(string)
    .set instance void AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::set_Param(string,
                                                                                   object)
  } // end of property IAPACMModelAdapter3::Param
  .property callconv(8) object 'type'()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_type()
    .set instance void AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::set_type(object)
  } // end of property IAPACMModelAdapter3::'type'
  .property callconv(8) object Queries()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 04 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Queries()
  } // end of property IAPACMModelAdapter3::Queries
  .property callconv(8) object VBScripts()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_VBScripts()
  } // end of property IAPACMModelAdapter3::VBScripts
  .property callconv(8) class AspenTech.AspenPlus.APServer.APSHostCompListMgr
          Properties()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 04 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Properties()
  } // end of property IAPACMModelAdapter3::Properties
  .property callconv(8) int64 Blkptr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
    .get instance int64 AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Blkptr()
  } // end of property IAPACMModelAdapter3::Blkptr
  .property callconv(8) object DegreesOfFreedom()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 05 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_DegreesOfFreedom()
  } // end of property IAPACMModelAdapter3::DegreesOfFreedom
} // end of class AspenTech.AspenPlus.APServer.IAPACMModelAdapter3

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPDynBlock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 35 45 36 45 31 34 30 37 2D 30 43 41 42   // ..$5E6E1407-0CAB
                                                                                                  2D 34 32 44 32 2D 39 46 33 46 2D 36 36 44 38 38   // -42D2-9F3F-66D88
                                                                                                  30 44 44 45 46 46 44 00 00 )                      // 0DDEFFD..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 00 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  UpdateResults() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 01 60 00 00 )                         // .....`..
  } // end of method IAPDynBlock::UpdateResults

} // end of class AspenTech.AspenPlus.APServer.IAPDynBlock

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPDynBlock2
       implements AspenTech.AspenPlus.APServer.IAPDynBlock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 00 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 33 35 45 37 35 32 31 32 2D 32 34 43 34   // ..$35E75212-24C4
                                                                                                  2D 34 35 36 38 2D 38 43 43 38 2D 43 41 44 38 36   // -4568-8CC8-CAD86
                                                                                                  42 30 37 37 37 35 35 00 00 )                      // B077755..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  UpdateResults() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 01 60 00 00 )                         // .....`..
  } // end of method IAPDynBlock2::UpdateResults

  .method public hidebysig newslot abstract virtual 
          instance void  ProfileHandle(native int& hndl) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 02 60 00 00 )                         // .....`..
  } // end of method IAPDynBlock2::ProfileHandle

  .method public hidebysig newslot abstract virtual 
          instance void  IsSolving(int32& bSolving) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPDynBlock2::IsSolving

  .method public hidebysig newslot abstract virtual 
          instance void  CleanUpReportVars() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPDynBlock2::CleanUpReportVars

} // end of class AspenTech.AspenPlus.APServer.IAPDynBlock2

.class public auto ansi import AspenTech.AspenPlus.APServer.APACMModelAdapterClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.IAPACMModelAdapter,
                  AspenTech.AspenPlus.APServer.APACMModelAdapter,
                  AspenTech.AspenPlus.APServer.IAPACMModelAdapter2,
                  AspenTech.AspenPlus.APServer.IAPACMModelAdapter3,
                  AspenTech.AspenPlus.APServer.IAPDynBlock,
                  AspenTech.AspenPlus.APServer.IAPDynBlock2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 43 43 42 31 34 34 38 2D 45 31 31 31   // ..$6CCB1448-E111
                                                                                                  2D 31 31 44 34 2D 38 32 38 39 2D 30 30 43 30 34   // -11D4-8289-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method APACMModelAdapterClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::Rename
  } // end of method APACMModelAdapterClass::Rename

  .method public hidebysig newslot virtual 
          instance void  Destroy([in] string  marshal( bstr) fqBlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::Destroy
  } // end of method APACMModelAdapterClass::Destroy

  .method public hidebysig newslot virtual 
          instance void  Connect([in] string  marshal( bstr) portname,
                                 [in] string  marshal( bstr) streamname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::Connect
  } // end of method APACMModelAdapterClass::Connect

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Ports
  } // end of method APACMModelAdapterClass::get_Ports

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Parameters
  } // end of method APACMModelAdapterClass::get_Parameters

  .method public hidebysig newslot specialname virtual 
          instance int32 
          marshal( error) 
          get_StatusCode() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_StatusCode
  } // end of method APACMModelAdapterClass::get_StatusCode

  .method public hidebysig newslot virtual 
          instance void  Validate() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::Validate
  } // end of method APACMModelAdapterClass::Validate

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) Service) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::GetService
  } // end of method APACMModelAdapterClass::GetService

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Name
  } // end of method APACMModelAdapterClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_Param([in] string  marshal( bstr) parameterName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Param
  } // end of method APACMModelAdapterClass::get_Param

  .method public hidebysig newslot specialname virtual 
          instance void  set_Param([in] string  marshal( bstr) parameterName,
                                   [in] object  marshal( struct) parameterValue) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::set_Param
  } // end of method APACMModelAdapterClass::set_Param

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_type
  } // end of method APACMModelAdapterClass::get_type

  .method public hidebysig newslot specialname virtual 
          instance void  set_type([in] object  marshal( struct) pVar) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::set_type
  } // end of method APACMModelAdapterClass::set_type

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          get_Queries() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 04 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Queries
  } // end of method APACMModelAdapterClass::get_Queries

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          get_VBScripts() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_VBScripts
  } // end of method APACMModelAdapterClass::get_VBScripts

  .method public hidebysig newslot virtual 
          instance void  Initialize(string  marshal( bstr) Path,
                                    string  marshal( bstr) Library) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 04 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::Initialize
  } // end of method APACMModelAdapterClass::Initialize

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr 
          marshal( interface ) 
          get_Properties() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 04 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Properties
  } // end of method APACMModelAdapterClass::get_Properties

  .method public hidebysig newslot virtual 
          instance void  OnComponentManagerEvent(valuetype AspenTech.AspenPlus.APServer.eACMComponentManagerEventType event,
                                                 string  marshal( bstr) NewName,
                                                 string  marshal( bstr) OldName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 04 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 3A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..:AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 41 43 4D 43 6F 6D 70 6F 6E 65 6E 74 4D 61 6E   // eACMComponentMan
                                                                                                            61 67 65 72 45 76 65 6E 74 54 79 70 65 00 00 )    // agerEventType..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::OnComponentManagerEvent
  } // end of method APACMModelAdapterClass::OnComponentManagerEvent

  .method public hidebysig newslot specialname virtual 
          instance int64  get_Blkptr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter::get_Blkptr
  } // end of method APACMModelAdapterClass::get_Blkptr

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter2_Rename([in] string  marshal( bstr) fqOldname,
                                                    [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::Rename
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_Rename

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter2_Destroy([in] string  marshal( bstr) fqBlockName) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::Destroy
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_Destroy

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter2_Connect([in] string  marshal( bstr) portname,
                                                     [in] string  marshal( bstr) streamname) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::Connect
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_Connect

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPACMModelAdapter2_get_Ports() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Ports
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_get_Ports

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPACMModelAdapter2_get_Parameters() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Parameters
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_get_Parameters

  .method public hidebysig newslot specialname virtual 
          instance int32 
          marshal( error) 
          IAPACMModelAdapter2_get_StatusCode() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_StatusCode
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_get_StatusCode

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter2_Validate() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::Validate
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_Validate

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          IAPACMModelAdapter2_GetService([in] string  marshal( bstr) Service) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::GetService
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_GetService

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          IAPACMModelAdapter2_get_Name() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Name
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_get_Name

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          IAPACMModelAdapter2_get_Param([in] string  marshal( bstr) parameterName) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Param
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_get_Param

  .method public hidebysig newslot specialname virtual 
          instance void  IAPACMModelAdapter2_set_Param([in] string  marshal( bstr) parameterName,
                                                       [in] object  marshal( struct) parameterValue) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::set_Param
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_set_Param

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          IAPACMModelAdapter2_get_type() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_type
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_get_type

  .method public hidebysig newslot specialname virtual 
          instance void  IAPACMModelAdapter2_set_type([in] object  marshal( struct) pVar) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::set_type
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_set_type

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPACMModelAdapter2_get_Queries() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Queries
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_get_Queries

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPACMModelAdapter2_get_VBScripts() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_VBScripts
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_get_VBScripts

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter2_Initialize(string  marshal( bstr) Path,
                                                        string  marshal( bstr) Library) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::Initialize
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_Initialize

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr 
          marshal( interface ) 
          IAPACMModelAdapter2_get_Properties() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Properties
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_get_Properties

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter2_OnComponentManagerEvent(valuetype AspenTech.AspenPlus.APServer.eACMComponentManagerEventType event,
                                                                     string  marshal( bstr) NewName,
                                                                     string  marshal( bstr) OldName) runtime managed internalcall
  {
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 3A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..:AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 41 43 4D 43 6F 6D 70 6F 6E 65 6E 74 4D 61 6E   // eACMComponentMan
                                                                                                            61 67 65 72 45 76 65 6E 74 54 79 70 65 00 00 )    // agerEventType..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::OnComponentManagerEvent
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_OnComponentManagerEvent

  .method public hidebysig newslot specialname virtual 
          instance int64  IAPACMModelAdapter2_get_Blkptr() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_Blkptr
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter2_get_Blkptr

  .method public hidebysig newslot virtual 
          instance void  InitializeByModelName(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                                               string  marshal( bstr) bsModelName) runtime managed internalcall
  {
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::InitializeByModelName
  } // end of method APACMModelAdapterClass::InitializeByModelName

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_DegreesOfFreedom() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::get_DegreesOfFreedom
  } // end of method APACMModelAdapterClass::get_DegreesOfFreedom

  .method public hidebysig newslot virtual 
          instance void  ResetSM(string  marshal( bstr) pszProperty,
                                 valuetype AspenTech.AspenPlus.APServer.eResetTypes iResetType,
                                 uint32 iOOMFAttributes,
                                 bool bKeepUserAssigns) runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 28 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..(AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 52 65 73 65 74 54 79 70 65 73 00 00 )          // eResetTypes..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::ResetSM
  } // end of method APACMModelAdapterClass::ResetSM

  .method public hidebysig newslot virtual 
          instance void  ReconcileEOToSM(string  marshal( bstr) pszProperty,
                                         int32 iReconType,
                                         uint32 iOOMFAttributes) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter2::ReconcileEOToSM
  } // end of method APACMModelAdapterClass::ReconcileEOToSM

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter3_Rename([in] string  marshal( bstr) fqOldname,
                                                    [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::Rename
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_Rename

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter3_Destroy([in] string  marshal( bstr) fqBlockName) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::Destroy
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_Destroy

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter3_Connect([in] string  marshal( bstr) portname,
                                                     [in] string  marshal( bstr) streamname) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::Connect
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_Connect

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPACMModelAdapter3_get_Ports() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Ports
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_Ports

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPACMModelAdapter3_get_Parameters() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Parameters
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_Parameters

  .method public hidebysig newslot specialname virtual 
          instance int32 
          marshal( error) 
          IAPACMModelAdapter3_get_StatusCode() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_StatusCode
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_StatusCode

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter3_Validate() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::Validate
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_Validate

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          IAPACMModelAdapter3_GetService([in] string  marshal( bstr) Service) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::GetService
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_GetService

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          IAPACMModelAdapter3_get_Name() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Name
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_Name

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          IAPACMModelAdapter3_get_Param([in] string  marshal( bstr) parameterName) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Param
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_Param

  .method public hidebysig newslot specialname virtual 
          instance void  IAPACMModelAdapter3_set_Param([in] string  marshal( bstr) parameterName,
                                                       [in] object  marshal( struct) parameterValue) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::set_Param
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_set_Param

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          IAPACMModelAdapter3_get_type() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_type
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_type

  .method public hidebysig newslot specialname virtual 
          instance void  IAPACMModelAdapter3_set_type([in] object  marshal( struct) pVar) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::set_type
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_set_type

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPACMModelAdapter3_get_Queries() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Queries
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_Queries

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( iunknown ) 
          IAPACMModelAdapter3_get_VBScripts() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_VBScripts
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_VBScripts

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter3_Initialize(string  marshal( bstr) Path,
                                                        string  marshal( bstr) Library) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::Initialize
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_Initialize

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr 
          marshal( interface ) 
          IAPACMModelAdapter3_get_Properties() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Properties
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_Properties

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter3_OnComponentManagerEvent(valuetype AspenTech.AspenPlus.APServer.eACMComponentManagerEventType event,
                                                                     string  marshal( bstr) NewName,
                                                                     string  marshal( bstr) OldName) runtime managed internalcall
  {
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 3A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..:AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 41 43 4D 43 6F 6D 70 6F 6E 65 6E 74 4D 61 6E   // eACMComponentMan
                                                                                                            61 67 65 72 45 76 65 6E 74 54 79 70 65 00 00 )    // agerEventType..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::OnComponentManagerEvent
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_OnComponentManagerEvent

  .method public hidebysig newslot specialname virtual 
          instance int64  IAPACMModelAdapter3_get_Blkptr() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_Blkptr
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_Blkptr

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter3_InitializeByModelName(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                                                                   string  marshal( bstr) bsModelName) runtime managed internalcall
  {
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::InitializeByModelName
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_InitializeByModelName

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          IAPACMModelAdapter3_get_DegreesOfFreedom() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::get_DegreesOfFreedom
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_get_DegreesOfFreedom

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter3_ResetSM(string  marshal( bstr) pszProperty,
                                                     valuetype AspenTech.AspenPlus.APServer.eResetTypes iResetType,
                                                     uint32 iOOMFAttributes,
                                                     bool bKeepUserAssigns) runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 28 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..(AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 52 65 73 65 74 54 79 70 65 73 00 00 )          // eResetTypes..
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::ResetSM
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_ResetSM

  .method public hidebysig newslot virtual 
          instance void  IAPACMModelAdapter3_ReconcileEOToSM(string  marshal( bstr) pszProperty,
                                                             int32 iReconType,
                                                             uint32 iOOMFAttributes) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::ReconcileEOToSM
  } // end of method APACMModelAdapterClass::IAPACMModelAdapter3_ReconcileEOToSM

  .method public hidebysig newslot virtual 
          instance void  AddReportVar(string  marshal( bstr) varName,
                                      string  marshal( bstr) varGUID) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::AddReportVar
  } // end of method APACMModelAdapterClass::AddReportVar

  .method public hidebysig newslot virtual 
          instance void  AddReportArray(string  marshal( bstr) ID,
                                        string  marshal( bstr) valGuid,
                                        string[]  marshal( safearray bstr) instanceGUIDInfo,
                                        string[]  marshal( safearray bstr) classGUIDInfo,
                                        object[]  marshal( safearray variant) wcReplaceInfo) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPACMModelAdapter3::AddReportArray
  } // end of method APACMModelAdapterClass::AddReportArray

  .method public hidebysig newslot virtual 
          instance void  UpdateResults() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPDynBlock::UpdateResults
  } // end of method APACMModelAdapterClass::UpdateResults

  .method public hidebysig newslot virtual 
          instance void  IAPDynBlock2_UpdateResults() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPDynBlock2::UpdateResults
  } // end of method APACMModelAdapterClass::IAPDynBlock2_UpdateResults

  .method public hidebysig newslot virtual 
          instance void  ProfileHandle(native int& hndl) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPDynBlock2::ProfileHandle
  } // end of method APACMModelAdapterClass::ProfileHandle

  .method public hidebysig newslot virtual 
          instance void  IsSolving(int32& bSolving) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPDynBlock2::IsSolving
  } // end of method APACMModelAdapterClass::IsSolving

  .method public hidebysig newslot virtual 
          instance void  CleanUpReportVars() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPDynBlock2::CleanUpReportVars
  } // end of method APACMModelAdapterClass::CleanUpReportVars

  .property callconv(8) object Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_Ports()
  } // end of property APACMModelAdapterClass::Ports
  .property callconv(8) object Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_Parameters()
  } // end of property APACMModelAdapterClass::Parameters
  .property callconv(8) int32 StatusCode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_StatusCode()
  } // end of property APACMModelAdapterClass::StatusCode
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_Name()
  } // end of property APACMModelAdapterClass::Name
  .property callconv(8) object Param(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.APServer.APACMModelAdapterClass::set_Param(string,
                                                                                      object)
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_Param(string)
  } // end of property APACMModelAdapterClass::Param
  .property callconv(8) object 'type'()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_type()
    .set instance void AspenTech.AspenPlus.APServer.APACMModelAdapterClass::set_type(object)
  } // end of property APACMModelAdapterClass::'type'
  .property callconv(8) object Queries()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 04 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_Queries()
  } // end of property APACMModelAdapterClass::Queries
  .property callconv(8) object VBScripts()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_VBScripts()
  } // end of property APACMModelAdapterClass::VBScripts
  .property callconv(8) class AspenTech.AspenPlus.APServer.APSHostCompListMgr
          Properties()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 04 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_Properties()
  } // end of property APACMModelAdapterClass::Properties
  .property callconv(8) int64 Blkptr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
    .get instance int64 AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_Blkptr()
  } // end of property APACMModelAdapterClass::Blkptr
  .property callconv(8) object IAPACMModelAdapter2_Ports()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_get_Ports()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter2_Ports
  .property callconv(8) object IAPACMModelAdapter2_Parameters()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_get_Parameters()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter2_Parameters
  .property callconv(8) int32 IAPACMModelAdapter2_StatusCode()
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_get_StatusCode()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter2_StatusCode
  .property callconv(8) string IAPACMModelAdapter2_Name()
  {
    .get instance string AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_get_Name()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter2_Name
  .property callconv(8) object IAPACMModelAdapter2_Param(string)
  {
    .set instance void AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_set_Param(string,
                                                                                                          object)
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_get_Param(string)
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter2_Param
  .property callconv(8) object IAPACMModelAdapter2_type()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_get_type()
    .set instance void AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_set_type(object)
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter2_type
  .property callconv(8) object IAPACMModelAdapter2_Queries()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_get_Queries()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter2_Queries
  .property callconv(8) object IAPACMModelAdapter2_VBScripts()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_get_VBScripts()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter2_VBScripts
  .property callconv(8) class AspenTech.AspenPlus.APServer.APSHostCompListMgr
          IAPACMModelAdapter2_Properties()
  {
    .get instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_get_Properties()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter2_Properties
  .property callconv(8) int64 IAPACMModelAdapter2_Blkptr()
  {
    .get instance int64 AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter2_get_Blkptr()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter2_Blkptr
  .property callconv(8) object DegreesOfFreedom()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::get_DegreesOfFreedom()
  } // end of property APACMModelAdapterClass::DegreesOfFreedom
  .property callconv(8) object IAPACMModelAdapter3_Ports()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_Ports()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_Ports
  .property callconv(8) object IAPACMModelAdapter3_Parameters()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_Parameters()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_Parameters
  .property callconv(8) int32 IAPACMModelAdapter3_StatusCode()
  {
    .get instance int32 AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_StatusCode()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_StatusCode
  .property callconv(8) string IAPACMModelAdapter3_Name()
  {
    .get instance string AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_Name()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_Name
  .property callconv(8) object IAPACMModelAdapter3_Param(string)
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_Param(string)
    .set instance void AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_set_Param(string,
                                                                                                          object)
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_Param
  .property callconv(8) object IAPACMModelAdapter3_type()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_type()
    .set instance void AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_set_type(object)
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_type
  .property callconv(8) object IAPACMModelAdapter3_Queries()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_Queries()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_Queries
  .property callconv(8) object IAPACMModelAdapter3_VBScripts()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_VBScripts()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_VBScripts
  .property callconv(8) class AspenTech.AspenPlus.APServer.APSHostCompListMgr
          IAPACMModelAdapter3_Properties()
  {
    .get instance class AspenTech.AspenPlus.APServer.APSHostCompListMgr AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_Properties()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_Properties
  .property callconv(8) int64 IAPACMModelAdapter3_Blkptr()
  {
    .get instance int64 AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_Blkptr()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_Blkptr
  .property callconv(8) object IAPACMModelAdapter3_DegreesOfFreedom()
  {
    .get instance object AspenTech.AspenPlus.APServer.APACMModelAdapterClass::IAPACMModelAdapter3_get_DegreesOfFreedom()
  } // end of property APACMModelAdapterClass::IAPACMModelAdapter3_DegreesOfFreedom
} // end of class AspenTech.AspenPlus.APServer.APACMModelAdapterClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.APServerEventSink
       implements [ASCClassLib380]ASCClassLib380.DASCSimulationMsgsEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 33 38 30 30 31 34 2D 46 37 30 34   // ..$00380014-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          41 50 53 65 72 76 65 72 45 76 65 6E 74 53 69 6E   // APServerEventSin
                                                                                                                          6B 43 6C 61 73 73 00 00 )                         // kClass..
} // end of class AspenTech.AspenPlus.APServer.APServerEventSink

.class public auto ansi import AspenTech.AspenPlus.APServer.APServerEventSinkClass
       extends [mscorlib]System.Object
       implements [ASCClassLib380]ASCClassLib380.DASCSimulationMsgsEvents,
                  AspenTech.AspenPlus.APServer.APServerEventSink,
                  [ASCClassLib380]ASCClassLib380.DASCSimulationMsgsEvents2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 45 46 42 39 42 43 32 2D 45 31 31 31   // ..$FEFB9BC2-E111
                                                                                                  2D 31 31 44 34 2D 38 32 41 44 2D 30 30 43 30 34   // -11D4-82AD-00C04
                                                                                                  46 30 34 38 41 41 45 00 00 )                      // F048AAE..
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method APServerEventSinkClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  OnNewLine([in] string  marshal( bstr) bText) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override [ASCClassLib380]ASCClassLib380.DASCSimulationMsgsEvents::OnNewLine
  } // end of method APServerEventSinkClass::OnNewLine

  .method public hidebysig newslot virtual 
          instance void  DASCSimulationMsgsEvents2_OnNewLine([in] string  marshal( bstr) bText) runtime managed preservesig internalcall
  {
    .override [ASCClassLib380]ASCClassLib380.DASCSimulationMsgsEvents2::OnNewLine
  } // end of method APServerEventSinkClass::DASCSimulationMsgsEvents2_OnNewLine

  .method public hidebysig newslot virtual 
          instance void  UpdateProfiles([in] string[]  marshal( safearray bstr) nameArray,
                                        [in] object[]  marshal( safearray variant) valArray,
                                        float64 time) runtime managed internalcall
  {
    .override [ASCClassLib380]ASCClassLib380.DASCSimulationMsgsEvents2::UpdateProfiles
  } // end of method APServerEventSinkClass::UpdateProfiles

  .method public hidebysig newslot virtual 
          instance void  ResetSimulation() runtime managed internalcall
  {
    .override [ASCClassLib380]ASCClassLib380.DASCSimulationMsgsEvents2::ResetSimulation
  } // end of method APServerEventSinkClass::ResetSimulation

} // end of class AspenTech.AspenPlus.APServer.APServerEventSinkClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPServerSim
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 44 34 37 45 37 33 30 2D 33 38 32 36   // ..$0D47E730-3826
                                                                                                  2D 31 31 44 35 2D 38 33 30 31 2D 30 30 43 30 34   // -11D5-8301-00C04
                                                                                                  46 32 39 38 37 35 36 00 00 )                      // F298756..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance void  NewEvent([in] int32 lEventId,
                                  [in] object  marshal( struct) Hint1,
                                  [in] object  marshal( struct) Hint2) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPServerSim::NewEvent

} // end of class AspenTech.AspenPlus.APServer.IAPServerSim

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.APServerSim
       implements AspenTech.AspenPlus.APServer.IAPServerSim,
                  AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 44 34 37 45 37 33 30 2D 33 38 32 36   // ..$0D47E730-3826
                                                                                                  2D 31 31 44 35 2D 38 33 30 31 2D 30 30 43 30 34   // -11D5-8301-00C04
                                                                                                  46 32 39 38 37 35 36 00 00 )                      // F298756..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 2D 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..-AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          41 50 53 65 72 76 65 72 53 69 6D 43 6C 61 73 73   // APServerSimClass
                                                                                                                          00 00 ) 
} // end of class AspenTech.AspenPlus.APServer.APServerSim

.class public auto ansi import AspenTech.AspenPlus.APServer.APServerSimClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.IAPServerSim,
                  AspenTech.AspenPlus.APServer.APServerSim,
                  AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 44 34 37 45 37 33 31 2D 33 38 32 36   // ..$0D47E731-3826
                                                                                                  2D 31 31 44 35 2D 38 33 30 31 2D 30 30 43 30 34   // -11D5-8301-00C04
                                                                                                  46 32 39 38 37 35 36 00 00 )                      // F298756..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComSourceInterfacesAttribute::.ctor(string) = ( 01 00 32 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..2AspenTech.Asp
                                                                                                                 65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                 5F 49 41 50 53 65 72 76 65 72 53 69 6D 45 76 65   // _IAPServerSimEve
                                                                                                                 6E 74 73 00 00 00 00 )                            // nts....
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method APServerSimClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  NewEvent([in] int32 lEventId,
                                  [in] object  marshal( struct) Hint1,
                                  [in] object  marshal( struct) Hint2) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPServerSim::NewEvent
  } // end of method APServerSimClass::NewEvent

  .method public hidebysig newslot virtual 
          instance void  add_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event::add_OnEvent
  } // end of method APServerSimClass::add_OnEvent

  .method public hidebysig newslot virtual 
          instance void  remove_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event::remove_OnEvent
  } // end of method APServerSimClass::remove_OnEvent

  .event AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler OnEvent
  {
    .removeon instance void AspenTech.AspenPlus.APServer.APServerSimClass::remove_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler)
    .addon instance void AspenTech.AspenPlus.APServer.APServerSimClass::add_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler)
  } // end of event APServerSimClass::OnEvent
} // end of class AspenTech.AspenPlus.APServer.APServerSimClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPProperties
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 34 46 41 41 43 34 44 2D 41 34 39 37   // ..$04FAAC4D-A497
                                                                                                  2D 34 34 35 45 2D 38 33 43 41 2D 30 43 44 38 31   // -445E-83CA-0CD81
                                                                                                  46 31 31 31 45 34 37 00 00 )                      // F111E47..
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPProperties::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_OptionValue([in] valuetype AspenTech.AspenPlus.APServer.APPropertyOption option,
                                         [in] object  marshal( struct) 'value') runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..-AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 72 6F 70 65 72 74 79 4F 70 74 69 6F 6E   // APPropertyOption
                                                                                                            00 00 ) 
  } // end of method IAPProperties::set_OptionValue

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_OptionValue([in] valuetype AspenTech.AspenPlus.APServer.APPropertyOption option) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..-AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 72 6F 70 65 72 74 79 4F 70 74 69 6F 6E   // APPropertyOption
                                                                                                            00 00 ) 
  } // end of method IAPProperties::get_OptionValue

  .method public hidebysig newslot abstract virtual 
          instance void  AddComponent([in] string  marshal( bstr) Component) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPProperties::AddComponent

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveComponent([in] string  marshal( bstr) Component) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPProperties::RemoveComponent

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Components() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IAPProperties::get_Components

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Options() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IAPProperties::get_Options

  .method public hidebysig newslot abstract virtual 
          instance void  RenameComponent([in] string  marshal( bstr) OldName,
                                         [in] string  marshal( bstr) NewName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
  } // end of method IAPProperties::RenameComponent

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveAllComponents() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
  } // end of method IAPProperties::RemoveAllComponents

  .method public hidebysig newslot abstract virtual 
          instance void  SetParent(string  marshal( bstr) Parent) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
  } // end of method IAPProperties::SetParent

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.IAPProperties::get_Name()
  } // end of property IAPProperties::Name
  .property callconv(8) object OptionValue(valuetype AspenTech.AspenPlus.APServer.APPropertyOption)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPProperties::get_OptionValue(valuetype AspenTech.AspenPlus.APServer.APPropertyOption)
    .set instance void AspenTech.AspenPlus.APServer.IAPProperties::set_OptionValue(valuetype AspenTech.AspenPlus.APServer.APPropertyOption,
                                                                                   object)
  } // end of property IAPProperties::OptionValue
  .property callconv(8) int32 Components()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPProperties::get_Components()
  } // end of property IAPProperties::Components
  .property callconv(8) int32 Options()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPProperties::get_Options()
  } // end of property IAPProperties::Options
} // end of class AspenTech.AspenPlus.APServer.IAPProperties

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.APSHostCompList
       implements AspenTech.AspenPlus.APServer.IAPProperties
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          41 50 53 48 6F 73 74 43 6F 6D 70 4C 69 73 74 43   // APSHostCompListC
                                                                                                                          6C 61 73 73 00 00 )                               // lass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 34 46 41 41 43 34 44 2D 41 34 39 37   // ..$04FAAC4D-A497
                                                                                                  2D 34 34 35 45 2D 38 33 43 41 2D 30 43 44 38 31   // -445E-83CA-0CD81
                                                                                                  46 31 31 31 45 34 37 00 00 )                      // F111E47..
} // end of class AspenTech.AspenPlus.APServer.APSHostCompList

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPPolymerProperties
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 34 35 34 41 35 43 45 43 2D 41 32 44 43   // ..$454A5CEC-A2DC
                                                                                                  2D 34 46 37 35 2D 38 45 46 46 2D 46 39 33 38 34   // -4F75-8EFF-F9384
                                                                                                  42 33 37 32 38 46 44 00 00 )                      // B3728FD..
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPPolymerProperties::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_OptionValue([in] valuetype AspenTech.AspenPlus.APServer.APPolymerOption option,
                                         [in] object  marshal( struct) Item1,
                                         [in] object  marshal( struct) 'value') runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2C 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..,AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 6F 6C 79 6D 65 72 4F 70 74 69 6F 6E 00   // APPolymerOption.
                                                                                                            00 ) 
  } // end of method IAPPolymerProperties::set_OptionValue

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_OptionValue([in] valuetype AspenTech.AspenPlus.APServer.APPolymerOption option,
                          [in] object  marshal( struct) Item1) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2C 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..,AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 6F 6C 79 6D 65 72 4F 70 74 69 6F 6E 00   // APPolymerOption.
                                                                                                            00 ) 
  } // end of method IAPPolymerProperties::get_OptionValue

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveFromOptionValueList([in] valuetype AspenTech.AspenPlus.APServer.APPolymerOption option,
                                                   [in] string  marshal( bstr) ValueToBeRemoved) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2C 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..,AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 6F 6C 79 6D 65 72 4F 70 74 69 6F 6E 00   // APPolymerOption.
                                                                                                            00 ) 
  } // end of method IAPPolymerProperties::RemoveFromOptionValueList

  .method public hidebysig newslot abstract virtual 
          instance void  AddToOptionValueList([in] valuetype AspenTech.AspenPlus.APServer.APPolymerOption option,
                                              [in] string  marshal( bstr) ValueToBeAdded) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2C 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..,AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 6F 6C 79 6D 65 72 4F 70 74 69 6F 6E 00   // APPolymerOption.
                                                                                                            00 ) 
  } // end of method IAPPolymerProperties::AddToOptionValueList

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.IAPPolymerProperties::get_Name()
  } // end of property IAPPolymerProperties::Name
  .property callconv(8) object OptionValue(valuetype AspenTech.AspenPlus.APServer.APPolymerOption,
                                           object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.IAPPolymerProperties::get_OptionValue(valuetype AspenTech.AspenPlus.APServer.APPolymerOption,
                                                                                            object)
    .set instance void AspenTech.AspenPlus.APServer.IAPPolymerProperties::set_OptionValue(valuetype AspenTech.AspenPlus.APServer.APPolymerOption,
                                                                                          object,
                                                                                          object)
  } // end of property IAPPolymerProperties::OptionValue
} // end of class AspenTech.AspenPlus.APServer.IAPPolymerProperties

.class public auto ansi import AspenTech.AspenPlus.APServer.APSHostCompListClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.IAPProperties,
                  AspenTech.AspenPlus.APServer.APSHostCompList,
                  AspenTech.AspenPlus.APServer.IAPPolymerProperties
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 45 31 44 31 37 36 45 38 2D 30 30 35 35   // ..$E1D176E8-0055
                                                                                                  2D 34 41 39 31 2D 39 35 46 34 2D 46 32 34 43 37   // -4A91-95F4-F24C7
                                                                                                  33 36 41 30 46 34 30 00 00 )                      // 36A0F40..
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method APSHostCompListClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPProperties::get_Name
  } // end of method APSHostCompListClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance void  set_OptionValue([in] valuetype AspenTech.AspenPlus.APServer.APPropertyOption option,
                                         [in] object  marshal( struct) 'value') runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..-AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 72 6F 70 65 72 74 79 4F 70 74 69 6F 6E   // APPropertyOption
                                                                                                            00 00 ) 
    .override AspenTech.AspenPlus.APServer.IAPProperties::set_OptionValue
  } // end of method APSHostCompListClass::set_OptionValue

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_OptionValue([in] valuetype AspenTech.AspenPlus.APServer.APPropertyOption option) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..-AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 72 6F 70 65 72 74 79 4F 70 74 69 6F 6E   // APPropertyOption
                                                                                                            00 00 ) 
    .override AspenTech.AspenPlus.APServer.IAPProperties::get_OptionValue
  } // end of method APSHostCompListClass::get_OptionValue

  .method public hidebysig newslot virtual 
          instance void  AddComponent([in] string  marshal( bstr) Component) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPProperties::AddComponent
  } // end of method APSHostCompListClass::AddComponent

  .method public hidebysig newslot virtual 
          instance void  RemoveComponent([in] string  marshal( bstr) Component) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPProperties::RemoveComponent
  } // end of method APSHostCompListClass::RemoveComponent

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Components() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPProperties::get_Components
  } // end of method APSHostCompListClass::get_Components

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Options() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPProperties::get_Options
  } // end of method APSHostCompListClass::get_Options

  .method public hidebysig newslot virtual 
          instance void  RenameComponent([in] string  marshal( bstr) OldName,
                                         [in] string  marshal( bstr) NewName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPProperties::RenameComponent
  } // end of method APSHostCompListClass::RenameComponent

  .method public hidebysig newslot virtual 
          instance void  RemoveAllComponents() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPProperties::RemoveAllComponents
  } // end of method APSHostCompListClass::RemoveAllComponents

  .method public hidebysig newslot virtual 
          instance void  SetParent(string  marshal( bstr) Parent) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPProperties::SetParent
  } // end of method APSHostCompListClass::SetParent

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          IAPPolymerProperties_get_Name() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.APServer.IAPPolymerProperties::get_Name
  } // end of method APSHostCompListClass::IAPPolymerProperties_get_Name

  .method public hidebysig newslot specialname virtual 
          instance void  set_OptionValue([in] valuetype AspenTech.AspenPlus.APServer.APPolymerOption option,
                                         [in] object  marshal( struct) Item1,
                                         [in] object  marshal( struct) 'value') runtime managed internalcall
  {
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2C 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..,AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 6F 6C 79 6D 65 72 4F 70 74 69 6F 6E 00   // APPolymerOption.
                                                                                                            00 ) 
    .override AspenTech.AspenPlus.APServer.IAPPolymerProperties::set_OptionValue
  } // end of method APSHostCompListClass::set_OptionValue

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_OptionValue([in] valuetype AspenTech.AspenPlus.APServer.APPolymerOption option,
                          [in] object  marshal( struct) Item1) runtime managed internalcall
  {
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2C 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..,AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 6F 6C 79 6D 65 72 4F 70 74 69 6F 6E 00   // APPolymerOption.
                                                                                                            00 ) 
    .override AspenTech.AspenPlus.APServer.IAPPolymerProperties::get_OptionValue
  } // end of method APSHostCompListClass::get_OptionValue

  .method public hidebysig newslot virtual 
          instance void  RemoveFromOptionValueList([in] valuetype AspenTech.AspenPlus.APServer.APPolymerOption option,
                                                   [in] string  marshal( bstr) ValueToBeRemoved) runtime managed internalcall
  {
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2C 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..,AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 6F 6C 79 6D 65 72 4F 70 74 69 6F 6E 00   // APPolymerOption.
                                                                                                            00 ) 
    .override AspenTech.AspenPlus.APServer.IAPPolymerProperties::RemoveFromOptionValueList
  } // end of method APSHostCompListClass::RemoveFromOptionValueList

  .method public hidebysig newslot virtual 
          instance void  AddToOptionValueList([in] valuetype AspenTech.AspenPlus.APServer.APPolymerOption option,
                                              [in] string  marshal( bstr) ValueToBeAdded) runtime managed internalcall
  {
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2C 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..,AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            41 50 50 6F 6C 79 6D 65 72 4F 70 74 69 6F 6E 00   // APPolymerOption.
                                                                                                            00 ) 
    .override AspenTech.AspenPlus.APServer.IAPPolymerProperties::AddToOptionValueList
  } // end of method APSHostCompListClass::AddToOptionValueList

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.APServer.APSHostCompListClass::get_Name()
  } // end of property APSHostCompListClass::Name
  .property callconv(8) object OptionValue(valuetype AspenTech.AspenPlus.APServer.APPropertyOption)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.APServer.APSHostCompListClass::get_OptionValue(valuetype AspenTech.AspenPlus.APServer.APPropertyOption)
    .set instance void AspenTech.AspenPlus.APServer.APSHostCompListClass::set_OptionValue(valuetype AspenTech.AspenPlus.APServer.APPropertyOption,
                                                                                          object)
  } // end of property APSHostCompListClass::OptionValue
  .property callconv(8) int32 Components()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.APSHostCompListClass::get_Components()
  } // end of property APSHostCompListClass::Components
  .property callconv(8) int32 Options()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.APSHostCompListClass::get_Options()
  } // end of property APSHostCompListClass::Options
  .property callconv(8) string IAPPolymerProperties_Name()
  {
    .get instance string AspenTech.AspenPlus.APServer.APSHostCompListClass::IAPPolymerProperties_get_Name()
  } // end of property APSHostCompListClass::IAPPolymerProperties_Name
  .property callconv(8) object IAPPolymerProperties_OptionValue(valuetype AspenTech.AspenPlus.APServer.APPolymerOption,
                                                                object)
  {
    .get instance object AspenTech.AspenPlus.APServer.APSHostCompListClass::get_OptionValue(valuetype AspenTech.AspenPlus.APServer.APPolymerOption,
                                                                                            object)
    .set instance void AspenTech.AspenPlus.APServer.APSHostCompListClass::set_OptionValue(valuetype AspenTech.AspenPlus.APServer.APPolymerOption,
                                                                                          object,
                                                                                          object)
  } // end of property APSHostCompListClass::IAPPolymerProperties_OptionValue
} // end of class AspenTech.AspenPlus.APServer.APSHostCompListClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IAPPropertiesCollection
       implements [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 37 34 32 37 34 46 45 2D 30 37 38 45   // ..$074274FE-078E
                                                                                                  2D 34 33 31 34 2D 38 35 37 31 2D 35 37 42 31 42   // -4314-8571-57B1B
                                                                                                  41 31 46 35 31 38 32 00 00 )                      // A1F5182..
  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompList 
          marshal( interface ) 
          Add([in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 02 60 00 00 )                         // .....`..
  } // end of method IAPPropertiesCollection::Add

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompList 
          marshal( interface ) 
          Duplicate([in] string  marshal( bstr) source,
                    [in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IAPPropertiesCollection::Duplicate

  .method public hidebysig newslot abstract virtual 
          instance void  Remove([in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IAPPropertiesCollection::Remove

  .method public hidebysig newslot abstract virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IAPPropertiesCollection::Rename

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IAPPropertiesCollection::get_Count

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompList 
          marshal( interface ) 
          get_Item([in] object  marshal( struct) index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IAPPropertiesCollection::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IAPPropertiesCollection::GetEnumerator

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.IAPPropertiesCollection::get_Count()
  } // end of property IAPPropertiesCollection::Count
  .property callconv(8) class AspenTech.AspenPlus.APServer.APSHostCompList
          Item(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.APServer.APSHostCompList AspenTech.AspenPlus.APServer.IAPPropertiesCollection::get_Item(object)
  } // end of property IAPPropertiesCollection::Item
} // end of class AspenTech.AspenPlus.APServer.IAPPropertiesCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.APSHostCompListMgr
       implements AspenTech.AspenPlus.APServer.IAPPropertiesCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 37 34 32 37 34 46 45 2D 30 37 38 45   // ..$074274FE-078E
                                                                                                  2D 34 33 31 34 2D 38 35 37 31 2D 35 37 42 31 42   // -4314-8571-57B1B
                                                                                                  41 31 46 35 31 38 32 00 00 )                      // A1F5182..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          41 50 53 48 6F 73 74 43 6F 6D 70 4C 69 73 74 4D   // APSHostCompListM
                                                                                                                          67 72 43 6C 61 73 73 00 00 )                      // grClass..
} // end of class AspenTech.AspenPlus.APServer.APSHostCompListMgr

.class public auto ansi import AspenTech.AspenPlus.APServer.APSHostCompListMgrClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.IAPPropertiesCollection,
                  AspenTech.AspenPlus.APServer.APSHostCompListMgr,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 33 37 32 32 43 37 43 35 2D 45 42 44 32   // ..$3722C7C5-EBD2
                                                                                                  2D 34 35 35 39 2D 39 43 41 38 2D 32 42 38 42 45   // -4559-9CA8-2B8BE
                                                                                                  41 32 45 44 33 33 44 00 00 )                      // A2ED33D..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method APSHostCompListMgrClass::.ctor

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompList 
          marshal( interface ) 
          Add([in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPPropertiesCollection::Add
  } // end of method APSHostCompListMgrClass::Add

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompList 
          marshal( interface ) 
          Duplicate([in] string  marshal( bstr) source,
                    [in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPPropertiesCollection::Duplicate
  } // end of method APSHostCompListMgrClass::Duplicate

  .method public hidebysig newslot virtual 
          instance void  Remove([in] string  marshal( bstr) Name) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPPropertiesCollection::Remove
  } // end of method APSHostCompListMgrClass::Remove

  .method public hidebysig newslot virtual 
          instance void  Rename([in] string  marshal( bstr) fqOldname,
                                [in] string  marshal( bstr) fqNewname) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPPropertiesCollection::Rename
  } // end of method APSHostCompListMgrClass::Rename

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.APServer.IAPPropertiesCollection::get_Count
  } // end of method APSHostCompListMgrClass::get_Count

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.APServer.APSHostCompList 
          marshal( interface ) 
          get_Item([in] object  marshal( struct) index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.IAPPropertiesCollection::get_Item
  } // end of method APSHostCompListMgrClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.APServer.IAPPropertiesCollection::GetEnumerator
  } // end of method APSHostCompListMgrClass::GetEnumerator

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.APServer.APSHostCompListMgrClass::get_Count()
  } // end of property APSHostCompListMgrClass::Count
  .property callconv(8) class AspenTech.AspenPlus.APServer.APSHostCompList
          Item(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.APServer.APSHostCompList AspenTech.AspenPlus.APServer.APSHostCompListMgrClass::get_Item(object)
  } // end of property APSHostCompListMgrClass::Item
} // end of class AspenTech.AspenPlus.APServer.APSHostCompListMgrClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.ICatalogXMLManager
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 43 31 44 34 41 46 37 38 2D 34 32 46 31   // ..$C1D4AF78-42F1
                                                                                                  2D 34 33 39 37 2D 38 46 30 42 2D 39 31 45 30 32   // -4397-8F0B-91E02
                                                                                                  46 31 43 30 43 32 43 00 00 )                      // F1C0C2C..
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method ICatalogXMLManager::get_Name

  .method public hidebysig newslot abstract virtual 
          instance bool  IsEmpty() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
  } // end of method ICatalogXMLManager::IsEmpty

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          CatObjects(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
  } // end of method ICatalogXMLManager::CatObjects

  .method public hidebysig newslot abstract virtual 
          instance void  Load([in] string  marshal( bstr) bsCatFullName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
  } // end of method ICatalogXMLManager::Load

  .method public hidebysig newslot abstract virtual 
          instance void  FindCatObjectByName(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                                             string  marshal( bstr) bsModelName,
                                             object&  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
  } // end of method ICatalogXMLManager::FindCatObjectByName

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.ICatalogXMLManager::get_Name()
  } // end of property ICatalogXMLManager::Name
} // end of class AspenTech.AspenPlus.APServer.ICatalogXMLManager

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.CatalogXMLManager
       implements AspenTech.AspenPlus.APServer.ICatalogXMLManager
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          43 61 74 61 6C 6F 67 58 4D 4C 4D 61 6E 61 67 65   // CatalogXMLManage
                                                                                                                          72 43 6C 61 73 73 00 00 )                         // rClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 43 31 44 34 41 46 37 38 2D 34 32 46 31   // ..$C1D4AF78-42F1
                                                                                                  2D 34 33 39 37 2D 38 46 30 42 2D 39 31 45 30 32   // -4397-8F0B-91E02
                                                                                                  46 31 43 30 43 32 43 00 00 )                      // F1C0C2C..
} // end of class AspenTech.AspenPlus.APServer.CatalogXMLManager

.class public auto ansi import AspenTech.AspenPlus.APServer.CatalogXMLManagerClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.ICatalogXMLManager,
                  AspenTech.AspenPlus.APServer.CatalogXMLManager
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 45 38 33 45 30 30 38 2D 35 41 38 44   // ..$0E83E008-5A8D
                                                                                                  2D 34 31 42 30 2D 42 41 39 34 2D 38 32 35 43 36   // -41B0-BA94-825C6
                                                                                                  36 44 43 43 35 46 34 00 00 )                      // 6DCC5F4..
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method CatalogXMLManagerClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatalogXMLManager::get_Name
  } // end of method CatalogXMLManagerClass::get_Name

  .method public hidebysig newslot virtual 
          instance bool  IsEmpty() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatalogXMLManager::IsEmpty
  } // end of method CatalogXMLManagerClass::IsEmpty

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          CatObjects(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .override AspenTech.AspenPlus.APServer.ICatalogXMLManager::CatObjects
  } // end of method CatalogXMLManagerClass::CatObjects

  .method public hidebysig newslot virtual 
          instance void  Load([in] string  marshal( bstr) bsCatFullName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatalogXMLManager::Load
  } // end of method CatalogXMLManagerClass::Load

  .method public hidebysig newslot virtual 
          instance void  FindCatObjectByName(valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType eType,
                                             string  marshal( bstr) bsModelName,
                                             object&  marshal( iunknown ) ppUnk) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .override AspenTech.AspenPlus.APServer.ICatalogXMLManager::FindCatObjectByName
  } // end of method CatalogXMLManagerClass::FindCatObjectByName

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.CatalogXMLManagerClass::get_Name()
  } // end of property CatalogXMLManagerClass::Name
} // end of class AspenTech.AspenPlus.APServer.CatalogXMLManagerClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.ICatObjectCollection
       implements [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 32 45 45 33 30 31 33 2D 33 36 35 38   // ..$12EE3013-3658
                                                                                                  2D 34 38 36 45 2D 41 35 41 37 2D 39 43 42 35 44   // -486E-A5A7-9CB5D
                                                                                                  46 32 46 31 39 31 42 00 00 )                      // F2F191B..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          Item([in] object  marshal( struct) vtIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method ICatObjectCollection::Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method ICatObjectCollection::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method ICatObjectCollection::get_Count

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance int32 AspenTech.AspenPlus.APServer.ICatObjectCollection::get_Count()
  } // end of property ICatObjectCollection::Count
} // end of class AspenTech.AspenPlus.APServer.ICatObjectCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.CatObjectCollection
       implements AspenTech.AspenPlus.APServer.ICatObjectCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 35 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..5AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          43 61 74 4F 62 6A 65 63 74 43 6F 6C 6C 65 63 74   // CatObjectCollect
                                                                                                                          69 6F 6E 43 6C 61 73 73 00 00 )                   // ionClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 32 45 45 33 30 31 33 2D 33 36 35 38   // ..$12EE3013-3658
                                                                                                  2D 34 38 36 45 2D 41 35 41 37 2D 39 43 42 35 44   // -486E-A5A7-9CB5D
                                                                                                  46 32 46 31 39 31 42 00 00 )                      // F2F191B..
} // end of class AspenTech.AspenPlus.APServer.CatObjectCollection

.class public auto ansi import AspenTech.AspenPlus.APServer.CatObjectCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.ICatObjectCollection,
                  AspenTech.AspenPlus.APServer.CatObjectCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 37 44 43 45 38 46 38 2D 30 38 30 36   // ..$17DCE8F8-0806
                                                                                                  2D 34 35 39 31 2D 42 31 37 42 2D 46 38 30 34 37   // -4591-B17B-F8047
                                                                                                  43 31 44 43 44 33 43 00 00 )                      // C1DCD3C..
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method CatObjectCollectionClass::.ctor

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          Item([in] object  marshal( struct) vtIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObjectCollection::Item
  } // end of method CatObjectCollectionClass::Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObjectCollection::GetEnumerator
  } // end of method CatObjectCollectionClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObjectCollection::get_Count
  } // end of method CatObjectCollectionClass::get_Count

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance int32 AspenTech.AspenPlus.APServer.CatObjectCollectionClass::get_Count()
  } // end of property CatObjectCollectionClass::Count
} // end of class AspenTech.AspenPlus.APServer.CatObjectCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.ICatObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 43 32 35 42 42 37 46 2D 34 31 32 31   // ..$0C25BB7F-4121
                                                                                                  2D 34 46 46 46 2D 38 30 44 33 2D 37 35 30 33 41   // -4FFF-80D3-7503A
                                                                                                  30 36 35 38 33 42 36 00 00 )                      // 06583B6..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method ICatObject::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType 
          get_ClassType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
  } // end of method ICatObject::get_ClassType

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_DLLName() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
  } // end of method ICatObject::get_DLLName

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          DLL() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
  } // end of method ICatObject::DLL

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          CatObjModels() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
  } // end of method ICatObject::CatObjModels

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 00 00 00 00 ) 
  } // end of method ICatObject::GetService

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.ICatObject::get_Name()
  } // end of property ICatObject::Name
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType
          ClassType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .get instance valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType AspenTech.AspenPlus.APServer.ICatObject::get_ClassType()
  } // end of property ICatObject::ClassType
  .property callconv(8) string DLLName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.ICatObject::get_DLLName()
  } // end of property ICatObject::DLLName
} // end of class AspenTech.AspenPlus.APServer.ICatObject

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.CatObject
       implements AspenTech.AspenPlus.APServer.ICatObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 2B 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..+AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          43 61 74 4F 62 6A 65 63 74 43 6C 61 73 73 00 00 ) // CatObjectClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 43 32 35 42 42 37 46 2D 34 31 32 31   // ..$0C25BB7F-4121
                                                                                                  2D 34 46 46 46 2D 38 30 44 33 2D 37 35 30 33 41   // -4FFF-80D3-7503A
                                                                                                  30 36 35 38 33 42 36 00 00 )                      // 06583B6..
} // end of class AspenTech.AspenPlus.APServer.CatObject

.class public auto ansi import AspenTech.AspenPlus.APServer.CatObjectClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.ICatObject,
                  AspenTech.AspenPlus.APServer.CatObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 44 35 30 32 31 45 30 35 2D 31 33 36 42   // ..$D5021E05-136B
                                                                                                  2D 34 45 35 46 2D 38 36 38 46 2D 42 43 33 34 33   // -4E5F-868F-BC343
                                                                                                  42 37 31 43 31 33 32 00 00 )                      // B71C132..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method CatObjectClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObject::get_Name
  } // end of method CatObjectClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType 
          get_ClassType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .override AspenTech.AspenPlus.APServer.ICatObject::get_ClassType
  } // end of method CatObjectClass::get_ClassType

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_DLLName() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObject::get_DLLName
  } // end of method CatObjectClass::get_DLLName

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          DLL() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObject::DLL
  } // end of method CatObjectClass::DLL

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          CatObjModels() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObject::CatObjModels
  } // end of method CatObjectClass::CatObjModels

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObject::GetService
  } // end of method CatObjectClass::GetService

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.CatObjectClass::get_Name()
  } // end of property CatObjectClass::Name
  .property callconv(8) valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType
          ClassType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 43 61 74 61 6C 6F 67 4F 62 6A 65 63 74 43 6C   // eCatalogObjectCl
                                                                                                            61 73 73 54 79 70 65 00 00 )                      // assType..
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .get instance valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType AspenTech.AspenPlus.APServer.CatObjectClass::get_ClassType()
  } // end of property CatObjectClass::ClassType
  .property callconv(8) string DLLName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.CatObjectClass::get_DLLName()
  } // end of property CatObjectClass::DLLName
} // end of class AspenTech.AspenPlus.APServer.CatObjectClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.ICatObjectModelCollection
       implements [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 33 32 37 38 35 43 35 39 2D 41 33 45 39   // ..$32785C59-A3E9
                                                                                                  2D 34 39 44 43 2D 42 37 44 41 2D 32 46 46 34 37   // -49DC-B7DA-2FF47
                                                                                                  43 37 39 46 42 42 46 00 00 )                      // C79FBBF..
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          Item([in] object  marshal( struct) vtIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method ICatObjectModelCollection::Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method ICatObjectModelCollection::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method ICatObjectModelCollection::get_Count

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance int32 AspenTech.AspenPlus.APServer.ICatObjectModelCollection::get_Count()
  } // end of property ICatObjectModelCollection::Count
} // end of class AspenTech.AspenPlus.APServer.ICatObjectModelCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.CatObjectModelCollection
       implements AspenTech.AspenPlus.APServer.ICatObjectModelCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 3A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..:AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          43 61 74 4F 62 6A 65 63 74 4D 6F 64 65 6C 43 6F   // CatObjectModelCo
                                                                                                                          6C 6C 65 63 74 69 6F 6E 43 6C 61 73 73 00 00 )    // llectionClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 33 32 37 38 35 43 35 39 2D 41 33 45 39   // ..$32785C59-A3E9
                                                                                                  2D 34 39 44 43 2D 42 37 44 41 2D 32 46 46 34 37   // -49DC-B7DA-2FF47
                                                                                                  43 37 39 46 42 42 46 00 00 )                      // C79FBBF..
} // end of class AspenTech.AspenPlus.APServer.CatObjectModelCollection

.class public auto ansi import AspenTech.AspenPlus.APServer.CatObjectModelCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.ICatObjectModelCollection,
                  AspenTech.AspenPlus.APServer.CatObjectModelCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 34 36 43 39 42 35 41 33 2D 37 46 31 41   // ..$46C9B5A3-7F1A
                                                                                                  2D 34 42 43 31 2D 41 44 41 46 2D 41 34 37 31 41   // -4BC1-ADAF-A471A
                                                                                                  34 33 39 39 30 43 31 00 00 )                      // 43990C1..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method CatObjectModelCollectionClass::.ctor

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          Item([in] object  marshal( struct) vtIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObjectModelCollection::Item
  } // end of method CatObjectModelCollectionClass::Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObjectModelCollection::GetEnumerator
  } // end of method CatObjectModelCollectionClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObjectModelCollection::get_Count
  } // end of method CatObjectModelCollectionClass::get_Count

  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance int32 AspenTech.AspenPlus.APServer.CatObjectModelCollectionClass::get_Count()
  } // end of property CatObjectModelCollectionClass::Count
} // end of class AspenTech.AspenPlus.APServer.CatObjectModelCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.ICatObjectModel
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 37 42 35 32 35 35 46 46 2D 46 36 34 34   // ..$7B5255FF-F644
                                                                                                  2D 34 32 30 33 2D 39 41 38 35 2D 31 45 36 30 32   // -4203-9A85-1E602
                                                                                                  45 30 39 43 31 37 42 00 00 )                      // E09C17B..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method ICatObjectModel::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_CategoryId() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
  } // end of method ICatObjectModel::get_CategoryId

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          GetStreamFromStorage([in] valuetype AspenTech.AspenPlus.APServer.eModelStrmType eAttribute) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..+AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 4D 6F 64 65 6C 53 74 72 6D 54 79 70 65 00 00 ) // eModelStrmType..
  } // end of method ICatObjectModel::GetStreamFromStorage

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.ICatObjectModel::get_Name()
  } // end of property ICatObjectModel::Name
  .property callconv(8) string CategoryId()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.ICatObjectModel::get_CategoryId()
  } // end of property ICatObjectModel::CategoryId
} // end of class AspenTech.AspenPlus.APServer.ICatObjectModel

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.CatObjectModel
       implements AspenTech.AspenPlus.APServer.ICatObjectModel
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          43 61 74 4F 62 6A 65 63 74 4D 6F 64 65 6C 43 6C   // CatObjectModelCl
                                                                                                                          61 73 73 00 00 )                                  // ass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 37 42 35 32 35 35 46 46 2D 46 36 34 34   // ..$7B5255FF-F644
                                                                                                  2D 34 32 30 33 2D 39 41 38 35 2D 31 45 36 30 32   // -4203-9A85-1E602
                                                                                                  45 30 39 43 31 37 42 00 00 )                      // E09C17B..
} // end of class AspenTech.AspenPlus.APServer.CatObjectModel

.class public auto ansi import AspenTech.AspenPlus.APServer.CatObjectModelClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.ICatObjectModel,
                  AspenTech.AspenPlus.APServer.CatObjectModel
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 43 43 45 37 43 44 41 37 2D 45 41 41 38   // ..$CCE7CDA7-EAA8
                                                                                                  2D 34 36 44 39 2D 42 34 39 46 2D 34 32 32 46 45   // -46D9-B49F-422FE
                                                                                                  31 32 45 35 45 39 41 00 00 )                      // 12E5E9A..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method CatObjectModelClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObjectModel::get_Name
  } // end of method CatObjectModelClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_CategoryId() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObjectModel::get_CategoryId
  } // end of method CatObjectModelClass::get_CategoryId

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.APServer.IStream 
          marshal( interface ) 
          GetStreamFromStorage([in] valuetype AspenTech.AspenPlus.APServer.eModelStrmType eAttribute) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .param [1]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..+AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                            65 4D 6F 64 65 6C 53 74 72 6D 54 79 70 65 00 00 ) // eModelStrmType..
    .override AspenTech.AspenPlus.APServer.ICatObjectModel::GetStreamFromStorage
  } // end of method CatObjectModelClass::GetStreamFromStorage

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.CatObjectModelClass::get_Name()
  } // end of property CatObjectModelClass::Name
  .property callconv(8) string CategoryId()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.CatObjectModelClass::get_CategoryId()
  } // end of property CatObjectModelClass::CategoryId
} // end of class AspenTech.AspenPlus.APServer.CatObjectModelClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.ICatObjectDLL
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 38 38 32 45 37 34 41 43 2D 37 32 38 33   // ..$882E74AC-7283
                                                                                                  2D 34 42 44 45 2D 38 44 46 42 2D 42 42 44 42 35   // -4BDE-8DFB-BBDB5
                                                                                                  32 30 42 35 42 35 33 00 00 )                      // 20B5B53..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method ICatObjectDLL::get_Name

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          Models() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
  } // end of method ICatObjectDLL::Models

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.ICatObjectDLL::get_Name()
  } // end of property ICatObjectDLL::Name
} // end of class AspenTech.AspenPlus.APServer.ICatObjectDLL

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.CatObjectDLL
       implements AspenTech.AspenPlus.APServer.ICatObjectDLL
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 38 38 32 45 37 34 41 43 2D 37 32 38 33   // ..$882E74AC-7283
                                                                                                  2D 34 42 44 45 2D 38 44 46 42 2D 42 42 44 42 35   // -4BDE-8DFB-BBDB5
                                                                                                  32 30 42 35 42 35 33 00 00 )                      // 20B5B53..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 2E 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ...AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 50 53 65 72 76 65 72 2E   // enPlus.APServer.
                                                                                                                          43 61 74 4F 62 6A 65 63 74 44 4C 4C 43 6C 61 73   // CatObjectDLLClas
                                                                                                                          73 00 00 )                                        // s..
} // end of class AspenTech.AspenPlus.APServer.CatObjectDLL

.class public auto ansi import AspenTech.AspenPlus.APServer.CatObjectDLLClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer.ICatObjectDLL,
                  AspenTech.AspenPlus.APServer.CatObjectDLL
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 33 36 30 36 43 31 43 2D 35 37 43 44   // ..$03606C1C-57CD
                                                                                                  2D 34 34 31 33 2D 38 32 37 36 2D 43 31 36 32 43   // -4413-8276-C162C
                                                                                                  45 39 46 41 46 38 35 00 00 )                      // E9FAF85..
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method CatObjectDLLClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObjectDLL::get_Name
  } // end of method CatObjectDLLClass::get_Name

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          Models() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.APServer.ICatObjectDLL::Models
  } // end of method CatObjectDLLClass::Models

  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance string AspenTech.AspenPlus.APServer.CatObjectDLLClass::get_Name()
  } // end of property CatObjectDLLClass::Name
} // end of class AspenTech.AspenPlus.APServer.CatObjectDLLClass

.class public auto ansi sealed AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method _IAPServerSimEvents_OnEventEventHandler::.ctor

  .method public virtual instance void  Invoke([in] int32 lEventId,
                                               [in] object  marshal( struct) Hint1,
                                               [in] object  marshal( struct) Hint2) runtime managed preservesig
  {
  } // end of method _IAPServerSimEvents_OnEventEventHandler::Invoke

} // end of class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler

.class public auto ansi sealed AspenTech.AspenPlus.APServer.eCatalogObjectClassType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType CLS_ACMBlock = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType CLS_ACMReaction = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType CLS_AOSSolver = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eCatalogObjectClassType CLS_ACMBlockBuiltIn = int32(0x00000003)
} // end of class AspenTech.AspenPlus.APServer.eCatalogObjectClassType

.class public auto ansi sealed AspenTech.AspenPlus.APServer.eACMComponentManagerEventType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eACMComponentManagerEventType ACMCListEvent_Added = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eACMComponentManagerEventType ACMCListEvent_Removed = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eACMComponentManagerEventType ACMCListEvent_Renamed = int32(0x00000002)
} // end of class AspenTech.AspenPlus.APServer.eACMComponentManagerEventType

.class public auto ansi sealed AspenTech.AspenPlus.APServer.APPropertyOption
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_ComponentList = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_PropertyMethod = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_HenryComponentsID = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_ChemistryID = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_FreeWater = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_WaterSolubility = int32(0x00000005)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_SimulationApproach = int32(0x00000006)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_KBase = int32(0x00000007)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_Retention = int32(0x00000008)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_Tolerance = int32(0x00000009)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_MaxIterations = int32(0x0000000A)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPropertyOption APOpt_Notify = int32(0x0000000B)
} // end of class AspenTech.AspenPlus.APServer.APPropertyOption

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.ISequentialStream
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 43 37 33 33 41 33 30 2D 32 41 31 43   // ..$0C733A30-2A1C
                                                                                                  2D 31 31 43 45 2D 41 44 45 35 2D 30 30 41 41 30   // -11CE-ADE5-00AA0
                                                                                                  30 34 34 37 37 33 44 00 00 )                      // 044773D..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  RemoteRead([out] uint8& pv,
                                    [in] uint32 cb,
                                    [out] uint32& pcbRead) runtime managed internalcall
  {
  } // end of method ISequentialStream::RemoteRead

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteWrite([in] uint8& pv,
                                     [in] uint32 cb,
                                     [out] uint32& pcbWritten) runtime managed internalcall
  {
  } // end of method ISequentialStream::RemoteWrite

} // end of class AspenTech.AspenPlus.APServer.ISequentialStream

.class interface public abstract auto ansi import AspenTech.AspenPlus.APServer.IStream
       implements AspenTech.AspenPlus.APServer.ISequentialStream
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 30 30 30 30 30 43 2D 30 30 30 30   // ..$0000000C-0000
                                                                                                  2D 30 30 30 30 2D 43 30 30 30 2D 30 30 30 30 30   // -0000-C000-00000
                                                                                                  30 30 30 30 30 34 36 00 00 )                      // 0000046..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  RemoteRead([out] uint8& pv,
                                    [in] uint32 cb,
                                    [out] uint32& pcbRead) runtime managed internalcall
  {
  } // end of method IStream::RemoteRead

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteWrite([in] uint8& pv,
                                     [in] uint32 cb,
                                     [out] uint32& pcbWritten) runtime managed internalcall
  {
  } // end of method IStream::RemoteWrite

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteSeek([in] valuetype AspenTech.AspenPlus.APServer._LARGE_INTEGER dlibMove,
                                    [in] uint32 dwOrigin,
                                    [out] valuetype AspenTech.AspenPlus.APServer._ULARGE_INTEGER& plibNewPosition) runtime managed internalcall
  {
  } // end of method IStream::RemoteSeek

  .method public hidebysig newslot abstract virtual 
          instance void  SetSize([in] valuetype AspenTech.AspenPlus.APServer._ULARGE_INTEGER libNewSize) runtime managed internalcall
  {
  } // end of method IStream::SetSize

  .method public hidebysig newslot abstract virtual 
          instance void  RemoteCopyTo([in] class AspenTech.AspenPlus.APServer.IStream  marshal( interface ) pstm,
                                      [in] valuetype AspenTech.AspenPlus.APServer._ULARGE_INTEGER cb,
                                      [out] valuetype AspenTech.AspenPlus.APServer._ULARGE_INTEGER& pcbRead,
                                      [out] valuetype AspenTech.AspenPlus.APServer._ULARGE_INTEGER& pcbWritten) runtime managed internalcall
  {
  } // end of method IStream::RemoteCopyTo

  .method public hidebysig newslot abstract virtual 
          instance void  Commit([in] uint32 grfCommitFlags) runtime managed internalcall
  {
  } // end of method IStream::Commit

  .method public hidebysig newslot abstract virtual 
          instance void  Revert() runtime managed internalcall
  {
  } // end of method IStream::Revert

  .method public hidebysig newslot abstract virtual 
          instance void  LockRegion([in] valuetype AspenTech.AspenPlus.APServer._ULARGE_INTEGER libOffset,
                                    [in] valuetype AspenTech.AspenPlus.APServer._ULARGE_INTEGER cb,
                                    [in] uint32 dwLockType) runtime managed internalcall
  {
  } // end of method IStream::LockRegion

  .method public hidebysig newslot abstract virtual 
          instance void  UnlockRegion([in] valuetype AspenTech.AspenPlus.APServer._ULARGE_INTEGER libOffset,
                                      [in] valuetype AspenTech.AspenPlus.APServer._ULARGE_INTEGER cb,
                                      [in] uint32 dwLockType) runtime managed internalcall
  {
  } // end of method IStream::UnlockRegion

  .method public hidebysig newslot abstract virtual 
          instance void  Stat([out] valuetype AspenTech.AspenPlus.APServer.tagSTATSTG& pstatstg,
                              [in] uint32 grfStatFlag) runtime managed internalcall
  {
  } // end of method IStream::Stat

  .method public hidebysig newslot abstract virtual 
          instance void  Clone([out] class AspenTech.AspenPlus.APServer.IStream&  marshal( interface ) ppstm) runtime managed internalcall
  {
  } // end of method IStream::Clone

} // end of class AspenTech.AspenPlus.APServer.IStream

.class public auto ansi sealed AspenTech.AspenPlus.APServer.eModelStrmType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eModelStrmType STRM_PortDefXML = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eModelStrmType STRM_APTemplate = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eModelStrmType STRM_IconDef = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eModelStrmType STRM_CustomFormsXML = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eModelStrmType STRM_StyleSheetXML = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eModelStrmType STRM_ACMLanguage = int32(0x00000005)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eModelStrmType STRM_Config = int32(0x00000006)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eModelStrmType STRM_ACMRxnConfig = int32(0x00000007)
} // end of class AspenTech.AspenPlus.APServer.eModelStrmType

.class public auto ansi sealed AspenTech.AspenPlus.APServer.APServerRetVMask
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_NAME = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_PHYSICAL_TYPE = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_LOWER = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_VALUE = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_UPPER = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_SCALE = int32(0x00000005)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_UOM = int32(0x00000006)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_CODE = int32(0x00000007)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_STEP = int32(0x00000008)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_SBWEIGHT = int32(0x00000009)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_SHADOW_PRICE = int32(0x0000000A)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_ACTIVE_BOUND = int32(0x0000000B)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTEVMASK_QUALITY = int32(0x0000000C)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APServerRetVMask APSERVER_RTESIZEOF_VMASK = int32(0x0000000D)
} // end of class AspenTech.AspenPlus.APServer.APServerRetVMask

.class public auto ansi sealed AspenTech.AspenPlus.APServer.eAPCapeOpenIdOption
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eAPCapeOpenIdOption CAPE_PROGID = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eAPCapeOpenIdOption CAPE_CLSID = int32(0x00000002)
} // end of class AspenTech.AspenPlus.APServer.eAPCapeOpenIdOption

.class public auto ansi sealed AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0010
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0010 CAPE_PROGID = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0010 CAPE_CLSID = int32(0x00000002)
} // end of class AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0010

.class public auto ansi sealed AspenTech.AspenPlus.APServer.ApServerRteBlockStatus
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus APSERVERRTE_BLOCK_NONEXISTENT = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus APSERVERRTE_BLOCK_EXCLUDED = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.ApServerRteBlockStatus APSERVERRTE_BLOCK_INCLUDED = int32(0x00000002)
} // end of class AspenTech.AspenPlus.APServer.ApServerRteBlockStatus

.class public auto ansi sealed AspenTech.AspenPlus.APServer.ApServerRteParamType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType APSERVERRTE_PARAM_UNDEFINED = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType APSERVERRTE_PARAM_UNKNOWN = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType APSERVERRTE_PARAM_STRING = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType APSERVERRTE_PARAM_REAL = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.ApServerRteParamType APSERVERRTE_PARAM_INTEGER = int32(0x00000004)
} // end of class AspenTech.AspenPlus.APServer.ApServerRteParamType

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.APServer._LARGE_INTEGER
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public int64 QuadPart
} // end of class AspenTech.AspenPlus.APServer._LARGE_INTEGER

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.APServer._ULARGE_INTEGER
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public uint64 QuadPart
} // end of class AspenTech.AspenPlus.APServer._ULARGE_INTEGER

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.APServer.tagSTATSTG
       extends [mscorlib]System.ValueType
{
  .pack 8
  .size 0
  .field public  marshal( lpwstr) string pwcsName
  .field public uint32 'type'
  .field public valuetype AspenTech.AspenPlus.APServer._ULARGE_INTEGER cbSize
  .field public valuetype AspenTech.AspenPlus.APServer._FILETIME mtime
  .field public valuetype AspenTech.AspenPlus.APServer._FILETIME ctime
  .field public valuetype AspenTech.AspenPlus.APServer._FILETIME atime
  .field public uint32 grfMode
  .field public uint32 grfLocksSupported
  .field public valuetype [mscorlib]System.Guid 'clsid'
  .field public uint32 grfStateBits
  .field public uint32 reserved
} // end of class AspenTech.AspenPlus.APServer.tagSTATSTG

.class public sequential ansi sealed beforefieldinit AspenTech.AspenPlus.APServer._FILETIME
       extends [mscorlib]System.ValueType
{
  .pack 4
  .size 0
  .field public uint32 dwLowDateTime
  .field public uint32 dwHighDateTime
} // end of class AspenTech.AspenPlus.APServer._FILETIME

.class public auto ansi sealed AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0007
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0007 CLS_ACMBlock = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0007 CLS_ACMReaction = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0007 CLS_AOSSolver = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0007 CLS_ACMBlockBuiltIn = int32(0x00000003)
} // end of class AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0007

.class public auto ansi sealed AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0003
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0003 APSERVERRTE_BLOCK_NONEXISTENT = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0003 APSERVERRTE_BLOCK_EXCLUDED = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0003 APSERVERRTE_BLOCK_INCLUDED = int32(0x00000002)
} // end of class AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0003

.class public auto ansi sealed AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0002
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0002 APSERVERRTE_PARAM_UNDEFINED = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0002 APSERVERRTE_PARAM_UNKNOWN = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0002 APSERVERRTE_PARAM_STRING = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0002 APSERVERRTE_PARAM_REAL = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0002 APSERVERRTE_PARAM_INTEGER = int32(0x00000004)
} // end of class AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0002

.class public auto ansi sealed AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_ComponentList = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_PropertyMethod = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_HenryComponentsID = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_ChemistryID = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_FreeWater = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_WaterSolubility = int32(0x00000005)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_SimulationApproach = int32(0x00000006)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_KBase = int32(0x00000007)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_Retention = int32(0x00000008)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_Tolerance = int32(0x00000009)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_MaxIterations = int32(0x0000000A)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004 APOpt_Notify = int32(0x0000000B)
} // end of class AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0004

.class public auto ansi sealed AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0006
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0006 ACMCListEvent_Added = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0006 ACMCListEvent_Removed = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0006 ACMCListEvent_Renamed = int32(0x00000002)
} // end of class AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0006

.class public auto ansi sealed AspenTech.AspenPlus.APServer.eResetTypes
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eResetTypes RESET_CALC_VARIABLE = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eResetTypes RESET_CONST_VARIABLE = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eResetTypes RESET_VARIABLE = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eResetTypes RESET_PARAMETER = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.eResetTypes RESET_ALL = int32(0x00000007)
} // end of class AspenTech.AspenPlus.APServer.eResetTypes

.class public auto ansi sealed AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0009
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0009 RESET_CALC_VARIABLE = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0009 RESET_CONST_VARIABLE = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0009 RESET_VARIABLE = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0009 RESET_PARAMETER = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0009 RESET_ALL = int32(0x00000007)
} // end of class AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0009

.class public auto ansi sealed AspenTech.AspenPlus.APServer.APPolymerOption
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_Polymer = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_Catalyst = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_Segments = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_PolymerAttributes = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CatalystAttributes = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CatalystSites = int32(0x00000005)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CAUSR1Comps = int32(0x00000006)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CAUSR2Comps = int32(0x00000007)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CAUSR3Comps = int32(0x00000008)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CAUSR4Comps = int32(0x00000009)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CAUSR5Comps = int32(0x0000000A)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CAUSRAComps = int32(0x0000000B)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CAUSRBComps = int32(0x0000000C)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CAUSRCComps = int32(0x0000000D)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CAUSRDComps = int32(0x0000000E)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CAUSREComps = int32(0x0000000F)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_CACLASS0Comps = int32(0x00000010)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_PROXANALComps = int32(0x00000011)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_ULTANALComps = int32(0x00000012)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_SULFANALComps = int32(0x00000013)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_GENANALComps = int32(0x00000014)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_PSDName = int32(0x00000015)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_PSDIntervals = int32(0x00000016)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_PSDSizeofIntervals = int32(0x00000017)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_SubStreams = int32(0x00000018)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.APPolymerOption APPolyOpt_NCComps = int32(0x00000019)
} // end of class AspenTech.AspenPlus.APServer.APPolymerOption

.class public auto ansi sealed AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_Polymer = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_Catalyst = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_Segments = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_PolymerAttributes = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CatalystAttributes = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CatalystSites = int32(0x00000005)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CAUSR1Comps = int32(0x00000006)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CAUSR2Comps = int32(0x00000007)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CAUSR3Comps = int32(0x00000008)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CAUSR4Comps = int32(0x00000009)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CAUSR5Comps = int32(0x0000000A)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CAUSRAComps = int32(0x0000000B)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CAUSRBComps = int32(0x0000000C)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CAUSRCComps = int32(0x0000000D)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CAUSRDComps = int32(0x0000000E)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CAUSREComps = int32(0x0000000F)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_CACLASS0Comps = int32(0x00000010)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_PROXANALComps = int32(0x00000011)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_ULTANALComps = int32(0x00000012)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_SULFANALComps = int32(0x00000013)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_GENANALComps = int32(0x00000014)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_PSDName = int32(0x00000015)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_PSDIntervals = int32(0x00000016)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_PSDSizeofIntervals = int32(0x00000017)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_SubStreams = int32(0x00000018)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005 APPolyOpt_NCComps = int32(0x00000019)
} // end of class AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0005

.class public auto ansi sealed AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008 STRM_PortDefXML = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008 STRM_APTemplate = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008 STRM_IconDef = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008 STRM_CustomFormsXML = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008 STRM_StyleSheetXML = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008 STRM_ACMLanguage = int32(0x00000005)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008 STRM_Config = int32(0x00000006)
  .field public static literal valuetype AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008 STRM_ACMRxnConfig = int32(0x00000007)
} // end of class AspenTech.AspenPlus.APServer.__MIDL___MIDL_itf_apserverdll_0000_0000_0008

.class public auto ansi sealed AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer._IAPServerSimEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .field public class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler m_OnEventDelegate
  .field public int32 m_dwCookie
  .method public virtual instance void  OnEvent(int32 A_1,
                                                object A_2,
                                                object A_3) cil managed
  {
    // Code size       42 (0x2a)
    .maxstack  4
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::m_OnEventDelegate
    IL_0009:  brfalse    IL_0029

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::m_OnEventDelegate
    IL_0017:  ldarg      A_1
    IL_001b:  ldarg      A_2
    IL_001f:  ldarg      A_3
    IL_0023:  callvirt   instance void AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler::Invoke(int32,
                                                                                                                    object,
                                                                                                                    object)
    IL_0028:  ret

    IL_0029:  ret
  } // end of method _IAPServerSimEvents_SinkHelper::OnEvent

  .method assembly specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  4
    IL_0000:  ldarg      0
    IL_0004:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0009:  ldarg      0
    IL_000d:  ldc.i4     0x0
    IL_0012:  stfld      int32 AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::m_dwCookie
    IL_0017:  ldarg      0
    IL_001b:  ldnull
    IL_001c:  stfld      class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::m_OnEventDelegate
    IL_0021:  ret
  } // end of method _IAPServerSimEvents_SinkHelper::.ctor

} // end of class AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper

.class private auto ansi sealed AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.APServer._IAPServerSimEvents_Event,
                  [mscorlib]System.IDisposable
{
  .field private class [mscorlib]System.WeakReference m_wkConnectionPointContainer
  .field private class [mscorlib]System.Collections.ArrayList m_aEventSinkHelpers
  .field private class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint m_ConnectionPoint
  .method private instance void  Init() cil managed
  {
    // Code size       271 (0x10f)
    .maxstack  5
    .locals init (class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint V_0,
             valuetype [mscorlib]System.Guid V_1,
             uint8[] V_2)
    IL_0000:  ldnull
    IL_0001:  stloc.0
    IL_0002:  ldc.i4     0x10
    IL_0007:  newarr     [mscorlib]System.Byte
    IL_000c:  stloc.2
    IL_000d:  ldloc.2
    IL_000e:  ldc.i4     0x0
    IL_0013:  ldc.i4     0x32
    IL_0018:  stelem.i1
    IL_0019:  ldloc.2
    IL_001a:  ldc.i4     0x1
    IL_001f:  ldc.i4     0xe7
    IL_0024:  stelem.i1
    IL_0025:  ldloc.2
    IL_0026:  ldc.i4     0x2
    IL_002b:  ldc.i4     0x47
    IL_0030:  stelem.i1
    IL_0031:  ldloc.2
    IL_0032:  ldc.i4     0x3
    IL_0037:  ldc.i4     0xd
    IL_003c:  stelem.i1
    IL_003d:  ldloc.2
    IL_003e:  ldc.i4     0x4
    IL_0043:  ldc.i4     0x26
    IL_0048:  stelem.i1
    IL_0049:  ldloc.2
    IL_004a:  ldc.i4     0x5
    IL_004f:  ldc.i4     0x38
    IL_0054:  stelem.i1
    IL_0055:  ldloc.2
    IL_0056:  ldc.i4     0x6
    IL_005b:  ldc.i4     0xd5
    IL_0060:  stelem.i1
    IL_0061:  ldloc.2
    IL_0062:  ldc.i4     0x7
    IL_0067:  ldc.i4     0x11
    IL_006c:  stelem.i1
    IL_006d:  ldloc.2
    IL_006e:  ldc.i4     0x8
    IL_0073:  ldc.i4     0x83
    IL_0078:  stelem.i1
    IL_0079:  ldloc.2
    IL_007a:  ldc.i4     0x9
    IL_007f:  ldc.i4     0x1
    IL_0084:  stelem.i1
    IL_0085:  ldloc.2
    IL_0086:  ldc.i4     0xa
    IL_008b:  ldc.i4     0x0
    IL_0090:  stelem.i1
    IL_0091:  ldloc.2
    IL_0092:  ldc.i4     0xb
    IL_0097:  ldc.i4     0xc0
    IL_009c:  stelem.i1
    IL_009d:  ldloc.2
    IL_009e:  ldc.i4     0xc
    IL_00a3:  ldc.i4     0x4f
    IL_00a8:  stelem.i1
    IL_00a9:  ldloc.2
    IL_00aa:  ldc.i4     0xd
    IL_00af:  ldc.i4     0x29
    IL_00b4:  stelem.i1
    IL_00b5:  ldloc.2
    IL_00b6:  ldc.i4     0xe
    IL_00bb:  ldc.i4     0x87
    IL_00c0:  stelem.i1
    IL_00c1:  ldloc.2
    IL_00c2:  ldc.i4     0xf
    IL_00c7:  ldc.i4     0x56
    IL_00cc:  stelem.i1
    IL_00cd:  ldloca.s   V_1
    IL_00cf:  ldloc.2
    IL_00d0:  call       instance void [mscorlib]System.Guid::.ctor(uint8[])
    IL_00d5:  ldarg      0
    IL_00d9:  ldfld      class [mscorlib]System.WeakReference AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_wkConnectionPointContainer
    IL_00de:  callvirt   instance object [mscorlib]System.WeakReference::get_Target()
    IL_00e3:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer
    IL_00e8:  ldloca.s   V_1
    IL_00ea:  ldloca.s   V_0
    IL_00ec:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer::FindConnectionPoint(valuetype [mscorlib]System.Guid&,
                                                                                                                                        class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint&)
    IL_00f1:  ldarg      0
    IL_00f5:  ldloc.0
    IL_00f6:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint
    IL_00fb:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_ConnectionPoint
    IL_0100:  ldarg      0
    IL_0104:  newobj     instance void [mscorlib]System.Collections.ArrayList::.ctor()
    IL_0109:  stfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_aEventSinkHelpers
    IL_010e:  ret
  } // end of method _IAPServerSimEvents_EventProvider::Init

  .method public virtual instance void  add_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::Init()
      IL_0022:  newobj     instance void AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::m_OnEventDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method _IAPServerSimEvents_EventProvider::add_OnEvent

  .method public virtual instance void  remove_OnEvent(class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::m_OnEventDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class AspenTech.AspenPlus.APServer._IAPServerSimEvents_OnEventEventHandler AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::m_OnEventDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method _IAPServerSimEvents_EventProvider::remove_OnEvent

  .method public specialname rtspecialname 
          instance void  .ctor(object A_1) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  6
    IL_0000:  ldarg      0
    IL_0004:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0009:  ldarg      0
    IL_000d:  ldarg      A_1
    IL_0011:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer
    IL_0016:  ldc.i4.0
    IL_0017:  newobj     instance void [mscorlib]System.WeakReference::.ctor(object,
                                                                             bool)
    IL_001c:  stfld      class [mscorlib]System.WeakReference AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_wkConnectionPointContainer
    IL_0021:  ret
  } // end of method _IAPServerSimEvents_EventProvider::.ctor

  .method public virtual instance void  Finalize() cil managed
  {
    // Code size       158 (0x9e)
    .maxstack  5
    .locals init (int32 V_0,
             int32 V_1,
             class AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      .try
      {
        IL_0000:  ldarg      0
        IL_0004:  ldloca.s   V_3
        IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                            bool&)
        IL_000b:  ldarg      0
        IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_ConnectionPoint
        IL_0014:  brfalse    IL_0080

        IL_0019:  ldarg      0
        IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_aEventSinkHelpers
        IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
        IL_0027:  stloc.0
        IL_0028:  ldc.i4     0x0
        IL_002d:  stloc.1
        IL_002e:  ldc.i4     0x0
        IL_0033:  ldloc.0
        IL_0034:  bge        IL_0071

        IL_0039:  ldarg      0
        IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_aEventSinkHelpers
        IL_0042:  ldloc.1
        IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
        IL_0048:  castclass  AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper
        IL_004d:  stloc.2
        IL_004e:  ldarg      0
        IL_0052:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_ConnectionPoint
        IL_0057:  ldloc.2
        IL_0058:  ldfld      int32 AspenTech.AspenPlus.APServer._IAPServerSimEvents_SinkHelper::m_dwCookie
        IL_005d:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
        IL_0062:  ldloc.1
        IL_0063:  ldc.i4     0x1
        IL_0068:  add
        IL_0069:  stloc.1
        IL_006a:  ldloc.1
        IL_006b:  ldloc.0
        IL_006c:  blt        IL_0039

        IL_0071:  ldarg      0
        IL_0075:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::m_ConnectionPoint
        IL_007a:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
        IL_007f:  pop
        IL_0080:  leave      IL_008b

      }  // end .try
      catch [mscorlib]System.Exception 
      {
        IL_0085:  pop
        IL_0086:  leave      IL_008b

      }  // end handler
      IL_008b:  leave      IL_009d

    }  // end .try
    finally
    {
      IL_0090:  ldloc.3
      IL_0091:  brfalse.s  IL_009c

      IL_0093:  ldarg      0
      IL_0097:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_009c:  endfinally
    }  // end handler
    IL_009d:  ret
  } // end of method _IAPServerSimEvents_EventProvider::Finalize

  .method public virtual instance void  Dispose() cil managed
  {
    // Code size       19 (0x13)
    .maxstack  2
    IL_0000:  ldarg      0
    IL_0004:  callvirt   instance void AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider::Finalize()
    IL_0009:  ldarg      0
    IL_000d:  call       void [mscorlib]System.GC::SuppressFinalize(object)
    IL_0012:  ret
  } // end of method _IAPServerSimEvents_EventProvider::Dispose

} // end of class AspenTech.AspenPlus.APServer._IAPServerSimEvents_EventProvider


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file C:\Users\Administrator\Desktop\Aspen 逆向\.local\batch-roundtrip-20261125\work-il\clr-i0oqz32u\editable\source.res
