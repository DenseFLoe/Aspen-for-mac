"""Order-insensitive method-body audit for items whose declaration order differs.

Usage: method_audit.py <sha8>

Pairs original and candidate MethodDef rows by
(declaring type full name, method name, flags, body length) in occurrence order,
then compares bodies byte-for-byte and, where they differ, counts token-only
differences recoverable by tokens.body_diff_map.  This is a measurement aid for
partial items; it does not produce a replay recipe.
"""
import json
import sys
from collections import defaultdict
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")
sys.path.insert(0, str(BASE / "managed-byte-recovery"))
sys.path.insert(0, str(BASE / "router" / "managed"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import clr_meta
from tokens import Image, body_diff_map

WORK = Path(__file__).resolve().parent.parent
LEDGER = {}
for line in open(BASE / "per-file.jsonl", encoding="utf-8"):
    r = json.loads(line)
    LEDGER[r["sha256"]] = r


def rows(img):
    pe, cli, root = clr_meta.read_image(img.data)
    out = []
    for x in clr_meta.method_defs(pe, cli, root):
        owner = img._owners()[0].get(x["row"], 0)
        out.append({"row": x["row"], "token": x["token"], "owner": img.typedef_key(owner) if owner else "",
                    "name": clr_meta.strings(pe, cli, root, x["name_index"]),
                    "flags": x["flags"], "rva": x["rva"], "bytes": x["body_bytes"]})
    return pe, out


def run(sha8):
    sha = next(s for s in LEDGER if s.startswith(sha8))
    r = LEDGER[sha]
    oi = Image(Path(r["installed_location"]).read_bytes(), "o")
    ci = Image(Path(WORK / sha8 / "out" / r["name"]).read_bytes(), "c")
    pe_o, ro = rows(oi)
    pe_c, rc = rows(ci)
    groups = defaultdict(lambda: {"o": [], "c": []})
    for x in ro:
        groups[(x["owner"], x["name"])]["o"].append(x)
    for x in rc:
        groups[(x["owner"], x["name"])]["c"].append(x)
    exact = remap = differ = only = 0
    differences = []
    for key, g in groups.items():
        n = min(len(g["o"]), len(g["c"]))
        only += abs(len(g["o"]) - len(g["c"]))
        for i in range(n):
            a, b = g["o"][i], g["c"][i]
            A = pe_o.get_data(a["rva"], a["bytes"])
            B = pe_c.get_data(b["rva"], b["bytes"])
            if A == B:
                exact += 1
                continue
            remaps, leftover = body_diff_map(oi, ci, A, B)
            if not leftover and remaps:
                remap += 1
            else:
                differ += 1
                differences.append({"token": "0x%08X" % a["token"], "owner": key[0], "name": key[1],
                                    "bytes": b["bytes"], "leftover": len(leftover),
                                    "first": (leftover[0].get("offset") if leftover else None)})
    report = {"sha8": sha8, "name": r["name"], "original_methods": len(ro), "candidate_methods": len(rc),
              "body_exact": exact, "token_only": remap, "body_differ": differ, "unpaired": only,
              "paired": exact + remap + differ,
              "differences": differences[:80]}
    (WORK / sha8 / "method-audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("sha8", "original_methods", "candidate_methods",
                                            "body_exact", "token_only", "body_differ", "unpaired", "paired")},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(run(sys.argv[1]))
