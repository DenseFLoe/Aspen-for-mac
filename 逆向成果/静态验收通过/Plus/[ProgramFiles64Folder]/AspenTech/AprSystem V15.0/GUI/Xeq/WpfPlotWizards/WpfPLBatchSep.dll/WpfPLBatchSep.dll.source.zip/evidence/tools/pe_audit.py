import argparse, hashlib, json
from pathlib import Path
import pefile

def sha(data):
    return hashlib.sha256(data).hexdigest()

def snapshot(path):
    pe = pefile.PE(path, fast_load=True)
    pe.parse_data_directories([
        pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_RESOURCE"],
        pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_DEBUG"],
    ])
    def visit(directory, parts=()):
        for entry in directory.entries:
            key = str(entry.name) if entry.name else str(entry.id)
            if hasattr(entry, "directory"):
                yield from visit(entry.directory, (*parts, key))
            else:
                meta = entry.data.struct
                payload = pe.get_data(meta.OffsetToData, meta.Size)
                yield {"path": list((*parts, key)), "length": len(payload),
                       "codepage": meta.CodePage, "sha256": sha(payload)}
    return {
        "sha256": sha(Path(path).read_bytes()),
        "size": Path(path).stat().st_size,
        "resource_leaves": list(visit(pe.DIRECTORY_ENTRY_RESOURCE)) if hasattr(pe, "DIRECTORY_ENTRY_RESOURCE") else [],
        "security_directory_size": pe.OPTIONAL_HEADER.DATA_DIRECTORY[4].Size,
        "debug_directory_size": pe.OPTIONAL_HEADER.DATA_DIRECTORY[6].Size,
        "pe_header_time_datestamp": pe.FILE_HEADER.TimeDateStamp,
        "pe_checksum": pe.OPTIONAL_HEADER.CheckSum,
        "sections": [{"name": s.Name.rstrip(b"\x00").decode("ascii"), "rva": s.VirtualAddress,
                      "raw_size": s.SizeOfRawData} for s in pe.sections],
    }

p = argparse.ArgumentParser()
p.add_argument("original")
p.add_argument("candidate")
p.add_argument("report", type=Path)
a = p.parse_args()
original, candidate = snapshot(a.original), snapshot(a.candidate)
result = {"original": original, "candidate": candidate,
          "resource_payloads_equal": original["resource_leaves"] == candidate["resource_leaves"],
          "pefile_version": pefile.__version__}
a.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")