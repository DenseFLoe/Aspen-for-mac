using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLHeatx;

[RibbonPlotWizardMgr("WpfPLHEATX.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class HeatxPlotWizardModule : PlotModuleBase
{
}
