using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenCxs;
using AspenTech.AspenCxs.CxsViewModel;
using AspenTech.AspenCxs.CxsViewModel.CompositeEvents;
using AspenTech.AspenPlus.Localization.Properties;
using AspenTech.AspenPlus.MMControls;
using AspenTech.AspenPlus.MMControls.CompositeEvents;
using AspenTech.AspenPlus.MMForms.Convergence.EO_Conv_Options;
using Microsoft.Practices.Composite.Presentation.Commands;
using Microsoft.Win32;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.MMForms.Blocks.ACMModel")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.MMForms.Blocks.ACMModel")]
[assembly: AssemblyCopyright("Copyright ©  2010 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/acmmodel", "AspenTech.AspenPlus.MMForms.Blocks.ACMModel")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]

namespace AspenTech.AspenPlus.MMForms.Blocks.ACMModel
{
	public class MMACMModel_Sparse_ViewModel : MMTabPageViewModel
	{
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_Sparse")]
	public class MMACMModel_SolverOptions_Sparse : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMSSTab1;

		internal MMTabItem tab0;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_Sparse()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMACMModel_Sparse_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_sparse.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMSSTab1 = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMACMModel_SolverOptions_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration ENTBLKSIM_Property = CxvPropertyDeclaration.Register("ENTBLKSIM", typeof(MMACMModel_SolverOptions_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKSIM"
		});

		public static readonly CxvPropertyDeclaration INITSTAT_Property = CxvPropertyDeclaration.Register("INITSTAT", typeof(MMACMModel_SolverOptions_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.CCINITOK"
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMACMModel_SolverOptions_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@INITSTAT" },
			EnteredDataPaths = { "@ENTBLKSIM" }
		});

		public object ENTBLKSIM => ((CxvViewModel)this).GetValue(ENTBLKSIM_Property);

		public object INITSTAT => ((CxvViewModel)this).GetValue(INITSTAT_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions")]
	public class MMACMModel_SolverOptions : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMTabStrip1;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMACMModel_SolverOptions_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			if (connectionId == 1)
			{
				MMTabStrip1 = (MMTabStrip)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMACMModel_Blocko_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration SMSPEC_Property = CxvPropertyDeclaration.Register("SMSPEC", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SMSPEC"
		});

		public static readonly CxvPropertyDeclaration ENTBLKDG_Property = CxvPropertyDeclaration.Register("ENTBLKDG", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKDG"
		});

		public static readonly CxvPropertyDeclaration ENTBLKRP_Property = CxvPropertyDeclaration.Register("ENTBLKRP", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKRP"
		});

		public static readonly CxvPropertyDeclaration SMENT_Property = CxvPropertyDeclaration.Register("SMENT", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SMENT"
		});

		public static readonly CxvPropertyDeclaration ENTBLKPR_Property = CxvPropertyDeclaration.Register("ENTBLKPR", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKPR"
		});

		public static readonly CxvPropertyDeclaration GENBLKOP_Property = CxvPropertyDeclaration.Register("GENBLKOP", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.GENBLKOP"
		});

		public static readonly CxvPropertyDeclaration ENTBLKSIM_Property = CxvPropertyDeclaration.Register("ENTBLKSIM", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKSIM"
		});

		public static readonly CxvPropertyDeclaration BKOP_Property = CxvPropertyDeclaration.Register("BKOP", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.BKOP"
		});

		public static readonly CxvPropertyDeclaration ENTCOMLIS_Property = CxvPropertyDeclaration.Register("ENTCOMLIS", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTCOMLIS"
		});

		public static readonly CxvPropertyDeclaration INITSTAT_Property = CxvPropertyDeclaration.Register("INITSTAT", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.CCINITOK"
		});

		public static readonly CxvPropertyDeclaration COMPLIST_Property = CxvPropertyDeclaration.Register("COMPLIST", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.COMPLIST"
		});

		public static readonly CxvPropertyDeclaration choice_Property = CxvPropertyDeclaration.Register("choice", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "choice"
		});

		public static readonly CxvPropertyDeclaration FLSP_Property = CxvPropertyDeclaration.Register("FLSP", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.FLSP"
		});

		public static readonly CxvPropertyDeclaration STRE_Property = CxvPropertyDeclaration.Register("STRE", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.STRE"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@BKOP", "@GENBLKOP" },
			EnteredDataPaths = { "@ENTBLKPR" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@COMPLIST" },
			EnteredDataPaths = { "@ENTCOMLIS" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@INITSTAT" },
			EnteredDataPaths = { "@ENTBLKSIM" }
		});

		public static readonly CxvPropertyDeclaration tab3_var_Property = CxvPropertyDeclaration.Register("tab3_var", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@FLSP" },
			EnteredDataPaths = { "@STRE" }
		});

		public static readonly CxvPropertyDeclaration tab4_var_Property = CxvPropertyDeclaration.Register("tab4_var", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@ENTBLKDG" }
		});

		public static readonly CxvPropertyDeclaration tab5_var_Property = CxvPropertyDeclaration.Register("tab5_var", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@SMSPEC" },
			EnteredDataPaths = { "@SMENT" }
		});

		public static readonly CxvPropertyDeclaration tab6_var_Property = CxvPropertyDeclaration.Register("tab6_var", typeof(MMACMModel_Blocko_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@ENTBLKRP" }
		});

		public object SMSPEC => ((CxvViewModel)this).GetValue(SMSPEC_Property);

		public object ENTBLKDG => ((CxvViewModel)this).GetValue(ENTBLKDG_Property);

		public object ENTBLKRP => ((CxvViewModel)this).GetValue(ENTBLKRP_Property);

		public object SMENT => ((CxvViewModel)this).GetValue(SMENT_Property);

		public object ENTBLKPR => ((CxvViewModel)this).GetValue(ENTBLKPR_Property);

		public object GENBLKOP => ((CxvViewModel)this).GetValue(GENBLKOP_Property);

		public object ENTBLKSIM => ((CxvViewModel)this).GetValue(ENTBLKSIM_Property);

		public object BKOP => ((CxvViewModel)this).GetValue(BKOP_Property);

		public object ENTCOMLIS => ((CxvViewModel)this).GetValue(ENTCOMLIS_Property);

		public object INITSTAT => ((CxvViewModel)this).GetValue(INITSTAT_Property);

		public object COMPLIST => ((CxvViewModel)this).GetValue(COMPLIST_Property);

		public object choice => ((CxvViewModel)this).GetValue(choice_Property);

		public object FLSP => ((CxvViewModel)this).GetValue(FLSP_Property);

		public object STRE => ((CxvViewModel)this).GetValue(STRE_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);

		public object tab3_var => ((CxvViewModel)this).GetValue(tab3_var_Property);

		public object tab4_var => ((CxvViewModel)this).GetValue(tab4_var_Property);

		public object tab5_var => ((CxvViewModel)this).GetValue(tab5_var_Property);

		public object tab6_var => ((CxvViewModel)this).GetValue(tab6_var_Property);
	}
	[ProgId("MMACMModel.MMACMModel_Blocko")]
	public class MMACMModel_Blocko : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMTabStrip1;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem tab3;

		internal MMTabItem tab4;

		internal MMTabItem tab5;

		internal MMTabItem tab6;

		internal MMTabItem tabInfo;

		private bool _contentLoaded;

		public MMACMModel_Blocko()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMACMModel_Blocko_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_blocko.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Expected O, but got Unknown
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Expected O, but got Unknown
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Expected O, but got Unknown
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			//IL_0061: Expected O, but got Unknown
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Expected O, but got Unknown
			//IL_0071: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Expected O, but got Unknown
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0088: Expected O, but got Unknown
			//IL_008b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0095: Expected O, but got Unknown
			//IL_0098: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a2: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMTabStrip1 = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				tab3 = (MMTabItem)target;
				break;
			case 6:
				tab4 = (MMTabItem)target;
				break;
			case 7:
				tab5 = (MMTabItem)target;
				break;
			case 8:
				tab6 = (MMTabItem)target;
				break;
			case 9:
				tabInfo = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMACMModel_Blocko_CompList_ViewModel : MMTabPageViewModel
	{
		public class grdFeedProducts_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(grdFeedProducts_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@main.Input.COMP_GROUP.@y",
				DisplayedCase = (CxsDisplayedCase)1
			});

			public static readonly CxvPropertyDeclaration MMComboBox5_var1_Property = CxvPropertyDeclaration.Register("MMComboBox5_var1", typeof(grdFeedProducts_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.COMP_GROUP.@y"
			});

			public static readonly CxvPropertyDeclaration MMComboBox4_MultiMap_Property;

			public static readonly CxvPropertyDeclaration MMComboBox3_var1_Property;

			public static readonly CxvPropertyDeclaration MMComboBox2_var1_Property;

			public static readonly CxvPropertyDeclaration MMComboBox1_3_MultiMap_Property;

			public static readonly CxvPropertyDeclaration MMComboBox1_2_var1_Property;

			public static readonly CxvPropertyDeclaration MMComboBox1_0_var1_Property;

			public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);

			public object MMComboBox5_var1 => ((CxvViewModel)this).GetValue(MMComboBox5_var1_Property);

			public object MMComboBox4_MultiMap => ((CxvViewModel)this).GetValue(MMComboBox4_MultiMap_Property);

			public object MMComboBox3_var1 => ((CxvViewModel)this).GetValue(MMComboBox3_var1_Property);

			public object MMComboBox2_var1 => ((CxvViewModel)this).GetValue(MMComboBox2_var1_Property);

			public object MMComboBox1_3_MultiMap => ((CxvViewModel)this).GetValue(MMComboBox1_3_MultiMap_Property);

			public object MMComboBox1_2_var1 => ((CxvViewModel)this).GetValue(MMComboBox1_2_var1_Property);

			public object MMComboBox1_0_var1 => ((CxvViewModel)this).GetValue(MMComboBox1_0_var1_Property);

			public grdFeedProducts_GridData_ItemTemplate()
			{
			}

			static grdFeedProducts_GridData_ItemTemplate()
			{
	MMComboBox4_MultiMap_Property = CxvPropertyDeclaration.Register("MMComboBox4_MultiMap", typeof(grdFeedProducts_GridData_ItemTemplate), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
				{
					Name = "MMComboBox4_var1",
					DataPath = "@main.Input.CL_TRUECOMPS.@y"
				} },
	Options = { new CxvMultiMapOption
				{
					Display = "True components",
					DisplayResourceKey = "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapOption_Display_True_components",
					Value = "MMComboBox4_MultiMapOption_1",
					Values = { new CxvMultiMapValue
				{
					Variable = "MMComboBox4_var1",
					Value = "YES"
				} }
				}, new CxvMultiMapOption
				{
					Display = "Apparent components",
					DisplayResourceKey = "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapOption_Display_Apparent_components",
					Value = "MMComboBox4_MultiMapOption_2",
					Values = { new CxvMultiMapValue
				{
					Variable = "MMComboBox4_var1",
					Value = "NO"
				} }
				} },
	IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.CLCHEML.@y"
				}
});
	MMComboBox3_var1_Property = CxvPropertyDeclaration.Register("MMComboBox3_var1", typeof(grdFeedProducts_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
				{
					ExposeAs = (CxvVariableTypeCode)2,
					DataPath = "@main.Input.CL_CHEMISTRY.@y"
				});
	MMComboBox2_var1_Property = CxvPropertyDeclaration.Register("MMComboBox2_var1", typeof(grdFeedProducts_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
				{
					ExposeAs = (CxvVariableTypeCode)2,
					DataPath = "@main.Input.CL_HENRYCOMP.@y"
				});
	MMComboBox1_3_MultiMap_Property = CxvPropertyDeclaration.Register("MMComboBox1_3_MultiMap", typeof(grdFeedProducts_GridData_ItemTemplate), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
				{
					Name = "MMComboBox1_3_var1",
					DataPath = "@main.Input.CL_SOLUWATER.@y"
				} },
	Options = { new CxvMultiMapOption
				{
					Display = "0 - Saturated steam table",
					DisplayResourceKey = "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapOption_Display_0___Saturated_steam_table",
					Value = "MMComboBox1_3_MultiMapOption_1",
					Values = { new CxvMultiMapValue
				{
					Variable = "MMComboBox1_3_var1",
					Value = "0"
				} }
				}, new CxvMultiMapOption
				{
					Display = "1 - Saturated primary package",
					DisplayResourceKey = "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapOption_Display_1___Saturated_primary_package",
					Value = "MMComboBox1_3_MultiMapOption_2",
					Values = { new CxvMultiMapValue
				{
					Variable = "MMComboBox1_3_var1",
					Value = "1"
				} }
				}, new CxvMultiMapOption
				{
					Display = "2 - Unsaturated primary package",
					DisplayResourceKey = "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapOption_Display_2___Unsaturated_primary_package",
					Value = "MMComboBox1_3_MultiMapOption_3",
					Values = { new CxvMultiMapValue
				{
					Variable = "MMComboBox1_3_var1",
					Value = "2"
				} }
				}, new CxvMultiMapOption
				{
					Display = "3 - No correction",
					DisplayResourceKey = "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapOption_Display_3___No_correction",
					Value = "MMComboBox1_3_MultiMapOption_4",
					Values = { new CxvMultiMapValue
				{
					Variable = "MMComboBox1_3_var1",
					Value = "3"
				} }
				}, new CxvMultiMapOption
				{
					Display = "4 - Water solubility is one",
					DisplayResourceKey = "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapOption_Display_4___Water_solubility_is_one",
					Value = "MMComboBox1_3_MultiMapOption_5",
					Values = { new CxvMultiMapValue
				{
					Variable = "MMComboBox1_3_var1",
					Value = "4"
				} }
				}, new CxvMultiMapOption
				{
					Display = "5 - Unsaturated steam",
					DisplayResourceKey = "MMACMModel_Blocko_CompList_ViewModel__CxvMultiMapOption_Display_5___Unsaturated_steam",
					Value = "MMComboBox1_3_MultiMapOption_6",
					Values = { new CxvMultiMapValue
				{
					Variable = "MMComboBox1_3_var1",
					Value = "5"
				} }
				} }
});
	MMComboBox1_2_var1_Property = CxvPropertyDeclaration.Register("MMComboBox1_2_var1", typeof(grdFeedProducts_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
				{
					ExposeAs = (CxvVariableTypeCode)2,
					DataPath = "@main.Input.CL_FREEWATER.@y"
				});
	MMComboBox1_0_var1_Property = CxvPropertyDeclaration.Register("MMComboBox1_0_var1", typeof(grdFeedProducts_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
				{
					ExposeAs = (CxvVariableTypeCode)2,
					DataPath = "@main.Input.CL_OPSETNAME.@y"
				});
	}
		}

		public static readonly CxvPropertyDeclaration grdFeedProducts_GridData_Property = CxvPropertyDeclaration.Register("grdFeedProducts_GridData", typeof(MMACMModel_Blocko_CompList_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdFeedProducts_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.COMP_GROUP",
				UseChildId = true,
				Name = "y"
			}
		});

		public object grdFeedProducts_GridData => ((CxvViewModel)this).GetValue(grdFeedProducts_GridData_Property);
	}
	[ProgId("MMACMModel.MMACMModel_Blocko_CompList")]
	public class MMACMModel_Blocko_CompList : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMScrollAreaHorizontal grdFeedProducts;

		private bool _contentLoaded;

		public MMACMModel_Blocko_CompList()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMACMModel_Blocko_CompList_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_blocko_complist.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				grdFeedProducts = (MMScrollAreaHorizontal)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMACMModel_Blocko_EOOptions_ViewModel : MMTabPageViewModel
	{
		public class grdScMeth_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMComboBox3_var1_Property = CxvPropertyDeclaration.Register("MMComboBox3_var1", typeof(grdScMeth_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.LOCALSCRIPT.@y",
				IsVisibleCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LOCASC.@y"
				}
			});

			public static readonly CxvPropertyDeclaration MMComboBox2_var1_Property;

			public static readonly CxvPropertyDeclaration MMComboBox4_var1_Property;

			public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property;

			public static readonly CxvPropertyDeclaration MMComboBox5_var1_Property;

			public static readonly CxvPropertyDeclaration ID_Property;

			public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property;

			public object MMComboBox3_var1 => ((CxvViewModel)this).GetValue(MMComboBox3_var1_Property);

			public object MMComboBox2_var1 => ((CxvViewModel)this).GetValue(MMComboBox2_var1_Property);

			public object MMComboBox4_var1 => ((CxvViewModel)this).GetValue(MMComboBox4_var1_Property);

			public object MMTextBox3_var1 => ((CxvViewModel)this).GetValue(MMTextBox3_var1_Property);

			public object MMComboBox5_var1 => ((CxvViewModel)this).GetValue(MMComboBox5_var1_Property);

			public object ID => ((CxvViewModel)this).GetValue(ID_Property);

			public object MMTextBox2_var1 => ((CxvViewModel)this).GetValue(MMTextBox2_var1_Property);

			public grdScMeth_GridData_ItemTemplate()
			{
			}

			static grdScMeth_GridData_ItemTemplate()
			{
	MMComboBox2_var1_Property = CxvPropertyDeclaration.Register("MMComboBox2_var1", typeof(grdScMeth_GridData_ItemTemplate), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
				{
					Name = "MultimapOptionScriptType",
					DataPath = "@main.Input.SC_TYPE.@y"
				} },
	Options = { new CxvMultiMapOption
				{
					Display = "Localscript",
					DisplayResourceKey = "MMACMModel_Eoopti_Model_ViewModel__CxvMultiMapOption_Display_Localscript",
					Value = "LOCALSCRIPT",
					Values = { new CxvMultiMapValue
				{
					Variable = "MultimapOptionScriptType",
					Value = "LOCALSCRIPT"
				} }
				}, new CxvMultiMapOption
				{
					Display = "Globalscript",
					DisplayResourceKey = "MMACMModel_Eoopti_Model_ViewModel__CxvMultiMapOption_Display_Globalscript",
					Value = "GLOBALSCRIPT",
					Values = { new CxvMultiMapValue
				{
					Variable = "MultimapOptionScriptType",
					Value = "GLOBALSCRIPT"
				} }
				}, new CxvMultiMapOption
				{
					Display = "File",
					DisplayResourceKey = "MMACMModel_Eoopti_Model_ViewModel__CxvMultiMapOption_Display_File",
					Value = "FILE",
					Values = { new CxvMultiMapValue
				{
					Variable = "MultimapOptionScriptType",
					Value = "FILE"
				} }
				} }
});
	MMComboBox4_var1_Property = CxvPropertyDeclaration.Register("MMComboBox4_var1", typeof(grdScMeth_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
				{
					ExposeAs = (CxvVariableTypeCode)2,
					DataPath = "@main.Input.GLOBALSCRIPT.@y",
					DisplayedCase = (CxsDisplayedCase)2,
					IsVisibleCondition = new CxvLogicalTest
					{
						DataPath = "@main.CC Nodes.GLOBSC.@y"
					}
				});
	MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(grdScMeth_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Input.USER_METHOD.@y",
					DisplayedCase = (CxsDisplayedCase)1
				});
	MMComboBox5_var1_Property = CxvPropertyDeclaration.Register("MMComboBox5_var1", typeof(grdScMeth_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
				{
					ExposeAs = (CxvVariableTypeCode)2,
					DataPath = "@main.Input.SC_METHOD.@y"
				});
	ID_Property = CxvPropertyDeclaration.Register("ID", typeof(grdScMeth_GridData_ItemTemplate), (CxvPropertyBase)new CxvPropertySelector
{
	Choices = { new CxvPropertyChoice { Conditions = { new CxvLogicalTest
				{
					DataPath = "@main.CC_Nodes.GLOBSC.@y"
				} }, Property = new CxvVariableProperty
				{
					ExposeAs = (CxvVariableTypeCode)2,
					DataPath = "@main.Input.GLOBALSCRIPT.@y"
				} }, new CxvPropertyChoice { Conditions = { new CxvLogicalTest
				{
					DataPath = "@main.CC_Nodes.LOCASC.@y"
				} }, Property = new CxvVariableProperty
				{
					ExposeAs = (CxvVariableTypeCode)2,
					DataPath = "@main.Input.LOCALSCRIPT.@y"
				} } }
});
	MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(grdScMeth_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Input.FILE.@y",
					DisplayedCase = (CxsDisplayedCase)1,
					IsEnabledCondition = new CxvLogicalTest
					{
						DataPath = "@main.CC Nodes.FILESC.@y"
					}
				});
	}
		}

		public static readonly CxvPropertyDeclaration grdScMeth_GridData_Property = CxvPropertyDeclaration.Register("grdScMeth_GridData", typeof(MMACMModel_Blocko_EOOptions_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdScMeth_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.SC_METHOD",
				UseChildId = true,
				Name = "y"
			}
		});

		private DelegateCommand<object> _cmdEdit_Command;

		private ObservableCollection<int> _selectedRowIndexes;

		public object grdScMeth_GridData => ((CxvViewModel)this).GetValue(grdScMeth_GridData_Property);

		public DelegateCommand<object> cmdEdit_Command
		{
			get
			{
				if (_cmdEdit_Command == null)
				{
					_cmdEdit_Command = new DelegateCommand<object>((Action<object>)cmdEdit_CommandExecute, (Func<object, bool>)cmdEdit_CommandCanExecute);
				}
				return _cmdEdit_Command;
			}
		}

		private void cmdEdit_CommandExecute(object parameter)
		{
			//IL_0134: Unknown result type (might be due to invalid IL or missing references)
			//IL_0139: Unknown result type (might be due to invalid IL or missing references)
			//IL_0144: Unknown result type (might be due to invalid IL or missing references)
			//IL_0154: Expected O, but got Unknown
			//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00be: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ff: Expected O, but got Unknown
			//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0209: Expected O, but got Unknown
			//IL_016e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0173: Unknown result type (might be due to invalid IL or missing references)
			//IL_017e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0185: Unknown result type (might be due to invalid IL or missing references)
			//IL_0195: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b4: Expected O, but got Unknown
			if (_selectedRowIndexes.Count == 1)
			{
				int num = _selectedRowIndexes[0];
				if (num >= 0)
				{
					grdScMeth_GridData_ItemTemplate obj = (grdScMeth_GridData as IList)[num] as grdScMeth_GridData_ItemTemplate;
					string strA = ICxvViewDataContainerExtensions.ResolveViewPropertyPath(obj, "MMComboBox2_var1.Value") as string;
					string text = ICxvViewDataContainerExtensions.ResolveViewPropertyPath(obj, "ID.Value") as string;
					string text2 = CxsConverter.ValueToString(((CxvViewModel)this).ResolveParameter("main", (CxvPropertyWatch)null));
					int num2 = text2.LastIndexOf("Data");
					if (num2 > 0)
				{
					text2 = text2.Substring(0, num2 + 4);
				}
				else
				{
					text2 = "Top.appModelV8";
				}
					text2 += ".EO Configuration.";
					if (string.Compare(strA, "LOCALSCRIPT", StringComparison.OrdinalIgnoreCase) == 0)
					{
						if (!string.IsNullOrEmpty(text))
						{
							DisplayFormEventArgs e = new DisplayFormEventArgs
							{
								FormProgId = "MMScMethod.MMScMethod_Setup_LocScr",
								LegacyFlags = 0,
								HelpId = 166,
								HelpFile = "eoconf.hlp",
								ShowPrompts = true,
								ShortName = Resources.MMACMModel_Blocko_EOOptions_LocalScript
							};
							string text3 = text2 + "Local Scripts.";
							e.Parameters.Add("Input", text3 + text + ".Input");
							((MMViewModel)this).DisplayForm(e);
						}
						else
						{
							((CxvViewModel)this).ShowMessageBox(new ShowMessageBoxEventArgs
							{
								Message = Resources.MMACMModel_Blocko_EOOptions_SpecifyGlobalScriptID,
								Title = Resources.MMACMModel_Blocko_EOOptions_EditVariable
							});
						}
					}
					else if (string.Compare(strA, "GLOBALSCRIPT", StringComparison.OrdinalIgnoreCase) == 0)
					{
						if (!string.IsNullOrEmpty(text))
						{
							DisplayFormEventArgs e2 = new DisplayFormEventArgs
							{
								FormProgId = "MMScMethod.MMScMethod_Setup_GloScr",
								LegacyFlags = 0,
								HelpId = 166,
								HelpFile = "eoconf.hlp",
								ShowPrompts = true,
								ShortName = Resources.MMACMModel_Blocko_EOOptions_GlobalScript
							};
							string text4 = text2 + "Global Scripts.";
							e2.Parameters.Add("Input", text4 + text + ".Input");
							((MMViewModel)this).DisplayForm(e2);
						}
						else
						{
							((CxvViewModel)this).ShowMessageBox(new ShowMessageBoxEventArgs
							{
								Message = Resources.MMACMModel_Blocko_EOOptions_SpecifyGlobalScriptID,
								Title = Resources.MMACMModel_Blocko_EOOptions_EditVariable
							});
						}
					}
				}
			}
		}

		private bool cmdEdit_CommandCanExecute(object parameter)
		{
			if (_selectedRowIndexes != null && _selectedRowIndexes.Count == 1)
			{
				int num = _selectedRowIndexes[0];
				IList list = grdScMeth_GridData as IList;
				if (num >= 0 && num < list.Count - 1)
				{
					string text = ICxvViewDataContainerExtensions.ResolveViewPropertyPath((list[num] as grdScMeth_GridData_ItemTemplate), "MMComboBox2_var1.Value") as string;
					if (!string.IsNullOrEmpty(text))
					{
						return string.Compare(text, "File", StringComparison.InvariantCultureIgnoreCase) != 0;
					}
					return false;
				}
			}
			return false;
		}

		public ObservableCollection<int> SelectedRowIndexes
		{
			get
			{
				return _selectedRowIndexes;
			}
			set
			{
				if (value != _selectedRowIndexes)
				{
					_selectedRowIndexes = value;
					_selectedRowIndexes.CollectionChanged -= delegate
					{
						cmdEdit_Command.RaiseCanExecuteChanged();
					};
					_selectedRowIndexes.CollectionChanged += delegate
					{
						cmdEdit_Command.RaiseCanExecuteChanged();
					};
				}
			}
		}

	}
	[ProgId("MMACMModel.MMACMModel_Blocko_EOOptions")]
	public class MMACMModel_Blocko_EOOptions : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame2;

		internal MMScrollArea grdScMeth;

		internal MMCmdButton cmdEdit;

		private bool _contentLoaded;

		public MMACMModel_Blocko_EOOptions()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMACMModel_Blocko_EOOptions_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_blocko_eooptions.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Expected O, but got Unknown
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMFrame2 = (MMGroupBox)target;
				break;
			case 2:
				grdScMeth = (MMScrollArea)target;
				break;
			case 3:
				cmdEdit = (MMCmdButton)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMACMModel_Blocko_SFlash_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMFrame3_state_Property = CxvPropertyDeclaration.Register("MMFrame3_state", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.KOD.@choice"
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText9_tol_Property = CxvPropertyDeclaration.Register("MMLBUText9_tol", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.TOL.@choice"
		});

		public static readonly CxvPropertyDeclaration MMSpinBox1_maxit_Property = CxvPropertyDeclaration.Register("MMSpinBox1_maxit", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.MAXIT.@choice"
		});

		public static readonly CxvPropertyDeclaration frmEst_state_Property = CxvPropertyDeclaration.Register("frmEst_state", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.KOD.@choice"
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText8_pest_Property = CxvPropertyDeclaration.Register("MMLBUText8_pest", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.P_EST.@choice",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.PEST.@choice"
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText7_test_Property = CxvPropertyDeclaration.Register("MMLBUText7_test", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.T_EST.@choice",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.TEST.@choice"
			}
		});

		public static readonly CxvPropertyDeclaration frmFlSpec_state_Property = CxvPropertyDeclaration.Register("frmFlSpec_state", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.KOD.@choice"
			}
		});

		public static readonly CxvPropertyDeclaration MMComboBox2_MultiMap_Property;

		public static readonly CxvPropertyDeclaration MMLBUText6_vfrac_Property;

		public static readonly CxvPropertyDeclaration MMLBUText5_pres_Property;

		public static readonly CxvPropertyDeclaration MMLBUText4_temp_Property;

		public static readonly CxvPropertyDeclaration MMMenuButton1_target_Property;

		public static readonly CxvPropertyDeclaration MMMenuButton1_flashstream_Property;

		public static readonly CxvPropertyDeclaration cboKode_MultiMap_Property;

		public object MMFrame3_state => ((CxvViewModel)this).GetValue(MMFrame3_state_Property);

		public object MMLBUText9_tol => ((CxvViewModel)this).GetValue(MMLBUText9_tol_Property);

		public object MMSpinBox1_maxit => ((CxvViewModel)this).GetValue(MMSpinBox1_maxit_Property);

		public object frmEst_state => ((CxvViewModel)this).GetValue(frmEst_state_Property);

		public object MMLBUText8_pest => ((CxvViewModel)this).GetValue(MMLBUText8_pest_Property);

		public object MMLBUText7_test => ((CxvViewModel)this).GetValue(MMLBUText7_test_Property);

		public object frmFlSpec_state => ((CxvViewModel)this).GetValue(frmFlSpec_state_Property);

		public object MMComboBox2_MultiMap => ((CxvViewModel)this).GetValue(MMComboBox2_MultiMap_Property);

		public object MMLBUText6_vfrac => ((CxvViewModel)this).GetValue(MMLBUText6_vfrac_Property);

		public object MMLBUText5_pres => ((CxvViewModel)this).GetValue(MMLBUText5_pres_Property);

		public object MMLBUText4_temp => ((CxvViewModel)this).GetValue(MMLBUText4_temp_Property);

		public object MMMenuButton1_target => ((CxvViewModel)this).GetValue(MMMenuButton1_target_Property);

		public object MMMenuButton1_flashstream => ((CxvViewModel)this).GetValue(MMMenuButton1_flashstream_Property);

		public object cboKode_MultiMap => ((CxvViewModel)this).GetValue(cboKode_MultiMap_Property);

		public MMACMModel_Blocko_SFlash_ViewModel()
		{
		}

		static MMACMModel_Blocko_SFlash_ViewModel()
		{
	MMComboBox2_MultiMap_Property = CxvPropertyDeclaration.Register("MMComboBox2_MultiMap", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "MMComboBox2_nphase",
				DataPath = "@main.Input.NPHASE.@choice"
			}, new CxvMultiMapVariable
			{
				Name = "MMComboBox2_phase",
				DataPath = "@main.Input.PHASE.@choice"
			}, new CxvMultiMapVariable
			{
				Name = "MMComboBox2_freewater",
				DataPath = "@main.Input.FREE_WATER.@choice"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Vapor-Only",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Vapor_Only",
				Value = "MMComboBox2_MultiMapOption_1",
				Prompt = "Only a vapor phase exists.",
				PromptResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Prompt_Only_a_vapor_phase_exists_",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox2_nphase",
				Value = "1"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_phase",
				Value = "V"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_freewater",
				Value = "NO"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Liquid-Only",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Liquid_Only",
				Value = "MMComboBox2_MultiMapOption_2",
				Prompt = "Only a single liquid phase exists.",
				PromptResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Prompt_Only_a_single_liquid_phase_exists_",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox2_nphase",
				Value = "1"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_phase",
				Value = "L"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_freewater",
				Value = "NO"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Solid-Only",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Solid_Only",
				Value = "MMComboBox2_MultiMapOption_3",
				Prompt = "Only pure salts (electrolytes) or solids exist.",
				PromptResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Prompt_Only_pure_salts__electrolytes__or_solid",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox2_nphase",
				Value = "1"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_phase",
				Value = "S"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_freewater",
				Value = "NO"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Vapor-Liquid",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid",
				Value = "MMComboBox2_MultiMapOption_4",
				Prompt = "2 phases (vapor and liquid) are considered in phase equilibrium calculations.",
				PromptResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Prompt_2_phases__vapor_and_liquid__are_conside",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox2_nphase",
				Value = "2"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_phase"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_freewater",
				Value = "NO"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Vapor-Liquid-Liquid",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_Liquid",
				Value = "MMComboBox2_MultiMapOption_5",
				Prompt = "3 phases (vapor and two liquid phases) are considered in phase equilibrium calculations.",
				PromptResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Prompt_3_phases__vapor_and_two_liquid_phases__",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox2_nphase",
				Value = "3"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_phase"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_freewater",
				Value = "NO"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Liquid-FreeWater",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Liquid_FreeWater",
				Value = "MMComboBox2_MultiMapOption_6",
				Prompt = "2 liquid phases (organic and pure water) are considered in phase equilibrium calculations.",
				PromptResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Prompt_2_liquid_phases__organic_and_pure_water",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox2_nphase",
				Value = "1"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_phase",
				Value = "L"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_freewater",
				Value = "YES"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Vapor-Liquid-FreeWater",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_FreeWater",
				Value = "MMComboBox2_MultiMapOption_7",
				Prompt = "3 liquid phases (vapor, organic and pure water) are considered in phase equilibrium calculations.",
				PromptResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Prompt_3_liquid_phases__vapor__organic_and_pur",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox2_nphase",
				Value = "2"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_phase"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_freewater",
				Value = "YES"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Liquid-DirtyWater",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Liquid_DirtyWater",
				Value = "MMComboBox2_MultiMapOption_8",
				Prompt = "2 liquid phases (organic and dirty water) are considered in phase equilibrium calculations.",
				PromptResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Prompt_2_liquid_phases__organic_and_dirty_wate",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox2_nphase",
				Value = "1"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_phase",
				Value = "L"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_freewater",
				Value = "DIRTY"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Vapor-Liquid-DirtyWater",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_DirtyWater",
				Value = "MMComboBox2_MultiMapOption_9",
				Prompt = "3 liquid phases (vapor, organic and dirty water) are considered in phase equilibrium calculations.",
				PromptResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Prompt_3_liquid_phases__vapor__organic_and_dir",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMComboBox2_nphase",
				Value = "2"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_phase"
			}, new CxvMultiMapValue
			{
				Variable = "MMComboBox2_freewater",
				Value = "DIRTY"
			} }
				} }
});
	MMLBUText6_vfrac_Property = CxvPropertyDeclaration.Register("MMLBUText6_vfrac", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.VFRAC.@choice",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.VAPFR.@choice"
				}
			});
	MMLBUText5_pres_Property = CxvPropertyDeclaration.Register("MMLBUText5_pres", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.PRES.@choice",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.PRESS.@choice"
				}
			});
	MMLBUText4_temp_Property = CxvPropertyDeclaration.Register("MMLBUText4_temp", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.TEMP.@choice",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.TEMPR.@choice"
				}
			});
	MMMenuButton1_target_Property = CxvPropertyDeclaration.Register("MMMenuButton1_target", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "choice"
			});
	MMMenuButton1_flashstream_Property = CxvPropertyDeclaration.Register("MMMenuButton1_flashstream", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvAdvCollectionProperty
			{
				DataPath = "@main.Input.NPHASE",
				SelectedItemBinding = "MMMenuButton1_target.Value",
				CreateNewPrompt = "Stream:",
				CreateNewPromptResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvAdvCollectionProperty_CreateNewPrompt_Stream_",
				CompletePaths = { "FLSP" }
			});
	cboKode_MultiMap_Property = CxvPropertyDeclaration.Register("cboKode_MultiMap", typeof(MMACMModel_Blocko_SFlash_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboKode_kode",
				DataPath = "@main.Input.KODE.@choice"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Temperature & pressure",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Temperature___pressure",
				Value = "cboKode_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboKode_kode",
				Value = "TP"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Temperature & vapor fraction",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Temperature___vapor_fraction",
				Value = "cboKode_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboKode_kode",
				Value = "TV"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Temperature & enthalpy",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Temperature___enthalpy",
				Value = "cboKode_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboKode_kode",
				Value = "TH"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Pressure & vapor fraction",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Pressure___vapor_fraction",
				Value = "cboKode_MultiMapOption_4",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboKode_kode",
				Value = "PV"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Pressure & enthalpy",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Pressure___enthalpy",
				Value = "cboKode_MultiMapOption_5",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboKode_kode",
				Value = "PH"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Do not flash stream",
				DisplayResourceKey = "MMACMModel_Blocko_SFlash_ViewModel__CxvMultiMapOption_Display_Do_not_flash_stream",
				Value = "cboKode_MultiMapOption_6",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboKode_kode",
				Value = "NOFLASH"
			} }
				} },
	IsEnabledCondition = new CxvLogicalTest
			{
				Parameter = "choice",
				Operator = (CxvLogicalOperator)11
			}
});
	}
	}
	[ProgId("MMACMModel.MMACMModel_Blocko_SFlash")]
	public class MMACMModel_Blocko_SFlash : MMTabPage, IComponentConnector
	{
		internal MMLabel MMMenuButton1_label;

		internal MMAdvancedComboEdit MMMenuButton1;

		internal MMLabel cboKode_label;

		internal MMComboEdit cboKode;

		internal MMGroupBox frmFlSpec;

		internal MMLabel MMLBUText4_label;

		internal MMVariableEdit MMLBUText4;

		internal MMLabel MMLBUText5_label;

		internal MMVariableEdit MMLBUText5;

		internal MMLabel MMLBUText6_label;

		internal MMVariableEdit MMLBUText6;

		internal MMLabel MMLabel1;

		internal MMComboEdit MMComboBox2;

		internal MMGroupBox frmEst;

		internal MMLabel MMLBUText7_label;

		internal MMVariableEdit MMLBUText7;

		internal MMLabel MMLBUText8_label;

		internal MMVariableEdit MMLBUText8;

		internal MMGroupBox MMFrame3;

		internal MMLabel MMSpinBox1_label;

		internal MMSpinBox MMSpinBox1;

		internal MMLabel MMLBUText9_label;

		internal MMVariableEdit MMLBUText9;

		private bool _contentLoaded;

		public MMACMModel_Blocko_SFlash()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMACMModel_Blocko_SFlash_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_blocko_sflash.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_006b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0075: Expected O, but got Unknown
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			//IL_0082: Expected O, but got Unknown
			//IL_0085: Unknown result type (might be due to invalid IL or missing references)
			//IL_008f: Expected O, but got Unknown
			//IL_0092: Unknown result type (might be due to invalid IL or missing references)
			//IL_009c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b6: Expected O, but got Unknown
			//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c3: Expected O, but got Unknown
			//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d0: Expected O, but got Unknown
			//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00dd: Expected O, but got Unknown
			//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ea: Expected O, but got Unknown
			//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f7: Expected O, but got Unknown
			//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
			//IL_0104: Expected O, but got Unknown
			//IL_0107: Unknown result type (might be due to invalid IL or missing references)
			//IL_0111: Expected O, but got Unknown
			//IL_0114: Unknown result type (might be due to invalid IL or missing references)
			//IL_011e: Expected O, but got Unknown
			//IL_0121: Unknown result type (might be due to invalid IL or missing references)
			//IL_012b: Expected O, but got Unknown
			//IL_012e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0138: Expected O, but got Unknown
			//IL_013b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0145: Expected O, but got Unknown
			//IL_0148: Unknown result type (might be due to invalid IL or missing references)
			//IL_0152: Expected O, but got Unknown
			//IL_0155: Unknown result type (might be due to invalid IL or missing references)
			//IL_015f: Expected O, but got Unknown
			//IL_0162: Unknown result type (might be due to invalid IL or missing references)
			//IL_016c: Expected O, but got Unknown
			//IL_016f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0179: Expected O, but got Unknown
			//IL_017c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0186: Expected O, but got Unknown
			//IL_0189: Unknown result type (might be due to invalid IL or missing references)
			//IL_0193: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMMenuButton1_label = (MMLabel)target;
				break;
			case 2:
				MMMenuButton1 = (MMAdvancedComboEdit)target;
				break;
			case 3:
				cboKode_label = (MMLabel)target;
				break;
			case 4:
				cboKode = (MMComboEdit)target;
				break;
			case 5:
				frmFlSpec = (MMGroupBox)target;
				break;
			case 6:
				MMLBUText4_label = (MMLabel)target;
				break;
			case 7:
				MMLBUText4 = (MMVariableEdit)target;
				break;
			case 8:
				MMLBUText5_label = (MMLabel)target;
				break;
			case 9:
				MMLBUText5 = (MMVariableEdit)target;
				break;
			case 10:
				MMLBUText6_label = (MMLabel)target;
				break;
			case 11:
				MMLBUText6 = (MMVariableEdit)target;
				break;
			case 12:
				MMLabel1 = (MMLabel)target;
				break;
			case 13:
				MMComboBox2 = (MMComboEdit)target;
				break;
			case 14:
				frmEst = (MMGroupBox)target;
				break;
			case 15:
				MMLBUText7_label = (MMLabel)target;
				break;
			case 16:
				MMLBUText7 = (MMVariableEdit)target;
				break;
			case 17:
				MMLBUText8_label = (MMLabel)target;
				break;
			case 18:
				MMLBUText8 = (MMVariableEdit)target;
				break;
			case 19:
				MMFrame3 = (MMGroupBox)target;
				break;
			case 20:
				MMSpinBox1_label = (MMLabel)target;
				break;
			case 21:
				MMSpinBox1 = (MMSpinBox)target;
				break;
			case 22:
				MMLBUText9_label = (MMLabel)target;
				break;
			case 23:
				MMLBUText9 = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMACMModel_Blocko_SimOptions_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMComboAEMethod1_AEMETHOD_Property = CxvPropertyDeclaration.Register("MMComboAEMethod1_AEMETHOD", typeof(MMACMModel_Blocko_SimOptions_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.AE_METHOD"
		});

		public static readonly CxvPropertyDeclaration MMCheckBox4_Inter_Property = CxvPropertyDeclaration.Register("MMCheckBox4_Inter", typeof(MMACMModel_Blocko_SimOptions_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
		{
			DataPath = "@main.Input.INTER",
			TrueValue = "YES",
			FalseValue = "NO",
			DefaultValue = false
		});

		public static readonly CxvPropertyDeclaration _MMCheckBox2_user_bypass_Property = CxvPropertyDeclaration.Register("_MMCheckBox2_user_bypass", typeof(MMACMModel_Blocko_SimOptions_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
		{
			DataPath = "@main.Input.USER_BYPASS",
			TrueValue = "YES",
			FalseValue = "NO",
			DefaultValue = true
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMACMModel_Blocko_SimOptions_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.MODEL",
			IsCalculated = false,
			IsReadOnly = true
		});

		public static readonly CxvPropertyDeclaration MMComboReportVarQuery_RESQUERY_Property = CxvPropertyDeclaration.Register("MMComboReportVarQuery_RESQUERY", typeof(MMACMModel_Blocko_SimOptions_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.RES_QUERY_ID"
		});

		public static readonly CxvPropertyDeclaration MMCheckBox3_flashfeeds_Property = CxvPropertyDeclaration.Register("MMCheckBox3_flashfeeds", typeof(MMACMModel_Blocko_SimOptions_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
		{
			DataPath = "@main.Input.FLASH_FEEDS",
			TrueValue = "YES",
			FalseValue = "NO",
			DefaultValue = false
		});

		public static readonly CxvPropertyDeclaration MMCheckBox1_var1_Property = CxvPropertyDeclaration.Register("MMCheckBox1_var1", typeof(MMACMModel_Blocko_SimOptions_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
		{
			DataPath = "@main.Input.ENERGY_BAL",
			TrueValue = "YES",
			FalseValue = "NO"
		});

		public object MMComboAEMethod1_AEMETHOD => ((CxvViewModel)this).GetValue(MMComboAEMethod1_AEMETHOD_Property);

		public object MMCheckBox4_Inter => ((CxvViewModel)this).GetValue(MMCheckBox4_Inter_Property);

		public object _MMCheckBox2_user_bypass => ((CxvViewModel)this).GetValue(_MMCheckBox2_user_bypass_Property);

		public object MMLBUText1_var1 => ((CxvViewModel)this).GetValue(MMLBUText1_var1_Property);

		public object MMComboReportVarQuery_RESQUERY => ((CxvViewModel)this).GetValue(MMComboReportVarQuery_RESQUERY_Property);

		public object MMCheckBox3_flashfeeds => ((CxvViewModel)this).GetValue(MMCheckBox3_flashfeeds_Property);

		public object MMCheckBox1_var1 => ((CxvViewModel)this).GetValue(MMCheckBox1_var1_Property);
	}
	[ProgId("MMACMModel.MMACMModel_Blocko_SimOptions")]
	public class MMACMModel_Blocko_SimOptions : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMCheckBox MMCheckBox3;

		internal MMCheckBox MMCheckBox1;

		internal MMCheckBox MMCheckBox2;

		internal MMCheckBox MMCheckBox4;

		internal MMLabel MMComboAEMethod1_label;

		internal MMComboEdit MMComboAEMethod1;

		internal MMLabel MMComboReportVarQuery_label;

		internal MMComboEdit MMComboReportVarQuery;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		private bool _contentLoaded;

		public MMACMModel_Blocko_SimOptions()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMACMModel_Blocko_SimOptions_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_blocko_simoptions.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0055: Unknown result type (might be due to invalid IL or missing references)
			//IL_005f: Expected O, but got Unknown
			//IL_0062: Unknown result type (might be due to invalid IL or missing references)
			//IL_006c: Expected O, but got Unknown
			//IL_006f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0079: Expected O, but got Unknown
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0086: Expected O, but got Unknown
			//IL_0089: Unknown result type (might be due to invalid IL or missing references)
			//IL_0093: Expected O, but got Unknown
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a0: Expected O, but got Unknown
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ad: Expected O, but got Unknown
			//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ba: Expected O, but got Unknown
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c7: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				MMCheckBox3 = (MMCheckBox)target;
				break;
			case 3:
				MMCheckBox1 = (MMCheckBox)target;
				break;
			case 4:
				MMCheckBox2 = (MMCheckBox)target;
				break;
			case 5:
				MMCheckBox4 = (MMCheckBox)target;
				break;
			case 6:
				MMComboAEMethod1_label = (MMLabel)target;
				break;
			case 7:
				MMComboAEMethod1 = (MMComboEdit)target;
				break;
			case 8:
				MMComboReportVarQuery_label = (MMLabel)target;
				break;
			case 9:
				MMComboReportVarQuery = (MMComboEdit)target;
				break;
			case 10:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 11:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	internal class DyanmicAxHost : AxHost
	{
		public DyanmicAxHost(string clsid)
			: base(clsid)
		{
		}
	}
	internal class MMACMModel_Custom_ViewModel : MMTabPageViewModel
	{
		private System.Windows.Forms.Control customWinForm;

		private FrameworkElement customWPFForm;

		private AxHost ocxHost;

		private object ocxObject;

		private Type controlType;

		private object _mvarControlContext;

		protected override void OnViewChanged()
		{
			string text = ((CxvViewModel)this).ResolveParameter("Progid") as string;
			string text2 = ((CxvViewModel)this).ResolveParameter("Clsid") as string;
			bool flag = false;
			if (!string.IsNullOrEmpty(text2))
			{
				string keyName = "HKEY_CLASSES_ROOT\\CLSID\\" + text2 + "\\InprocServer32";
				if (Registry.GetValue(keyName, "", null) is string)
				{
					if (Registry.GetValue(keyName, "Assembly", null) is string assemblyString)
					{
						Assembly assembly = null;
						flag = true;
						string text3 = Registry.GetValue(keyName, "CodeBase", null) as string;
						string text4 = Registry.GetValue(keyName, "Class", null) as string;
						try
						{
							if (text3 != null)
							{
								if (text3.StartsWith("file:"))
								{
									text3 = text3.Substring(5);
								}
								assembly = Assembly.LoadFrom(text3);
							}
							else
							{
								assembly = Assembly.Load(assemblyString);
							}
						}
						catch (Exception)
						{
						}
						if (assembly != null)
						{
							controlType = assembly.GetType(string.IsNullOrEmpty(text4) ? text : text4);
						}
						if (controlType != null && controlType.IsSubclassOf(typeof(FrameworkElement)))
						{
							try
							{
								object obj = Activator.CreateInstance(controlType);
								customWPFForm = obj as FrameworkElement;
								object view = ((MMViewModel)this).View;
								(view as MMTabPage).Content = customWPFForm;
							}
							catch (Exception)
							{
							}
						}
						else if (controlType != null && controlType.IsSubclassOf(typeof(System.Windows.Forms.Control)))
						{
							try
							{
								object obj2 = Activator.CreateInstance(controlType);
								customWinForm = obj2 as System.Windows.Forms.Control;
								(((MMViewModel)this).View as MMACMModel_Custom).formHost.Child = customWinForm;
							}
							catch (Exception)
							{
							}
						}
					}
					else
					{
						flag = true;
						try
						{
							controlType = Type.GetTypeFromProgID(text, throwOnError: true);
							ocxHost = new DyanmicAxHost(text2);
							(((MMViewModel)this).View as MMACMModel_Custom).formHost.Child = ocxHost;
							ocxHost.CreateControl();
							ocxObject = ocxHost.GetOcx();
						}
						catch (Exception)
						{
						}
					}
				}
			}
			_ = flag;
			if (controlType == null)
			{
				string text5 = "";
				if (flag)
				{
					text5 = Resources.MMACMModel_Custom_LoadError;
				}
				else
				{
					text5 = Resources.MMACMModel_Custom_FindError;
				}
				object view2 = ((MMViewModel)this).View;
				(view2 as MMTabPage).Content = string.Format(text5, text);
				object view3 = ((MMViewModel)this).View;
				(view3 as MMTabPage).FontSize += 2.0;
			}
			else
			{
				ControlContext = ((CxvViewModel)this).ExpandDataPathAndGet("@main.Data", "value");
				((CxvViewModel)this).ResolvedCxsProvider.Case.Message += Case_Message;
			}
			base.OnViewChanged();
		}

		private void Case_Message(object sender, CxsMessageEventArgs e)
		{
		}

		public override void Unload()
		{
			((CxvViewModel)this).ResolvedCxsProvider.Case.Message -= Case_Message;
			ControlContext = null;
			base.Unload();
		}

		public object ControlContext
		{
			get
			{
				return _mvarControlContext;
			}
			set
			{
				if (_mvarControlContext != value)
				{
					_mvarControlContext = value;
					if (controlType != null)
					{
						try
						{
							if (customWinForm != null)
							{
								controlType.InvokeMember("ControlContext", BindingFlags.SetProperty, null, customWinForm, new object[1] { _mvarControlContext });
							}
							else if (customWPFForm != null)
							{
								controlType.InvokeMember("ControlContext", BindingFlags.SetProperty, null, customWPFForm, new object[1] { _mvarControlContext });
							}
							else if (ocxObject != null)
							{
								controlType.InvokeMember("ControlContext", BindingFlags.SetProperty, null, ocxObject, new object[1] { _mvarControlContext });
							}
						}
						catch (Exception)
						{
						}
					}
				}
			}
		}

	}
	[ProgId("MMACMModel.MMACMModel_Custom")]
	public class MMACMModel_Custom : MMTabPage, IComponentConnector
	{
		internal WindowsFormsHost formHost;

		private bool _contentLoaded;

		public MMACMModel_Custom()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMACMModel_Custom_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_custom.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				formHost = (WindowsFormsHost)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMACMModel_Sparse_Basic_ViewModel : MMTabPageViewModel
	{
		private ICommand _CmdReset_Command;

		public static readonly CxvPropertyDeclaration SparseSolverMethod_Property;

		public static readonly CxvPropertyDeclaration ConvergenceCriterion_Property;

		public static readonly CxvPropertyDeclaration DivSteps_Property;

		public static readonly CxvPropertyDeclaration StepReductions_Property;

		public static readonly CxvPropertyDeclaration MaxIterations_Property;

		public static readonly CxvPropertyDeclaration MaxFastNewtonSteps_Property;

		public static readonly CxvPropertyDeclaration CreepIterations_Property;

		public static readonly CxvPropertyDeclaration CreepSize_Property;

		public static readonly CxvPropertyDeclaration DoglegMethod_Property;

		public static readonly CxvPropertyDeclaration BestPoint_Property;

		public static readonly CxvPropertyDeclaration MaxRange_Property;

		public static readonly CxvPropertyDeclaration MaxApproach_Property;

		public static readonly CxvPropertyDeclaration AbsolutePerturbation_Property;

		public static readonly CxvPropertyDeclaration SingularityPerturbation_Property;

		public static readonly CxvPropertyDeclaration VariableStep_Property;

		public static readonly CxvPropertyDeclaration ClipFactor_Property;

		public static readonly CxvPropertyDeclaration HighestVariableSteps_Property;

		public static readonly CxvPropertyDeclaration HighestResiduals_Property;

		public static readonly CxvPropertyDeclaration PrintLinearAlgebra_Property;

		public ICommand CmdReset_Command
		{
			get
			{
				if (_CmdReset_Command == null)
				{
					_CmdReset_Command = (ICommand)new CxvDelegateCommand<object>((Action<object>)CmdReset_CommandExecute);
				}
				return _CmdReset_Command;
			}
		}

		private void CmdReset_CommandExecute(object parameter)
		{
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("AbsolutePerturbation.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("BestPoint.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("ClipFactor.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("ConvergenceCriterion.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("CreepIterations.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("CreepSize.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("DivergenceSteps.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("DoglegMethod.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("HighestResiduals.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("HighestVariableSteps.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("MaxApproach.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("MaxFastNewtonSteps.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("MaxIterations.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("MaxRange.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("PrintLinearAlgebra.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("SingularityPerturbation.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("SparseSolverMethod.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("StepReductions.Value", (object)null);
			((CxvViewModel)this).ResolveUpdateViewPropertyPath("VariableStep.Value", (object)null);
		}

		public object SparseSolverMethod => ((CxvViewModel)this).GetValue(SparseSolverMethod_Property);

		public object ConvergenceCriterion => ((CxvViewModel)this).GetValue(ConvergenceCriterion_Property);

		public object DivergenceSteps => ((CxvViewModel)this).GetValue(DivSteps_Property);

		public object StepReductions => ((CxvViewModel)this).GetValue(StepReductions_Property);

		public object MaxIterations => ((CxvViewModel)this).GetValue(MaxIterations_Property);

		public object MaxFastNewtonSteps => ((CxvViewModel)this).GetValue(MaxFastNewtonSteps_Property);

		public object CreepIterations => ((CxvViewModel)this).GetValue(CreepIterations_Property);

		public object CreepSize => ((CxvViewModel)this).GetValue(CreepSize_Property);

		public object DoglegMethod => ((CxvViewModel)this).GetValue(DoglegMethod_Property);

		public object BestPoint => ((CxvViewModel)this).GetValue(BestPoint_Property);

		public object MaxRange => ((CxvViewModel)this).GetValue(MaxRange_Property);

		public object MaxApproach => ((CxvViewModel)this).GetValue(MaxApproach_Property);

		public object AbsolutePerturbation => ((CxvViewModel)this).GetValue(AbsolutePerturbation_Property);

		public object SingularityPerturbation => ((CxvViewModel)this).GetValue(SingularityPerturbation_Property);

		public object VariableStep => ((CxvViewModel)this).GetValue(VariableStep_Property);

		public object ClipFactor => ((CxvViewModel)this).GetValue(ClipFactor_Property);

		public object HighestVariableSteps => ((CxvViewModel)this).GetValue(HighestVariableSteps_Property);

		public object HighestResiduals => ((CxvViewModel)this).GetValue(HighestResiduals_Property);

		public object PrintLinearAlgebra => ((CxvViewModel)this).GetValue(PrintLinearAlgebra_Property);

		public MMACMModel_Sparse_Basic_ViewModel()
		{
		}

		static MMACMModel_Sparse_Basic_ViewModel()
		{
	SparseSolverMethod_Property = CxvPropertyDeclaration.Register("SparseSolverMethod", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "SparseSolverMethod",
				DataPath = "@main.Input.SPRSMETHOD"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Hybrid",
				Value = "SparseSolverMethodOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "SparseSolverMethod",
				Value = "HYBRID"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Newton",
				Value = "SparseSolverMethodOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "SparseSolverMethod",
				Value = "NEWTON"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Fast Newton",
				Value = "SparseSolverMethodOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "SparseSolverMethod",
				Value = "FASTNEWTON"
			} }
				} }
});
	ConvergenceCriterion_Property = CxvPropertyDeclaration.Register("ConvergenceCriterion", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "ConvergenceCriterion",
				DataPath = "@main.Input.SPRSCONVERGE"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Residual",
				Value = "ConvergenceCriterionOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "ConvergenceCriterion",
				Value = "RESIDUAL"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Variable",
				Value = "ConvergenceCriterionOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "ConvergenceCriterion",
				Value = "VARIABLE"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Residual and Variable",
				Value = "ConvergenceCriterionOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "ConvergenceCriterion",
				Value = "RESIDUALANDV"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Residual or Variable",
				Value = "ConvergenceCriterionOption_4",
					Values = { new CxvMultiMapValue
			{
				Variable = "ConvergenceCriterion",
				Value = "RESIDUALORV"
			} }
				} }
});
	DivSteps_Property = CxvPropertyDeclaration.Register("DivergenceSteps", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSDIVERGE"
			});
	StepReductions_Property = CxvPropertyDeclaration.Register("StepReductions", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSREDUCTN"
			});
	MaxIterations_Property = CxvPropertyDeclaration.Register("MaxIterations", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSMAXITER"
			});
	MaxFastNewtonSteps_Property = CxvPropertyDeclaration.Register("MaxFastNewtonSteps", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSFASTNWTN",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.FASTN"
				}
			});
	CreepIterations_Property = CxvPropertyDeclaration.Register("CreepIterations", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSCRPITER"
			});
	CreepSize_Property = CxvPropertyDeclaration.Register("CreepSize", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSCRPSIZE"
			});
	DoglegMethod_Property = CxvPropertyDeclaration.Register("DoglegMethod", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
			{
				DataPath = "@main.Input.SPRSDOGLEG",
				TrueValue = "YES",
				FalseValue = "NO",
				DefaultValue = false
			});
	BestPoint_Property = CxvPropertyDeclaration.Register("BestPoint", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
			{
				DataPath = "@main.Input.SPRSBESTPT",
				TrueValue = "YES",
				FalseValue = "NO",
				DefaultValue = true
			});
	MaxRange_Property = CxvPropertyDeclaration.Register("MaxRange", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSMAXRANGE"
			});
	MaxApproach_Property = CxvPropertyDeclaration.Register("MaxApproach", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSMAXAPPR"
			});
	AbsolutePerturbation_Property = CxvPropertyDeclaration.Register("AbsolutePerturbation", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSABSPERT"
			});
	SingularityPerturbation_Property = CxvPropertyDeclaration.Register("SingularityPerturbation", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSSNGPERT"
			});
	VariableStep_Property = CxvPropertyDeclaration.Register("VariableStep", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSVARSTEP"
			});
	ClipFactor_Property = CxvPropertyDeclaration.Register("ClipFactor", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSCLIPFCTR"
			});
	HighestVariableSteps_Property = CxvPropertyDeclaration.Register("HighestVariableSteps", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSHIGHVAR"
			});
	HighestResiduals_Property = CxvPropertyDeclaration.Register("HighestResiduals", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSHIGHRES"
			});
	PrintLinearAlgebra_Property = CxvPropertyDeclaration.Register("PrintLinearAlgebra", typeof(MMACMModel_Sparse_Basic_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.SPRSPRINT"
			});
	}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_Sparse_Basic")]
	public class MMACMModel_SolverOptions_Sparse_Basic : MMTabPage, IComponentConnector
	{
		internal MMCmdButton CmdReset;

		internal MMGroupBox frmConv;

		internal MMLabel MethodComboBox1_label;

		internal MMComboEdit MethodComboBox;

		internal MMLabel ConvergenceComboBox1_label;

		internal MMComboEdit ConvergenceComboBox;

		internal MMLabel Divergence_label;

		internal MMVariableEdit DivergenceText;

		internal MMLabel StepReductions_label;

		internal MMVariableEdit StepReductionsText;

		internal MMLabel MaxIterations_label;

		internal MMVariableEdit MaxIterationsText;

		internal MMLabel MaxFastNewton_label;

		internal MMVariableEdit MaxFastNewtonText;

		internal MMLabel CreepIterations_label;

		internal MMVariableEdit CreepIterationsText;

		internal MMLabel CreepSize_label;

		internal MMVariableEdit CreepSizeText;

		internal MMCheckBox DoglegCheckBox_1;

		internal MMCheckBox BestPointCheckBox_1;

		internal MMGroupBox frmIter;

		internal MMLabel MaxRange_label;

		internal MMVariableEdit MaxRangeText;

		internal MMLabel ApproachBound_label;

		internal MMVariableEdit ApproachBoundText;

		internal MMLabel AbsolutePerturbation_label;

		internal MMVariableEdit AbsolutePerturbationText;

		internal MMLabel SingularityPerturbation_label;

		internal MMVariableEdit SingularityPerturbationText;

		internal MMLabel MaxVariableStep_label;

		internal MMVariableEdit MaxVariableStepText;

		internal MMLabel ClipFactor_label;

		internal MMVariableEdit ClipFactorText;

		internal MMGroupBox frmNewton;

		internal MMLabel HighestVariable_label;

		internal MMVariableEdit HighestVariableText;

		internal MMLabel HighestResiduals_label;

		internal MMVariableEdit HighestResidualsText;

		internal MMLabel PrintLinear_label;

		internal MMVariableEdit PrintLinearText;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_Sparse_Basic()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMACMModel_Sparse_Basic_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_sparse_basic.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_00af: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d3: Expected O, but got Unknown
			//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e0: Expected O, but got Unknown
			//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ed: Expected O, but got Unknown
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fa: Expected O, but got Unknown
			//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0107: Expected O, but got Unknown
			//IL_010a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0114: Expected O, but got Unknown
			//IL_0117: Unknown result type (might be due to invalid IL or missing references)
			//IL_0121: Expected O, but got Unknown
			//IL_0124: Unknown result type (might be due to invalid IL or missing references)
			//IL_012e: Expected O, but got Unknown
			//IL_0131: Unknown result type (might be due to invalid IL or missing references)
			//IL_013b: Expected O, but got Unknown
			//IL_013e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0148: Expected O, but got Unknown
			//IL_014b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0155: Expected O, but got Unknown
			//IL_0158: Unknown result type (might be due to invalid IL or missing references)
			//IL_0162: Expected O, but got Unknown
			//IL_0165: Unknown result type (might be due to invalid IL or missing references)
			//IL_016f: Expected O, but got Unknown
			//IL_0172: Unknown result type (might be due to invalid IL or missing references)
			//IL_017c: Expected O, but got Unknown
			//IL_017f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0189: Expected O, but got Unknown
			//IL_018c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0196: Expected O, but got Unknown
			//IL_0199: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a3: Expected O, but got Unknown
			//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b0: Expected O, but got Unknown
			//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
			//IL_01bd: Expected O, but got Unknown
			//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ca: Expected O, but got Unknown
			//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d7: Expected O, but got Unknown
			//IL_01da: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e4: Expected O, but got Unknown
			//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f1: Expected O, but got Unknown
			//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_01fe: Expected O, but got Unknown
			//IL_0201: Unknown result type (might be due to invalid IL or missing references)
			//IL_020b: Expected O, but got Unknown
			//IL_020e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0218: Expected O, but got Unknown
			//IL_021b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0225: Expected O, but got Unknown
			//IL_0228: Unknown result type (might be due to invalid IL or missing references)
			//IL_0232: Expected O, but got Unknown
			//IL_0235: Unknown result type (might be due to invalid IL or missing references)
			//IL_023f: Expected O, but got Unknown
			//IL_0242: Unknown result type (might be due to invalid IL or missing references)
			//IL_024c: Expected O, but got Unknown
			//IL_024f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0259: Expected O, but got Unknown
			//IL_025c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0266: Expected O, but got Unknown
			//IL_0269: Unknown result type (might be due to invalid IL or missing references)
			//IL_0273: Expected O, but got Unknown
			//IL_0276: Unknown result type (might be due to invalid IL or missing references)
			//IL_0280: Expected O, but got Unknown
			//IL_0283: Unknown result type (might be due to invalid IL or missing references)
			//IL_028d: Expected O, but got Unknown
			//IL_0290: Unknown result type (might be due to invalid IL or missing references)
			//IL_029a: Expected O, but got Unknown
			//IL_029d: Unknown result type (might be due to invalid IL or missing references)
			//IL_02a7: Expected O, but got Unknown
			//IL_02aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_02b4: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				CmdReset = (MMCmdButton)target;
				break;
			case 2:
				frmConv = (MMGroupBox)target;
				break;
			case 3:
				MethodComboBox1_label = (MMLabel)target;
				break;
			case 4:
				MethodComboBox = (MMComboEdit)target;
				break;
			case 5:
				ConvergenceComboBox1_label = (MMLabel)target;
				break;
			case 6:
				ConvergenceComboBox = (MMComboEdit)target;
				break;
			case 7:
				Divergence_label = (MMLabel)target;
				break;
			case 8:
				DivergenceText = (MMVariableEdit)target;
				break;
			case 9:
				StepReductions_label = (MMLabel)target;
				break;
			case 10:
				StepReductionsText = (MMVariableEdit)target;
				break;
			case 11:
				MaxIterations_label = (MMLabel)target;
				break;
			case 12:
				MaxIterationsText = (MMVariableEdit)target;
				break;
			case 13:
				MaxFastNewton_label = (MMLabel)target;
				break;
			case 14:
				MaxFastNewtonText = (MMVariableEdit)target;
				break;
			case 15:
				CreepIterations_label = (MMLabel)target;
				break;
			case 16:
				CreepIterationsText = (MMVariableEdit)target;
				break;
			case 17:
				CreepSize_label = (MMLabel)target;
				break;
			case 18:
				CreepSizeText = (MMVariableEdit)target;
				break;
			case 19:
				DoglegCheckBox_1 = (MMCheckBox)target;
				break;
			case 20:
				BestPointCheckBox_1 = (MMCheckBox)target;
				break;
			case 21:
				frmIter = (MMGroupBox)target;
				break;
			case 22:
				MaxRange_label = (MMLabel)target;
				break;
			case 23:
				MaxRangeText = (MMVariableEdit)target;
				break;
			case 24:
				ApproachBound_label = (MMLabel)target;
				break;
			case 25:
				ApproachBoundText = (MMVariableEdit)target;
				break;
			case 26:
				AbsolutePerturbation_label = (MMLabel)target;
				break;
			case 27:
				AbsolutePerturbationText = (MMVariableEdit)target;
				break;
			case 28:
				SingularityPerturbation_label = (MMLabel)target;
				break;
			case 29:
				SingularityPerturbationText = (MMVariableEdit)target;
				break;
			case 30:
				MaxVariableStep_label = (MMLabel)target;
				break;
			case 31:
				MaxVariableStepText = (MMVariableEdit)target;
				break;
			case 32:
				ClipFactor_label = (MMLabel)target;
				break;
			case 33:
				ClipFactorText = (MMVariableEdit)target;
				break;
			case 34:
				frmNewton = (MMGroupBox)target;
				break;
			case 35:
				HighestVariable_label = (MMLabel)target;
				break;
			case 36:
				HighestVariableText = (MMVariableEdit)target;
				break;
			case 37:
				HighestResiduals_label = (MMLabel)target;
				break;
			case 38:
				HighestResidualsText = (MMVariableEdit)target;
				break;
			case 39:
				PrintLinear_label = (MMLabel)target;
				break;
			case 40:
				PrintLinearText = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_DMOBas_Basic")]
	public class MMACMModel_SolverOptions_DMOBas_Basic : MMTabPage, IComponentConnector
	{
		internal MMLabel MMLabel1;

		internal MMAdvancedComboEdit MMAdvCombo1;

		internal MMCmdButton CmdReset;

		internal MMGroupBox frmConv;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMLabel MMLBUText3_label;

		internal MMVariableEdit MMLBUText3;

		internal MMGroupBox frmIter;

		internal MMLabel MMSpinBox1_label;

		internal MMSpinBox MMSpinBox1;

		internal MMLabel MMSpinBox4_label;

		internal MMSpinBox MMSpinBox4;

		internal MMGroupBox frmNewton;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMLabel MMSpinBox3_label;

		internal MMSpinBox MMSpinBox3;

		internal MMLabel lbtuStep_label;

		internal MMVariableEdit lbtuStep;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_DMOBas_Basic()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMEOConv_DMOBas_Basic_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_dmobas_basic.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_005f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Expected O, but got Unknown
			//IL_006c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0076: Expected O, but got Unknown
			//IL_0079: Unknown result type (might be due to invalid IL or missing references)
			//IL_0083: Expected O, but got Unknown
			//IL_0086: Unknown result type (might be due to invalid IL or missing references)
			//IL_0090: Expected O, but got Unknown
			//IL_0093: Unknown result type (might be due to invalid IL or missing references)
			//IL_009d: Expected O, but got Unknown
			//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00aa: Expected O, but got Unknown
			//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b7: Expected O, but got Unknown
			//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c4: Expected O, but got Unknown
			//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d1: Expected O, but got Unknown
			//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00de: Expected O, but got Unknown
			//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00eb: Expected O, but got Unknown
			//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f8: Expected O, but got Unknown
			//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0105: Expected O, but got Unknown
			//IL_0108: Unknown result type (might be due to invalid IL or missing references)
			//IL_0112: Expected O, but got Unknown
			//IL_0115: Unknown result type (might be due to invalid IL or missing references)
			//IL_011f: Expected O, but got Unknown
			//IL_0122: Unknown result type (might be due to invalid IL or missing references)
			//IL_012c: Expected O, but got Unknown
			//IL_012f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0139: Expected O, but got Unknown
			//IL_013c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0146: Expected O, but got Unknown
			//IL_0149: Unknown result type (might be due to invalid IL or missing references)
			//IL_0153: Expected O, but got Unknown
			//IL_0156: Unknown result type (might be due to invalid IL or missing references)
			//IL_0160: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMLabel1 = (MMLabel)target;
				break;
			case 2:
				MMAdvCombo1 = (MMAdvancedComboEdit)target;
				break;
			case 3:
				CmdReset = (MMCmdButton)target;
				break;
			case 4:
				frmConv = (MMGroupBox)target;
				break;
			case 5:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 6:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 7:
				MMLBUText3_label = (MMLabel)target;
				break;
			case 8:
				MMLBUText3 = (MMVariableEdit)target;
				break;
			case 9:
				frmIter = (MMGroupBox)target;
				break;
			case 10:
				MMSpinBox1_label = (MMLabel)target;
				break;
			case 11:
				MMSpinBox1 = (MMSpinBox)target;
				break;
			case 12:
				MMSpinBox4_label = (MMLabel)target;
				break;
			case 13:
				MMSpinBox4 = (MMSpinBox)target;
				break;
			case 14:
				frmNewton = (MMGroupBox)target;
				break;
			case 15:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 16:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 17:
				MMSpinBox3_label = (MMLabel)target;
				break;
			case 18:
				MMSpinBox3 = (MMSpinBox)target;
				break;
			case 19:
				lbtuStep_label = (MMLabel)target;
				break;
			case 20:
				lbtuStep = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_DMOBas")]
	public class MMACMModel_SolverOptions_DMOBas : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMSSTab1;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_DMOBas()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMEOConv_DMOBas_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_dmobas.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMSSTab1 = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_DMOBas_Report")]
	public class MMACMModel_SolverOptions_DMOBas_Report : MMTabPage, IComponentConnector
	{
		internal MMLabel MMLabel1;

		internal MMAdvancedComboEdit MMAdvCombo1;

		internal MMCmdButton CmdReset;

		internal MMGroupBox frmHess;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMLabel MMSpinBox1_label;

		internal MMSpinBox MMSpinBox1;

		internal MMLabel MMComboBox2_label;

		internal MMComboEdit MMComboBox2;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_DMOBas_Report()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMEOConv_DMOBas_Report_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_dmobas_report.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Expected O, but got Unknown
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Expected O, but got Unknown
			//IL_0051: Unknown result type (might be due to invalid IL or missing references)
			//IL_005b: Expected O, but got Unknown
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0068: Expected O, but got Unknown
			//IL_006b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0075: Expected O, but got Unknown
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			//IL_0082: Expected O, but got Unknown
			//IL_0085: Unknown result type (might be due to invalid IL or missing references)
			//IL_008f: Expected O, but got Unknown
			//IL_0092: Unknown result type (might be due to invalid IL or missing references)
			//IL_009c: Expected O, but got Unknown
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a9: Expected O, but got Unknown
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b6: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMLabel1 = (MMLabel)target;
				break;
			case 2:
				MMAdvCombo1 = (MMAdvancedComboEdit)target;
				break;
			case 3:
				CmdReset = (MMCmdButton)target;
				break;
			case 4:
				frmHess = (MMGroupBox)target;
				break;
			case 5:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 6:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 7:
				MMSpinBox1_label = (MMLabel)target;
				break;
			case 8:
				MMSpinBox1 = (MMSpinBox)target;
				break;
			case 9:
				MMComboBox2_label = (MMLabel)target;
				break;
			case 10:
				MMComboBox2 = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_DMOBas_Search")]
	public class MMACMModel_SolverOptions_DMOBas_Search : MMTabPage, IComponentConnector
	{
		internal MMLabel MMLabel1;

		internal MMAdvancedComboEdit MMAdvCombo1;

		internal MMCmdButton CmdReset;

		internal MMGroupBox frmHess;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMLabel MMLBUText6_label;

		internal MMVariableEdit MMLBUText6;

		internal MMLabel MMSpinBox1_label;

		internal MMSpinBox MMSpinBox1;

		internal MMGroupBox frmLine;

		internal MMLabel MMComboBox3_label;

		internal MMComboEdit MMComboBox3;

		internal MMLabel MMComboBox2_label;

		internal MMComboEdit MMComboBox2;

		internal MMLabel MMSpinBox3_label;

		internal MMSpinBox MMSpinBox3;

		internal MMGroupBox MMFrame1;

		internal MMLabel MMComboBox4_label;

		internal MMComboEdit MMComboBox4;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_DMOBas_Search()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMEOConv_DMOBas_Search_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_dmobas_search.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_005f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Expected O, but got Unknown
			//IL_006c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0076: Expected O, but got Unknown
			//IL_0079: Unknown result type (might be due to invalid IL or missing references)
			//IL_0083: Expected O, but got Unknown
			//IL_0086: Unknown result type (might be due to invalid IL or missing references)
			//IL_0090: Expected O, but got Unknown
			//IL_0093: Unknown result type (might be due to invalid IL or missing references)
			//IL_009d: Expected O, but got Unknown
			//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00aa: Expected O, but got Unknown
			//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b7: Expected O, but got Unknown
			//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c4: Expected O, but got Unknown
			//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d1: Expected O, but got Unknown
			//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00de: Expected O, but got Unknown
			//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00eb: Expected O, but got Unknown
			//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f8: Expected O, but got Unknown
			//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0105: Expected O, but got Unknown
			//IL_0108: Unknown result type (might be due to invalid IL or missing references)
			//IL_0112: Expected O, but got Unknown
			//IL_0115: Unknown result type (might be due to invalid IL or missing references)
			//IL_011f: Expected O, but got Unknown
			//IL_0122: Unknown result type (might be due to invalid IL or missing references)
			//IL_012c: Expected O, but got Unknown
			//IL_012f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0139: Expected O, but got Unknown
			//IL_013c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0146: Expected O, but got Unknown
			//IL_0149: Unknown result type (might be due to invalid IL or missing references)
			//IL_0153: Expected O, but got Unknown
			//IL_0156: Unknown result type (might be due to invalid IL or missing references)
			//IL_0160: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMLabel1 = (MMLabel)target;
				break;
			case 2:
				MMAdvCombo1 = (MMAdvancedComboEdit)target;
				break;
			case 3:
				CmdReset = (MMCmdButton)target;
				break;
			case 4:
				frmHess = (MMGroupBox)target;
				break;
			case 5:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 6:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 7:
				MMLBUText6_label = (MMLabel)target;
				break;
			case 8:
				MMLBUText6 = (MMVariableEdit)target;
				break;
			case 9:
				MMSpinBox1_label = (MMLabel)target;
				break;
			case 10:
				MMSpinBox1 = (MMSpinBox)target;
				break;
			case 11:
				frmLine = (MMGroupBox)target;
				break;
			case 12:
				MMComboBox3_label = (MMLabel)target;
				break;
			case 13:
				MMComboBox3 = (MMComboEdit)target;
				break;
			case 14:
				MMComboBox2_label = (MMLabel)target;
				break;
			case 15:
				MMComboBox2 = (MMComboEdit)target;
				break;
			case 16:
				MMSpinBox3_label = (MMLabel)target;
				break;
			case 17:
				MMSpinBox3 = (MMSpinBox)target;
				break;
			case 18:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 19:
				MMComboBox4_label = (MMLabel)target;
				break;
			case 20:
				MMComboBox4 = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_LSSBas")]
	public class MMACMModel_SolverOptions_LSSBas : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMSSTab1;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_LSSBas()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMEOConv_LSSBas_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_lssbas.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMSSTab1 = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_LSSBas_Basic")]
	public class MMACMModel_SolverOptions_LSSBas_Basic : MMTabPage, IComponentConnector
	{
		internal MMLabel MMLabel1;

		internal MMAdvancedComboEdit MMAdvCombo1;

		internal MMCmdButton CmdReset;

		internal MMGroupBox frmIter;

		internal MMLabel MMLBUText2_label;

		internal MMVariableEdit MMLBUText2;

		internal MMLabel MMLBUText4_label;

		internal MMVariableEdit MMLBUText4;

		internal MMLabel MMLBUText5_label;

		internal MMVariableEdit MMLBUText5;

		internal MMGroupBox MMFrame1;

		internal MMLabel MMSpinBox1_label;

		internal MMSpinBox MMSpinBox1;

		internal MMLabel MMSpinBox2_label;

		internal MMSpinBox MMSpinBox2;

		internal MMLabel MMSpinBox3_label;

		internal MMSpinBox MMSpinBox3;

		internal MMLabel MMSpinBox4_label;

		internal MMSpinBox MMSpinBox4;

		internal MMGroupBox MMFrame2;

		internal MMLabel MMSpinBox5_label;

		internal MMSpinBox MMSpinBox5;

		internal MMLabel MMSpinBox6_label;

		internal MMSpinBox MMSpinBox6;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_LSSBas_Basic()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMEOConv_LSSBas_Basic_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_lssbas_basic.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_006f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0079: Expected O, but got Unknown
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0086: Expected O, but got Unknown
			//IL_0089: Unknown result type (might be due to invalid IL or missing references)
			//IL_0093: Expected O, but got Unknown
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a0: Expected O, but got Unknown
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ad: Expected O, but got Unknown
			//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ba: Expected O, but got Unknown
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c7: Expected O, but got Unknown
			//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d4: Expected O, but got Unknown
			//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e1: Expected O, but got Unknown
			//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ee: Expected O, but got Unknown
			//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fb: Expected O, but got Unknown
			//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
			//IL_0108: Expected O, but got Unknown
			//IL_010b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0115: Expected O, but got Unknown
			//IL_0118: Unknown result type (might be due to invalid IL or missing references)
			//IL_0122: Expected O, but got Unknown
			//IL_0125: Unknown result type (might be due to invalid IL or missing references)
			//IL_012f: Expected O, but got Unknown
			//IL_0132: Unknown result type (might be due to invalid IL or missing references)
			//IL_013c: Expected O, but got Unknown
			//IL_013f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0149: Expected O, but got Unknown
			//IL_014c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0156: Expected O, but got Unknown
			//IL_0159: Unknown result type (might be due to invalid IL or missing references)
			//IL_0163: Expected O, but got Unknown
			//IL_0166: Unknown result type (might be due to invalid IL or missing references)
			//IL_0170: Expected O, but got Unknown
			//IL_0173: Unknown result type (might be due to invalid IL or missing references)
			//IL_017d: Expected O, but got Unknown
			//IL_0180: Unknown result type (might be due to invalid IL or missing references)
			//IL_018a: Expected O, but got Unknown
			//IL_018d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0197: Expected O, but got Unknown
			//IL_019a: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a4: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMLabel1 = (MMLabel)target;
				break;
			case 2:
				MMAdvCombo1 = (MMAdvancedComboEdit)target;
				break;
			case 3:
				CmdReset = (MMCmdButton)target;
				break;
			case 4:
				frmIter = (MMGroupBox)target;
				break;
			case 5:
				MMLBUText2_label = (MMLabel)target;
				break;
			case 6:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			case 7:
				MMLBUText4_label = (MMLabel)target;
				break;
			case 8:
				MMLBUText4 = (MMVariableEdit)target;
				break;
			case 9:
				MMLBUText5_label = (MMLabel)target;
				break;
			case 10:
				MMLBUText5 = (MMVariableEdit)target;
				break;
			case 11:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 12:
				MMSpinBox1_label = (MMLabel)target;
				break;
			case 13:
				MMSpinBox1 = (MMSpinBox)target;
				break;
			case 14:
				MMSpinBox2_label = (MMLabel)target;
				break;
			case 15:
				MMSpinBox2 = (MMSpinBox)target;
				break;
			case 16:
				MMSpinBox3_label = (MMLabel)target;
				break;
			case 17:
				MMSpinBox3 = (MMSpinBox)target;
				break;
			case 18:
				MMSpinBox4_label = (MMLabel)target;
				break;
			case 19:
				MMSpinBox4 = (MMSpinBox)target;
				break;
			case 20:
				MMFrame2 = (MMGroupBox)target;
				break;
			case 21:
				MMSpinBox5_label = (MMLabel)target;
				break;
			case 22:
				MMSpinBox5 = (MMSpinBox)target;
				break;
			case 23:
				MMSpinBox6_label = (MMLabel)target;
				break;
			case 24:
				MMSpinBox6 = (MMSpinBox)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_LSSBas_Report")]
	public class MMACMModel_SolverOptions_LSSBas_Report : MMTabPage, IComponentConnector
	{
		internal MMLabel MMLabel1;

		internal MMAdvancedComboEdit MMAdvCombo1;

		internal MMCmdButton CmdReset;

		internal MMGroupBox frmHess;

		internal MMGroupBox MMFrame1;

		internal MMLabel MMSpinBox4_label;

		internal MMSpinBox MMSpinBox4;

		internal MMGroupBox MMFrame2;

		internal MMLabel MMSpinBox2_label;

		internal MMSpinBox MMSpinBox2;

		internal MMLabel MMSpinBox1_label;

		internal MMSpinBox MMSpinBox1;

		internal MMLabel MMSpinBox3_label;

		internal MMSpinBox MMSpinBox3;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_LSSBas_Report()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMEOConv_LSSBas_Report_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_lssbas_report.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			//IL_0061: Unknown result type (might be due to invalid IL or missing references)
			//IL_006b: Expected O, but got Unknown
			//IL_006e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Expected O, but got Unknown
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Expected O, but got Unknown
			//IL_0088: Unknown result type (might be due to invalid IL or missing references)
			//IL_0092: Expected O, but got Unknown
			//IL_0095: Unknown result type (might be due to invalid IL or missing references)
			//IL_009f: Expected O, but got Unknown
			//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Expected O, but got Unknown
			//IL_00af: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d3: Expected O, but got Unknown
			//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e0: Expected O, but got Unknown
			//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ed: Expected O, but got Unknown
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fa: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMLabel1 = (MMLabel)target;
				break;
			case 2:
				MMAdvCombo1 = (MMAdvancedComboEdit)target;
				break;
			case 3:
				CmdReset = (MMCmdButton)target;
				break;
			case 4:
				frmHess = (MMGroupBox)target;
				break;
			case 5:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 6:
				MMSpinBox4_label = (MMLabel)target;
				break;
			case 7:
				MMSpinBox4 = (MMSpinBox)target;
				break;
			case 8:
				MMFrame2 = (MMGroupBox)target;
				break;
			case 9:
				MMSpinBox2_label = (MMLabel)target;
				break;
			case 10:
				MMSpinBox2 = (MMSpinBox)target;
				break;
			case 11:
				MMSpinBox1_label = (MMLabel)target;
				break;
			case 12:
				MMSpinBox1 = (MMSpinBox)target;
				break;
			case 13:
				MMSpinBox3_label = (MMLabel)target;
				break;
			case 14:
				MMSpinBox3 = (MMSpinBox)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_LSSBas_Search")]
	public class MMACMModel_SolverOptions_LSSBas_Search : MMTabPage, IComponentConnector
	{
		internal MMLabel MMLabel1;

		internal MMAdvancedComboEdit MMAdvCombo1;

		internal MMCmdButton CmdReset;

		internal MMGroupBox frmIter;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMGroupBox MMFrame1;

		internal MMLabel MMComboBox2_label;

		internal MMComboEdit MMComboBox2;

		internal MMLabel MMSpinBox2_label;

		internal MMSpinBox MMSpinBox2;

		internal MMLabel MMLBUText3_label;

		internal MMVariableEdit MMLBUText3;

		internal MMLabel MMLBUText2_label;

		internal MMVariableEdit MMLBUText2;

		internal MMLabel MMLBUText4_label;

		internal MMVariableEdit MMLBUText4;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_LSSBas_Search()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMEOConv_LSSBas_Search_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_lssbas_search.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Expected O, but got Unknown
			//IL_0068: Unknown result type (might be due to invalid IL or missing references)
			//IL_0072: Expected O, but got Unknown
			//IL_0075: Unknown result type (might be due to invalid IL or missing references)
			//IL_007f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_008f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0099: Expected O, but got Unknown
			//IL_009c: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a6: Expected O, but got Unknown
			//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b3: Expected O, but got Unknown
			//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c0: Expected O, but got Unknown
			//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cd: Expected O, but got Unknown
			//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00da: Expected O, but got Unknown
			//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e7: Expected O, but got Unknown
			//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f4: Expected O, but got Unknown
			//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0101: Expected O, but got Unknown
			//IL_0104: Unknown result type (might be due to invalid IL or missing references)
			//IL_010e: Expected O, but got Unknown
			//IL_0111: Unknown result type (might be due to invalid IL or missing references)
			//IL_011b: Expected O, but got Unknown
			//IL_011e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0128: Expected O, but got Unknown
			//IL_012b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0135: Expected O, but got Unknown
			//IL_0138: Unknown result type (might be due to invalid IL or missing references)
			//IL_0142: Expected O, but got Unknown
			//IL_0145: Unknown result type (might be due to invalid IL or missing references)
			//IL_014f: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMLabel1 = (MMLabel)target;
				break;
			case 2:
				MMAdvCombo1 = (MMAdvancedComboEdit)target;
				break;
			case 3:
				CmdReset = (MMCmdButton)target;
				break;
			case 4:
				frmIter = (MMGroupBox)target;
				break;
			case 5:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 6:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 7:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 8:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 9:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 10:
				MMComboBox2_label = (MMLabel)target;
				break;
			case 11:
				MMComboBox2 = (MMComboEdit)target;
				break;
			case 12:
				MMSpinBox2_label = (MMLabel)target;
				break;
			case 13:
				MMSpinBox2 = (MMSpinBox)target;
				break;
			case 14:
				MMLBUText3_label = (MMLabel)target;
				break;
			case 15:
				MMLBUText3 = (MMVariableEdit)target;
				break;
			case 16:
				MMLBUText2_label = (MMLabel)target;
				break;
			case 17:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			case 18:
				MMLBUText4_label = (MMLabel)target;
				break;
			case 19:
				MMLBUText4 = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_NSLBas")]
	public class MMACMModel_SolverOptions_NSLBas : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip MMSSTab1;

		internal MMTabItem tab0;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_NSLBas()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMEOConv_NSLBas_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_nslbas.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMSSTab1 = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	[ProgId("MMACMModel.MMACMModel_SolverOptions_NSLBas_Basic")]
	public class MMACMModel_SolverOptions_NSLBas_Basic : MMTabPage, IComponentConnector
	{
		internal MMLabel MMLabel1;

		internal MMAdvancedComboEdit MMAdvCombo1;

		internal MMCmdButton CmdReset;

		internal MMGroupBox frmMatrix;

		internal MMLabel MMSpinBox3_label;

		internal MMSpinBox MMSpinBox3;

		internal MMLabel MMSpinBox1_label;

		internal MMSpinBox MMSpinBox1;

		internal MMLabel MMSpinBox2_label;

		internal MMSpinBox MMSpinBox2;

		internal MMLabel MMLBUText3_label;

		internal MMVariableEdit MMLBUText3;

		internal MMLabel MMLBUText2_label;

		internal MMVariableEdit MMLBUText2;

		private bool _contentLoaded;

		public MMACMModel_SolverOptions_NSLBas_Basic()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMEOConv_NSLBas_Basic_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.ACMModel;component/mmacmmodel_solveroptions_nslbas_basic.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			//IL_0061: Unknown result type (might be due to invalid IL or missing references)
			//IL_006b: Expected O, but got Unknown
			//IL_006e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Expected O, but got Unknown
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Expected O, but got Unknown
			//IL_0088: Unknown result type (might be due to invalid IL or missing references)
			//IL_0092: Expected O, but got Unknown
			//IL_0095: Unknown result type (might be due to invalid IL or missing references)
			//IL_009f: Expected O, but got Unknown
			//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Expected O, but got Unknown
			//IL_00af: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d3: Expected O, but got Unknown
			//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e0: Expected O, but got Unknown
			//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ed: Expected O, but got Unknown
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fa: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMLabel1 = (MMLabel)target;
				break;
			case 2:
				MMAdvCombo1 = (MMAdvancedComboEdit)target;
				break;
			case 3:
				CmdReset = (MMCmdButton)target;
				break;
			case 4:
				frmMatrix = (MMGroupBox)target;
				break;
			case 5:
				MMSpinBox3_label = (MMLabel)target;
				break;
			case 6:
				MMSpinBox3 = (MMSpinBox)target;
				break;
			case 7:
				MMSpinBox1_label = (MMLabel)target;
				break;
			case 8:
				MMSpinBox1 = (MMSpinBox)target;
				break;
			case 9:
				MMSpinBox2_label = (MMLabel)target;
				break;
			case 10:
				MMSpinBox2 = (MMSpinBox)target;
				break;
			case 11:
				MMLBUText3_label = (MMLabel)target;
				break;
			case 12:
				MMLBUText3 = (MMVariableEdit)target;
				break;
			case 13:
				MMLBUText2_label = (MMLabel)target;
				break;
			case 14:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
}
namespace XamlGeneratedNamespace
{
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class GeneratedInternalTypeHelper : InternalTypeHelper
	{
		protected override object CreateInstance(Type type, CultureInfo culture)
		{
			return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.CreateInstance, null, null, culture);
		}

		protected override object GetPropertyValue(PropertyInfo propertyInfo, object target, CultureInfo culture)
		{
			return propertyInfo.GetValue(target, BindingFlags.Default, null, null, culture);
		}

		protected override void SetPropertyValue(PropertyInfo propertyInfo, object target, object value, CultureInfo culture)
		{
			propertyInfo.SetValue(target, value, BindingFlags.Default, null, null, culture);
		}

		protected override Delegate CreateDelegate(Type delegateType, object target, string handler)
		{
			return (Delegate)target.GetType().InvokeMember("_CreateDelegate", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, target, new object[2] { delegateType, handler }, null);
		}

		protected override void AddEventHandler(EventInfo eventInfo, object target, Delegate handler)
		{
			eventInfo.AddEventHandler(target, handler);
		}
	}
}
