using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenCxs;
using AspenTech.AspenCxs.CxsViewModel;
using AspenTech.AspenPlus.Localization.Properties;
using AspenTech.AspenPlus.MMControls;
using AspenTech.AspenPlus.MMControls.CompositeEvents;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.MMForms.Blocks.Scfrac")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.MMForms.Blocks.Scfrac")]
[assembly: AssemblyCopyright("Copyright © aspentech 2010 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/scfrac", "AspenTech.AspenPlus.MMForms.Blocks.Scfrac")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]
namespace AspenTech.AspenPlus.MMForms.Blocks.Scfrac
{
	public class MMScfrac_Input_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration CONNECT_Property = CxvPropertyDeclaration.Register("CONNECT", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.CONNECT"
		});

		public static readonly CxvPropertyDeclaration STEAMCPLT_Property = CxvPropertyDeclaration.Register("STEAMCPLT", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.STEAMCPLT"
		});

		public static readonly CxvPropertyDeclaration FIND_Property = CxvPropertyDeclaration.Register("FIND", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.FIND"
		});

		public static readonly CxvPropertyDeclaration ENUF_Property = CxvPropertyDeclaration.Register("ENUF", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENUF"
		});

		public static readonly CxvPropertyDeclaration UENTFI_Property = CxvPropertyDeclaration.Register("UENTFI", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTFI"
		});

		public static readonly CxvPropertyDeclaration COND_Property = CxvPropertyDeclaration.Register("COND", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.COND"
		});

		public static readonly CxvPropertyDeclaration UENTCOND_Property = CxvPropertyDeclaration.Register("UENTCOND", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCOND"
		});

		public static readonly CxvPropertyDeclaration UENTCVG_Property = CxvPropertyDeclaration.Register("UENTCVG", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCVG"
		});

		public static readonly CxvPropertyDeclaration UENTSTEAM_Property = CxvPropertyDeclaration.Register("UENTSTEAM", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTSTEAM"
		});

		public static readonly CxvPropertyDeclaration CPSPEC_Property = CxvPropertyDeclaration.Register("CPSPEC", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.CPSPEC"
		});

		public static readonly CxvPropertyDeclaration CPSPEC2_Property = CxvPropertyDeclaration.Register("CPSPEC2", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.CPSPEC2"
		});

		public static readonly CxvPropertyDeclaration CPSPEC3_Property = CxvPropertyDeclaration.Register("CPSPEC3", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.CPSPEC3"
		});

		public static readonly CxvPropertyDeclaration UNSPECS_Property = CxvPropertyDeclaration.Register("UNSPECS", typeof(MMScfrac_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UNSPECS"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMScfrac_Input_ViewModel), new CxvTabItemProperty
		{
			CompleteDataPaths = { "@CONNECT" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMScfrac_Input_ViewModel), new CxvTabItemProperty
		{
			CompleteDataPaths = { "@STEAMCPLT" },
			EnteredDataPaths = { "@UENTSTEAM" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMScfrac_Input_ViewModel), new CxvTabItemProperty
		{
			CompleteDataPaths = { "@CPSPEC", "@CPSPEC2", "@CPSPEC3", "@ENUF" },
			EnteredDataPaths = { "@UNSPECS" }
		});

		public static readonly CxvPropertyDeclaration tab3_var_Property = CxvPropertyDeclaration.Register("tab3_var", typeof(MMScfrac_Input_ViewModel), new CxvTabItemProperty
		{
			CompleteDataPaths = { "@ENUF", "@FIND" },
			EnteredDataPaths = { "@UENTFI" }
		});

		public static readonly CxvPropertyDeclaration tab4_var_Property = CxvPropertyDeclaration.Register("tab4_var", typeof(MMScfrac_Input_ViewModel), new CxvTabItemProperty
		{
			CompleteDataPaths = { "@COND" },
			EnteredDataPaths = { "@UENTCOND" }
		});

		public static readonly CxvPropertyDeclaration tab5_var_Property = CxvPropertyDeclaration.Register("tab5_var", typeof(MMScfrac_Input_ViewModel), new CxvTabItemProperty
		{
			EnteredDataPaths = { "@UENTCVG" }
		});

		public object CONNECT => GetValue(CONNECT_Property);

		public object STEAMCPLT => GetValue(STEAMCPLT_Property);

		public object FIND => GetValue(FIND_Property);

		public object ENUF => GetValue(ENUF_Property);

		public object UENTFI => GetValue(UENTFI_Property);

		public object COND => GetValue(COND_Property);

		public object UENTCOND => GetValue(UENTCOND_Property);

		public object UENTCVG => GetValue(UENTCVG_Property);

		public object UENTSTEAM => GetValue(UENTSTEAM_Property);

		public object CPSPEC => GetValue(CPSPEC_Property);

		public object CPSPEC2 => GetValue(CPSPEC2_Property);

		public object CPSPEC3 => GetValue(CPSPEC3_Property);

		public object UNSPECS => GetValue(UNSPECS_Property);

		public object tab0_var => GetValue(tab0_var_Property);

		public object tab1_var => GetValue(tab1_var_Property);

		public object tab2_var => GetValue(tab2_var_Property);

		public object tab3_var => GetValue(tab3_var_Property);

		public object tab4_var => GetValue(tab4_var_Property);

		public object tab5_var => GetValue(tab5_var_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Input")]
	public class MMScfrac_Input : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabScfracInput;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem tab3;

		internal MMTabItem tab4;

		internal MMTabItem tab5;

		internal MMTabItem tabInfo;

		private bool _contentLoaded;

		public MMScfrac_Input()
		{
			base.ViewModelType = typeof(MMScfrac_Input_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_input.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				tabScfracInput = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				tab3 = (MMTabItem)target;
				break;
			case 6:
				tab4 = (MMTabItem)target;
				break;
			case 7:
				tab5 = (MMTabItem)target;
				break;
			case 8:
				tabInfo = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMScfrac_Input_Conden_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration ogrCondenser_MultiMap_Property = CxvPropertyDeclaration.Register("ogrCondenser_MultiMap", typeof(MMScfrac_Input_Conden_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "ogrCondenser_OPT_COND",
					DataPath = "@main.Input.OPT_COND"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Temperature:",
					DisplayResourceKey = "MMScfrac_Input_Conden_ViewModel__CxvMultiMapOption_Display_Temperature_",
					Value = "ogrCondenser_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "ogrCondenser_OPT_COND",
							Value = "TEMP"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Distillate vapor fraction:",
					DisplayResourceKey = "MMScfrac_Input_Conden_ViewModel__CxvMultiMapOption_Display_Distillate_vapor_fraction_",
					Value = "ogrCondenser_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "ogrCondenser_OPT_COND",
							Value = "RDV"
						}
					}
				}
			}
		});

		public static readonly CxvPropertyDeclaration lbtuPressure_var1_Property = CxvPropertyDeclaration.Register("lbtuPressure_var1", typeof(MMScfrac_Input_Conden_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.PRES"
		});

		public static readonly CxvPropertyDeclaration lbtuTemperature_var1_Property = CxvPropertyDeclaration.Register("lbtuTemperature_var1", typeof(MMScfrac_Input_Conden_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.TEMP",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.OPTTEMP"
			}
		});

		public static readonly CxvPropertyDeclaration txtRDV_var1_Property = CxvPropertyDeclaration.Register("txtRDV_var1", typeof(MMScfrac_Input_Conden_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.RDV",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.OPTRDV"
			}
		});

		public static readonly CxvPropertyDeclaration lbtuDegsub_var1_Property = CxvPropertyDeclaration.Register("lbtuDegsub_var1", typeof(MMScfrac_Input_Conden_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.DEGSUB",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.ENTDEGSUB"
			}
		});

		public object ogrCondenser_MultiMap => GetValue(ogrCondenser_MultiMap_Property);

		public object lbtuPressure_var1 => GetValue(lbtuPressure_var1_Property);

		public object lbtuTemperature_var1 => GetValue(lbtuTemperature_var1_Property);

		public object txtRDV_var1 => GetValue(txtRDV_var1_Property);

		public object lbtuDegsub_var1 => GetValue(lbtuDegsub_var1_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Input_Conden")]
	public class MMScfrac_Input_Conden : MMTabPage, IComponentConnector
	{
		internal MMOptionGroup ogrCondenser;

		internal MMLabel lbtuPressure_label;

		internal MMVariableEdit lbtuPressure;

		internal MMOptionButton ogrCondenser_opt0;

		internal MMVariableEdit lbtuTemperature;

		internal MMOptionButton ogrCondenser_opt1;

		internal MMValueEdit txtRDV;

		internal MMLabel lbtuDegsub_label;

		internal MMVariableEdit lbtuDegsub;

		private bool _contentLoaded;

		public MMScfrac_Input_Conden()
		{
			base.ViewModelType = typeof(MMScfrac_Input_Conden_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_input_conden.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				ogrCondenser = (MMOptionGroup)target;
				break;
			case 2:
				lbtuPressure_label = (MMLabel)target;
				break;
			case 3:
				lbtuPressure = (MMVariableEdit)target;
				break;
			case 4:
				ogrCondenser_opt0 = (MMOptionButton)target;
				break;
			case 5:
				lbtuTemperature = (MMVariableEdit)target;
				break;
			case 6:
				ogrCondenser_opt1 = (MMOptionButton)target;
				break;
			case 7:
				txtRDV = (MMValueEdit)target;
				break;
			case 8:
				lbtuDegsub_label = (MMLabel)target;
				break;
			case 9:
				lbtuDegsub = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMScfrac_Input_Connec_ViewModel : MMTabPageViewModel
	{
		public class grdProdStream_Connec_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration snpSection_var1_Property = CxvPropertyDeclaration.Register("snpSection_var1", typeof(grdProdStream_Connec_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.SECNO.@yconnec",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCPRODS"
				}
			});

			public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(grdProdStream_Connec_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.FEED_FRAC.@yconnec",
				BasisPath = "@main.Input.FRAC_BASIS.@yconnec",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCPRODS"
				}
			});

			public static readonly CxvPropertyDeclaration lbtuFlow_var1_Property = CxvPropertyDeclaration.Register("lbtuFlow_var1", typeof(grdProdStream_Connec_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.FLOW_EST.@yconnec",
				BasisPath = "@main.Input.FLOW_BASIS.@yconnec",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCPRODS"
				}
			});

			public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(grdProdStream_Connec_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.Id,
				DataPath = "@main.Input.PROD_PRES.@yconnec",
				DisplayedCase = CxsDisplayedCase.Uppercase,
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCPRODS"
				}
			});

			public static readonly CxvPropertyDeclaration cboType_MultiMap_Property = CxvPropertyDeclaration.Register("cboType_MultiMap", typeof(grdProdStream_Connec_GridData_ItemTemplate), new CxvMultiMapProperty
			{
				Variables = 
				{
					new CxvMultiMapVariable
					{
						Name = "cboType_var1",
						DataPath = "@main.Input.TYPE.@yconnec"
					}
				},
				Options = 
				{
					new CxvMultiMapOption
					{
						Display = "Overhead",
						DisplayResourceKey = "MMScfrac_Input_Connec_ViewModel__CxvMultiMapOption_Display_Overhead",
						Value = "cboType_MultiMapOption_1",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboType_var1",
								Value = "O"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "Bottoms",
						DisplayResourceKey = "MMScfrac_Input_Connec_ViewModel__CxvMultiMapOption_Display_Bottoms",
						Value = "cboType_MultiMapOption_2",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboType_var1",
								Value = "B"
							}
						}
					}
				},
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCPRODS"
				}
			});

			public static readonly CxvPropertyDeclaration txtProd_Pres_var1_Property = CxvPropertyDeclaration.Register("txtProd_Pres_var1", typeof(grdProdStream_Connec_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.PROD_PRES.@yconnec",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCPRODS"
				}
			});

			public object snpSection_var1 => GetValue(snpSection_var1_Property);

			public object MMLBUText1_var1 => GetValue(MMLBUText1_var1_Property);

			public object lbtuFlow_var1 => GetValue(lbtuFlow_var1_Property);

			public object MMTextBox2_var1 => GetValue(MMTextBox2_var1_Property);

			public object cboType_MultiMap => GetValue(cboType_MultiMap_Property);

			public object txtProd_Pres_var1 => GetValue(txtProd_Pres_var1_Property);
		}

		public static readonly CxvPropertyDeclaration cboVPhases_MultiMap_Property = CxvPropertyDeclaration.Register("cboVPhases_MultiMap", typeof(MMScfrac_Input_Connec_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "cboVPhases_BLKOPFREWAT",
					DataPath = "@main.Input.BLKOPFREWAT"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Vapor-Liquid",
					DisplayResourceKey = "MMScfrac_Input_Connec_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid",
					Value = "cboVPhases_MultiMapOption_1",
					Prompt = "2 phases (vapor and liquid) are considered in phase equilibrium \r\ncalculations. \r\n",
					PromptResourceKey = "MMScfrac_Input_Connec_ViewModel__CxvMultiMapOption_Prompt_2_phases__vapor_and_liquid__are_considered",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboVPhases_BLKOPFREWAT",
							Value = "NO"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Vapor-Liquid-FreeWater",
					DisplayResourceKey = "MMScfrac_Input_Connec_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_FreeWater",
					Value = "cboVPhases_MultiMapOption_2",
					Prompt = "3 phases (vapor, organic, and pure water) are considered in phase \r\nequilibrium calculations.\r\n",
					PromptResourceKey = "MMScfrac_Input_Connec_ViewModel__CxvMultiMapOption_Prompt_3_phases__vapor__organic__and_pure_water__",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboVPhases_BLKOPFREWAT",
							Value = "YES"
						}
					}
				}
			}
		});

		public static readonly CxvPropertyDeclaration lbtuProd_Pres_var1_Property = CxvPropertyDeclaration.Register("lbtuProd_Pres_var1", typeof(MMScfrac_Input_Connec_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.PROD_PRES"
		});

		public static readonly CxvPropertyDeclaration grdProdStream_Connec_GridData_Property = CxvPropertyDeclaration.Register("grdProdStream_Connec_GridData", typeof(MMScfrac_Input_Connec_ViewModel), new CxvVectorProperty
		{
			ItemType = typeof(grdProdStream_Connec_GridData_ItemTemplate),
			IndexBasis = new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.PROD_PRES",
				UseChildId = true,
				Name = "yconnec"
			}
		});

		public object cboVPhases_MultiMap => GetValue(cboVPhases_MultiMap_Property);

		public object lbtuProd_Pres_var1 => GetValue(lbtuProd_Pres_var1_Property);

		public object grdProdStream_Connec_GridData => GetValue(grdProdStream_Connec_GridData_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Input_Connec")]
	public class MMScfrac_Input_Connec : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraProdStream_Connec;

		internal MMScrollArea grdProdStream_Connec;

		internal MMGroupBox MMFrame1;

		internal MMComboEdit cboVPhases;

		private bool _contentLoaded;

		public MMScfrac_Input_Connec()
		{
			base.ViewModelType = typeof(MMScfrac_Input_Connec_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_input_connec.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				fraProdStream_Connec = (MMGroupBox)target;
				break;
			case 2:
				grdProdStream_Connec = (MMScrollArea)target;
				break;
			case 3:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 4:
				cboVPhases = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMScfrac_Input_Conver_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMLBUText3_var1_Property = CxvPropertyDeclaration.Register("MMLBUText3_var1", typeof(MMScfrac_Input_Conver_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.MAX_FINDEX"
		});

		public static readonly CxvPropertyDeclaration MMLBUText2_var1_Property = CxvPropertyDeclaration.Register("MMLBUText2_var1", typeof(MMScfrac_Input_Conver_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.TOL"
		});

		public static readonly CxvPropertyDeclaration spnMaxit_var1_Property = CxvPropertyDeclaration.Register("spnMaxit_var1", typeof(MMScfrac_Input_Conver_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.MAXIT"
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMScfrac_Input_Conver_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.FLASH_TOL"
		});

		public static readonly CxvPropertyDeclaration spnFlash_Maxit_var1_Property = CxvPropertyDeclaration.Register("spnFlash_Maxit_var1", typeof(MMScfrac_Input_Conver_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.FLASH_MAXIT"
		});

		public object MMLBUText3_var1 => GetValue(MMLBUText3_var1_Property);

		public object MMLBUText2_var1 => GetValue(MMLBUText2_var1_Property);

		public object spnMaxit_var1 => GetValue(spnMaxit_var1_Property);

		public object MMLBUText1_var1 => GetValue(MMLBUText1_var1_Property);

		public object spnFlash_Maxit_var1 => GetValue(spnFlash_Maxit_var1_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Input_Conver")]
	public class MMScfrac_Input_Conver : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraModelConver_Param;

		internal MMLabel spnMaxit_label;

		internal MMSpinBox spnMaxit;

		internal MMLabel MMLBUText2_label;

		internal MMVariableEdit MMLBUText2;

		internal MMLabel MMLBUText3_label;

		internal MMVariableEdit MMLBUText3;

		internal MMGroupBox fraFlashConver_Param;

		internal MMLabel spnFlash_Maxit_label;

		internal MMSpinBox spnFlash_Maxit;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		private bool _contentLoaded;

		public MMScfrac_Input_Conver()
		{
			base.ViewModelType = typeof(MMScfrac_Input_Conver_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_input_conver.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				fraModelConver_Param = (MMGroupBox)target;
				break;
			case 2:
				spnMaxit_label = (MMLabel)target;
				break;
			case 3:
				spnMaxit = (MMSpinBox)target;
				break;
			case 4:
				MMLBUText2_label = (MMLabel)target;
				break;
			case 5:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			case 6:
				MMLBUText3_label = (MMLabel)target;
				break;
			case 7:
				MMLBUText3 = (MMVariableEdit)target;
				break;
			case 8:
				fraFlashConver_Param = (MMGroupBox)target;
				break;
			case 9:
				spnFlash_Maxit_label = (MMLabel)target;
				break;
			case 10:
				spnFlash_Maxit = (MMSpinBox)target;
				break;
			case 11:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 12:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMScfrac_Input_Dialog_ViewModel : MMTabPageViewModel
	{
		private ICommand _Command1_Command;

		public static readonly CxvPropertyDeclaration lstpSPFRAC_var1_Property = CxvPropertyDeclaration.Register("lstpSPFRAC_var1", typeof(MMScfrac_Input_Dialog_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.List,
			DataPath = "@main.Input.COMPS.@spcid",
			AllowSort = false
		});

		public ICommand Command1_Command
		{
			get
			{
				if (_Command1_Command == null)
				{
					_Command1_Command = new CxvDelegateCommand<object>(Command1_CommandExecute);
				}
				return _Command1_Command;
			}
		}

		public object lstpSPFRAC_var1 => GetValue(lstpSPFRAC_var1_Property);

		private void Command1_CommandExecute(object parameter)
		{
			CloseForm();
		}
	}
	[ProgId("MMScfrac.MMScfrac_Input_Dialog")]
	public class MMScfrac_Input_Dialog : MMTabPage, IComponentConnector
	{
		internal MMListPicker lstpSPFRAC;

		internal MMCmdButton Command1;

		private bool _contentLoaded;

		public MMScfrac_Input_Dialog()
		{
			base.ViewModelType = typeof(MMScfrac_Input_Dialog_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_input_dialog.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				lstpSPFRAC = (MMListPicker)target;
				break;
			case 2:
				Command1 = (MMCmdButton)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMScfrac_Input_FracIn_ViewModel : MMTabPageViewModel
	{
		public class MMScrollArea1_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration snpSection_var1_Property = CxvPropertyDeclaration.Register("snpSection_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.IdWithOptions,
				DataPath = "@main.Input.FINDEX.@yfindex"
			});

			public static readonly CxvPropertyDeclaration txtFindex_var1_Property = CxvPropertyDeclaration.Register("txtFindex_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.FINDEX.@yfindex"
			});

			public static readonly CxvPropertyDeclaration txtFiheavy_var1_Property = CxvPropertyDeclaration.Register("txtFiheavy_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.FIHEAVY.@yfindex"
			});

			public static readonly CxvPropertyDeclaration txtFiratio_var1_Property = CxvPropertyDeclaration.Register("txtFiratio_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.FIRATIO.@yfindex"
			});

			public static readonly CxvPropertyDeclaration txtFiest_var1_Property = CxvPropertyDeclaration.Register("txtFiest_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.FIEST.@yfindex"
			});

			public object snpSection_var1 => GetValue(snpSection_var1_Property);

			public object txtFindex_var1 => GetValue(txtFindex_var1_Property);

			public object txtFiheavy_var1 => GetValue(txtFiheavy_var1_Property);

			public object txtFiratio_var1 => GetValue(txtFiratio_var1_Property);

			public object txtFiest_var1 => GetValue(txtFiest_var1_Property);
		}

		public static readonly CxvPropertyDeclaration MMScrollArea1_GridData_Property = CxvPropertyDeclaration.Register("MMScrollArea1_GridData", typeof(MMScfrac_Input_FracIn_ViewModel), new CxvVectorProperty
		{
			ItemType = typeof(MMScrollArea1_GridData_ItemTemplate),
			IndexBasis = new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.FIEST",
				UseChildId = true,
				Name = "yfindex"
			}
		});

		public object MMScrollArea1_GridData => GetValue(MMScrollArea1_GridData_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Input_FracIn")]
	public class MMScfrac_Input_FracIn : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraFindex;

		internal MMScrollArea MMScrollArea1;

		private bool _contentLoaded;

		public MMScfrac_Input_FracIn()
		{
			base.ViewModelType = typeof(MMScfrac_Input_FracIn_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_input_fracin.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				fraFindex = (MMGroupBox)target;
				break;
			case 2:
				MMScrollArea1 = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMScfrac_Input_Specif_ViewModel : MMTabPageViewModel
	{
		private ICommand _cmdComponents_Command;

		public static readonly CxvPropertyDeclaration fraSpecs_spcid_Property = CxvPropertyDeclaration.Register("fraSpecs_spcid", typeof(MMScfrac_Input_Specif_ViewModel), new CxvParameterProperty
		{
			Parameter = "spcid"
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMScfrac_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.VALUE.@spcid",
			IsEnabledCondition = new CxvLogicalTest
			{
				Parameter = "spcid",
				Operator = CxvLogicalOperator.IdExists
			}
		});

		public static readonly CxvPropertyDeclaration cboBase_Property_var1_Property = CxvPropertyDeclaration.Register("cboBase_Property_var1", typeof(MMScfrac_Input_Specif_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.BASE_PROPERT.@spcid",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.SHSPCBSET.@spcid"
			}
		});

		public static readonly CxvPropertyDeclaration cboBase_Stream_var1_Property = CxvPropertyDeclaration.Register("cboBase_Stream_var1", typeof(MMScfrac_Input_Specif_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.BASE_STREAM.@spcid",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.SHSPCBSET.@spcid"
			}
		});

		public static readonly CxvPropertyDeclaration cboSpec_Stream_var1_Property = CxvPropertyDeclaration.Register("cboSpec_Stream_var1", typeof(MMScfrac_Input_Specif_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.SPEC_STREAM.@spcid",
			IsEnabledCondition = new CxvLogicalTest
			{
				Parameter = "spcid",
				Operator = CxvLogicalOperator.IdExists
			}
		});

		public static readonly CxvPropertyDeclaration cboProperty_var1_Property = CxvPropertyDeclaration.Register("cboProperty_var1", typeof(MMScfrac_Input_Specif_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.PROPERTY.@spcid",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.SHSPCSET.@spcid"
			}
		});

		public static readonly CxvPropertyDeclaration chkFlash_var1_Property = CxvPropertyDeclaration.Register("chkFlash_var1", typeof(MMScfrac_Input_Specif_ViewModel), new CxvBooleanProperty
		{
			DataPath = "@main.Input.FLASH.@spcid",
			TrueValue = "YES",
			FalseValue = "NO",
			DefaultValue = false,
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.SHSPCSET.@spcid"
			}
		});

		public static readonly CxvPropertyDeclaration cmdComponents_var1_Property = CxvPropertyDeclaration.Register("cmdComponents_var1", typeof(MMScfrac_Input_Specif_ViewModel), new CxvCmdButtonProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.SHSPCCOMPS.@spcid"
			}
		});

		public static readonly CxvPropertyDeclaration MMMenuButton1_var2_Property = CxvPropertyDeclaration.Register("MMMenuButton1_var2", typeof(MMScfrac_Input_Specif_ViewModel), new CxvParameterProperty
		{
			Parameter = "spcid"
		});

		public static readonly CxvPropertyDeclaration MMMenuButton1_var1_Property = CxvPropertyDeclaration.Register("MMMenuButton1_var1", typeof(MMScfrac_Input_Specif_ViewModel), new CxvAdvCollectionProperty
		{
			DataPath = "@main.Input.VALUE",
			SelectedItemBinding = "MMMenuButton1_var2.Value",
			CreateNewPrompt = "Spec ID:",
			CreateNewPromptResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvAdvCollectionProperty_CreateNewPrompt_Spec_ID_",
			CompletePaths = { "CPSPEC", "CPSPEC2", "CPSPEC3" }
		});

		public static readonly CxvPropertyDeclaration cboSpectype_MultiMap_Property = CxvPropertyDeclaration.Register("cboSpectype_MultiMap", typeof(MMScfrac_Input_Specif_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "cboSpectype_var1",
					DataPath = "@main.Input.SPECTYPE.@spcid"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Mole purity",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_Mole_purity",
					Value = "cboSpectype_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "MOLE-FRAC"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Mass purity",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_Mass_purity",
					Value = "cboSpectype_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "MASS-FRAC"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "StdVol purity",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_StdVol_purity",
					Value = "cboSpectype_MultiMapOption_3",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "STDVOL-FRAC"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Molar recovery",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_Molar_recovery",
					Value = "cboSpectype_MultiMapOption_4",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "MOLE-RECOV"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Mass recovery",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_Mass_recovery",
					Value = "cboSpectype_MultiMapOption_5",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "MASS-RECOV"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "StdVol recovery",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_StdVol_recovery",
					Value = "cboSpectype_MultiMapOption_6",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "STDVOL-RECOV"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Mole flow",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_Mole_flow",
					Value = "cboSpectype_MultiMapOption_7",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "MOLE-FLOW"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Mass flow",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_Mass_flow",
					Value = "cboSpectype_MultiMapOption_8",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "MASS-FLOW"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "StdVol flow",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_StdVol_flow",
					Value = "cboSpectype_MultiMapOption_9",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "STDVOL-FLOW"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Property value",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_Property_value",
					Value = "cboSpectype_MultiMapOption_10",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "PROP"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Property difference",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_Property_difference",
					Value = "cboSpectype_MultiMapOption_11",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "PROP-DIFF"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Property ratio",
					DisplayResourceKey = "MMScfrac_Input_Specif_ViewModel__CxvMultiMapOption_Display_Property_ratio",
					Value = "cboSpectype_MultiMapOption_12",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSpectype_var1",
							Value = "PROP-RATIO"
						}
					}
				}
			},
			IsEnabledCondition = new CxvLogicalTest
			{
				Parameter = "spcid",
				Operator = CxvLogicalOperator.IdExists
			}
		});

		public static readonly CxvPropertyDeclaration cboUnits_UOM_Property = CxvPropertyDeclaration.Register("cboUnits_UOM", typeof(MMScfrac_Input_Specif_ViewModel), new CxvParameterProperty
		{
			Parameter = "UOM",
			IsReadOnly = true,
			IsCalculated = false
		});

		public static readonly CxvPropertyDeclaration UOM_Enabled_Property = CxvPropertyDeclaration.Register("UOM_Enabled", typeof(MMScfrac_Input_Specif_ViewModel), new CxvLogicalProperty
		{
			Tests = 
			{
				new CxvLogicalTest
				{
					Parameter = "spcid",
					Operator = CxvLogicalOperator.IdExists
				}
			}
		});

		public ICommand cmdComponents_Command
		{
			get
			{
				if (_cmdComponents_Command == null)
				{
					_cmdComponents_Command = new CxvDelegateCommand<object>(cmdComponents_CommandExecute);
				}
				return _cmdComponents_Command;
			}
		}

		public object fraSpecs_spcid => GetValue(fraSpecs_spcid_Property);

		public object MMLBUText1_var1 => GetValue(MMLBUText1_var1_Property);

		public object cboBase_Property_var1 => GetValue(cboBase_Property_var1_Property);

		public object cboBase_Stream_var1 => GetValue(cboBase_Stream_var1_Property);

		public object cboSpec_Stream_var1 => GetValue(cboSpec_Stream_var1_Property);

		public object cboProperty_var1 => GetValue(cboProperty_var1_Property);

		public object chkFlash_var1 => GetValue(chkFlash_var1_Property);

		public object cmdComponents_var1 => GetValue(cmdComponents_var1_Property);

		public object MMMenuButton1_var2 => GetValue(MMMenuButton1_var2_Property);

		public object MMMenuButton1_var1 => GetValue(MMMenuButton1_var1_Property);

		public object cboSpectype_MultiMap => GetValue(cboSpectype_MultiMap_Property);

		private void cmdComponents_CommandExecute(object parameter)
		{
			DisplayFormEventArgs e2;
			DisplayFormEventArgs e = new DisplayFormEventArgs();
			e.FormProgId = "MMScfrac.MMScfrac_Input_Dialog";
			e.LegacyFlags = 0;
			e.HelpId = 0;
			e.HelpFile = "Scfrac.hlp";
			e.ShowPrompts = true;
			e.ShortName = Resources.MMScfrac_Input_Specif_ViewModel__Components_ShortName;
			e.CompleteDataPaths = new string[1] { "CPSPEC" };
			e.ResizeMode = ResizeMode.CanResizeWithGrip;
			e2 = e;
			e2.Parameters.Add("spcid", CxsConverter.ValueToString(ResolveParameter("spcid")));
			DisplayForm(e2);
		}

		public object cboUnits_UOM => GetValue(cboUnits_UOM_Property);

		public object UOM_Enabled => GetValue(UOM_Enabled_Property);

		protected override void OnSubPropertyDataChanged(CxvPropertyDeclaration pd, string subPropertyName)
		{
			base.OnSubPropertyDataChanged(pd, subPropertyName);
			if (pd.Name == "cboSpectype_MultiMap")
			{
				if (subPropertyName == "SelectedItem")
				{
			string text = CxsConverter.ValueToString(ResolveParameter("spcid"));
			if (text == null)
			{
				ResetUOM();
				return;
			}
			string text2 = CxsConverter.ValueToString(ExpandDataPathAndGet("@main.Input.SPECTYPE." + text, "value"));
			if (text2 == null)
			{
				ResetUOM();
				return;
			}
			int num = 0;
			if (text2 == "MASS-FLOW")
			{
				num = 10;
			}
			else if (text2 == "MOLE-FLOW")
			{
				num = 11;
			}
			else if (text2 == "STDVOL-FLOW")
			{
				num = 12;
			}
			if (num == 0)
			{
				ResetUOM();
				return;
			}
			num--;
			string text3 = ExpandDataPath("@main");
			string text4 = text3.Substring(0, text3.IndexOf(".Blocks."));
			string text5 = CxsConverter.ValueToString(ExpandDataPathAndGet("@main.Input.Unit Set", "value"));
			if (string.IsNullOrEmpty(text5))
			{
				text5 = CxsConverter.ValueToString(ExpandDataPathAndGet(text4 + ".Setup.Global.Input.INSET", "value"));
			}
			if (string.IsNullOrEmpty(text5))
			{
				ResetUOM();
				return;
			}
			string text6 = CxsConverter.ValueToString(ExpandDataPathAndGet(text4 + ".Setup.Units-Sets." + text5 + ".Unit-Types.#" + num, "value"));
			if (text6 != null)
			{
				ResolveUpdateParameter("UOM", text6);
			}
			else
			{
				ResetUOM();
			}
				}
			}
		}

		private void ResetUOM()
		{
			ResolveUpdateParameter("UOM", "");
		}
	}
	[ProgId("MMScfrac.MMScfrac_Input_Specif")]
	public class MMScfrac_Input_Specif : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraSpecs;

		internal MMLabel MMMenuButton1_label;

		internal MMAdvancedComboEdit MMMenuButton1;

		internal MMLabel cboSpectype_label;

		internal MMComboEdit cboSpectype;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMTextEdit cboUnits;

		internal MMLabel cboSpec_Stream_label;

		internal MMComboEdit cboSpec_Stream;

		internal MMLabel cboProperty_label;

		internal MMComboEdit cboProperty;

		internal MMLabel cboBase_Stream_label;

		internal MMComboEdit cboBase_Stream;

		internal MMLabel cboBase_Property_label;

		internal MMComboEdit cboBase_Property;

		internal MMCheckBox chkFlash;

		internal MMCmdButton cmdComponents;

		private bool _contentLoaded;

		public MMScfrac_Input_Specif()
		{
			base.ViewModelType = typeof(MMScfrac_Input_Specif_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_input_specif.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				fraSpecs = (MMGroupBox)target;
				break;
			case 2:
				MMMenuButton1_label = (MMLabel)target;
				break;
			case 3:
				MMMenuButton1 = (MMAdvancedComboEdit)target;
				break;
			case 4:
				cboSpectype_label = (MMLabel)target;
				break;
			case 5:
				cboSpectype = (MMComboEdit)target;
				break;
			case 6:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 7:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 8:
				cboUnits = (MMTextEdit)target;
				break;
			case 9:
				cboSpec_Stream_label = (MMLabel)target;
				break;
			case 10:
				cboSpec_Stream = (MMComboEdit)target;
				break;
			case 11:
				cboProperty_label = (MMLabel)target;
				break;
			case 12:
				cboProperty = (MMComboEdit)target;
				break;
			case 13:
				cboBase_Stream_label = (MMLabel)target;
				break;
			case 14:
				cboBase_Stream = (MMComboEdit)target;
				break;
			case 15:
				cboBase_Property_label = (MMLabel)target;
				break;
			case 16:
				cboBase_Property = (MMComboEdit)target;
				break;
			case 17:
				chkFlash = (MMCheckBox)target;
				break;
			case 18:
				cmdComponents = (MMCmdButton)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMScfrac_Input_Steam_ViewModel : MMTabPageViewModel
	{
		public class grdSteam_Prod_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMComboBox1_var1_Property = CxvPropertyDeclaration.Register("MMComboBox1_var1", typeof(grdSteam_Prod_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.IdWithOptions,
				DataPath = "@main.Input.STEAM:PROD.@ysteam"
			});

			public static readonly CxvPropertyDeclaration lbtuSteam_Pres_display_Property = CxvPropertyDeclaration.Register("lbtuSteam_Pres_display", typeof(grdSteam_Prod_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.STEAM_PRES.@ysteam"
			});

			public static readonly CxvPropertyDeclaration lbtuSteam_Temp_display_Property = CxvPropertyDeclaration.Register("lbtuSteam_Temp_display", typeof(grdSteam_Prod_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.STEAM_TEMP.@ysteam"
			});

			public static readonly CxvPropertyDeclaration MMLBUText1_display_Property = CxvPropertyDeclaration.Register("MMLBUText1_display", typeof(grdSteam_Prod_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.STEAM:PROD.@ysteam"
			});

			public object MMComboBox1_var1 => GetValue(MMComboBox1_var1_Property);

			public object lbtuSteam_Pres_display => GetValue(lbtuSteam_Pres_display_Property);

			public object lbtuSteam_Temp_display => GetValue(lbtuSteam_Temp_display_Property);

			public object MMLBUText1_display => GetValue(MMLBUText1_display_Property);
		}

		public static readonly CxvPropertyDeclaration grdSteam_Prod_GridData_Property = CxvPropertyDeclaration.Register("grdSteam_Prod_GridData", typeof(MMScfrac_Input_Steam_ViewModel), new CxvVectorProperty
		{
			ItemType = typeof(grdSteam_Prod_GridData_ItemTemplate),
			IndexBasis = new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.STEAM:PROD",
				UseChildId = true,
				Name = "ysteam"
			}
		});

		public object grdSteam_Prod_GridData => GetValue(grdSteam_Prod_GridData_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Input_Steam")]
	public class MMScfrac_Input_Steam : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraSteam_Prod;

		internal MMScrollArea grdSteam_Prod;

		private bool _contentLoaded;

		public MMScfrac_Input_Steam()
		{
			base.ViewModelType = typeof(MMScfrac_Input_Steam_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_input_steam.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				fraSteam_Prod = (MMGroupBox)target;
				break;
			case 2:
				grdSteam_Prod = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMScfrac_Result_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration B_PRES_Property = CxvPropertyDeclaration.Register("B_PRES", typeof(MMScfrac_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.B_PRES"
		});

		public static readonly CxvPropertyDeclaration B_TEMP_Property = CxvPropertyDeclaration.Register("B_TEMP", typeof(MMScfrac_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP"
		});

		public static readonly CxvPropertyDeclaration B_TEMP2_Property = CxvPropertyDeclaration.Register("B_TEMP2", typeof(MMScfrac_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP2"
		});

		public static readonly CxvPropertyDeclaration SECTION_Property = CxvPropertyDeclaration.Register("SECTION", typeof(MMScfrac_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.SECTION"
		});

		public static readonly CxvPropertyDeclaration FINDEX_OUT_Property = CxvPropertyDeclaration.Register("FINDEX_OUT", typeof(MMScfrac_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.FINDEX_OUT"
		});

		public static readonly CxvPropertyDeclaration ACT_STAGES_Property = CxvPropertyDeclaration.Register("ACT_STAGES", typeof(MMScfrac_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.ACT_STAGES"
		});

		public static readonly CxvPropertyDeclaration CALC_Property = CxvPropertyDeclaration.Register("CALC", typeof(MMScfrac_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.CALC"
		});

		public static readonly CxvPropertyDeclaration LINE1_Property = CxvPropertyDeclaration.Register("LINE1", typeof(MMScfrac_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.LINE1"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMScfrac_Result_ViewModel), new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@B_PRES", "@B_TEMP" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMScfrac_Result_ViewModel), new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@CALC", "@LINE1" }
		});

		public static readonly CxvPropertyDeclaration tab3_var_Property = CxvPropertyDeclaration.Register("tab3_var", typeof(MMScfrac_Result_ViewModel), new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@ACT_STAGES", "@FINDEX_OUT" }
		});

		public static readonly CxvPropertyDeclaration tab4_var_Property = CxvPropertyDeclaration.Register("tab4_var", typeof(MMScfrac_Result_ViewModel), new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@B_TEMP2", "@SECTION" }
		});

		public object B_PRES => GetValue(B_PRES_Property);

		public object B_TEMP => GetValue(B_TEMP_Property);

		public object B_TEMP2 => GetValue(B_TEMP2_Property);

		public object SECTION => GetValue(SECTION_Property);

		public object FINDEX_OUT => GetValue(FINDEX_OUT_Property);

		public object ACT_STAGES => GetValue(ACT_STAGES_Property);

		public object CALC => GetValue(CALC_Property);

		public object LINE1 => GetValue(LINE1_Property);

		public object tab0_var => GetValue(tab0_var_Property);

		public object tab2_var => GetValue(tab2_var_Property);

		public object tab3_var => GetValue(tab3_var_Property);

		public object tab4_var => GetValue(tab4_var_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Result")]
	public class MMScfrac_Result : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabScfResults;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem tab3;

		internal MMTabItem tab4;

		internal MMTabItem tabStatus;

		private bool _contentLoaded;

		public MMScfrac_Result()
		{
			base.ViewModelType = typeof(MMScfrac_Result_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_result.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				tabScfResults = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				tab3 = (MMTabItem)target;
				break;
			case 6:
				tab4 = (MMTabItem)target;
				break;
			case 7:
				tabStatus = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMScfrac_Result_Conden_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration lbtuB_Pres_var1_Property = CxvPropertyDeclaration.Register("lbtuB_Pres_var1", typeof(MMScfrac_Result_Conden_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.B_PRES"
		});

		public static readonly CxvPropertyDeclaration lbtuB_Temp_var1_Property = CxvPropertyDeclaration.Register("lbtuB_Temp_var1", typeof(MMScfrac_Result_Conden_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP"
		});

		public static readonly CxvPropertyDeclaration lbtuLiq_Flow_var1_Property = CxvPropertyDeclaration.Register("lbtuLiq_Flow_var1", typeof(MMScfrac_Result_Conden_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.LIQ_FLOW"
		});

		public static readonly CxvPropertyDeclaration lbtuVap_Flow_var1_Property = CxvPropertyDeclaration.Register("lbtuVap_Flow_var1", typeof(MMScfrac_Result_Conden_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.VAP_FLOW"
		});

		public static readonly CxvPropertyDeclaration lbtuFWDecant_var1_Property = CxvPropertyDeclaration.Register("lbtuFWDecant_var1", typeof(MMScfrac_Result_Conden_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.FWDECANT"
		});

		public object lbtuB_Pres_var1 => GetValue(lbtuB_Pres_var1_Property);

		public object lbtuB_Temp_var1 => GetValue(lbtuB_Temp_var1_Property);

		public object lbtuLiq_Flow_var1 => GetValue(lbtuLiq_Flow_var1_Property);

		public object lbtuVap_Flow_var1 => GetValue(lbtuVap_Flow_var1_Property);

		public object lbtuFWDecant_var1 => GetValue(lbtuFWDecant_var1_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Result_Conden")]
	public class MMScfrac_Result_Conden : MMTabPage, IComponentConnector
	{
		internal MMLabel lbtuB_Pres_label;

		internal MMVariableEdit lbtuB_Pres;

		internal MMLabel lbtuB_Temp_label;

		internal MMVariableEdit lbtuB_Temp;

		internal MMLabel lbtuLiq_Flow_label;

		internal MMVariableEdit lbtuLiq_Flow;

		internal MMLabel lbtuVap_Flow_label;

		internal MMVariableEdit lbtuVap_Flow;

		internal MMLabel lbtuFWDecant_label;

		internal MMVariableEdit lbtuFWDecant;

		private bool _contentLoaded;

		public MMScfrac_Result_Conden()
		{
			base.ViewModelType = typeof(MMScfrac_Result_Conden_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_result_conden.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				lbtuB_Pres_label = (MMLabel)target;
				break;
			case 2:
				lbtuB_Pres = (MMVariableEdit)target;
				break;
			case 3:
				lbtuB_Temp_label = (MMLabel)target;
				break;
			case 4:
				lbtuB_Temp = (MMVariableEdit)target;
				break;
			case 5:
				lbtuLiq_Flow_label = (MMLabel)target;
				break;
			case 6:
				lbtuLiq_Flow = (MMVariableEdit)target;
				break;
			case 7:
				lbtuVap_Flow_label = (MMLabel)target;
				break;
			case 8:
				lbtuVap_Flow = (MMVariableEdit)target;
				break;
			case 9:
				lbtuFWDecant_label = (MMLabel)target;
				break;
			case 10:
				lbtuFWDecant = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMScfrac_Result_Produc_ViewModel : MMTabPageViewModel
	{
		public class MMScrollArea1_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.Id,
				DataPath = "@main.Output.B_TEMP2.@yprod",
				DisplayedCase = CxsDisplayedCase.Uppercase
			});

			public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.SECTION.@yprod"
			});

			public static readonly CxvPropertyDeclaration txtStdVflow_var1_Property = CxvPropertyDeclaration.Register("txtStdVflow_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.STDVFLOW.@yprod"
			});

			public static readonly CxvPropertyDeclaration txtB_Massflow_var1_Property = CxvPropertyDeclaration.Register("txtB_Massflow_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.B_MASSFLOW.@yprod"
			});

			public static readonly CxvPropertyDeclaration txtB_Moleflow_var1_Property = CxvPropertyDeclaration.Register("txtB_Moleflow_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.B_MOLEFLOW.@yprod"
			});

			public static readonly CxvPropertyDeclaration txtB_Temp2_var1_Property = CxvPropertyDeclaration.Register("txtB_Temp2_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.B_TEMP2.@yprod"
			});

			public object MMTextBox2_var1 => GetValue(MMTextBox2_var1_Property);

			public object MMTextBox1_var1 => GetValue(MMTextBox1_var1_Property);

			public object txtStdVflow_var1 => GetValue(txtStdVflow_var1_Property);

			public object txtB_Massflow_var1 => GetValue(txtB_Massflow_var1_Property);

			public object txtB_Moleflow_var1 => GetValue(txtB_Moleflow_var1_Property);

			public object txtB_Temp2_var1 => GetValue(txtB_Temp2_var1_Property);
		}

		public static readonly CxvPropertyDeclaration lbtuStdVflow_display_Property = CxvPropertyDeclaration.Register("lbtuStdVflow_display", typeof(MMScfrac_Result_Produc_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.STDVFLOW"
		});

		public static readonly CxvPropertyDeclaration lbtuB_Massflow_display_Property = CxvPropertyDeclaration.Register("lbtuB_Massflow_display", typeof(MMScfrac_Result_Produc_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.B_MASSFLOW"
		});

		public static readonly CxvPropertyDeclaration lbtuB_Moleflow_display_Property = CxvPropertyDeclaration.Register("lbtuB_Moleflow_display", typeof(MMScfrac_Result_Produc_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.B_MOLEFLOW"
		});

		public static readonly CxvPropertyDeclaration lbtuB_Temp2_display_Property = CxvPropertyDeclaration.Register("lbtuB_Temp2_display", typeof(MMScfrac_Result_Produc_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP2"
		});

		public static readonly CxvPropertyDeclaration MMScrollArea1_GridData_Property = CxvPropertyDeclaration.Register("MMScrollArea1_GridData", typeof(MMScfrac_Result_Produc_ViewModel), new CxvVectorProperty
		{
			ItemType = typeof(MMScrollArea1_GridData_ItemTemplate),
			IndexBasis = new CxvChildCountIndexBasis
			{
				DataPath = "@main.Output.B_TEMP2",
				UseChildId = true,
				Name = "yprod"
			}
		});

		public object lbtuStdVflow_display => GetValue(lbtuStdVflow_display_Property);

		public object lbtuB_Massflow_display => GetValue(lbtuB_Massflow_display_Property);

		public object lbtuB_Moleflow_display => GetValue(lbtuB_Moleflow_display_Property);

		public object lbtuB_Temp2_display => GetValue(lbtuB_Temp2_display_Property);

		public object MMScrollArea1_GridData => GetValue(MMScrollArea1_GridData_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Result_Produc")]
	public class MMScfrac_Result_Produc : MMTabPage, IComponentConnector
	{
		internal MMScrollArea MMScrollArea1;

		private bool _contentLoaded;

		public MMScfrac_Result_Produc()
		{
			base.ViewModelType = typeof(MMScfrac_Result_Produc_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_result_produc.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				MMScrollArea1 = (MMScrollArea)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMScfrac_Result_Sectio_ViewModel : MMTabPageViewModel
	{
		public class MMScrollArea1_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.Id,
				DataPath = "@main.Output.FINDEX_OUT.@yprof"
			});

			public static readonly CxvPropertyDeclaration txtSteam_Flow_var1_Property = CxvPropertyDeclaration.Register("txtSteam_Flow_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.STEAM-FLOW.@yprof"
			});

			public static readonly CxvPropertyDeclaration txtDuty_var1_Property = CxvPropertyDeclaration.Register("txtDuty_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.DUTY.@yprof"
			});

			public static readonly CxvPropertyDeclaration txtB_Pres2_var1_Property = CxvPropertyDeclaration.Register("txtB_Pres2_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.B_PRES2.@yprof"
			});

			public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.ACT_STAGES.@yprof"
			});

			public static readonly CxvPropertyDeclaration txtFindex_Out_var1_Property = CxvPropertyDeclaration.Register("txtFindex_Out_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.FINDEX_OUT.@yprof"
			});

			public object MMTextBox1_var1 => GetValue(MMTextBox1_var1_Property);

			public object txtSteam_Flow_var1 => GetValue(txtSteam_Flow_var1_Property);

			public object txtDuty_var1 => GetValue(txtDuty_var1_Property);

			public object txtB_Pres2_var1 => GetValue(txtB_Pres2_var1_Property);

			public object MMTextBox2_var1 => GetValue(MMTextBox2_var1_Property);

			public object txtFindex_Out_var1 => GetValue(txtFindex_Out_var1_Property);
		}

		public static readonly CxvPropertyDeclaration lbtuB_PRES2_display_Property = CxvPropertyDeclaration.Register("lbtuB_PRES2_display", typeof(MMScfrac_Result_Sectio_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.B_PRES2"
		});

		public static readonly CxvPropertyDeclaration lbtuSteam_Flow_display_Property = CxvPropertyDeclaration.Register("lbtuSteam_Flow_display", typeof(MMScfrac_Result_Sectio_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.STEAM-FLOW"
		});

		public static readonly CxvPropertyDeclaration lbtuDuty_display_Property = CxvPropertyDeclaration.Register("lbtuDuty_display", typeof(MMScfrac_Result_Sectio_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.DUTY"
		});

		public static readonly CxvPropertyDeclaration MMScrollArea1_GridData_Property = CxvPropertyDeclaration.Register("MMScrollArea1_GridData", typeof(MMScfrac_Result_Sectio_ViewModel), new CxvVectorProperty
		{
			ItemType = typeof(MMScrollArea1_GridData_ItemTemplate),
			IndexBasis = new CxvChildCountIndexBasis
			{
				DataPath = "@main.Output.FINDEX_OUT",
				UseChildId = true,
				Name = "yprof"
			}
		});

		public object lbtuB_PRES2_display => GetValue(lbtuB_PRES2_display_Property);

		public object lbtuSteam_Flow_display => GetValue(lbtuSteam_Flow_display_Property);

		public object lbtuDuty_display => GetValue(lbtuDuty_display_Property);

		public object MMScrollArea1_GridData => GetValue(MMScrollArea1_GridData_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Result_Sectio")]
	public class MMScfrac_Result_Sectio : MMTabPage, IComponentConnector
	{
		internal MMScrollArea MMScrollArea1;

		private bool _contentLoaded;

		public MMScfrac_Result_Sectio()
		{
			base.ViewModelType = typeof(MMScfrac_Result_Sectio_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_result_sectio.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				MMScrollArea1 = (MMScrollArea)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMScfrac_Result_Specs_ViewModel : MMTabPageViewModel
	{
		public class MMScrollArea2_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration cboSpectype_MultiMap_Property = CxvPropertyDeclaration.Register("cboSpectype_MultiMap", typeof(MMScrollArea2_GridData_ItemTemplate), new CxvMultiMapProperty
			{
				Variables = 
				{
					new CxvMultiMapVariable
					{
						Name = "cboSpectype_var1",
						DataPath = "@main.Output.LINE1.@ydsres"
					}
				},
				Options = 
				{
					new CxvMultiMapOption
					{
						Display = "Mole purity",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_Mole_purity",
						Value = "cboSpectype_MultiMapOption_1",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "MOLE-FRA"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "Mass purity",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_Mass_purity",
						Value = "cboSpectype_MultiMapOption_2",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "MASS-FRA"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "StdVol purity",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_StdVol_purity",
						Value = "cboSpectype_MultiMapOption_3",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "STDVOL-F"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "Molar recovery",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_Molar_recovery",
						Value = "cboSpectype_MultiMapOption_4",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "MOLE-REC"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "Mass recovery",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_Mass_recovery",
						Value = "cboSpectype_MultiMapOption_5",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "MASS-REC"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "StdVol recovery",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_StdVol_recovery",
						Value = "cboSpectype_MultiMapOption_6",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "STDVOL-R"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "Mole flow",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_Mole_flow",
						Value = "cboSpectype_MultiMapOption_7",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "MOLE-FLO"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "Mass flow",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_Mass_flow",
						Value = "cboSpectype_MultiMapOption_8",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "MASS-FLO"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "StdVol flow",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_StdVol_flow",
						Value = "cboSpectype_MultiMapOption_9",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "STDVOL-F"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "Property value",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_Property_value",
						Value = "cboSpectype_MultiMapOption_10",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "PROP"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "Property difference",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_Property_difference",
						Value = "cboSpectype_MultiMapOption_11",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "PROP-DIF"
							}
						}
					},
					new CxvMultiMapOption
					{
						Display = "Property ratio",
						DisplayResourceKey = "MMScfrac_Result_Specs_ViewModel__CxvMultiMapOption_Display_Property_ratio",
						Value = "cboSpectype_MultiMapOption_12",
						Values = 
						{
							new CxvMultiMapValue
							{
								Variable = "cboSpectype_var1",
								Value = "PROP-RAT"
							}
						}
					}
				}
			});

			public static readonly CxvPropertyDeclaration txtCalc_var1_Property = CxvPropertyDeclaration.Register("txtCalc_var1", typeof(MMScrollArea2_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.CALC.@ydsres"
			});

			public static readonly CxvPropertyDeclaration txtError_var1_Property = CxvPropertyDeclaration.Register("txtError_var1", typeof(MMScrollArea2_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.ERR.@ydsres"
			});

			public static readonly CxvPropertyDeclaration txtSpec_var1_Property = CxvPropertyDeclaration.Register("txtSpec_var1", typeof(MMScrollArea2_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.SPEC.@ydsres"
			});

			public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMScrollArea2_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.Id,
				DataPath = "@main.Output.CALC.@ydsres",
				DisplayedCase = CxsDisplayedCase.Uppercase
			});

			public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(MMScrollArea2_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.LINE2.@ydsres",
				DisplayedCase = CxsDisplayedCase.Uppercase
			});

			public object cboSpectype_MultiMap => GetValue(cboSpectype_MultiMap_Property);

			public object txtCalc_var1 => GetValue(txtCalc_var1_Property);

			public object txtError_var1 => GetValue(txtError_var1_Property);

			public object txtSpec_var1 => GetValue(txtSpec_var1_Property);

			public object MMTextBox1_var1 => GetValue(MMTextBox1_var1_Property);

			public object MMTextBox3_var1 => GetValue(MMTextBox3_var1_Property);
		}

		public static readonly CxvPropertyDeclaration MMScrollArea2_GridData_Property = CxvPropertyDeclaration.Register("MMScrollArea2_GridData", typeof(MMScfrac_Result_Specs_ViewModel), new CxvVectorProperty
		{
			ItemType = typeof(MMScrollArea2_GridData_ItemTemplate),
			IndexBasis = new CxvChildCountIndexBasis
			{
				DataPath = "@main.Output.CALC",
				UseChildId = true,
				Name = "ydsres"
			}
		});

		public object MMScrollArea2_GridData => GetValue(MMScrollArea2_GridData_Property);
	}
	[ProgId("MMScfrac.MMScfrac_Result_Specs")]
	public class MMScfrac_Result_Specs : MMTabPage, IComponentConnector
	{
		internal MMScrollArea MMScrollArea2;

		private bool _contentLoaded;

		public MMScfrac_Result_Specs()
		{
			base.ViewModelType = typeof(MMScfrac_Result_Specs_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Scfrac;component/mmscfrac_result_specs.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				MMScrollArea2 = (MMScrollArea)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
}

namespace XamlGeneratedNamespace
{
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class GeneratedInternalTypeHelper : InternalTypeHelper
	{
		protected override object CreateInstance(Type type, CultureInfo culture)
		{
			return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.CreateInstance, null, null, culture);
		}

		protected override object GetPropertyValue(PropertyInfo propertyInfo, object target, CultureInfo culture)
		{
			return propertyInfo.GetValue(target, BindingFlags.Default, null, null, culture);
		}

		protected override void SetPropertyValue(PropertyInfo propertyInfo, object target, object value, CultureInfo culture)
		{
			propertyInfo.SetValue(target, value, BindingFlags.Default, null, null, culture);
		}

		protected override Delegate CreateDelegate(Type delegateType, object target, string handler)
		{
			return (Delegate)target.GetType().InvokeMember("_CreateDelegate", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, target, new object[2] { delegateType, handler }, null);
		}

		protected override void AddEventHandler(EventInfo eventInfo, object target, Delegate handler)
		{
			eventInfo.AddEventHandler(target, handler);
		}
	}
}