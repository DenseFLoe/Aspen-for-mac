# 静态证据复查

`cil-managed.json` 和 `satellite-managed.json` 由 `tools/managed/Program.cs` 生成，记录实际比较结果。源码使用 .NET SDK 9 与 Mono.Cecil 0.11.6（实测 DLL SHA-256 `831dca77470d85cb6ffbea3072daa7a3df5b7c9fcfd9c3f43674a9be99d4bfcf`）。在新目录复制项目和源码，将 Mono.Cecil.dll 放在项目旁，执行如下命令。依次将主件和卫星各自原件/产物传入。

```powershell
dotnet build Audit.csproj --nologo
dotnet .\bin\Debug\net9.0\Audit.dll <original.dll> <rebuilt.dll> <comparison.json>
```

`main-pe.json` 和 `satellite-pe.json` 使用 Python 3 与 pefile 2024.8.26 读取原版、候选 PE。该比较使用资源树的叶路径、语言、代码页、长度和 payload SHA-256。原版签名由 `Get-AuthenticodeSignature -LiteralPath <file>` 检查。

```powershell
py -3 -B .\evidence\tools\pe_audit.py <original.dll> <rebuilt.dll> <pe-report.json>
```

`tools/BamlEvidence.cs` 用 .NET SDK 9、ILSpy 9.1 系列的 ICSharpCode.BamlDecompiler 和 ICSharpCode.Decompiler 编译。实测两 DLL SHA-256 依次为 `0ab41a9be38d43c6be522fb9659d77b00b3991557c665fa5877d0cabe5123be2` 和 `2e47c9b7557d071935f4730d5cd692162bd0f6266ce7d29f1d13ffeb6b2dae75`。该脚本只读源或候选主件和卫星。原件关联程序集的搜索路径仅供 ILSpy 解释类型和连接方法。

```powershell
dotnet BamlEvidence.dll <code DLL> <satellite DLL> <XAML output directory> <WpfPlotWizards reference dir> <Xeq reference dir>
py -3 -B .\evidence\tools\layout_audit.py .\source\main\WpfPLBatchSep.dll.il .\layout .\evidence\baml-sha256.tsv <layout-report.json>
```

`baml-sha256.tsv` 是资源键、payload 长度和 SHA-256。分别解码原件和候选时，该表逐行一致，导出的 14 个 XAML 也逐份一致。 `wpf-layout.json` 以键、程序集 URI、XAML 文件及 CIL 连接方法为索引，表达式的文字值取自 ILSpy 对实际 BAML 的解码。
