# Temperature.cs

Source: editable/WpfPLConSep/Temperature.cs

Source SHA-256: 25f5443294f4bec9177abf16c7e0f08c3ecc1972abf64b84e7b79509e619c755
