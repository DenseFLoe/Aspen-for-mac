using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPlotwizard;

namespace WpfPLMCompr;

[ProgId("WpfPLMCompr.Efficiency")]
public class Efficiency : IRibbonPlotWizardType
{
	private IHNode _context;

	private IHWizardPlot2 _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private int _nMap;

	private int _nCurves;

	private int _mapNum;

	private string _uniqueId = WpfPLMComprResources.Efficiency_ID;

	private string _plotName;

	private object _nodeCxs;

	private Image _imgBitmap;

	private bool _bHasInputDialog;

	private readonly string _mapNumFieldId = WpfPLMComprResources.Map_number;

	private bool _bCheckDataOnly;

	public string TooltipContentForRibbonItem => WpfPLMComprResources.TooltipContentForRibbonItem_Efficiency;

	public string TooltipHeaderForRibbonItem => WpfPLMComprResources.TooltipHeaderForRibbonItem_Efficiency;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot2;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _mapNumFieldId };

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public Efficiency()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		_mapNum = 1;
		_bHasInputDialog = false;
		if (_imgBitmap == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLMCompr.Images.Efficiency.ico");
			_imgBitmap = new Bitmap(manifestResourceStream);
		}
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		if (sFieldName.CompareTo(_mapNumFieldId) == 0)
		{
			List<string> list = new List<string>();
			for (int i = 0; i < _nMap; i++)
			{
				list.Add((i + 1).ToString());
			}
			return list;
		}
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
		if (sFieldName.CompareTo(_mapNumFieldId) == 0)
		{
			_mapNum = 1;
			sCurrentVal = _mapNum.ToString();
		}
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
		if (sFieldName.CompareTo(_mapNumFieldId) == 0)
		{
			_mapNum = Convert.ToInt32(sValue);
		}
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot2;
		IHNode iHNode = _context.FindNode("Input/OPT_CFORMAT");
		if (((dynamic)iHNode.get_Value(Type.Missing)).ToString().ToUpper() == "TABLE")
		{
			iHNode = _context.FindNode("Input/NMAP");
			_nMap = ((int?)(dynamic)iHNode.get_Value(Type.Missing)).GetValueOrDefault(0);
			if (_nMap <= 0)
			{
				ierror = 1;
				return;
			}
			iHNode = _context.FindNode("Input/NCURVES");
			_nCurves = ((int?)(dynamic)iHNode.get_Value(Type.Missing)).GetValueOrDefault(0);
			if (_nCurves <= 0)
			{
				ierror = 1;
				return;
			}
			iHNode = _context.FindNode("Input/EF_FLOW");
			if (iHNode == null || iHNode.Elements.Count <= 0)
			{
				ierror = 1;
			}
		}
		else
		{
			ierror = 1;
		}
	}

	public void UpdateWizardData()
	{
		IHNode iHNode = null;
		string text = "";
		_wizardPlot.RemoveAllIndependentVariable();
		_wizardPlot.RemoveAllDependentVariable();
		_wizardPlot.PlotVal.Title = WpfPLMComprResources.Efficiency_Title;
		if (_nCurves > 1)
		{
			iHNode = _context.FindNode("Input/OPT_MACHNO");
			if (iHNode != null && ((dynamic)iHNode.get_Value(Type.Missing)).ToString().ToUpper() == "YES")
			{
				iHNode = _context.FindNode("Input/MACH_NO");
				text = WpfPLMComprResources.Mach_No + " = ";
			}
			else
			{
				iHNode = _context.FindNode("Input/SHAFT_SPEED");
				text = WpfPLMComprResources.Shaft_speed + " = ";
			}
			text = WpfPLMComprResources.Mach_No + " = " + _mapNum + " " + text;
		}
		for (int i = 0; i < _nCurves; i++)
		{
			string text2 = _mapNum + "/" + (i + 1);
			_wizardPlot.SetMultIndependentVariables(_context, "Input/EF_FLOW/" + text2);
			_wizardPlot.AddDependentVariable(_context, "Input/EFF_DATA/" + text2);
			if (_nCurves > 1)
			{
				string label = text + (dynamic)iHNode.Elements[_mapNum - 1, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
				((IHPlotVal)_wizardPlot.PlotVal).set_Label(i, label);
			}
		}
		string text3 = (dynamic)_context.FindNode("Input/EF_FLOW_UNIT").get_Value(Type.Missing);
		_wizardPlot.PlotVal.Title = WpfPLMComprResources.Efficiency_Title;
		_wizardPlot.PlotVal.XAxisTitle = WpfPLMComprResources.Performance_XAxisTitle;
		if (!string.IsNullOrEmpty(text3))
		{
			CHPlotVal plotVal = _wizardPlot.PlotVal;
			plotVal.XAxisTitle = plotVal.XAxisTitle + " " + text3.ToLower();
		}
		((IHPlotVal)_wizardPlot.PlotVal).set_YAxisTitle((object)null, WpfPLMComprResources.Efficiency_YAxisTitle);
	}
}
