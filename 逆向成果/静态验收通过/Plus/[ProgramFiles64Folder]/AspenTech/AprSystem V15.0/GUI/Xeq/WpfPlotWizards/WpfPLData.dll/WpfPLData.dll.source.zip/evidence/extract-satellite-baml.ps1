param(
    [Parameter(Mandatory)][string]$Satellite,
    [Parameter(Mandatory)][string]$OutBaml,
    [Parameter(Mandatory)][string]$Cecil
)
$ErrorActionPreference = 'Stop'
$expectedSatellite = 'c5ba599e2cd845db870d7494a86f68f66b7a5071f06ecab636ec3e0a5a8284a5'
$expectedBaml = '9229871289aba90b98c5623e882f2be6768e3f8019275cc93ce368183c822b3f'
if ((Get-FileHash -LiteralPath $Satellite).Hash -ne $expectedSatellite) {
    throw 'Satellite fingerprint differs from the reviewed en-US dependency'
}
$out = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutBaml)
if ([IO.File]::Exists($out)) { throw 'Choose a new BAML output path' }
Add-Type -Path (Resolve-Path -LiteralPath $Cecil)
$module = [Mono.Cecil.ModuleDefinition]::ReadModule((Resolve-Path -LiteralPath $Satellite).Path)
try {
    $resource = $module.Resources | Where-Object Name -CEQ 'WpfPLData.g.en-US.resources'
    $reader = [Resources.ResourceReader]::new($resource.GetResourceStream())
    try {
        $kind = $null
        $data = $null
        $reader.GetResourceData('datacurve.baml', [ref]$kind, [ref]$data)
        if ($kind -ne 'ResourceTypeCode.Stream' -or [BitConverter]::ToInt32($data, 0) -ne $data.Length - 4) {
            throw 'Unexpected resource data encoding'
        }
        [byte[]]$baml = $data[4..($data.Length - 1)]
        $digest = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($baml))
        if ($digest -ne $expectedBaml) { throw 'BAML fingerprint differs' }
        [IO.File]::WriteAllBytes($out, $baml)
    } finally {
        $reader.Dispose()
    }
} finally {
    $module.Dispose()
}
