# Performance.cs

Source: editable/WpfPLMCompr/Performance.cs

Source SHA-256: ffed3f356be01eaee66b2382de711ca6993a16d9b538b25c46a34cc829aec518
