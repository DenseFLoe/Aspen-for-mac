using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Text;

static partial class ResolvedCilEvidence
{
    static object PeDetails(PEReader pe, MetadataReader metadata, string path)
    {
        var headers = pe.PEHeaders;
        var cor = headers.CorHeader!;
        var header = headers.PEHeader!;
        var clr = cor.ResourcesDirectory;
        var win32 = header.ResourceTableDirectory;
        var certificate = header.CertificateTableDirectory;
        var managed = clr.Size > 0
            ? pe.GetSectionData(clr.RelativeVirtualAddress).GetContent(0, clr.Size).ToArray()
            : Array.Empty<byte>();
        var table = win32.Size > 0
            ? pe.GetSectionData(win32.RelativeVirtualAddress).GetContent(0, win32.Size).ToArray()
            : Array.Empty<byte>();
        var leaves = new List<object>();
        if (table.Length > 0)
            Visit(0, string.Empty, 0);
        string? certDigest = null;
        if (certificate.Size > 0)
        {
            byte[] bytes = new byte[certificate.Size];
            using var file = File.OpenRead(path);
            file.Position = certificate.RelativeVirtualAddress; // The security directory uses a file offset.
            file.ReadExactly(bytes);
            certDigest = Digest(bytes);
        }
        return new {
            sha256 = Digest(File.ReadAllBytes(path)),
            file_bytes = new FileInfo(path).Length,
            machine = headers.CoffHeader.Machine.ToString(), clr_flags = cor.Flags.ToString(),
            linker = $"{header.MajorLinkerVersion}.{header.MinorLinkerVersion}",
            coff_timestamp = headers.CoffHeader.TimeDateStamp,
            checksum = header.CheckSum,
            mvid = metadata.GetGuid(metadata.GetModuleDefinition().Mvid),
            debug = pe.ReadDebugDirectory().Select(e => new { kind = e.Type.ToString(), e.DataSize }).ToArray(),
            certificate_bytes = certificate.Size, certificate_sha256 = certDigest,
            strong_name_bytes = cor.StrongNameSignatureDirectory.Size,
            win32_resources = leaves,
            managed_resource_region = new { bytes = managed.Length, sha256 = Digest(managed) },
            managed_resources = metadata.ManifestResources.Select(handle =>
            {
                var manifest = metadata.GetManifestResource(handle);
                if (!manifest.Implementation.IsNil)
                    throw new BadImageFormatException("External resource is outside this reader's coverage.");
                int offset = checked((int)manifest.Offset);
                int length = BinaryPrimitives.ReadInt32LittleEndian(managed.AsSpan(offset, 4));
                return new { name = metadata.GetString(manifest.Name), visibility = manifest.Attributes.ToString(),
                    bytes = length, sha256 = Digest(managed.AsSpan(offset + 4, length).ToArray()) };
            }).ToArray(),
        };

        void Visit(int offset, string parent, int depth)
        {
            if (depth > 6)
                throw new BadImageFormatException("Invalid Win32 resource directory depth.");
            int count = U16(offset + 12) + U16(offset + 14);
            for (int j = 0; j < count; j++)
            {
                int entry = checked(offset + 16 + 8 * j);
                uint name = U32(entry);
                uint location = U32(entry + 4);
                int at = (int)(location & 0x7fffffff);
                int textOffset = (int)(name & 0x7fffffff);
                string key = parent + "/" + ((name & 0x80000000) != 0
                    ? Encoding.Unicode.GetString(table.AsSpan(textOffset + 2, 2 * U16(textOffset)))
                    : name.ToString());
                if ((location & 0x80000000) != 0)
                {
                    Visit(at, key, depth + 1);
                }
                else
                {
                    int rva = checked((int)U32(at));
                    int size = checked((int)U32(at + 4));
                    var payload = pe.GetSectionData(rva).GetContent(0, size).ToArray();
                    leaves.Add(new { key, bytes = size, codepage = U32(at + 8), sha256 = Digest(payload) });
                }
            }
        }
        ushort U16(int at) => BinaryPrimitives.ReadUInt16LittleEndian(table.AsSpan(at, 2));
        uint U32(int at) => BinaryPrimitives.ReadUInt32LittleEndian(table.AsSpan(at, 4));
    }
}
