import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re
from xml.etree import ElementTree as ET

X = "{http://schemas.microsoft.com/winfx/2006/xaml}"
PACK = "/WpfPLBatchSep;component/"

def local(tag):
    return tag.rsplit("}", 1)[-1]

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def match_lines(body, opcode, member):
    return [m.group(1) for m in re.finditer(
        r"\b(IL_[0-9a-f]+):\s+" + re.escape(opcode) + r"\s+[^\r\n]*::'?" + re.escape(member) + r"['(\s]*$",
        body, re.M
    )]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("il", type=Path)
    parser.add_argument("xaml_root", type=Path)
    parser.add_argument("payload_index", type=Path)
    parser.add_argument("report", type=Path)
    args = parser.parse_args()
    il = args.il.read_text(encoding="utf-8-sig")
    payloads = dict((key, {"length": int(size), "sha256": digest_})
                    for key, size, digest_ in (line.split() for line in
                    args.payload_index.read_text(encoding="utf-8-sig").splitlines()))
    bodies = {}
    for m in re.finditer(r"^\s*\.method\b(.+?)^\s*\} // end of method ([^\r\n]+)", il, re.M | re.S):
        bodies.setdefault(m[2], []).append(m[1])

    def method_body(typename, method):
        values = bodies.get(typename + "::" + method, [])
        if len(values) > 1:
            raise ValueError("Unexpected ambiguous method " + typename + "::" + method)
        return values[0] if values else ""

    load_uris = {}
    for key in bodies:
        if not key.endswith("::InitializeComponent"):
            continue
        owner = key.split("::")[0]
        block = method_body(owner, "InitializeComponent")
        if "System.Windows.Application::LoadComponent" not in block:
            raise ValueError("WPF loader call missing for " + owner)
        m = re.search(r'\bldstr\s+"([^"]+)"(?:\s*\+\s*"([^"]+)")?', block)
        uri = (m[1] + (m[2] or "")) if m else ""
        if not uri.startswith(PACK) or not uri.endswith(".xaml"):
            raise ValueError("Unexpected WPF URI " + uri)
        load_uris[uri[len(PACK):]] = owner

    layouts = []
    unresolved = []
    for path in sorted(args.xaml_root.rglob("*.xaml")):
        key = path.relative_to(args.xaml_root).as_posix()
        markup = ET.parse(path).getroot()
        classname = markup.attrib[X + "Class"]
        typename = classname.rsplit(".", 1)[-1]
        if load_uris[key] != typename:
            raise ValueError("Pack URI class differs from XAML x:Class: " + key)
        connector = method_body(typename, "System.Windows.Markup.IComponentConnector.Connect")
        style = method_body(typename, "System.Windows.Markup.IStyleConnector.Connect")
        if not connector:
            raise ValueError("Missing IComponentConnector: " + key)
        owner_prefix = typename + "::"
        constructor = "\n".join(bodies.get(owner_prefix + ".ctor", []))
        controls = []
        events = []
        bindings = []
        commands = []
        event_names = set(re.findall(r"\bldftn\s+[^\r\n]*::([\w.]+)\(", connector + style))
        event_properties = {
            "Checked", "Click", "Closed", "ColumnReordered", "DropDownClosed", "GotFocus", "Handler",
            "Loaded", "MouseDoubleClick", "PreviewMouseDoubleClick", "SelectionChanged", "SizeChanged",
            "SelectedItemChanged", "Sorting", "Unloaded", "Unchecked"
        }
        for node in markup.iter():
            nt = local(node.tag)
            name = node.get(X + "Name") or node.get("Name")
            if name:
                stores = match_lines(connector, "stfld", name)
                controls.append({"type": nt, "name": name, "connector_stfld": stores})
                if not stores:
                    unresolved.append(f"{key}: named control without connector store: {name}")
            for prop, value in node.attrib.items():
                if prop in event_properties and not value.startswith("{"):
                    if value not in event_names:
                        unresolved.append(f"{key}: event callback absent from Connect: {value}")
                    events.append({"element": nt, "name": name, "event": prop, "handler": value,
                                   "has_method_def": owner_prefix + value in bodies})
                    if owner_prefix + value not in bodies:
                        unresolved.append(f"{key}: event callback declaration absent: {value}")
                if re.match(r"\{(?:Binding|MultiBinding|PriorityBinding|TemplateBinding)(?:\s|\})", value):
                    leaf = re.match(r"\{Binding\s+(?:Path=)?([\w.]+)", value)
                    prop_name = leaf[1] if leaf else None
                    matches = sorted(k for k in bodies if prop_name and k.endswith("::get_" + prop_name))
                    bindings.append({"element": nt, "name": name, "property": prop,
                                     "expression": value, "matching_managed_getters": matches})
                if prop == "Command":
                    command = re.search(r"\.([A-Za-z_]\w*)\}", value)
                    registered = bool(command and f"{classname}::{command[1]}" in constructor
                        and "System.Windows.Input.CommandBinding::.ctor" in constructor)
                    commands.append({"element": nt, "expression": value, "registered_in_constructor": registered})
                    if not registered:
                        unresolved.append(f"{key}: command constructor registration absent: {value}")
        tags = Counter(local(n.tag) for n in markup.iter())
        resource = key[:-len(".xaml")] + ".baml"
        layouts.append({"xaml": key, "uri": PACK + key, "baml": resource, "payload": payloads[resource],
            "xaml_sha256": digest(path), "class": classname, "elements": sum(tags.values()), "tags": dict(tags),
            "component_connector": bool(connector), "style_connector": bool(style),
            "fields": controls, "events": events, "commands": commands, "bindings": bindings,
            "connector_event_callbacks": sorted(event_names)})
    scanned_files = {item["xaml"] for item in layouts}
    if set(load_uris) != scanned_files or set(payloads) != {item["baml"] for item in layouts}:
        raise ValueError("WPF loader, BAML keys, and XAML files do not have identical basenames")
    args.report.write_text(json.dumps({
        "layout_count": len(layouts),
        "named_fields": sum(len(row["fields"]) for row in layouts),
        "markup_events": sum(len(row["events"]) for row in layouts),
        "markup_bindings": sum(len(row["bindings"]) for row in layouts),
        "markup_commands": sum(len(row["commands"]) for row in layouts),
        "unresolved": unresolved,
        "layouts": layouts,
    }, indent=2) + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()
