#!/usr/bin/env python3
"""Reproduce AspenTech.AspenPlus.MMForms.Utility.dll (9d0c8274) from this archive.

Usage:  py -3 reproduce.py <this-archive.zip> <empty-output-directory>

Steps (all gates are hard failures):
  1. extract the archive to <out>/_pkg
  2. verify build inputs, pinned reference assemblies and the pinned compiler by SHA-256
  3. recompile editable/ with the archive's compiler/ (csc.exe 3.8.0; a .NET Framework
     executable invoked DIRECTLY, not via 'dotnet <csc.dll>'), cwd = package root and
     RELATIVE source/output paths, so the candidate SHA-256 is layout independent
  4. verify the compiled candidate SHA-256 == build-plan.compiler_output_sha256
  5. replay: token relocation + archived CLR metadata / debug record / certificate table
     (token_replay.reproduce), then verify the final image SHA-256 == original_sha256

The replay replaces the CLR metadata, strong name, certificate table and CLR prefix with
bytes preserved from the original; method bodies come from the recompiled candidate after
token relocation.  Do not describe the result as a complete source rebuild.
"""
import json, os, subprocess, sys, zipfile
from hashlib import sha256

def digest(path):
    h = sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    if len(sys.argv) != 3:
        print(__doc__); return 2
    archive = os.path.abspath(sys.argv[1])
    out = os.path.abspath(sys.argv[2])
    if os.path.exists(out) and os.listdir(out):
        print('output directory must be empty:', out); return 2
    os.makedirs(out, exist_ok=True)
    pkg = os.path.join(out, '_pkg')
    with zipfile.ZipFile(archive) as z:
        z.extractall(pkg)
    plan = json.load(open(os.path.join(pkg, 'build-plan.json'), encoding='utf-8'))
    # 2. inputs / compiler / references
    for name, expected in plan['build_input_sha256'].items():
        actual = digest(os.path.join(pkg, name))
        if actual != expected:
            print('build input mismatch:', name); return 1
    compiler = os.path.join(pkg, plan['compiler']['file'])
    if digest(compiler) != plan['compiler']['sha256']:
        print('pinned compiler mismatch'); return 1
    for name, expected in plan['references'].items():
        if not os.path.isfile(name) or digest(name) != expected:
            print('pinned reference missing or changed:', name); return 1
    # 3. compile (cwd = package root, relative paths)
    flags = list(plan['fixed_flags'])
    flags += ['/out:' + plan['compile_layout']['output'],
              '/win32res:' + plan['compile_layout']['win32res']]
    flags += ['/reference:"' + name + '"' for name in plan['references']]
    flags += [plan['compile_layout']['source']]
    rsp = os.path.join(pkg, 'compile.rsp')
    open(rsp, 'w', encoding='utf-8').write('\n'.join(flags) + '\n')
    proc = subprocess.run([compiler, '@compile.rsp'], cwd=pkg, capture_output=True)
    if proc.returncode:
        print((proc.stdout + proc.stderr).decode('utf-8', 'replace')[-3000:]); return 1
    compiled = os.path.join(pkg, plan['compile_layout']['output'])
    candidate = digest(compiled)
    # 4. candidate gate
    if candidate != plan['compiler_output_sha256']:
        print('candidate SHA-256 %s != pinned %s' % (candidate, plan['compiler_output_sha256'])); return 1
    # 5. replay
    sys.path.insert(0, os.path.join(pkg, 'tools'))
    import token_replay  # noqa: E402  (vendored, unmodified frozen legacy chain)
    recipe = json.load(open(os.path.join(pkg, 'layout-recipe.json'), encoding='utf-8'))
    ob = os.path.join(pkg, 'original-build')
    metadata = open(os.path.join(ob, 'clr-metadata.bin'), 'rb').read()
    debug = open(os.path.join(ob, 'debug-record.bin'), 'rb').read()
    certificate = open(os.path.join(ob, 'certificate-table.bin'), 'rb').read()
    result = token_replay.reproduce(open(compiled, 'rb').read(), recipe, metadata, debug, certificate, b'')
    rebuilt = sha256(result).hexdigest()
    ok = rebuilt == plan['original_sha256'] and len(result) == plan['original_bytes']
    exact = os.path.join(out, 'exact')
    os.makedirs(exact, exist_ok=True)
    open(os.path.join(exact, plan['assembly_name']), 'wb').write(result)
    print(json.dumps({'equal': ok, 'rebuilt_sha256': rebuilt,
                      'original_sha256': plan['original_sha256'],
                      'original_bytes': plan['original_bytes'], 'rebuilt_bytes': len(result),
                      'candidate_sha256': candidate,
                      'methods_replayed': len(recipe['verified_methods']),
                      'recipe_gaps': len(recipe.get('gaps', []))}, ensure_ascii=False, indent=1))
    return 0 if ok else 1

if __name__ == '__main__':
    sys.exit(main())