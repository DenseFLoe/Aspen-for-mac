#!/usr/bin/env python3
"""Append this lane's replay tools to the recipe package (self-contained)."""
import sys
import zipfile
from hashlib import sha256
from pathlib import Path

EXTRA = ("token_replay3.py", "pe_layout3.py", "replay2.py", "pe_layout2.py", "build_recipe2.py",
         "make_source2.py", "derive_rules2.py", "declaration_restore3.py",
         "compare_methods.py", "make_pkg.py", "finalize_pkg3.py")


def main(src, out, tool_dir):
    src, out, tool_dir = Path(src), Path(out), Path(tool_dir)
    with zipfile.ZipFile(src) as z:
        members = {n: z.read(n) for n in z.namelist()}
    for name in EXTRA:
        path = tool_dir / name
        if not path.exists() and (tool_dir.parent / "managed-override-1" / name).exists():
            path = tool_dir.parent / "managed-override-1" / name
        members["tools/" + name] = path.read_bytes()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(members):
            z.writestr(n, members[n])
    print(sha256(out.read_bytes()).hexdigest(), out)


if __name__ == "__main__":
    main(*sys.argv[1:4])
