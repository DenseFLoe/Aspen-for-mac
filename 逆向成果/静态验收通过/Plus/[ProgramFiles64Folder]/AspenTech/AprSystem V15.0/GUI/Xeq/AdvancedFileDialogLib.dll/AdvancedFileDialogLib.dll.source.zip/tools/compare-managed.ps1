param(
    [Parameter(Mandatory = $true)][string]$Original,
    [Parameter(Mandatory = $true)][string]$Candidate,
    [Parameter(Mandatory = $true)][string]$Report
)
$ErrorActionPreference = 'Stop'
Add-Type -LiteralPath (Join-Path $PSScriptRoot 'Mono.Cecil.dll')

function As-CanonJson($value) {
    ConvertTo-Json -InputObject $value -Depth 16 -Compress
}

function Type-Key($type) {
    if ($null -eq $type) { return $null }
    if ($type.Scope -is [Mono.Cecil.ModuleDefinition]) {
        $scope = 'module:' + $type.Scope.Name
    } else {
        $scope = [string]$type.Scope
    }
    return $type.FullName + ' @ ' + $scope
}

function Member-Key($ref) {
    if ($ref -is [Mono.Cecil.TypeReference]) { return Type-Key $ref }
    if ($ref -is [Mono.Cecil.FieldReference]) { return $ref.Name + '|' + (Type-Key $ref.DeclaringType) + '|' + (Type-Key $ref.FieldType) }
    if ($ref -is [Mono.Cecil.MethodReference]) {
        $params = @(foreach ($p in $ref.Parameters) { Type-Key $p.ParameterType })
        return $ref.Name + '|' + (Type-Key $ref.DeclaringType) + '|' + (Type-Key $ref.ReturnType) + '|' +
            ($params -join ',') + '|' + $ref.HasThis + '|' + $ref.ExplicitThis + '|' + [int]$ref.CallingConvention
    }
    throw "Unhandled bound member $ref"
}

function Attributes($provider) {
    @(foreach ($attr in $provider.CustomAttributes) {
        (Member-Key $attr.Constructor) + '=' + [Convert]::ToHexString($attr.GetBlob())
    }) | Sort-Object -CaseSensitive
}

function Param-Row($param) {
    $marshal = if ($param.HasMarshalInfo) {
        if ($param.MarshalInfo.GetType().FullName -ne 'Mono.Cecil.MarshalInfo') {
            throw "Unhandled marshal descriptor $($param.MarshalInfo.GetType().FullName)"
        }
        [int]$param.MarshalInfo.NativeType
    }
    [ordered]@{
        name = [string]$param.Name
        type = Type-Key $param.ParameterType
        flags = [int]$param.Attributes
        constant = $param.Constant
        marshal = $marshal
        custom = @(Attributes $param)
    }
}

function Method-Decl($method) {
    [ordered]@{
        key = Member-Key $method
        attributes = [int]$method.Attributes
        implementation = [int]$method.ImplAttributes
        semantics = [int]$method.SemanticsAttributes
        has_body = $method.HasBody
        result = Param-Row $method.MethodReturnType
        parameters = @(foreach ($p in $method.Parameters) { Param-Row $p })
        overrides = @(foreach ($o in $method.Overrides) { Member-Key $o })
        custom = @(Attributes $method)
    }
}

function Target-Offset($instruction, $end) {
    if ($null -eq $instruction) { return $end }
    return $instruction.Offset
}

function Method-Body($method) {
    if (!$method.HasBody) { return $null }
    $body = $method.Body
    [ordered]@{
        code_size = $body.CodeSize
        max_stack = $body.MaxStackSize
        init_locals = $body.InitLocals
        locals = @(foreach ($v in $body.Variables) { Type-Key $v.VariableType })
        instructions = @(foreach ($ins in $body.Instructions) {
            $value = $ins.Operand
            $binding = $value -is [Mono.Cecil.MemberReference]
            if ($binding) {
                $value = Member-Key $value
            } elseif ($value -is [Mono.Cecil.Cil.Instruction]) {
                $value = 'branch:' + $value.Offset
            } elseif ($value -is [Mono.Cecil.Cil.Instruction[]]) {
                $value = 'switch:' + ($value.Offset -join ',')
            } elseif ($value -is [Mono.Cecil.Cil.VariableDefinition]) {
                $value = 'local:' + $value.Index
            } elseif ($value -is [Mono.Cecil.ParameterDefinition]) {
                $value = 'arg:' + $value.Index
            }
            [ordered]@{ offset = $ins.Offset; opcode = $ins.OpCode.Name; operand = $value; binding = $binding }
        })
        exception_regions = @(foreach ($eh in $body.ExceptionHandlers) {
            [ordered]@{
                kind = [string]$eh.HandlerType
                try_start = $eh.TryStart.Offset
                try_end = Target-Offset $eh.TryEnd $body.CodeSize
                handler_start = $eh.HandlerStart.Offset
                handler_end = Target-Offset $eh.HandlerEnd $body.CodeSize
                filter_start = $eh.FilterStart.Offset
                catch_type = Type-Key $eh.CatchType
            }
        })
    }
}

function Module-Model($module) {
    [ordered]@{
        identity = $module.Assembly.Name.FullName
        public_key = [Convert]::ToHexString($module.Assembly.Name.PublicKey)
        hash_algorithm = [int]$module.Assembly.Name.HashAlgorithm
        runtime = $module.RuntimeVersion
        name = $module.Name
        assembly_custom = @(Attributes $module.Assembly)
        module_custom = @(Attributes $module)
        assembly_refs = @($module.AssemblyReferences.FullName)
        module_refs = @($module.ModuleReferences.Name)
        resources = @($module.Resources.Name)
        types = @(foreach ($t in $module.GetTypes()) {
            [ordered]@{
                token = '0x{0:x8}' -f $t.MetadataToken.ToInt32()
                name = $t.FullName
                attributes = [int]$t.Attributes
                base = Type-Key $t.BaseType
                custom = @(Attributes $t)
                interfaces = @(foreach ($i in $t.Interfaces) { [ordered]@{ type = Type-Key $i.InterfaceType; custom = @(Attributes $i) } })
                fields = @(foreach ($f in $t.Fields) {
                    [ordered]@{
                        key = Member-Key $f
                        attributes = [int]$f.Attributes
                        constant = $f.Constant
                        custom = @(Attributes $f)
                    }
                })
                properties = @($t.Properties.FullName)
                events = @($t.Events.FullName)
            }
        })
    }
}

$om = [Mono.Cecil.ModuleDefinition]::ReadModule((Resolve-Path -LiteralPath $Original).Path)
$cm = [Mono.Cecil.ModuleDefinition]::ReadModule((Resolve-Path -LiteralPath $Candidate).Path)
try {
    $left = Module-Model $om
    $right = Module-Model $cm
    $moduleDiff = @($left.Keys | Where-Object { (As-CanonJson $left[$_]) -cne (As-CanonJson $right[$_]) })
    $candidates = @{}
    foreach ($t in $cm.GetTypes()) {
        foreach ($m in $t.Methods) { $candidates[$m.MetadataToken.ToInt32()] = $m }
    }
    $methods = @(foreach ($t in $om.GetTypes()) {
        foreach ($m in $t.Methods) {
            $token = $m.MetadataToken.ToInt32()
            $target = $candidates[$token]
            if ($null -eq $target) { throw ('Candidate missing method 0x{0:x8}' -f $token) }
            $declaration = Method-Decl $m
            $targetDeclaration = Method-Decl $target
            $body = Method-Body $m
            $targetBody = Method-Body $target
            [ordered]@{
                token = '0x{0:x8}' -f $token
                name = $m.FullName
                definition_equal = (As-CanonJson $declaration) -ceq (As-CanonJson $targetDeclaration)
                body_equal = (As-CanonJson $body) -ceq (As-CanonJson $targetBody)
                definition = $declaration
                candidate_definition_if_different = if ((As-CanonJson $declaration) -cne (As-CanonJson $targetDeclaration)) { $targetDeclaration }
                body = $body
                candidate_body_if_different = if ((As-CanonJson $body) -cne (As-CanonJson $targetBody)) { $targetBody }
            }
        }
    })
    $data = [ordered]@{
        original_sha256 = (Get-FileHash -LiteralPath $Original).Hash.ToLowerInvariant()
        candidate_sha256 = (Get-FileHash -LiteralPath $Candidate).Hash.ToLowerInvariant()
        original_method_rows = $methods.Count
        candidate_method_rows = $candidates.Count
        methods_with_body = @($methods | Where-Object { $_.definition.has_body }).Count
        implementation_differences = @($methods | Where-Object { !$_.body_equal } | ForEach-Object token)
        definition_differences = @($methods | Where-Object { !$_.definition_equal } | ForEach-Object token)
        module_differences = $moduleDiff
        original_module = $left
        candidate_module_if_different = if ($moduleDiff.Count) { $right }
        methods = $methods
    }
    As-CanonJson $data | Set-Content -Encoding utf8NoBOM -LiteralPath $Report
    $data | Select-Object -ExpandProperty Keys | Where-Object {$_ -match 'rows|differences|methods_with_body'} |
        ForEach-Object { '{0}: {1}' -f $_, ($data[$_] -join ', ') } | Write-Output
} finally {
    $om.Dispose()
    $cm.Dispose()
}

