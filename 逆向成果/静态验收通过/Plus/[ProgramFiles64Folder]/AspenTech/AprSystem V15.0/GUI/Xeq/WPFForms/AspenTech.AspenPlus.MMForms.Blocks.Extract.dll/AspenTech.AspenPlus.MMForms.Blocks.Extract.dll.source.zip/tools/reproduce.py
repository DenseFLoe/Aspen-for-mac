"""Clean-room reproduce entry for the 31d53676 rebuild package (v2).

Usage:
    py -3 tools/reproduce.py <archive.zip> <fresh-empty-dir>

Steps: extract nothing by hand — replay.build() recompiles the packaged editable
source with the pinned csc, then token_replay.reproduce() restores the original
metadata/certificate/strong-name records. Finally compare:
  * compiled candidate SHA-256  vs build-plan.candidate_sha256
  * replayed exact image SHA-256 vs build-plan.original_sha256 (the Aspen original)
Prints `equal=true` only when the replayed image equals the original byte-for-byte.

Requires the local host toolchain recorded in build-plan.json (dotnet/csc) and the
`aspen-acceptance-work/deps` directory (pefile) on this machine.
"""
import json
import sys
import zipfile
from hashlib import sha256
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
for cand in (r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps",):
    if Path(cand).is_dir() and cand not in sys.path:
        sys.path.insert(0, cand)

import token_replay  # noqa: E402
import replay  # noqa: E402


def main(package_path, out_dir):
    package_path = Path(package_path).resolve()
    out_dir = Path(out_dir)
    if out_dir.exists() and any(out_dir.iterdir()):
        raise SystemExit("output directory must be empty or absent: " + str(out_dir))
    out_dir.mkdir(parents=True, exist_ok=True)
    work = out_dir / "build"

    compiled = replay.build(package_path, work)
    compiled_sha = sha256(compiled.read_bytes()).hexdigest()

    with zipfile.ZipFile(package_path) as z:
        recipe = json.loads(z.read("layout-recipe.json"))
        plan = json.loads(z.read("build-plan.json"))
        data = token_replay.reproduce(
            compiled.read_bytes(), recipe,
            z.read("original-build/clr-metadata.bin"),
            z.read("original-build/debug-record.bin"),
            z.read("original-build/certificate-table.bin"),
            z.read("original-build/strong-name.bin") if recipe.get("strong_name") else b"")

    replay_sha = sha256(data).hexdigest()
    dest = out_dir / "exact"
    dest.mkdir()
    artifact = dest / compiled.name
    artifact.write_bytes(data)

    expected_compiled = plan.get("candidate_sha256")
    original = plan["original_sha256"]
    compiled_ok = (compiled_sha == expected_compiled)
    equal = (replay_sha == original)

    print("artifact", artifact)
    print("compiled_sha256", compiled_sha)
    print("expected_compiler_output_sha256", expected_compiled, "match=%s" % compiled_ok)
    print("replay_sha256", replay_sha)
    print("original_sha256", original)
    print("equal=%s" % ("true" if equal else "false"))
    return 0 if (equal and compiled_ok) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
