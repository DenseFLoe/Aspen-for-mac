using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLCyclone;

[RibbonPlotWizardMgr("WpfPLCYCLONE.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class CyclonePlotWizardModule : PlotModuleBase
{
}
