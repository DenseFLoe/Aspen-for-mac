# AssemblyInfo.cs

Source: editable/Properties/AssemblyInfo.cs

Source SHA-256: 1b55d8eac859c4c947ca81e3eb6ef4000bcd3bb015ebb97148048387ffeac269
