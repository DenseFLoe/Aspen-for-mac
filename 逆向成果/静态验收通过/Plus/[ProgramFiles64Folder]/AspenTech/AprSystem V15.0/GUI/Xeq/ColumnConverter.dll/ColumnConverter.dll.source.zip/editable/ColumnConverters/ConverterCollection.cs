using System.Collections;
using System.Runtime.InteropServices;
using AspenTech.AspenPlus.APConvert;

namespace ColumnConverters;

[ComVisible(false)]
public class ConverterCollection : IAPConverterCollection
{
	private ArrayList convertCollection;

	private ColumnConverter hConvert1;

	private User2toConSep hConvert2;

	public string convertType;

	public object this[int i] => convertCollection[i - 1];

	public int Count => convertCollection.Count;

	public ConverterCollection(string type)
	{
		convertType = type;
		convertCollection = new ArrayList();
		if (type.ToUpper() == "CONSEP")
		{
			hConvert1 = new ColumnConverter(convertType);
			convertCollection.Add(hConvert1);
		}
		else
		{
			hConvert2 = new User2toConSep();
			convertCollection.Add(hConvert2);
		}
	}

	public IEnumerator GetEnumerator()
	{
		return (this as IEnumerable).GetEnumerator();
	}
}
