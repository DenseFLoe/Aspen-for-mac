#!/usr/bin/env python3
"""Owner-aware variant of managed-override-1/make_source.py.

The original tlbimp assemblies carry one MethodImpl (.override) row per class
MethodDef.  Decompiled C# declares them as `public virtual extern`, which the
compiler cannot turn into an override row; explicit interface implementation
(`extern I.M(...)`) can.  Overrides are paired by owning type + method name +
occurrence order (the shared script keys by method name only and rejects names
that repeat across classes, e.g. Clear in IAPVPropRequest and IAPVPropSystem).

Usage: make_source2.py <sha8> <src.cs> <orig.il> <dst.cs>
"""
import json
import re
import sys
from pathlib import Path


def overrides_from_il(il_text):
    """Return {(owner_simple, method_name): [(iface_full, name), ...]} in IL order."""
    out = {}
    starts = [m.start() for m in re.finditer(r"(?m)^\t\.method\b", il_text)]
    for s in starts:
        end = re.search(r"\} // end of method (\S+)::(\S+)", il_text[s:])
        if not end:
            continue
        block = il_text[s:s + end.end()]
        owner = end.group(1).split("::")[-1]
        owner_simple = owner.split(".")[-1]
        name = end.group(2)
        targets = []
        for m in re.finditer(r"\.override\s+method\s+.*?\s(\S+?)::(\S+?)\(", block):
            targets.append((m.group(1), m.group(2)))
        if targets:
            out.setdefault((owner_simple, name), []).append(targets)
    return out


def class_blocks(source):
    """Yield (class_name, start_line_index, end_line_index) for each top-level class."""
    lines = source.splitlines(keepends=True)
    blocks = []
    i = 0
    while i < len(lines):
        m = re.match(r"^public (?:sealed )?class (\w+)", lines[i])
        if m:
            depth = 0
            j = i
            while j < len(lines):
                depth += lines[j].count("{") - lines[j].count("}")
                if depth == 0 and "{" in "".join(lines[i:j + 1]):
                    break
                j += 1
            blocks.append((m.group(1), i, j))
            i = j + 1
            continue
        i += 1
    return lines, blocks


def transform(source, mapping):
    lines, blocks = class_blocks(source)
    # occurrence counters per (class, method)
    occ = {}
    # line -> (class, index in class)
    owner_of_line = {}
    for cls, a, b in blocks:
        for k in range(a, b + 1):
            owner_of_line[k] = cls
    out = list(lines)
    seen = {}
    for k, line in enumerate(lines):
        m = re.match(r"^(\t)public virtual extern (.+?) (\w+)\((.*)\);\s*$", line)
        if not m:
            continue
        cls = owner_of_line.get(k)
        if cls is None:
            continue
        name = m.group(3)
        n = seen.get((cls, name), 0)
        seen[(cls, name)] = n + 1
        entries = mapping.get((cls, name))
        if not entries:
            continue
        if n >= len(entries):
            raise SystemExit("no override row for %s.%s occurrence %d" % (cls, name, n))
        targets = entries[n]
        if len(targets) != 1:
            raise SystemExit("method %s.%s has %d override targets" % (cls, name, len(targets)))
        iface = targets[0][0].split(".")[-1]
        out[k] = "\textern %s %s.%s(%s);\n" % (m.group(2), iface, name, m.group(4))
    return "".join(out)


def main():
    sha8, src, il, dst = sys.argv[1:5]
    source = Path(src).read_text(encoding="utf-8-sig")
    mapping = overrides_from_il(Path(il).read_text(encoding="utf-8", errors="replace"))
    result = transform(source, mapping)
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    Path(dst).write_text(result, encoding="utf-8")
    print(json.dumps({"sha8": sha8, "override_groups": {"%s::%s" % k: v for k, v in mapping.items()},
                      "groups": len(mapping),
                      "rows": sum(len(v) for v in mapping.values())},
                     ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
