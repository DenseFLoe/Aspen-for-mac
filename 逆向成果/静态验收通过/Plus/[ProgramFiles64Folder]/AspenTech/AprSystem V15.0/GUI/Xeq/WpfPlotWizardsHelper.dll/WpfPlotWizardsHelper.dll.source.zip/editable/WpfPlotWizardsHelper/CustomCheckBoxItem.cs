using System.Windows;

namespace WpfPlotWizardsHelper;

public class CustomCheckBoxItem : DependencyObject
{
	public static readonly DependencyProperty IsCheckedProperty = DependencyProperty.Register("IsChecked", typeof(bool), typeof(CustomCheckBoxItem));

	public static readonly DependencyProperty ContentProperty = DependencyProperty.Register("Content", typeof(string), typeof(CustomCheckBoxItem));

	public static readonly DependencyProperty TagProperty = DependencyProperty.Register("Tag", typeof(object), typeof(CustomCheckBoxItem));

	public string Content
	{
		get
		{
			return (string)GetValue(ContentProperty);
		}
		set
		{
			SetValue(ContentProperty, value);
		}
	}

	public bool IsChecked
	{
		get
		{
			return (bool)GetValue(IsCheckedProperty);
		}
		set
		{
			SetValue(IsCheckedProperty, value);
		}
	}

	public object Tag
	{
		get
		{
			return GetValue(TagProperty);
		}
		set
		{
			SetValue(TagProperty, value);
		}
	}
}
