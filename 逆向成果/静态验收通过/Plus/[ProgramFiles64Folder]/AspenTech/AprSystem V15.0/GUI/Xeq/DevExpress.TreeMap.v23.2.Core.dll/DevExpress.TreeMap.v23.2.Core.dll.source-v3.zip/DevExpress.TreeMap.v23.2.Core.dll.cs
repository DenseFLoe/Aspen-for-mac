﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using DevExpress.Data;
using DevExpress.Data.Helpers;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("DevExpress.TreeMap.Core")]
[assembly: AssemblyDescription("XtraTreeMap Suite")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Developer Express Inc.")]
[assembly: AssemblyProduct("DevExpress.TreeMap.Core")]
[assembly: AssemblyCopyright("Copyright © 2000-2024 Developer Express Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("23.2.4.0")]
[assembly: SatelliteContractVersion("23.2.0.0")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: CLSCompliant(true)]
[assembly: AllowPartiallyTrustedCallers]
[assembly: InternalsVisibleTo("DevExpress.TreeMap.Core.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100dfcd8cadc2dd24a7cd4ce95c4a9c1b8e7cb1dc2d665120556b4b0ec35495fddb2bd6eed0ca1e56480276295a225ba2a9746f3d3e1a04547ccf5b26acc3f96eb2a13ac467512497aa79208e32f242fd0618014d53c95a36e5de0e891873841fa8f559566e38e968426488b4aa4d0f0b59e59f38dcf3fbccf25d990ab19c27ddc2")]
[assembly: TargetFramework(".NETFramework,Version=v4.5.2", FrameworkDisplayName = ".NET Framework 4.5.2")]
[assembly: AssemblyVersion("23.2.4.0")]
namespace DevExpress.TreeMap
{
	public interface IHierarchicalItem
	{
		IList<IHierarchicalItem> Children { get; }

		object Label { get; set; }

		double Value { get; set; }

		object Tag { get; }

		object DataSourceColor { get; }

		void NotifyChildrenUpdate();
	}
	public interface ITreeMapItem : IHierarchicalItem
	{
	}
	public interface ISunburstItem : IHierarchicalItem
	{
	}
	public interface ITreeMapItemLayout
	{
		TreeMapRect Layout { get; set; }

		double Weight { get; }
	}
	public interface ILegendItem
	{
		string Text { get; }
	}
	public interface ILegendSourceItem
	{
		string Text { get; }

		object Brush { get; }

		object SourceObject { get; }
	}
	public interface ILegendItemProvider
	{
		List<ILegendItem> CreateLegendItems(IEnumerable<ILegendSourceItem> sourceItems);
	}
	public struct TreeMapRect
	{
		public static TreeMapRect Empty => new TreeMapRect(0.0, 0.0, 0.0, 0.0);

		public double X { get; set; }

		public double Y { get; set; }

		public double Width { get; set; }

		public double Height { get; set; }

		public bool IsEmpty
		{
			get
			{
				if (X == 0.0 && Y == 0.0 && Width == 0.0)
				{
					return Height == 0.0;
				}
				return false;
			}
		}

		public TreeMapRect(double x, double y, double width, double height)
		{
			this = default(TreeMapRect);
			X = x;
			Y = y;
			Width = width;
			Height = height;
		}
	}
}
namespace DevExpress.TreeMap.Native
{
	public abstract class LegendItemCreator
	{
		public abstract ILegendItem CreateItem(string text, object brushSource, object source);
	}
	public class LegendSupportColorizerBehavior : IPatternHolder
	{
		private const string defaultLegendPattern = "{L}";

		private string legendItemPattern;

		private PatternParser patternParser;

		private LegendItemCreator ItemCreator { get; }

		private string ActualLegendPattern
		{
			get
			{
				if (string.IsNullOrEmpty(legendItemPattern))
				{
					return DefaultLegendPattern;
				}
				return legendItemPattern;
			}
		}

		protected virtual string DefaultLegendPattern => "{L}";

		public LegendSupportColorizerBehavior(LegendItemCreator itemCreator)
		{
			ItemCreator = itemCreator;
			UpdateTextPattern();
		}

		PatternDataProvider IPatternHolder.GetDataProvider(PatternConstants patternConstant)
		{
			return CreateDataProvider(patternConstant);
		}

		private void UpdateTextPattern()
		{
			patternParser = new PatternParser(ActualLegendPattern, this);
		}

		protected string GetText(object context)
		{
			patternParser.SetContext(context);
			return patternParser.GetText();
		}

		protected virtual PatternDataProvider CreateDataProvider(PatternConstants patternConstant)
		{
			return new TreeMapItemPatternProvider(patternConstant);
		}

		public void UpdateLegendItemPattern(string legendItemPattern)
		{
			this.legendItemPattern = legendItemPattern;
			UpdateTextPattern();
		}

		public List<ILegendItem> CreateLegendItems(IEnumerable<ILegendSourceItem> sourceItems, bool varyColorInGroup, Func<ILegendSourceItem, object> createBrush)
		{
			if (varyColorInGroup || sourceItems == null)
			{
				return null;
			}
			List<ILegendItem> list = new List<ILegendItem>();
			foreach (ILegendSourceItem sourceItem in sourceItems)
			{
				list.Add(ItemCreator.CreateItem(GetText(sourceItem.SourceObject), createBrush(sourceItem), sourceItem.SourceObject));
			}
			return list;
		}
	}
	public class GroupController : ListSourceDataController, IDataControllerData, IDataControllerData2, ISupportUpdateDataController
	{
		private readonly IFlatDataAdapter dataAdapter;

		public virtual object DataSource { get; set; }

		private IList<IHierarchicalItem> Items => dataAdapter.Items;


		public GroupController(IFlatDataAdapter dataAdapter)
		{
			this.dataAdapter = dataAdapter;
			base.DataClient = this;
		}

		UnboundColumnInfoCollection IDataControllerData.GetUnboundColumns()
		{
			return null;
		}

		object IDataControllerData.GetUnboundData(int row, DataColumnInfo col, object value)
		{
			return null;
		}

		void IDataControllerData.SetUnboundData(int row, DataColumnInfo col, object value)
		{
		}

		private void AddComplexColumnInfo(ComplexColumnInfoCollection collection, string item)
		{
			if (item != null && item.Contains(".") && base.Columns[item] == null && collection.IndexOf(item) < 0)
			{
				collection.Add(item);
			}
		}

		ComplexColumnInfoCollection IDataControllerData2.GetComplexColumns()
		{
			ComplexColumnInfoCollection complexColumnInfoCollection = new ComplexColumnInfoCollection();
			AddComplexColumnInfo(complexColumnInfoCollection, dataAdapter.ValueDataMember);
			AddComplexColumnInfo(complexColumnInfoCollection, dataAdapter.LabelDataMember);
			if (dataAdapter.Groups != null)
			{
				foreach (string group in dataAdapter.Groups)
				{
					AddComplexColumnInfo(complexColumnInfoCollection, group);
				}
			}
			return complexColumnInfoCollection;
		}

		bool IDataControllerData2.CanUseFastProperties => true;

		void IDataControllerData2.SubstituteFilter(SubstituteFilterEventArgs args)
		{
		}

		bool IDataControllerData2.HasUserFilter => false;

		bool? IDataControllerData2.IsRowFit(int listSourceRow, bool fit)
		{
			return null;
		}

		PropertyDescriptorCollection IDataControllerData2.PatchPropertyDescriptorCollection(PropertyDescriptorCollection collection)
		{
			return collection;
		}

		private static IList GetList(object dataSource, string dataMember)
		{
			if (dataMember == null)
			{
				dataMember = string.Empty;
			}
			return MasterDetailHelper.GetDataSource(dataSource, dataMember);
		}

		private void LoadGroupData(IList<IHierarchicalItem> items)
		{
			ApplySortGroup(dataAdapter.Groups);
			CreateTreeMapItems(items);
		}

		private void LoadData(IList<IHierarchicalItem> items)
		{
			for (int i = 0; i < base.ListSourceRowCount; i++)
			{
				IHierarchicalItem hierarchicalItem = CreateTreeMapItem(i);
				if (hierarchicalItem != null)
				{
					items.Add(hierarchicalItem);
				}
			}
		}

		private void ApplySortGroup(IEnumerable<string> groups)
		{
			int num = groups.Count();
			DataColumnSortInfo[] array = new DataColumnSortInfo[num];
			int num2 = 0;
			foreach (string group in groups)
			{
				if (!string.IsNullOrEmpty(group))
				{
					DataColumnInfo dataColumnInfo = base.Columns[group];
					if (dataColumnInfo != null)
					{
						array[num2++] = new DataColumnSortInfo(dataColumnInfo);
					}
				}
			}
			base.SortInfo.ClearAndAddRange(array, num);
		}

		private IHierarchicalItem CreateTreeMapItem(int rowIndex, object row)
		{
			object rowValue = GetRowValue(rowIndex, dataAdapter.ValueDataMember);
			double value = ParseNumerical(rowValue);
			object rowValue2 = GetRowValue(rowIndex, dataAdapter.LabelDataMember);
			string colorDataMember = dataAdapter.ColorDataMember;
			object color = ((!string.IsNullOrEmpty(colorDataMember)) ? GetRowValue(rowIndex, colorDataMember) : null);
			IHierarchicalItem hierarchicalItem = dataAdapter.CreateItem(value, rowValue2, row, color, rowIndex);
			return hierarchicalItem;
		}

		private IHierarchicalItem CreateTreeMapItem(int rowIndex)
		{
			return CreateTreeMapItem(rowIndex, GetRow(rowIndex));
		}

		private double ParseNumerical(object value)
		{
			if (value != null)
			{
				if (IsNumericalType(value.GetType()))
				{
					return Convert.ToDouble(value);
				}
				if (double.TryParse(value.ToString(), NumberStyles.Number, CultureInfo.InvariantCulture, out var result))
				{
					return result;
				}
			}
			return 0.0;
		}

		private bool IsNumericalType(Type type)
		{
			if (!(type == typeof(double)) && !(type == typeof(float)) && !(type == typeof(int)) && !(type == typeof(uint)) && !(type == typeof(long)) && !(type == typeof(ulong)) && !(type == typeof(decimal)) && !(type == typeof(short)) && !(type == typeof(ushort)) && !(type == typeof(byte)))
			{
				return type == typeof(sbyte);
			}
			return true;
		}

		private void CreateTreeMapItems(IList<IHierarchicalItem> items)
		{
			foreach (GroupRowInfo item in base.GroupInfo)
			{
				if (item.ParentGroup == null)
				{
					AddTreeMapItem(items, item);
				}
			}
		}

		private List<object> AddTreeMapItem(IList<IHierarchicalItem> items, GroupRowInfo groupInfo, int childCount = 0)
		{
			List<IHierarchicalItem> list = new List<IHierarchicalItem>();
			List<object> list2 = FillChildren(groupInfo, list, childCount);
			int rowIndex = GetRowIndex(base.SortInfo[groupInfo.Level].ColumnInfo.Name, groupInfo.GroupValue);
			IHierarchicalItem hierarchicalItem = dataAdapter.CreateGroupItem(groupInfo.Level, groupInfo.GroupValue, list2, rowIndex);
			foreach (IHierarchicalItem item in list)
			{
				hierarchicalItem.Children.Add(item);
			}
			items.Add(hierarchicalItem);
			return list2;
		}

		private List<object> FillChildren(GroupRowInfo groupInfo, IList<IHierarchicalItem> items, int childCount = 0)
		{
			List<object> list = new List<object>();
			List<GroupRowInfo> list2 = new List<GroupRowInfo>();
			base.GroupInfo.GetChildrenGroups(groupInfo, list2);
			if (list2.Count > 0)
			{
				foreach (GroupRowInfo item in list2)
				{
					list.AddRange(AddTreeMapItem(items, item, childCount));
				}
			}
			else
			{
				list.AddRange(FillLeafs(groupInfo.ChildControllerRow, (childCount == 0) ? groupInfo.ChildControllerRowCount : childCount, items));
			}
			return list;
		}

		private List<object> FillLeafs(int start, int count, IList<IHierarchicalItem> items)
		{
			List<object> list = new List<object>();
			for (int i = start; i < start + count; i++)
			{
				IHierarchicalItem hierarchicalItem = CreateTreeMapItem(i);
				items.Add(hierarchicalItem);
				list.Add(hierarchicalItem.Tag);
			}
			return list;
		}

		private bool FindAndProcessItem(Predicate<IHierarchicalItem> predicate, IHierarchicalItem parentItem, IList<IHierarchicalItem> items, Action<IHierarchicalItem, IHierarchicalItem> action)
		{
			foreach (IHierarchicalItem item in items)
			{
				if (predicate(item))
				{
					action(parentItem, item);
					return true;
				}
				if (item.Children.Any() && FindAndProcessItem(predicate, item, item.Children, action))
				{
					return true;
				}
			}
			return false;
		}

		private IHierarchicalItem FindItemParent(IHierarchicalItem parent, List<GroupRowInfo> groups)
		{
			IList<IHierarchicalItem> list = ((parent != null) ? parent.Children : Items);
			foreach (IHierarchicalItem item in list)
			{
				if (item.Label != null && item.Label.Equals(groups[0].GroupValue))
				{
					groups.RemoveAt(0);
					return (groups.Count == 0) ? item : FindItemParent(item, groups);
				}
			}
			return parent;
		}

		private void AddItem(object row, int rowIndex)
		{
			GroupRowInfo groupRowInfoByControllerRowHandle = base.GroupInfo.GetGroupRowInfoByControllerRowHandle(rowIndex);
			if (groupRowInfoByControllerRowHandle != null)
			{
				List<GroupRowInfo> list = new List<GroupRowInfo> { groupRowInfoByControllerRowHandle };
				int parentRow;
				for (parentRow = base.GroupInfo.GetParentRow(groupRowInfoByControllerRowHandle); parentRow != int.MinValue; parentRow = base.GroupInfo.GetParentRow(parentRow))
				{
					list.Insert(0, base.GroupInfo.GetGroupRowInfoByHandle(parentRow));
				}
				IHierarchicalItem hierarchicalItem = FindItemParent(null, list);
				IList<IHierarchicalItem> list2 = ((hierarchicalItem != null) ? hierarchicalItem.Children : Items);
				if (list.Count > 0)
				{
					AddTreeMapItem(list2, list[0], 1);
				}
				else
				{
					if (hierarchicalItem != null)
					{
						((IList)hierarchicalItem.Tag).Add(row);
					}
					list2.Add(CreateTreeMapItem(rowIndex, row));
				}
				hierarchicalItem?.NotifyChildrenUpdate();
			}
			else
			{
				Items.Insert(rowIndex, CreateTreeMapItem(rowIndex, row));
			}
		}

		private bool IsItemMissingInDataSource(IHierarchicalItem item)
		{
			if (item.Tag is IList list)
			{
				foreach (object item2 in list)
				{
					if (base.ListSource.Contains(item2))
					{
						return false;
					}
				}
				return true;
			}
			return !base.ListSource.Contains(item.Tag);
		}

		private void RemoveItem(IHierarchicalItem parentItem, IHierarchicalItem item)
		{
			if (parentItem == null)
			{
				Items.Remove(item);
				return;
			}
			parentItem.Children.Remove(item);
			((IList)parentItem.Tag).Remove(item.Tag);
			parentItem.NotifyChildrenUpdate();
		}

		protected void ReplaceItem(object row, int rowIndex, object oldItem)
		{
			FindAndProcessItem((IHierarchicalItem item) => item.Tag.Equals(oldItem), null, Items, RemoveItem);
			AddItem(row, rowIndex);
		}

		protected virtual void OnItemChanged(ListChangedEventArgs e, object row, int rowIndex)
		{
			if (e.PropertyDescriptor != null)
			{
				string name = e.PropertyDescriptor.Name;
				bool flag = dataAdapter.Groups.Contains(name);
				bool shouldUpdateLabel = name == dataAdapter.LabelDataMember;
				bool shouldUpdateValue = name == dataAdapter.ValueDataMember;
				if (shouldUpdateValue || shouldUpdateLabel || flag)
				{
					FindAndProcessItem((IHierarchicalItem item) => item.Tag == row, null, Items, delegate(IHierarchicalItem parentItem, IHierarchicalItem item)
					{
						if (shouldUpdateValue)
						{
							item.Value = ParseNumerical(GetRowValue(rowIndex, dataAdapter.ValueDataMember));
							parentItem?.NotifyChildrenUpdate();
						}
						else if (shouldUpdateLabel)
						{
							item.Label = GetRowValue(rowIndex, dataAdapter.LabelDataMember);
							parentItem?.NotifyChildrenUpdate();
						}
						else
						{
							RemoveItem(parentItem, item);
							AddItem(row, rowIndex);
						}
					});
				}
			}
		}

		protected virtual Predicate<IHierarchicalItem> GetDeleteItemPredicate(ListChangedEventArgs e)
		{
			return IsItemMissingInDataSource;
		}

		protected override void OnBindingListChanged(ListChangedEventArgs e)
		{
			base.OnBindingListChanged(e);
			object rowByListSourceIndex = GetRowByListSourceIndex(e.NewIndex);
			int controllerRow = GetControllerRow(e.NewIndex);
			switch (e.ListChangedType)
			{
			case ListChangedType.ItemChanged:
				OnItemChanged(e, rowByListSourceIndex, controllerRow);
				break;
			case ListChangedType.ItemAdded:
				AddItem(rowByListSourceIndex, controllerRow);
				break;
			case ListChangedType.ItemDeleted:
				FindAndProcessItem(GetDeleteItemPredicate(e), null, Items, RemoveItem);
				break;
			default:
				UpdateData();
				break;
			}
			dataAdapter.UpdateData();
		}

		public void UpdateData()
		{
			if (Items != null)
			{
				Items.Clear();
				base.SortInfo.Clear();
				if (DataSource != null)
				{
					base.ListSource = GetList(DataSource, dataAdapter.DataMember);
					if (base.ListSource != null)
					{
						RePopulateColumns();
						if (dataAdapter.Groups != null && dataAdapter.Groups.Count() > 0)
						{
							LoadGroupData(Items);
							return;
						}
						LoadData(Items);
					}
				}
			}
		}

		public int GetRowIndex(string columnName, object columnValue)
		{
			return GetListSourceRowIndex(FindRowByValue(columnName, columnValue));
		}
	}
	public interface ILabelFormatter
	{
		string GetDataLabelText(object sourceObject, object labelObject);
	}
	public interface IPatternHolder
	{
		PatternDataProvider GetDataProvider(PatternConstants patternConstant);
	}
	public interface IFlatDataAdapter
	{
		string DataMember { get; }

		string ValueDataMember { get; }

		string LabelDataMember { get; }

		string ColorDataMember { get; }

		IList<IHierarchicalItem> Items { get; }

		IEnumerable<string> Groups { get; }

		IHierarchicalItem CreateItem(double value, object label, object tag, object color, int indexInSource);

		IHierarchicalItem CreateGroupItem(int groupLevel, object label, object tag, int indexInSource);

		void UpdateData();
	}
	public interface ISupportUpdateDataController
	{
		object DataSource { get; set; }

		void UpdateData();

		int GetRowIndex(string columnName, object columnValue);
	}
	public interface IGroupIndexProvider
	{
		int GetGroupIndex(object groupValue);
	}
	public class LabelBoundsCalculator
	{
		public const double DoublePI = Math.PI * 2.0;

		private static TreeMapRect CalcHorizontalLabelBoundsCore(double starAngle, double endAngle, double centerX, double centerY, double height, double minRadius, double maxRadius)
		{
			double num = (starAngle + endAngle) / 2.0;
			double num2 = (minRadius + maxRadius) / 2.0 * Math.Sin(num);
			double labelX = (minRadius + maxRadius) / 2.0 * Math.Cos(num);
			double maxRadiusPow = maxRadius * maxRadius;
			double minRadiusPow = minRadius * minRadius;
			if (starAngle > Math.PI * 2.0 || endAngle > Math.PI * 2.0)
			{
				starAngle -= Math.PI * 2.0;
				endAngle -= Math.PI * 2.0;
			}
			Tuple<double, double> tuple = CalcIntersectWithSegment(starAngle, endAngle, num2 - height / 2.0, labelX, minRadiusPow, maxRadiusPow);
			Tuple<double, double> tuple2 = CalcIntersectWithSegment(starAngle, endAngle, num2 + height / 2.0, labelX, minRadiusPow, maxRadiusPow);
			double num3 = Math.Max(tuple.Item1, tuple2.Item1);
			double num4 = Math.Min(tuple.Item2, tuple2.Item2);
			double y = num2 - height / 2.0 + centerY;
			double num5 = num4 - num3;
			if (num5 < 0.0)
			{
				return TreeMapRect.Empty;
			}
			return new TreeMapRect(num3 + centerX, y, num5, height);
		}

		private static Tuple<double, double> CalcIntersectWithArc(double starAngle, double endAngle, double y, double yPow2, double radiusPow2, ref double firstIntersectX)
		{
			double num = Math.Sqrt(radiusPow2 - yPow2);
			Tuple<double, double> tuple = CheckIntersectWithArcAngGetCoordinates(starAngle, endAngle, y, num, ref firstIntersectX);
			Tuple<double, double> tuple2 = CheckIntersectWithArcAngGetCoordinates(starAngle, endAngle, y, -num, ref firstIntersectX);
			if (tuple == null && tuple2 == null)
			{
				return null;
			}
			if (tuple != null && tuple2 != null)
			{
				if ((tuple.Item1 < 0.0 && tuple.Item2 < 0.0) || (tuple.Item1 > 0.0 && tuple.Item2 > 0.0))
				{
					return tuple;
				}
				return tuple2;
			}
			if (tuple == null)
			{
				return tuple2;
			}
			return tuple;
		}

		private static Tuple<double, double> CalcIntersectWithSegment(double starAngle, double endAngle, double labelY, double labelX, double minRadiusPow2, double maxRadiusPow2)
		{
			Tuple<double, double> tuple;
			double firstIntersectX = double.NaN;
			double num = labelY * labelY;
			double num2;
			Tuple<double, double> tuple2;
			double num3;
			if (num < maxRadiusPow2)
			{
				tuple = CalcIntersectWithArc(starAngle, endAngle, labelY, num, maxRadiusPow2, ref firstIntersectX);
				if (tuple != null)
				{
					firstIntersectX = double.NaN;
					tuple2 = CalcIntersectWithArc(starAngle, endAngle, labelY, num, minRadiusPow2, ref firstIntersectX);
					if (tuple2 == null)
					{
						return tuple;
					}
					if (!(labelX < 0.0))
					{
						return new Tuple<double, double>(tuple2.Item2, tuple.Item2);
					}
					return new Tuple<double, double>(tuple.Item1, tuple2.Item1);
				}
			}
			if (num < minRadiusPow2)
			{
				tuple = CalcIntersectWithArc(starAngle, endAngle, labelY, num, minRadiusPow2, ref firstIntersectX);
				if (tuple != null)
				{
					return tuple;
				}
			}
			num2 = labelY / Math.Tan(starAngle);
			if (!double.IsNaN(num2) && !double.IsInfinity(num2))
			{
				num3 = num2 * num2 + num;
				if (num3 <= maxRadiusPow2 && num3 >= minRadiusPow2)
				{
					tuple = TryGetCoordinates(num2, ref firstIntersectX);
					if (tuple != null)
					{
						return tuple;
					}
				}
			}
			num2 = labelY / Math.Tan(endAngle);
			return new Tuple<double, double>(Math.Min(firstIntersectX, num2), Math.Max(firstIntersectX, num2));
		}
		private static Tuple<double, double> CheckIntersectWithArcAngGetCoordinates(double starAngle, double endAngle, double y, double intersectX, ref double firstIntersectX)
		{
			double num = Math.Atan2(y, intersectX);
			if (starAngle >= 0.0 && endAngle >= 0.0 && num < 0.0)
			{
				num += Math.PI * 2.0;
			}
			else if (starAngle < 0.0 && endAngle < 0.0 && num > 0.0)
			{
				num -= Math.PI * 2.0;
			}
			if (num <= starAngle && num >= endAngle)
			{
				return TryGetCoordinates(intersectX, ref firstIntersectX);
			}
			return null;
		}

		private static Tuple<double, double> TryGetCoordinates(double intersectX, ref double firstIntersectX)
		{
			if (!double.IsNaN(firstIntersectX))
			{
				return new Tuple<double, double>(Math.Min(firstIntersectX, intersectX), Math.Max(firstIntersectX, intersectX));
			}
			firstIntersectX = intersectX;
			return null;
		}

		public static Tuple<TreeMapRect, TreeMapRect> CalcHorizontalLabelBounds(double startAngleRad, double endAngleRad, double centerX, double centerY, double minRadius, double maxRadius, double minHeight)
		{
			TreeMapRect item = CalcHorizontalLabelBoundsCore(startAngleRad, endAngleRad, centerX, centerY, 45.0, minRadius, maxRadius);
			TreeMapRect item2 = CalcHorizontalLabelBoundsCore(startAngleRad, endAngleRad, centerX, centerY, minHeight, minRadius, maxRadius);
			return new Tuple<TreeMapRect, TreeMapRect>(item, item2);
		}
	}
	public enum LayoutAlgorithmDirection
	{
		TopLeftToBottomRight,
		BottomLeftToTopRight,
		TopRightToBottomLeft,
		BottomRightToTopLeft
	}
	public enum SliceAndDiceAlgorithmLayoutMode
	{
		Auto,
		Vertical,
		Horizontal
	}
	public abstract class LayoutAlgorithmBase
	{
		public abstract void Calculate(IEnumerable<ITreeMapItemLayout> sortedData, double width, double height);
	}
	public abstract class SquarifiedAlgorithmBase : LayoutAlgorithmBase
	{
		protected class RectCalculator
		{
			private SquarifiedAlgorithmBase algorithm;

			private bool isLeftDirection;

			private bool isTopDirection;

			public RectCalculator(SquarifiedAlgorithmBase algorithm)
			{
				this.algorithm = algorithm;
				isLeftDirection = algorithm.Direction == LayoutAlgorithmDirection.TopLeftToBottomRight || algorithm.Direction == LayoutAlgorithmDirection.BottomLeftToTopRight;
				isTopDirection = algorithm.Direction == LayoutAlgorithmDirection.TopLeftToBottomRight || algorithm.Direction == LayoutAlgorithmDirection.TopRightToBottomLeft;
			}

			public TreeMapRect CalculateFirstRect(int i, TreeMapRect rect, ITreeMapItemLayout[] items, bool isVertical, double sum)
			{
				TreeMapRect result = default(TreeMapRect);
				result.Width = (isVertical ? (items[i].Weight / sum * rect.Width) : rect.Width);
				result.Height = (isVertical ? rect.Height : (items[i].Weight / sum * rect.Height));
				result.X = (isLeftDirection ? rect.X : (rect.Width - result.Width));
				result.Y = (isTopDirection ? rect.Y : (result.Y = rect.Height - result.Height));
				return result;
			}

			public TreeMapRect CalculateRect(double side, double anchorSide, double ratio, TreeMapRect rect, double offset, bool isVertical, double width, double height)
			{
				TreeMapRect result = default(TreeMapRect);
				if (isVertical)
				{
					result.Height = Math.Min(side, height);
					result.Width = Math.Min(anchorSide, width);
					result.X = (isLeftDirection ? rect.X : (rect.Width - result.Width));
					result.Y = (isTopDirection ? (rect.Y + offset) : (rect.Height - (result.Height + offset)));
				}
				else
				{
					result.Width = Math.Min(side, width);
					result.Height = Math.Min(anchorSide, height);
					result.X = (isLeftDirection ? (rect.X + offset) : (rect.Width - (result.Width + offset)));
					result.Y = (isTopDirection ? rect.Y : (rect.Height - result.Height));
				}
				return result;
			}

			public TreeMapRect CalculateNewInitialRect(TreeMapRect initialRect, TreeMapRect rect, bool isVertical)
			{
				if (isVertical)
				{
					initialRect.X = initialRect.X + rect.Width;
					initialRect.Width = initialRect.Width - rect.Width;
					return new TreeMapRect(initialRect.X, initialRect.Y, initialRect.Width, initialRect.Height);
				}
				initialRect.Y = initialRect.Y + rect.Height;
				initialRect.Height = initialRect.Height - rect.Height;
				return new TreeMapRect(initialRect.X, initialRect.Y, initialRect.Width, initialRect.Height);
			}
		}

		private class Data
		{
			public double Value { get; set; }
		}

		private RectCalculator rectCalculator;

		private LayoutAlgorithmDirection direction;

		protected RectCalculator RectCalculatorDirection => rectCalculator;

		public LayoutAlgorithmDirection Direction => direction;

		public SquarifiedAlgorithmBase(LayoutAlgorithmDirection direction)
		{
			this.direction = direction;
			rectCalculator = new RectCalculator(this);
		}

		private void FillItemsLayout(IList<ITreeMapItemLayout> sortedData, List<TreeMapRect> temp, int index)
		{
			foreach (TreeMapRect item in temp)
			{
				TreeMapRect layout = (IsRectCorrect(item) ? item : TreeMapRect.Empty);
				sortedData[index++].Layout = layout;
			}
		}

		private bool IsRectCorrect(TreeMapRect rect)
		{
			if (rect.Width >= 0.0)
			{
				return rect.Height >= 0.0;
			}
			return false;
		}

		private double[] GetSides(ITreeMapItemLayout[] values, int index, int count, double anchor)
		{
			double num = 0.0;
			int num2 = count + index;
			int num3 = 0;
			double[] array = new double[count];
			for (int i = index; i < num2; i++)
			{
				double weight = values[i].Weight;
				array[num3++] = weight;
				num += weight;
			}
			for (int j = 0; j < count; j++)
			{
				array[j] = array[j] / num * anchor;
			}
			return array;
		}

		private double[] GetValues(ITreeMapItemLayout[] data, out double sum)
		{
			sum = 0.0;
			int num = data.Count();
			double[] array = new double[num];
			for (int i = 0; i < num; i++)
			{
				array[i] = data[i].Weight;
				if (array[i] > 0.0)
				{
					sum += array[i];
				}
			}
			return array;
		}

		protected abstract bool NeedContinueRow(double width, double height, TreeMapRect initialRect, TreeMapRect rect);

		protected abstract bool GetOrientationInitialRectangle(TreeMapRect initialRect, bool isVertical);

		protected void CalculateSquarifiedAndStriped(IEnumerable<ITreeMapItemLayout> sortedData, double width, double height)
		{
			if (sortedData != null && sortedData.Count() > 0 && width > 0.0 && height > 0.0)
			{
			TreeMapRect treeMapRect = default(TreeMapRect);
			TreeMapRect treeMapRect2 = new TreeMapRect(0.0, 0.0, width, height);
			int num = 0;
			bool flag = treeMapRect2.Width > treeMapRect2.Height;
			List<TreeMapRect> list = new List<TreeMapRect>();
			ITreeMapItemLayout[] array = sortedData.ToArray();
			double num2 = array.Sum((ITreeMapItemLayout item) => (item != null && item.Weight > 0.0) ? item.Weight : 0.0);
			if (num2 > 0.0)
			{
			double num3 = treeMapRect2.Height * treeMapRect2.Width / num2;
			double num4 = 0.0;
			for (int num5 = 0; num5 < array.Length; num5++)
			{
				double weight = array[num5].Weight;
				if (array[num5].Weight > 0.0 && num2 > 0.0)
				{
					int count = list.Count;
					if (count == 0)
					{
						treeMapRect = RectCalculatorDirection.CalculateFirstRect(num5, treeMapRect2, array, flag, num2);
						num4 = Math.Max(treeMapRect.Height / treeMapRect.Width, treeMapRect.Width / treeMapRect.Height);
						list.Add(treeMapRect);
					}
					else
					{
						double num6 = 0.0;
						double[] sides = GetSides(array, num, num5 - num + 1, flag ? treeMapRect2.Height : treeMapRect2.Width);
						double anchorSide = array[num].Weight / sides[0] * num3;
						List<TreeMapRect> list2 = new List<TreeMapRect>();
						list2.AddRange(list);
						list.Clear();
						double num7 = 0.0;
						double num8 = 0.0;
						for (int num9 = 0; num9 <= count; num9++)
						{
							TreeMapRect item = RectCalculatorDirection.CalculateRect(sides[num9], anchorSide, num3, treeMapRect2, num6, flag, width, height);
							num6 += (flag ? item.Height : item.Width);
							num7 = Math.Max(item.Width / item.Height, item.Height / item.Width);
							if (num7 < num4)
							{
								list.Add(item);
								if (num8 < num7)
								{
									num8 = num7;
								}
								continue;
							}
							if (NeedContinueRow(width, height, treeMapRect2, list2[0]))
							{
								list.Add(item);
								continue;
							}
							FillItemsLayout(array, list2, num);
							list.Clear();
							treeMapRect2 = RectCalculatorDirection.CalculateNewInitialRect(treeMapRect2, list2[0], flag);
							num = num5;
							flag = GetOrientationInitialRectangle(treeMapRect2, flag);
							treeMapRect = RectCalculatorDirection.CalculateFirstRect(num5, treeMapRect2, array, flag, num2);
							num4 = Math.Max(treeMapRect.Height / treeMapRect.Width, treeMapRect.Width / treeMapRect.Height);
							num8 = 0.0;
							list.Add(treeMapRect);
							break;
						}
						if (num8 != 0.0)
						{
							num4 = num8;
						}
					}
					num2 -= weight;
				}
				else
				{
					list.Add(TreeMapRect.Empty);
				}
			}
			FillItemsLayout(array, list, num);
			}
			}
		}
	}
	public sealed class SquarifiedAlgorithm : SquarifiedAlgorithmBase
	{
		public SquarifiedAlgorithm()
			: this(LayoutAlgorithmDirection.TopLeftToBottomRight)
		{
		}

		public SquarifiedAlgorithm(LayoutAlgorithmDirection direction)
			: base(direction)
		{
		}

		protected override bool NeedContinueRow(double width, double height, TreeMapRect initialRect, TreeMapRect rect)
		{
			return false;
		}

		protected override bool GetOrientationInitialRectangle(TreeMapRect initialRect, bool isVertical)
		{
			return initialRect.Width > initialRect.Height;
		}

		public override void Calculate(IEnumerable<ITreeMapItemLayout> sortedData, double width, double height)
		{
			CalculateSquarifiedAndStriped(sortedData, width, height);
		}
	}
	public sealed class StripedAlgorithm : SquarifiedAlgorithmBase
	{
		public const double DefaultLastStripeMinThickness = 0.025;

		private double lastStripeMinThickness;

		public StripedAlgorithm()
			: this(LayoutAlgorithmDirection.TopLeftToBottomRight, 0.025)
		{
		}

		public StripedAlgorithm(LayoutAlgorithmDirection direction, double lastStripeMinThickness)
			: base(direction)
		{
			this.lastStripeMinThickness = lastStripeMinThickness;
		}

		protected override bool NeedContinueRow(double width, double height, TreeMapRect initialRect, TreeMapRect rect)
		{
			double num = initialRect.Width - rect.Width;
			double num2 = initialRect.Height - rect.Height;
			if (num == 0.0 || !(num / width < lastStripeMinThickness))
			{
				if (num2 != 0.0)
				{
					return num2 / height < lastStripeMinThickness;
				}
				return false;
			}
			return true;
		}

		protected override bool GetOrientationInitialRectangle(TreeMapRect initialRect, bool isVertical)
		{
			return isVertical;
		}

		public override void Calculate(IEnumerable<ITreeMapItemLayout> sortedData, double width, double height)
		{
			CalculateSquarifiedAndStriped(sortedData, width, height);
		}
	}
	public sealed class SliceAndDiceAlgorithm : LayoutAlgorithmBase
	{
		private LayoutAlgorithmDirection direction;

		private SliceAndDiceAlgorithmLayoutMode mode;

		public SliceAndDiceAlgorithm()
			: this(LayoutAlgorithmDirection.TopLeftToBottomRight, SliceAndDiceAlgorithmLayoutMode.Auto)
		{
		}

		public SliceAndDiceAlgorithm(LayoutAlgorithmDirection direction, SliceAndDiceAlgorithmLayoutMode mode)
		{
			this.direction = direction;
			this.mode = mode;
		}

		private bool IsVerticalDirection(double width, double height)
		{
			switch (mode)
			{
			case SliceAndDiceAlgorithmLayoutMode.Vertical:
				return false;
			case SliceAndDiceAlgorithmLayoutMode.Horizontal:
				return true;
			case SliceAndDiceAlgorithmLayoutMode.Auto:
			default:
				return width < height;
			}
		}

		private bool IsFromLeft()
		{
			if (direction != LayoutAlgorithmDirection.TopLeftToBottomRight)
			{
				return direction == LayoutAlgorithmDirection.BottomLeftToTopRight;
			}
			return true;
		}

		private bool IsFromTop()
		{
			if (direction != LayoutAlgorithmDirection.TopLeftToBottomRight)
			{
				return direction == LayoutAlgorithmDirection.TopRightToBottomLeft;
			}
			return true;
		}

		private void GetCoefficients(double width, double height, bool isVertical, out double begin, out int sign, out int coef)
		{
			if (isVertical)
			{
				if (IsFromTop())
				{
					begin = 0.0;
					sign = 1;
				}
				else
				{
					begin = height;
					sign = -1;
				}
			}
			else if (IsFromLeft())
			{
				begin = 0.0;
				sign = 1;
			}
			else
			{
				begin = width;
				sign = -1;
			}
			coef = ((sign == -1) ? (-1) : 0);
		}

		public override void Calculate(IEnumerable<ITreeMapItemLayout> sortedData, double width, double height)
		{
			double num = 0.0;
			double begin;
			int sign;
			int coef;
			double num2 = sortedData.Sum((ITreeMapItemLayout d) => (d.Weight > 0.0) ? d.Weight : 0.0);
			bool flag = IsVerticalDirection(width, height);
			GetCoefficients(width, height, flag, out begin, out sign, out coef);
			foreach (ITreeMapItemLayout sortedDatum in sortedData)
			{
				if (sortedDatum.Weight > 0.0)
				{
					TreeMapRect layout = default(TreeMapRect);
					if (flag)
					{
						layout.Width = width;
						layout.Height = sortedDatum.Weight / num2 * height;
						layout.X = 0.0;
						layout.Y = begin + num * (double)sign + layout.Height * (double)coef;
						num += layout.Height;
					}
					else
					{
						layout.Width = sortedDatum.Weight / num2 * width;
						layout.Height = height;
						layout.X = begin + num * (double)sign + layout.Width * (double)coef;
						layout.Y = 0.0;
						num += layout.Width;
					}
					sortedDatum.Layout = layout;
				}
				else
				{
					sortedDatum.Layout = new TreeMapRect(0.0, 0.0, 0.0, 0.0);
				}
			}
		}
	}
	public class TreeMapLayoutItemComparer : IComparer<ITreeMapItemLayout>
	{
		public TreeMapLayoutItemComparer()
		{
		}

		public int Compare(ITreeMapItemLayout x, ITreeMapItemLayout y)
		{
			if (x == null)
			{
				if (y == null)
				{
					return 0;
				}
				return -1;
			}
			return y?.Weight.CompareTo(x.Weight) ?? 1;
		}
	}
	public interface ICenterLabelPatternValueHolder
	{
		double TotalValue { get; }
	}
	public enum PatternConstants
	{
		Label,
		Value,
		TotalValue,
		Value1,
		Value2
	}
	public abstract class PatternDataProvider
	{
		private object context;

		protected PatternConstants PatternConstant { get; }

		protected object Context => context;

		protected PatternDataProvider(PatternConstants patternConstant)
		{
			PatternConstant = patternConstant;
		}

		protected abstract bool CheckContext(object value);

		protected abstract object GetValue();

		public void TryAddContext(object context)
		{
			if (CheckContext(context))
			{
				this.context = context;
			}
		}

		public string GetText(string format)
		{
			object value = GetValue();
			if (value != null)
			{
				if (!string.IsNullOrEmpty(format))
				{
					return PatternUtils.Format(value, format);
				}
				return value.ToString();
			}
			return string.Empty;
		}
	}
	public class TreeMapItemPatternProvider : PatternDataProvider
	{
		private IHierarchicalItem Item => (IHierarchicalItem)base.Context;

		public TreeMapItemPatternProvider(PatternConstants patternConstant)
			: base(patternConstant)
		{
		}

		protected override bool CheckContext(object value)
		{
			return value is IHierarchicalItem;
		}

		protected override object GetValue()
		{
			if (Item != null)
			{
				switch (base.PatternConstant)
				{
				case PatternConstants.Label:
					return Item.Label;
				case PatternConstants.Value:
					return Item.Value;
				}
			}
			return null;
		}
	}
	public class CenterLabelPatternProvider : PatternDataProvider
	{
		private ICenterLabelPatternValueHolder ValueHolder => (ICenterLabelPatternValueHolder)base.Context;

		public CenterLabelPatternProvider(PatternConstants patternConstant)
			: base(patternConstant)
		{
		}

		protected override bool CheckContext(object value)
		{
			return value is ICenterLabelPatternValueHolder;
		}

		protected override object GetValue()
		{
			if (base.PatternConstant == PatternConstants.TotalValue)
			{
				return ValueHolder.TotalValue;
			}
			return null;
		}
	}
	public class ToolTipPatternProvider : TreeMapItemPatternProvider
	{
		public ToolTipPatternProvider(PatternConstants patternConstant)
			: base(patternConstant)
		{
		}
	}
	public class ValueRangeLegendItemDataProvider : PatternDataProvider
	{
		public ValueRangeLegendItemDataProvider(PatternConstants patternConstants)
			: base(patternConstants)
		{
		}

		protected override object GetValue()
		{
			if (base.Context != null && (base.PatternConstant == PatternConstants.Value1 || base.PatternConstant == PatternConstants.Value2))
			{
				int num = ((base.PatternConstant == PatternConstants.Value1) ? 0 : 1);
				return ((double[])base.Context)[num];
			}
			return null;
		}

		protected override bool CheckContext(object value)
		{
			if (value is double[])
			{
				return ((double[])value).Length > 1;
			}
			return false;
		}
	}
	public class PatternParser
	{
		private class PatternFragment
		{
			private readonly string fragment;

			private readonly string format;

			private readonly PatternDataProvider dataProvider;

			public string Fragment => fragment;

			public PatternFragment(string fragment, string format, PatternDataProvider dataProvider)
			{
				this.fragment = fragment;
				this.format = format;
				this.dataProvider = dataProvider;
			}

			public string GetText()
			{
				return dataProvider.GetText(format);
			}

			public void SetContext(object context)
			{
				dataProvider.TryAddContext(context);
			}
		}

		private static Dictionary<string, PatternConstants> constants;

		private readonly string pattern;

		private readonly IPatternHolder patternHolder;

		private readonly List<PatternFragment> fragments = new List<PatternFragment>();

		static PatternParser()
		{
			constants = new Dictionary<string, PatternConstants>();
			constants.Add("L", PatternConstants.Label);
			constants.Add("V", PatternConstants.Value);
			constants.Add("TV", PatternConstants.TotalValue);
			constants.Add("V1", PatternConstants.Value1);
			constants.Add("V2", PatternConstants.Value2);
		}

		public PatternParser(string pattern, IPatternHolder patternHolder)
		{
			this.pattern = pattern;
			this.patternHolder = patternHolder;
			Parse();
		}

		private void Parse()
		{
			List<string> list = SplitString(pattern, '{', '}');
			if (list != null)
			{
				foreach (string item in list)
				{
					string format;
					PatternConstants? patternConstant;
					if (PrepareFragment(item, out patternConstant, out format))
					{
						PatternDataProvider dataProvider = patternHolder.GetDataProvider(patternConstant.Value);
						if (dataProvider != null)
						{
							fragments.Add(new PatternFragment(item, format, dataProvider));
						}
					}
				}
			}
		}

		private bool PrepareFragment(string fragment, out PatternConstants? patternConstant, out string format)
		{
			patternConstant = null;
			format = string.Empty;
			if (!fragment.StartsWith("{") || !fragment.EndsWith("}"))
			{
				return false;
			}
			string text = fragment.Substring(1, fragment.Length - 2);
			int num = text.IndexOf(":");
			if (num >= 0)
			{
				format = text.Substring(num + 1).Trim();
				text = text.Substring(0, num);
			}
			text = text.Trim().ToUpper();
			if (!constants.ContainsKey(text))
			{
				return false;
			}
			patternConstant = constants[text];
			return true;
		}

		private List<string> SplitString(string splittingString, char leftSeparator, char rightSeparator)
		{
			List<string> list = new List<string>();
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			if (!string.IsNullOrEmpty(splittingString))
			{
				foreach (char c in splittingString)
				{
					if (c == leftSeparator)
					{
						num = num3;
					}
					else if (c == rightSeparator)
					{
						num2 = num3;
						list.Add(splittingString.Substring(num, num2 - num + 1));
					}
					num3++;
				}
				return list;
			}
			return null;
		}

		public void SetContext(params object[] contexts)
		{
			foreach (PatternFragment fragment in fragments)
			{
				foreach (object context in contexts)
				{
					fragment.SetContext(context);
				}
			}
		}

		public string GetText()
		{
			string text = pattern;
			foreach (PatternFragment fragment in fragments)
			{
				text = text.Replace(fragment.Fragment, fragment.GetText());
			}
			return text;
		}
	}
	public static class PatternUtils
	{
		public static string Format(object value, string format)
		{
			IFormattable formattable = value as IFormattable;
			try
			{
				if (formattable != null)
				{
					return formattable.ToString(format, CultureInfo.CurrentCulture);
				}
			}
			catch
			{
			}
			if (!(value is string))
			{
				return value.ToString() + ":" + format;
			}
			return (string)value;
		}
	}
	public class TreeMapItemHelper
	{
		private static bool FillItemPath<T>(T requestItem, List<T> itemPath, IEnumerable<T> items) where T : class, IHierarchicalItem
		{
			foreach (T item in items)
			{
				if (requestItem == item)
				{
					itemPath.Add(item);
					return true;
				}
				if (item.Children.Count > 0 && FillItemPath(requestItem, itemPath, (IEnumerable<T>)item.Children))
				{
					itemPath.Insert(0, item);
					return true;
				}
			}
			return false;
		}

		public static List<T> GetItemPath<T>(T item, IEnumerable<T> items) where T : class, IHierarchicalItem
		{
			List<T> list = new List<T>();
			FillItemPath(item, list, items);
			return list;
		}

		public static bool IsGroupItem(IHierarchicalItem item)
		{
			if (item.Children != null)
			{
				return item.Children.Count > 0;
			}
			return false;
		}
	}
	public enum PrintImageFormat
	{
		Bitmap,
		Metafile
	}
}
