"""Move the XamlGeneratedNamespace block to the end of the source file.

Roslyn emits TypeDefs for namespaces in reverse order of their first declaration,
so the original's helper-first order requires the namespace to be declared last.
Usage: move_ns.py <file>
"""
import sys
from pathlib import Path

p = Path(sys.argv[1])
text = p.read_text(encoding="utf-8-sig")
start = text.index("namespace XamlGeneratedNamespace")
open_brace = text.index("{", start)
depth = 0
i = open_brace
while True:
    if text[i] == "{":
        depth += 1
    elif text[i] == "}":
        depth -= 1
        if depth == 0:
            break
    i += 1
block = text[start:i + 1]
rest = text[:start] + text[i + 1:]
rest = rest.rstrip("\n") + "\n" + block + "\n"
p.write_text(rest, encoding="utf-8")
print("moved", len(block), "bytes")
