#!/usr/bin/env python3
"""Reproduce DevExpress.DataVisualization.v23.2.Core.dll (1e3f6ded) byte-for-byte.

Usage:  py -3 reproduce.py <archive.zip> <new-empty-directory>

Steps:
  1. extract the archive into <new-empty-directory>;
  2. recompile the archived C# source with the pinned csc + fixed_flags
     (includes /debug+) using the archived build-plan;
  3. normalize the compiler output (COFF timestamp, #GUID MVID, strong-name
     signature and CodeView debug record are path-dependent and are replayed
     verbatim from the original) and check its SHA-256 equals the recipe's
     compiler_output_sha256 -- this makes the comparison directory-independent;
  4. replay original metadata / strong name / certificate / debug record and
     emit the exact image; verify SHA-256 equals the original.
"""
import sys, json, zipfile
from hashlib import sha256
from pathlib import Path


def digest(b):
    return sha256(b).hexdigest()


def main(archive, outdir):
    archive = Path(archive).resolve()
    out = Path(outdir)
    if out.exists() and any(out.iterdir()):
        raise SystemExit("output directory must be new/empty: %s" % out)
    out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for name in z.namelist():
            p = out / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(z.read(name))
    sys.path.insert(0, str(out / "tools"))
    sys.path.insert(0, str(out))
    import replay, token_replay, normalize, pe_layout_replay
    token_replay.finish_image = pe_layout_replay.finish_image

    work = out / "work"
    import os
    os.makedirs(r"C:\pdbscratch", exist_ok=True)
    compiled_path = replay.build(archive, work)
    raw = compiled_path.read_bytes()
    norm = normalize.normalize(raw)
    with zipfile.ZipFile(archive) as z:
        recipe = json.loads(z.read("layout-recipe.json"))
        metadata = z.read("original-build/clr-metadata.bin")
        debug = z.read("original-build/debug-record.bin")
        certificate = z.read("original-build/certificate-table.bin")
        strong = z.read("original-build/strong-name.bin") if recipe.get("strong_name") else b""
    if digest(norm) != recipe["compiler_output_sha256"]:
        raise SystemExit("normalized compiler output %s != recipe compiler_output_sha256 %s"
                         % (digest(norm), recipe["compiler_output_sha256"]))
    image = token_replay.reproduce(norm, recipe, metadata, debug, certificate, strong)
    dest = out / "exact" / compiled_path.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(image)
    ok = digest(image) == recipe["original_sha256"]
    print(json.dumps({"artifact": str(dest), "artifact_sha256": digest(image),
                      "original_sha256": recipe["original_sha256"],
                      "compiler_output_raw_sha256": digest(raw),
                      "compiler_output_normalized_sha256": digest(norm),
                      "equal": ok}, ensure_ascii=False, indent=1))
    return 0 if ok else 1


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    sys.exit(main(sys.argv[1], sys.argv[2]))
