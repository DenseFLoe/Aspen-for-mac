"""Structural identity for CLR metadata rows, and token relocation for CIL bodies.

The managed layout recipe replays the *original* #~ metadata blob, so every token
operand a compiler emits points into the compiler's own table order and must be
rewritten to the original token. This module derives that bijection from the two
metadata images alone (no disassembler, no IL text):

  identity(image)            canonical key per row of the IL-visible tables
  token_map(original, new)   old<->new row indexes per table, plus #US strings
  relocate(body, mapping)    patch one compiled CIL body into original token space

A key is built from names, owner chains, scopes and *canonicalised signatures*
(ECMA-335 II.23.2), so row order, heap order and heap offsets are irrelevant.
"""

import struct

import pefile

import clr_meta


class IdentityError(ValueError):
    """A metadata row cannot be identified between the two images."""


# tables whose rows can appear as IL token operands
TYPE_DEF, TYPE_REF, TYPE_SPEC = 0x02, 0x01, 0x1B
FIELD, METHOD_DEF, MEMBER_REF = 0x04, 0x06, 0x0A
STAND_ALONE_SIG, METHOD_SPEC = 0x11, 0x2B
MODULE_REF, ASSEMBLY, ASSEMBLY_REF = 0x1A, 0x20, 0x23

TOKEN_TABLES = {0x01: TYPE_REF, 0x02: TYPE_DEF, 0x04: FIELD, 0x06: METHOD_DEF,
                0x0A: MEMBER_REF, 0x11: STAND_ALONE_SIG, 0x1B: TYPE_SPEC, 0x2B: METHOD_SPEC}
US_TABLE = 0x70


def _compressed(data, at):
    """Read an ECMA-335 II.23.2 compressed unsigned integer."""
    lead = data[at]
    if lead & 0x80 == 0:
        return lead, at + 1
    if lead & 0xC0 == 0x80:
        return ((lead & 0x3F) << 8) | data[at + 1], at + 2
    if lead & 0xE0 == 0xC0:
        return ((lead & 0x1F) << 24) | (data[at + 1] << 16) | (data[at + 2] << 8) | data[at + 3], at + 4
    raise IdentityError("Invalid compressed integer")


class Image:
    """A read-only view of one managed PE plus its canonical row identities."""

    def __init__(self, data, label=""):
        self.label = label
        self.pe = pefile.PE(data=data, fast_load=True)
        self.cli = clr_meta.cli_header(self.pe)
        self.root = clr_meta.metadata_root(self.pe, self.cli)
        self.tables = self.root["tables"]
        self._cache = {}
        self._sig_cache = {}
        self._nested = None
        self._owners = None

    # ------------------------------------------------------------ heap access
    def string(self, index):
        if not index:
            return ""
        return clr_meta.strings(self.pe, self.cli, self.root, index)

    def blob_bytes(self, index):
        if not index:
            return b""
        return clr_meta.blob(self.pe, self.cli, self.root, index)

    def us(self, index):
        heap = self.root["streams"]["#US"]
        if not 0 < index < heap["size"]:
            raise IdentityError("#US index out of range")
        base = self.cli["metadata_rva"] + heap["offset"]
        payload = self.pe.get_data(base + index, heap["size"] - index)
        length, at = _compressed(payload, 0)
        data = payload[at:at + length]
        if len(data) != length:
            raise IdentityError("#US string extent exceeds its heap")
        return data

    def rows(self, table):
        return self.tables["layout"][table]["rows"] if table in self.tables["layout"] else 0

    def row(self, table, index):
        return clr_meta.read_row(self.root["bytes"], self.tables, table, index)

    # ------------------------------------------------------- table structure
    def nested_parents(self):
        if self._nested is None:
            parents = {}
            for index in range(1, self.rows(0x29) + 1):
                row = self.row(0x29, index)
                parents[row[0]] = row[1]
            self._nested = parents
        return self._nested

    def owners(self):
        """Map Field/MethodDef row indexes to their declaring TypeDef row."""
        if self._owners is None:
            fields, methods = {}, {}
            count = self.rows(TYPE_DEF)
            starts = [self.row(TYPE_DEF, i)[4] for i in range(1, count + 1)]
            mstarts = [self.row(TYPE_DEF, i)[5] for i in range(1, count + 1)]
            for position, row in enumerate(range(1, count + 1)):
                first = starts[position]
                last = starts[position + 1] if position + 1 < count else self.rows(FIELD) + 1
                for index in range(first, last):
                    fields[index] = row
                first = mstarts[position]
                last = mstarts[position + 1] if position + 1 < count else self.rows(METHOD_DEF) + 1
                for index in range(first, last):
                    methods[index] = row
            self._owners = (fields, methods)
        return self._owners

    # ------------------------------------------------------------- type keys
    def type_key(self, coded):
        tag, index = coded & 3, coded >> 2
        if tag == 0:
            return self.type_def_key(index)
        if tag == 1:
            return self.type_ref_key(index)
        if tag == 2:
            return self.type_spec_key(index)
        raise IdentityError("Unsupported TypeDefOrRef tag %d" % tag)

    def type_def_key(self, index):
        cached = self._cache.get(("td", index))
        if cached:
            return cached
        row = self.row(TYPE_DEF, index)
        name, namespace = self.string(row[1]), self.string(row[2])
        parent = self.nested_parents().get(index)
        key = ("td", namespace, name, self.type_def_key(parent) if parent else None)
        self._cache[("td", index)] = key
        return key

    def scope_key(self, coded):
        tag, index = coded & 3, coded >> 2
        if tag == 0:
            row = self.row(0x00, index)
            return ("module", self.string(row[1]))
        if tag == 1:
            row = self.row(MODULE_REF, index)
            return ("mr", self.string(row[0]))
        if tag == 2:
            row = self.row(ASSEMBLY_REF, index)
            name, culture = self.string(row[7]), self.string(row[6])
            token = self.blob_bytes(row[5]).hex()
            versioned = (name, culture, token) in self.ambiguous_references()
            if versioned:
                return ("assembly", name, row[0], row[1], row[2], row[3], culture, token)
            return ("assembly", name, 0, 0, 0, 0, culture, token)
        if tag == 3:
            return self.type_ref_key(index)
        raise IdentityError("Unsupported ResolutionScope tag %d" % tag)

    def ambiguous_references(self):
        """AssemblyRef identities that repeat with different versions in this image."""
        if getattr(self, "_balanced", None) is not None:
            return self._balanced
        groups = {}
        for index in range(1, self.rows(ASSEMBLY_REF) + 1):
            row = self.row(ASSEMBLY_REF, index)
            key = (self.string(row[7]), self.string(row[6]), self.blob_bytes(row[5]).hex())
            groups.setdefault(key, set()).add((row[0], row[1], row[2], row[3]))
        self._balanced = {key for key, versions in groups.items() if len(versions) > 1}
        return self._balanced

    def type_ref_key(self, index):
        cached = self._cache.get(("tr", index))
        if cached:
            return cached
        row = self.row(TYPE_REF, index)
        key = ("tr", self.scope_key(row[0]), self.string(row[2]), self.string(row[1]))
        self._cache[("tr", index)] = key
        return key

    def type_spec_key(self, index):
        cached = self._cache.get(("ts", index))
        if cached:
            return cached
        self._cache[("ts", index)] = ("ts", "cycle", index)
        key = ("ts", self.signature(self.blob_bytes(self.row(TYPE_SPEC, index)[0]), "type"))
        self._cache[("ts", index)] = key
        return key

    def member_ref_parent(self, coded):
        tag, index = coded & 7, coded >> 3
        table = {0: TYPE_DEF, 1: TYPE_REF, 2: MODULE_REF, 3: METHOD_DEF, 4: TYPE_SPEC}.get(tag)
        if table == TYPE_DEF:
            return self.type_def_key(index)
        if table == TYPE_REF:
            return self.type_ref_key(index)
        if table == MODULE_REF:
            return ("mr", self.string(self.row(MODULE_REF, index)[0]))
        if table == METHOD_DEF:
            return self.method_def_key(index)
        if table == TYPE_SPEC:
            return self.type_spec_key(index)
        raise IdentityError("Unsupported MemberRefParent tag %d" % tag)

    # -------------------------------------------------* signature canonical
    def signature(self, data, kind="auto"):
        """Canonical structure of one signature blob; kind disambiguates conventions."""
        if not data:
            raise IdentityError("Empty signature blob")
        first = data[0]
        if kind == "type":
            key, at = self._type(data, 0)
        elif kind == "method":
            key, at = self._method_sig(data, 0)
        elif kind == "field":
            if first != 0x06:
                raise IdentityError("Field signature lacks its calling convention")
            key, at = self._type(data, 1)
        elif first == 0x07:                                # LOCALVAR
            count, at = _compressed(data, 1)
            locals_ = []
            for _ in range(count):
                item, at = self._type(data, at)
                locals_.append(item)
            key = ("locals", tuple(locals_))
        elif first == 0x08:                                # PROPERTY
            count, at = _compressed(data, 1)
            ret, at = self._type(data, at)
            params = []
            for _ in range(count):
                item, at = self._type(data, at)
                params.append(item)
            key = ("property", ret, tuple(params))
        elif first == 0x0A:                                # METHODSPEC instantiation
            count, at = _compressed(data, 1)
            arguments = []
            for _ in range(count):
                item, at = self._type(data, at)
                arguments.append(item)
            key = ("instantiation", tuple(arguments))
        elif first == 0x06:                                # FIELD
            key, at = self._type(data, 1)
        else:
            key, at = self._method_sig(data, 0)
        if at != len(data):
            raise IdentityError("Signature blob has trailing bytes")
        return key

    def _type(self, data, at, terminal=False):
        if at >= len(data):
            raise IdentityError("Signature truncated")
        element = data[at]
        at += 1
        if element in (0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B,
                       0x0C, 0x0D, 0x0E, 0x16, 0x18, 0x19, 0x1C):
            return ("p", element), at
        if element in (0x11, 0x12):                       # VALUETYPE / CLASS
            token, at = _compressed(data, at)
            return ("t", self.type_key(token)), at
        if element in (0x13, 0x1E):                       # VAR / MVAR
            number, at = _compressed(data, at)
            return ("var" if element == 0x13 else "mvar", number), at
        if element == 0x0F:                               # PTR
            inner, at = self._type(data, at)
            return ("ptr", inner), at
        if element == 0x10:                               # BYREF
            inner, at = self._type(data, at)
            return ("byref", inner), at
        if element == 0x1D:                               # SZARRAY
            inner, at = self._type(data, at)
            return ("szarray", inner), at
        if element == 0x14:                               # ARRAY
            inner, at = self._type(data, at)
            rank, at = _compressed(data, at)
            sizes = []
            for _ in range(_compressed(data, at)[0]):
                value, at = _compressed(data, at)
                sizes.append(value)
            bounds = []
            for _ in range(_compressed(data, at)[0]):
                value, at = _compressed(data, at)
                bounds.append(value)
            return ("array", inner, rank, tuple(sizes), tuple(bounds)), at
        if element == 0x15:                               # GENERICINST <class|valuetype> tok count args
            form = data[at]
            if form not in (0x11, 0x12):
                raise IdentityError("Generic instantiation lacks a class/valuetype form")
            at += 1
            token, at = _compressed(data, at)
            count, at = _compressed(data, at)
            arguments = []
            for _ in range(count):
                item, at = self._type(data, at)
                arguments.append(item)
            return ("generic", form, self.type_key(token), tuple(arguments)), at
        if element == 0x1B:                               # FNPTR
            inner, at = self._method_sig(data, at)
            return ("fnptr", inner), at
        if element in (0x1F, 0x20):                       # CMOD_REQD / CMOD_OPT
            token, at = _compressed(data, at)
            inner, at = self._type(data, at)
            return ("mod", element, self.type_key(token), inner), at
        if element == 0x45:                               # PINNED
            inner, at = self._type(data, at)
            return ("pinned", inner), at
        raise IdentityError("Unsupported signature element 0x%02X" % element)

    def _method_sig(self, data, at):
        convention = data[at]
        at += 1
        generic = 0
        if convention & 0x10:
            generic, at = _compressed(data, at)
        count, at = _compressed(data, at)
        ret, at = self._type(data, at) if data[at] != 0x01 else (("p", 0x01), at + 1)
        params = []
        for _ in range(count):
            if data[at] == 0x41:
                at += 1
            item, at = self._type(data, at)
            params.append(item)
        return ("method", convention & 0x0F, generic, ret, tuple(params)), at

    # ------------------------------------------------------------- row keys
    def field_key(self, index):
        cached = self._cache.get(("f", index))
        if cached:
            return cached
        fields, _ = self.owners()
        owner = fields.get(index)
        if owner is None:
            raise IdentityError("Field row %d has no declaring type" % index)
        row = self.row(FIELD, index)
        key = ("f", self.type_def_key(owner), self.string(row[1]), self.signature(self.blob_bytes(row[2]), "field"))
        self._cache[("f", index)] = key
        return key

    def method_def_key(self, index):
        cached = self._cache.get(("m", index))
        if cached:
            return cached
        _, methods = self.owners()
        owner = methods.get(index)
        if owner is None:
            raise IdentityError("MethodDef row %d has no declaring type" % index)
        row = self.row(METHOD_DEF, index)
        key = ("m", self.type_def_key(owner), self.string(row[3]), self.signature(self.blob_bytes(row[4]), "method"))
        self._cache[("m", index)] = key
        return key

    def member_ref_key(self, index):
        cached = self._cache.get(("mr", index))
        if cached:
            return cached
        row = self.row(MEMBER_REF, index)
        key = ("mr", self.member_ref_parent(row[0]), self.string(row[1]),
               self.signature(self.blob_bytes(row[2])))
        self._cache[("mr", index)] = key
        return key

    def method_spec_key(self, index):
        cached = self._cache.get(("ms", index))
        if cached:
            return cached
        row = self.row(METHOD_SPEC, index)
        tag, target = row[0] & 1, row[0] >> 1
        base = self.method_def_key(target) if tag == 0 else self.member_ref_key(target)
        key = ("ms", base, self.signature(self.blob_bytes(row[1])))
        self._cache[("ms", index)] = key
        return key

    def stand_alone_sig_key(self, index):
        return ("sig", self.signature(self.blob_bytes(self.row(STAND_ALONE_SIG, index)[0])))

    def key(self, table, index):
        if table == TYPE_DEF:
            return self.type_def_key(index)
        if table == TYPE_REF:
            return self.type_ref_key(index)
        if table == TYPE_SPEC:
            return self.type_spec_key(index)
        if table == FIELD:
            return self.field_key(index)
        if table == METHOD_DEF:
            return self.method_def_key(index)
        if table == MEMBER_REF:
            return self.member_ref_key(index)
        if table == METHOD_SPEC:
            return self.method_spec_key(index)
        if table == STAND_ALONE_SIG:
            return self.stand_alone_sig_key(index)
        raise IdentityError("Table 0x%02X has no structural key" % table)


def _rows(image, table):
    return {image.key(table, index): index for index in range(1, image.rows(table) + 1)} if False else None


def _collect(image, table):
    out = {}
    for index in range(1, image.rows(table) + 1):
        out.setdefault(image.key(table, index), []).append(index)
    return out


def _string_rows(image):
    out = {}
    heap = image.root["streams"]["#US"]
    size = heap["size"]
    index = 1
    base = image.cli["metadata_rva"] + heap["offset"]
    while index < size:
        payload = image.pe.get_data(base + index, size - index)
        length, at = _compressed(payload, 0)
        body = payload[at:at + length]
        out.setdefault(bytes(body), []).append(index)
        index += at + length
        if length % 2:
            index += 1
    return out


def token_map(original, compiled):
    """Bijection between compiled token rows and original token rows."""
    forward, backward, problems = {}, {}, []
    tables = sorted(TOKEN_TABLES)
    for table in tables:
        old = _collect(original, table)
        new = _collect(compiled, table)
        for key, rows in old.items():
            if len(rows) != 1:
                problems.append({"table": table, "reason": "duplicate original identity", "key": str(key)[:160]})
        for key, rows in new.items():
            if key not in old:
                problems.append({"table": table, "reason": "compiled row has no original identity",
                                 "key": str(key)[:160]})
                continue
            if len(rows) != 1 or len(old[key]) != 1:
                continue
            forward.setdefault(table, {})[rows[0]] = old[key][0]
            backward.setdefault(table, {})[old[key][0]] = rows[0]
        for key, rows in old.items():
            if key not in new:
                problems.append({"table": table, "reason": "original row has no compiled identity",
                                 "key": str(key)[:160]})
    old_us = _string_rows(original)
    new_us = _string_rows(compiled)
    us_forward, us_backward = {}, {}
    for content, rows in new_us.items():
        if content in old_us and len(old_us[content]) == 1 and len(rows) == 1:
            us_forward[rows[0]] = old_us[content][0]
            us_backward[old_us[content][0]] = rows[0]
        elif content not in old_us:
            problems.append({"table": US_TABLE, "reason": "compiled #US string has no original row",
                             "key": content[:60].hex()})
    return {"forward": forward, "backward": backward, "us_forward": us_forward,
            "us_backward": us_backward, "problems": problems}


# ------------------------------------------------------------ IL relocation
TOKEN_OPCODES = {0x28, 0x29, 0x6F, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x79, 0x7B, 0x7C,
                 0x7D, 0x7E, 0x7F, 0x80, 0x81, 0x8C, 0x8D, 0x8F, 0xA3, 0xA4, 0xA5, 0xC2,
                 0xC6, 0xD0}
TWO_BYTE_TOKEN = {0x06, 0x07, 0x15, 0x16, 0x1C}
TWO_BYTE_U16 = {0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E}
ONE_BYTE_OPERAND = set(range(0x0E, 0x14)) | {0x1F, 0xDE} | set(range(0x2B, 0x38))
FOUR_BYTE_OPERAND = {0x20, 0x22, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F, 0x40,
                     0x41, 0x42, 0x43, 0x44, 0xDD}
EIGHT_BYTE_OPERAND = {0x21, 0x23}


def _operand_points(body, start, end):
    """Yield (offset, width, kind) for every instruction operand in one CIL span."""
    at = start
    while at < end:
        opcode = body[at]
        if opcode == 0xFE:
            if at + 1 >= end:
                raise IdentityError("Truncated two-byte CIL opcode")
            second = body[at + 1]
            size = 2
            if second in TWO_BYTE_TOKEN:
                yield at + 2, 4, "token"
                size += 4
            elif second in TWO_BYTE_U16:
                size += 2
            at += size
            continue
        if opcode in TOKEN_OPCODES:
            yield at + 1, 4, "token"
            at += 5
        elif opcode == 0x27:                       # switch: 4-byte count then targets
            if at + 5 > end:
                raise IdentityError("Truncated CIL switch")
            count = struct.unpack_from("<I", body, at + 1)[0]
            at += 5 + 4 * count
        elif opcode in FOUR_BYTE_OPERAND:
            at += 5
        elif opcode in EIGHT_BYTE_OPERAND:
            at += 9
        elif opcode in ONE_BYTE_OPERAND:
            at += 2
        else:
            at += 1
    if at != end:
        raise IdentityError("CIL instruction stream overruns its declared code size")


def _sections(body):
    if not body:
        return None
    first = body[0]
    if first & 3 == 2:
        head, code, flags = 1, first >> 2, None
    elif first & 3 == 3:
        raw, = struct.unpack_from("<H", body)
        head = (raw >> 12) * 4
        flags = raw & 0xFFF
        if head != 12:
            raise IdentityError("Nonstandard fat CIL method header")
        code, = struct.unpack_from("<I", body, 4)
    else:
        raise IdentityError("Unknown CIL method header")
    if head + code > len(body):
        raise IdentityError("CIL method extent exceeds its body")
    return head, code, flags


def _exception_points(body, head, code):
    """Return (clause_offset, class_token_offset, kind) for each exception clause."""
    at = (head + code + 3) & ~3
    if at >= len(body):
        return []
    flags = body[at]
    if flags & 0x3F != 1 or flags & 0x80:
        raise IdentityError("Unknown or chained CIL exception section")
    fat = bool(flags & 0x40)
    width = 24 if fat else 12
    size = int.from_bytes(body[at + 1:at + 4], "little") if fat else body[at + 1]
    if at + size != len(body) or (size - 4) % width:
        raise IdentityError("CIL exception section extent differs from its clause count")
    out = []
    for index in range((size - 4) // width):
        start = at + 4 + index * width
        kind = int.from_bytes(body[start:start + 4], "little") if fat else int.from_bytes(body[start:start + 2], "little")
        out.append((start, start + width - 4, kind))
    return out


def relocate(body, mapping, *, local_signature=None):
    """Patch one compiled CIL body into original token space; return (bytes, patches)."""
    parsed = _sections(body)
    if parsed is None:
        return b"", []
    head, code, _ = parsed
    output = bytearray(body)
    patches = []
    for offset, width, kind in _operand_points(body, head, head + code):
        token = struct.unpack_from("<I", body, offset)[0]
        table, row = token >> 24, token & 0xFFFFFF
        if table == US_TABLE:
            target = mapping["us_forward"].get(row)
            kind_name = "user string"
        else:
            target = mapping["forward"].get(table, {}).get(row)
            kind_name = "CIL operand"
        if target is None:
            raise IdentityError("Unmapped token 0x%08X (%s) at offset %d" % (token, kind_name, offset))
        new_token = (table << 24) | target
        if new_token != token:
            struct.pack_into("<I", output, offset, new_token)
            patches.append({"method_offset": offset, "candidate_token": token,
                            "original_token": new_token, "kind": kind_name})
    if head == 12:
        index, = struct.unpack_from("<I", body, 8)
        if index:
            target = mapping["forward"].get(STAND_ALONE_SIG, {}).get(index)
            if target is None:
                raise IdentityError("Unmapped local variable signature 0x%08X" % index)
            if target != index:
                struct.pack_into("<I", output, 8, target)
                patches.append({"method_offset": 8, "candidate_token": index,
                                "original_token": target, "kind": "local variable signature"})
    for clause, token_at, space in _exception_points(body, head, code):
        value, = struct.unpack_from("<I", body, token_at)
        if not value:
            continue
        table, row = value >> 24, value & 0xFFFFFF
        target = mapping["forward"].get(table, {}).get(row)
        if target is None:
            raise IdentityError("Unmapped exception type token 0x%08X" % value)
        new_value = (table << 24) | target
        if new_value != value:
            struct.pack_into("<I", output, token_at, new_value)
            patches.append({"method_offset": token_at, "candidate_token": value,
                            "original_token": new_value, "kind": "catch type"})
    return bytes(output), patches

def pair_methods(original, compiled, mapping=None):
    """Pair MethodDef rows by identity and verify every body in original token space."""
    from hashlib import sha256
    mapping = mapping or token_map(original, compiled)
    forward = {}
    for index in range(1, compiled.rows(METHOD_DEF) + 1):
        forward.setdefault(compiled.method_def_key(index), []).append(index)
    pairs, gaps, used = [], [], set()
    for index in range(1, original.rows(METHOD_DEF) + 1):
        key = original.method_def_key(index)
        name = original.string(original.row(METHOD_DEF, index)[3])
        candidates = forward.get(key, [])
        if len(candidates) != 1:
            gaps.append({"kind": "declaration_gap", "token": "0x%08X" % (0x06000000 | index),
                         "name": name, "detail": "no unique compiled counterpart at this identity"})
            continue
        other = candidates[0]
        used.add(other)
        old, new = original.row(METHOD_DEF, index), compiled.row(METHOD_DEF, other)
        if not old[0] and not new[0]:
            continue
        if not old[0] or not new[0]:
            gaps.append({"kind": "declaration_gap", "token": "0x%08X" % (0x06000000 | index),
                         "name": name, "detail": "one side has no CIL body"})
            continue
        old_bytes = clr_meta.method_extent(original.pe, old[0])
        new_bytes = clr_meta.method_extent(compiled.pe, new[0])
        body_old = original.pe.get_data(old[0], old_bytes[0])
        body_new = compiled.pe.get_data(new[0], new_bytes[0])
        try:
            patched, patches = relocate(body_new, mapping)
        except IdentityError as problem:
            gaps.append({"kind": "token_gap", "token": "0x%08X" % (0x06000000 | index),
                         "name": name, "detail": str(problem)})
            continue
        if patched != body_old:
            first = next((i for i, (x, y) in enumerate(zip(body_old, patched)) if x != y),
                         min(len(body_old), len(patched)))
            gaps.append({"kind": "source_form_gap", "token": "0x%08X" % (0x06000000 | index),
                         "name": name, "original_bytes": len(body_old),
                         "candidate_bytes": len(patched), "first_difference_offset": first,
                         "detail": "CIL body differs from the original body beyond token relocation"})
            continue
        pairs.append({"original_token": "0x%08X" % (0x06000000 | index),
                      "candidate_token": "0x%08X" % (0x06000000 | other),
                      "original_rva": old[0], "candidate_rva": new[0],
                      "bytes": len(body_old), "body_sha256": sha256(body_old).hexdigest(),
                      "remapped_tokens": patches})
    for index in range(1, compiled.rows(METHOD_DEF) + 1):
        if index not in used:
            gaps.append({"kind": "declaration_gap", "token": "0x%08X" % (0x06000000 | index),
                         "name": compiled.string(compiled.row(METHOD_DEF, index)[3]),
                         "detail": "compiled method has no original counterpart"})
    return pairs, gaps, mapping
