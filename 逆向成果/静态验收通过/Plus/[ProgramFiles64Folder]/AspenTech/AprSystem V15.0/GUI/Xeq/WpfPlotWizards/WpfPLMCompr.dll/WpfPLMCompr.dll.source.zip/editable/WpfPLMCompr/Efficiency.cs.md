# Efficiency.cs

Source: editable/WpfPLMCompr/Efficiency.cs

Source SHA-256: a0b0ad9094bc15ce8a80a122aaac05156eff6996ef5d537fc473c31fb375670c
