using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPLControls;
using WpfPlotwizard;

namespace WpfPLVscrub;

[ProgId("WpfPLVscrub.Efficiency")]
public class Efficiency : UserControl, IRibbonPlotWizardType, IPlotWizardTemplate, IComponentConnector
{
	private IHNode _context;

	private IHWizardPlot2 _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private string _uniqueId = "Efficiency";

	private string _plotName;

	private object _nodeCxs;

	private string _currentLengthUnit = string.Empty;

	private System.Drawing.Image _imgBitmap;

	private bool _bHasInputDialog;

	private string _currentConfigValue = string.Empty;

	private readonly string _lengthUnitFieldId = WpfPLRPlugResources.Length;

	public static RoutedCommand OKCommand = new RoutedCommand();

	public static RoutedCommand CancelCommand = new RoutedCommand();

	private bool _bCheckDataOnly;

	internal CurvesSelectorControl CurveList;

	private bool _contentLoaded;

	public string TooltipContentForRibbonItem => WpfPLViscrubResources.TooltipContent_DropletEfficiency;

	public string TooltipHeaderForRibbonItem => WpfPLViscrubResources.TooltipHeader_DropletEfficiency;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot2;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { _lengthUnitFieldId };

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public Efficiency()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		InitializeComponent();
		_bHasInputDialog = true;
		if (_imgBitmap == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLVscrub.Images.SepEff.ico");
			_imgBitmap = new Bitmap(manifestResourceStream);
		}
		CommandBinding commandBinding = new CommandBinding(OKCommand, ExecuteOKCommand, CanExecuteOKCommand);
		CommandBinding commandBinding2 = new CommandBinding(CancelCommand, ExecuteCancelCommand);
		base.CommandBindings.Add(commandBinding);
		base.CommandBindings.Add(commandBinding2);
	}

	public void SetCaption(ref string caption)
	{
		caption = WpfPLViscrubResources.Caption_DropletEfficiency;
	}

	public void SetDefaultHeight(ref double defaultHeight)
	{
		defaultHeight = 270.0;
	}

	public void SetDefaultWidth(ref double defaultWidth)
	{
		defaultWidth = 300.0;
	}

	public void SetMinHeight(ref double minHeight)
	{
		minHeight = 270.0;
	}

	public void SetMinWidth(ref double minWidth)
	{
		minWidth = 300.0;
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
		{
			List<string> list = new List<string>();
			_help.LoadXUnitsList(_context.Application.Tree, (IHWizardPlot)_wizardPlot, list);
			return list;
		}
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
		if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
		{
			sCurrentVal = _help.GetXUnitString(_context.Application.Tree, (IHWizardPlot)_wizardPlot);
		}
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
		if (sFieldName.CompareTo(_lengthUnitFieldId) == 0)
		{
			_currentLengthUnit = sValue;
		}
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		if (sField.CompareTo(_lengthUnitFieldId) == 0)
		{
			return (RibbonControlType)1;
		}
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
		sConfigValue = _currentConfigValue;
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
		_currentConfigValue = sValue;
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot2;
		new List<string>();
		IHNode iHNode = _context.FindNode("Output/EFFICIENCY2");
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		string[] array = new string[3] { "Output/LINE1", "Output/LINE2", "Output/LINE3" };
		List<string> list = new List<string>();
		int count = iHNode.Elements.Count;
		for (int i = 0; i < count; i++)
		{
			string text = "";
			for (int j = 0; j < array.GetLength(0); j++)
			{
				string path = array[j] + "/" + (i + 1);
				string text2 = (dynamic)_context.FindNode(path).get_Value(Type.Missing);
				if (!string.IsNullOrEmpty(text2))
				{
					text = text + text2.Trim() + " ";
				}
			}
			list.Add(text);
		}
		CurveList.SetCurves(list.ToArray());
		if (list.Count == 1)
		{
			CurveList.IsCheckAll = true;
			_bHasInputDialog = false;
		}
		if (!string.IsNullOrEmpty(_currentConfigValue))
		{
			CurveList.IsCheckAll = false;
			RestoreConfigValue(_currentConfigValue);
		}
		_wizardPlot.SetIndependentVariable(_context, "Output/DROP_DIAM2");
	}

	public void UpdateWizardData()
	{
		_wizardPlot.RemoveAllDependentVariable();
		List<string> list = new List<string>(CurveList.GetSelectedCurves());
		int count = list.Count;
		for (int i = 0; i < count; i++)
		{
			string text = list[i];
			int selectedCurveIndex = CurveList.GetSelectedCurveIndex(text);
			string depvar = "Output/EFFICIENCY2/" + (selectedCurveIndex + 1);
			_wizardPlot.AddDependentVariable(_context, depvar);
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(i, text);
		}
		((IHPlotVal)_wizardPlot.PlotVal).set_AxisScale(0, 1);
		_help.SaveXUnitsComboText(_context.Application.Tree, (IHWizardPlot)_wizardPlot, _currentLengthUnit);
		_currentConfigValue = SaveConfigValue();
	}

	private string SaveConfigValue()
	{
		_ = string.Empty;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("Curvelection=");
		List<string> list = new List<string>(CurveList.GetSelectedCurves());
		int count = list.Count;
		for (int i = 0; i < count; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(",");
			}
			stringBuilder.Append(list[i]);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("CheckAll=");
		stringBuilder.Append(CurveList.IsCheckAll);
		stringBuilder.Append(";");
		return stringBuilder.ToString();
	}

	private void RestoreConfigValue(string ConfigString)
	{
		string[] array = ConfigString.Split(';');
		int num = 0;
		string text = array[num].Substring(array[num].IndexOf('=') + 1);
		string[] array2 = text.Split(',');
		List<string> list = new List<string>();
		string[] array3 = array2;
		foreach (string item in array3)
		{
			list.Add(item);
		}
		CurveList.SetSelectedCurves(list.ToArray());
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		CurveList.IsCheckAll = Convert.ToBoolean(text);
	}

	private void ExecuteOKCommand(object sender, ExecutedRoutedEventArgs e)
	{
		UpdateWizardData();
		_help.CloseForm((UserControl)this, (bool?)true);
	}

	private void CanExecuteOKCommand(object sender, CanExecuteRoutedEventArgs e)
	{
		int num = CurveList.GetSelectedCurves().Count();
		e.CanExecute = num != 0;
	}

	private void ExecuteCancelCommand(object sender, ExecutedRoutedEventArgs e)
	{
		if (!string.IsNullOrEmpty(_currentConfigValue))
		{
			RestoreConfigValue(_currentConfigValue);
		}
		_help.CloseForm((UserControl)this, (bool?)false);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	public void InitializeComponent()
	{
		if (_contentLoaded)
		{
			return;
		}
		_contentLoaded = true;
		Uri resourceLocator = new Uri("/WpfPLVscrub;component/efficiency.xaml", UriKind.Relative);
		Application.LoadComponent(this, resourceLocator);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		if (connectionId == 1)
		{
			CurveList = (CurvesSelectorControl)target;
		}
		else
		{
			_contentLoaded = true;
		}
	}
}
