# AssemblyInfo.cs

Source: editable/Properties/AssemblyInfo.cs

Source SHA-256: 705773f7ffeedb4af3987845f82d1fa8a29546477e78889affb071517a6f098b
