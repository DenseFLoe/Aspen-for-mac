using System;
using System.Collections;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Threading;
using ASCClassLib380;

[assembly: TypeLibVersion(38, 0)]
[assembly: ImportedFromTypeLib("APSERVERDLLLib")]
[assembly: Guid("6CCB1440-E111-11D4-8289-00C04F048AAE")]
[assembly: AssemblyVersion("38.0.0.0")]
namespace AspenTech.AspenPlus.APServer;

[ComImport]
[Guid("6CCB144C-5C26-11D4-8289-00C04F048AAE")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPServer
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void TriggerCancel([In] short level);

	[DispId(1610743811)]
	object EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}
}
[ComImport]
[Guid("0D47E732-3826-11D5-8301-00C04F298756")]
[TypeLibType(TypeLibTypeFlags.FDispatchable)]
[InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
public interface _IAPServerSimEvents
{
	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void OnEvent([In] int lEventId, [In][MarshalAs(UnmanagedType.Struct)] object Hint1, [In][MarshalAs(UnmanagedType.Struct)] object Hint2);
}
[ComVisible(false)]
[ComEventInterface(typeof(_IAPServerSimEvents), typeof(_IAPServerSimEvents_EventProvider))]
[TypeLibType(TypeLibTypeFlags.FHidden)]
public interface _IAPServerSimEvents_Event
{
	event _IAPServerSimEvents_OnEventEventHandler OnEvent;
}
[ComImport]
[CoClass(typeof(APServerClass))]
[Guid("6CCB144C-5C26-11D4-8289-00C04F048AAE")]
public interface APServer : IAPServer, _IAPServerSimEvents_Event
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("F0282861-C20D-4551-ABD6-3FBFC9411A38")]
public interface IAPServer2 : IAPServer
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	new void TriggerCancel([In] short level);

	[DispId(1610743811)]
	new object EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	[DispId(1610743812)]
	APServerBlockCollection Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743813)]
	IStream FileStream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743814)]
	object DefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("6E6E08A0-A8BD-4717-B7A6-30932D90C5F5")]
public interface IAPServer3 : IAPServer2
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	new void TriggerCancel([In] short level);

	[DispId(1610743811)]
	new object EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	[DispId(1610743812)]
	new APServerBlockCollection Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743813)]
	new IStream FileStream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743814)]
	new object DefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744064)]
	object DupDefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744064)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744065)]
	object CatalogXMLMgr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744065)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744066)]
	APACMExpCollection ACMExpModels
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744066)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[Guid("0D47E734-3826-11D5-8301-00C04F298756")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPServerRte : IAPServer3
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	new void TriggerCancel([In] short level);

	[DispId(1610743811)]
	new object EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	[DispId(1610743812)]
	new APServerBlockCollection Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743813)]
	new IStream FileStream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743814)]
	new object DefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744064)]
	new object DupDefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744064)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744065)]
	new object CatalogXMLMgr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744065)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744066)]
	new APACMExpCollection ACMExpModels
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744066)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743824)]
	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
	ApServerRteBlockStatus BlockStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
		get;
	}

	[DispId(1610743825)]
	int NumberIter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		get;
	}

	[DispId(1610743826)]
	int Converged
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743827)]
	void WriteHistory([In][MarshalAs(UnmanagedType.BStr)] string line);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	void JournalComment([In][MarshalAs(UnmanagedType.BStr)] string comment);

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
	[DispId(1610743829)]
	ApServerRteParamType ParamType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743829)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
		get;
	}

	[DispId(1610743830)]
	string ParamStringValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743831)]
	int ParamIntValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	void GetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [MarshalAs(UnmanagedType.BStr)] out string uom, out double retval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743833)]
	void SetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [In][MarshalAs(UnmanagedType.BStr)] string uom, [In] double newVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	void ProcessVarQuality();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743841)]
	void SaveVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	void UpdateVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743843)]
	void RestoreVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[DispId(1610743844)]
	double Rmiss
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743844)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743846)]
	void JournalLine([In][MarshalAs(UnmanagedType.BStr)] string s);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	int SetVarAttr([MarshalAs(UnmanagedType.BStr)] string Name, ref int ID, int attr, double val, [MarshalAs(UnmanagedType.BStr)] string unit, int spec);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743848)]
	int Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743849)]
	void SetInt(int iin);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743856)]
	int InqEnabledInactiveSpecGroups([MarshalAs(UnmanagedType.BStr)] ref string sOut, int bDestroy);
}
[ComImport]
[Guid("6CCB1449-5C26-11D4-8289-00C04F048AAE")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPServerScripting : IAPServerRte
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	new void TriggerCancel([In] short level);

	[DispId(1610743811)]
	new object EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	[DispId(1610743812)]
	new APServerBlockCollection Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743813)]
	new IStream FileStream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743814)]
	new object DefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744064)]
	new object DupDefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744064)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744065)]
	new object CatalogXMLMgr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744065)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744066)]
	new APACMExpCollection ACMExpModels
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744066)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
	[DispId(1610743824)]
	new ApServerRteBlockStatus BlockStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
		get;
	}

	[DispId(1610743825)]
	new int NumberIter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		get;
	}

	[DispId(1610743826)]
	new int Converged
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743827)]
	new void WriteHistory([In][MarshalAs(UnmanagedType.BStr)] string line);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	new void JournalComment([In][MarshalAs(UnmanagedType.BStr)] string comment);

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
	[DispId(1610743829)]
	new ApServerRteParamType ParamType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743829)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
		get;
	}

	[DispId(1610743830)]
	new string ParamStringValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743831)]
	new int ParamIntValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	new void GetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [MarshalAs(UnmanagedType.BStr)] out string uom, out double retval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743833)]
	new void SetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [In][MarshalAs(UnmanagedType.BStr)] string uom, [In] double newVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	new void ProcessVarQuality();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743841)]
	new void SaveVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	new void UpdateVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743843)]
	new void RestoreVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[DispId(1610743844)]
	new double Rmiss
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743844)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743846)]
	new void JournalLine([In][MarshalAs(UnmanagedType.BStr)] string s);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	new int SetVarAttr([MarshalAs(UnmanagedType.BStr)] string Name, ref int ID, int attr, double val, [MarshalAs(UnmanagedType.BStr)] string unit, int spec);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743848)]
	new int Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743849)]
	new void SetInt(int iin);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743856)]
	new int InqEnabledInactiveSpecGroups([MarshalAs(UnmanagedType.BStr)] ref string sOut, int bDestroy);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743845)]
	void ExecuteScript([In][MarshalAs(UnmanagedType.BStr)] string commandString);
}
[ComImport]
[Guid("0A117815-2682-4A9A-9A49-E5DE33D805CE")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPServerScripting2 : IAPServerScripting
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	new void TriggerCancel([In] short level);

	[DispId(1610743811)]
	new object EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	[DispId(1610743812)]
	new APServerBlockCollection Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743813)]
	new IStream FileStream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743814)]
	new object DefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744064)]
	new object DupDefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744064)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744065)]
	new object CatalogXMLMgr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744065)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744066)]
	new APACMExpCollection ACMExpModels
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744066)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743824)]
	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
	new ApServerRteBlockStatus BlockStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
		get;
	}

	[DispId(1610743825)]
	new int NumberIter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		get;
	}

	[DispId(1610743826)]
	new int Converged
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743827)]
	new void WriteHistory([In][MarshalAs(UnmanagedType.BStr)] string line);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	new void JournalComment([In][MarshalAs(UnmanagedType.BStr)] string comment);

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
	[DispId(1610743829)]
	new ApServerRteParamType ParamType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743829)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
		get;
	}

	[DispId(1610743830)]
	new string ParamStringValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743831)]
	new int ParamIntValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	new void GetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [MarshalAs(UnmanagedType.BStr)] out string uom, out double retval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743833)]
	new void SetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [In][MarshalAs(UnmanagedType.BStr)] string uom, [In] double newVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	new void ProcessVarQuality();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743841)]
	new void SaveVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	new void UpdateVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743843)]
	new void RestoreVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[DispId(1610743844)]
	new double Rmiss
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743844)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743846)]
	new void JournalLine([In][MarshalAs(UnmanagedType.BStr)] string s);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	new int SetVarAttr([MarshalAs(UnmanagedType.BStr)] string Name, ref int ID, int attr, double val, [MarshalAs(UnmanagedType.BStr)] string unit, int spec);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743848)]
	new int Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743849)]
	new void SetInt(int iin);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743856)]
	new int InqEnabledInactiveSpecGroups([MarshalAs(UnmanagedType.BStr)] ref string sOut, int bDestroy);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743845)]
	new void ExecuteScript([In][MarshalAs(UnmanagedType.BStr)] string commandString);

	[DispId(1610743857)]
	string ConvergenceFailureText
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743857)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("57B9406E-F919-4778-956F-3861294B4FA1")]
public interface IAPServer4 : IAPServerScripting2
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	new void TriggerCancel([In] short level);

	[DispId(1610743811)]
	new object EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	[DispId(1610743812)]
	new APServerBlockCollection Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743813)]
	new IStream FileStream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743814)]
	new object DefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744064)]
	new object DupDefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744064)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744065)]
	new object CatalogXMLMgr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744065)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610744066)]
	new APACMExpCollection ACMExpModels
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610744066)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
	[DispId(1610743824)]
	new ApServerRteBlockStatus BlockStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
		get;
	}

	[DispId(1610743825)]
	new int NumberIter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		get;
	}

	[DispId(1610743826)]
	new int Converged
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743827)]
	new void WriteHistory([In][MarshalAs(UnmanagedType.BStr)] string line);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	new void JournalComment([In][MarshalAs(UnmanagedType.BStr)] string comment);

	[DispId(1610743829)]
	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
	new ApServerRteParamType ParamType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743829)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
		get;
	}

	[DispId(1610743830)]
	new string ParamStringValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743831)]
	new int ParamIntValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	new void GetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [MarshalAs(UnmanagedType.BStr)] out string uom, out double retval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743833)]
	new void SetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [In][MarshalAs(UnmanagedType.BStr)] string uom, [In] double newVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	new void ProcessVarQuality();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743841)]
	new void SaveVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	new void UpdateVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743843)]
	new void RestoreVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[DispId(1610743844)]
	new double Rmiss
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743844)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743846)]
	new void JournalLine([In][MarshalAs(UnmanagedType.BStr)] string s);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	new int SetVarAttr([MarshalAs(UnmanagedType.BStr)] string Name, ref int ID, int attr, double val, [MarshalAs(UnmanagedType.BStr)] string unit, int spec);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743848)]
	new int Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743849)]
	new void SetInt(int iin);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743856)]
	new int InqEnabledInactiveSpecGroups([MarshalAs(UnmanagedType.BStr)] ref string sOut, int bDestroy);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743845)]
	new void ExecuteScript([In][MarshalAs(UnmanagedType.BStr)] string commandString);

	[DispId(1610743857)]
	new string ConvergenceFailureText
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743857)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610747904)]
	int SolvingFlowsheet
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610747904)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610747904)]
		[param: In]
		set;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDispatchable)]
[InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
[Guid("31CD01DA-0C76-4FE9-BD7B-962D300BECAF")]
public interface IAPServerDispatch
{
	[DispId(1610809346)]
	object EOUnits
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809345)]
	void GetService([In][MarshalAs(UnmanagedType.BStr)] string bService, [MarshalAs(UnmanagedType.IUnknown)] out object ppUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809347)]
	void SimExecuteScript([In][MarshalAs(UnmanagedType.BStr)] string commandString, [In][MarshalAs(UnmanagedType.Struct)] object vtVal);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809348)]
	void ToggleEOSimEvents(int iMask, bool bEnable);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809349)]
	void AddCapeOpenBlk([In][MarshalAs(UnmanagedType.BStr)] string bsDisplayName, [In][MarshalAs(UnmanagedType.BStr)] string capeId, [In][ComAliasName("AspenTech.AspenPlus.APServer.eAPCapeOpenIdOption")] eAPCapeOpenIdOption eIdType, [MarshalAs(UnmanagedType.IUnknown)] out object ppUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809350)]
	void GetCapeBlockService([In][MarshalAs(UnmanagedType.IUnknown)] object pBlkIUnk, [In][MarshalAs(UnmanagedType.BStr)] string bsServiceId, [MarshalAs(UnmanagedType.IUnknown)] out object ppUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809351)]
	void SaveCOBlkToStg([In][MarshalAs(UnmanagedType.Struct)] object bsCapefullId, [In][MarshalAs(UnmanagedType.IUnknown)] object pUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809352)]
	void LoadCOBlkToStg([In][MarshalAs(UnmanagedType.Struct)] object bsCapefullId, [In][MarshalAs(UnmanagedType.IUnknown)] object pUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809353)]
	void StreamSummary([In][MarshalAs(UnmanagedType.Struct)] object vtXMLTFF, [In][MarshalAs(UnmanagedType.Struct)] object vtScope, [In][MarshalAs(UnmanagedType.Struct)] object vtScopeType, [MarshalAs(UnmanagedType.Struct)] out object vtXMLResult);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874881)]
	void GetValidAPStreams([In][MarshalAs(UnmanagedType.Struct)] object vtScope, [MarshalAs(UnmanagedType.Struct)] out object vtXMLStreams);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874882)]
	void GetLicenseInfo([MarshalAs(UnmanagedType.BStr)] out string bstrLicInfo);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874883)]
	void CheckFeatureLicense([In][MarshalAs(UnmanagedType.Struct)] object vtFeature, [MarshalAs(UnmanagedType.Struct)] out object vtCookie);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874884)]
	void GetSpDistilAnalysis([MarshalAs(UnmanagedType.IUnknown)] out object ppUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874885)]
	void GetASCDDistil([MarshalAs(UnmanagedType.IUnknown)] out object ppUnk);
}
[ComImport]
[ComSourceInterfaces("AspenTech.AspenPlus.APServer._IAPServerSimEvents\0\0")]
[Guid("6CCB144D-E111-11D4-8289-00C04F048AAE")]
[ClassInterface(ClassInterfaceType.None)]
public class APServerClass
{
	[DispId(1610743811)]
	public virtual extern object EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	public virtual extern object IAPServerRte_EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	public virtual extern APServerBlockCollection Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern IStream FileStream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern object DefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object DupDefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object CatalogXMLMgr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern APACMExpCollection ACMExpModels
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
	public virtual extern ApServerRteBlockStatus BlockStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
		get;
	}

	public virtual extern int NumberIter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern int Converged
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
	public virtual extern ApServerRteParamType ParamType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
		get;
	}

	public virtual extern string ParamStringValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	public virtual extern int ParamIntValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern double Rmiss
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern object IAPServerScripting_EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	public virtual extern APServerBlockCollection IAPServerScripting_Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern IStream IAPServerScripting_FileStream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern object IAPServerScripting_DefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object IAPServerScripting_DupDefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object IAPServerScripting_CatalogXMLMgr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern APACMExpCollection IAPServerScripting_ACMExpModels
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
	public virtual extern ApServerRteBlockStatus IAPServerScripting_BlockStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
		get;
	}

	public virtual extern int IAPServerScripting_NumberIter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern int IAPServerScripting_Converged
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
	public virtual extern ApServerRteParamType IAPServerScripting_ParamType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
		get;
	}

	public virtual extern string IAPServerScripting_ParamStringValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	public virtual extern int IAPServerScripting_ParamIntValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern double IAPServerScripting_Rmiss
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern object IAPServerScripting2_EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	public virtual extern APServerBlockCollection IAPServerScripting2_Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern IStream IAPServerScripting2_FileStream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern object IAPServerScripting2_DefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object IAPServerScripting2_DupDefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object IAPServerScripting2_CatalogXMLMgr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern APACMExpCollection IAPServerScripting2_ACMExpModels
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
	public virtual extern ApServerRteBlockStatus IAPServerScripting2_BlockStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
		get;
	}

	public virtual extern int IAPServerScripting2_NumberIter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern int IAPServerScripting2_Converged
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
	public virtual extern ApServerRteParamType IAPServerScripting2_ParamType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
		get;
	}

	public virtual extern string IAPServerScripting2_ParamStringValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	public virtual extern int IAPServerScripting2_ParamIntValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern double IAPServerScripting2_Rmiss
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern string ConvergenceFailureText
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	public virtual extern object IAPServer4_EOSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IUnknown)]
		set;
	}

	public virtual extern APServerBlockCollection IAPServer4_Blocks
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern IStream IAPServer4_FileStream
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern object IAPServer4_DefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted | TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object IAPServer4_DupDefaultProperties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object IAPServer4_CatalogXMLMgr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern APACMExpCollection IAPServer4_ACMExpModels
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
	public virtual extern ApServerRteBlockStatus IAPServer4_BlockStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteBlockStatus")]
		get;
	}

	public virtual extern int IAPServer4_NumberIter
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern int IAPServer4_Converged
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
	public virtual extern ApServerRteParamType IAPServer4_ParamType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.ApServerRteParamType")]
		get;
	}

	public virtual extern string IAPServer4_ParamStringValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	public virtual extern int IAPServer4_ParamIntValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern double IAPServer4_Rmiss
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern string IAPServer4_ConvergenceFailureText
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	public virtual extern int SolvingFlowsheet
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern object EOUnits
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	public virtual extern event _IAPServerSimEvents_OnEventEventHandler OnEvent;

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void TriggerCancel([In] short level);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object IAPServerRte_ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerRte_TriggerCancel([In] short level);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void WriteHistory([In][MarshalAs(UnmanagedType.BStr)] string line);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void JournalComment([In][MarshalAs(UnmanagedType.BStr)] string comment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [MarshalAs(UnmanagedType.BStr)] out string uom, out double retval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void SetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [In][MarshalAs(UnmanagedType.BStr)] string uom, [In] double newVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void ProcessVarQuality();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void SaveVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void UpdateVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void RestoreVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void JournalLine([In][MarshalAs(UnmanagedType.BStr)] string s);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int SetVarAttr([MarshalAs(UnmanagedType.BStr)] string Name, ref int ID, int attr, double val, [MarshalAs(UnmanagedType.BStr)] string unit, int spec);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void SetInt(int iin);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int InqEnabledInactiveSpecGroups([MarshalAs(UnmanagedType.BStr)] ref string sOut, int bDestroy);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object IAPServerScripting_ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_TriggerCancel([In] short level);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_WriteHistory([In][MarshalAs(UnmanagedType.BStr)] string line);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_JournalComment([In][MarshalAs(UnmanagedType.BStr)] string comment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_GetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [MarshalAs(UnmanagedType.BStr)] out string uom, out double retval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_SetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [In][MarshalAs(UnmanagedType.BStr)] string uom, [In] double newVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_ProcessVarQuality();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_SaveVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_UpdateVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_RestoreVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_JournalLine([In][MarshalAs(UnmanagedType.BStr)] string s);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int IAPServerScripting_SetVarAttr([MarshalAs(UnmanagedType.BStr)] string Name, ref int ID, int attr, double val, [MarshalAs(UnmanagedType.BStr)] string unit, int spec);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int IAPServerScripting_Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting_SetInt(int iin);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int IAPServerScripting_InqEnabledInactiveSpecGroups([MarshalAs(UnmanagedType.BStr)] ref string sOut, int bDestroy);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void ExecuteScript([In][MarshalAs(UnmanagedType.BStr)] string commandString);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object IAPServerScripting2_ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_TriggerCancel([In] short level);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_WriteHistory([In][MarshalAs(UnmanagedType.BStr)] string line);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_JournalComment([In][MarshalAs(UnmanagedType.BStr)] string comment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_GetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [MarshalAs(UnmanagedType.BStr)] out string uom, out double retval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_SetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [In][MarshalAs(UnmanagedType.BStr)] string uom, [In] double newVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_ProcessVarQuality();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_SaveVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_UpdateVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_RestoreVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_JournalLine([In][MarshalAs(UnmanagedType.BStr)] string s);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int IAPServerScripting2_SetVarAttr([MarshalAs(UnmanagedType.BStr)] string Name, ref int ID, int attr, double val, [MarshalAs(UnmanagedType.BStr)] string unit, int spec);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int IAPServerScripting2_Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_SetInt(int iin);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int IAPServerScripting2_InqEnabledInactiveSpecGroups([MarshalAs(UnmanagedType.BStr)] ref string sOut, int bDestroy);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServerScripting2_ExecuteScript([In][MarshalAs(UnmanagedType.BStr)] string commandString);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object IAPServer4_ResolveBlock([In][MarshalAs(UnmanagedType.BStr)] string blockname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_TriggerCancel([In] short level);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_WriteHistory([In][MarshalAs(UnmanagedType.BStr)] string line);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_JournalComment([In][MarshalAs(UnmanagedType.BStr)] string comment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_GetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [MarshalAs(UnmanagedType.BStr)] out string uom, out double retval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_SetParamRealValue([In][MarshalAs(UnmanagedType.BStr)] string Param, [In][MarshalAs(UnmanagedType.BStr)] string uom, [In] double newVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_ProcessVarQuality();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_SaveVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_UpdateVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_RestoreVariables([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_I4)] int[] vmask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_JournalLine([In][MarshalAs(UnmanagedType.BStr)] string s);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int IAPServer4_SetVarAttr([MarshalAs(UnmanagedType.BStr)] string Name, ref int ID, int attr, double val, [MarshalAs(UnmanagedType.BStr)] string unit, int spec);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int IAPServer4_Solve();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_SetInt(int iin);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern int IAPServer4_InqEnabledInactiveSpecGroups([MarshalAs(UnmanagedType.BStr)] ref string sOut, int bDestroy);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPServer4_ExecuteScript([In][MarshalAs(UnmanagedType.BStr)] string commandString);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetService([In][MarshalAs(UnmanagedType.BStr)] string bService, [MarshalAs(UnmanagedType.IUnknown)] out object ppUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void SimExecuteScript([In][MarshalAs(UnmanagedType.BStr)] string commandString, [In][MarshalAs(UnmanagedType.Struct)] object vtVal);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void ToggleEOSimEvents(int iMask, bool bEnable);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void AddCapeOpenBlk([In][MarshalAs(UnmanagedType.BStr)] string bsDisplayName, [In][MarshalAs(UnmanagedType.BStr)] string capeId, [In][ComAliasName("AspenTech.AspenPlus.APServer.eAPCapeOpenIdOption")] eAPCapeOpenIdOption eIdType, [MarshalAs(UnmanagedType.IUnknown)] out object ppUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetCapeBlockService([In][MarshalAs(UnmanagedType.IUnknown)] object pBlkIUnk, [In][MarshalAs(UnmanagedType.BStr)] string bsServiceId, [MarshalAs(UnmanagedType.IUnknown)] out object ppUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void SaveCOBlkToStg([In][MarshalAs(UnmanagedType.Struct)] object bsCapefullId, [In][MarshalAs(UnmanagedType.IUnknown)] object pUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void LoadCOBlkToStg([In][MarshalAs(UnmanagedType.Struct)] object bsCapefullId, [In][MarshalAs(UnmanagedType.IUnknown)] object pUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void StreamSummary([In][MarshalAs(UnmanagedType.Struct)] object vtXMLTFF, [In][MarshalAs(UnmanagedType.Struct)] object vtScope, [In][MarshalAs(UnmanagedType.Struct)] object vtScopeType, [MarshalAs(UnmanagedType.Struct)] out object vtXMLResult);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetValidAPStreams([In][MarshalAs(UnmanagedType.Struct)] object vtScope, [MarshalAs(UnmanagedType.Struct)] out object vtXMLStreams);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetLicenseInfo([MarshalAs(UnmanagedType.BStr)] out string bstrLicInfo);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void CheckFeatureLicense([In][MarshalAs(UnmanagedType.Struct)] object vtFeature, [MarshalAs(UnmanagedType.Struct)] out object vtCookie);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetSpDistilAnalysis([MarshalAs(UnmanagedType.IUnknown)] out object ppUnk);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetASCDDistil([MarshalAs(UnmanagedType.IUnknown)] out object ppUnk);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("6CCB1443-E111-11D4-8289-00C04F048AAE")]
public interface IAPBlockCollection : IEnumerable
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IAPBlock Add([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Struct)] object type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void Remove([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[DispId(1610743811)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(0)]
	IAPBlock this[[In][MarshalAs(UnmanagedType.Struct)] object index]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();
}
[ComImport]
[CoClass(typeof(APServerBlockCollectionClass))]
[Guid("6CCB1443-E111-11D4-8289-00C04F048AAE")]
public interface APServerBlockCollection : IAPBlockCollection
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("6CCB1446-E111-11D4-8289-00C04F048AAE")]
public class APServerBlockCollectionClass
{
	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(0)]
	public virtual extern IAPBlock this[[In][MarshalAs(UnmanagedType.Struct)] object index]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IAPBlock Add([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Struct)] object type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void Remove([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();
}
[ComImport]
[Guid("14693A78-09BB-43E9-BF44-A35235CD0B3C")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPACMExpCollection : IEnumerable
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IAPBlock Add([In][ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void Remove([In][ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void Rename([In][ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[DispId(1610743811)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(0)]
	IAPBlock this[[In][ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [In][MarshalAs(UnmanagedType.Struct)] object index]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();
}
[ComImport]
[Guid("14693A78-09BB-43E9-BF44-A35235CD0B3C")]
[CoClass(typeof(APACMExpCollectionClass))]
public interface APACMExpCollection : IAPACMExpCollection
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("ECF5827A-CACB-4688-9B72-1BCD22DED2B0")]
public class APACMExpCollectionClass
{
	[DispId(1610743811)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(0)]
	public virtual extern IAPBlock this[[In][ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [In][MarshalAs(UnmanagedType.Struct)] object index]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IAPBlock Add([In][ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void Remove([In][ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void Rename([In][ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();
}
[ComImport]
[Guid("6CCB1441-5C26-11D4-8289-00C04F048AAE")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPCapeUnitAdapter
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void Destroy([In][MarshalAs(UnmanagedType.BStr)] string fqBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void Connect([In][MarshalAs(UnmanagedType.BStr)] string portname, [In][MarshalAs(UnmanagedType.BStr)] string streamname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void LaunchGUI();

	[DispId(1610743813)]
	object Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743814)]
	object Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743815)]
	int StatusCode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		[return: MarshalAs(UnmanagedType.Error)]
		get;
	}
}
[ComImport]
[Guid("6CCB1441-5C26-11D4-8289-00C04F048AAE")]
[CoClass(typeof(APCapeUnitAdapterClass))]
public interface APCapeUnitAdapter : IAPCapeUnitAdapter
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("6CCB1442-E111-11D4-8289-00C04F048AAE")]
public class APCapeUnitAdapterClass
{
	[DispId(1610743813)]
	public virtual extern object Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743814)]
	public virtual extern object Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743815)]
	public virtual extern int StatusCode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		[return: MarshalAs(UnmanagedType.Error)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void Destroy([In][MarshalAs(UnmanagedType.BStr)] string fqBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	public virtual extern void Connect([In][MarshalAs(UnmanagedType.BStr)] string portname, [In][MarshalAs(UnmanagedType.BStr)] string streamname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	public virtual extern void LaunchGUI();
}
[ComImport]
[Guid("6CCB1447-E111-11D4-8289-00C04F048AAE")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPBlock
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void Destroy([In][MarshalAs(UnmanagedType.BStr)] string fqBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void Connect([In][MarshalAs(UnmanagedType.BStr)] string portname, [In][MarshalAs(UnmanagedType.BStr)] string streamname);

	[DispId(1610743812)]
	object Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743813)]
	object Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743814)]
	int StatusCode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Error)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void Validate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object GetService([In][MarshalAs(UnmanagedType.BStr)] string Service);

	[DispId(1610743817)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743818)]
	object Param
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}
}
[ComImport]
[Guid("B467B5BD-2426-42C6-94F3-A03AAE5C0D5E")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPBlock2 : IAPBlock
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	new void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	new void Destroy([In][MarshalAs(UnmanagedType.BStr)] string fqBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	new void Connect([In][MarshalAs(UnmanagedType.BStr)] string portname, [In][MarshalAs(UnmanagedType.BStr)] string streamname);

	[DispId(1610743812)]
	new object Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743813)]
	new object Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743814)]
	new int StatusCode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Error)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void Validate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string Service);

	[DispId(1610743817)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743818)]
	new object Param
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743819)]
	object type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}
}
[ComImport]
[Guid("04A6921B-2F25-4B8C-9672-213184B580A5")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPACMModelAdapter : IAPBlock2
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	new void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	new void Destroy([In][MarshalAs(UnmanagedType.BStr)] string fqBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	new void Connect([In][MarshalAs(UnmanagedType.BStr)] string portname, [In][MarshalAs(UnmanagedType.BStr)] string streamname);

	[DispId(1610743812)]
	new object Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743813)]
	new object Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743814)]
	new int StatusCode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Error)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void Validate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string Service);

	[DispId(1610743817)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743818)]
	new object Param
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743819)]
	new object type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610874880)]
	object Queries
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874880)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610874881)]
	object VBScripts
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874881)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874882)]
	void Initialize([MarshalAs(UnmanagedType.BStr)] string Path, [MarshalAs(UnmanagedType.BStr)] string Library);

	[DispId(1610874883)]
	APSHostCompListMgr Properties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874883)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874884)]
	void OnComponentManagerEvent([ComAliasName("AspenTech.AspenPlus.APServer.eACMComponentManagerEventType")] eACMComponentManagerEventType @event, [MarshalAs(UnmanagedType.BStr)] string NewName, [MarshalAs(UnmanagedType.BStr)] string OldName);

	[DispId(1610874885)]
	long Blkptr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874885)]
		get;
	}
}
[ComImport]
[CoClass(typeof(APACMModelAdapterClass))]
[Guid("04A6921B-2F25-4B8C-9672-213184B580A5")]
public interface APACMModelAdapter : IAPACMModelAdapter
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("2632EB98-9E0E-4616-811D-C9AA203A3C88")]
public interface IAPACMModelAdapter2 : IAPACMModelAdapter
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	new void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	new void Destroy([In][MarshalAs(UnmanagedType.BStr)] string fqBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	new void Connect([In][MarshalAs(UnmanagedType.BStr)] string portname, [In][MarshalAs(UnmanagedType.BStr)] string streamname);

	[DispId(1610743812)]
	new object Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743813)]
	new object Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743814)]
	new int StatusCode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Error)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void Validate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string Service);

	[DispId(1610743817)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743818)]
	new object Param
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743819)]
	new object type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610874880)]
	new object Queries
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874880)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610874881)]
	new object VBScripts
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874881)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874882)]
	new void Initialize([MarshalAs(UnmanagedType.BStr)] string Path, [MarshalAs(UnmanagedType.BStr)] string Library);

	[DispId(1610874883)]
	new APSHostCompListMgr Properties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874883)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874884)]
	new void OnComponentManagerEvent([ComAliasName("AspenTech.AspenPlus.APServer.eACMComponentManagerEventType")] eACMComponentManagerEventType @event, [MarshalAs(UnmanagedType.BStr)] string NewName, [MarshalAs(UnmanagedType.BStr)] string OldName);

	[DispId(1610874885)]
	new long Blkptr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874885)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610940416)]
	void InitializeByModelName([ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [MarshalAs(UnmanagedType.BStr)] string bsModelName);

	[DispId(1610940417)]
	object DegreesOfFreedom
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610940417)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610940418)]
	void ResetSM([MarshalAs(UnmanagedType.BStr)] string pszProperty, [ComAliasName("AspenTech.AspenPlus.APServer.eResetTypes")] eResetTypes iResetType, uint iOOMFAttributes, bool bKeepUserAssigns);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610940419)]
	void ReconcileEOToSM([MarshalAs(UnmanagedType.BStr)] string pszProperty, int iReconType, uint iOOMFAttributes);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("FAE182FC-A170-4985-B414-02766538635A")]
public interface IAPACMModelAdapter3 : IAPACMModelAdapter2
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	new void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	new void Destroy([In][MarshalAs(UnmanagedType.BStr)] string fqBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	new void Connect([In][MarshalAs(UnmanagedType.BStr)] string portname, [In][MarshalAs(UnmanagedType.BStr)] string streamname);

	[DispId(1610743812)]
	new object Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743813)]
	new object Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743814)]
	new int StatusCode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Error)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void Validate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	new object GetService([In][MarshalAs(UnmanagedType.BStr)] string Service);

	[DispId(1610743817)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743818)]
	new object Param
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743819)]
	new object type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610874880)]
	new object Queries
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874880)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610874881)]
	new object VBScripts
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874881)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874882)]
	new void Initialize([MarshalAs(UnmanagedType.BStr)] string Path, [MarshalAs(UnmanagedType.BStr)] string Library);

	[DispId(1610874883)]
	new APSHostCompListMgr Properties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874883)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874884)]
	new void OnComponentManagerEvent([ComAliasName("AspenTech.AspenPlus.APServer.eACMComponentManagerEventType")] eACMComponentManagerEventType @event, [MarshalAs(UnmanagedType.BStr)] string NewName, [MarshalAs(UnmanagedType.BStr)] string OldName);

	[DispId(1610874885)]
	new long Blkptr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874885)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610940416)]
	new void InitializeByModelName([ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [MarshalAs(UnmanagedType.BStr)] string bsModelName);

	[DispId(1610940417)]
	new object DegreesOfFreedom
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610940417)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610940418)]
	new void ResetSM([MarshalAs(UnmanagedType.BStr)] string pszProperty, [ComAliasName("AspenTech.AspenPlus.APServer.eResetTypes")] eResetTypes iResetType, uint iOOMFAttributes, bool bKeepUserAssigns);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610940419)]
	new void ReconcileEOToSM([MarshalAs(UnmanagedType.BStr)] string pszProperty, int iReconType, uint iOOMFAttributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1611005952)]
	void AddReportVar([MarshalAs(UnmanagedType.BStr)] string varName, [MarshalAs(UnmanagedType.BStr)] string varGUID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1611005953)]
	void AddReportArray([MarshalAs(UnmanagedType.BStr)] string ID, [MarshalAs(UnmanagedType.BStr)] string valGuid, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] instanceGUIDInfo, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] classGUIDInfo, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] object[] wcReplaceInfo);
}
[ComImport]
[Guid("5E6E1407-0CAB-42D2-9F3F-66D880DDEFFD")]
[TypeLibType(TypeLibTypeFlags.FDual)]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAPDynBlock
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678272)]
	void UpdateResults();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual)]
[Guid("35E75212-24C4-4568-8CC8-CAD86B077755")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAPDynBlock2 : IAPDynBlock
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678272)]
	new void UpdateResults();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void ProfileHandle(ref IntPtr hndl);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void IsSolving(ref int bSolving);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void CleanUpReportVars();
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("6CCB1448-E111-11D4-8289-00C04F048AAE")]
public class APACMModelAdapterClass
{
	[DispId(1610743812)]
	public virtual extern object Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743813)]
	public virtual extern object Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743814)]
	public virtual extern int StatusCode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Error)]
		get;
	}

	[DispId(1610743817)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743818)]
	public virtual extern object Param
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743819)]
	public virtual extern object type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610874880)]
	public virtual extern object Queries
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874880)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610874881)]
	public virtual extern object VBScripts
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874881)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610874883)]
	public virtual extern APSHostCompListMgr Properties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874883)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610874885)]
	public virtual extern long Blkptr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610874885)]
		get;
	}

	public virtual extern object IAPACMModelAdapter2_Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object IAPACMModelAdapter2_Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern int IAPACMModelAdapter2_StatusCode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Error)]
		get;
	}

	public virtual extern string IAPACMModelAdapter2_Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	public virtual extern object IAPACMModelAdapter2_Param
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	public virtual extern object IAPACMModelAdapter2_type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	public virtual extern object IAPACMModelAdapter2_Queries
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object IAPACMModelAdapter2_VBScripts
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern APSHostCompListMgr IAPACMModelAdapter2_Properties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern long IAPACMModelAdapter2_Blkptr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern object DegreesOfFreedom
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	public virtual extern object IAPACMModelAdapter3_Ports
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object IAPACMModelAdapter3_Parameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern int IAPACMModelAdapter3_StatusCode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Error)]
		get;
	}

	public virtual extern string IAPACMModelAdapter3_Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	public virtual extern object IAPACMModelAdapter3_Param
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	public virtual extern object IAPACMModelAdapter3_type
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	public virtual extern object IAPACMModelAdapter3_Queries
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern object IAPACMModelAdapter3_VBScripts
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	public virtual extern APSHostCompListMgr IAPACMModelAdapter3_Properties
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern long IAPACMModelAdapter3_Blkptr
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern object IAPACMModelAdapter3_DegreesOfFreedom
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void Destroy([In][MarshalAs(UnmanagedType.BStr)] string fqBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	public virtual extern void Connect([In][MarshalAs(UnmanagedType.BStr)] string portname, [In][MarshalAs(UnmanagedType.BStr)] string streamname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void Validate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string Service);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874882)]
	public virtual extern void Initialize([MarshalAs(UnmanagedType.BStr)] string Path, [MarshalAs(UnmanagedType.BStr)] string Library);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610874884)]
	public virtual extern void OnComponentManagerEvent([ComAliasName("AspenTech.AspenPlus.APServer.eACMComponentManagerEventType")] eACMComponentManagerEventType @event, [MarshalAs(UnmanagedType.BStr)] string NewName, [MarshalAs(UnmanagedType.BStr)] string OldName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter2_Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter2_Destroy([In][MarshalAs(UnmanagedType.BStr)] string fqBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter2_Connect([In][MarshalAs(UnmanagedType.BStr)] string portname, [In][MarshalAs(UnmanagedType.BStr)] string streamname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter2_Validate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object IAPACMModelAdapter2_GetService([In][MarshalAs(UnmanagedType.BStr)] string Service);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter2_Initialize([MarshalAs(UnmanagedType.BStr)] string Path, [MarshalAs(UnmanagedType.BStr)] string Library);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter2_OnComponentManagerEvent([ComAliasName("AspenTech.AspenPlus.APServer.eACMComponentManagerEventType")] eACMComponentManagerEventType @event, [MarshalAs(UnmanagedType.BStr)] string NewName, [MarshalAs(UnmanagedType.BStr)] string OldName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void InitializeByModelName([ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [MarshalAs(UnmanagedType.BStr)] string bsModelName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void ResetSM([MarshalAs(UnmanagedType.BStr)] string pszProperty, [ComAliasName("AspenTech.AspenPlus.APServer.eResetTypes")] eResetTypes iResetType, uint iOOMFAttributes, bool bKeepUserAssigns);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void ReconcileEOToSM([MarshalAs(UnmanagedType.BStr)] string pszProperty, int iReconType, uint iOOMFAttributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter3_Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter3_Destroy([In][MarshalAs(UnmanagedType.BStr)] string fqBlockName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter3_Connect([In][MarshalAs(UnmanagedType.BStr)] string portname, [In][MarshalAs(UnmanagedType.BStr)] string streamname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter3_Validate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object IAPACMModelAdapter3_GetService([In][MarshalAs(UnmanagedType.BStr)] string Service);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter3_Initialize([MarshalAs(UnmanagedType.BStr)] string Path, [MarshalAs(UnmanagedType.BStr)] string Library);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter3_OnComponentManagerEvent([ComAliasName("AspenTech.AspenPlus.APServer.eACMComponentManagerEventType")] eACMComponentManagerEventType @event, [MarshalAs(UnmanagedType.BStr)] string NewName, [MarshalAs(UnmanagedType.BStr)] string OldName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter3_InitializeByModelName([ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [MarshalAs(UnmanagedType.BStr)] string bsModelName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter3_ResetSM([MarshalAs(UnmanagedType.BStr)] string pszProperty, [ComAliasName("AspenTech.AspenPlus.APServer.eResetTypes")] eResetTypes iResetType, uint iOOMFAttributes, bool bKeepUserAssigns);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPACMModelAdapter3_ReconcileEOToSM([MarshalAs(UnmanagedType.BStr)] string pszProperty, int iReconType, uint iOOMFAttributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void AddReportVar([MarshalAs(UnmanagedType.BStr)] string varName, [MarshalAs(UnmanagedType.BStr)] string varGUID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void AddReportArray([MarshalAs(UnmanagedType.BStr)] string ID, [MarshalAs(UnmanagedType.BStr)] string valGuid, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] instanceGUIDInfo, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] classGUIDInfo, [MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] object[] wcReplaceInfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void UpdateResults();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IAPDynBlock2_UpdateResults();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void ProfileHandle(ref IntPtr hndl);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IsSolving(ref int bSolving);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void CleanUpReportVars();
}
[ComImport]
[Guid("00380014-F704-49A8-9694-22DA620B8282")]
[CoClass(typeof(APServerEventSinkClass))]
public interface APServerEventSink : DASCSimulationMsgsEvents
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("FEFB9BC2-E111-11D4-82AD-00C04F048AAE")]
public class APServerEventSinkClass
{
	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	public virtual extern void OnNewLine([In][MarshalAs(UnmanagedType.BStr)] string bText);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void DASCSimulationMsgsEvents2_OnNewLine([In][MarshalAs(UnmanagedType.BStr)] string bText);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void UpdateProfiles([In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] string[] nameArray, [In][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)] object[] valArray, double time);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void ResetSimulation();
}
[ComImport]
[Guid("0D47E730-3826-11D5-8301-00C04F298756")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPServerSim
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void NewEvent([In] int lEventId, [In][MarshalAs(UnmanagedType.Struct)] object Hint1, [In][MarshalAs(UnmanagedType.Struct)] object Hint2);
}
[ComImport]
[Guid("0D47E730-3826-11D5-8301-00C04F298756")]
[CoClass(typeof(APServerSimClass))]
public interface APServerSim : IAPServerSim, _IAPServerSimEvents_Event
{
}
[ComImport]
[Guid("0D47E731-3826-11D5-8301-00C04F298756")]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[ComSourceInterfaces("AspenTech.AspenPlus.APServer._IAPServerSimEvents\0\0")]
[ClassInterface(ClassInterfaceType.None)]
public class APServerSimClass
{
	public virtual extern event _IAPServerSimEvents_OnEventEventHandler OnEvent;

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void NewEvent([In] int lEventId, [In][MarshalAs(UnmanagedType.Struct)] object Hint1, [In][MarshalAs(UnmanagedType.Struct)] object Hint2);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("04FAAC4D-A497-445E-83CA-0CD81F111E47")]
public interface IAPProperties
{
	[DispId(1610743809)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743818)]
	object OptionValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void AddComponent([In][MarshalAs(UnmanagedType.BStr)] string Component);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void RemoveComponent([In][MarshalAs(UnmanagedType.BStr)] string Component);

	[DispId(1610743813)]
	int Components
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
	}

	[DispId(1610743814)]
	int Options
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void RenameComponent([In][MarshalAs(UnmanagedType.BStr)] string OldName, [In][MarshalAs(UnmanagedType.BStr)] string NewName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	void RemoveAllComponents();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	void SetParent([MarshalAs(UnmanagedType.BStr)] string Parent);
}
[ComImport]
[CoClass(typeof(APSHostCompListClass))]
[Guid("04FAAC4D-A497-445E-83CA-0CD81F111E47")]
public interface APSHostCompList : IAPProperties
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("454A5CEC-A2DC-4F75-8EFF-F9384B3728FD")]
public interface IAPPolymerProperties
{
	[DispId(1610743809)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743813)]
	object OptionValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void RemoveFromOptionValueList([In][ComAliasName("AspenTech.AspenPlus.APServer.APPolymerOption")] APPolymerOption option, [In][MarshalAs(UnmanagedType.BStr)] string ValueToBeRemoved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void AddToOptionValueList([In][ComAliasName("AspenTech.AspenPlus.APServer.APPolymerOption")] APPolymerOption option, [In][MarshalAs(UnmanagedType.BStr)] string ValueToBeAdded);
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("E1D176E8-0055-4A91-95F4-F24C736A0F40")]
public class APSHostCompListClass
{
	[DispId(1610743809)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743818)]
	public virtual extern object OptionValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743813)]
	public virtual extern int Components
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
	}

	[DispId(1610743814)]
	public virtual extern int Options
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		get;
	}

	public virtual extern string IAPPolymerProperties_Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	public virtual extern object IAPPolymerProperties_OptionValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	public virtual extern void AddComponent([In][MarshalAs(UnmanagedType.BStr)] string Component);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	public virtual extern void RemoveComponent([In][MarshalAs(UnmanagedType.BStr)] string Component);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void RenameComponent([In][MarshalAs(UnmanagedType.BStr)] string OldName, [In][MarshalAs(UnmanagedType.BStr)] string NewName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	public virtual extern void RemoveAllComponents();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	public virtual extern void SetParent([MarshalAs(UnmanagedType.BStr)] string Parent);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void RemoveFromOptionValueList([In][ComAliasName("AspenTech.AspenPlus.APServer.APPolymerOption")] APPolymerOption option, [In][MarshalAs(UnmanagedType.BStr)] string ValueToBeRemoved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void AddToOptionValueList([In][ComAliasName("AspenTech.AspenPlus.APServer.APPolymerOption")] APPolymerOption option, [In][MarshalAs(UnmanagedType.BStr)] string ValueToBeAdded);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("074274FE-078E-4314-8571-57B1BA1F5182")]
public interface IAPPropertiesCollection : IEnumerable
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	[return: MarshalAs(UnmanagedType.Interface)]
	APSHostCompList Add([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.Interface)]
	APSHostCompList Duplicate([In][MarshalAs(UnmanagedType.BStr)] string source, [In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void Remove([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[DispId(1610743812)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(0)]
	APSHostCompList this[[In][MarshalAs(UnmanagedType.Struct)] object index]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();
}
[ComImport]
[Guid("074274FE-078E-4314-8571-57B1BA1F5182")]
[CoClass(typeof(APSHostCompListMgrClass))]
public interface APSHostCompListMgr : IAPPropertiesCollection
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("3722C7C5-EBD2-4559-9CA8-2B8BEA2ED33D")]
[ClassInterface(ClassInterfaceType.None)]
public class APSHostCompListMgrClass
{
	[DispId(1610743812)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(0)]
	public virtual extern APSHostCompList this[[In][MarshalAs(UnmanagedType.Struct)] object index]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern APSHostCompList Add([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern APSHostCompList Duplicate([In][MarshalAs(UnmanagedType.BStr)] string source, [In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void Remove([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	public virtual extern void Rename([In][MarshalAs(UnmanagedType.BStr)] string fqOldname, [In][MarshalAs(UnmanagedType.BStr)] string fqNewname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("C1D4AF78-42F1-4397-8F0B-91E02F1C0C2C")]
public interface ICatalogXMLManager
{
	[DispId(1)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	bool IsEmpty();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object CatObjects([ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void Load([In][MarshalAs(UnmanagedType.BStr)] string bsCatFullName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void FindCatObjectByName([ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [MarshalAs(UnmanagedType.BStr)] string bsModelName, [MarshalAs(UnmanagedType.IUnknown)] ref object ppUnk);
}
[ComImport]
[CoClass(typeof(CatalogXMLManagerClass))]
[Guid("C1D4AF78-42F1-4397-8F0B-91E02F1C0C2C")]
public interface CatalogXMLManager : ICatalogXMLManager
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[ClassInterface(ClassInterfaceType.None)]
[Guid("0E83E008-5A8D-41B0-BA94-825C66DCC5F4")]
public class CatalogXMLManagerClass
{
	[DispId(1)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	public virtual extern bool IsEmpty();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object CatObjects([ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	public virtual extern void Load([In][MarshalAs(UnmanagedType.BStr)] string bsCatFullName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	public virtual extern void FindCatObjectByName([ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")] eCatalogObjectClassType eType, [MarshalAs(UnmanagedType.BStr)] string bsModelName, [MarshalAs(UnmanagedType.IUnknown)] ref object ppUnk);
}
[ComImport]
[DefaultMember("Item")]
[Guid("12EE3013-3658-486E-A5A7-9CB5DF2F191B")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface ICatObjectCollection : IEnumerable
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(0)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object Item([In][MarshalAs(UnmanagedType.Struct)] object vtIndex);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
	}
}
[ComImport]
[CoClass(typeof(CatObjectCollectionClass))]
[Guid("12EE3013-3658-486E-A5A7-9CB5DF2F191B")]
public interface CatObjectCollection : ICatObjectCollection
{
}
[ComImport]
[DefaultMember("Item")]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[ClassInterface(ClassInterfaceType.None)]
[Guid("17DCE8F8-0806-4591-B17B-F8047C1DCD3C")]
public class CatObjectCollectionClass
{
	[DispId(1)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(0)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object Item([In][MarshalAs(UnmanagedType.Struct)] object vtIndex);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();
}
[ComImport]
[Guid("0C25BB7F-4121-4FFF-80D3-7503A06583B6")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface ICatObject
{
	[DispId(1)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")]
	[DispId(2)]
	eCatalogObjectClassType ClassType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")]
		get;
	}

	[DispId(3)]
	string DLLName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(3)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object DLL();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object CatObjModels();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[CoClass(typeof(CatObjectClass))]
[Guid("0C25BB7F-4121-4FFF-80D3-7503A06583B6")]
public interface CatObject : ICatObject
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("D5021E05-136B-4E5F-868F-BC343B71C132")]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
public class CatObjectClass
{
	[DispId(1)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")]
	[DispId(2)]
	public virtual extern eCatalogObjectClassType ClassType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[return: ComAliasName("AspenTech.AspenPlus.APServer.eCatalogObjectClassType")]
		get;
	}

	[DispId(3)]
	public virtual extern string DLLName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(3)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object DLL();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object CatObjModels();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[DefaultMember("Item")]
[Guid("32785C59-A3E9-49DC-B7DA-2FF47C79FBBF")]
public interface ICatObjectModelCollection : IEnumerable
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(0)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object Item([In][MarshalAs(UnmanagedType.Struct)] object vtIndex);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
	}
}
[ComImport]
[CoClass(typeof(CatObjectModelCollectionClass))]
[Guid("32785C59-A3E9-49DC-B7DA-2FF47C79FBBF")]
public interface CatObjectModelCollection : ICatObjectModelCollection
{
}
[ComImport]
[DefaultMember("Item")]
[Guid("46C9B5A3-7F1A-4BC1-ADAF-A471A43990C1")]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[ClassInterface(ClassInterfaceType.None)]
public class CatObjectModelCollectionClass
{
	[DispId(1)]
	public virtual extern int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(0)]
	[return: MarshalAs(UnmanagedType.Struct)]
	public virtual extern object Item([In][MarshalAs(UnmanagedType.Struct)] object vtIndex);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	public virtual extern IEnumerator GetEnumerator();
}
[ComImport]
[Guid("7B5255FF-F644-4203-9A85-1E602E09C17B")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface ICatObjectModel
{
	[DispId(1)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(2)]
	string CategoryId
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IStream GetStreamFromStorage([In][ComAliasName("AspenTech.AspenPlus.APServer.eModelStrmType")] eModelStrmType eAttribute);
}
[ComImport]
[CoClass(typeof(CatObjectModelClass))]
[Guid("7B5255FF-F644-4203-9A85-1E602E09C17B")]
public interface CatObjectModel : ICatObjectModel
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("CCE7CDA7-EAA8-46D9-B49F-422FE12E5E9A")]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
public class CatObjectModelClass
{
	[DispId(1)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(2)]
	public virtual extern string CategoryId
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IStream GetStreamFromStorage([In][ComAliasName("AspenTech.AspenPlus.APServer.eModelStrmType")] eModelStrmType eAttribute);
}
[ComImport]
[Guid("882E74AC-7283-4BDE-8DFB-BBDB520B5B53")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface ICatObjectDLL
{
	[DispId(1)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object Models();
}
[ComImport]
[Guid("882E74AC-7283-4BDE-8DFB-BBDB520B5B53")]
[CoClass(typeof(CatObjectDLLClass))]
public interface CatObjectDLL : ICatObjectDLL
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[TypeLibType(TypeLibTypeFlags.FCanCreate)]
[Guid("03606C1C-57CD-4413-8276-C162CE9FAF85")]
public class CatObjectDLLClass
{
	[DispId(1)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	public virtual extern object Models();
}
[ComVisible(false)]
public delegate void _IAPServerSimEvents_OnEventEventHandler([In] int lEventId, [In][MarshalAs(UnmanagedType.Struct)] object Hint1, [In][MarshalAs(UnmanagedType.Struct)] object Hint2);
public enum eCatalogObjectClassType
{
	CLS_ACMBlock,
	CLS_ACMReaction,
	CLS_AOSSolver,
	CLS_ACMBlockBuiltIn
}
public enum eACMComponentManagerEventType
{
	ACMCListEvent_Added,
	ACMCListEvent_Removed,
	ACMCListEvent_Renamed
}
public enum APPropertyOption
{
	APOpt_ComponentList,
	APOpt_PropertyMethod,
	APOpt_HenryComponentsID,
	APOpt_ChemistryID,
	APOpt_FreeWater,
	APOpt_WaterSolubility,
	APOpt_SimulationApproach,
	APOpt_KBase,
	APOpt_Retention,
	APOpt_Tolerance,
	APOpt_MaxIterations,
	APOpt_Notify
}
[ComImport]
[Guid("0C733A30-2A1C-11CE-ADE5-00AA0044773D")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface ISequentialStream
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteRead(out byte pv, [In] uint cb, out uint pcbRead);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteWrite([In] ref byte pv, [In] uint cb, out uint pcbWritten);
}
[ComImport]
[Guid("0000000C-0000-0000-C000-000000000046")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IStream : ISequentialStream
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	new void RemoteRead(out byte pv, [In] uint cb, out uint pcbRead);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	new void RemoteWrite([In] ref byte pv, [In] uint cb, out uint pcbWritten);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteSeek([In] _LARGE_INTEGER dlibMove, [In] uint dwOrigin, out _ULARGE_INTEGER plibNewPosition);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetSize([In] _ULARGE_INTEGER libNewSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteCopyTo([In][MarshalAs(UnmanagedType.Interface)] IStream pstm, [In] _ULARGE_INTEGER cb, out _ULARGE_INTEGER pcbRead, out _ULARGE_INTEGER pcbWritten);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Commit([In] uint grfCommitFlags);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Revert();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void LockRegion([In] _ULARGE_INTEGER libOffset, [In] _ULARGE_INTEGER cb, [In] uint dwLockType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void UnlockRegion([In] _ULARGE_INTEGER libOffset, [In] _ULARGE_INTEGER cb, [In] uint dwLockType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Stat(out tagSTATSTG pstatstg, [In] uint grfStatFlag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Clone([MarshalAs(UnmanagedType.Interface)] out IStream ppstm);
}
public enum eModelStrmType
{
	STRM_PortDefXML,
	STRM_APTemplate,
	STRM_IconDef,
	STRM_CustomFormsXML,
	STRM_StyleSheetXML,
	STRM_ACMLanguage,
	STRM_Config,
	STRM_ACMRxnConfig
}
public enum APServerRetVMask
{
	APSERVER_RTEVMASK_NAME,
	APSERVER_RTEVMASK_PHYSICAL_TYPE,
	APSERVER_RTEVMASK_LOWER,
	APSERVER_RTEVMASK_VALUE,
	APSERVER_RTEVMASK_UPPER,
	APSERVER_RTEVMASK_SCALE,
	APSERVER_RTEVMASK_UOM,
	APSERVER_RTEVMASK_CODE,
	APSERVER_RTEVMASK_STEP,
	APSERVER_RTEVMASK_SBWEIGHT,
	APSERVER_RTEVMASK_SHADOW_PRICE,
	APSERVER_RTEVMASK_ACTIVE_BOUND,
	APSERVER_RTEVMASK_QUALITY,
	APSERVER_RTESIZEOF_VMASK
}
public enum eAPCapeOpenIdOption
{
	CAPE_PROGID = 1,
	CAPE_CLSID
}
public enum __MIDL___MIDL_itf_apserverdll_0000_0000_0010
{
	CAPE_PROGID = 1,
	CAPE_CLSID
}
public enum ApServerRteBlockStatus
{
	APSERVERRTE_BLOCK_NONEXISTENT,
	APSERVERRTE_BLOCK_EXCLUDED,
	APSERVERRTE_BLOCK_INCLUDED
}
public enum ApServerRteParamType
{
	APSERVERRTE_PARAM_UNDEFINED,
	APSERVERRTE_PARAM_UNKNOWN,
	APSERVERRTE_PARAM_STRING,
	APSERVERRTE_PARAM_REAL,
	APSERVERRTE_PARAM_INTEGER
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct _LARGE_INTEGER
{
	public long QuadPart;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct _ULARGE_INTEGER
{
	public ulong QuadPart;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct tagSTATSTG
{
	[MarshalAs(UnmanagedType.LPWStr)]
	public string pwcsName;

	public uint type;

	public _ULARGE_INTEGER cbSize;

	public _FILETIME mtime;

	public _FILETIME ctime;

	public _FILETIME atime;

	public uint grfMode;

	public uint grfLocksSupported;

	public Guid clsid;

	public uint grfStateBits;

	public uint reserved;
}
[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct _FILETIME
{
	public uint dwLowDateTime;

	public uint dwHighDateTime;
}
public enum __MIDL___MIDL_itf_apserverdll_0000_0000_0007
{
	CLS_ACMBlock,
	CLS_ACMReaction,
	CLS_AOSSolver,
	CLS_ACMBlockBuiltIn
}
public enum __MIDL___MIDL_itf_apserverdll_0000_0000_0003
{
	APSERVERRTE_BLOCK_NONEXISTENT,
	APSERVERRTE_BLOCK_EXCLUDED,
	APSERVERRTE_BLOCK_INCLUDED
}
public enum __MIDL___MIDL_itf_apserverdll_0000_0000_0002
{
	APSERVERRTE_PARAM_UNDEFINED,
	APSERVERRTE_PARAM_UNKNOWN,
	APSERVERRTE_PARAM_STRING,
	APSERVERRTE_PARAM_REAL,
	APSERVERRTE_PARAM_INTEGER
}
public enum __MIDL___MIDL_itf_apserverdll_0000_0000_0004
{
	APOpt_ComponentList,
	APOpt_PropertyMethod,
	APOpt_HenryComponentsID,
	APOpt_ChemistryID,
	APOpt_FreeWater,
	APOpt_WaterSolubility,
	APOpt_SimulationApproach,
	APOpt_KBase,
	APOpt_Retention,
	APOpt_Tolerance,
	APOpt_MaxIterations,
	APOpt_Notify
}
public enum __MIDL___MIDL_itf_apserverdll_0000_0000_0006
{
	ACMCListEvent_Added,
	ACMCListEvent_Removed,
	ACMCListEvent_Renamed
}
public enum eResetTypes
{
	RESET_CALC_VARIABLE = 1,
	RESET_CONST_VARIABLE = 2,
	RESET_VARIABLE = 3,
	RESET_PARAMETER = 4,
	RESET_ALL = 7
}
public enum __MIDL___MIDL_itf_apserverdll_0000_0000_0009
{
	RESET_CALC_VARIABLE = 1,
	RESET_CONST_VARIABLE = 2,
	RESET_VARIABLE = 3,
	RESET_PARAMETER = 4,
	RESET_ALL = 7
}
public enum APPolymerOption
{
	APPolyOpt_Polymer,
	APPolyOpt_Catalyst,
	APPolyOpt_Segments,
	APPolyOpt_PolymerAttributes,
	APPolyOpt_CatalystAttributes,
	APPolyOpt_CatalystSites,
	APPolyOpt_CAUSR1Comps,
	APPolyOpt_CAUSR2Comps,
	APPolyOpt_CAUSR3Comps,
	APPolyOpt_CAUSR4Comps,
	APPolyOpt_CAUSR5Comps,
	APPolyOpt_CAUSRAComps,
	APPolyOpt_CAUSRBComps,
	APPolyOpt_CAUSRCComps,
	APPolyOpt_CAUSRDComps,
	APPolyOpt_CAUSREComps,
	APPolyOpt_CACLASS0Comps,
	APPolyOpt_PROXANALComps,
	APPolyOpt_ULTANALComps,
	APPolyOpt_SULFANALComps,
	APPolyOpt_GENANALComps,
	APPolyOpt_PSDName,
	APPolyOpt_PSDIntervals,
	APPolyOpt_PSDSizeofIntervals,
	APPolyOpt_SubStreams,
	APPolyOpt_NCComps
}
public enum __MIDL___MIDL_itf_apserverdll_0000_0000_0005
{
	APPolyOpt_Polymer,
	APPolyOpt_Catalyst,
	APPolyOpt_Segments,
	APPolyOpt_PolymerAttributes,
	APPolyOpt_CatalystAttributes,
	APPolyOpt_CatalystSites,
	APPolyOpt_CAUSR1Comps,
	APPolyOpt_CAUSR2Comps,
	APPolyOpt_CAUSR3Comps,
	APPolyOpt_CAUSR4Comps,
	APPolyOpt_CAUSR5Comps,
	APPolyOpt_CAUSRAComps,
	APPolyOpt_CAUSRBComps,
	APPolyOpt_CAUSRCComps,
	APPolyOpt_CAUSRDComps,
	APPolyOpt_CAUSREComps,
	APPolyOpt_CACLASS0Comps,
	APPolyOpt_PROXANALComps,
	APPolyOpt_ULTANALComps,
	APPolyOpt_SULFANALComps,
	APPolyOpt_GENANALComps,
	APPolyOpt_PSDName,
	APPolyOpt_PSDIntervals,
	APPolyOpt_PSDSizeofIntervals,
	APPolyOpt_SubStreams,
	APPolyOpt_NCComps
}
public enum __MIDL___MIDL_itf_apserverdll_0000_0000_0008
{
	STRM_PortDefXML,
	STRM_APTemplate,
	STRM_IconDef,
	STRM_CustomFormsXML,
	STRM_StyleSheetXML,
	STRM_ACMLanguage,
	STRM_Config,
	STRM_ACMRxnConfig
}
[ClassInterface(ClassInterfaceType.None)]
[TypeLibType(TypeLibTypeFlags.FHidden)]
public sealed class _IAPServerSimEvents_SinkHelper : _IAPServerSimEvents
{
	public _IAPServerSimEvents_OnEventEventHandler m_OnEventDelegate;

	public int m_dwCookie;

	public void OnEvent(int P_0, object P_1, object P_2)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnEventDelegate != null)
		{
			m_OnEventDelegate(P_0, P_1, P_2);
		}
	}

	internal _IAPServerSimEvents_SinkHelper()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		m_dwCookie = 0;
		m_OnEventDelegate = null;
	}
}
internal sealed class _IAPServerSimEvents_EventProvider : IDisposable
{
	private WeakReference m_wkConnectionPointContainer;

	private ArrayList m_aEventSinkHelpers;

	private IConnectionPoint m_ConnectionPoint;

	private void Init()
	{
		IConnectionPoint ppCP = null;
		byte[] guidBytes = new byte[16];
guidBytes[0] = 50;
guidBytes[1] = 231;
guidBytes[2] = 71;
guidBytes[3] = 13;
guidBytes[4] = 38;
guidBytes[5] = 56;
guidBytes[6] = 213;
guidBytes[7] = 17;
guidBytes[8] = 131;
guidBytes[9] = 1;
guidBytes[10] = 0;
guidBytes[11] = 192;
guidBytes[12] = 79;
guidBytes[13] = 41;
guidBytes[14] = 135;
guidBytes[15] = 86;
Guid riid = new Guid(guidBytes);
		((IConnectionPointContainer)m_wkConnectionPointContainer.Target).FindConnectionPoint(ref riid, out ppCP);
		m_ConnectionPoint = ppCP;
		m_aEventSinkHelpers = new ArrayList();
	}

	public void add_OnEvent(_IAPServerSimEvents_OnEventEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			_IAPServerSimEvents_SinkHelper iAPServerSimEvents_SinkHelper = new _IAPServerSimEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPServerSimEvents_SinkHelper, out pdwCookie);
			iAPServerSimEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPServerSimEvents_SinkHelper.m_OnEventDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPServerSimEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnEvent(_IAPServerSimEvents_OnEventEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				_IAPServerSimEvents_SinkHelper iAPServerSimEvents_SinkHelper = (_IAPServerSimEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPServerSimEvents_SinkHelper.m_OnEventDelegate != null && ((iAPServerSimEvents_SinkHelper.m_OnEventDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPServerSimEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public _IAPServerSimEvents_EventProvider(object P_0)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		m_wkConnectionPointContainer = new WeakReference((IConnectionPointContainer)P_0, trackResurrection: false);
	}

	public void Finalize()
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
				do
				{
					_IAPServerSimEvents_SinkHelper iAPServerSimEvents_SinkHelper = (_IAPServerSimEvents_SinkHelper)m_aEventSinkHelpers[num];
					m_ConnectionPoint.Unadvise(iAPServerSimEvents_SinkHelper.m_dwCookie);
					num++;
				}
				while (num < count);
			}
			Marshal.ReleaseComObject(m_ConnectionPoint);
			}
		}
		catch (Exception)
		{
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void Dispose()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		Finalize();
		GC.SuppressFinalize(this);
	}
}
