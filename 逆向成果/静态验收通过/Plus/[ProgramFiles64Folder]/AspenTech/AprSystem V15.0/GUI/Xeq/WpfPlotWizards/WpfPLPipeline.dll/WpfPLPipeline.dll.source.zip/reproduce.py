"""Clean-room reproduction from one archived package.

Usage: py -3 reproduce.py <archive.zip> <new-empty-dir>

Steps:
  1. extract the archive into <new-empty-dir>
  2. compile editable source with the archived relative compile.rsp
  3. verify compiled image SHA-256 == receipt.candidate_sha256 (source-rebuild check)
  4. replay the archived layout recipe over the compiled image
  5. compare final SHA-256 with receipt.sha256 and print equal
Exit 0 only when the final image is byte-identical to the original.
"""
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE / "tools"),
                r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps"]

DOTNET = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\patrol-0857\review340\net9\dotnet.exe")
CSC = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\patrol-0857\review340\net9\sdk\9.0.321\Roslyn\bincore\csc.dll")


def sha(b):
    return hashlib.sha256(b).hexdigest()


def main(archive, out):
    out = Path(out)
    if out.exists() and any(out.iterdir()):
        raise SystemExit("target dir not empty: " + str(out))
    out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        z.extractall(out)
    receipt = json.loads((out / "receipt.json").read_text(encoding="utf-8"))
    name = receipt["name"]
    import token_replay

    (out / "compiled").mkdir(exist_ok=True)
    p = subprocess.run([str(DOTNET), str(CSC), "/noconfig", "/nologo", "@compile.rsp"],
                       cwd=str(out), capture_output=True)
    compiled = out / "compiled" / name
    if p.returncode or not compiled.is_file():
        print((p.stdout + p.stderr).decode("utf-8", "replace")[-3000:])
        return 1
    csha = sha(compiled.read_bytes())
    print(json.dumps({"compiled_sha256": csha,
                      "expected_candidate_sha256": receipt.get("candidate_sha256"),
                      "candidate_equal": csha == receipt.get("candidate_sha256")}, indent=1))
    if receipt.get("candidate_sha256") and csha != receipt["candidate_sha256"]:
        print("CANDIDATE MISMATCH: source rebuild is not the archived candidate")
        return 2

    recipe = json.loads((out / "layout-recipe.json").read_text(encoding="utf-8"))
    ob = out / "original-build"

    def asset(n):
        q = ob / n
        return q.read_bytes() if q.is_file() else b""

    data = token_replay.reproduce(
        compiled.read_bytes(), recipe,
        asset("clr-metadata.bin"), asset("debug-record.bin"),
        asset("certificate-table.bin"),
        asset("strong-name.bin") if recipe.get("strong_name") else b"")
    final = sha(data)
    equal = final == receipt["sha256"]
    print(json.dumps({"final_sha256": final, "original_sha256": receipt["sha256"],
                      "equal": equal}, indent=1))
    return 0 if equal else 3


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
