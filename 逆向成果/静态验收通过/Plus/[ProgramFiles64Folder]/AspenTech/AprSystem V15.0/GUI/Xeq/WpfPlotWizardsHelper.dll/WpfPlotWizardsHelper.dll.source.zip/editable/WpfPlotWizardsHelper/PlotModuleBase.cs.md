# PlotModuleBase.cs

Source: editable/WpfPlotWizardsHelper/PlotModuleBase.cs

Source SHA-256: d240d3b92d837ea53c64043a2e9e6458aeb46be10310e6f7bb30b31bf5db9c7b
