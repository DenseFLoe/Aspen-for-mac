using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLVscrub;

[RibbonPlotWizardMgr("WpfPLVSCRUB.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class VscrubPlotWizardModule : PlotModuleBase
{
}
