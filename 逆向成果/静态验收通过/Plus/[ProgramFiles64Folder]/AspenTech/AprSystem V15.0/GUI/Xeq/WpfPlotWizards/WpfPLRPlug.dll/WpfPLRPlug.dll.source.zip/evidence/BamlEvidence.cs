using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Resources;
using System.Security.Cryptography;
using ICSharpCode.BamlDecompiler;
using ICSharpCode.Decompiler.Metadata;

static class BamlEvidence
{
    static void Main(string[] args)
    {
        if (args.Length < 4)
            throw new ArgumentException("Usage: <code DLL> <satellite DLL> <output dir> <reference dirs...>");
        var main = Path.GetFullPath(args[0]);
        var resolver = new UniversalAssemblyResolver(main, false, ".NETFramework,Version=v4.8");
        foreach (string dir in args.Skip(3))
            resolver.AddSearchDirectory(Path.GetFullPath(dir));
        var settings = new BamlDecompilerSettings { ThrowOnAssemblyResolveErrors = false };
        var decompiler = new XamlDecompiler(main, resolver, settings);

        using var pe = new PEReader(File.OpenRead(args[1]));
        var metadata = System.Reflection.Metadata.PEReaderExtensions.GetMetadataReader(pe);
        var entries = metadata.ManifestResources.Select(metadata.GetManifestResource).ToArray();
        var manifest = entries.Single(entry => metadata.GetString(entry.Name) == "WpfPLRPlug.g.en-US.resources");
        if (!manifest.Implementation.IsNil)
            throw new InvalidDataException("The satellite layout is not embedded.");
        var directory = pe.PEHeaders.CorHeader!.ResourcesDirectory;
        var data = pe.GetSectionData(directory.RelativeVirtualAddress)
            .GetContent(checked((int)manifest.Offset), directory.Size - checked((int)manifest.Offset)).ToArray();
        int length = BinaryPrimitives.ReadInt32LittleEndian(data);
        using var resources = new ResourceReader(new MemoryStream(data, 4, length));
        Directory.CreateDirectory(args[2]);

        var keys = new List<string>();
        var entriesReader = resources.GetEnumerator();
        while (entriesReader.MoveNext())
            keys.Add((string)entriesReader.Key);
        foreach (string key in keys.OrderBy(key => key, StringComparer.Ordinal))
        {
            if (!key.EndsWith(".baml", StringComparison.OrdinalIgnoreCase) || key != Path.GetFileName(key))
                throw new InvalidDataException("Unexpected satellite resource key: " + key);
            resources.GetResourceData(key, out var type, out var raw);
            if (type != "ResourceTypeCode.Stream" || BinaryPrimitives.ReadInt32LittleEndian(raw) != raw.Length - 4)
                throw new InvalidDataException("Invalid BAML stream: " + key);
            byte[] bytes = raw[4..];
            using var stream = new MemoryStream(bytes, false);
            var result = decompiler.Decompile(stream);
            string name = Path.GetFileNameWithoutExtension(key);
            result.Xaml.Save(Path.Combine(args[2], name + ".xaml"));
            Console.WriteLine($"{key}\t{bytes.Length}\t{Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant()}");
        }
    }
}
