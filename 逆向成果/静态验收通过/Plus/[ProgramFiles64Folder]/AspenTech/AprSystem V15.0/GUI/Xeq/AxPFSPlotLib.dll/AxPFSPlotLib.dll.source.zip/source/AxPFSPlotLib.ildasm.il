﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  AxPFSPlotLib.AxPfsplot
  AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler
  AxPFSPlotLib._DPfsplotEvents_SelectedEvent
  AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler
  AxPFSPlotLib._DPfsplotEvents_ZoomedEvent
  AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler
  AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent
  AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler
  AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent
  AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler
  AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent
  AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler
  AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent
  AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler
  AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent
  AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler
  AxPFSPlotLib._DPfsplotEvents_OnClickEvent
  AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler
  AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent
  AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler
  AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent
  AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler
  AxPFSPlotLib._DPfsplotEvents_KeyPressEvent
  AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler
  AxPFSPlotLib._DPfsplotEvents_KeyDownEvent
  AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler
  AxPFSPlotLib._DPfsplotEvents_KeyUpEvent
  AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler
  AxPFSPlotLib._DPfsplotEvents_ScrolledEvent
  AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler
  AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent
  AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler
  AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent
  AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler
  AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent
  AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler
  AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent
  AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler
  AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent
  AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler
  AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent
  AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler
  AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent
  AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler
  AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent
  AxPFSPlotLib.AxPfsplotEventMulticaster
}

// Metadata version: v4.0.30319
.assembly extern System.Windows.Forms
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern PFSPlotLib
{
  .publickeytoken = (B0 56 89 B3 9D EE FB CD )                         // .V......
  .ver 1:6:0:0
}
.assembly extern System.Drawing
{
  .publickeytoken = (B0 3F 5F 7F 11 D5 0A 3A )                         // .?_....:
  .ver 4:0:0:0
}
.assembly extern System
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly AxPFSPlotLib
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.
  .custom instance void [System.Windows.Forms]System.Windows.Forms.AxHost/TypeLibraryTimeStampAttribute::.ctor(string) = ( 01 00 13 30 34 2F 31 34 2F 32 30 32 35 20 30 39   // ...04/14/2025 09
                                                                                                                           3A 30 38 3A 30 32 00 00 )                         // :08:02..
  .custom instance void [mscorlib]System.Reflection.AssemblyKeyFileAttribute::.ctor(string) = ( 01 00 40 2E 2E 5C 70 61 63 6B 61 67 65 73 5C 41   // ..@..\packages\A
                                                                                                73 70 65 6E 54 65 63 68 2E 53 74 72 6F 6E 67 4E   // spenTech.StrongN
                                                                                                61 6D 65 2E 53 4E 4B 2E 31 2E 30 2E 30 5C 63 6F   // ame.SNK.1.0.0\co
                                                                                                6E 74 65 6E 74 5C 41 73 70 65 6E 74 65 63 68 2E   // ntent\Aspentech.
                                                                                                73 6E 6B 00 00 )                                  // snk..
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .publickey = (00 24 00 00 04 80 00 00 94 00 00 00 06 02 00 00   // .$..............
                00 24 00 00 52 53 41 31 00 04 00 00 01 00 01 00   // .$..RSA1........
                31 CE F7 DF 85 4A 51 60 93 9C 58 8A 09 81 30 D8   // 1....JQ`..X...0.
                3B 58 C6 41 43 FE 98 DE 4F EA 84 44 85 EE C0 F8   // ;X.AC...O..D....
                BF 75 0A 6A 39 BA 8A 55 2E 37 20 73 B6 95 3A 09   // .u.j9..U.7 s..:.
                53 17 FB FB A3 6E B8 37 F2 D0 14 D6 2D 52 2D 2C   // S....n.7....-R-,
                B2 4F 39 B6 12 E0 DA 27 6D BF 15 4A 5D 0F 84 0D   // .O9....'m..J]...
                59 7F 81 E6 0E 83 1D 25 B6 EB C3 47 9D 69 C3 A6   // Y......%...G.i..
                6A 21 E7 D3 A8 62 09 D1 D3 50 BB 90 86 82 98 3C   // j!...b...P.....<
                80 C0 F7 D4 3B 60 C3 48 79 73 35 A7 33 B2 61 C8 ) // ....;`.Hys5.3.a.
  .hash algorithm 0x00008004
  .ver 1:6:0:0
}
.module AxPFSPlotLib.dll
// MVID: {e1da7b97-aaec-4c94-a833-4739dc3ca12d}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000009    //  ILONLY
// Image base: 0x0000021FBA020000


// =============== CLASS MEMBERS DECLARATION ===================

.class public auto ansi beforefieldinit AxPFSPlotLib.AxPfsplot
       extends [System.Windows.Forms]System.Windows.Forms.AxHost
{
  .custom instance void [System]System.ComponentModel.DesignTimeVisibleAttribute::.ctor(bool) = ( 01 00 01 00 00 ) 
  .custom instance void [System]System.ComponentModel.DefaultEventAttribute::.ctor(string) = ( 01 00 08 53 65 6C 65 63 74 65 64 00 00 )          // ...Selected..
  .custom instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ClsidAttribute::.ctor(string) = ( 01 00 26 7B 63 61 34 31 32 65 31 39 2D 33 38 33   // ..&{ca412e19-383
                                                                                                            62 2D 34 31 30 30 2D 38 61 32 38 2D 32 32 31 34   // b-4100-8a28-2214
                                                                                                            64 32 33 39 31 62 65 62 7D 00 00 )                // d2391beb}..
  .field private class [PFSPlotLib]PFSPlotLib._DPfsplot ocx
  .field private class AxPFSPlotLib.AxPfsplotEventMulticaster eventMulticaster
  .field private class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie cookie
  .field private class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler Selected
  .field private class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler Zoomed
  .field private class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler VariableChanged
  .field private class [mscorlib]System.EventHandler ApplyVariableChanges
  .field private class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler OnDropText
  .field private class [mscorlib]System.EventHandler ReloadNow
  .field private class [mscorlib]System.EventHandler OnEditProfileVariables
  .field private class [mscorlib]System.EventHandler OnOnShowasHistory
  .field private class [mscorlib]System.EventHandler OnEditProfileTable
  .field private class [mscorlib]System.EventHandler OnResetFormDefinition
  .field private class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler SetMessageText
  .field private class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler CommunicationIntervalsSet
  .field private class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler PointerLocation
  .field private class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler OnClick
  .field private class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler OnDoubleClick
  .field private class [mscorlib]System.EventHandler CursorSet
  .field private class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler OnRBClick
  .field private class [mscorlib]System.EventHandler RegionDefined
  .field private class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler KeyPressEvent
  .field private class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler KeyDownEvent
  .field private class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler KeyUpEvent
  .field private class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler Scrolled
  .field private class [mscorlib]System.EventHandler PointerExit
  .field private class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler PhaseVariableSet
  .field private class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler PhaseVariableDropped
  .field private class [mscorlib]System.EventHandler ZoomTimeRange
  .field private class [mscorlib]System.EventHandler RevertToTimePlot
  .field private class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler OnLivePlot
  .field private class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler SetCaption
  .field private class [mscorlib]System.EventHandler Modified
  .field private class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler PlotDrawn
  .field private class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler ZoomDone
  .field private class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler OnDropFiles
  .field private class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler FlippedFlagChanged
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "ca412e19-383b-4100-8a28-2214d2391beb"
    IL_0006:  call       instance void [System.Windows.Forms]System.Windows.Forms.AxHost::.ctor(string)
    IL_000b:  ldarg.0
    IL_000c:  ldarg.0
    IL_000d:  dup
    IL_000e:  ldvirtftn  instance void AxPFSPlotLib.AxPfsplot::AboutBox()
    IL_0014:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/AboutBoxDelegate::.ctor(object,
                                                                                                                 native int)
    IL_0019:  call       instance void [System.Windows.Forms]System.Windows.Forms.AxHost::SetAboutBoxDelegate(class [System.Windows.Forms]System.Windows.Forms.AxHost/AboutBoxDelegate)
    IL_001e:  ret
  } // end of method AxPfsplot::.ctor

  .method public hidebysig newslot specialname virtual 
          instance string  get_Title() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Title"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::get_Title()
    IL_001f:  ret
  } // end of method AxPfsplot::get_Title

  .method public hidebysig newslot specialname virtual 
          instance void  set_Title(string 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Title"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_Title(string)
    IL_0020:  ret
  } // end of method AxPfsplot::set_Title

  .method public hidebysig newslot specialname virtual 
          instance string  get_xlabel() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "xlabel"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::get_xlabel()
    IL_001f:  ret
  } // end of method AxPfsplot::get_xlabel

  .method public hidebysig newslot specialname virtual 
          instance void  set_xlabel(string 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "xlabel"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_xlabel(string)
    IL_0020:  ret
  } // end of method AxPfsplot::set_xlabel

  .method public hidebysig newslot specialname virtual 
          instance string  get_ylabel() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ylabel"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::get_ylabel()
    IL_001f:  ret
  } // end of method AxPfsplot::get_ylabel

  .method public hidebysig newslot specialname virtual 
          instance void  set_ylabel(string 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ylabel"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_ylabel(string)
    IL_0020:  ret
  } // end of method AxPfsplot::set_ylabel

  .method public hidebysig newslot specialname virtual 
          instance bool  get_MultiYaxis() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "MultiYaxis"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_MultiYaxis()
    IL_001f:  ret
  } // end of method AxPfsplot::get_MultiYaxis

  .method public hidebysig newslot specialname virtual 
          instance void  set_MultiYaxis(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "MultiYaxis"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_MultiYaxis(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_MultiYaxis

  .method public hidebysig newslot specialname virtual 
          instance bool  get_RunPlot() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "RunPlot"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_RunPlot()
    IL_001f:  ret
  } // end of method AxPfsplot::get_RunPlot

  .method public hidebysig newslot specialname virtual 
          instance void  set_RunPlot(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "RunPlot"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_RunPlot(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_RunPlot

  .method public hidebysig newslot specialname virtual 
          instance int16  get_PlotType() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "PlotType"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::get_PlotType()
    IL_001f:  ret
  } // end of method AxPfsplot::get_PlotType

  .method public hidebysig newslot specialname virtual 
          instance void  set_PlotType(int16 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "PlotType"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_PlotType(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::set_PlotType

  .method public hidebysig newslot specialname virtual 
          instance float32  get_TimeWindow() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "TimeWindow"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance float32 [PFSPlotLib]PFSPlotLib._DPfsplot::get_TimeWindow()
    IL_001f:  ret
  } // end of method AxPfsplot::get_TimeWindow

  .method public hidebysig newslot specialname virtual 
          instance void  set_TimeWindow(float32 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "TimeWindow"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_TimeWindow(float32)
    IL_0020:  ret
  } // end of method AxPfsplot::set_TimeWindow

  .method public hidebysig newslot specialname virtual 
          instance bool  get_UseVariable() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "UseVariable"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_UseVariable()
    IL_001f:  ret
  } // end of method AxPfsplot::get_UseVariable

  .method public hidebysig newslot specialname virtual 
          instance void  set_UseVariable(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "UseVariable"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_UseVariable(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_UseVariable

  .method public hidebysig newslot specialname virtual 
          instance string  get_InputFile() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "InputFile"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::get_InputFile()
    IL_001f:  ret
  } // end of method AxPfsplot::get_InputFile

  .method public hidebysig newslot specialname virtual 
          instance void  set_InputFile(string 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "InputFile"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_InputFile(string)
    IL_0020:  ret
  } // end of method AxPfsplot::set_InputFile

  .method public hidebysig newslot specialname virtual 
          instance int16  get_npoints() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "npoints"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::get_npoints()
    IL_001f:  ret
  } // end of method AxPfsplot::get_npoints

  .method public hidebysig newslot specialname virtual 
          instance void  set_npoints(int16 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "npoints"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_npoints(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::set_npoints

  .method public hidebysig newslot specialname virtual 
          instance int16  get_nvariables() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "nvariables"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::get_nvariables()
    IL_001f:  ret
  } // end of method AxPfsplot::get_nvariables

  .method public hidebysig newslot specialname virtual 
          instance void  set_nvariables(int16 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "nvariables"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_nvariables(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::set_nvariables

  .method public hidebysig newslot specialname virtual 
          instance float32  get_TimeScrollUnit() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "TimeScrollUnit"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance float32 [PFSPlotLib]PFSPlotLib._DPfsplot::get_TimeScrollUnit()
    IL_001f:  ret
  } // end of method AxPfsplot::get_TimeScrollUnit

  .method public hidebysig newslot specialname virtual 
          instance void  set_TimeScrollUnit(float32 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "TimeScrollUnit"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_TimeScrollUnit(float32)
    IL_0020:  ret
  } // end of method AxPfsplot::set_TimeScrollUnit

  .method public hidebysig newslot specialname virtual 
          instance int16  get_GridType() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GridType"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::get_GridType()
    IL_001f:  ret
  } // end of method AxPfsplot::get_GridType

  .method public hidebysig newslot specialname virtual 
          instance void  set_GridType(int16 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GridType"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_GridType(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::set_GridType

  .method public hidebysig newslot specialname virtual 
          instance int16  get_MarkerSize() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "MarkerSize"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::get_MarkerSize()
    IL_001f:  ret
  } // end of method AxPfsplot::get_MarkerSize

  .method public hidebysig newslot specialname virtual 
          instance void  set_MarkerSize(int16 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "MarkerSize"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_MarkerSize(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::set_MarkerSize

  .method public hidebysig newslot specialname virtual 
          instance int16  get_MarkerInterval() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "MarkerInterval"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::get_MarkerInterval()
    IL_001f:  ret
  } // end of method AxPfsplot::get_MarkerInterval

  .method public hidebysig newslot specialname virtual 
          instance void  set_MarkerInterval(int16 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "MarkerInterval"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_MarkerInterval(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::set_MarkerInterval

  .method public hidebysig newslot specialname virtual 
          instance bool  get_Flipped() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Flipped"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_Flipped()
    IL_001f:  ret
  } // end of method AxPfsplot::get_Flipped

  .method public hidebysig newslot specialname virtual 
          instance void  set_Flipped(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Flipped"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_Flipped(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_Flipped

  .method public hidebysig newslot specialname virtual 
          instance bool  get_SquarePlot() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SquarePlot"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_SquarePlot()
    IL_001f:  ret
  } // end of method AxPfsplot::get_SquarePlot

  .method public hidebysig newslot specialname virtual 
          instance void  set_SquarePlot(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SquarePlot"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_SquarePlot(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_SquarePlot

  .method public hidebysig newslot specialname virtual 
          instance bool  get_DiagonalLine() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "DiagonalLine"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_DiagonalLine()
    IL_001f:  ret
  } // end of method AxPfsplot::get_DiagonalLine

  .method public hidebysig newslot specialname virtual 
          instance void  set_DiagonalLine(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "DiagonalLine"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_DiagonalLine(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_DiagonalLine

  .method public hidebysig newslot specialname virtual 
          instance bool  get_ZeroLine() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ZeroLine"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_ZeroLine()
    IL_001f:  ret
  } // end of method AxPfsplot::get_ZeroLine

  .method public hidebysig newslot specialname virtual 
          instance void  set_ZeroLine(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ZeroLine"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_ZeroLine(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_ZeroLine

  .method public hidebysig newslot specialname virtual 
          instance int16  get_DisplayType() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "DisplayType"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::get_DisplayType()
    IL_001f:  ret
  } // end of method AxPfsplot::get_DisplayType

  .method public hidebysig newslot specialname virtual 
          instance void  set_DisplayType(int16 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "DisplayType"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_DisplayType(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::set_DisplayType

  .method public hidebysig newslot specialname virtual 
          instance int32  get_BufferSize() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "BufferSize"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int32 [PFSPlotLib]PFSPlotLib._DPfsplot::get_BufferSize()
    IL_001f:  ret
  } // end of method AxPfsplot::get_BufferSize

  .method public hidebysig newslot specialname virtual 
          instance void  set_BufferSize(int32 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "BufferSize"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_BufferSize(int32)
    IL_0020:  ret
  } // end of method AxPfsplot::set_BufferSize

  .method public hidebysig newslot specialname virtual 
          instance bool  get_SizeToData() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SizeToData"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_SizeToData()
    IL_001f:  ret
  } // end of method AxPfsplot::get_SizeToData

  .method public hidebysig newslot specialname virtual 
          instance void  set_SizeToData(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SizeToData"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_SizeToData(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_SizeToData

  .method public hidebysig specialname virtual 
          instance valuetype [System.Drawing]System.Drawing.Color 
          get_BackColor() cil managed
  {
    // Code size       40 (0x28)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brfalse.s  IL_0021

    IL_0008:  ldarg.0
    IL_0009:  call       instance bool [System.Windows.Forms]System.Windows.Forms.AxHost::PropsValid()
    IL_000e:  brfalse.s  IL_0021

    IL_0010:  ldarg.0
    IL_0011:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0016:  callvirt   instance uint32 [PFSPlotLib]PFSPlotLib._DPfsplot::get_BackColor()
    IL_001b:  call       valuetype [System.Drawing]System.Drawing.Color [System.Windows.Forms]System.Windows.Forms.AxHost::GetColorFromOleColor(uint32)
    IL_0020:  ret

    IL_0021:  ldarg.0
    IL_0022:  call       instance valuetype [System.Drawing]System.Drawing.Color [System.Windows.Forms]System.Windows.Forms.AxHost::get_BackColor()
    IL_0027:  ret
  } // end of method AxPfsplot::get_BackColor

  .method public hidebysig specialname virtual 
          instance void  set_BackColor(valuetype [System.Drawing]System.Drawing.Color 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance void [System.Windows.Forms]System.Windows.Forms.AxHost::set_BackColor(valuetype [System.Drawing]System.Drawing.Color)
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_000d:  brfalse.s  IL_0020

    IL_000f:  ldarg.0
    IL_0010:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0015:  ldarg.1
    IL_0016:  call       uint32 [System.Windows.Forms]System.Windows.Forms.AxHost::GetOleColorFromColor(valuetype [System.Drawing]System.Drawing.Color)
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_BackColor(uint32)
    IL_0020:  ret
  } // end of method AxPfsplot::set_BackColor

  .method public hidebysig specialname virtual 
          instance valuetype [System.Drawing]System.Drawing.Color 
          get_ForeColor() cil managed
  {
    // Code size       40 (0x28)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brfalse.s  IL_0021

    IL_0008:  ldarg.0
    IL_0009:  call       instance bool [System.Windows.Forms]System.Windows.Forms.AxHost::PropsValid()
    IL_000e:  brfalse.s  IL_0021

    IL_0010:  ldarg.0
    IL_0011:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0016:  callvirt   instance uint32 [PFSPlotLib]PFSPlotLib._DPfsplot::get_ForeColor()
    IL_001b:  call       valuetype [System.Drawing]System.Drawing.Color [System.Windows.Forms]System.Windows.Forms.AxHost::GetColorFromOleColor(uint32)
    IL_0020:  ret

    IL_0021:  ldarg.0
    IL_0022:  call       instance valuetype [System.Drawing]System.Drawing.Color [System.Windows.Forms]System.Windows.Forms.AxHost::get_ForeColor()
    IL_0027:  ret
  } // end of method AxPfsplot::get_ForeColor

  .method public hidebysig specialname virtual 
          instance void  set_ForeColor(valuetype [System.Drawing]System.Drawing.Color 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance void [System.Windows.Forms]System.Windows.Forms.AxHost::set_ForeColor(valuetype [System.Drawing]System.Drawing.Color)
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_000d:  brfalse.s  IL_0020

    IL_000f:  ldarg.0
    IL_0010:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0015:  ldarg.1
    IL_0016:  call       uint32 [System.Windows.Forms]System.Windows.Forms.AxHost::GetOleColorFromColor(valuetype [System.Drawing]System.Drawing.Color)
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_ForeColor(uint32)
    IL_0020:  ret
  } // end of method AxPfsplot::set_ForeColor

  .method public hidebysig newslot specialname virtual 
          instance bool  get_Parametric() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Parametric"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_Parametric()
    IL_001f:  ret
  } // end of method AxPfsplot::get_Parametric

  .method public hidebysig newslot specialname virtual 
          instance void  set_Parametric(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Parametric"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_Parametric(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_Parametric

  .method public hidebysig newslot specialname virtual 
          instance int16  get_nxvariables() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "nxvariables"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::get_nxvariables()
    IL_001f:  ret
  } // end of method AxPfsplot::get_nxvariables

  .method public hidebysig newslot specialname virtual 
          instance void  set_nxvariables(int16 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "nxvariables"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_nxvariables(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::set_nxvariables

  .method public hidebysig newslot specialname virtual 
          instance bool  get_ReverseXAxis() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ReverseXAxis"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_ReverseXAxis()
    IL_001f:  ret
  } // end of method AxPfsplot::get_ReverseXAxis

  .method public hidebysig newslot specialname virtual 
          instance void  set_ReverseXAxis(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ReverseXAxis"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_ReverseXAxis(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_ReverseXAxis

  .method public hidebysig newslot specialname virtual 
          instance bool  get_AddTimeStamp() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AddTimeStamp"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_AddTimeStamp()
    IL_001f:  ret
  } // end of method AxPfsplot::get_AddTimeStamp

  .method public hidebysig newslot specialname virtual 
          instance void  set_AddTimeStamp(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AddTimeStamp"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_AddTimeStamp(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_AddTimeStamp

  .method public hidebysig newslot specialname virtual 
          instance bool  get_ShowLegend() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ShowLegend"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_ShowLegend()
    IL_001f:  ret
  } // end of method AxPfsplot::get_ShowLegend

  .method public hidebysig newslot specialname virtual 
          instance void  set_ShowLegend(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ShowLegend"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_ShowLegend(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_ShowLegend

  .method public hidebysig newslot specialname virtual 
          instance int16  get_CommunicationIntervals() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CommunicationIntervals"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::get_CommunicationIntervals()
    IL_001f:  ret
  } // end of method AxPfsplot::get_CommunicationIntervals

  .method public hidebysig newslot specialname virtual 
          instance void  set_CommunicationIntervals(int16 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CommunicationIntervals"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_CommunicationIntervals(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::set_CommunicationIntervals

  .method public hidebysig newslot specialname virtual 
          instance float32  get_GridInterval() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GridInterval"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance float32 [PFSPlotLib]PFSPlotLib._DPfsplot::get_GridInterval()
    IL_001f:  ret
  } // end of method AxPfsplot::get_GridInterval

  .method public hidebysig newslot specialname virtual 
          instance void  set_GridInterval(float32 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GridInterval"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_GridInterval(float32)
    IL_0020:  ret
  } // end of method AxPfsplot::set_GridInterval

  .method public hidebysig newslot specialname virtual 
          instance bool  get_VariableDrop() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "VariableDrop"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_VariableDrop()
    IL_001f:  ret
  } // end of method AxPfsplot::get_VariableDrop

  .method public hidebysig newslot specialname virtual 
          instance void  set_VariableDrop(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "VariableDrop"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_VariableDrop(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_VariableDrop

  .method public hidebysig newslot specialname virtual 
          instance bool  get_IgnoreSetLegend() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IgnoreSetLegend"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_IgnoreSetLegend()
    IL_001f:  ret
  } // end of method AxPfsplot::get_IgnoreSetLegend

  .method public hidebysig newslot specialname virtual 
          instance void  set_IgnoreSetLegend(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IgnoreSetLegend"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_IgnoreSetLegend(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_IgnoreSetLegend

  .method public hidebysig newslot specialname virtual 
          instance object  get_PlotVals() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "PlotVals"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance object [PFSPlotLib]PFSPlotLib._DPfsplot::get_PlotVals()
    IL_001f:  ret
  } // end of method AxPfsplot::get_PlotVals

  .method public hidebysig newslot specialname virtual 
          instance void  set_PlotVals(object 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "PlotVals"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_PlotVals(object)
    IL_0020:  ret
  } // end of method AxPfsplot::set_PlotVals

  .method public hidebysig newslot specialname virtual 
          instance bool  get_EditProfileVariables() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "EditProfileVariables"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_EditProfileVariables()
    IL_001f:  ret
  } // end of method AxPfsplot::get_EditProfileVariables

  .method public hidebysig newslot specialname virtual 
          instance void  set_EditProfileVariables(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "EditProfileVariables"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_EditProfileVariables(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_EditProfileVariables

  .method public hidebysig newslot specialname virtual 
          instance bool  get_EditProfileTable() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "EditProfileTable"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_EditProfileTable()
    IL_001f:  ret
  } // end of method AxPfsplot::get_EditProfileTable

  .method public hidebysig newslot specialname virtual 
          instance void  set_EditProfileTable(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "EditProfileTable"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_EditProfileTable(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_EditProfileTable

  .method public hidebysig newslot specialname virtual 
          instance bool  get_AlwaysShowFull() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AlwaysShowFull"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_AlwaysShowFull()
    IL_001f:  ret
  } // end of method AxPfsplot::get_AlwaysShowFull

  .method public hidebysig newslot specialname virtual 
          instance void  set_AlwaysShowFull(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AlwaysShowFull"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_AlwaysShowFull(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_AlwaysShowFull

  .method public hidebysig newslot specialname virtual 
          instance int16  get_ClientType() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ClientType"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::get_ClientType()
    IL_001f:  ret
  } // end of method AxPfsplot::get_ClientType

  .method public hidebysig newslot specialname virtual 
          instance void  set_ClientType(int16 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ClientType"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_ClientType(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::set_ClientType

  .method public hidebysig newslot specialname virtual 
          instance bool  get_ShowTitle() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ShowTitle"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_ShowTitle()
    IL_001f:  ret
  } // end of method AxPfsplot::get_ShowTitle

  .method public hidebysig newslot specialname virtual 
          instance void  set_ShowTitle(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ShowTitle"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_ShowTitle(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_ShowTitle

  .method public hidebysig newslot specialname virtual 
          instance bool  get_ShowXaxisLabel() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ShowXaxisLabel"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_ShowXaxisLabel()
    IL_001f:  ret
  } // end of method AxPfsplot::get_ShowXaxisLabel

  .method public hidebysig newslot specialname virtual 
          instance void  set_ShowXaxisLabel(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ShowXaxisLabel"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_ShowXaxisLabel(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_ShowXaxisLabel

  .method public hidebysig newslot specialname virtual 
          instance bool  get_CanLivePlot() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CanLivePlot"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_CanLivePlot()
    IL_001f:  ret
  } // end of method AxPfsplot::get_CanLivePlot

  .method public hidebysig newslot specialname virtual 
          instance void  set_CanLivePlot(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CanLivePlot"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_CanLivePlot(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_CanLivePlot

  .method public hidebysig newslot specialname virtual 
          instance bool  get_LivePlot() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "LivePlot"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_LivePlot()
    IL_001f:  ret
  } // end of method AxPfsplot::get_LivePlot

  .method public hidebysig newslot specialname virtual 
          instance void  set_LivePlot(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "LivePlot"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_LivePlot(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_LivePlot

  .method public hidebysig newslot specialname virtual 
          instance bool  get_ShowTracker() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ShowTracker"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::get_ShowTracker()
    IL_001f:  ret
  } // end of method AxPfsplot::get_ShowTracker

  .method public hidebysig newslot specialname virtual 
          instance void  set_ShowTracker(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ShowTracker"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_ShowTracker(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::set_ShowTracker

  .method public hidebysig newslot specialname virtual 
          instance float64  get_ZoomLevel() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ZoomLevel"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance float64 [PFSPlotLib]PFSPlotLib._DPfsplot::get_ZoomLevel()
    IL_001f:  ret
  } // end of method AxPfsplot::get_ZoomLevel

  .method public hidebysig newslot specialname virtual 
          instance void  set_ZoomLevel(float64 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ZoomLevel"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::set_ZoomLevel(float64)
    IL_0020:  ret
  } // end of method AxPfsplot::set_ZoomLevel

  .method public hidebysig specialname instance void 
          add_Selected(class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler AxPFSPlotLib.AxPfsplot::Selected
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler AxPFSPlotLib.AxPfsplot::Selected
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler>(!!0&,
                                                                                                                                              !!0,
                                                                                                                                              !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_Selected

  .method public hidebysig specialname instance void 
          remove_Selected(class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler AxPFSPlotLib.AxPfsplot::Selected
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler AxPFSPlotLib.AxPfsplot::Selected
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler>(!!0&,
                                                                                                                                              !!0,
                                                                                                                                              !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_Selected

  .method public hidebysig specialname instance void 
          add_Zoomed(class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler AxPFSPlotLib.AxPfsplot::Zoomed
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler AxPFSPlotLib.AxPfsplot::Zoomed
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler>(!!0&,
                                                                                                                                            !!0,
                                                                                                                                            !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_Zoomed

  .method public hidebysig specialname instance void 
          remove_Zoomed(class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler AxPFSPlotLib.AxPfsplot::Zoomed
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler AxPFSPlotLib.AxPfsplot::Zoomed
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler>(!!0&,
                                                                                                                                            !!0,
                                                                                                                                            !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_Zoomed

  .method public hidebysig specialname instance void 
          add_VariableChanged(class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler AxPFSPlotLib.AxPfsplot::VariableChanged
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler AxPFSPlotLib.AxPfsplot::VariableChanged
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler>(!!0&,
                                                                                                                                                     !!0,
                                                                                                                                                     !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_VariableChanged

  .method public hidebysig specialname instance void 
          remove_VariableChanged(class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler AxPFSPlotLib.AxPfsplot::VariableChanged
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler AxPFSPlotLib.AxPfsplot::VariableChanged
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler>(!!0&,
                                                                                                                                                     !!0,
                                                                                                                                                     !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_VariableChanged

  .method public hidebysig specialname instance void 
          add_ApplyVariableChanges(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ApplyVariableChanges
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ApplyVariableChanges
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_ApplyVariableChanges

  .method public hidebysig specialname instance void 
          remove_ApplyVariableChanges(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ApplyVariableChanges
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ApplyVariableChanges
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_ApplyVariableChanges

  .method public hidebysig specialname instance void 
          add_OnDropText(class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler AxPFSPlotLib.AxPfsplot::OnDropText
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler AxPFSPlotLib.AxPfsplot::OnDropText
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler>(!!0&,
                                                                                                                                                !!0,
                                                                                                                                                !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_OnDropText

  .method public hidebysig specialname instance void 
          remove_OnDropText(class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler AxPFSPlotLib.AxPfsplot::OnDropText
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler AxPFSPlotLib.AxPfsplot::OnDropText
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler>(!!0&,
                                                                                                                                                !!0,
                                                                                                                                                !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_OnDropText

  .method public hidebysig specialname instance void 
          add_ReloadNow(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ReloadNow
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ReloadNow
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_ReloadNow

  .method public hidebysig specialname instance void 
          remove_ReloadNow(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ReloadNow
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ReloadNow
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_ReloadNow

  .method public hidebysig specialname instance void 
          add_OnEditProfileVariables(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileVariables
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileVariables
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_OnEditProfileVariables

  .method public hidebysig specialname instance void 
          remove_OnEditProfileVariables(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileVariables
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileVariables
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_OnEditProfileVariables

  .method public hidebysig specialname instance void 
          add_OnOnShowasHistory(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnOnShowasHistory
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnOnShowasHistory
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_OnOnShowasHistory

  .method public hidebysig specialname instance void 
          remove_OnOnShowasHistory(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnOnShowasHistory
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnOnShowasHistory
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_OnOnShowasHistory

  .method public hidebysig specialname instance void 
          add_OnEditProfileTable(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileTable
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileTable
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_OnEditProfileTable

  .method public hidebysig specialname instance void 
          remove_OnEditProfileTable(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileTable
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileTable
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_OnEditProfileTable

  .method public hidebysig specialname instance void 
          add_OnResetFormDefinition(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnResetFormDefinition
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnResetFormDefinition
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_OnResetFormDefinition

  .method public hidebysig specialname instance void 
          remove_OnResetFormDefinition(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnResetFormDefinition
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnResetFormDefinition
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_OnResetFormDefinition

  .method public hidebysig specialname instance void 
          add_SetMessageText(class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler AxPFSPlotLib.AxPfsplot::SetMessageText
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler AxPFSPlotLib.AxPfsplot::SetMessageText
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler>(!!0&,
                                                                                                                                                    !!0,
                                                                                                                                                    !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_SetMessageText

  .method public hidebysig specialname instance void 
          remove_SetMessageText(class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler AxPFSPlotLib.AxPfsplot::SetMessageText
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler AxPFSPlotLib.AxPfsplot::SetMessageText
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler>(!!0&,
                                                                                                                                                    !!0,
                                                                                                                                                    !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_SetMessageText

  .method public hidebysig specialname instance void 
          add_CommunicationIntervalsSet(class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler AxPFSPlotLib.AxPfsplot::CommunicationIntervalsSet
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler AxPFSPlotLib.AxPfsplot::CommunicationIntervalsSet
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler>(!!0&,
                                                                                                                                                               !!0,
                                                                                                                                                               !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_CommunicationIntervalsSet

  .method public hidebysig specialname instance void 
          remove_CommunicationIntervalsSet(class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler AxPFSPlotLib.AxPfsplot::CommunicationIntervalsSet
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler AxPFSPlotLib.AxPfsplot::CommunicationIntervalsSet
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler>(!!0&,
                                                                                                                                                               !!0,
                                                                                                                                                               !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_CommunicationIntervalsSet

  .method public hidebysig specialname instance void 
          add_PointerLocation(class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler AxPFSPlotLib.AxPfsplot::PointerLocation
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler AxPFSPlotLib.AxPfsplot::PointerLocation
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler>(!!0&,
                                                                                                                                                     !!0,
                                                                                                                                                     !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_PointerLocation

  .method public hidebysig specialname instance void 
          remove_PointerLocation(class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler AxPFSPlotLib.AxPfsplot::PointerLocation
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler AxPFSPlotLib.AxPfsplot::PointerLocation
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler>(!!0&,
                                                                                                                                                     !!0,
                                                                                                                                                     !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_PointerLocation

  .method public hidebysig specialname instance void 
          add_OnClick(class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler AxPFSPlotLib.AxPfsplot::OnClick
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler AxPFSPlotLib.AxPfsplot::OnClick
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler>(!!0&,
                                                                                                                                             !!0,
                                                                                                                                             !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_OnClick

  .method public hidebysig specialname instance void 
          remove_OnClick(class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler AxPFSPlotLib.AxPfsplot::OnClick
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler AxPFSPlotLib.AxPfsplot::OnClick
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler>(!!0&,
                                                                                                                                             !!0,
                                                                                                                                             !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_OnClick

  .method public hidebysig specialname instance void 
          add_OnDoubleClick(class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler AxPFSPlotLib.AxPfsplot::OnDoubleClick
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler AxPFSPlotLib.AxPfsplot::OnDoubleClick
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler>(!!0&,
                                                                                                                                                   !!0,
                                                                                                                                                   !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_OnDoubleClick

  .method public hidebysig specialname instance void 
          remove_OnDoubleClick(class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler AxPFSPlotLib.AxPfsplot::OnDoubleClick
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler AxPFSPlotLib.AxPfsplot::OnDoubleClick
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler>(!!0&,
                                                                                                                                                   !!0,
                                                                                                                                                   !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_OnDoubleClick

  .method public hidebysig specialname instance void 
          add_CursorSet(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::CursorSet
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::CursorSet
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_CursorSet

  .method public hidebysig specialname instance void 
          remove_CursorSet(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::CursorSet
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::CursorSet
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_CursorSet

  .method public hidebysig specialname instance void 
          add_OnRBClick(class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler AxPFSPlotLib.AxPfsplot::OnRBClick
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler AxPFSPlotLib.AxPfsplot::OnRBClick
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler>(!!0&,
                                                                                                                                               !!0,
                                                                                                                                               !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_OnRBClick

  .method public hidebysig specialname instance void 
          remove_OnRBClick(class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler AxPFSPlotLib.AxPfsplot::OnRBClick
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler AxPFSPlotLib.AxPfsplot::OnRBClick
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler>(!!0&,
                                                                                                                                               !!0,
                                                                                                                                               !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_OnRBClick

  .method public hidebysig specialname instance void 
          add_RegionDefined(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RegionDefined
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RegionDefined
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_RegionDefined

  .method public hidebysig specialname instance void 
          remove_RegionDefined(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RegionDefined
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RegionDefined
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_RegionDefined

  .method public hidebysig specialname instance void 
          add_KeyPressEvent(class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler AxPFSPlotLib.AxPfsplot::KeyPressEvent
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler AxPFSPlotLib.AxPfsplot::KeyPressEvent
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler>(!!0&,
                                                                                                                                              !!0,
                                                                                                                                              !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_KeyPressEvent

  .method public hidebysig specialname instance void 
          remove_KeyPressEvent(class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler AxPFSPlotLib.AxPfsplot::KeyPressEvent
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler AxPFSPlotLib.AxPfsplot::KeyPressEvent
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler>(!!0&,
                                                                                                                                              !!0,
                                                                                                                                              !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_KeyPressEvent

  .method public hidebysig specialname instance void 
          add_KeyDownEvent(class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler AxPFSPlotLib.AxPfsplot::KeyDownEvent
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler AxPFSPlotLib.AxPfsplot::KeyDownEvent
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler>(!!0&,
                                                                                                                                             !!0,
                                                                                                                                             !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_KeyDownEvent

  .method public hidebysig specialname instance void 
          remove_KeyDownEvent(class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler AxPFSPlotLib.AxPfsplot::KeyDownEvent
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler AxPFSPlotLib.AxPfsplot::KeyDownEvent
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler>(!!0&,
                                                                                                                                             !!0,
                                                                                                                                             !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_KeyDownEvent

  .method public hidebysig specialname instance void 
          add_KeyUpEvent(class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler AxPFSPlotLib.AxPfsplot::KeyUpEvent
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler AxPFSPlotLib.AxPfsplot::KeyUpEvent
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler>(!!0&,
                                                                                                                                           !!0,
                                                                                                                                           !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_KeyUpEvent

  .method public hidebysig specialname instance void 
          remove_KeyUpEvent(class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler AxPFSPlotLib.AxPfsplot::KeyUpEvent
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler AxPFSPlotLib.AxPfsplot::KeyUpEvent
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler>(!!0&,
                                                                                                                                           !!0,
                                                                                                                                           !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_KeyUpEvent

  .method public hidebysig specialname instance void 
          add_Scrolled(class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler AxPFSPlotLib.AxPfsplot::Scrolled
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler AxPFSPlotLib.AxPfsplot::Scrolled
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler>(!!0&,
                                                                                                                                              !!0,
                                                                                                                                              !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_Scrolled

  .method public hidebysig specialname instance void 
          remove_Scrolled(class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler AxPFSPlotLib.AxPfsplot::Scrolled
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler AxPFSPlotLib.AxPfsplot::Scrolled
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler>(!!0&,
                                                                                                                                              !!0,
                                                                                                                                              !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_Scrolled

  .method public hidebysig specialname instance void 
          add_PointerExit(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::PointerExit
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::PointerExit
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_PointerExit

  .method public hidebysig specialname instance void 
          remove_PointerExit(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::PointerExit
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::PointerExit
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_PointerExit

  .method public hidebysig specialname instance void 
          add_PhaseVariableSet(class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableSet
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableSet
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler>(!!0&,
                                                                                                                                                      !!0,
                                                                                                                                                      !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_PhaseVariableSet

  .method public hidebysig specialname instance void 
          remove_PhaseVariableSet(class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableSet
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableSet
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler>(!!0&,
                                                                                                                                                      !!0,
                                                                                                                                                      !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_PhaseVariableSet

  .method public hidebysig specialname instance void 
          add_PhaseVariableDropped(class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableDropped
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableDropped
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler>(!!0&,
                                                                                                                                                          !!0,
                                                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_PhaseVariableDropped

  .method public hidebysig specialname instance void 
          remove_PhaseVariableDropped(class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableDropped
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableDropped
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler>(!!0&,
                                                                                                                                                          !!0,
                                                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_PhaseVariableDropped

  .method public hidebysig specialname instance void 
          add_ZoomTimeRange(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ZoomTimeRange
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ZoomTimeRange
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_ZoomTimeRange

  .method public hidebysig specialname instance void 
          remove_ZoomTimeRange(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ZoomTimeRange
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ZoomTimeRange
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_ZoomTimeRange

  .method public hidebysig specialname instance void 
          add_RevertToTimePlot(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RevertToTimePlot
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RevertToTimePlot
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_RevertToTimePlot

  .method public hidebysig specialname instance void 
          remove_RevertToTimePlot(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RevertToTimePlot
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RevertToTimePlot
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_RevertToTimePlot

  .method public hidebysig specialname instance void 
          add_OnLivePlot(class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler AxPFSPlotLib.AxPfsplot::OnLivePlot
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler AxPFSPlotLib.AxPfsplot::OnLivePlot
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler>(!!0&,
                                                                                                                                                !!0,
                                                                                                                                                !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_OnLivePlot

  .method public hidebysig specialname instance void 
          remove_OnLivePlot(class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler AxPFSPlotLib.AxPfsplot::OnLivePlot
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler AxPFSPlotLib.AxPfsplot::OnLivePlot
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler>(!!0&,
                                                                                                                                                !!0,
                                                                                                                                                !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_OnLivePlot

  .method public hidebysig specialname instance void 
          add_SetCaption(class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler AxPFSPlotLib.AxPfsplot::SetCaption
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler AxPFSPlotLib.AxPfsplot::SetCaption
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler>(!!0&,
                                                                                                                                                !!0,
                                                                                                                                                !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_SetCaption

  .method public hidebysig specialname instance void 
          remove_SetCaption(class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler AxPFSPlotLib.AxPfsplot::SetCaption
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler AxPFSPlotLib.AxPfsplot::SetCaption
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler>(!!0&,
                                                                                                                                                !!0,
                                                                                                                                                !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_SetCaption

  .method public hidebysig specialname instance void 
          add_Modified(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::Modified
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::Modified
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_Modified

  .method public hidebysig specialname instance void 
          remove_Modified(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::Modified
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::Modified
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_Modified

  .method public hidebysig specialname instance void 
          add_PlotDrawn(class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler AxPFSPlotLib.AxPfsplot::PlotDrawn
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler AxPFSPlotLib.AxPfsplot::PlotDrawn
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler>(!!0&,
                                                                                                                                               !!0,
                                                                                                                                               !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_PlotDrawn

  .method public hidebysig specialname instance void 
          remove_PlotDrawn(class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler AxPFSPlotLib.AxPfsplot::PlotDrawn
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler AxPFSPlotLib.AxPfsplot::PlotDrawn
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler>(!!0&,
                                                                                                                                               !!0,
                                                                                                                                               !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_PlotDrawn

  .method public hidebysig specialname instance void 
          add_ZoomDone(class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler AxPFSPlotLib.AxPfsplot::ZoomDone
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler AxPFSPlotLib.AxPfsplot::ZoomDone
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler>(!!0&,
                                                                                                                                              !!0,
                                                                                                                                              !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_ZoomDone

  .method public hidebysig specialname instance void 
          remove_ZoomDone(class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler AxPFSPlotLib.AxPfsplot::ZoomDone
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler AxPFSPlotLib.AxPfsplot::ZoomDone
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler>(!!0&,
                                                                                                                                              !!0,
                                                                                                                                              !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_ZoomDone

  .method public hidebysig specialname instance void 
          add_OnDropFiles(class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler AxPFSPlotLib.AxPfsplot::OnDropFiles
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler AxPFSPlotLib.AxPfsplot::OnDropFiles
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler>(!!0&,
                                                                                                                                                 !!0,
                                                                                                                                                 !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_OnDropFiles

  .method public hidebysig specialname instance void 
          remove_OnDropFiles(class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler AxPFSPlotLib.AxPfsplot::OnDropFiles
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler AxPFSPlotLib.AxPfsplot::OnDropFiles
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler>(!!0&,
                                                                                                                                                 !!0,
                                                                                                                                                 !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_OnDropFiles

  .method public hidebysig specialname instance void 
          add_FlippedFlagChanged(class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler AxPFSPlotLib.AxPfsplot::FlippedFlagChanged
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler AxPFSPlotLib.AxPfsplot::FlippedFlagChanged
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler>(!!0&,
                                                                                                                                                        !!0,
                                                                                                                                                        !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::add_FlippedFlagChanged

  .method public hidebysig specialname instance void 
          remove_FlippedFlagChanged(class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler V_0,
             class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler V_1,
             class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler AxPFSPlotLib.AxPfsplot::FlippedFlagChanged
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler AxPFSPlotLib.AxPfsplot::FlippedFlagChanged
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler>(!!0&,
                                                                                                                                                        !!0,
                                                                                                                                                        !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxPfsplot::remove_FlippedFlagChanged

  .method public hidebysig newslot virtual 
          instance void  Paste() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Paste"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::Paste()
    IL_001f:  ret
  } // end of method AxPfsplot::Paste

  .method public hidebysig newslot virtual 
          instance void  SetMultiplier(int16 axisNo,
                                       int16 multiplier) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetMultiplier"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetMultiplier(int16,
                                                                                       int16)
    IL_0021:  ret
  } // end of method AxPfsplot::SetMultiplier

  .method public hidebysig newslot virtual 
          instance int16  GetMultiplier(int16 axisNo) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetMultiplier"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetMultiplier(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetMultiplier

  .method public hidebysig newslot virtual 
          instance void  ModifyText(string oldText,
                                    string newText) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ModifyText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::ModifyText(string,
                                                                                    string)
    IL_0021:  ret
  } // end of method AxPfsplot::ModifyText

  .method public hidebysig newslot virtual 
          instance bool  GetData(int16 varNo,
                                 int16 dataNo,
                                 float64& 'value') cil managed
  {
    // Code size       37 (0x25)
    .maxstack  4
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::GetData(int16,
                                                                                 int16,
                                                                                 float64&)
    IL_0022:  stloc.0
    IL_0023:  ldloc.0
    IL_0024:  ret
  } // end of method AxPfsplot::GetData

  .method public hidebysig newslot virtual 
          instance bool  GetXData(int16 varNo,
                                  int16 dataNo,
                                  float64& 'value') cil managed
  {
    // Code size       37 (0x25)
    .maxstack  4
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetXData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::GetXData(int16,
                                                                                  int16,
                                                                                  float64&)
    IL_0022:  stloc.0
    IL_0023:  ldloc.0
    IL_0024:  ret
  } // end of method AxPfsplot::GetXData

  .method public hidebysig newslot virtual 
          instance void  SetLegendBox(int16 location,
                                      int16 width,
                                      float32 itemheight,
                                      int16 margin) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetLegendBox"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    margin
    IL_001f:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetLegendBox(int16,
                                                                                      int16,
                                                                                      float32,
                                                                                      int16)
    IL_0024:  ret
  } // end of method AxPfsplot::SetLegendBox

  .method public hidebysig newslot virtual 
          instance void  SetSubstitutionString(string 'string') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSubstitutionString"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetSubstitutionString(string)
    IL_0020:  ret
  } // end of method AxPfsplot::SetSubstitutionString

  .method public hidebysig newslot virtual 
          instance void  SetSubstitutionValue(int16 varNo,
                                              string 'string') cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSubstitutionValue"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetSubstitutionValue(int16,
                                                                                              string)
    IL_0021:  ret
  } // end of method AxPfsplot::SetSubstitutionValue

  .method public hidebysig newslot virtual 
          instance int16  GetMultiplierType(int16 axisNo) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetMultiplierType"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetMultiplierType(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetMultiplierType

  .method public hidebysig newslot virtual 
          instance void  SetMultiplierType(int16 axisNo,
                                           int16 multiplierType) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetMultiplierType"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetMultiplierType(int16,
                                                                                           int16)
    IL_0021:  ret
  } // end of method AxPfsplot::SetMultiplierType

  .method public hidebysig newslot virtual 
          instance void  DeleteVariable(int16 varNo) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "DeleteVariable"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::DeleteVariable(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::DeleteVariable

  .method public hidebysig newslot virtual 
          instance void  MoveVariable(int16 sourceVarNo,
                                      int16 targetVarNo) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "MoveVariable"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::MoveVariable(int16,
                                                                                      int16)
    IL_0021:  ret
  } // end of method AxPfsplot::MoveVariable

  .method public hidebysig newslot virtual 
          instance void  SetAxisMode(int16 axisNo,
                                     int16 index,
                                     int16 mode) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetAxisMode"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetAxisMode(int16,
                                                                                     int16,
                                                                                     int16)
    IL_0022:  ret
  } // end of method AxPfsplot::SetAxisMode

  .method public hidebysig newslot virtual 
          instance void  GetAxisMode(int16 axisNo,
                                     int16 index,
                                     int16& mode) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetAxisMode"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetAxisMode(int16,
                                                                                     int16,
                                                                                     int16&)
    IL_0022:  ret
  } // end of method AxPfsplot::GetAxisMode

  .method public hidebysig newslot virtual 
          instance void  EnableResetFromDefinition(bool enable) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "EnableResetFromDefinition"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::EnableResetFromDefinition(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::EnableResetFromDefinition

  .method public hidebysig newslot virtual 
          instance void  SetXYData(int16 objectID,
                                   int16 dataNo,
                                   float64 x,
                                   float64 y) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetXYData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    y
    IL_001f:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetXYData(int16,
                                                                                   int16,
                                                                                   float64,
                                                                                   float64)
    IL_0024:  ret
  } // end of method AxPfsplot::SetXYData

  .method public hidebysig newslot virtual 
          instance int16  NewLine(int16 color,
                                  int16 linetype,
                                  int16 marker,
                                  int16 markerSize,
                                  int16 direction) cil managed
  {
    // Code size       41 (0x29)
    .maxstack  6
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "NewLine"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    markerSize
    IL_001f:  ldarg.s    direction
    IL_0021:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::NewLine(int16,
                                                                                  int16,
                                                                                  int16,
                                                                                  int16,
                                                                                  int16)
    IL_0026:  stloc.0
    IL_0027:  ldloc.0
    IL_0028:  ret
  } // end of method AxPfsplot::NewLine

  .method public hidebysig newslot virtual 
          instance int16  NewPolygon(int16 color,
                                     int16 fillmode) cil managed
  {
    // Code size       36 (0x24)
    .maxstack  3
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "NewPolygon"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::NewPolygon(int16,
                                                                                     int16)
    IL_0021:  stloc.0
    IL_0022:  ldloc.0
    IL_0023:  ret
  } // end of method AxPfsplot::NewPolygon

  .method public hidebysig newslot virtual 
          instance int16  newText(string text,
                                  float64 x,
                                  float64 y,
                                  int16 attached) cil managed
  {
    // Code size       39 (0x27)
    .maxstack  5
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "newText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    attached
    IL_001f:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::newText(string,
                                                                                  float64,
                                                                                  float64,
                                                                                  int16)
    IL_0024:  stloc.0
    IL_0025:  ldloc.0
    IL_0026:  ret
  } // end of method AxPfsplot::newText

  .method public hidebysig newslot virtual 
          instance void  SetTextAttribute(int16 objectID,
                                          int16 color,
                                          int16 'alignment',
                                          int16 angle,
                                          string fontname,
                                          int16 size,
                                          int16 style) cil managed
  {
    // Code size       43 (0x2b)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetTextAttribute"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    angle
    IL_001f:  ldarg.s    fontname
    IL_0021:  ldarg.s    size
    IL_0023:  ldarg.s    style
    IL_0025:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetTextAttribute(int16,
                                                                                          int16,
                                                                                          int16,
                                                                                          int16,
                                                                                          string,
                                                                                          int16,
                                                                                          int16)
    IL_002a:  ret
  } // end of method AxPfsplot::SetTextAttribute

  .method public hidebysig newslot virtual 
          instance int16  SetObject(int16 objectID,
                                    int16 'value',
                                    int16 mask) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  4
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetObject"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::SetObject(int16,
                                                                                    int16,
                                                                                    int16)
    IL_0022:  stloc.0
    IL_0023:  ldloc.0
    IL_0024:  ret
  } // end of method AxPfsplot::SetObject

  .method public hidebysig newslot virtual 
          instance void  SetLineAttribute(int16 objectID,
                                          int16 color,
                                          int16 linetype,
                                          int16 marker,
                                          int16 markerSize,
                                          int16 direction,
                                          int16 mask) cil managed
  {
    // Code size       43 (0x2b)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetLineAttribute"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    marker
    IL_001f:  ldarg.s    markerSize
    IL_0021:  ldarg.s    direction
    IL_0023:  ldarg.s    mask
    IL_0025:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetLineAttribute(int16,
                                                                                          int16,
                                                                                          int16,
                                                                                          int16,
                                                                                          int16,
                                                                                          int16,
                                                                                          int16)
    IL_002a:  ret
  } // end of method AxPfsplot::SetLineAttribute

  .method public hidebysig newslot virtual 
          instance void  DoDoubleClick(int16 x,
                                       int16 y) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "DoDoubleClick"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::DoDoubleClick(int16,
                                                                                       int16)
    IL_0021:  ret
  } // end of method AxPfsplot::DoDoubleClick

  .method public hidebysig newslot virtual 
          instance void  DisplayText(string szText,
                                     int16 x,
                                     int16 y,
                                     int32 millisecs) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "DisplayText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    millisecs
    IL_001f:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::DisplayText(string,
                                                                                     int16,
                                                                                     int16,
                                                                                     int32)
    IL_0024:  ret
  } // end of method AxPfsplot::DisplayText

  .method public hidebysig newslot virtual 
          instance void  SetEvent(int16 eventID,
                                  bool onOff,
                                  bool 'default') cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetEvent"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetEvent(int16,
                                                                                  bool,
                                                                                  bool)
    IL_0022:  ret
  } // end of method AxPfsplot::SetEvent

  .method public hidebysig newslot virtual 
          instance void  ManageCursor(bool onOff) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ManageCursor"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::ManageCursor(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::ManageCursor

  .method public hidebysig newslot virtual 
          instance void  InvokeMenuItem(int32 iD) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "InvokeMenuItem"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::InvokeMenuItem(int32)
    IL_0020:  ret
  } // end of method AxPfsplot::InvokeMenuItem

  .method public hidebysig newslot virtual 
          instance string  GetMenuItem(int16& code,
                                       int16& iD) cil managed
  {
    // Code size       36 (0x24)
    .maxstack  3
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetMenuItem"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetMenuItem(int16&,
                                                                                       int16&)
    IL_0021:  stloc.0
    IL_0022:  ldloc.0
    IL_0023:  ret
  } // end of method AxPfsplot::GetMenuItem

  .method public hidebysig newslot virtual 
          instance void  UpdateMenu() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "UpdateMenu"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::UpdateMenu()
    IL_001f:  ret
  } // end of method AxPfsplot::UpdateMenu

  .method public hidebysig newslot virtual 
          instance bool  IsMenuItemEnabled(int16 iD) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IsMenuItemEnabled"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::IsMenuItemEnabled(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::IsMenuItemEnabled

  .method public hidebysig newslot virtual 
          instance void  DragLine(int16 x1,
                                  int16 y1,
                                  int16 x2,
                                  int16 y2,
                                  int16 color) cil managed
  {
    // Code size       39 (0x27)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "DragLine"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    y2
    IL_001f:  ldarg.s    color
    IL_0021:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::DragLine(int16,
                                                                                  int16,
                                                                                  int16,
                                                                                  int16,
                                                                                  int16)
    IL_0026:  ret
  } // end of method AxPfsplot::DragLine

  .method public hidebysig newslot virtual 
          instance void  UpdateAxis() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "UpdateAxis"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::UpdateAxis()
    IL_001f:  ret
  } // end of method AxPfsplot::UpdateAxis

  .method public hidebysig newslot virtual 
          instance void  Clear() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Clear"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::Clear()
    IL_001f:  ret
  } // end of method AxPfsplot::Clear

  .method public hidebysig newslot virtual 
          instance void  Zoom(int16 mode) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Zoom"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::Zoom(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::Zoom

  .method public hidebysig newslot virtual 
          instance bool  IsRegionDefined() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IsRegionDefined"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::IsRegionDefined()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::IsRegionDefined

  .method public hidebysig newslot virtual 
          instance bool  GetPointerLocation(int16& ix,
                                            int16& iy) cil managed
  {
    // Code size       36 (0x24)
    .maxstack  3
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetPointerLocation"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::GetPointerLocation(int16&,
                                                                                            int16&)
    IL_0021:  stloc.0
    IL_0022:  ldloc.0
    IL_0023:  ret
  } // end of method AxPfsplot::GetPointerLocation

  .method public hidebysig newslot virtual 
          instance void  SetSymbol(string symbolName,
                                   string 'value') cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSymbol"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetSymbol(string,
                                                                                   string)
    IL_0021:  ret
  } // end of method AxPfsplot::SetSymbol

  .method public hidebysig newslot virtual 
          instance bool  ConvertToDevice(float64 x,
                                         float64 y,
                                         int16& ix,
                                         int16& iy) cil managed
  {
    // Code size       39 (0x27)
    .maxstack  5
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ConvertToDevice"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    iy
    IL_001f:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::ConvertToDevice(float64,
                                                                                         float64,
                                                                                         int16&,
                                                                                         int16&)
    IL_0024:  stloc.0
    IL_0025:  ldloc.0
    IL_0026:  ret
  } // end of method AxPfsplot::ConvertToDevice

  .method public hidebysig newslot virtual 
          instance bool  ConvertToPlot(int16 ix,
                                       int16 iy,
                                       float64& x,
                                       float64& y) cil managed
  {
    // Code size       39 (0x27)
    .maxstack  5
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ConvertToPlot"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    y
    IL_001f:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::ConvertToPlot(int16,
                                                                                       int16,
                                                                                       float64&,
                                                                                       float64&)
    IL_0024:  stloc.0
    IL_0025:  ldloc.0
    IL_0026:  ret
  } // end of method AxPfsplot::ConvertToPlot

  .method public hidebysig newslot virtual 
          instance void  SetCopyMode(int16 mode) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetCopyMode"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetCopyMode(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::SetCopyMode

  .method public hidebysig newslot virtual 
          instance void  SetTextMode(int16 mode) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetTextMode"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetTextMode(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::SetTextMode

  .method public hidebysig newslot virtual 
          instance void  SetHighlightMode(int16 mode) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetHighlightMode"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetHighlightMode(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::SetHighlightMode

  .method public hidebysig newslot virtual 
          instance void  SetMousePointer(int16 'type') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetMousePointer"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetMousePointer(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::SetMousePointer

  .method public hidebysig newslot virtual 
          instance void  CopyWithSize(int16 width,
                                      int16 height) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CopyWithSize"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::CopyWithSize(int16,
                                                                                      int16)
    IL_0021:  ret
  } // end of method AxPfsplot::CopyWithSize

  .method public hidebysig newslot virtual 
          instance bool  GetXYData(int16 objectID,
                                   int16 dataNo,
                                   float64& x,
                                   float64& y) cil managed
  {
    // Code size       39 (0x27)
    .maxstack  5
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetXYData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    y
    IL_001f:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::GetXYData(int16,
                                                                                   int16,
                                                                                   float64&,
                                                                                   float64&)
    IL_0024:  stloc.0
    IL_0025:  ldloc.0
    IL_0026:  ret
  } // end of method AxPfsplot::GetXYData

  .method public hidebysig newslot virtual 
          instance void  ChangeText(int16 objectID,
                                    string text,
                                    float64 x,
                                    float64 y,
                                    int16 attached) cil managed
  {
    // Code size       39 (0x27)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ChangeText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    y
    IL_001f:  ldarg.s    attached
    IL_0021:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::ChangeText(int16,
                                                                                    string,
                                                                                    float64,
                                                                                    float64,
                                                                                    int16)
    IL_0026:  ret
  } // end of method AxPfsplot::ChangeText

  .method public hidebysig newslot virtual 
          instance void  Print2(bool setupOnly) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Print2"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::Print2(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::Print2

  .method public hidebysig newslot virtual 
          instance void  PrintPreview(bool oN) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "PrintPreview"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::PrintPreview(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::PrintPreview

  .method public hidebysig newslot virtual 
          instance void  OpenLog(string filename) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "OpenLog"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::OpenLog(string)
    IL_0020:  ret
  } // end of method AxPfsplot::OpenLog

  .method public hidebysig newslot virtual 
          instance void  CloseLog() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CloseLog"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::CloseLog()
    IL_001f:  ret
  } // end of method AxPfsplot::CloseLog

  .method public hidebysig newslot virtual 
          instance void  PageLayout() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "PageLayout"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::PageLayout()
    IL_001f:  ret
  } // end of method AxPfsplot::PageLayout

  .method public hidebysig newslot virtual 
          instance void  Rotate(int16 direction) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Rotate"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::Rotate(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::Rotate

  .method public hidebysig newslot virtual 
          instance void  SetPhasePlot(bool bSet) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetPhasePlot"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetPhasePlot(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::SetPhasePlot

  .method public hidebysig newslot virtual 
          instance bool  GetPhasePlot() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetPhasePlot"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::GetPhasePlot()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::GetPhasePlot

  .method public hidebysig newslot virtual 
          instance int32  AddPhaseData(float32 x_data,
                                       float32& py_data) cil managed
  {
    // Code size       36 (0x24)
    .maxstack  3
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AddPhaseData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance int32 [PFSPlotLib]PFSPlotLib._DPfsplot::AddPhaseData(float32,
                                                                                       float32&)
    IL_0021:  stloc.0
    IL_0022:  ldloc.0
    IL_0023:  ret
  } // end of method AxPfsplot::AddPhaseData

  .method public hidebysig newslot virtual 
          instance string  GetPhaseXVariable() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetPhaseXVariable"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetPhaseXVariable()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::GetPhaseXVariable

  .method public hidebysig newslot virtual 
          instance void  SetPhaseXVariable(string sVarName) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetPhaseXVariable"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetPhaseXVariable(string)
    IL_0020:  ret
  } // end of method AxPfsplot::SetPhaseXVariable

  .method public hidebysig newslot virtual 
          instance void  FirePhasePlot(string sVarName) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "FirePhasePlot"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::FirePhasePlot(string)
    IL_0020:  ret
  } // end of method AxPfsplot::FirePhasePlot

  .method public hidebysig newslot virtual 
          instance int16  GetScale(int16 varNo) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetScale"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetScale(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetScale

  .method public hidebysig newslot virtual 
          instance bool  GetAxisHighLows(int16 iAxis,
                                         float64& dVarLow,
                                         float64& dVarHigh,
                                         float64& dAxisLow,
                                         float64& dAxisHigh,
                                         float64& dLow,
                                         float64& dHigh) cil managed
  {
    // Code size       45 (0x2d)
    .maxstack  8
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetAxisHighLows"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    dAxisLow
    IL_001f:  ldarg.s    dAxisHigh
    IL_0021:  ldarg.s    dLow
    IL_0023:  ldarg.s    dHigh
    IL_0025:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::GetAxisHighLows(int16,
                                                                                         float64&,
                                                                                         float64&,
                                                                                         float64&,
                                                                                         float64&,
                                                                                         float64&,
                                                                                         float64&)
    IL_002a:  stloc.0
    IL_002b:  ldloc.0
    IL_002c:  ret
  } // end of method AxPfsplot::GetAxisHighLows

  .method public hidebysig newslot virtual 
          instance void  EnableFireEvent(bool enable) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "EnableFireEvent"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::EnableFireEvent(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::EnableFireEvent

  .method public hidebysig newslot virtual 
          instance void  AddLegendEditDialog() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AddLegendEditDialog"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::AddLegendEditDialog()
    IL_001f:  ret
  } // end of method AxPfsplot::AddLegendEditDialog

  .method public hidebysig newslot virtual 
          instance void  SetAxisScale(int16 varNo,
                                      int16 scale) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetAxisScale"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetAxisScale(int16,
                                                                                      int16)
    IL_0021:  ret
  } // end of method AxPfsplot::SetAxisScale

  .method public hidebysig newslot virtual 
          instance string  GetSelAnnoAttributes(int16& ifontsize,
                                                int16& ifontattrib,
                                                int16& ifontcolor,
                                                int16& idirecton,
                                                int16& ialignment,
                                                int16& iattachment,
                                                int16& iarrow) cil managed
  {
    // Code size       45 (0x2d)
    .maxstack  8
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSelAnnoAttributes"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    idirecton
    IL_001f:  ldarg.s    ialignment
    IL_0021:  ldarg.s    iattachment
    IL_0023:  ldarg.s    iarrow
    IL_0025:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetSelAnnoAttributes(int16&,
                                                                                                int16&,
                                                                                                int16&,
                                                                                                int16&,
                                                                                                int16&,
                                                                                                int16&,
                                                                                                int16&)
    IL_002a:  stloc.0
    IL_002b:  ldloc.0
    IL_002c:  ret
  } // end of method AxPfsplot::GetSelAnnoAttributes

  .method public hidebysig newslot virtual 
          instance void  SetSelAnnoAttributes(string sfontname,
                                              int16 ifontsize,
                                              int16 ifontattrib,
                                              int16 ifontcolor,
                                              int16 idirecton,
                                              int16 ialignment,
                                              int16 iattachment,
                                              int16 iarrow) cil managed
  {
    // Code size       45 (0x2d)
    .maxstack  9
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSelAnnoAttributes"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    ifontcolor
    IL_001f:  ldarg.s    idirecton
    IL_0021:  ldarg.s    ialignment
    IL_0023:  ldarg.s    iattachment
    IL_0025:  ldarg.s    iarrow
    IL_0027:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetSelAnnoAttributes(string,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16)
    IL_002c:  ret
  } // end of method AxPfsplot::SetSelAnnoAttributes

  .method public hidebysig newslot virtual 
          instance void  GetVarLineInfo(int16& iColor,
                                        int16& iLineWidth,
                                        int16& iLineStyle,
                                        int16& iMarker,
                                        int16& iSize,
                                        int16& iInterval) cil managed
  {
    // Code size       41 (0x29)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetVarLineInfo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    iMarker
    IL_001f:  ldarg.s    iSize
    IL_0021:  ldarg.s    iInterval
    IL_0023:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetVarLineInfo(int16&,
                                                                                        int16&,
                                                                                        int16&,
                                                                                        int16&,
                                                                                        int16&,
                                                                                        int16&)
    IL_0028:  ret
  } // end of method AxPfsplot::GetVarLineInfo

  .method public hidebysig newslot virtual 
          instance void  SetVarLineInfo(int16 iColor,
                                        int16 iLineWidth,
                                        int16 iLineStyle,
                                        int16 iMarker,
                                        int16 iSize,
                                        int16 iInterval) cil managed
  {
    // Code size       41 (0x29)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetVarLineInfo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    iMarker
    IL_001f:  ldarg.s    iSize
    IL_0021:  ldarg.s    iInterval
    IL_0023:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetVarLineInfo(int16,
                                                                                        int16,
                                                                                        int16,
                                                                                        int16,
                                                                                        int16,
                                                                                        int16)
    IL_0028:  ret
  } // end of method AxPfsplot::SetVarLineInfo

  .method public hidebysig newslot virtual 
          instance void  GetIndexSelVarLine(int16& iIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetIndexSelVarLine"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetIndexSelVarLine(int16&)
    IL_0020:  ret
  } // end of method AxPfsplot::GetIndexSelVarLine

  .method public hidebysig newslot virtual 
          instance void  HideShowVariable(int16 iIndex,
                                          int16 iHide1Show0) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "HideShowVariable"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::HideShowVariable(int16,
                                                                                          int16)
    IL_0021:  ret
  } // end of method AxPfsplot::HideShowVariable

  .method public hidebysig newslot virtual 
          instance void  GetIndexSelLabel(int16& iIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetIndexSelLabel"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetIndexSelLabel(int16&)
    IL_0020:  ret
  } // end of method AxPfsplot::GetIndexSelLabel

  .method public hidebysig newslot virtual 
          instance void  HideShowLabel(int16 iIndex,
                                       int16 iHide1Show0) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "HideShowLabel"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::HideShowLabel(int16,
                                                                                       int16)
    IL_0021:  ret
  } // end of method AxPfsplot::HideShowLabel

  .method public hidebysig newslot virtual 
          instance int16  GetSelAxisScaleReverse() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSelAxisScaleReverse"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetSelAxisScaleReverse()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::GetSelAxisScaleReverse

  .method public hidebysig newslot virtual 
          instance void  SetSelAxisScaleReverse(int16 iReverse) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSelAxisScaleReverse"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetSelAxisScaleReverse(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::SetSelAxisScaleReverse

  .method public hidebysig newslot virtual 
          instance int16  GetSelAxisScaleResetRange() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSelAxisScaleResetRange"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetSelAxisScaleResetRange()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::GetSelAxisScaleResetRange

  .method public hidebysig newslot virtual 
          instance void  SetSelAxisScaleResetRange(int16 iResetRange) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSelAxisScaleResetRange"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetSelAxisScaleResetRange(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::SetSelAxisScaleResetRange

  .method public hidebysig newslot virtual 
          instance int16  GetSelAxisScaleLockGrid() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSelAxisScaleLockGrid"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetSelAxisScaleLockGrid()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::GetSelAxisScaleLockGrid

  .method public hidebysig newslot virtual 
          instance void  SetSelAxisScaleLockGrid(int16 iLockGrid) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSelAxisScaleLockGrid"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetSelAxisScaleLockGrid(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::SetSelAxisScaleLockGrid

  .method public hidebysig newslot virtual 
          instance float64  GetSelAxisScaleInterval() cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (float64 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSelAxisScaleInterval"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance float64 [PFSPlotLib]PFSPlotLib._DPfsplot::GetSelAxisScaleInterval()
    IL_001f:  conv.r8
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetSelAxisScaleInterval

  .method public hidebysig newslot virtual 
          instance void  SetSelAxisScaleInterval(float64 dInterval) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSelAxisScaleInterval"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetSelAxisScaleInterval(float64)
    IL_0020:  ret
  } // end of method AxPfsplot::SetSelAxisScaleInterval

  .method public hidebysig newslot virtual 
          instance void  GetIndexSelAxisScaleRgn(int16& iIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetIndexSelAxisScaleRgn"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetIndexSelAxisScaleRgn(int16&)
    IL_0020:  ret
  } // end of method AxPfsplot::GetIndexSelAxisScaleRgn

  .method public hidebysig newslot virtual 
          instance string  GetVariableLineState(int16 iIndex,
                                                int16& iVisibility) cil managed
  {
    // Code size       36 (0x24)
    .maxstack  3
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetVariableLineState"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetVariableLineState(int16,
                                                                                                int16&)
    IL_0021:  stloc.0
    IL_0022:  ldloc.0
    IL_0023:  ret
  } // end of method AxPfsplot::GetVariableLineState

  .method public hidebysig newslot virtual 
          instance string  GetYaxisLabelsState(int16 iIndex,
                                               int16& iVisibility) cil managed
  {
    // Code size       36 (0x24)
    .maxstack  3
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetYaxisLabelsState"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetYaxisLabelsState(int16,
                                                                                               int16&)
    IL_0021:  stloc.0
    IL_0022:  ldloc.0
    IL_0023:  ret
  } // end of method AxPfsplot::GetYaxisLabelsState

  .method public hidebysig newslot virtual 
          instance void  AddYAxisMapDialog() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AddYAxisMapDialog"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::AddYAxisMapDialog()
    IL_001f:  ret
  } // end of method AxPfsplot::AddYAxisMapDialog

  .method public hidebysig newslot virtual 
          instance void  SetAxisRangeR(int16 axisNo,
                                       float64 lowValue,
                                       float64 highValue,
                                       int16 iRibon) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetAxisRangeR"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    iRibon
    IL_001f:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetAxisRangeR(int16,
                                                                                       float64,
                                                                                       float64,
                                                                                       int16)
    IL_0024:  ret
  } // end of method AxPfsplot::SetAxisRangeR

  .method public hidebysig newslot virtual 
          instance bool  CheckMenuItem(int32 command,
                                       int16& check) cil managed
  {
    // Code size       36 (0x24)
    .maxstack  3
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CheckMenuItem"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::CheckMenuItem(int32,
                                                                                       int16&)
    IL_0021:  stloc.0
    IL_0022:  ldloc.0
    IL_0023:  ret
  } // end of method AxPfsplot::CheckMenuItem

  .method public hidebysig newslot virtual 
          instance int16  GetLabelColorIndex() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetLabelColorIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetLabelColorIndex()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::GetLabelColorIndex

  .method public hidebysig newslot virtual 
          instance void  SetLabelColorIndex(int16 iColIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetLabelColorIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetLabelColorIndex(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::SetLabelColorIndex

  .method public hidebysig newslot virtual 
          instance int16  GetAxisColorIndex() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetAxisColorIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetAxisColorIndex()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::GetAxisColorIndex

  .method public hidebysig newslot virtual 
          instance void  SetAxisColorIndex(int16 iColIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetAxisColorIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetAxisColorIndex(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::SetAxisColorIndex

  .method public hidebysig newslot virtual 
          instance void  SetPrintSettings(int16 bLandscape,
                                          float64 leftMargin,
                                          float64 topMargin,
                                          float64 rightMargin,
                                          float64 bottomMargin) cil managed
  {
    // Code size       39 (0x27)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetPrintSettings"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    rightMargin
    IL_001f:  ldarg.s    bottomMargin
    IL_0021:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetPrintSettings(int16,
                                                                                          float64,
                                                                                          float64,
                                                                                          float64,
                                                                                          float64)
    IL_0026:  ret
  } // end of method AxPfsplot::SetPrintSettings

  .method public hidebysig newslot virtual 
          instance void  GetVarLocalAttribute(int16 lineno,
                                              int16& ilocal) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetVarLocalAttribute"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetVarLocalAttribute(int16,
                                                                                              int16&)
    IL_0021:  ret
  } // end of method AxPfsplot::GetVarLocalAttribute

  .method public hidebysig newslot virtual 
          instance void  SetVarLocalAttribute(int16 lineno,
                                              int16 ilocal) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetVarLocalAttribute"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetVarLocalAttribute(int16,
                                                                                              int16)
    IL_0021:  ret
  } // end of method AxPfsplot::SetVarLocalAttribute

  .method public hidebysig newslot virtual 
          instance bool  GetPlotIsLive() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetPlotIsLive"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance bool [PFSPlotLib]PFSPlotLib._DPfsplot::GetPlotIsLive()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::GetPlotIsLive

  .method public hidebysig newslot virtual 
          instance void  SetPlotIsLive(bool bIsLive) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetPlotIsLive"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetPlotIsLive(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::SetPlotIsLive

  .method public hidebysig newslot virtual 
          instance void  KeyDown(int32 nChar,
                                 int32 nRepCnt,
                                 int32 nFlags) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "KeyDown"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::KeyDown(int32,
                                                                                 int32,
                                                                                 int32)
    IL_0022:  ret
  } // end of method AxPfsplot::KeyDown

  .method public hidebysig newslot virtual 
          instance void  GetVarLineAttributes(int16 iVar,
                                              int16& iColor,
                                              int16& iLineWidth,
                                              int16& iLineStyle,
                                              int16& iMarker,
                                              int16& iSize,
                                              int16& iInterval) cil managed
  {
    // Code size       43 (0x2b)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetVarLineAttributes"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    iLineStyle
    IL_001f:  ldarg.s    iMarker
    IL_0021:  ldarg.s    iSize
    IL_0023:  ldarg.s    iInterval
    IL_0025:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetVarLineAttributes(int16,
                                                                                              int16&,
                                                                                              int16&,
                                                                                              int16&,
                                                                                              int16&,
                                                                                              int16&,
                                                                                              int16&)
    IL_002a:  ret
  } // end of method AxPfsplot::GetVarLineAttributes

  .method public hidebysig newslot virtual 
          instance void  SetVarLineAttributes(int16 iVar,
                                              int16 iColor,
                                              int16 iLineWidth,
                                              int16 iLineStyle,
                                              int16 iMarker,
                                              int16 iSize,
                                              int16 iInterval) cil managed
  {
    // Code size       43 (0x2b)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetVarLineAttributes"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    iLineStyle
    IL_001f:  ldarg.s    iMarker
    IL_0021:  ldarg.s    iSize
    IL_0023:  ldarg.s    iInterval
    IL_0025:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetVarLineAttributes(int16,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16)
    IL_002a:  ret
  } // end of method AxPfsplot::SetVarLineAttributes

  .method public hidebysig newslot virtual 
          instance void  GetAnnotationCount(int16& nAnno) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetAnnotationCount"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetAnnotationCount(int16&)
    IL_0020:  ret
  } // end of method AxPfsplot::GetAnnotationCount

  .method public hidebysig newslot virtual 
          instance string  GetAnnoAttributes(int16 iIndex,
                                             int16& ifontsize,
                                             int16& ifontattrib,
                                             int16& ifontcolor,
                                             int16& idirecton,
                                             int16& ialignment,
                                             int16& iattachment,
                                             int16& iarrow) cil managed
  {
    // Code size       47 (0x2f)
    .maxstack  9
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetAnnoAttributes"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    ifontcolor
    IL_001f:  ldarg.s    idirecton
    IL_0021:  ldarg.s    ialignment
    IL_0023:  ldarg.s    iattachment
    IL_0025:  ldarg.s    iarrow
    IL_0027:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetAnnoAttributes(int16,
                                                                                             int16&,
                                                                                             int16&,
                                                                                             int16&,
                                                                                             int16&,
                                                                                             int16&,
                                                                                             int16&,
                                                                                             int16&)
    IL_002c:  stloc.0
    IL_002d:  ldloc.0
    IL_002e:  ret
  } // end of method AxPfsplot::GetAnnoAttributes

  .method public hidebysig newslot virtual 
          instance void  SetFlippedFlag(bool bFlipped) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetFlippedFlag"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetFlippedFlag(bool)
    IL_0020:  ret
  } // end of method AxPfsplot::SetFlippedFlag

  .method public hidebysig newslot virtual 
          instance void  ApplySettingByUserFlag() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ApplySettingByUserFlag"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::ApplySettingByUserFlag()
    IL_001f:  ret
  } // end of method AxPfsplot::ApplySettingByUserFlag

  .method public hidebysig newslot virtual 
          instance string  GetLabelColor(int16 axisNo) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetLabelColor"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetLabelColor(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetLabelColor

  .method public hidebysig newslot virtual 
          instance string  GetAxisColor(int16 axisNo) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetAxisColor"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetAxisColor(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetAxisColor

  .method public hidebysig newslot virtual 
          instance void  GetSetAxisRefit(int16 iAxis) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSetAxisRefit"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetSetAxisRefit(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::GetSetAxisRefit

  .method public hidebysig newslot virtual 
          instance void  SetPartSettings(string partSettings) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetPartSettings"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetPartSettings(string)
    IL_0020:  ret
  } // end of method AxPfsplot::SetPartSettings

  .method public hidebysig newslot virtual 
          instance void  AboutBox() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AboutBox"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::AboutBox()
    IL_001f:  ret
  } // end of method AxPfsplot::AboutBox

  .method public hidebysig newslot virtual 
          instance void  Redraw() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Redraw"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::Redraw()
    IL_001f:  ret
  } // end of method AxPfsplot::Redraw

  .method public hidebysig newslot virtual 
          instance void  Scroll(bool horizontal,
                                int16 'type',
                                int16 'value') cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Scroll"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::Scroll(bool,
                                                                                int16,
                                                                                int16)
    IL_0022:  ret
  } // end of method AxPfsplot::Scroll

  .method public hidebysig newslot virtual 
          instance void  GetScroll(bool horizontal,
                                   int16& minValue,
                                   int16& maxValue) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetScroll"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetScroll(bool,
                                                                                   int16&,
                                                                                   int16&)
    IL_0022:  ret
  } // end of method AxPfsplot::GetScroll

  .method public hidebysig newslot virtual 
          instance string  GetCurrentValue(int16 objID) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetCurrentValue"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetCurrentValue(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetCurrentValue

  .method public hidebysig newslot virtual 
          instance void  AddTimeData(int16 varNo,
                                     float64 time,
                                     float64 'value') cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AddTimeData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::AddTimeData(int16,
                                                                                     float64,
                                                                                     float64)
    IL_0022:  ret
  } // end of method AxPfsplot::AddTimeData

  .method public hidebysig newslot virtual 
          instance void  SetLabel(int16 axisNo,
                                  string label) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetLabel"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetLabel(int16,
                                                                                  string)
    IL_0021:  ret
  } // end of method AxPfsplot::SetLabel

  .method public hidebysig newslot virtual 
          instance void  SetLegend(int16 varNo,
                                   string legend) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetLegend"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetLegend(int16,
                                                                                   string)
    IL_0021:  ret
  } // end of method AxPfsplot::SetLegend

  .method public hidebysig newslot virtual 
          instance void  SetScale(int16 varNo,
                                  int16 scale) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetScale"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetScale(int16,
                                                                                  int16)
    IL_0021:  ret
  } // end of method AxPfsplot::SetScale

  .method public hidebysig newslot virtual 
          instance void  SetInteger(int16 varNo) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetInteger"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetInteger(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::SetInteger

  .method public hidebysig newslot virtual 
          instance void  SetRange(int16 varNo,
                                  float64 lowValue,
                                  float64 highValue) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetRange"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetRange(int16,
                                                                                  float64,
                                                                                  float64)
    IL_0022:  ret
  } // end of method AxPfsplot::SetRange

  .method public hidebysig newslot virtual 
          instance void  SetData(int16 varNo,
                                 int16 dataNo,
                                 float64 'value') cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetData(int16,
                                                                                 int16,
                                                                                 float64)
    IL_0022:  ret
  } // end of method AxPfsplot::SetData

  .method public hidebysig newslot virtual 
          instance void  SetFont(int16 fontID,
                                 string fontname,
                                 int16 size,
                                 int16 attrib) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetFont"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    attrib
    IL_001f:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetFont(int16,
                                                                                 string,
                                                                                 int16,
                                                                                 int16)
    IL_0024:  ret
  } // end of method AxPfsplot::SetFont

  .method public hidebysig newslot virtual 
          instance void  SetVariable(int16 index,
                                     string variableName) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetVariable"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetVariable(int16,
                                                                                     string)
    IL_0021:  ret
  } // end of method AxPfsplot::SetVariable

  .method public hidebysig newslot virtual 
          instance string  GetVariable(int16 index) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetVariable"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetVariable(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetVariable

  .method public hidebysig newslot virtual 
          instance void  GetRange(int16 varNo,
                                  float64& lowValue,
                                  float64& highValue) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetRange"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetRange(int16,
                                                                                  float64&,
                                                                                  float64&)
    IL_0022:  ret
  } // end of method AxPfsplot::GetRange

  .method public hidebysig newslot virtual 
          instance string  GetLabel(int16 axisNo) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetLabel"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetLabel(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetLabel

  .method public hidebysig newslot virtual 
          instance void  RewindTimeData(float64 starttime) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "RewindTimeData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::RewindTimeData(float64)
    IL_0020:  ret
  } // end of method AxPfsplot::RewindTimeData

  .method public hidebysig newslot virtual 
          instance string  GetFont(int16 fontID,
                                   int16& size,
                                   int16& attrib) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  4
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetFont"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetFont(int16,
                                                                                   int16&,
                                                                                   int16&)
    IL_0022:  stloc.0
    IL_0023:  ldloc.0
    IL_0024:  ret
  } // end of method AxPfsplot::GetFont

  .method public hidebysig newslot virtual 
          instance void  SetAttribute(int16 lineno,
                                      int16 'type',
                                      int16 marker,
                                      int16 color) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetAttribute"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    color
    IL_001f:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetAttribute(int16,
                                                                                      int16,
                                                                                      int16,
                                                                                      int16)
    IL_0024:  ret
  } // end of method AxPfsplot::SetAttribute

  .method public hidebysig newslot virtual 
          instance void  GetAttribute(int16 lineno,
                                      int16& 'type',
                                      int16& marker,
                                      int16& color) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetAttribute"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    color
    IL_001f:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetAttribute(int16,
                                                                                      int16&,
                                                                                      int16&,
                                                                                      int16&)
    IL_0024:  ret
  } // end of method AxPfsplot::GetAttribute

  .method public hidebysig newslot virtual 
          instance void  ClearTimeData(int16 varNo) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ClearTimeData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::ClearTimeData(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::ClearTimeData

  .method public hidebysig newslot virtual 
          instance string  GetSettings() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSettings"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetSettings()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::GetSettings

  .method public hidebysig newslot virtual 
          instance void  SetSettings(string settings) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSettings"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetSettings(string)
    IL_0020:  ret
  } // end of method AxPfsplot::SetSettings

  .method public hidebysig newslot virtual 
          instance void  EditObject(int16 objectID) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "EditObject"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::EditObject(int16)
    IL_0020:  ret
  } // end of method AxPfsplot::EditObject

  .method public hidebysig newslot virtual 
          instance int16  GetAxisMap(int16 varNo) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetAxisMap"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetAxisMap(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetAxisMap

  .method public hidebysig newslot virtual 
          instance void  SetAxisMap(int16 varNo,
                                    int16 axisNo) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetAxisMap"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetAxisMap(int16,
                                                                                    int16)
    IL_0021:  ret
  } // end of method AxPfsplot::SetAxisMap

  .method public hidebysig newslot virtual 
          instance void  FireReloadEvent() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "FireReloadEvent"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::FireReloadEvent()
    IL_001f:  ret
  } // end of method AxPfsplot::FireReloadEvent

  .method public hidebysig newslot virtual 
          instance void  CopyToBuffer(object& data) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CopyToBuffer"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::CopyToBuffer(object&)
    IL_0020:  ret
  } // end of method AxPfsplot::CopyToBuffer

  .method public hidebysig newslot virtual 
          instance void  SetAxisRange(int16 axisNo,
                                      float64 lowValue,
                                      float64 highValue) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetAxisRange"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetAxisRange(int16,
                                                                                      float64,
                                                                                      float64)
    IL_0022:  ret
  } // end of method AxPfsplot::SetAxisRange

  .method public hidebysig newslot virtual 
          instance void  GetAxisRange(int16 axisNo,
                                      float64& lowValue,
                                      float64& highValue) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetAxisRange"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::GetAxisRange(int16,
                                                                                      float64&,
                                                                                      float64&)
    IL_0022:  ret
  } // end of method AxPfsplot::GetAxisRange

  .method public hidebysig newslot virtual 
          instance void  SetXData(int16 varNo,
                                  int16 dataNo,
                                  float64 'value') cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetXData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetXData(int16,
                                                                                  int16,
                                                                                  float64)
    IL_0022:  ret
  } // end of method AxPfsplot::SetXData

  .method public hidebysig newslot virtual 
          instance void  SetTieLine(int16 'type',
                                    int16 varNo) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetTieLine"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetTieLine(int16,
                                                                                    int16)
    IL_0021:  ret
  } // end of method AxPfsplot::SetTieLine

  .method public hidebysig newslot virtual 
          instance int16  AddText(string text,
                                  float32 x,
                                  float32 y,
                                  int16 color,
                                  int16 'alignment',
                                  string fontname,
                                  int16 size,
                                  int16 style) cil managed
  {
    // Code size       47 (0x2f)
    .maxstack  9
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AddText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    color
    IL_001f:  ldarg.s    'alignment'
    IL_0021:  ldarg.s    fontname
    IL_0023:  ldarg.s    size
    IL_0025:  ldarg.s    style
    IL_0027:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::AddText(string,
                                                                                  float32,
                                                                                  float32,
                                                                                  int16,
                                                                                  int16,
                                                                                  string,
                                                                                  int16,
                                                                                  int16)
    IL_002c:  stloc.0
    IL_002d:  ldloc.0
    IL_002e:  ret
  } // end of method AxPfsplot::AddText

  .method public hidebysig newslot virtual 
          instance void  SetXVariable(int16 yvarno,
                                      int16 xvarno) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetXVariable"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::SetXVariable(int16,
                                                                                      int16)
    IL_0021:  ret
  } // end of method AxPfsplot::SetXVariable

  .method public hidebysig newslot virtual 
          instance int16  GetXVariable(int16 yvarno) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetXVariable"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetXVariable(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetXVariable

  .method public hidebysig newslot virtual 
          instance string  GetLegend(int16 varNo) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetLegend"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance string [PFSPlotLib]PFSPlotLib._DPfsplot::GetLegend(int16)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxPfsplot::GetLegend

  .method public hidebysig newslot virtual 
          instance int16  GetNYaxes() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetNYaxes"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance int16 [PFSPlotLib]PFSPlotLib._DPfsplot::GetNYaxes()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxPfsplot::GetNYaxes

  .method public hidebysig newslot virtual 
          instance void  AddTextDialog() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AddTextDialog"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::AddTextDialog()
    IL_001f:  ret
  } // end of method AxPfsplot::AddTextDialog

  .method public hidebysig newslot virtual 
          instance void  HideVariableDialog() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "HideVariableDialog"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::HideVariableDialog()
    IL_001f:  ret
  } // end of method AxPfsplot::HideVariableDialog

  .method public hidebysig newslot virtual 
          instance void  Copy() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Copy"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
    IL_001a:  callvirt   instance void [PFSPlotLib]PFSPlotLib._DPfsplot::Copy()
    IL_001f:  ret
  } // end of method AxPfsplot::Copy

  .method family hidebysig virtual instance void 
          CreateSink() cil managed
  {
    // Code size       51 (0x33)
    .maxstack  4
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldarg.0
      IL_0002:  newobj     instance void AxPFSPlotLib.AxPfsplotEventMulticaster::.ctor(class AxPFSPlotLib.AxPfsplot)
      IL_0007:  stfld      class AxPFSPlotLib.AxPfsplotEventMulticaster AxPFSPlotLib.AxPfsplot::eventMulticaster
      IL_000c:  ldarg.0
      IL_000d:  ldarg.0
      IL_000e:  ldfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
      IL_0013:  ldarg.0
      IL_0014:  ldfld      class AxPFSPlotLib.AxPfsplotEventMulticaster AxPFSPlotLib.AxPfsplot::eventMulticaster
      IL_0019:  ldtoken    [PFSPlotLib]PFSPlotLib._DPfsplotEvents
      IL_001e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0023:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie::.ctor(object,
                                                                                                                        object,
                                                                                                                        class [mscorlib]System.Type)
      IL_0028:  stfld      class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie AxPFSPlotLib.AxPfsplot::cookie
      IL_002d:  leave.s    IL_0032

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_002f:  pop
      IL_0030:  leave.s    IL_0032

    }  // end handler
    IL_0032:  ret
  } // end of method AxPfsplot::CreateSink

  .method family hidebysig virtual instance void 
          DetachSink() cil managed
  {
    // Code size       17 (0x11)
    .maxstack  1
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie AxPFSPlotLib.AxPfsplot::cookie
      IL_0006:  callvirt   instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie::Disconnect()
      IL_000b:  leave.s    IL_0010

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_000d:  pop
      IL_000e:  leave.s    IL_0010

    }  // end handler
    IL_0010:  ret
  } // end of method AxPfsplot::DetachSink

  .method family hidebysig virtual instance void 
          AttachInterfaces() cil managed
  {
    // Code size       23 (0x17)
    .maxstack  2
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldarg.0
      IL_0002:  call       instance object [System.Windows.Forms]System.Windows.Forms.AxHost::GetOcx()
      IL_0007:  castclass  [PFSPlotLib]PFSPlotLib._DPfsplot
      IL_000c:  stfld      class [PFSPlotLib]PFSPlotLib._DPfsplot AxPFSPlotLib.AxPfsplot::ocx
      IL_0011:  leave.s    IL_0016

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_0013:  pop
      IL_0014:  leave.s    IL_0016

    }  // end handler
    IL_0016:  ret
  } // end of method AxPfsplot::AttachInterfaces

  .method assembly hidebysig instance void 
          RaiseOnSelected(object sender,
                          class AxPFSPlotLib._DPfsplotEvents_SelectedEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler AxPFSPlotLib.AxPfsplot::Selected
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler AxPFSPlotLib.AxPfsplot::Selected
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler::Invoke(object,
                                                                                                 class AxPFSPlotLib._DPfsplotEvents_SelectedEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnSelected

  .method assembly hidebysig instance void 
          RaiseOnZoomed(object sender,
                        class AxPFSPlotLib._DPfsplotEvents_ZoomedEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler AxPFSPlotLib.AxPfsplot::Zoomed
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler AxPFSPlotLib.AxPfsplot::Zoomed
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler::Invoke(object,
                                                                                               class AxPFSPlotLib._DPfsplotEvents_ZoomedEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnZoomed

  .method assembly hidebysig instance void 
          RaiseOnVariableChanged(object sender,
                                 class AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler AxPFSPlotLib.AxPfsplot::VariableChanged
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler AxPFSPlotLib.AxPfsplot::VariableChanged
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler::Invoke(object,
                                                                                                        class AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnVariableChanged

  .method assembly hidebysig instance void 
          RaiseOnApplyVariableChanges(object sender,
                                      class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ApplyVariableChanges
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ApplyVariableChanges
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnApplyVariableChanges

  .method assembly hidebysig instance void 
          RaiseOnOnDropText(object sender,
                            class AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler AxPFSPlotLib.AxPfsplot::OnDropText
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler AxPFSPlotLib.AxPfsplot::OnDropText
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler::Invoke(object,
                                                                                                   class AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnOnDropText

  .method assembly hidebysig instance void 
          RaiseOnReloadNow(object sender,
                           class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ReloadNow
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ReloadNow
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnReloadNow

  .method assembly hidebysig instance void 
          RaiseOnOnEditProfileVariables(object sender,
                                        class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileVariables
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileVariables
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnOnEditProfileVariables

  .method assembly hidebysig instance void 
          RaiseOnOnOnShowasHistory(object sender,
                                   class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnOnShowasHistory
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnOnShowasHistory
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnOnOnShowasHistory

  .method assembly hidebysig instance void 
          RaiseOnOnEditProfileTable(object sender,
                                    class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileTable
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnEditProfileTable
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnOnEditProfileTable

  .method assembly hidebysig instance void 
          RaiseOnOnResetFormDefinition(object sender,
                                       class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnResetFormDefinition
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::OnResetFormDefinition
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnOnResetFormDefinition

  .method assembly hidebysig instance void 
          RaiseOnSetMessageText(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler AxPFSPlotLib.AxPfsplot::SetMessageText
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler AxPFSPlotLib.AxPfsplot::SetMessageText
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler::Invoke(object,
                                                                                                       class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnSetMessageText

  .method assembly hidebysig instance void 
          RaiseOnCommunicationIntervalsSet(object sender,
                                           class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler AxPFSPlotLib.AxPfsplot::CommunicationIntervalsSet
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler AxPFSPlotLib.AxPfsplot::CommunicationIntervalsSet
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler::Invoke(object,
                                                                                                                  class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnCommunicationIntervalsSet

  .method assembly hidebysig instance void 
          RaiseOnPointerLocation(object sender,
                                 class AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler AxPFSPlotLib.AxPfsplot::PointerLocation
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler AxPFSPlotLib.AxPfsplot::PointerLocation
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler::Invoke(object,
                                                                                                        class AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnPointerLocation

  .method assembly hidebysig instance void 
          RaiseOnOnClick(object sender,
                         class AxPFSPlotLib._DPfsplotEvents_OnClickEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler AxPFSPlotLib.AxPfsplot::OnClick
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler AxPFSPlotLib.AxPfsplot::OnClick
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler::Invoke(object,
                                                                                                class AxPFSPlotLib._DPfsplotEvents_OnClickEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnOnClick

  .method assembly hidebysig instance void 
          RaiseOnOnDoubleClick(object sender,
                               class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler AxPFSPlotLib.AxPfsplot::OnDoubleClick
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler AxPFSPlotLib.AxPfsplot::OnDoubleClick
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler::Invoke(object,
                                                                                                      class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnOnDoubleClick

  .method assembly hidebysig instance void 
          RaiseOnCursorSet(object sender,
                           class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::CursorSet
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::CursorSet
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnCursorSet

  .method assembly hidebysig instance void 
          RaiseOnOnRBClick(object sender,
                           class AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler AxPFSPlotLib.AxPfsplot::OnRBClick
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler AxPFSPlotLib.AxPfsplot::OnRBClick
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler::Invoke(object,
                                                                                                  class AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnOnRBClick

  .method assembly hidebysig instance void 
          RaiseOnRegionDefined(object sender,
                               class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RegionDefined
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RegionDefined
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnRegionDefined

  .method assembly hidebysig instance void 
          RaiseOnKeyPressEvent(object sender,
                               class AxPFSPlotLib._DPfsplotEvents_KeyPressEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler AxPFSPlotLib.AxPfsplot::KeyPressEvent
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler AxPFSPlotLib.AxPfsplot::KeyPressEvent
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler::Invoke(object,
                                                                                                 class AxPFSPlotLib._DPfsplotEvents_KeyPressEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnKeyPressEvent

  .method assembly hidebysig instance void 
          RaiseOnKeyDownEvent(object sender,
                              class AxPFSPlotLib._DPfsplotEvents_KeyDownEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler AxPFSPlotLib.AxPfsplot::KeyDownEvent
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler AxPFSPlotLib.AxPfsplot::KeyDownEvent
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler::Invoke(object,
                                                                                                class AxPFSPlotLib._DPfsplotEvents_KeyDownEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnKeyDownEvent

  .method assembly hidebysig instance void 
          RaiseOnKeyUpEvent(object sender,
                            class AxPFSPlotLib._DPfsplotEvents_KeyUpEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler AxPFSPlotLib.AxPfsplot::KeyUpEvent
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler AxPFSPlotLib.AxPfsplot::KeyUpEvent
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler::Invoke(object,
                                                                                              class AxPFSPlotLib._DPfsplotEvents_KeyUpEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnKeyUpEvent

  .method assembly hidebysig instance void 
          RaiseOnScrolled(object sender,
                          class AxPFSPlotLib._DPfsplotEvents_ScrolledEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler AxPFSPlotLib.AxPfsplot::Scrolled
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler AxPFSPlotLib.AxPfsplot::Scrolled
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler::Invoke(object,
                                                                                                 class AxPFSPlotLib._DPfsplotEvents_ScrolledEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnScrolled

  .method assembly hidebysig instance void 
          RaiseOnPointerExit(object sender,
                             class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::PointerExit
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::PointerExit
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnPointerExit

  .method assembly hidebysig instance void 
          RaiseOnPhaseVariableSet(object sender,
                                  class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableSet
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableSet
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler::Invoke(object,
                                                                                                         class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnPhaseVariableSet

  .method assembly hidebysig instance void 
          RaiseOnPhaseVariableDropped(object sender,
                                      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableDropped
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler AxPFSPlotLib.AxPfsplot::PhaseVariableDropped
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler::Invoke(object,
                                                                                                             class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnPhaseVariableDropped

  .method assembly hidebysig instance void 
          RaiseOnZoomTimeRange(object sender,
                               class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ZoomTimeRange
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::ZoomTimeRange
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnZoomTimeRange

  .method assembly hidebysig instance void 
          RaiseOnRevertToTimePlot(object sender,
                                  class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RevertToTimePlot
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::RevertToTimePlot
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnRevertToTimePlot

  .method assembly hidebysig instance void 
          RaiseOnOnLivePlot(object sender,
                            class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler AxPFSPlotLib.AxPfsplot::OnLivePlot
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler AxPFSPlotLib.AxPfsplot::OnLivePlot
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler::Invoke(object,
                                                                                                   class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnOnLivePlot

  .method assembly hidebysig instance void 
          RaiseOnSetCaption(object sender,
                            class AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler AxPFSPlotLib.AxPfsplot::SetCaption
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler AxPFSPlotLib.AxPfsplot::SetCaption
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler::Invoke(object,
                                                                                                   class AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnSetCaption

  .method assembly hidebysig instance void 
          RaiseOnModified(object sender,
                          class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::Modified
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxPFSPlotLib.AxPfsplot::Modified
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnModified

  .method assembly hidebysig instance void 
          RaiseOnPlotDrawn(object sender,
                           class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler AxPFSPlotLib.AxPfsplot::PlotDrawn
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler AxPFSPlotLib.AxPfsplot::PlotDrawn
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler::Invoke(object,
                                                                                                  class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnPlotDrawn

  .method assembly hidebysig instance void 
          RaiseOnZoomDone(object sender,
                          class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler AxPFSPlotLib.AxPfsplot::ZoomDone
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler AxPFSPlotLib.AxPfsplot::ZoomDone
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler::Invoke(object,
                                                                                                 class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnZoomDone

  .method assembly hidebysig instance void 
          RaiseOnOnDropFiles(object sender,
                             class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler AxPFSPlotLib.AxPfsplot::OnDropFiles
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler AxPFSPlotLib.AxPfsplot::OnDropFiles
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler::Invoke(object,
                                                                                                    class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnOnDropFiles

  .method assembly hidebysig instance void 
          RaiseOnFlippedFlagChanged(object sender,
                                    class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler AxPFSPlotLib.AxPfsplot::FlippedFlagChanged
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler AxPFSPlotLib.AxPfsplot::FlippedFlagChanged
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler::Invoke(object,
                                                                                                           class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent)
    IL_0015:  ret
  } // end of method AxPfsplot::RaiseOnFlippedFlagChanged

  .event AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler Selected
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_Selected(class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_Selected(class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler)
  } // end of event AxPfsplot::Selected
  .event AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler Zoomed
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_Zoomed(class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_Zoomed(class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler)
  } // end of event AxPfsplot::Zoomed
  .event AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler VariableChanged
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_VariableChanged(class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_VariableChanged(class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler)
  } // end of event AxPfsplot::VariableChanged
  .event [mscorlib]System.EventHandler ApplyVariableChanges
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_ApplyVariableChanges(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_ApplyVariableChanges(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::ApplyVariableChanges
  .event AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler OnDropText
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_OnDropText(class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_OnDropText(class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler)
  } // end of event AxPfsplot::OnDropText
  .event [mscorlib]System.EventHandler ReloadNow
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_ReloadNow(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_ReloadNow(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::ReloadNow
  .event [mscorlib]System.EventHandler OnEditProfileVariables
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_OnEditProfileVariables(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_OnEditProfileVariables(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::OnEditProfileVariables
  .event [mscorlib]System.EventHandler OnOnShowasHistory
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_OnOnShowasHistory(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_OnOnShowasHistory(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::OnOnShowasHistory
  .event [mscorlib]System.EventHandler OnEditProfileTable
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_OnEditProfileTable(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_OnEditProfileTable(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::OnEditProfileTable
  .event [mscorlib]System.EventHandler OnResetFormDefinition
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_OnResetFormDefinition(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_OnResetFormDefinition(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::OnResetFormDefinition
  .event AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler SetMessageText
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_SetMessageText(class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_SetMessageText(class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler)
  } // end of event AxPfsplot::SetMessageText
  .event AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler CommunicationIntervalsSet
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_CommunicationIntervalsSet(class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_CommunicationIntervalsSet(class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler)
  } // end of event AxPfsplot::CommunicationIntervalsSet
  .event AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler PointerLocation
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_PointerLocation(class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_PointerLocation(class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler)
  } // end of event AxPfsplot::PointerLocation
  .event AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler OnClick
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_OnClick(class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_OnClick(class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler)
  } // end of event AxPfsplot::OnClick
  .event AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler OnDoubleClick
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_OnDoubleClick(class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_OnDoubleClick(class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler)
  } // end of event AxPfsplot::OnDoubleClick
  .event [mscorlib]System.EventHandler CursorSet
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_CursorSet(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_CursorSet(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::CursorSet
  .event AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler OnRBClick
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_OnRBClick(class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_OnRBClick(class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler)
  } // end of event AxPfsplot::OnRBClick
  .event [mscorlib]System.EventHandler RegionDefined
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_RegionDefined(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_RegionDefined(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::RegionDefined
  .event AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler KeyPressEvent
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_KeyPressEvent(class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_KeyPressEvent(class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler)
  } // end of event AxPfsplot::KeyPressEvent
  .event AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler KeyDownEvent
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_KeyDownEvent(class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_KeyDownEvent(class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler)
  } // end of event AxPfsplot::KeyDownEvent
  .event AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler KeyUpEvent
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_KeyUpEvent(class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_KeyUpEvent(class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler)
  } // end of event AxPfsplot::KeyUpEvent
  .event AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler Scrolled
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_Scrolled(class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_Scrolled(class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler)
  } // end of event AxPfsplot::Scrolled
  .event [mscorlib]System.EventHandler PointerExit
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_PointerExit(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_PointerExit(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::PointerExit
  .event AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler PhaseVariableSet
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_PhaseVariableSet(class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_PhaseVariableSet(class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler)
  } // end of event AxPfsplot::PhaseVariableSet
  .event AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler PhaseVariableDropped
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_PhaseVariableDropped(class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_PhaseVariableDropped(class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler)
  } // end of event AxPfsplot::PhaseVariableDropped
  .event [mscorlib]System.EventHandler ZoomTimeRange
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_ZoomTimeRange(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_ZoomTimeRange(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::ZoomTimeRange
  .event [mscorlib]System.EventHandler RevertToTimePlot
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_RevertToTimePlot(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_RevertToTimePlot(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::RevertToTimePlot
  .event AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler OnLivePlot
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_OnLivePlot(class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_OnLivePlot(class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler)
  } // end of event AxPfsplot::OnLivePlot
  .event AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler SetCaption
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_SetCaption(class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_SetCaption(class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler)
  } // end of event AxPfsplot::SetCaption
  .event [mscorlib]System.EventHandler Modified
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_Modified(class [mscorlib]System.EventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_Modified(class [mscorlib]System.EventHandler)
  } // end of event AxPfsplot::Modified
  .event AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler PlotDrawn
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_PlotDrawn(class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_PlotDrawn(class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler)
  } // end of event AxPfsplot::PlotDrawn
  .event AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler ZoomDone
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_ZoomDone(class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_ZoomDone(class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler)
  } // end of event AxPfsplot::ZoomDone
  .event AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler OnDropFiles
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_OnDropFiles(class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_OnDropFiles(class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler)
  } // end of event AxPfsplot::OnDropFiles
  .event AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler FlippedFlagChanged
  {
    .addon instance void AxPFSPlotLib.AxPfsplot::add_FlippedFlagChanged(class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler)
    .removeon instance void AxPFSPlotLib.AxPfsplot::remove_FlippedFlagChanged(class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler)
  } // end of event AxPfsplot::FlippedFlagChanged
  .property instance callconv(8) string Title()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_Title(string)
    .get instance string AxPFSPlotLib.AxPfsplot::get_Title()
  } // end of property AxPfsplot::Title
  .property instance callconv(8) string xlabel()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_xlabel(string)
    .get instance string AxPFSPlotLib.AxPfsplot::get_xlabel()
  } // end of property AxPfsplot::xlabel
  .property instance callconv(8) string ylabel()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_ylabel(string)
    .get instance string AxPFSPlotLib.AxPfsplot::get_ylabel()
  } // end of property AxPfsplot::ylabel
  .property instance callconv(8) bool MultiYaxis()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_MultiYaxis(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_MultiYaxis()
  } // end of property AxPfsplot::MultiYaxis
  .property instance callconv(8) bool RunPlot()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_RunPlot(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_RunPlot()
  } // end of property AxPfsplot::RunPlot
  .property instance callconv(8) int16 PlotType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_PlotType(int16)
    .get instance int16 AxPFSPlotLib.AxPfsplot::get_PlotType()
  } // end of property AxPfsplot::PlotType
  .property instance callconv(8) float32 TimeWindow()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_TimeWindow(float32)
    .get instance float32 AxPFSPlotLib.AxPfsplot::get_TimeWindow()
  } // end of property AxPfsplot::TimeWindow
  .property instance callconv(8) bool UseVariable()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_UseVariable(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_UseVariable()
  } // end of property AxPfsplot::UseVariable
  .property instance callconv(8) string InputFile()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_InputFile(string)
    .get instance string AxPFSPlotLib.AxPfsplot::get_InputFile()
  } // end of property AxPfsplot::InputFile
  .property instance callconv(8) int16 npoints()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_npoints(int16)
    .get instance int16 AxPFSPlotLib.AxPfsplot::get_npoints()
  } // end of property AxPfsplot::npoints
  .property instance callconv(8) int16 nvariables()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_nvariables(int16)
    .get instance int16 AxPFSPlotLib.AxPfsplot::get_nvariables()
  } // end of property AxPfsplot::nvariables
  .property instance callconv(8) float32 TimeScrollUnit()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_TimeScrollUnit(float32)
    .get instance float32 AxPFSPlotLib.AxPfsplot::get_TimeScrollUnit()
  } // end of property AxPfsplot::TimeScrollUnit
  .property instance callconv(8) int16 GridType()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_GridType(int16)
    .get instance int16 AxPFSPlotLib.AxPfsplot::get_GridType()
  } // end of property AxPfsplot::GridType
  .property instance callconv(8) int16 MarkerSize()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_MarkerSize(int16)
    .get instance int16 AxPFSPlotLib.AxPfsplot::get_MarkerSize()
  } // end of property AxPfsplot::MarkerSize
  .property instance callconv(8) int16 MarkerInterval()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_MarkerInterval(int16)
    .get instance int16 AxPFSPlotLib.AxPfsplot::get_MarkerInterval()
  } // end of property AxPfsplot::MarkerInterval
  .property instance callconv(8) bool Flipped()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_Flipped(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_Flipped()
  } // end of property AxPfsplot::Flipped
  .property instance callconv(8) bool SquarePlot()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_SquarePlot(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_SquarePlot()
  } // end of property AxPfsplot::SquarePlot
  .property instance callconv(8) bool DiagonalLine()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_DiagonalLine(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_DiagonalLine()
  } // end of property AxPfsplot::DiagonalLine
  .property instance callconv(8) bool ZeroLine()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_ZeroLine(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_ZeroLine()
  } // end of property AxPfsplot::ZeroLine
  .property instance callconv(8) int16 DisplayType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_DisplayType(int16)
    .get instance int16 AxPFSPlotLib.AxPfsplot::get_DisplayType()
  } // end of property AxPfsplot::DisplayType
  .property instance callconv(8) int32 BufferSize()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_BufferSize(int32)
    .get instance int32 AxPFSPlotLib.AxPfsplot::get_BufferSize()
  } // end of property AxPfsplot::BufferSize
  .property instance callconv(8) bool SizeToData()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_SizeToData(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_SizeToData()
  } // end of property AxPfsplot::SizeToData
  .property instance callconv(8) valuetype [System.Drawing]System.Drawing.Color
          BackColor()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B FE FF FF 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 0D 53 79 73 74 65 6D 2E 55 49 6E 74 33 32   // ...System.UInt32
                                                                                                            00 00 ) 
    .custom instance void [System]System.ComponentModel.BrowsableAttribute::.ctor(bool) = ( 01 00 01 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_BackColor(valuetype [System.Drawing]System.Drawing.Color)
    .get instance valuetype [System.Drawing]System.Drawing.Color AxPFSPlotLib.AxPfsplot::get_BackColor()
  } // end of property AxPfsplot::BackColor
  .property instance callconv(8) valuetype [System.Drawing]System.Drawing.Color
          ForeColor()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FF FD FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 0D 53 79 73 74 65 6D 2E 55 49 6E 74 33 32   // ...System.UInt32
                                                                                                            00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.BrowsableAttribute::.ctor(bool) = ( 01 00 01 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_ForeColor(valuetype [System.Drawing]System.Drawing.Color)
    .get instance valuetype [System.Drawing]System.Drawing.Color AxPFSPlotLib.AxPfsplot::get_ForeColor()
  } // end of property AxPfsplot::ForeColor
  .property instance callconv(8) bool Parametric()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_Parametric(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_Parametric()
  } // end of property AxPfsplot::Parametric
  .property instance callconv(8) int16 nxvariables()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_nxvariables(int16)
    .get instance int16 AxPFSPlotLib.AxPfsplot::get_nxvariables()
  } // end of property AxPfsplot::nxvariables
  .property instance callconv(8) bool ReverseXAxis()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_ReverseXAxis(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_ReverseXAxis()
  } // end of property AxPfsplot::ReverseXAxis
  .property instance callconv(8) bool AddTimeStamp()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1A 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_AddTimeStamp(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_AddTimeStamp()
  } // end of property AxPfsplot::AddTimeStamp
  .property instance callconv(8) bool ShowLegend()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1B 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_ShowLegend(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_ShowLegend()
  } // end of property AxPfsplot::ShowLegend
  .property instance callconv(8) int16 CommunicationIntervals()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1C 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_CommunicationIntervals(int16)
    .get instance int16 AxPFSPlotLib.AxPfsplot::get_CommunicationIntervals()
  } // end of property AxPfsplot::CommunicationIntervals
  .property instance callconv(8) float32 GridInterval()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1D 00 00 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_GridInterval(float32)
    .get instance float32 AxPFSPlotLib.AxPfsplot::get_GridInterval()
  } // end of property AxPfsplot::GridInterval
  .property instance callconv(8) bool VariableDrop()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1E 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_VariableDrop(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_VariableDrop()
  } // end of property AxPfsplot::VariableDrop
  .property instance callconv(8) bool IgnoreSetLegend()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1F 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_IgnoreSetLegend(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_IgnoreSetLegend()
  } // end of property AxPfsplot::IgnoreSetLegend
  .property instance callconv(8) object PlotVals()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 00 00 00 00 )                         // .. .....
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_PlotVals(object)
    .get instance object AxPFSPlotLib.AxPfsplot::get_PlotVals()
  } // end of property AxPfsplot::PlotVals
  .property instance callconv(8) bool EditProfileVariables()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 00 00 00 00 )                         // ..!.....
    .get instance bool AxPFSPlotLib.AxPfsplot::get_EditProfileVariables()
    .set instance void AxPFSPlotLib.AxPfsplot::set_EditProfileVariables(bool)
  } // end of property AxPfsplot::EditProfileVariables
  .property instance callconv(8) bool EditProfileTable()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 22 00 00 00 00 00 )                         // ..".....
    .set instance void AxPFSPlotLib.AxPfsplot::set_EditProfileTable(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_EditProfileTable()
  } // end of property AxPfsplot::EditProfileTable
  .property instance callconv(8) bool AlwaysShowFull()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 23 00 00 00 00 00 )                         // ..#.....
    .set instance void AxPFSPlotLib.AxPfsplot::set_AlwaysShowFull(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_AlwaysShowFull()
  } // end of property AxPfsplot::AlwaysShowFull
  .property instance callconv(8) int16 ClientType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 00 00 00 00 )                         // ..$.....
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_ClientType(int16)
    .get instance int16 AxPFSPlotLib.AxPfsplot::get_ClientType()
  } // end of property AxPfsplot::ClientType
  .property instance callconv(8) bool ShowTitle()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 25 00 00 00 00 00 )                         // ..%.....
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_ShowTitle(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_ShowTitle()
  } // end of property AxPfsplot::ShowTitle
  .property instance callconv(8) bool ShowXaxisLabel()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 26 00 00 00 00 00 )                         // ..&.....
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .set instance void AxPFSPlotLib.AxPfsplot::set_ShowXaxisLabel(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_ShowXaxisLabel()
  } // end of property AxPfsplot::ShowXaxisLabel
  .property instance callconv(8) bool CanLivePlot()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 27 00 00 00 00 00 )                         // ..'.....
    .set instance void AxPFSPlotLib.AxPfsplot::set_CanLivePlot(bool)
    .get instance bool AxPFSPlotLib.AxPfsplot::get_CanLivePlot()
  } // end of property AxPfsplot::CanLivePlot
  .property instance callconv(8) bool LivePlot()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 28 00 00 00 00 00 )                         // ..(.....
    .get instance bool AxPFSPlotLib.AxPfsplot::get_LivePlot()
    .set instance void AxPFSPlotLib.AxPfsplot::set_LivePlot(bool)
  } // end of property AxPfsplot::LivePlot
  .property instance callconv(8) bool ShowTracker()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 29 00 00 00 00 00 )                         // ..).....
    .get instance bool AxPFSPlotLib.AxPfsplot::get_ShowTracker()
    .set instance void AxPFSPlotLib.AxPfsplot::set_ShowTracker(bool)
  } // end of property AxPfsplot::ShowTracker
  .property instance callconv(8) float64 ZoomLevel()
  {
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 2A 00 00 00 00 00 )                         // ..*.....
    .set instance void AxPFSPlotLib.AxPfsplot::set_ZoomLevel(float64)
    .get instance float64 AxPFSPlotLib.AxPfsplot::get_ZoomLevel()
  } // end of property AxPfsplot::ZoomLevel
} // end of class AxPFSPlotLib.AxPfsplot

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_SelectedEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_SelectedEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_SelectedEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_SelectedEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_SelectedEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_SelectedEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_SelectedEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_SelectedEvent
       extends [mscorlib]System.Object
{
  .field public int16 objectID
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(int16 objectID) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_SelectedEvent::objectID
    IL_000d:  ret
  } // end of method _DPfsplotEvents_SelectedEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_SelectedEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_ZoomedEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_ZoomedEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_ZoomedEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_ZoomedEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_ZoomedEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_ZoomedEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_ZoomedEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_ZoomedEvent
       extends [mscorlib]System.Object
{
  .field public bool onOff
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(bool onOff) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      bool AxPFSPlotLib._DPfsplotEvents_ZoomedEvent::onOff
    IL_000d:  ret
  } // end of method _DPfsplotEvents_ZoomedEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_ZoomedEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_VariableChangedEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_VariableChangedEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_VariableChangedEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_VariableChangedEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_VariableChangedEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent
       extends [mscorlib]System.Object
{
  .field public int16 varNo
  .field public string variableName
  .field public int16 status
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(int16 varNo,
                               string variableName,
                               int16 status) cil managed
  {
    // Code size       28 (0x1c)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent::varNo
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      string AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent::variableName
    IL_0014:  ldarg.0
    IL_0015:  ldarg.3
    IL_0016:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent::status
    IL_001b:  ret
  } // end of method _DPfsplotEvents_VariableChangedEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_OnDropTextEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_OnDropTextEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_OnDropTextEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_OnDropTextEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_OnDropTextEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent
       extends [mscorlib]System.Object
{
  .field public string text
  .field public int16 objectID
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string text,
                               int16 objectID) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent::text
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent::objectID
    IL_0014:  ret
  } // end of method _DPfsplotEvents_OnDropTextEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_SetMessageTextEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_SetMessageTextEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_SetMessageTextEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_SetMessageTextEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent
       extends [mscorlib]System.Object
{
  .field public string text
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string text) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent::text
    IL_000d:  ret
  } // end of method _DPfsplotEvents_SetMessageTextEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_CommunicationIntervalsSetEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_CommunicationIntervalsSetEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_CommunicationIntervalsSetEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_CommunicationIntervalsSetEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent
       extends [mscorlib]System.Object
{
  .field public int16 intervals
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(int16 intervals) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent::intervals
    IL_000d:  ret
  } // end of method _DPfsplotEvents_CommunicationIntervalsSetEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_PointerLocationEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_PointerLocationEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_PointerLocationEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_PointerLocationEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_PointerLocationEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent
       extends [mscorlib]System.Object
{
  .field public string coordinate
  .field public int16 ix
  .field public int16 iy
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string coordinate,
                               int16 ix,
                               int16 iy) cil managed
  {
    // Code size       28 (0x1c)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent::coordinate
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent::ix
    IL_0014:  ldarg.0
    IL_0015:  ldarg.3
    IL_0016:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent::iy
    IL_001b:  ret
  } // end of method _DPfsplotEvents_PointerLocationEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_OnClickEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_OnClickEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_OnClickEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_OnClickEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_OnClickEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_OnClickEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_OnClickEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_OnClickEvent
       extends [mscorlib]System.Object
{
  .field public float64 x
  .field public float64 y
  .field public int16 ix
  .field public int16 iy
  .field public int16 objectID
  .field public int16 modifier
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(float64 x,
                               float64 y,
                               int16 ix,
                               int16 iy,
                               int16 objectID,
                               int16 modifier) cil managed
  {
    // Code size       52 (0x34)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      float64 AxPFSPlotLib._DPfsplotEvents_OnClickEvent::x
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      float64 AxPFSPlotLib._DPfsplotEvents_OnClickEvent::y
    IL_0014:  ldarg.0
    IL_0015:  ldarg.3
    IL_0016:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnClickEvent::ix
    IL_001b:  ldarg.0
    IL_001c:  ldarg.s    iy
    IL_001e:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnClickEvent::iy
    IL_0023:  ldarg.0
    IL_0024:  ldarg.s    objectID
    IL_0026:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnClickEvent::objectID
    IL_002b:  ldarg.0
    IL_002c:  ldarg.s    modifier
    IL_002e:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnClickEvent::modifier
    IL_0033:  ret
  } // end of method _DPfsplotEvents_OnClickEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_OnClickEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_OnDoubleClickEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_OnDoubleClickEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_OnDoubleClickEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_OnDoubleClickEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent
       extends [mscorlib]System.Object
{
  .field public float64 x
  .field public float64 y
  .field public int16 ix
  .field public int16 iy
  .field public int16 objectID
  .field public int16 modifier
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(float64 x,
                               float64 y,
                               int16 ix,
                               int16 iy,
                               int16 objectID,
                               int16 modifier) cil managed
  {
    // Code size       52 (0x34)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      float64 AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent::x
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      float64 AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent::y
    IL_0014:  ldarg.0
    IL_0015:  ldarg.3
    IL_0016:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent::ix
    IL_001b:  ldarg.0
    IL_001c:  ldarg.s    iy
    IL_001e:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent::iy
    IL_0023:  ldarg.0
    IL_0024:  ldarg.s    objectID
    IL_0026:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent::objectID
    IL_002b:  ldarg.0
    IL_002c:  ldarg.s    modifier
    IL_002e:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent::modifier
    IL_0033:  ret
  } // end of method _DPfsplotEvents_OnDoubleClickEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_OnRBClickEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_OnRBClickEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_OnRBClickEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_OnRBClickEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_OnRBClickEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent
       extends [mscorlib]System.Object
{
  .field public float64 x
  .field public float64 y
  .field public int16 ix
  .field public int16 iy
  .field public int16 objectID
  .field public int16 modifier
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(float64 x,
                               float64 y,
                               int16 ix,
                               int16 iy,
                               int16 objectID,
                               int16 modifier) cil managed
  {
    // Code size       52 (0x34)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      float64 AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent::x
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      float64 AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent::y
    IL_0014:  ldarg.0
    IL_0015:  ldarg.3
    IL_0016:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent::ix
    IL_001b:  ldarg.0
    IL_001c:  ldarg.s    iy
    IL_001e:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent::iy
    IL_0023:  ldarg.0
    IL_0024:  ldarg.s    objectID
    IL_0026:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent::objectID
    IL_002b:  ldarg.0
    IL_002c:  ldarg.s    modifier
    IL_002e:  stfld      int16 AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent::modifier
    IL_0033:  ret
  } // end of method _DPfsplotEvents_OnRBClickEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_KeyPressEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_KeyPressEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_KeyPressEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_KeyPressEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_KeyPressEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_KeyPressEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_KeyPressEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_KeyPressEvent
       extends [mscorlib]System.Object
{
  .field public int32 keyAscii
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(int32 keyAscii) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int32 AxPFSPlotLib._DPfsplotEvents_KeyPressEvent::keyAscii
    IL_000d:  ret
  } // end of method _DPfsplotEvents_KeyPressEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_KeyPressEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_KeyDownEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_KeyDownEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_KeyDownEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_KeyDownEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_KeyDownEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_KeyDownEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_KeyDownEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_KeyDownEvent
       extends [mscorlib]System.Object
{
  .field public int32 keyCode
  .field public int32 shift
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(int32 keyCode,
                               int32 shift) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int32 AxPFSPlotLib._DPfsplotEvents_KeyDownEvent::keyCode
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      int32 AxPFSPlotLib._DPfsplotEvents_KeyDownEvent::shift
    IL_0014:  ret
  } // end of method _DPfsplotEvents_KeyDownEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_KeyDownEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_KeyUpEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_KeyUpEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_KeyUpEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_KeyUpEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_KeyUpEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_KeyUpEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_KeyUpEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_KeyUpEvent
       extends [mscorlib]System.Object
{
  .field public int32 keyCode
  .field public int32 shift
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(int32 keyCode,
                               int32 shift) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int32 AxPFSPlotLib._DPfsplotEvents_KeyUpEvent::keyCode
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      int32 AxPFSPlotLib._DPfsplotEvents_KeyUpEvent::shift
    IL_0014:  ret
  } // end of method _DPfsplotEvents_KeyUpEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_KeyUpEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_ScrolledEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_ScrolledEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_ScrolledEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_ScrolledEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_ScrolledEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_ScrolledEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_ScrolledEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_ScrolledEvent
       extends [mscorlib]System.Object
{
  .field public bool horizontal
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(bool horizontal) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      bool AxPFSPlotLib._DPfsplotEvents_ScrolledEvent::horizontal
    IL_000d:  ret
  } // end of method _DPfsplotEvents_ScrolledEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_ScrolledEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_PhaseVariableSetEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_PhaseVariableSetEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_PhaseVariableSetEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_PhaseVariableSetEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent
       extends [mscorlib]System.Object
{
  .field public string variablePath
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string variablePath) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent::variablePath
    IL_000d:  ret
  } // end of method _DPfsplotEvents_PhaseVariableSetEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_PhaseVariableDroppedEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_PhaseVariableDroppedEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_PhaseVariableDroppedEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_PhaseVariableDroppedEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent
       extends [mscorlib]System.Object
{
  .field public string sVarName
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string sVarName) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent::sVarName
    IL_000d:  ret
  } // end of method _DPfsplotEvents_PhaseVariableDroppedEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_OnLivePlotEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_OnLivePlotEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_OnLivePlotEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_OnLivePlotEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent
       extends [mscorlib]System.Object
{
  .field public bool set
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(bool set) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      bool AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent::set
    IL_000d:  ret
  } // end of method _DPfsplotEvents_OnLivePlotEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_SetCaptionEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_SetCaptionEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_SetCaptionEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_SetCaptionEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_SetCaptionEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent
       extends [mscorlib]System.Object
{
  .field public string text
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string text) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent::text
    IL_000d:  ret
  } // end of method _DPfsplotEvents_SetCaptionEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_PlotDrawnEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_PlotDrawnEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_PlotDrawnEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_PlotDrawnEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent
       extends [mscorlib]System.Object
{
  .field public bool onOff
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(bool onOff) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      bool AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent::onOff
    IL_000d:  ret
  } // end of method _DPfsplotEvents_PlotDrawnEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_ZoomDoneEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_ZoomDoneEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_ZoomDoneEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_ZoomDoneEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent
       extends [mscorlib]System.Object
{
  .field public float32 fZoomVal
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(float32 fZoomVal) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      float32 AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent::fZoomVal
    IL_000d:  ret
  } // end of method _DPfsplotEvents_ZoomDoneEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_OnDropFilesEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_OnDropFilesEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_OnDropFilesEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_OnDropFilesEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent
       extends [mscorlib]System.Object
{
  .field public string varFiles
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string varFiles) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent::varFiles
    IL_000d:  ret
  } // end of method _DPfsplotEvents_OnDropFilesEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent

.class public auto ansi sealed AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DPfsplotEvents_FlippedFlagChangedEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent e) runtime managed
  {
  } // end of method _DPfsplotEvents_FlippedFlagChangedEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DPfsplotEvents_FlippedFlagChangedEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DPfsplotEvents_FlippedFlagChangedEventHandler::EndInvoke

} // end of class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEventHandler

.class public auto ansi beforefieldinit AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent
       extends [mscorlib]System.Object
{
  .field public bool bFlipped
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(bool bFlipped) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      bool AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent::bFlipped
    IL_000d:  ret
  } // end of method _DPfsplotEvents_FlippedFlagChangedEvent::.ctor

} // end of class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent

.class public auto ansi beforefieldinit AxPFSPlotLib.AxPfsplotEventMulticaster
       extends [mscorlib]System.Object
       implements [PFSPlotLib]PFSPlotLib._DPfsplotEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .field private class AxPFSPlotLib.AxPfsplot parent
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class AxPFSPlotLib.AxPfsplot parent) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ret
  } // end of method AxPfsplotEventMulticaster::.ctor

  .method public hidebysig newslot virtual 
          instance void  Selected(int16 objectID) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_SelectedEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_SelectedEvent::.ctor(int16)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnSelected(object,
                                                                               class AxPFSPlotLib._DPfsplotEvents_SelectedEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::Selected

  .method public hidebysig newslot virtual 
          instance void  Zoomed(bool onOff) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_ZoomedEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_ZoomedEvent::.ctor(bool)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnZoomed(object,
                                                                             class AxPFSPlotLib._DPfsplotEvents_ZoomedEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::Zoomed

  .method public hidebysig newslot virtual 
          instance void  VariableChanged(int16 varNo,
                                         string variableName,
                                         int16 status) cil managed
  {
    // Code size       28 (0x1c)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent::.ctor(int16,
                                                                                                string,
                                                                                                int16)
    IL_0008:  stloc.0
    IL_0009:  ldarg.0
    IL_000a:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000f:  ldarg.0
    IL_0010:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0015:  ldloc.0
    IL_0016:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnVariableChanged(object,
                                                                                      class AxPFSPlotLib._DPfsplotEvents_VariableChangedEvent)
    IL_001b:  ret
  } // end of method AxPfsplotEventMulticaster::VariableChanged

  .method public hidebysig newslot virtual 
          instance void  ApplyVariableChanges() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnApplyVariableChanges(object,
                                                                                           class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::ApplyVariableChanges

  .method public hidebysig newslot virtual 
          instance void  OnDropText(string text,
                                    int16 objectID) cil managed
  {
    // Code size       27 (0x1b)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent::.ctor(string,
                                                                                           int16)
    IL_0007:  stloc.0
    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000e:  ldarg.0
    IL_000f:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0014:  ldloc.0
    IL_0015:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnOnDropText(object,
                                                                                 class AxPFSPlotLib._DPfsplotEvents_OnDropTextEvent)
    IL_001a:  ret
  } // end of method AxPfsplotEventMulticaster::OnDropText

  .method public hidebysig newslot virtual 
          instance void  ReloadNow() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnReloadNow(object,
                                                                                class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::ReloadNow

  .method public hidebysig newslot virtual 
          instance void  OnEditProfileVariables() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnOnEditProfileVariables(object,
                                                                                             class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::OnEditProfileVariables

  .method public hidebysig newslot virtual 
          instance void  OnOnShowasHistory() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnOnOnShowasHistory(object,
                                                                                        class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::OnOnShowasHistory

  .method public hidebysig newslot virtual 
          instance void  OnEditProfileTable() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnOnEditProfileTable(object,
                                                                                         class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::OnEditProfileTable

  .method public hidebysig newslot virtual 
          instance void  OnResetFormDefinition() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnOnResetFormDefinition(object,
                                                                                            class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::OnResetFormDefinition

  .method public hidebysig newslot virtual 
          instance void  SetMessageText(string text) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent::.ctor(string)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnSetMessageText(object,
                                                                                     class AxPFSPlotLib._DPfsplotEvents_SetMessageTextEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::SetMessageText

  .method public hidebysig newslot virtual 
          instance void  CommunicationIntervalsSet(int16 intervals) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent::.ctor(int16)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnCommunicationIntervalsSet(object,
                                                                                                class AxPFSPlotLib._DPfsplotEvents_CommunicationIntervalsSetEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::CommunicationIntervalsSet

  .method public hidebysig newslot virtual 
          instance void  PointerLocation(string coordinate,
                                         int16 ix,
                                         int16 iy) cil managed
  {
    // Code size       28 (0x1c)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent::.ctor(string,
                                                                                                int16,
                                                                                                int16)
    IL_0008:  stloc.0
    IL_0009:  ldarg.0
    IL_000a:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000f:  ldarg.0
    IL_0010:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0015:  ldloc.0
    IL_0016:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnPointerLocation(object,
                                                                                      class AxPFSPlotLib._DPfsplotEvents_PointerLocationEvent)
    IL_001b:  ret
  } // end of method AxPfsplotEventMulticaster::PointerLocation

  .method public hidebysig newslot virtual 
          instance void  OnClick(float64 x,
                                 float64 y,
                                 int16 ix,
                                 int16 iy,
                                 int16 objectID,
                                 int16 modifier) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  6
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnClickEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  ldarg.s    iy
    IL_0005:  ldarg.s    objectID
    IL_0007:  ldarg.s    modifier
    IL_0009:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_OnClickEvent::.ctor(float64,
                                                                                        float64,
                                                                                        int16,
                                                                                        int16,
                                                                                        int16,
                                                                                        int16)
    IL_000e:  stloc.0
    IL_000f:  ldarg.0
    IL_0010:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0015:  ldarg.0
    IL_0016:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_001b:  ldloc.0
    IL_001c:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnOnClick(object,
                                                                              class AxPFSPlotLib._DPfsplotEvents_OnClickEvent)
    IL_0021:  ret
  } // end of method AxPfsplotEventMulticaster::OnClick

  .method public hidebysig newslot virtual 
          instance void  OnDoubleClick(float64 x,
                                       float64 y,
                                       int16 ix,
                                       int16 iy,
                                       int16 objectID,
                                       int16 modifier) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  6
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  ldarg.s    iy
    IL_0005:  ldarg.s    objectID
    IL_0007:  ldarg.s    modifier
    IL_0009:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent::.ctor(float64,
                                                                                              float64,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16,
                                                                                              int16)
    IL_000e:  stloc.0
    IL_000f:  ldarg.0
    IL_0010:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0015:  ldarg.0
    IL_0016:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_001b:  ldloc.0
    IL_001c:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnOnDoubleClick(object,
                                                                                    class AxPFSPlotLib._DPfsplotEvents_OnDoubleClickEvent)
    IL_0021:  ret
  } // end of method AxPfsplotEventMulticaster::OnDoubleClick

  .method public hidebysig newslot virtual 
          instance void  CursorSet() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnCursorSet(object,
                                                                                class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::CursorSet

  .method public hidebysig newslot virtual 
          instance void  OnRBClick(float64 x,
                                   float64 y,
                                   int16 ix,
                                   int16 iy,
                                   int16 objectID,
                                   int16 modifier) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  6
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  ldarg.s    iy
    IL_0005:  ldarg.s    objectID
    IL_0007:  ldarg.s    modifier
    IL_0009:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent::.ctor(float64,
                                                                                          float64,
                                                                                          int16,
                                                                                          int16,
                                                                                          int16,
                                                                                          int16)
    IL_000e:  stloc.0
    IL_000f:  ldarg.0
    IL_0010:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0015:  ldarg.0
    IL_0016:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_001b:  ldloc.0
    IL_001c:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnOnRBClick(object,
                                                                                class AxPFSPlotLib._DPfsplotEvents_OnRBClickEvent)
    IL_0021:  ret
  } // end of method AxPfsplotEventMulticaster::OnRBClick

  .method public hidebysig newslot virtual 
          instance void  RegionDefined() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnRegionDefined(object,
                                                                                    class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::RegionDefined

  .method public hidebysig newslot virtual 
          instance void  KeyPress(int32 keyAscii) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_KeyPressEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_KeyPressEvent::.ctor(int32)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnKeyPressEvent(object,
                                                                                    class AxPFSPlotLib._DPfsplotEvents_KeyPressEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::KeyPress

  .method public hidebysig newslot virtual 
          instance void  KeyDown(int32 keyCode,
                                 int32 shift) cil managed
  {
    // Code size       27 (0x1b)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_KeyDownEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_KeyDownEvent::.ctor(int32,
                                                                                        int32)
    IL_0007:  stloc.0
    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000e:  ldarg.0
    IL_000f:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0014:  ldloc.0
    IL_0015:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnKeyDownEvent(object,
                                                                                   class AxPFSPlotLib._DPfsplotEvents_KeyDownEvent)
    IL_001a:  ret
  } // end of method AxPfsplotEventMulticaster::KeyDown

  .method public hidebysig newslot virtual 
          instance void  KeyUp(int32 keyCode,
                               int32 shift) cil managed
  {
    // Code size       27 (0x1b)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_KeyUpEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_KeyUpEvent::.ctor(int32,
                                                                                      int32)
    IL_0007:  stloc.0
    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000e:  ldarg.0
    IL_000f:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0014:  ldloc.0
    IL_0015:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnKeyUpEvent(object,
                                                                                 class AxPFSPlotLib._DPfsplotEvents_KeyUpEvent)
    IL_001a:  ret
  } // end of method AxPfsplotEventMulticaster::KeyUp

  .method public hidebysig newslot virtual 
          instance void  Scrolled(bool horizontal) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_ScrolledEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_ScrolledEvent::.ctor(bool)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnScrolled(object,
                                                                               class AxPFSPlotLib._DPfsplotEvents_ScrolledEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::Scrolled

  .method public hidebysig newslot virtual 
          instance void  PointerExit() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnPointerExit(object,
                                                                                  class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::PointerExit

  .method public hidebysig newslot virtual 
          instance void  PhaseVariableSet(string variablePath) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent::.ctor(string)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnPhaseVariableSet(object,
                                                                                       class AxPFSPlotLib._DPfsplotEvents_PhaseVariableSetEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::PhaseVariableSet

  .method public hidebysig newslot virtual 
          instance void  PhaseVariableDropped(string sVarName) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent::.ctor(string)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnPhaseVariableDropped(object,
                                                                                           class AxPFSPlotLib._DPfsplotEvents_PhaseVariableDroppedEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::PhaseVariableDropped

  .method public hidebysig newslot virtual 
          instance void  ZoomTimeRange() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnZoomTimeRange(object,
                                                                                    class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::ZoomTimeRange

  .method public hidebysig newslot virtual 
          instance void  RevertToTimePlot() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnRevertToTimePlot(object,
                                                                                       class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::RevertToTimePlot

  .method public hidebysig newslot virtual 
          instance void  OnLivePlot(bool set) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent::.ctor(bool)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnOnLivePlot(object,
                                                                                 class AxPFSPlotLib._DPfsplotEvents_OnLivePlotEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::OnLivePlot

  .method public hidebysig newslot virtual 
          instance void  SetCaption(string text) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent::.ctor(string)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnSetCaption(object,
                                                                                 class AxPFSPlotLib._DPfsplotEvents_SetCaptionEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::SetCaption

  .method public hidebysig newslot virtual 
          instance void  Modified() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnModified(object,
                                                                               class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxPfsplotEventMulticaster::Modified

  .method public hidebysig newslot virtual 
          instance void  PlotDrawn(bool onOff) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent::.ctor(bool)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnPlotDrawn(object,
                                                                                class AxPFSPlotLib._DPfsplotEvents_PlotDrawnEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::PlotDrawn

  .method public hidebysig newslot virtual 
          instance void  ZoomDone(float32 fZoomVal) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent::.ctor(float32)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnZoomDone(object,
                                                                               class AxPFSPlotLib._DPfsplotEvents_ZoomDoneEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::ZoomDone

  .method public hidebysig newslot virtual 
          instance void  OnDropFiles(string varFiles) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent::.ctor(string)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnOnDropFiles(object,
                                                                                  class AxPFSPlotLib._DPfsplotEvents_OnDropFilesEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::OnDropFiles

  .method public hidebysig newslot virtual 
          instance void  FlippedFlagChanged(bool bFlipped) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent::.ctor(bool)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxPFSPlotLib.AxPfsplot AxPFSPlotLib.AxPfsplotEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxPFSPlotLib.AxPfsplot::RaiseOnFlippedFlagChanged(object,
                                                                                         class AxPFSPlotLib._DPfsplotEvents_FlippedFlagChangedEvent)
    IL_0019:  ret
  } // end of method AxPfsplotEventMulticaster::FlippedFlagChanged

} // end of class AxPFSPlotLib.AxPfsplotEventMulticaster


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file orig.ildasm.res
