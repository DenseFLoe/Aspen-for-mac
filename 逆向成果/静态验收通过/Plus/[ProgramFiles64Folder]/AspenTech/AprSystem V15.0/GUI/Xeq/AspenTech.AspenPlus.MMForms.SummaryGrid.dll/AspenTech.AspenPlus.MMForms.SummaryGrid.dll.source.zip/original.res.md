# original.res

Includes the original verified Win32 version resource.
