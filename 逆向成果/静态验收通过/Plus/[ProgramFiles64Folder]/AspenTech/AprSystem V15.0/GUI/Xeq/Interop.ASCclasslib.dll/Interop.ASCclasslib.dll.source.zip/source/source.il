﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  AspenTech.AspenPlus.ASCclasslib.IASCObject
  AspenTech.AspenPlus.ASCclasslib.IASCSimulation
  AspenTech.AspenPlus.ASCclasslib.IASCSimulation2
  AspenTech.AspenPlus.ASCclasslib.ASCSimulation
  AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass
  AspenTech.AspenPlus.ASCclasslib.IASCBlock
  AspenTech.AspenPlus.ASCclasslib.ASCBlock
  AspenTech.AspenPlus.ASCclasslib.ASCBlockClass
  AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection
  AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection
  AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection
  AspenTech.AspenPlus.ASCclasslib.ASCBlockCollectionClass
  AspenTech.AspenPlus.ASCclasslib.IASCVariable
  AspenTech.AspenPlus.ASCclasslib.ASCVariable
  AspenTech.AspenPlus.ASCclasslib.ASCVariableClass
  AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection
  AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection
  AspenTech.AspenPlus.ASCclasslib.ASCVariableCollectionClass
  AspenTech.AspenPlus.ASCclasslib.IASCEquation
  AspenTech.AspenPlus.ASCclasslib.ASCEquation
  AspenTech.AspenPlus.ASCclasslib.ASCEquationClass
  AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection
  AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection
  AspenTech.AspenPlus.ASCclasslib.ASCEquationCollectionClass
  AspenTech.AspenPlus.ASCclasslib.IASCPort
  AspenTech.AspenPlus.ASCclasslib.IASCPort2
  AspenTech.AspenPlus.ASCclasslib.ASCPort
  AspenTech.AspenPlus.ASCclasslib.ASCPortClass
  AspenTech.AspenPlus.ASCclasslib.IASCPortCollection
  AspenTech.AspenPlus.ASCclasslib.ASCPortCollection
  AspenTech.AspenPlus.ASCclasslib.ASCPortCollectionClass
  AspenTech.AspenPlus.ASCclasslib.IASCSolver
  AspenTech.AspenPlus.ASCclasslib.ASCSolver
  AspenTech.AspenPlus.ASCclasslib.ASCSolverClass
  AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection
  AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection
  AspenTech.AspenPlus.ASCclasslib.ASCSolverCollectionClass
  AspenTech.AspenPlus.ASCclasslib.IASCParameters
  AspenTech.AspenPlus.ASCclasslib.ASCParameters
  AspenTech.AspenPlus.ASCclasslib.ASCParametersClass
  AspenTech.AspenPlus.ASCclasslib.IASCParameter
  AspenTech.AspenPlus.ASCclasslib.IASCParameter2
  AspenTech.AspenPlus.ASCclasslib.IASCParameter3
  AspenTech.AspenPlus.ASCclasslib.ASCParameter
  AspenTech.AspenPlus.ASCclasslib.ASCParameterClass
  AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection
  AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection
  AspenTech.AspenPlus.ASCclasslib.ASCParameterCollectionClass
  AspenTech.AspenPlus.ASCclasslib.IEBScriptService
  AspenTech.AspenPlus.ASCclasslib.EBScriptService
  AspenTech.AspenPlus.ASCclasslib.EBScriptServiceClass
  AspenTech.AspenPlus.ASCclasslib.IASCEditBlock
  AspenTech.AspenPlus.ASCclasslib.ASCEditBlock
  AspenTech.AspenPlus.ASCclasslib.ASCEditBlockClass
  AspenTech.AspenPlus.ASCclasslib.IASCEditLibraries
  AspenTech.AspenPlus.ASCclasslib.ASCEditLibraries
  AspenTech.AspenPlus.ASCclasslib.ASCEditLibrariesClass
  AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_Event
  AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgs
  AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event
  AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass
  AspenTech.AspenPlus.ASCclasslib.IASCGridService
  AspenTech.AspenPlus.ASCclasslib.ASCVariableGrid
  AspenTech.AspenPlus.ASCclasslib.ASCVariableGridClass
  AspenTech.AspenPlus.ASCclasslib.ASCEquationGrid
  AspenTech.AspenPlus.ASCclasslib.ASCEquationGridClass
  AspenTech.AspenPlus.ASCclasslib.IASCSensitivity
  AspenTech.AspenPlus.ASCclasslib.ASCSensitivity
  AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass
  AspenTech.AspenPlus.ASCclasslib.IASCSimEventMgr
  AspenTech.AspenPlus.ASCclasslib.ASCSimEventMgr
  AspenTech.AspenPlus.ASCclasslib.ASCSimEventMgrClass
  AspenTech.AspenPlus.ASCclasslib.IASCSimEventLock
  AspenTech.AspenPlus.ASCclasslib.ASCSimEventLock
  AspenTech.AspenPlus.ASCclasslib.ASCSimEventLockClass
  AspenTech.AspenPlus.ASCclasslib.IASCInterfaceHolder
  AspenTech.AspenPlus.ASCclasslib.ASCInterfaceHolder
  AspenTech.AspenPlus.ASCclasslib.ASCInterfaceHolderClass
  AspenTech.AspenPlus.ASCclasslib.IASCExternalFileService
  AspenTech.AspenPlus.ASCclasslib.ASCExternalFileService
  AspenTech.AspenPlus.ASCclasslib.ASCExternalFileServiceClass
  AspenTech.AspenPlus.ASCclasslib.ASCPortGrid
  AspenTech.AspenPlus.ASCclasslib.ASCPortGridClass
  AspenTech.AspenPlus.ASCclasslib.ASCParameterGrid
  AspenTech.AspenPlus.ASCclasslib.ASCParameterGridClass
  AspenTech.AspenPlus.ASCclasslib.IASCGridInfo
  AspenTech.AspenPlus.ASCclasslib.ASCGridInfo
  AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass
  AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo
  AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfo
  AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfoClass
  AspenTech.AspenPlus.ASCclasslib.IASCGridStaticControl
  AspenTech.AspenPlus.ASCclasslib.ASCGridStaticControl
  AspenTech.AspenPlus.ASCclasslib.ASCGridStaticControlClass
  AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl
  AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControl
  AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControlClass
  AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl
  AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControl
  AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControlClass
  AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl
  AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxControl
  AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxControlClass
  AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem
  AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxItem
  AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxItemClass
  AspenTech.AspenPlus.ASCclasslib.IASCGridColumnCollection
  AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollection
  AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollectionClass
  AspenTech.AspenPlus.ASCclasslib.IASCGridStyleCollection
  AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollection
  AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollectionClass
  AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService
  AspenTech.AspenPlus.ASCclasslib.ASCDynamicsService
  AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService2
  AspenTech.AspenPlus.ASCclasslib.ASCDynamicsServiceClass
  AspenTech.AspenPlus.ASCclasslib.IASCVariableProfile
  AspenTech.AspenPlus.ASCclasslib.ASCVariableProfile
  AspenTech.AspenPlus.ASCclasslib.ASCVariableProfileClass
  AspenTech.AspenPlus.ASCclasslib.ASCSpec
  AspenTech.AspenPlus.ASCclasslib.ASCActiveBound
  AspenTech.AspenPlus.ASCclasslib.ASCVarQuality
  AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType
  AspenTech.AspenPlus.ASCclasslib.ASCPortDir
  AspenTech.AspenPlus.ASCclasslib.ASCPortType
  AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler
  AspenTech.AspenPlus.ASCclasslib.IASCSimEventSink
  AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType
  AspenTech.AspenPlus.ASCclasslib.ASCControlType
  AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState
  AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0003
  AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0004
  AspenTech.AspenPlus.ASCclasslib.IASCObjectCollectionHelper
  AspenTech.AspenPlus.ASCclasslib.IASCBlock2
  AspenTech.AspenPlus.ASCclasslib.IASCVariable2
  AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam
  AspenTech.AspenPlus.ASCclasslib.IASCVariable3
  AspenTech.AspenPlus.ASCclasslib.ASCVariableType
  AspenTech.AspenPlus.ASCclasslib.IASCVariable4
  AspenTech.AspenPlus.ASCclasslib.IASCVariable5
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper
  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly Interop.ASCclasslib
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 32 2D 44 42 33 36   // ..$00400002-DB36
                                                                                                  2D 34 32 45 37 2D 42 36 43 34 2D 43 30 33 35 44   // -42E7-B6C4-C035D
                                                                                                  44 34 36 33 37 30 37 00 00 )                      // D463707..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ImportedFromTypeLibAttribute::.ctor(string) = ( 01 00 0E 41 53 43 43 6C 61 73 73 4C 69 62 34 30   // ...ASCClassLib40
                                                                                                                 30 00 00 )                                        // 0..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibVersionAttribute::.ctor(int32,
                                                                                                int32) = ( 01 00 28 00 00 00 00 00 00 00 00 00 )             // ..(.........
  .publickey = (00 24 00 00 04 80 00 00 94 00 00 00 06 02 00 00   // .$..............
                00 24 00 00 52 53 41 31 00 04 00 00 01 00 01 00   // .$..RSA1........
                31 CE F7 DF 85 4A 51 60 93 9C 58 8A 09 81 30 D8   // 1....JQ`..X...0.
                3B 58 C6 41 43 FE 98 DE 4F EA 84 44 85 EE C0 F8   // ;X.AC...O..D....
                BF 75 0A 6A 39 BA 8A 55 2E 37 20 73 B6 95 3A 09   // .u.j9..U.7 s..:.
                53 17 FB FB A3 6E B8 37 F2 D0 14 D6 2D 52 2D 2C   // S....n.7....-R-,
                B2 4F 39 B6 12 E0 DA 27 6D BF 15 4A 5D 0F 84 0D   // .O9....'m..J]...
                59 7F 81 E6 0E 83 1D 25 B6 EB C3 47 9D 69 C3 A6   // Y......%...G.i..
                6A 21 E7 D3 A8 62 09 D1 D3 50 BB 90 86 82 98 3C   // j!...b...P.....<
                80 C0 F7 D4 3B 60 C3 48 79 73 35 A7 33 B2 61 C8 ) // ....;`.Hys5.3.a.
  .hash algorithm 0x00008004
  .ver 40:0:0:0
}
.module Interop.ASCclasslib.dll
// MVID: {20e5e23b-9a70-447c-bce5-a7f8848f65be}
.imagebase 0x00400000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000009    //  ILONLY
// Image base: 0x0000020444210000


// =============== CLASS MEMBERS DECLARATION ===================

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 31 2D 46 37 30 34   // ..$00400001-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCObject::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCObject::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCObject::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCObject::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCObject::GetService

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCObject::get_Parent()
  } // end of property IASCObject::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCObject::get_Simulation()
  } // end of property IASCObject::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCObject::get_Name()
  } // end of property IASCObject::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCObject::get_IsValid()
  } // end of property IASCObject::IsValid
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCObject

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCSimulation
       implements AspenTech.AspenPlus.ASCclasslib.IASCObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 33 2D 46 37 30 34   // ..$00400003-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_BuildVersion() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::get_BuildVersion

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCBlock 
          marshal( interface ) 
          get_Flowsheet() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::get_Flowsheet

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection 
          marshal( interface ) 
          get_Solvers() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::get_Solvers

  .method public hidebysig newslot abstract virtual 
          instance void  PushScope([in] string  marshal( bstr) pbScope) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::PushScope

  .method public hidebysig newslot abstract virtual 
          instance void  PopScope() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::PopScope

  .method public hidebysig newslot abstract virtual 
          instance void  ResetScope() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::ResetScope

  .method public hidebysig newslot abstract virtual 
          instance void  Solve() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::Solve

  .method public hidebysig newslot abstract virtual 
          instance void  SolveWithObjective([in] string  marshal( bstr) bObjective) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::SolveWithObjective

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_DefaultObjective([in] string  marshal( bstr) pObjective) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::set_DefaultObjective

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_DefaultObjective() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::get_DefaultObjective

  .method public hidebysig newslot abstract virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation::TriggerCancel

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCSimulation::get_Parent()
  } // end of property IASCSimulation::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCSimulation::get_Simulation()
  } // end of property IASCSimulation::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCSimulation::get_Name()
  } // end of property IASCSimulation::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCSimulation::get_IsValid()
  } // end of property IASCSimulation::IsValid
  .property callconv(8) string BuildVersion()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCSimulation::get_BuildVersion()
  } // end of property IASCSimulation::BuildVersion
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCBlock
          Flowsheet()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCBlock AspenTech.AspenPlus.ASCclasslib.IASCSimulation::get_Flowsheet()
  } // end of property IASCSimulation::Flowsheet
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection
          Solvers()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection AspenTech.AspenPlus.ASCclasslib.IASCSimulation::get_Solvers()
  } // end of property IASCSimulation::Solvers
  .property callconv(8) string DefaultObjective()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCSimulation::set_DefaultObjective(string)
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCSimulation::get_DefaultObjective()
  } // end of property IASCSimulation::DefaultObjective
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCSimulation

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCSimulation2
       implements AspenTech.AspenPlus.ASCclasslib.IASCSimulation
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 37 2D 46 37 30 34   // ..$00400047-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_BuildVersion() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::get_BuildVersion

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCBlock 
          marshal( interface ) 
          get_Flowsheet() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::get_Flowsheet

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection 
          marshal( interface ) 
          get_Solvers() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::get_Solvers

  .method public hidebysig newslot abstract virtual 
          instance void  PushScope([in] string  marshal( bstr) pbScope) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::PushScope

  .method public hidebysig newslot abstract virtual 
          instance void  PopScope() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::PopScope

  .method public hidebysig newslot abstract virtual 
          instance void  ResetScope() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::ResetScope

  .method public hidebysig newslot abstract virtual 
          instance void  Solve() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::Solve

  .method public hidebysig newslot abstract virtual 
          instance void  SolveWithObjective([in] string  marshal( bstr) bObjective) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::SolveWithObjective

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_DefaultObjective([in] string  marshal( bstr) pObjective) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::set_DefaultObjective

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_DefaultObjective() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::get_DefaultObjective

  .method public hidebysig newslot abstract virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::TriggerCancel

  .method public hidebysig newslot abstract virtual 
          instance void  SaveSimulation([in] string  marshal( bstr) bFilePath) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::SaveSimulation

  .method public hidebysig newslot abstract virtual 
          instance void  OpenSimulation([in] string  marshal( bstr) bFilePath) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::OpenSimulation

  .method public hidebysig newslot abstract virtual 
          instance void  AddSimulation([in] string  marshal( bstr) bFilePath) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::AddSimulation

  .method public hidebysig newslot abstract virtual 
          instance void  SaveBlock([in] string  marshal( bstr) bFilePath,
                                   [in] string  marshal( bstr) bBlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::SaveBlock

  .method public hidebysig newslot abstract virtual 
          instance void  LoadBlock([in] string  marshal( bstr) bFilePath) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSimulation2::LoadBlock

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_Parent()
  } // end of property IASCSimulation2::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_Simulation()
  } // end of property IASCSimulation2::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_Name()
  } // end of property IASCSimulation2::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_IsValid()
  } // end of property IASCSimulation2::IsValid
  .property callconv(8) string BuildVersion()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_BuildVersion()
  } // end of property IASCSimulation2::BuildVersion
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCBlock
          Flowsheet()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCBlock AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_Flowsheet()
  } // end of property IASCSimulation2::Flowsheet
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection
          Solvers()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_Solvers()
  } // end of property IASCSimulation2::Solvers
  .property callconv(8) string DefaultObjective()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_DefaultObjective()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::set_DefaultObjective(string)
  } // end of property IASCSimulation2::DefaultObjective
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCSimulation2

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSimulation
       implements AspenTech.AspenPlus.ASCclasslib.IASCSimulation2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 32 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..2AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 53 69 6D 75 6C 61 74 69 6F 6E   // ib.ASCSimulation
                                                                                                                          43 6C 61 73 73 00 00 )                            // Class..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 37 2D 46 37 30 34   // ..$00400047-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSimulation

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCSimulation2,
                  AspenTech.AspenPlus.ASCclasslib.ASCSimulation
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 31 2D 30 38 37 41   // ..$00400001-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCSimulationClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_Parent
  } // end of method ASCSimulationClass::get_Parent

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_Simulation
  } // end of method ASCSimulationClass::get_Simulation

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_Name
  } // end of method ASCSimulationClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_IsValid
  } // end of method ASCSimulationClass::get_IsValid

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::GetService
  } // end of method ASCSimulationClass::GetService

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_BuildVersion() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_BuildVersion
  } // end of method ASCSimulationClass::get_BuildVersion

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCBlock 
          marshal( interface ) 
          get_Flowsheet() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_Flowsheet
  } // end of method ASCSimulationClass::get_Flowsheet

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection 
          marshal( interface ) 
          get_Solvers() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_Solvers
  } // end of method ASCSimulationClass::get_Solvers

  .method public hidebysig newslot virtual 
          instance void  PushScope([in] string  marshal( bstr) pbScope) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::PushScope
  } // end of method ASCSimulationClass::PushScope

  .method public hidebysig newslot virtual 
          instance void  PopScope() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::PopScope
  } // end of method ASCSimulationClass::PopScope

  .method public hidebysig newslot virtual 
          instance void  ResetScope() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::ResetScope
  } // end of method ASCSimulationClass::ResetScope

  .method public hidebysig newslot virtual 
          instance void  Solve() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::Solve
  } // end of method ASCSimulationClass::Solve

  .method public hidebysig newslot virtual 
          instance void  SolveWithObjective([in] string  marshal( bstr) bObjective) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::SolveWithObjective
  } // end of method ASCSimulationClass::SolveWithObjective

  .method public hidebysig newslot specialname virtual 
          instance void  set_DefaultObjective([in] string  marshal( bstr) pObjective) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::set_DefaultObjective
  } // end of method ASCSimulationClass::set_DefaultObjective

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_DefaultObjective() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::get_DefaultObjective
  } // end of method ASCSimulationClass::get_DefaultObjective

  .method public hidebysig newslot virtual 
          instance void  TriggerCancel([in] int16 level) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::TriggerCancel
  } // end of method ASCSimulationClass::TriggerCancel

  .method public hidebysig newslot virtual 
          instance void  SaveSimulation([in] string  marshal( bstr) bFilePath) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::SaveSimulation
  } // end of method ASCSimulationClass::SaveSimulation

  .method public hidebysig newslot virtual 
          instance void  OpenSimulation([in] string  marshal( bstr) bFilePath) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::OpenSimulation
  } // end of method ASCSimulationClass::OpenSimulation

  .method public hidebysig newslot virtual 
          instance void  AddSimulation([in] string  marshal( bstr) bFilePath) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::AddSimulation
  } // end of method ASCSimulationClass::AddSimulation

  .method public hidebysig newslot virtual 
          instance void  SaveBlock([in] string  marshal( bstr) bFilePath,
                                   [in] string  marshal( bstr) bBlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::SaveBlock
  } // end of method ASCSimulationClass::SaveBlock

  .method public hidebysig newslot virtual 
          instance void  LoadBlock([in] string  marshal( bstr) bFilePath) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulation2::LoadBlock
  } // end of method ASCSimulationClass::LoadBlock

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass::get_Parent()
  } // end of property ASCSimulationClass::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass::get_Simulation()
  } // end of property ASCSimulationClass::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass::get_Name()
  } // end of property ASCSimulationClass::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass::get_IsValid()
  } // end of property ASCSimulationClass::IsValid
  .property callconv(8) string BuildVersion()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass::get_BuildVersion()
  } // end of property ASCSimulationClass::BuildVersion
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCBlock
          Flowsheet()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCBlock AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass::get_Flowsheet()
  } // end of property ASCSimulationClass::Flowsheet
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection
          Solvers()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass::get_Solvers()
  } // end of property ASCSimulationClass::Solvers
  .property callconv(8) string DefaultObjective()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass::get_DefaultObjective()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass::set_DefaultObjective(string)
  } // end of property ASCSimulationClass::DefaultObjective
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSimulationClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCBlock
       implements AspenTech.AspenPlus.ASCclasslib.IASCObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 34 2D 46 37 30 34   // ..$00400004-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlock::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlock::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlock::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlock::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlock::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsBlockContainer() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock::get_IsBlockContainer

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection 
          marshal( interface ) 
          get_Blocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock::get_Blocks

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection 
          marshal( interface ) 
          get_Variables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock::get_Variables

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection 
          marshal( interface ) 
          get_Equations() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock::get_Equations

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection 
          marshal( interface ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock::get_Parameters

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCPortCollection 
          marshal( interface ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock::get_Ports

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Parent()
  } // end of property IASCBlock::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Simulation()
  } // end of property IASCBlock::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Name()
  } // end of property IASCBlock::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_IsValid()
  } // end of property IASCBlock::IsValid
  .property callconv(8) bool IsBlockContainer()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_IsBlockContainer()
  } // end of property IASCBlock::IsBlockContainer
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection
          Blocks()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Blocks()
  } // end of property IASCBlock::Blocks
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection
          Variables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Variables()
  } // end of property IASCBlock::Variables
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection
          Equations()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Equations()
  } // end of property IASCBlock::Equations
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection
          Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Parameters()
  } // end of property IASCBlock::Parameters
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCPortCollection
          Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCPortCollection AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Ports()
  } // end of property IASCBlock::Ports
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCBlock

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCBlock
       implements AspenTech.AspenPlus.ASCclasslib.IASCBlock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 2D 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..-AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 42 6C 6F 63 6B 43 6C 61 73 73   // ib.ASCBlockClass
                                                                                                                          00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 34 2D 46 37 30 34   // ..$00400004-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCBlock

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCBlockClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCBlock,
                  AspenTech.AspenPlus.ASCclasslib.ASCBlock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 32 2D 30 38 37 41   // ..$00400002-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCBlockClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Parent
  } // end of method ASCBlockClass::get_Parent

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Simulation
  } // end of method ASCBlockClass::get_Simulation

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Name
  } // end of method ASCBlockClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_IsValid
  } // end of method ASCBlockClass::get_IsValid

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::GetService
  } // end of method ASCBlockClass::GetService

  .method public hidebysig newslot specialname virtual 
          instance bool  get_IsBlockContainer() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_IsBlockContainer
  } // end of method ASCBlockClass::get_IsBlockContainer

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection 
          marshal( interface ) 
          get_Blocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Blocks
  } // end of method ASCBlockClass::get_Blocks

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection 
          marshal( interface ) 
          get_Variables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Variables
  } // end of method ASCBlockClass::get_Variables

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection 
          marshal( interface ) 
          get_Equations() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Equations
  } // end of method ASCBlockClass::get_Equations

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection 
          marshal( interface ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Parameters
  } // end of method ASCBlockClass::get_Parameters

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCPortCollection 
          marshal( interface ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlock::get_Ports
  } // end of method ASCBlockClass::get_Ports

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCBlockClass::get_Parent()
  } // end of property ASCBlockClass::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.ASCBlockClass::get_Simulation()
  } // end of property ASCBlockClass::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCBlockClass::get_Name()
  } // end of property ASCBlockClass::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCBlockClass::get_IsValid()
  } // end of property ASCBlockClass::IsValid
  .property callconv(8) bool IsBlockContainer()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCBlockClass::get_IsBlockContainer()
  } // end of property ASCBlockClass::IsBlockContainer
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection
          Blocks()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection AspenTech.AspenPlus.ASCclasslib.ASCBlockClass::get_Blocks()
  } // end of property ASCBlockClass::Blocks
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection
          Variables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection AspenTech.AspenPlus.ASCclasslib.ASCBlockClass::get_Variables()
  } // end of property ASCBlockClass::Variables
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection
          Equations()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection AspenTech.AspenPlus.ASCclasslib.ASCBlockClass::get_Equations()
  } // end of property ASCBlockClass::Equations
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection
          Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection AspenTech.AspenPlus.ASCclasslib.ASCBlockClass::get_Parameters()
  } // end of property ASCBlockClass::Parameters
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCPortCollection
          Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCPortCollection AspenTech.AspenPlus.ASCclasslib.ASCBlockClass::get_Ports()
  } // end of property ASCBlockClass::Ports
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCBlockClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection
       implements [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 32 2D 46 37 30 34   // ..$00400002-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCObjectCollection::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IASCObjectCollection::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCObjectCollection::get_Count

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCObjectCollection::Find

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCObjectCollection::GetService

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
  } // end of method IASCObjectCollection::GetAttributes

  .method public hidebysig newslot abstract virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
  } // end of method IASCObjectCollection::SetAttributes

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection::get_Item(int32)
  } // end of property IASCObjectCollection::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection::get_Count()
  } // end of property IASCObjectCollection::Count
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 35 2D 46 37 30 34   // ..$00400005-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCBlockCollection::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method IASCBlockCollection::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlockCollection::get_Count

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlockCollection::Find

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlockCollection::GetService

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
  } // end of method IASCBlockCollection::GetAttributes

  .method public hidebysig newslot abstract virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
  } // end of method IASCBlockCollection::SetAttributes

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCBlock 
          marshal( interface ) 
          get_Block([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlockCollection::get_Block

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::get_Item(int32)
  } // end of property IASCBlockCollection::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::get_Count()
  } // end of property IASCBlockCollection::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCBlock
          Block(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCBlock AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::get_Block(object)
  } // end of property IASCBlockCollection::Block
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 35 2D 46 37 30 34   // ..$00400005-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 37 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..7AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 42 6C 6F 63 6B 43 6F 6C 6C 65   // ib.ASCBlockColle
                                                                                                                          63 74 69 6F 6E 43 6C 61 73 73 00 00 )             // ctionClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCBlockCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection,
                  AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 38 2D 30 38 37 41   // ..$00400008-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCBlockCollectionClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::get_Item
  } // end of method ASCBlockCollectionClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::GetEnumerator
  } // end of method ASCBlockCollectionClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::get_Count
  } // end of method ASCBlockCollectionClass::get_Count

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::Find
  } // end of method ASCBlockCollectionClass::Find

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::GetService
  } // end of method ASCBlockCollectionClass::GetService

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::GetAttributes
  } // end of method ASCBlockCollectionClass::GetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::SetAttributes
  } // end of method ASCBlockCollectionClass::SetAttributes

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCBlock 
          marshal( interface ) 
          get_Block([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCBlockCollection::get_Block
  } // end of method ASCBlockCollectionClass::get_Block

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCBlockCollectionClass::get_Item(int32)
  } // end of property ASCBlockCollectionClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCBlockCollectionClass::get_Count()
  } // end of property ASCBlockCollectionClass::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCBlock
          Block(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCBlock AspenTech.AspenPlus.ASCclasslib.ASCBlockCollectionClass::get_Block(object)
  } // end of property ASCBlockCollectionClass::Block
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCVariable
       implements AspenTech.AspenPlus.ASCclasslib.IASCObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 36 2D 46 37 30 34   // ..$00400006-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Value([in] float64 Value) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_LowerBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_LowerBound

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_LowerBound([in] float64 Lower) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_LowerBound

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_UpperBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_UpperBound

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UpperBound([in] float64 Upper) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_UpperBound

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec 
          get_Spec() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Spec

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Spec([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec Spec) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_Spec

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Scale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Scale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Scale([in] float64 Scale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_Scale

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_SBWeight() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_SBWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_SBWeight([in] float64 Weight) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_SBWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_ShadowPrice() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_ShadowPrice

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ShadowPrice([in] float64 Price) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_ShadowPrice

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Marked() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Marked

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Marked([in] bool Marked) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_Marked

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Modified([in] string  marshal( bstr) Attrib) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Modified

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Modified([in] string  marshal( bstr) Attrib,
                                      [in] bool Modified) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_Modified

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound 
          get_ActiveBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_ActiveBound

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality 
          get_Quality() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Quality

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Quality([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality Quality) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_Quality

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_UOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UOM([in] string  marshal( bstr) pbUOM) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Initial() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Initial

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Initial([in] float64 Initial) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_Initial

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Change() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Change

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Change([in] float64 Change) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_Change

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Number() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Number

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType 
          get_BoundType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_BoundType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_BoundType([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType BoundType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_BoundType

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_InternalScale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_InternalScale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_InternalScale([in] float64 intscale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_InternalScale

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Step() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_Step

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Step([in] float64 Step) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::set_Step

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_PhysicalType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_PhysicalType

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_UOMList() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable::get_UOMList

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Parent()
  } // end of property IASCVariable::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Simulation()
  } // end of property IASCVariable::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Name()
  } // end of property IASCVariable::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_IsValid()
  } // end of property IASCVariable::IsValid
  .property callconv(8) float64 Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Value()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Value(float64)
  } // end of property IASCVariable::Value
  .property callconv(8) float64 LowerBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_LowerBound()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_LowerBound(float64)
  } // end of property IASCVariable::LowerBound
  .property callconv(8) float64 UpperBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_UpperBound(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_UpperBound()
  } // end of property IASCVariable::UpperBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec
          Spec()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Spec(valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec)
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Spec()
  } // end of property IASCVariable::Spec
  .property callconv(8) float64 Scale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Scale()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Scale(float64)
  } // end of property IASCVariable::Scale
  .property callconv(8) float64 SBWeight()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_SBWeight(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_SBWeight()
  } // end of property IASCVariable::SBWeight
  .property callconv(8) float64 ShadowPrice()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_ShadowPrice(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_ShadowPrice()
  } // end of property IASCVariable::ShadowPrice
  .property callconv(8) bool Marked()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Marked(bool)
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Marked()
  } // end of property IASCVariable::Marked
  .property callconv(8) bool Modified(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Modified(string)
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Modified(string,
                                                                                  bool)
  } // end of property IASCVariable::Modified
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound
          ActiveBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_ActiveBound()
  } // end of property IASCVariable::ActiveBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality
          Quality()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Quality()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Quality(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality)
  } // end of property IASCVariable::Quality
  .property callconv(8) string UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_UOM()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_UOM(string)
  } // end of property IASCVariable::UOM
  .property callconv(8) float64 Initial()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Initial(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Initial()
  } // end of property IASCVariable::Initial
  .property callconv(8) float64 Change()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Change()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Change(float64)
  } // end of property IASCVariable::Change
  .property callconv(8) int32 Number()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Number()
  } // end of property IASCVariable::Number
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType
          BoundType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_BoundType()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_BoundType(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType)
  } // end of property IASCVariable::BoundType
  .property callconv(8) float64 InternalScale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_InternalScale(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_InternalScale()
  } // end of property IASCVariable::InternalScale
  .property callconv(8) float64 Step()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Step()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Step(float64)
  } // end of property IASCVariable::Step
  .property callconv(8) string PhysicalType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_PhysicalType()
  } // end of property IASCVariable::PhysicalType
  .property callconv(8) object UOMList()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_UOMList()
  } // end of property IASCVariable::UOMList
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCVariable

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCVariable
       implements AspenTech.AspenPlus.ASCclasslib.IASCVariable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 56 61 72 69 61 62 6C 65 43 6C   // ib.ASCVariableCl
                                                                                                                          61 73 73 00 00 )                                  // ass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 36 2D 46 37 30 34   // ..$00400006-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVariable

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCVariableClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCVariable,
                  AspenTech.AspenPlus.ASCclasslib.ASCVariable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 34 2D 30 38 37 41   // ..$00400004-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCVariableClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Parent
  } // end of method ASCVariableClass::get_Parent

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Simulation
  } // end of method ASCVariableClass::get_Simulation

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Name
  } // end of method ASCVariableClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_IsValid
  } // end of method ASCVariableClass::get_IsValid

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::GetService
  } // end of method ASCVariableClass::GetService

  .method public hidebysig newslot specialname virtual 
          instance float64  get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Value
  } // end of method ASCVariableClass::get_Value

  .method public hidebysig newslot specialname virtual 
          instance void  set_Value([in] float64 Value) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Value
  } // end of method ASCVariableClass::set_Value

  .method public hidebysig newslot specialname virtual 
          instance float64  get_LowerBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_LowerBound
  } // end of method ASCVariableClass::get_LowerBound

  .method public hidebysig newslot specialname virtual 
          instance void  set_LowerBound([in] float64 Lower) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_LowerBound
  } // end of method ASCVariableClass::set_LowerBound

  .method public hidebysig newslot specialname virtual 
          instance float64  get_UpperBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_UpperBound
  } // end of method ASCVariableClass::get_UpperBound

  .method public hidebysig newslot specialname virtual 
          instance void  set_UpperBound([in] float64 Upper) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_UpperBound
  } // end of method ASCVariableClass::set_UpperBound

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec 
          get_Spec() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Spec
  } // end of method ASCVariableClass::get_Spec

  .method public hidebysig newslot specialname virtual 
          instance void  set_Spec([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec Spec) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Spec
  } // end of method ASCVariableClass::set_Spec

  .method public hidebysig newslot specialname virtual 
          instance float64  get_Scale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Scale
  } // end of method ASCVariableClass::get_Scale

  .method public hidebysig newslot specialname virtual 
          instance void  set_Scale([in] float64 Scale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Scale
  } // end of method ASCVariableClass::set_Scale

  .method public hidebysig newslot specialname virtual 
          instance float64  get_SBWeight() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_SBWeight
  } // end of method ASCVariableClass::get_SBWeight

  .method public hidebysig newslot specialname virtual 
          instance void  set_SBWeight([in] float64 Weight) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_SBWeight
  } // end of method ASCVariableClass::set_SBWeight

  .method public hidebysig newslot specialname virtual 
          instance float64  get_ShadowPrice() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_ShadowPrice
  } // end of method ASCVariableClass::get_ShadowPrice

  .method public hidebysig newslot specialname virtual 
          instance void  set_ShadowPrice([in] float64 Price) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_ShadowPrice
  } // end of method ASCVariableClass::set_ShadowPrice

  .method public hidebysig newslot specialname virtual 
          instance bool  get_Marked() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Marked
  } // end of method ASCVariableClass::get_Marked

  .method public hidebysig newslot specialname virtual 
          instance void  set_Marked([in] bool Marked) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Marked
  } // end of method ASCVariableClass::set_Marked

  .method public hidebysig newslot specialname virtual 
          instance bool  get_Modified([in] string  marshal( bstr) Attrib) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Modified
  } // end of method ASCVariableClass::get_Modified

  .method public hidebysig newslot specialname virtual 
          instance void  set_Modified([in] string  marshal( bstr) Attrib,
                                      [in] bool Modified) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Modified
  } // end of method ASCVariableClass::set_Modified

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound 
          get_ActiveBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_ActiveBound
  } // end of method ASCVariableClass::get_ActiveBound

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality 
          get_Quality() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Quality
  } // end of method ASCVariableClass::get_Quality

  .method public hidebysig newslot specialname virtual 
          instance void  set_Quality([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality Quality) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Quality
  } // end of method ASCVariableClass::set_Quality

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_UOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_UOM
  } // end of method ASCVariableClass::get_UOM

  .method public hidebysig newslot specialname virtual 
          instance void  set_UOM([in] string  marshal( bstr) pbUOM) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_UOM
  } // end of method ASCVariableClass::set_UOM

  .method public hidebysig newslot specialname virtual 
          instance float64  get_Initial() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Initial
  } // end of method ASCVariableClass::get_Initial

  .method public hidebysig newslot specialname virtual 
          instance void  set_Initial([in] float64 Initial) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Initial
  } // end of method ASCVariableClass::set_Initial

  .method public hidebysig newslot specialname virtual 
          instance float64  get_Change() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Change
  } // end of method ASCVariableClass::get_Change

  .method public hidebysig newslot specialname virtual 
          instance void  set_Change([in] float64 Change) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Change
  } // end of method ASCVariableClass::set_Change

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Number() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Number
  } // end of method ASCVariableClass::get_Number

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType 
          get_BoundType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_BoundType
  } // end of method ASCVariableClass::get_BoundType

  .method public hidebysig newslot specialname virtual 
          instance void  set_BoundType([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType BoundType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_BoundType
  } // end of method ASCVariableClass::set_BoundType

  .method public hidebysig newslot specialname virtual 
          instance float64  get_InternalScale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_InternalScale
  } // end of method ASCVariableClass::get_InternalScale

  .method public hidebysig newslot specialname virtual 
          instance void  set_InternalScale([in] float64 intscale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_InternalScale
  } // end of method ASCVariableClass::set_InternalScale

  .method public hidebysig newslot specialname virtual 
          instance float64  get_Step() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_Step
  } // end of method ASCVariableClass::get_Step

  .method public hidebysig newslot specialname virtual 
          instance void  set_Step([in] float64 Step) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::set_Step
  } // end of method ASCVariableClass::set_Step

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_PhysicalType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_PhysicalType
  } // end of method ASCVariableClass::get_PhysicalType

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_UOMList() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariable::get_UOMList
  } // end of method ASCVariableClass::get_UOMList

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Parent()
  } // end of property ASCVariableClass::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Simulation()
  } // end of property ASCVariableClass::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Name()
  } // end of property ASCVariableClass::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_IsValid()
  } // end of property ASCVariableClass::IsValid
  .property callconv(8) float64 Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_Value(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Value()
  } // end of property ASCVariableClass::Value
  .property callconv(8) float64 LowerBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_LowerBound()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_LowerBound(float64)
  } // end of property ASCVariableClass::LowerBound
  .property callconv(8) float64 UpperBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_UpperBound(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_UpperBound()
  } // end of property ASCVariableClass::UpperBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec
          Spec()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Spec()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_Spec(valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec)
  } // end of property ASCVariableClass::Spec
  .property callconv(8) float64 Scale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Scale()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_Scale(float64)
  } // end of property ASCVariableClass::Scale
  .property callconv(8) float64 SBWeight()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_SBWeight(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_SBWeight()
  } // end of property ASCVariableClass::SBWeight
  .property callconv(8) float64 ShadowPrice()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_ShadowPrice(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_ShadowPrice()
  } // end of property ASCVariableClass::ShadowPrice
  .property callconv(8) bool Marked()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Marked()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_Marked(bool)
  } // end of property ASCVariableClass::Marked
  .property callconv(8) bool Modified(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_Modified(string,
                                                                                      bool)
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Modified(string)
  } // end of property ASCVariableClass::Modified
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound
          ActiveBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_ActiveBound()
  } // end of property ASCVariableClass::ActiveBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality
          Quality()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Quality()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_Quality(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality)
  } // end of property ASCVariableClass::Quality
  .property callconv(8) string UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_UOM()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_UOM(string)
  } // end of property ASCVariableClass::UOM
  .property callconv(8) float64 Initial()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Initial()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_Initial(float64)
  } // end of property ASCVariableClass::Initial
  .property callconv(8) float64 Change()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Change()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_Change(float64)
  } // end of property ASCVariableClass::Change
  .property callconv(8) int32 Number()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Number()
  } // end of property ASCVariableClass::Number
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType
          BoundType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_BoundType()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_BoundType(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType)
  } // end of property ASCVariableClass::BoundType
  .property callconv(8) float64 InternalScale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_InternalScale(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_InternalScale()
  } // end of property ASCVariableClass::InternalScale
  .property callconv(8) float64 Step()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_Step()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::set_Step(float64)
  } // end of property ASCVariableClass::Step
  .property callconv(8) string PhysicalType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_PhysicalType()
  } // end of property ASCVariableClass::PhysicalType
  .property callconv(8) object UOMList()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCVariableClass::get_UOMList()
  } // end of property ASCVariableClass::UOMList
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVariableClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 37 2D 46 37 30 34   // ..$00400007-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCVariableCollection::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method IASCVariableCollection::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariableCollection::get_Count

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariableCollection::Find

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariableCollection::GetService

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
  } // end of method IASCVariableCollection::GetAttributes

  .method public hidebysig newslot abstract virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
  } // end of method IASCVariableCollection::SetAttributes

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCVariable 
          marshal( interface ) 
          get_Variable([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariableCollection::get_Variable

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::get_Item(int32)
  } // end of property IASCVariableCollection::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::get_Count()
  } // end of property IASCVariableCollection::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCVariable
          Variable(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCVariable AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::get_Variable(object)
  } // end of property IASCVariableCollection::Variable
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 3A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..:AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 56 61 72 69 61 62 6C 65 43 6F   // ib.ASCVariableCo
                                                                                                                          6C 6C 65 63 74 69 6F 6E 43 6C 61 73 73 00 00 )    // llectionClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 37 2D 46 37 30 34   // ..$00400007-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCVariableCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection,
                  AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 39 2D 30 38 37 41   // ..$00400009-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCVariableCollectionClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::get_Item
  } // end of method ASCVariableCollectionClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::GetEnumerator
  } // end of method ASCVariableCollectionClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::get_Count
  } // end of method ASCVariableCollectionClass::get_Count

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::Find
  } // end of method ASCVariableCollectionClass::Find

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::GetService
  } // end of method ASCVariableCollectionClass::GetService

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::GetAttributes
  } // end of method ASCVariableCollectionClass::GetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::SetAttributes
  } // end of method ASCVariableCollectionClass::SetAttributes

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCVariable 
          marshal( interface ) 
          get_Variable([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariableCollection::get_Variable
  } // end of method ASCVariableCollectionClass::get_Variable

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCVariableCollectionClass::get_Item(int32)
  } // end of property ASCVariableCollectionClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCVariableCollectionClass::get_Count()
  } // end of property ASCVariableCollectionClass::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCVariable
          Variable(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCVariable AspenTech.AspenPlus.ASCclasslib.ASCVariableCollectionClass::get_Variable(object)
  } // end of property ASCVariableCollectionClass::Variable
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCEquation
       implements AspenTech.AspenPlus.ASCclasslib.IASCObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 35 2D 46 37 30 34   // ..$00400015-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEquation::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEquation::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEquation::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEquation::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEquation::GetService

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCEquation::get_Parent()
  } // end of property IASCEquation::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCEquation::get_Simulation()
  } // end of property IASCEquation::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCEquation::get_Name()
  } // end of property IASCEquation::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCEquation::get_IsValid()
  } // end of property IASCEquation::IsValid
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCEquation

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCEquation
       implements AspenTech.AspenPlus.ASCclasslib.IASCEquation
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 45 71 75 61 74 69 6F 6E 43 6C   // ib.ASCEquationCl
                                                                                                                          61 73 73 00 00 )                                  // ass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 35 2D 46 37 30 34   // ..$00400015-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCEquation

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCEquationClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCEquation,
                  AspenTech.AspenPlus.ASCclasslib.ASCEquation
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 30 2D 30 38 37 41   // ..$00400010-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCEquationClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquation::get_Parent
  } // end of method ASCEquationClass::get_Parent

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquation::get_Simulation
  } // end of method ASCEquationClass::get_Simulation

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquation::get_Name
  } // end of method ASCEquationClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquation::get_IsValid
  } // end of method ASCEquationClass::get_IsValid

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquation::GetService
  } // end of method ASCEquationClass::GetService

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCEquationClass::get_Parent()
  } // end of property ASCEquationClass::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.ASCEquationClass::get_Simulation()
  } // end of property ASCEquationClass::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCEquationClass::get_Name()
  } // end of property ASCEquationClass::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCEquationClass::get_IsValid()
  } // end of property ASCEquationClass::IsValid
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCEquationClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 36 2D 46 37 30 34   // ..$00400016-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCEquationCollection::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IASCEquationCollection::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEquationCollection::get_Count

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEquationCollection::Find

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEquationCollection::GetService

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
  } // end of method IASCEquationCollection::GetAttributes

  .method public hidebysig newslot abstract virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
  } // end of method IASCEquationCollection::SetAttributes

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCEquation 
          marshal( interface ) 
          get_Equation([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCEquationCollection::get_Equation

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::get_Item(int32)
  } // end of property IASCEquationCollection::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::get_Count()
  } // end of property IASCEquationCollection::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCEquation
          Equation(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCEquation AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::get_Equation(object)
  } // end of property IASCEquationCollection::Equation
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 36 2D 46 37 30 34   // ..$00400016-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 3A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..:AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 45 71 75 61 74 69 6F 6E 43 6F   // ib.ASCEquationCo
                                                                                                                          6C 6C 65 63 74 69 6F 6E 43 6C 61 73 73 00 00 )    // llectionClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCEquationCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection,
                  AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 31 2D 30 38 37 41   // ..$00400011-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCEquationCollectionClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::get_Item
  } // end of method ASCEquationCollectionClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::GetEnumerator
  } // end of method ASCEquationCollectionClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::get_Count
  } // end of method ASCEquationCollectionClass::get_Count

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::Find
  } // end of method ASCEquationCollectionClass::Find

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::GetService
  } // end of method ASCEquationCollectionClass::GetService

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::GetAttributes
  } // end of method ASCEquationCollectionClass::GetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::SetAttributes
  } // end of method ASCEquationCollectionClass::SetAttributes

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCEquation 
          marshal( interface ) 
          get_Equation([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEquationCollection::get_Equation
  } // end of method ASCEquationCollectionClass::get_Equation

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCEquationCollectionClass::get_Item(int32)
  } // end of property ASCEquationCollectionClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCEquationCollectionClass::get_Count()
  } // end of property ASCEquationCollectionClass::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCEquation
          Equation(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCEquation AspenTech.AspenPlus.ASCclasslib.ASCEquationCollectionClass::get_Equation(object)
  } // end of property ASCEquationCollectionClass::Equation
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCPort
       implements AspenTech.AspenPlus.ASCclasslib.IASCObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 38 2D 46 37 30 34   // ..$00400008-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPort::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPort::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPort::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPort::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPort::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir 
          get_Direction() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCPort::get_Direction

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType 
          get_Type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCPort::get_Type

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Stream() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCPort::get_Stream

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCPort::get_Parent()
  } // end of property IASCPort::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCPort::get_Simulation()
  } // end of property IASCPort::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCPort::get_Name()
  } // end of property IASCPort::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCPort::get_IsValid()
  } // end of property IASCPort::IsValid
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir
          Direction()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir AspenTech.AspenPlus.ASCclasslib.IASCPort::get_Direction()
  } // end of property IASCPort::Direction
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType
          Type()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType AspenTech.AspenPlus.ASCclasslib.IASCPort::get_Type()
  } // end of property IASCPort::Type
  .property callconv(8) string Stream()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCPort::get_Stream()
  } // end of property IASCPort::Stream
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCPort

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCPort2
       implements AspenTech.AspenPlus.ASCclasslib.IASCPort
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 39 2D 46 37 30 34   // ..$00400009-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPort2::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPort2::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPort2::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPort2::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPort2::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir 
          get_Direction() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCPort2::get_Direction

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType 
          get_Type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCPort2::get_Type

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Stream() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCPort2::get_Stream

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection 
          marshal( interface ) 
          get_Variables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
  } // end of method IASCPort2::get_Variables

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Parent()
  } // end of property IASCPort2::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Simulation()
  } // end of property IASCPort2::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Name()
  } // end of property IASCPort2::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_IsValid()
  } // end of property IASCPort2::IsValid
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir
          Direction()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Direction()
  } // end of property IASCPort2::Direction
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType
          Type()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Type()
  } // end of property IASCPort2::Type
  .property callconv(8) string Stream()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Stream()
  } // end of property IASCPort2::Stream
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection
          Variables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Variables()
  } // end of property IASCPort2::Variables
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCPort2

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCPort
       implements AspenTech.AspenPlus.ASCclasslib.IASCPort2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 2C 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..,AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 50 6F 72 74 43 6C 61 73 73 00   // ib.ASCPortClass.
                                                                                                                          00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 39 2D 46 37 30 34   // ..$00400009-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCPort

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCPortClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCPort2,
                  AspenTech.AspenPlus.ASCclasslib.ASCPort
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 33 2D 30 38 37 41   // ..$00400003-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCPortClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Parent
  } // end of method ASCPortClass::get_Parent

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Simulation
  } // end of method ASCPortClass::get_Simulation

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Name
  } // end of method ASCPortClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_IsValid
  } // end of method ASCPortClass::get_IsValid

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPort2::GetService
  } // end of method ASCPortClass::GetService

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir 
          get_Direction() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Direction
  } // end of method ASCPortClass::get_Direction

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType 
          get_Type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Type
  } // end of method ASCPortClass::get_Type

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Stream() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Stream
  } // end of method ASCPortClass::get_Stream

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection 
          marshal( interface ) 
          get_Variables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPort2::get_Variables
  } // end of method ASCPortClass::get_Variables

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCPortClass::get_Parent()
  } // end of property ASCPortClass::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.ASCPortClass::get_Simulation()
  } // end of property ASCPortClass::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCPortClass::get_Name()
  } // end of property ASCPortClass::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCPortClass::get_IsValid()
  } // end of property ASCPortClass::IsValid
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir
          Direction()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir AspenTech.AspenPlus.ASCclasslib.ASCPortClass::get_Direction()
  } // end of property ASCPortClass::Direction
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType
          Type()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType AspenTech.AspenPlus.ASCclasslib.ASCPortClass::get_Type()
  } // end of property ASCPortClass::Type
  .property callconv(8) string Stream()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCPortClass::get_Stream()
  } // end of property ASCPortClass::Stream
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection
          Variables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection AspenTech.AspenPlus.ASCclasslib.ASCPortClass::get_Variables()
  } // end of property ASCPortClass::Variables
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCPortClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCPortCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 30 2D 46 37 30 34   // ..$00400010-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCPortCollection::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IASCPortCollection::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPortCollection::get_Count

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPortCollection::Find

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCPortCollection::GetService

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
  } // end of method IASCPortCollection::GetAttributes

  .method public hidebysig newslot abstract virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
  } // end of method IASCPortCollection::SetAttributes

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCPort 
          marshal( interface ) 
          get_Port([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCPortCollection::get_Port

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::get_Item(int32)
  } // end of property IASCPortCollection::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::get_Count()
  } // end of property IASCPortCollection::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCPort
          Port(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCPort AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::get_Port(object)
  } // end of property IASCPortCollection::Port
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCPortCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCPortCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCPortCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 36 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..6AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 50 6F 72 74 43 6F 6C 6C 65 63   // ib.ASCPortCollec
                                                                                                                          74 69 6F 6E 43 6C 61 73 73 00 00 )                // tionClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 30 2D 46 37 30 34   // ..$00400010-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCPortCollection

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCPortCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCPortCollection,
                  AspenTech.AspenPlus.ASCclasslib.ASCPortCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 33 2D 30 38 37 41   // ..$00400013-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCPortCollectionClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::get_Item
  } // end of method ASCPortCollectionClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::GetEnumerator
  } // end of method ASCPortCollectionClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::get_Count
  } // end of method ASCPortCollectionClass::get_Count

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::Find
  } // end of method ASCPortCollectionClass::Find

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::GetService
  } // end of method ASCPortCollectionClass::GetService

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
    .override AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::GetAttributes
  } // end of method ASCPortCollectionClass::GetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
    .override AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::SetAttributes
  } // end of method ASCPortCollectionClass::SetAttributes

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCPort 
          marshal( interface ) 
          get_Port([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCPortCollection::get_Port
  } // end of method ASCPortCollectionClass::get_Port

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCPortCollectionClass::get_Item(int32)
  } // end of property ASCPortCollectionClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCPortCollectionClass::get_Count()
  } // end of property ASCPortCollectionClass::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCPort
          Port(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCPort AspenTech.AspenPlus.ASCclasslib.ASCPortCollectionClass::get_Port(object)
  } // end of property ASCPortCollectionClass::Port
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCPortCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCSolver
       implements AspenTech.AspenPlus.ASCclasslib.IASCObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 38 2D 46 37 30 34   // ..$00400018-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSolver::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSolver::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSolver::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSolver::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSolver::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCParameters 
          marshal( interface ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSolver::get_Parameters

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCSolver::get_Parent()
  } // end of property IASCSolver::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCSolver::get_Simulation()
  } // end of property IASCSolver::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCSolver::get_Name()
  } // end of property IASCSolver::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCSolver::get_IsValid()
  } // end of property IASCSolver::IsValid
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCParameters
          Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCParameters AspenTech.AspenPlus.ASCclasslib.IASCSolver::get_Parameters()
  } // end of property IASCSolver::Parameters
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCSolver

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSolver
       implements AspenTech.AspenPlus.ASCclasslib.IASCSolver
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 38 2D 46 37 30 34   // ..$00400018-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 2E 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ...AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 53 6F 6C 76 65 72 43 6C 61 73   // ib.ASCSolverClas
                                                                                                                          73 00 00 )                                        // s..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSolver

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSolverClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCSolver,
                  AspenTech.AspenPlus.ASCclasslib.ASCSolver
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 35 2D 30 38 37 41   // ..$00400005-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCSolverClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolver::get_Parent
  } // end of method ASCSolverClass::get_Parent

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolver::get_Simulation
  } // end of method ASCSolverClass::get_Simulation

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolver::get_Name
  } // end of method ASCSolverClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolver::get_IsValid
  } // end of method ASCSolverClass::get_IsValid

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolver::GetService
  } // end of method ASCSolverClass::GetService

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCParameters 
          marshal( interface ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolver::get_Parameters
  } // end of method ASCSolverClass::get_Parameters

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCSolverClass::get_Parent()
  } // end of property ASCSolverClass::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.ASCSolverClass::get_Simulation()
  } // end of property ASCSolverClass::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCSolverClass::get_Name()
  } // end of property ASCSolverClass::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCSolverClass::get_IsValid()
  } // end of property ASCSolverClass::IsValid
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCParameters
          Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCParameters AspenTech.AspenPlus.ASCclasslib.ASCSolverClass::get_Parameters()
  } // end of property ASCSolverClass::Parameters
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSolverClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 39 2D 46 37 30 34   // ..$00400019-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCSolverCollection::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method IASCSolverCollection::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSolverCollection::get_Count

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSolverCollection::Find

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSolverCollection::GetService

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
  } // end of method IASCSolverCollection::GetAttributes

  .method public hidebysig newslot abstract virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
  } // end of method IASCSolverCollection::SetAttributes

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCSolver 
          marshal( interface ) 
          get_Solver([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCSolverCollection::get_Solver

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::get_Item(int32)
  } // end of property IASCSolverCollection::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::get_Count()
  } // end of property IASCSolverCollection::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCSolver
          Solver(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCSolver AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::get_Solver(object)
  } // end of property IASCSolverCollection::Solver
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 39 2D 46 37 30 34   // ..$00400019-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 38 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..8AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 53 6F 6C 76 65 72 43 6F 6C 6C   // ib.ASCSolverColl
                                                                                                                          65 63 74 69 6F 6E 43 6C 61 73 73 00 00 )          // ectionClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSolverCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection,
                  AspenTech.AspenPlus.ASCclasslib.ASCSolverCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 35 2D 30 38 37 41   // ..$00400015-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCSolverCollectionClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::get_Item
  } // end of method ASCSolverCollectionClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::GetEnumerator
  } // end of method ASCSolverCollectionClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::get_Count
  } // end of method ASCSolverCollectionClass::get_Count

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::Find
  } // end of method ASCSolverCollectionClass::Find

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::GetService
  } // end of method ASCSolverCollectionClass::GetService

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::GetAttributes
  } // end of method ASCSolverCollectionClass::GetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::SetAttributes
  } // end of method ASCSolverCollectionClass::SetAttributes

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCSolver 
          marshal( interface ) 
          get_Solver([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSolverCollection::get_Solver
  } // end of method ASCSolverCollectionClass::get_Solver

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCSolverCollectionClass::get_Item(int32)
  } // end of property ASCSolverCollectionClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCSolverCollectionClass::get_Count()
  } // end of property ASCSolverCollectionClass::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCSolver
          Solver(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCSolver AspenTech.AspenPlus.ASCclasslib.ASCSolverCollectionClass::get_Solver(object)
  } // end of property ASCSolverCollectionClass::Solver
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSolverCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCParameters
       implements [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 31 2D 46 37 30 34   // ..$00400011-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Item([in] object  marshal( struct) Index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCParameters::get_Item

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Item([in] object  marshal( struct) Index,
                                  [in] object  marshal( struct) pVar) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCParameters::set_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IASCParameters::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameters::get_Count

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Description([in] object  marshal( struct) Index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameters::get_Description

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameters::GetService

  .property callconv(8) object Item(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCParameters::get_Item(object)
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCParameters::set_Item(object,
                                                                                object)
  } // end of property IASCParameters::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCParameters::get_Count()
  } // end of property IASCParameters::Count
  .property callconv(8) string Description(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameters::get_Description(object)
  } // end of property IASCParameters::Description
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCParameters

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCParameters
       implements AspenTech.AspenPlus.ASCclasslib.IASCParameters
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 32 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..2AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 50 61 72 61 6D 65 74 65 72 73   // ib.ASCParameters
                                                                                                                          43 6C 61 73 73 00 00 )                            // Class..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 31 2D 46 37 30 34   // ..$00400011-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCParameters

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCParametersClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCParameters,
                  AspenTech.AspenPlus.ASCclasslib.ASCParameters,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 34 2D 30 38 37 41   // ..$00400014-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCParametersClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_Item([in] object  marshal( struct) Index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameters::get_Item
  } // end of method ASCParametersClass::get_Item

  .method public hidebysig newslot specialname virtual 
          instance void  set_Item([in] object  marshal( struct) Index,
                                  [in] object  marshal( struct) pVar) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameters::set_Item
  } // end of method ASCParametersClass::set_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameters::GetEnumerator
  } // end of method ASCParametersClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameters::get_Count
  } // end of method ASCParametersClass::get_Count

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Description([in] object  marshal( struct) Index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameters::get_Description
  } // end of method ASCParametersClass::get_Description

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameters::GetService
  } // end of method ASCParametersClass::GetService

  .property callconv(8) object Item(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCParametersClass::get_Item(object)
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCParametersClass::set_Item(object,
                                                                                    object)
  } // end of property ASCParametersClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCParametersClass::get_Count()
  } // end of property ASCParametersClass::Count
  .property callconv(8) string Description(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCParametersClass::get_Description(object)
  } // end of property ASCParametersClass::Description
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCParametersClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCParameter
       implements AspenTech.AspenPlus.ASCclasslib.IASCObject
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 38 2D 46 37 30 34   // ..$00400028-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter::get_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Value([in] object  marshal( struct) val) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter::set_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_UOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter::get_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess 
          get_Access() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter::get_Access

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Description() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter::get_Description

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCParameter::get_Parent()
  } // end of property IASCParameter::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCParameter::get_Simulation()
  } // end of property IASCParameter::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameter::get_Name()
  } // end of property IASCParameter::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCParameter::get_IsValid()
  } // end of property IASCParameter::IsValid
  .property callconv(8) object Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCParameter::get_Value()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCParameter::set_Value(object)
  } // end of property IASCParameter::Value
  .property callconv(8) string UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameter::get_UOM()
  } // end of property IASCParameter::UOM
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess
          Access()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess AspenTech.AspenPlus.ASCclasslib.IASCParameter::get_Access()
  } // end of property IASCParameter::Access
  .property callconv(8) string Description()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameter::get_Description()
  } // end of property IASCParameter::Description
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCParameter

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCParameter2
       implements AspenTech.AspenPlus.ASCclasslib.IASCParameter
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 31 2D 46 37 30 34   // ..$00400041-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::get_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Value([in] object  marshal( struct) val) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::set_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_UOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::get_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess 
          get_Access() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::get_Access

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Description() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::get_Description

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Lower() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::get_Lower

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Lower([in] object  marshal( struct) val) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::set_Lower

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Upper() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::get_Upper

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Upper([in] object  marshal( struct) val) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter2::set_Upper

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCParameter2::get_Parent()
  } // end of property IASCParameter2::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCParameter2::get_Simulation()
  } // end of property IASCParameter2::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameter2::get_Name()
  } // end of property IASCParameter2::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCParameter2::get_IsValid()
  } // end of property IASCParameter2::IsValid
  .property callconv(8) object Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCParameter2::get_Value()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCParameter2::set_Value(object)
  } // end of property IASCParameter2::Value
  .property callconv(8) string UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameter2::get_UOM()
  } // end of property IASCParameter2::UOM
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess
          Access()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess AspenTech.AspenPlus.ASCclasslib.IASCParameter2::get_Access()
  } // end of property IASCParameter2::Access
  .property callconv(8) string Description()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameter2::get_Description()
  } // end of property IASCParameter2::Description
  .property callconv(8) object Lower()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCParameter2::set_Lower(object)
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCParameter2::get_Lower()
  } // end of property IASCParameter2::Lower
  .property callconv(8) object Upper()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCParameter2::set_Upper(object)
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCParameter2::get_Upper()
  } // end of property IASCParameter2::Upper
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCParameter2

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCParameter3
       implements AspenTech.AspenPlus.ASCclasslib.IASCParameter2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 39 2D 46 37 30 34   // ..$00400049-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Value([in] object  marshal( struct) val) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::set_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_UOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess 
          get_Access() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_Access

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Description() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_Description

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Lower() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_Lower

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Lower([in] object  marshal( struct) val) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::set_Lower

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Upper() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_Upper

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Upper([in] object  marshal( struct) val) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::set_Upper

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_PhysicalType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::get_PhysicalType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UOM([in] object  marshal( struct) A_1) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameter3::set_UOM

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Parent()
  } // end of property IASCParameter3::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Simulation()
  } // end of property IASCParameter3::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Name()
  } // end of property IASCParameter3::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_IsValid()
  } // end of property IASCParameter3::IsValid
  .property callconv(8) object Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Value()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCParameter3::set_Value(object)
  } // end of property IASCParameter3::Value
  .property callconv(8) string UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_UOM()
  } // end of property IASCParameter3::UOM
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess
          Access()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Access()
  } // end of property IASCParameter3::Access
  .property callconv(8) string Description()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Description()
  } // end of property IASCParameter3::Description
  .property callconv(8) object Lower()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Lower()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCParameter3::set_Lower(object)
  } // end of property IASCParameter3::Lower
  .property callconv(8) object Upper()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Upper()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCParameter3::set_Upper(object)
  } // end of property IASCParameter3::Upper
  .property callconv(8) string PhysicalType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_PhysicalType()
  } // end of property IASCParameter3::PhysicalType
  .property callconv(8) object UOM_2()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCParameter3::set_UOM(object)
  } // end of property IASCParameter3::UOM_2
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCParameter3

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCParameter
       implements AspenTech.AspenPlus.ASCclasslib.IASCParameter3
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 50 61 72 61 6D 65 74 65 72 43   // ib.ASCParameterC
                                                                                                                          6C 61 73 73 00 00 )                               // lass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 39 2D 46 37 30 34   // ..$00400049-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCParameter

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCParameterClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCParameter3,
                  AspenTech.AspenPlus.ASCclasslib.ASCParameter
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 36 2D 30 38 37 41   // ..$00400026-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCParameterClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Parent
  } // end of method ASCParameterClass::get_Parent

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Simulation
  } // end of method ASCParameterClass::get_Simulation

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Name
  } // end of method ASCParameterClass::get_Name

  .method public hidebysig newslot specialname virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_IsValid
  } // end of method ASCParameterClass::get_IsValid

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::GetService
  } // end of method ASCParameterClass::GetService

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Value
  } // end of method ASCParameterClass::get_Value

  .method public hidebysig newslot specialname virtual 
          instance void  set_Value([in] object  marshal( struct) val) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::set_Value
  } // end of method ASCParameterClass::set_Value

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_UOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_UOM
  } // end of method ASCParameterClass::get_UOM

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess 
          get_Access() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Access
  } // end of method ASCParameterClass::get_Access

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Description() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Description
  } // end of method ASCParameterClass::get_Description

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_Lower() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Lower
  } // end of method ASCParameterClass::get_Lower

  .method public hidebysig newslot specialname virtual 
          instance void  set_Lower([in] object  marshal( struct) val) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::set_Lower
  } // end of method ASCParameterClass::set_Lower

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_Upper() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_Upper
  } // end of method ASCParameterClass::get_Upper

  .method public hidebysig newslot specialname virtual 
          instance void  set_Upper([in] object  marshal( struct) val) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::set_Upper
  } // end of method ASCParameterClass::set_Upper

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_PhysicalType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::get_PhysicalType
  } // end of method ASCParameterClass::get_PhysicalType

  .method public hidebysig newslot specialname virtual 
          instance void  set_UOM([in] object  marshal( struct) A_1) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameter3::set_UOM
  } // end of method ASCParameterClass::set_UOM

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_Parent()
  } // end of property ASCParameterClass::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_Simulation()
  } // end of property ASCParameterClass::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_Name()
  } // end of property ASCParameterClass::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_IsValid()
  } // end of property ASCParameterClass::IsValid
  .property callconv(8) object Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::set_Value(object)
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_Value()
  } // end of property ASCParameterClass::Value
  .property callconv(8) string UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_UOM()
  } // end of property ASCParameterClass::UOM
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess
          Access()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_Access()
  } // end of property ASCParameterClass::Access
  .property callconv(8) string Description()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_Description()
  } // end of property ASCParameterClass::Description
  .property callconv(8) object Lower()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::set_Lower(object)
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_Lower()
  } // end of property ASCParameterClass::Lower
  .property callconv(8) object Upper()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_Upper()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::set_Upper(object)
  } // end of property ASCParameterClass::Upper
  .property callconv(8) string PhysicalType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::get_PhysicalType()
  } // end of property ASCParameterClass::PhysicalType
  .property callconv(8) object ASCParameter_UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCParameterClass::set_UOM(object)
  } // end of property ASCParameterClass::ASCParameter_UOM
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCParameterClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 39 2D 46 37 30 34   // ..$00400029-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCParameterCollection::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IASCParameterCollection::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameterCollection::get_Count

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameterCollection::Find

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCParameterCollection::GetService

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
  } // end of method IASCParameterCollection::GetAttributes

  .method public hidebysig newslot abstract virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
  } // end of method IASCParameterCollection::SetAttributes

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCParameter 
          marshal( interface ) 
          get_Parameter([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCParameterCollection::get_Parameter

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::get_Item(int32)
  } // end of property IASCParameterCollection::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::get_Count()
  } // end of property IASCParameterCollection::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCParameter
          Parameter(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCParameter AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::get_Parameter(object)
  } // end of property IASCParameterCollection::Parameter
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 39 2D 46 37 30 34   // ..$00400029-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 3B 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..;AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 50 61 72 61 6D 65 74 65 72 43   // ib.ASCParameterC
                                                                                                                          6F 6C 6C 65 63 74 69 6F 6E 43 6C 61 73 73 00 00 ) // ollectionClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCParameterCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection,
                  AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 37 2D 30 38 37 41   // ..$00400027-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCParameterCollectionClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::get_Item
  } // end of method ASCParameterCollectionClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::GetEnumerator
  } // end of method ASCParameterCollectionClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::get_Count
  } // end of method ASCParameterCollectionClass::get_Count

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::Find
  } // end of method ASCParameterCollectionClass::Find

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::GetService
  } // end of method ASCParameterCollectionClass::GetService

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::GetAttributes
  } // end of method ASCParameterCollectionClass::GetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::SetAttributes
  } // end of method ASCParameterCollectionClass::SetAttributes

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCParameter 
          marshal( interface ) 
          get_Parameter([in] object  marshal( struct) vItem) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCParameterCollection::get_Parameter
  } // end of method ASCParameterCollectionClass::get_Parameter

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCParameterCollectionClass::get_Item(int32)
  } // end of property ASCParameterCollectionClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCParameterCollectionClass::get_Count()
  } // end of property ASCParameterCollectionClass::Count
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCParameter
          Parameter(object)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCParameter AspenTech.AspenPlus.ASCclasslib.ASCParameterCollectionClass::get_Parameter(object)
  } // end of property ASCParameterCollectionClass::Parameter
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IEBScriptService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 32 2D 46 37 30 34   // ..$00400012-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance void  Execute([in] string  marshal( bstr) bCommand) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IEBScriptService::Execute

} // end of class AspenTech.AspenPlus.ASCclasslib.IEBScriptService

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.EBScriptService
       implements AspenTech.AspenPlus.ASCclasslib.IEBScriptService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 32 2D 46 37 30 34   // ..$00400012-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 45 42 53 63 72 69 70 74 53 65 72 76 69   // ib.EBScriptServi
                                                                                                                          63 65 43 6C 61 73 73 00 00 )                      // ceClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.EBScriptService

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.EBScriptServiceClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IEBScriptService,
                  AspenTech.AspenPlus.ASCclasslib.EBScriptService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 36 2D 30 38 37 41   // ..$00400006-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method EBScriptServiceClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  Execute([in] string  marshal( bstr) bCommand) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IEBScriptService::Execute
  } // end of method EBScriptServiceClass::Execute

} // end of class AspenTech.AspenPlus.ASCclasslib.EBScriptServiceClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCEditBlock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 30 2D 46 37 30 34   // ..$00400020-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance void  AddBlock([in] string  marshal( bstr) BlockName,
                                  [in] string  marshal( bstr) BlockType,
                                  [in] object  marshal( struct) Args) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEditBlock::AddBlock

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveBlock([in] string  marshal( bstr) BlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEditBlock::RemoveBlock

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveAllBlocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEditBlock::RemoveAllBlocks

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCEditBlock

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCEditBlock
       implements AspenTech.AspenPlus.ASCclasslib.IASCEditBlock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 30 2D 46 37 30 34   // ..$00400020-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..1AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 45 64 69 74 42 6C 6F 63 6B 43   // ib.ASCEditBlockC
                                                                                                                          6C 61 73 73 00 00 )                               // lass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCEditBlock

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCEditBlockClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCEditBlock,
                  AspenTech.AspenPlus.ASCclasslib.ASCEditBlock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 37 2D 30 38 37 41   // ..$00400017-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCEditBlockClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  AddBlock([in] string  marshal( bstr) BlockName,
                                  [in] string  marshal( bstr) BlockType,
                                  [in] object  marshal( struct) Args) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEditBlock::AddBlock
  } // end of method ASCEditBlockClass::AddBlock

  .method public hidebysig newslot virtual 
          instance void  RemoveBlock([in] string  marshal( bstr) BlockName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEditBlock::RemoveBlock
  } // end of method ASCEditBlockClass::RemoveBlock

  .method public hidebysig newslot virtual 
          instance void  RemoveAllBlocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEditBlock::RemoveAllBlocks
  } // end of method ASCEditBlockClass::RemoveAllBlocks

} // end of class AspenTech.AspenPlus.ASCclasslib.ASCEditBlockClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCEditLibraries
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 31 2D 46 37 30 34   // ..$00400021-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot abstract virtual 
          instance void  AddLibrary([in] string  marshal( bstr) LibraryName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEditLibraries::AddLibrary

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveLibrary([in] string  marshal( bstr) LibraryName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCEditLibraries::RemoveLibrary

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCEditLibraries

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCEditLibraries
       implements AspenTech.AspenPlus.ASCclasslib.IASCEditLibraries
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 31 2D 46 37 30 34   // ..$00400021-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 35 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..5AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 45 64 69 74 4C 69 62 72 61 72   // ib.ASCEditLibrar
                                                                                                                          69 65 73 43 6C 61 73 73 00 00 )                   // iesClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCEditLibraries

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCEditLibrariesClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCEditLibraries,
                  AspenTech.AspenPlus.ASCclasslib.ASCEditLibraries
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 38 2D 30 38 37 41   // ..$00400018-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCEditLibrariesClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  AddLibrary([in] string  marshal( bstr) LibraryName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEditLibraries::AddLibrary
  } // end of method ASCEditLibrariesClass::AddLibrary

  .method public hidebysig newslot virtual 
          instance void  RemoveLibrary([in] string  marshal( bstr) LibraryName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCEditLibraries::RemoveLibrary
  } // end of method ASCEditLibrariesClass::RemoveLibrary

} // end of class AspenTech.AspenPlus.ASCclasslib.ASCEditLibrariesClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 33 2D 46 37 30 34   // ..$00400013-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_BufferSize([in] int32 pnLines) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs::set_BufferSize

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_BufferSize() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs::get_BufferSize

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_LineCount() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs::get_LineCount

  .method public hidebysig newslot specialname abstract virtual 
          instance string[] 
          marshal( safearray bstr) 
          get_GetLines([in] int32 lStart,
                       [in] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs::get_GetLines

  .method public hidebysig newslot abstract virtual 
          instance void  ClearBuffer() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs::ClearBuffer

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_OutputFile([in] string  marshal( bstr) pbFileName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs::set_OutputFile

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_OutputFile() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs::get_OutputFile

  .property callconv(8) int32 BufferSize()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::set_BufferSize(int32)
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::get_BufferSize()
  } // end of property IASCSimulationMsgs::BufferSize
  .property callconv(8) int32 LineCount()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::get_LineCount()
  } // end of property IASCSimulationMsgs::LineCount
  .property callconv(8) string[] GetLines(int32,
                                          int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string[] AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::get_GetLines(int32,
                                                                                            int32)
  } // end of property IASCSimulationMsgs::GetLines
  .property callconv(8) string OutputFile()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::get_OutputFile()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::set_OutputFile(string)
  } // end of property IASCSimulationMsgs::OutputFile
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 10 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 34 2D 46 37 30 34   // ..$00400014-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot abstract virtual 
          instance void  OnNewLine([in] string  marshal( bstr) bText) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method DASCSimulationMsgsEvents::OnNewLine

} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents

.class interface public abstract auto ansi AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComEventInterfaceAttribute::.ctor(class [mscorlib]System.Type,
                                                                                                   class [mscorlib]System.Type) = ( 01 00 38 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..8AspenTech.Asp
                                                                                                                                    65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                                    69 62 2E 44 41 53 43 53 69 6D 75 6C 61 74 69 6F   // ib.DASCSimulatio
                                                                                                                                    6E 4D 73 67 73 45 76 65 6E 74 73 46 41 73 70 65   // nMsgsEventsFAspe
                                                                                                                                    6E 54 65 63 68 2E 41 73 70 65 6E 50 6C 75 73 2E   // nTech.AspenPlus.
                                                                                                                                    41 53 43 63 6C 61 73 73 6C 69 62 2E 44 41 53 43   // ASCclasslib.DASC
                                                                                                                                    53 69 6D 75 6C 61 74 69 6F 6E 4D 73 67 73 45 76   // SimulationMsgsEv
                                                                                                                                    65 6E 74 73 5F 45 76 65 6E 74 50 72 6F 76 69 64   // ents_EventProvid
                                                                                                                                    65 72 00 00 )                                     // er..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  add_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler A_1) runtime managed internalcall
  {
  } // end of method DASCSimulationMsgsEvents_Event::add_OnNewLine

  .method public hidebysig newslot abstract virtual 
          instance void  remove_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler A_1) runtime managed internalcall
  {
  } // end of method DASCSimulationMsgsEvents_Event::remove_OnNewLine

  .event AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler OnNewLine
  {
    .removeon instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_Event::remove_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler)
    .addon instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_Event::add_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler)
  } // end of event DASCSimulationMsgsEvents_Event::OnNewLine
} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_Event

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgs
       implements AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs,
                  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 36 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..6AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 53 69 6D 75 6C 61 74 69 6F 6E   // ib.ASCSimulation
                                                                                                                          4D 73 67 73 43 6C 61 73 73 00 00 )                // MsgsClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 33 2D 46 37 30 34   // ..$00400013-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgs

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2
       implements AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 35 31 2D 46 37 30 34   // ..$00400051-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_BufferSize([in] int32 pnLines) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs2::set_BufferSize

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_BufferSize() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs2::get_BufferSize

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_LineCount() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs2::get_LineCount

  .method public hidebysig newslot specialname abstract virtual 
          instance string[] 
          marshal( safearray bstr) 
          get_GetLines([in] int32 lStart,
                       [in] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs2::get_GetLines

  .method public hidebysig newslot abstract virtual 
          instance void  ClearBuffer() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs2::ClearBuffer

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_OutputFile([in] string  marshal( bstr) pbFileName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs2::set_OutputFile

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_OutputFile() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs2::get_OutputFile

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateProfiles([in] string[]  marshal( safearray bstr) nameArray,
                                        [in] object[]  marshal( safearray variant) valArray,
                                        [in] object[]  marshal( safearray variant) typeArray,
                                        [in] float64 time) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs2::UpdateProfiles

  .method public hidebysig newslot abstract virtual 
          instance void  ResetSimulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSimulationMsgs2::ResetSimulation

  .property callconv(8) int32 BufferSize()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::get_BufferSize()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::set_BufferSize(int32)
  } // end of property IASCSimulationMsgs2::BufferSize
  .property callconv(8) int32 LineCount()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::get_LineCount()
  } // end of property IASCSimulationMsgs2::LineCount
  .property callconv(8) string[] GetLines(int32,
                                          int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string[] AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::get_GetLines(int32,
                                                                                             int32)
  } // end of property IASCSimulationMsgs2::GetLines
  .property callconv(8) string OutputFile()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::get_OutputFile()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::set_OutputFile(string)
  } // end of property IASCSimulationMsgs2::OutputFile
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 35 32 2D 46 37 30 34   // ..$00400052-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 10 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 02 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  OnNewLine([in] string  marshal( bstr) bText) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method DASCSimulationMsgsEvents2::OnNewLine

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateProfiles([in] string[]  marshal( safearray bstr) nameArray,
                                        [in] object[]  marshal( safearray variant) valArray,
                                        float64 time) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
  } // end of method DASCSimulationMsgsEvents2::UpdateProfiles

  .method public hidebysig newslot abstract virtual 
          instance void  ResetSimulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
  } // end of method DASCSimulationMsgsEvents2::ResetSimulation

} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2

.class interface public abstract auto ansi AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComEventInterfaceAttribute::.ctor(class [mscorlib]System.Type,
                                                                                                   class [mscorlib]System.Type) = ( 01 00 39 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..9AspenTech.Asp
                                                                                                                                    65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                                    69 62 2E 44 41 53 43 53 69 6D 75 6C 61 74 69 6F   // ib.DASCSimulatio
                                                                                                                                    6E 4D 73 67 73 45 76 65 6E 74 73 32 47 41 73 70   // nMsgsEvents2GAsp
                                                                                                                                    65 6E 54 65 63 68 2E 41 73 70 65 6E 50 6C 75 73   // enTech.AspenPlus
                                                                                                                                    2E 41 53 43 63 6C 61 73 73 6C 69 62 2E 44 41 53   // .ASCclasslib.DAS
                                                                                                                                    43 53 69 6D 75 6C 61 74 69 6F 6E 4D 73 67 73 45   // CSimulationMsgsE
                                                                                                                                    76 65 6E 74 73 32 5F 45 76 65 6E 74 50 72 6F 76   // vents2_EventProv
                                                                                                                                    69 64 65 72 00 00 )                               // ider..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  add_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler A_1) runtime managed internalcall
  {
  } // end of method DASCSimulationMsgsEvents2_Event::add_OnNewLine

  .method public hidebysig newslot abstract virtual 
          instance void  remove_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler A_1) runtime managed internalcall
  {
  } // end of method DASCSimulationMsgsEvents2_Event::remove_OnNewLine

  .method public hidebysig newslot abstract virtual 
          instance void  add_UpdateProfiles(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler A_1) runtime managed internalcall
  {
  } // end of method DASCSimulationMsgsEvents2_Event::add_UpdateProfiles

  .method public hidebysig newslot abstract virtual 
          instance void  remove_UpdateProfiles(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler A_1) runtime managed internalcall
  {
  } // end of method DASCSimulationMsgsEvents2_Event::remove_UpdateProfiles

  .method public hidebysig newslot abstract virtual 
          instance void  add_ResetSimulation(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler A_1) runtime managed internalcall
  {
  } // end of method DASCSimulationMsgsEvents2_Event::add_ResetSimulation

  .method public hidebysig newslot abstract virtual 
          instance void  remove_ResetSimulation(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler A_1) runtime managed internalcall
  {
  } // end of method DASCSimulationMsgsEvents2_Event::remove_ResetSimulation

  .event AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler OnNewLine
  {
    .addon instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::add_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler)
    .removeon instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::remove_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler)
  } // end of event DASCSimulationMsgsEvents2_Event::OnNewLine
  .event AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler UpdateProfiles
  {
    .removeon instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::remove_UpdateProfiles(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler)
    .addon instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::add_UpdateProfiles(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler)
  } // end of event DASCSimulationMsgsEvents2_Event::UpdateProfiles
  .event AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler ResetSimulation
  {
    .addon instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::add_ResetSimulation(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler)
    .removeon instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::remove_ResetSimulation(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler)
  } // end of event DASCSimulationMsgsEvents2_Event::ResetSimulation
} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs,
                  AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgs,
                  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_Event,
                  AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2,
                  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComSourceInterfacesAttribute::.ctor(string) = ( 01 00 74 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..tAspenTech.Asp
                                                                                                                 65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                 69 62 2E 44 41 53 43 53 69 6D 75 6C 61 74 69 6F   // ib.DASCSimulatio
                                                                                                                 6E 4D 73 67 73 45 76 65 6E 74 73 00 41 73 70 65   // nMsgsEvents.Aspe
                                                                                                                 6E 54 65 63 68 2E 41 73 70 65 6E 50 6C 75 73 2E   // nTech.AspenPlus.
                                                                                                                 41 53 43 63 6C 61 73 73 6C 69 62 2E 44 41 53 43   // ASCclasslib.DASC
                                                                                                                 53 69 6D 75 6C 61 74 69 6F 6E 4D 73 67 73 45 76   // SimulationMsgsEv
                                                                                                                 65 6E 74 73 32 00 00 00 00 )                      // ents2....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 30 37 2D 30 38 37 41   // ..$00400007-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCSimulationMsgsClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance void  set_BufferSize([in] int32 pnLines) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::set_BufferSize
  } // end of method ASCSimulationMsgsClass::set_BufferSize

  .method public hidebysig newslot specialname virtual 
          instance int32  get_BufferSize() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::get_BufferSize
  } // end of method ASCSimulationMsgsClass::get_BufferSize

  .method public hidebysig newslot specialname virtual 
          instance int32  get_LineCount() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::get_LineCount
  } // end of method ASCSimulationMsgsClass::get_LineCount

  .method public hidebysig newslot specialname virtual 
          instance string[] 
          marshal( safearray bstr) 
          get_GetLines([in] int32 lStart,
                       [in] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::get_GetLines
  } // end of method ASCSimulationMsgsClass::get_GetLines

  .method public hidebysig newslot virtual 
          instance void  ClearBuffer() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::ClearBuffer
  } // end of method ASCSimulationMsgsClass::ClearBuffer

  .method public hidebysig newslot specialname virtual 
          instance void  set_OutputFile([in] string  marshal( bstr) pbFileName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::set_OutputFile
  } // end of method ASCSimulationMsgsClass::set_OutputFile

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_OutputFile() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs::get_OutputFile
  } // end of method ASCSimulationMsgsClass::get_OutputFile

  .method public hidebysig newslot virtual 
          instance void  add_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_Event::add_OnNewLine
  } // end of method ASCSimulationMsgsClass::add_OnNewLine

  .method public hidebysig newslot virtual 
          instance void  remove_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_Event::remove_OnNewLine
  } // end of method ASCSimulationMsgsClass::remove_OnNewLine

  .method public hidebysig newslot specialname virtual 
          instance void  IASCSimulationMsgs2_set_BufferSize([in] int32 pnLines) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::set_BufferSize
  } // end of method ASCSimulationMsgsClass::IASCSimulationMsgs2_set_BufferSize

  .method public hidebysig newslot specialname virtual 
          instance int32  IASCSimulationMsgs2_get_BufferSize() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::get_BufferSize
  } // end of method ASCSimulationMsgsClass::IASCSimulationMsgs2_get_BufferSize

  .method public hidebysig newslot specialname virtual 
          instance int32  IASCSimulationMsgs2_get_LineCount() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::get_LineCount
  } // end of method ASCSimulationMsgsClass::IASCSimulationMsgs2_get_LineCount

  .method public hidebysig newslot specialname virtual 
          instance string[] 
          marshal( safearray bstr) 
          IASCSimulationMsgs2_get_GetLines([in] int32 lStart,
                                           [in] int32 lCount) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::get_GetLines
  } // end of method ASCSimulationMsgsClass::IASCSimulationMsgs2_get_GetLines

  .method public hidebysig newslot virtual 
          instance void  IASCSimulationMsgs2_ClearBuffer() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::ClearBuffer
  } // end of method ASCSimulationMsgsClass::IASCSimulationMsgs2_ClearBuffer

  .method public hidebysig newslot specialname virtual 
          instance void  IASCSimulationMsgs2_set_OutputFile([in] string  marshal( bstr) pbFileName) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::set_OutputFile
  } // end of method ASCSimulationMsgsClass::IASCSimulationMsgs2_set_OutputFile

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          IASCSimulationMsgs2_get_OutputFile() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::get_OutputFile
  } // end of method ASCSimulationMsgsClass::IASCSimulationMsgs2_get_OutputFile

  .method public hidebysig newslot virtual 
          instance void  UpdateProfiles([in] string[]  marshal( safearray bstr) nameArray,
                                        [in] object[]  marshal( safearray variant) valArray,
                                        [in] object[]  marshal( safearray variant) typeArray,
                                        [in] float64 time) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::UpdateProfiles
  } // end of method ASCSimulationMsgsClass::UpdateProfiles

  .method public hidebysig newslot virtual 
          instance void  ResetSimulation() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimulationMsgs2::ResetSimulation
  } // end of method ASCSimulationMsgsClass::ResetSimulation

  .method public hidebysig newslot virtual 
          instance void  DASCSimulationMsgsEvents2_Event_add_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::add_OnNewLine
  } // end of method ASCSimulationMsgsClass::DASCSimulationMsgsEvents2_Event_add_OnNewLine

  .method public hidebysig newslot virtual 
          instance void  DASCSimulationMsgsEvents2_Event_remove_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::remove_OnNewLine
  } // end of method ASCSimulationMsgsClass::DASCSimulationMsgsEvents2_Event_remove_OnNewLine

  .method public hidebysig newslot virtual 
          instance void  add_UpdateProfiles(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::add_UpdateProfiles
  } // end of method ASCSimulationMsgsClass::add_UpdateProfiles

  .method public hidebysig newslot virtual 
          instance void  remove_UpdateProfiles(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::remove_UpdateProfiles
  } // end of method ASCSimulationMsgsClass::remove_UpdateProfiles

  .method public hidebysig newslot virtual 
          instance void  add_ResetSimulation(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::add_ResetSimulation
  } // end of method ASCSimulationMsgsClass::add_ResetSimulation

  .method public hidebysig newslot virtual 
          instance void  remove_ResetSimulation(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler A_1) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event::remove_ResetSimulation
  } // end of method ASCSimulationMsgsClass::remove_ResetSimulation

  .event AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler OnNewLine
  {
    .addon instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::add_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler)
    .removeon instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::remove_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler)
  } // end of event ASCSimulationMsgsClass::OnNewLine
  .event AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler DASCSimulationMsgsEvents2_Event_OnNewLine
  {
    .addon instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::DASCSimulationMsgsEvents2_Event_add_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler)
    .removeon instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::DASCSimulationMsgsEvents2_Event_remove_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler)
  } // end of event ASCSimulationMsgsClass::DASCSimulationMsgsEvents2_Event_OnNewLine
  .event AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler DASCSimulationMsgsEvents2_Event_UpdateProfiles
  {
    .addon instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::add_UpdateProfiles(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler)
    .removeon instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::remove_UpdateProfiles(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler)
  } // end of event ASCSimulationMsgsClass::DASCSimulationMsgsEvents2_Event_UpdateProfiles
  .event AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler DASCSimulationMsgsEvents2_Event_ResetSimulation
  {
    .addon instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::add_ResetSimulation(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler)
    .removeon instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::remove_ResetSimulation(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler)
  } // end of event ASCSimulationMsgsClass::DASCSimulationMsgsEvents2_Event_ResetSimulation
  .property callconv(8) int32 BufferSize()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::get_BufferSize()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::set_BufferSize(int32)
  } // end of property ASCSimulationMsgsClass::BufferSize
  .property callconv(8) int32 LineCount()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::get_LineCount()
  } // end of property ASCSimulationMsgsClass::LineCount
  .property callconv(8) string[] GetLines(int32,
                                          int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string[] AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::get_GetLines(int32,
                                                                                                int32)
  } // end of property ASCSimulationMsgsClass::GetLines
  .property callconv(8) string OutputFile()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::get_OutputFile()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::set_OutputFile(string)
  } // end of property ASCSimulationMsgsClass::OutputFile
  .property callconv(8) int32 IASCSimulationMsgs2_BufferSize()
  {
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::IASCSimulationMsgs2_get_BufferSize()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::IASCSimulationMsgs2_set_BufferSize(int32)
  } // end of property ASCSimulationMsgsClass::IASCSimulationMsgs2_BufferSize
  .property callconv(8) int32 IASCSimulationMsgs2_LineCount()
  {
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::IASCSimulationMsgs2_get_LineCount()
  } // end of property ASCSimulationMsgsClass::IASCSimulationMsgs2_LineCount
  .property callconv(8) string[] IASCSimulationMsgs2_GetLines(int32,
                                                              int32)
  {
    .get instance string[] AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::IASCSimulationMsgs2_get_GetLines(int32,
                                                                                                                    int32)
  } // end of property ASCSimulationMsgsClass::IASCSimulationMsgs2_GetLines
  .property callconv(8) string IASCSimulationMsgs2_OutputFile()
  {
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::IASCSimulationMsgs2_get_OutputFile()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass::IASCSimulationMsgs2_set_OutputFile(string)
  } // end of property ASCSimulationMsgsClass::IASCSimulationMsgs2_OutputFile
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSimulationMsgsClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCGridService
       implements AspenTech.AspenPlus.ASCclasslib.IASCObjectCollection
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 37 2D 46 37 30 34   // ..$00400017-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCGridService::get_Item

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IASCGridService::GetEnumerator

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCGridService::get_Count

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCGridService::Find

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCGridService::GetService

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
  } // end of method IASCGridService::GetAttributes

  .method public hidebysig newslot abstract virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
  } // end of method IASCGridService::SetAttributes

  .method public hidebysig newslot abstract virtual 
          instance void  SetSortKeys([in] object  marshal( struct) SortKeys,
                                     [in] object  marshal( struct) SortOrder) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridService::SetSortKeys

  .method public hidebysig newslot abstract virtual 
          instance void  SetQueryStrings([in] object  marshal( struct) QueryStrings) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridService::SetQueryStrings

  .method public hidebysig newslot abstract virtual 
          instance void  SetGridColumns([in] object  marshal( struct) ColumnAttributes) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridService::SetGridColumns

  .method public hidebysig newslot abstract virtual 
          instance void  Prepare() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridService::Prepare

  .method public hidebysig newslot abstract virtual 
          instance void  Sort() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridService::Sort

  .method public hidebysig newslot abstract virtual 
          instance void  SetAttr([in] string  marshal( bstr) AttrName,
                                 [in] object  marshal( struct) Value,
                                 [in] int32 iRowNum) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridService::SetAttr

  .method public hidebysig newslot abstract virtual 
          instance void  GetIndexPositions([in] object  marshal( struct) Indices,
                                           [out] object&  marshal( struct) Positions) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridService::GetIndexPositions

  .method public hidebysig newslot abstract virtual 
          instance void  GetPositionIndices([in] object  marshal( struct) Positions,
                                            [out] object&  marshal( struct) Indices) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridService::GetPositionIndices

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCGridService::get_Item(int32)
  } // end of property IASCGridService::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCGridService::get_Count()
  } // end of property IASCGridService::Count
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCGridService

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCVariableGrid
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 56 61 72 69 61 62 6C 65 47 72   // ib.ASCVariableGr
                                                                                                                          69 64 43 6C 61 73 73 00 00 )                      // idClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 37 2D 46 37 30 34   // ..$00400017-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVariableGrid

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCVariableGridClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridService,
                  AspenTech.AspenPlus.ASCclasslib.ASCVariableGrid,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 32 2D 30 38 37 41   // ..$00400012-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCVariableGridClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::get_Item
  } // end of method ASCVariableGridClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetEnumerator
  } // end of method ASCVariableGridClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::get_Count
  } // end of method ASCVariableGridClass::get_Count

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Find
  } // end of method ASCVariableGridClass::Find

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetService
  } // end of method ASCVariableGridClass::GetService

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetAttributes
  } // end of method ASCVariableGridClass::GetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetAttributes
  } // end of method ASCVariableGridClass::SetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetSortKeys([in] object  marshal( struct) SortKeys,
                                     [in] object  marshal( struct) SortOrder) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetSortKeys
  } // end of method ASCVariableGridClass::SetSortKeys

  .method public hidebysig newslot virtual 
          instance void  SetQueryStrings([in] object  marshal( struct) QueryStrings) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetQueryStrings
  } // end of method ASCVariableGridClass::SetQueryStrings

  .method public hidebysig newslot virtual 
          instance void  SetGridColumns([in] object  marshal( struct) ColumnAttributes) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetGridColumns
  } // end of method ASCVariableGridClass::SetGridColumns

  .method public hidebysig newslot virtual 
          instance void  Prepare() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Prepare
  } // end of method ASCVariableGridClass::Prepare

  .method public hidebysig newslot virtual 
          instance void  Sort() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Sort
  } // end of method ASCVariableGridClass::Sort

  .method public hidebysig newslot virtual 
          instance void  SetAttr([in] string  marshal( bstr) AttrName,
                                 [in] object  marshal( struct) Value,
                                 [in] int32 iRowNum) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetAttr
  } // end of method ASCVariableGridClass::SetAttr

  .method public hidebysig newslot virtual 
          instance void  GetIndexPositions([in] object  marshal( struct) Indices,
                                           [out] object&  marshal( struct) Positions) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetIndexPositions
  } // end of method ASCVariableGridClass::GetIndexPositions

  .method public hidebysig newslot virtual 
          instance void  GetPositionIndices([in] object  marshal( struct) Positions,
                                            [out] object&  marshal( struct) Indices) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetPositionIndices
  } // end of method ASCVariableGridClass::GetPositionIndices

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCVariableGridClass::get_Item(int32)
  } // end of property ASCVariableGridClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCVariableGridClass::get_Count()
  } // end of property ASCVariableGridClass::Count
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVariableGridClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCEquationGrid
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 45 71 75 61 74 69 6F 6E 47 72   // ib.ASCEquationGr
                                                                                                                          69 64 43 6C 61 73 73 00 00 )                      // idClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 37 2D 46 37 30 34   // ..$00400017-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCEquationGrid

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCEquationGridClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridService,
                  AspenTech.AspenPlus.ASCclasslib.ASCEquationGrid,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 36 2D 30 38 37 41   // ..$00400016-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCEquationGridClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::get_Item
  } // end of method ASCEquationGridClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetEnumerator
  } // end of method ASCEquationGridClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::get_Count
  } // end of method ASCEquationGridClass::get_Count

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Find
  } // end of method ASCEquationGridClass::Find

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetService
  } // end of method ASCEquationGridClass::GetService

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetAttributes
  } // end of method ASCEquationGridClass::GetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetAttributes
  } // end of method ASCEquationGridClass::SetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetSortKeys([in] object  marshal( struct) SortKeys,
                                     [in] object  marshal( struct) SortOrder) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetSortKeys
  } // end of method ASCEquationGridClass::SetSortKeys

  .method public hidebysig newslot virtual 
          instance void  SetQueryStrings([in] object  marshal( struct) QueryStrings) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetQueryStrings
  } // end of method ASCEquationGridClass::SetQueryStrings

  .method public hidebysig newslot virtual 
          instance void  SetGridColumns([in] object  marshal( struct) ColumnAttributes) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetGridColumns
  } // end of method ASCEquationGridClass::SetGridColumns

  .method public hidebysig newslot virtual 
          instance void  Prepare() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Prepare
  } // end of method ASCEquationGridClass::Prepare

  .method public hidebysig newslot virtual 
          instance void  Sort() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Sort
  } // end of method ASCEquationGridClass::Sort

  .method public hidebysig newslot virtual 
          instance void  SetAttr([in] string  marshal( bstr) AttrName,
                                 [in] object  marshal( struct) Value,
                                 [in] int32 iRowNum) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetAttr
  } // end of method ASCEquationGridClass::SetAttr

  .method public hidebysig newslot virtual 
          instance void  GetIndexPositions([in] object  marshal( struct) Indices,
                                           [out] object&  marshal( struct) Positions) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetIndexPositions
  } // end of method ASCEquationGridClass::GetIndexPositions

  .method public hidebysig newslot virtual 
          instance void  GetPositionIndices([in] object  marshal( struct) Positions,
                                            [out] object&  marshal( struct) Indices) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetPositionIndices
  } // end of method ASCEquationGridClass::GetPositionIndices

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCEquationGridClass::get_Item(int32)
  } // end of property ASCEquationGridClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCEquationGridClass::get_Count()
  } // end of property ASCEquationGridClass::Count
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCEquationGridClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCSensitivity
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 32 2D 46 37 30 34   // ..$00400022-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_DependentVariables([in] object  marshal( struct) pVariableNames) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSensitivity::set_DependentVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_DependentVariables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSensitivity::get_DependentVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NumDependentVariables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSensitivity::get_NumDependentVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_IndependentVariables([in] object  marshal( struct) pVariableNames) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSensitivity::set_IndependentVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_IndependentVariables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSensitivity::get_IndependentVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NumIndependentVariables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSensitivity::get_NumIndependentVariables

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Objective([in] string  marshal( bstr) pObjectiveName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSensitivity::set_Objective

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Objective() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSensitivity::get_Objective

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          Calculate([in][out] object&  marshal( struct) pDifferentiable) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
  } // end of method IASCSensitivity::Calculate

  .property callconv(8) object DependentVariables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::set_DependentVariables(object)
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::get_DependentVariables()
  } // end of property IASCSensitivity::DependentVariables
  .property callconv(8) int32 NumDependentVariables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::get_NumDependentVariables()
  } // end of property IASCSensitivity::NumDependentVariables
  .property callconv(8) object IndependentVariables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::get_IndependentVariables()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::set_IndependentVariables(object)
  } // end of property IASCSensitivity::IndependentVariables
  .property callconv(8) int32 NumIndependentVariables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::get_NumIndependentVariables()
  } // end of property IASCSensitivity::NumIndependentVariables
  .property callconv(8) string Objective()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::get_Objective()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::set_Objective(string)
  } // end of property IASCSensitivity::Objective
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCSensitivity

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSensitivity
       implements AspenTech.AspenPlus.ASCclasslib.IASCSensitivity
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 53 65 6E 73 69 74 69 76 69 74   // ib.ASCSensitivit
                                                                                                                          79 43 6C 61 73 73 00 00 )                         // yClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 32 2D 46 37 30 34   // ..$00400022-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSensitivity

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCSensitivity,
                  AspenTech.AspenPlus.ASCclasslib.ASCSensitivity
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 39 2D 30 38 37 41   // ..$00400019-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCSensitivityClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance void  set_DependentVariables([in] object  marshal( struct) pVariableNames) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::set_DependentVariables
  } // end of method ASCSensitivityClass::set_DependentVariables

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_DependentVariables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::get_DependentVariables
  } // end of method ASCSensitivityClass::get_DependentVariables

  .method public hidebysig newslot specialname virtual 
          instance int32  get_NumDependentVariables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::get_NumDependentVariables
  } // end of method ASCSensitivityClass::get_NumDependentVariables

  .method public hidebysig newslot specialname virtual 
          instance void  set_IndependentVariables([in] object  marshal( struct) pVariableNames) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::set_IndependentVariables
  } // end of method ASCSensitivityClass::set_IndependentVariables

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_IndependentVariables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::get_IndependentVariables
  } // end of method ASCSensitivityClass::get_IndependentVariables

  .method public hidebysig newslot specialname virtual 
          instance int32  get_NumIndependentVariables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::get_NumIndependentVariables
  } // end of method ASCSensitivityClass::get_NumIndependentVariables

  .method public hidebysig newslot specialname virtual 
          instance void  set_Objective([in] string  marshal( bstr) pObjectiveName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::set_Objective
  } // end of method ASCSensitivityClass::set_Objective

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_Objective() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::get_Objective
  } // end of method ASCSensitivityClass::get_Objective

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          Calculate([in][out] object&  marshal( struct) pDifferentiable) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCSensitivity::Calculate
  } // end of method ASCSensitivityClass::Calculate

  .property callconv(8) object DependentVariables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass::get_DependentVariables()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass::set_DependentVariables(object)
  } // end of property ASCSensitivityClass::DependentVariables
  .property callconv(8) int32 NumDependentVariables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass::get_NumDependentVariables()
  } // end of property ASCSensitivityClass::NumDependentVariables
  .property callconv(8) object IndependentVariables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass::get_IndependentVariables()
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass::set_IndependentVariables(object)
  } // end of property ASCSensitivityClass::IndependentVariables
  .property callconv(8) int32 NumIndependentVariables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass::get_NumIndependentVariables()
  } // end of property ASCSensitivityClass::NumIndependentVariables
  .property callconv(8) string Objective()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass::set_Objective(string)
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass::get_Objective()
  } // end of property ASCSensitivityClass::Objective
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSensitivityClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCSimEventMgr
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 33 2D 46 37 30 34   // ..$00400023-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance int32  Advise([in] int32 lEventFilter,
                                 [in] class AspenTech.AspenPlus.ASCclasslib.IASCSimEventSink  marshal( interface ) pSink) runtime managed internalcall
  {
  } // end of method IASCSimEventMgr::Advise

  .method public hidebysig newslot abstract virtual 
          instance void  UnAdvise([in] int32 lAdviseId) runtime managed internalcall
  {
  } // end of method IASCSimEventMgr::UnAdvise

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCSimEventLock 
          marshal( interface ) 
          BlockEvents([in] int32 lEventFilter,
                      [in] int32 lAdviseId) runtime managed internalcall
  {
  } // end of method IASCSimEventMgr::BlockEvents

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCSimEventMgr

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSimEventMgr
       implements AspenTech.AspenPlus.ASCclasslib.IASCSimEventMgr
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 33 2D 46 37 30 34   // ..$00400023-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 53 69 6D 45 76 65 6E 74 4D 67   // ib.ASCSimEventMg
                                                                                                                          72 43 6C 61 73 73 00 00 )                         // rClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSimEventMgr

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSimEventMgrClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCSimEventMgr,
                  AspenTech.AspenPlus.ASCclasslib.ASCSimEventMgr
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 30 2D 30 38 37 41   // ..$00400020-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCSimEventMgrClass::.ctor

  .method public hidebysig newslot virtual 
          instance int32  Advise([in] int32 lEventFilter,
                                 [in] class AspenTech.AspenPlus.ASCclasslib.IASCSimEventSink  marshal( interface ) pSink) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimEventMgr::Advise
  } // end of method ASCSimEventMgrClass::Advise

  .method public hidebysig newslot virtual 
          instance void  UnAdvise([in] int32 lAdviseId) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimEventMgr::UnAdvise
  } // end of method ASCSimEventMgrClass::UnAdvise

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCSimEventLock 
          marshal( interface ) 
          BlockEvents([in] int32 lEventFilter,
                      [in] int32 lAdviseId) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimEventMgr::BlockEvents
  } // end of method ASCSimEventMgrClass::BlockEvents

} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSimEventMgrClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCSimEventLock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 35 2D 46 37 30 34   // ..$00400025-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot abstract virtual 
          instance void  FlushEvents() runtime managed internalcall
  {
  } // end of method IASCSimEventLock::FlushEvents

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCSimEventLock

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSimEventLock
       implements AspenTech.AspenPlus.ASCclasslib.IASCSimEventLock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 35 2D 46 37 30 34   // ..$00400025-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 34 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..4AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 53 69 6D 45 76 65 6E 74 4C 6F   // ib.ASCSimEventLo
                                                                                                                          63 6B 43 6C 61 73 73 00 00 )                      // ckClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSimEventLock

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCSimEventLockClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCSimEventLock,
                  AspenTech.AspenPlus.ASCclasslib.ASCSimEventLock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 31 2D 30 38 37 41   // ..$00400021-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCSimEventLockClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  FlushEvents() runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCSimEventLock::FlushEvents
  } // end of method ASCSimEventLockClass::FlushEvents

} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSimEventLockClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCInterfaceHolder
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 36 2D 46 37 30 34   // ..$00400026-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  Register([in] string  marshal( bstr) ident,
                                  [in] object  marshal( iunknown ) pInterface) runtime managed internalcall
  {
  } // end of method IASCInterfaceHolder::Register

  .method public hidebysig newslot abstract virtual 
          instance void  Unregister([in] string  marshal( bstr) ident) runtime managed internalcall
  {
  } // end of method IASCInterfaceHolder::Unregister

  .method public hidebysig newslot abstract virtual 
          instance void  GetInterface([in] string  marshal( bstr) ident,
                                      [out] object&  marshal( iunknown ) ppInterface) runtime managed internalcall
  {
  } // end of method IASCInterfaceHolder::GetInterface

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCInterfaceHolder

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCInterfaceHolder
       implements AspenTech.AspenPlus.ASCclasslib.IASCInterfaceHolder
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 37 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..7AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 49 6E 74 65 72 66 61 63 65 48   // ib.ASCInterfaceH
                                                                                                                          6F 6C 64 65 72 43 6C 61 73 73 00 00 )             // olderClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 36 2D 46 37 30 34   // ..$00400026-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCInterfaceHolder

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCInterfaceHolderClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCInterfaceHolder,
                  AspenTech.AspenPlus.ASCclasslib.ASCInterfaceHolder
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 32 2D 30 38 37 41   // ..$00400022-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCInterfaceHolderClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  Register([in] string  marshal( bstr) ident,
                                  [in] object  marshal( iunknown ) pInterface) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCInterfaceHolder::Register
  } // end of method ASCInterfaceHolderClass::Register

  .method public hidebysig newslot virtual 
          instance void  Unregister([in] string  marshal( bstr) ident) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCInterfaceHolder::Unregister
  } // end of method ASCInterfaceHolderClass::Unregister

  .method public hidebysig newslot virtual 
          instance void  GetInterface([in] string  marshal( bstr) ident,
                                      [out] object&  marshal( iunknown ) ppInterface) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCInterfaceHolder::GetInterface
  } // end of method ASCInterfaceHolderClass::GetInterface

} // end of class AspenTech.AspenPlus.ASCclasslib.ASCInterfaceHolderClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCExternalFileService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 37 2D 46 37 30 34   // ..$00400027-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot abstract virtual 
          instance void  QueryContents([in] string  marshal( bstr) filename,
                                       [in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType file_type,
                                       [out] int32& var_attributes,
                                       [out] string[]&  marshal( safearray bstr) pbBlockIDs) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCExternalFileService::QueryContents

  .method public hidebysig newslot abstract virtual 
          instance void  Import([in] string  marshal( bstr) filename,
                                [in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType file_type,
                                [in] int32 var_attributes,
                                [in] string  marshal( bstr) blockid,
                                [in] string  marshal( bstr) match,
                                [in] string  marshal( bstr) substitute,
                                [in] bool usescope) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCExternalFileService::Import

  .method public hidebysig newslot abstract virtual 
          instance void  Export([in] string  marshal( bstr) filename,
                                [in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType file_type,
                                [in] int32 var_attributes,
                                [in] string[]  marshal( safearray bstr) bBlockIDs) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCExternalFileService::Export

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCExternalFileService

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCExternalFileService
       implements AspenTech.AspenPlus.ASCclasslib.IASCExternalFileService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 3B 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..;AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 45 78 74 65 72 6E 61 6C 46 69   // ib.ASCExternalFi
                                                                                                                          6C 65 53 65 72 76 69 63 65 43 6C 61 73 73 00 00 ) // leServiceClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 37 2D 46 37 30 34   // ..$00400027-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCExternalFileService

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCExternalFileServiceClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCExternalFileService,
                  AspenTech.AspenPlus.ASCclasslib.ASCExternalFileService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 33 2D 30 38 37 41   // ..$00400023-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCExternalFileServiceClass::.ctor

  .method public hidebysig newslot virtual 
          instance void  QueryContents([in] string  marshal( bstr) filename,
                                       [in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType file_type,
                                       [out] int32& var_attributes,
                                       [out] string[]&  marshal( safearray bstr) pbBlockIDs) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCExternalFileService::QueryContents
  } // end of method ASCExternalFileServiceClass::QueryContents

  .method public hidebysig newslot virtual 
          instance void  Import([in] string  marshal( bstr) filename,
                                [in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType file_type,
                                [in] int32 var_attributes,
                                [in] string  marshal( bstr) blockid,
                                [in] string  marshal( bstr) match,
                                [in] string  marshal( bstr) substitute,
                                [in] bool usescope) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCExternalFileService::Import
  } // end of method ASCExternalFileServiceClass::Import

  .method public hidebysig newslot virtual 
          instance void  Export([in] string  marshal( bstr) filename,
                                [in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType file_type,
                                [in] int32 var_attributes,
                                [in] string[]  marshal( safearray bstr) bBlockIDs) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCExternalFileService::Export
  } // end of method ASCExternalFileServiceClass::Export

} // end of class AspenTech.AspenPlus.ASCclasslib.ASCExternalFileServiceClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCPortGrid
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 37 2D 46 37 30 34   // ..$00400017-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 50 6F 72 74 47 72 69 64 43 6C   // ib.ASCPortGridCl
                                                                                                                          61 73 73 00 00 )                                  // ass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCPortGrid

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCPortGridClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridService,
                  AspenTech.AspenPlus.ASCclasslib.ASCPortGrid,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 34 2D 30 38 37 41   // ..$00400024-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCPortGridClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::get_Item
  } // end of method ASCPortGridClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetEnumerator
  } // end of method ASCPortGridClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::get_Count
  } // end of method ASCPortGridClass::get_Count

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Find
  } // end of method ASCPortGridClass::Find

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetService
  } // end of method ASCPortGridClass::GetService

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetAttributes
  } // end of method ASCPortGridClass::GetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetAttributes
  } // end of method ASCPortGridClass::SetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetSortKeys([in] object  marshal( struct) SortKeys,
                                     [in] object  marshal( struct) SortOrder) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetSortKeys
  } // end of method ASCPortGridClass::SetSortKeys

  .method public hidebysig newslot virtual 
          instance void  SetQueryStrings([in] object  marshal( struct) QueryStrings) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetQueryStrings
  } // end of method ASCPortGridClass::SetQueryStrings

  .method public hidebysig newslot virtual 
          instance void  SetGridColumns([in] object  marshal( struct) ColumnAttributes) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetGridColumns
  } // end of method ASCPortGridClass::SetGridColumns

  .method public hidebysig newslot virtual 
          instance void  Prepare() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Prepare
  } // end of method ASCPortGridClass::Prepare

  .method public hidebysig newslot virtual 
          instance void  Sort() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Sort
  } // end of method ASCPortGridClass::Sort

  .method public hidebysig newslot virtual 
          instance void  SetAttr([in] string  marshal( bstr) AttrName,
                                 [in] object  marshal( struct) Value,
                                 [in] int32 iRowNum) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetAttr
  } // end of method ASCPortGridClass::SetAttr

  .method public hidebysig newslot virtual 
          instance void  GetIndexPositions([in] object  marshal( struct) Indices,
                                           [out] object&  marshal( struct) Positions) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetIndexPositions
  } // end of method ASCPortGridClass::GetIndexPositions

  .method public hidebysig newslot virtual 
          instance void  GetPositionIndices([in] object  marshal( struct) Positions,
                                            [out] object&  marshal( struct) Indices) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetPositionIndices
  } // end of method ASCPortGridClass::GetPositionIndices

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCPortGridClass::get_Item(int32)
  } // end of property ASCPortGridClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCPortGridClass::get_Count()
  } // end of property ASCPortGridClass::Count
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCPortGridClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCParameterGrid
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 31 37 2D 46 37 30 34   // ..$00400017-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 35 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..5AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 50 61 72 61 6D 65 74 65 72 47   // ib.ASCParameterG
                                                                                                                          72 69 64 43 6C 61 73 73 00 00 )                   // ridClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCParameterGrid

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCParameterGridClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridService,
                  AspenTech.AspenPlus.ASCclasslib.ASCParameterGrid,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 35 2D 30 38 37 41   // ..$00400025-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCParameterGridClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Item([in] int32 lIndex) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::get_Item
  } // end of method ASCParameterGridClass::get_Item

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibFuncAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibFuncFlags) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetEnumerator
  } // end of method ASCParameterGridClass::GetEnumerator

  .method public hidebysig newslot specialname virtual 
          instance int32  get_Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::get_Count
  } // end of method ASCParameterGridClass::get_Count

  .method public hidebysig newslot virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          Find([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Find
  } // end of method ASCParameterGridClass::Find

  .method public hidebysig newslot virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetService
  } // end of method ASCParameterGridClass::GetService

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetAttributes([in] object  marshal( struct) ObjectAttributes,
                        [in][opt] int32 iFirst,
                        [in][opt] int32 lCount) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 02 60 00 00 )                         // .....`..
    .param [2] = int32(0x00000001)
    .param [3] = int32(0x00000000)
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetAttributes
  } // end of method ASCParameterGridClass::GetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetAttributes([in] object  marshal( struct) ObjectAttributes,
                                       [in] object  marshal( struct) AttribValues,
                                       [in][opt] int32 iFirst) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 02 60 00 00 )                         // .....`..
    .param [3] = int32(0x00000001)
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetAttributes
  } // end of method ASCParameterGridClass::SetAttributes

  .method public hidebysig newslot virtual 
          instance void  SetSortKeys([in] object  marshal( struct) SortKeys,
                                     [in] object  marshal( struct) SortOrder) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetSortKeys
  } // end of method ASCParameterGridClass::SetSortKeys

  .method public hidebysig newslot virtual 
          instance void  SetQueryStrings([in] object  marshal( struct) QueryStrings) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetQueryStrings
  } // end of method ASCParameterGridClass::SetQueryStrings

  .method public hidebysig newslot virtual 
          instance void  SetGridColumns([in] object  marshal( struct) ColumnAttributes) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetGridColumns
  } // end of method ASCParameterGridClass::SetGridColumns

  .method public hidebysig newslot virtual 
          instance void  Prepare() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Prepare
  } // end of method ASCParameterGridClass::Prepare

  .method public hidebysig newslot virtual 
          instance void  Sort() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::Sort
  } // end of method ASCParameterGridClass::Sort

  .method public hidebysig newslot virtual 
          instance void  SetAttr([in] string  marshal( bstr) AttrName,
                                 [in] object  marshal( struct) Value,
                                 [in] int32 iRowNum) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::SetAttr
  } // end of method ASCParameterGridClass::SetAttr

  .method public hidebysig newslot virtual 
          instance void  GetIndexPositions([in] object  marshal( struct) Indices,
                                           [out] object&  marshal( struct) Positions) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetIndexPositions
  } // end of method ASCParameterGridClass::GetIndexPositions

  .method public hidebysig newslot virtual 
          instance void  GetPositionIndices([in] object  marshal( struct) Positions,
                                            [out] object&  marshal( struct) Indices) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridService::GetPositionIndices
  } // end of method ASCParameterGridClass::GetPositionIndices

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Item(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.ASCParameterGridClass::get_Item(int32)
  } // end of property ASCParameterGridClass::Item
  .property callconv(8) int32 Count()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCParameterGridClass::get_Count()
  } // end of property ASCParameterGridClass::Count
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCParameterGridClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCGridInfo
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 30 2D 46 37 30 34   // ..$00400030-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_ColHeaderHeight() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_ColHeaderHeight

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_RowHeight() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_RowHeight

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_FrozenCols() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_FrozenCols

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_FrozenRows() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_FrozenRows

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollection 
          marshal( interface ) 
          get_Columns() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_Columns

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollection 
          marshal( interface ) 
          get_ControlStyles() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_ControlStyles

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_ColCount() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_ColCount

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_PrimaryCol() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_PrimaryCol

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_ShowRowHdr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 30 00 06 00 00 )                         // ...0....
  } // end of method IASCGridInfo::get_ShowRowHdr

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_AllowQueries() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_AllowQueries

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_HelpFile() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_HelpFile

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Mode([in] int32 A_1) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::set_Mode

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_PreSortedCols([in] string  marshal( bstr) bStr) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridInfo::get_PreSortedCols

  .property callconv(8) int32 ColHeaderHeight()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_ColHeaderHeight()
  } // end of property IASCGridInfo::ColHeaderHeight
  .property callconv(8) int32 RowHeight()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_RowHeight()
  } // end of property IASCGridInfo::RowHeight
  .property callconv(8) int32 FrozenCols()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_FrozenCols()
  } // end of property IASCGridInfo::FrozenCols
  .property callconv(8) int32 FrozenRows()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_FrozenRows()
  } // end of property IASCGridInfo::FrozenRows
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollection
          Columns()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollection AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_Columns()
  } // end of property IASCGridInfo::Columns
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollection
          ControlStyles()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollection AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_ControlStyles()
  } // end of property IASCGridInfo::ControlStyles
  .property callconv(8) int32 ColCount()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_ColCount()
  } // end of property IASCGridInfo::ColCount
  .property callconv(8) int32 PrimaryCol()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_PrimaryCol()
  } // end of property IASCGridInfo::PrimaryCol
  .property callconv(8) bool ShowRowHdr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 30 00 06 00 00 )                         // ...0....
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_ShowRowHdr()
  } // end of property IASCGridInfo::ShowRowHdr
  .property callconv(8) bool AllowQueries()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_AllowQueries()
  } // end of property IASCGridInfo::AllowQueries
  .property callconv(8) string HelpFile()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_HelpFile()
  } // end of property IASCGridInfo::HelpFile
  .property callconv(8) int32 Mode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::set_Mode(int32)
  } // end of property IASCGridInfo::Mode
  .property callconv(8) object PreSortedCols(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_PreSortedCols(string)
  } // end of property IASCGridInfo::PreSortedCols
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCGridInfo

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridInfo
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridInfo
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 30 2D 46 37 30 34   // ..$00400030-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 47 72 69 64 49 6E 66 6F 43 6C   // ib.ASCGridInfoCl
                                                                                                                          61 73 73 00 00 )                                  // ass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridInfo

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridInfo,
                  AspenTech.AspenPlus.ASCclasslib.ASCGridInfo
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 38 2D 30 38 37 41   // ..$00400028-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCGridInfoClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance int32  get_ColHeaderHeight() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_ColHeaderHeight
  } // end of method ASCGridInfoClass::get_ColHeaderHeight

  .method public hidebysig newslot specialname virtual 
          instance int32  get_RowHeight() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_RowHeight
  } // end of method ASCGridInfoClass::get_RowHeight

  .method public hidebysig newslot specialname virtual 
          instance int32  get_FrozenCols() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_FrozenCols
  } // end of method ASCGridInfoClass::get_FrozenCols

  .method public hidebysig newslot specialname virtual 
          instance int32  get_FrozenRows() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_FrozenRows
  } // end of method ASCGridInfoClass::get_FrozenRows

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollection 
          marshal( interface ) 
          get_Columns() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_Columns
  } // end of method ASCGridInfoClass::get_Columns

  .method public hidebysig newslot specialname virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollection 
          marshal( interface ) 
          get_ControlStyles() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_ControlStyles
  } // end of method ASCGridInfoClass::get_ControlStyles

  .method public hidebysig newslot specialname virtual 
          instance int32  get_ColCount() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_ColCount
  } // end of method ASCGridInfoClass::get_ColCount

  .method public hidebysig newslot specialname virtual 
          instance int32  get_PrimaryCol() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_PrimaryCol
  } // end of method ASCGridInfoClass::get_PrimaryCol

  .method public hidebysig newslot specialname virtual 
          instance bool  get_ShowRowHdr() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 30 00 06 00 00 )                         // ...0....
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_ShowRowHdr
  } // end of method ASCGridInfoClass::get_ShowRowHdr

  .method public hidebysig newslot specialname virtual 
          instance bool  get_AllowQueries() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_AllowQueries
  } // end of method ASCGridInfoClass::get_AllowQueries

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_HelpFile() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_HelpFile
  } // end of method ASCGridInfoClass::get_HelpFile

  .method public hidebysig newslot specialname virtual 
          instance void  set_Mode([in] int32 A_1) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::set_Mode
  } // end of method ASCGridInfoClass::set_Mode

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_PreSortedCols([in] string  marshal( bstr) bStr) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridInfo::get_PreSortedCols
  } // end of method ASCGridInfoClass::get_PreSortedCols

  .property callconv(8) int32 ColHeaderHeight()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_ColHeaderHeight()
  } // end of property ASCGridInfoClass::ColHeaderHeight
  .property callconv(8) int32 RowHeight()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_RowHeight()
  } // end of property ASCGridInfoClass::RowHeight
  .property callconv(8) int32 FrozenCols()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_FrozenCols()
  } // end of property ASCGridInfoClass::FrozenCols
  .property callconv(8) int32 FrozenRows()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_FrozenRows()
  } // end of property ASCGridInfoClass::FrozenRows
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollection
          Columns()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollection AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_Columns()
  } // end of property ASCGridInfoClass::Columns
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollection
          ControlStyles()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollection AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_ControlStyles()
  } // end of property ASCGridInfoClass::ControlStyles
  .property callconv(8) int32 ColCount()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_ColCount()
  } // end of property ASCGridInfoClass::ColCount
  .property callconv(8) int32 PrimaryCol()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_PrimaryCol()
  } // end of property ASCGridInfoClass::PrimaryCol
  .property callconv(8) bool ShowRowHdr()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 30 00 06 00 00 )                         // ...0....
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_ShowRowHdr()
  } // end of property ASCGridInfoClass::ShowRowHdr
  .property callconv(8) bool AllowQueries()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_AllowQueries()
  } // end of property ASCGridInfoClass::AllowQueries
  .property callconv(8) string HelpFile()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_HelpFile()
  } // end of property ASCGridInfoClass::HelpFile
  .property callconv(8) int32 Mode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::set_Mode(int32)
  } // end of property ASCGridInfoClass::Mode
  .property callconv(8) object PreSortedCols(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass::get_PreSortedCols(string)
  } // end of property ASCGridInfoClass::PreSortedCols
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridInfoClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 31 2D 46 37 30 34   // ..$00400031-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_EngineName() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridVarInfo::get_EngineName

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_DisplayName() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridVarInfo::get_DisplayName

  .method public hidebysig newslot specialname abstract virtual 
          instance uint32  get_ColumnWidth() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridVarInfo::get_ColumnWidth

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Visible() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridVarInfo::get_Visible

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_ReadOnly() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridVarInfo::get_ReadOnly

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Resize() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridVarInfo::get_Resize

  .method public hidebysig newslot abstract virtual 
          instance bool  CanQuery() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridVarInfo::CanQuery

  .method public hidebysig newslot abstract virtual 
          instance int32  get_DefaultControlStyle() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridVarInfo::get_DefaultControlStyle

  .method public hidebysig newslot abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCControlType 
          get_DefaultControlType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2E 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ...AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                            69 62 2E 41 53 43 43 6F 6E 74 72 6F 6C 54 79 70   // ib.ASCControlTyp
                                                                                                            65 00 00 )                                        // e..
  } // end of method IASCGridVarInfo::get_DefaultControlType

  .method public hidebysig newslot specialname abstract virtual 
          instance uint32  get_ModMask() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridVarInfo::get_ModMask

  .property callconv(8) string EngineName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_EngineName()
  } // end of property IASCGridVarInfo::EngineName
  .property callconv(8) string DisplayName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_DisplayName()
  } // end of property IASCGridVarInfo::DisplayName
  .property callconv(8) uint32 ColumnWidth()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance uint32 AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_ColumnWidth()
  } // end of property IASCGridVarInfo::ColumnWidth
  .property callconv(8) bool Visible()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_Visible()
  } // end of property IASCGridVarInfo::Visible
  .property callconv(8) bool ReadOnly()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_ReadOnly()
  } // end of property IASCGridVarInfo::ReadOnly
  .property callconv(8) bool Resize()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_Resize()
  } // end of property IASCGridVarInfo::Resize
  .property callconv(8) uint32 ModMask()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .get instance uint32 AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_ModMask()
  } // end of property IASCGridVarInfo::ModMask
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfo
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 31 2D 46 37 30 34   // ..$00400031-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 33 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..3AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 47 72 69 64 56 61 72 49 6E 66   // ib.ASCGridVarInf
                                                                                                                          6F 43 6C 61 73 73 00 00 )                         // oClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfo

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfoClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo,
                  AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfo
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 39 2D 30 38 37 41   // ..$00400029-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCGridVarInfoClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_EngineName() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_EngineName
  } // end of method ASCGridVarInfoClass::get_EngineName

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_DisplayName() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_DisplayName
  } // end of method ASCGridVarInfoClass::get_DisplayName

  .method public hidebysig newslot specialname virtual 
          instance uint32  get_ColumnWidth() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_ColumnWidth
  } // end of method ASCGridVarInfoClass::get_ColumnWidth

  .method public hidebysig newslot specialname virtual 
          instance bool  get_Visible() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_Visible
  } // end of method ASCGridVarInfoClass::get_Visible

  .method public hidebysig newslot specialname virtual 
          instance bool  get_ReadOnly() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_ReadOnly
  } // end of method ASCGridVarInfoClass::get_ReadOnly

  .method public hidebysig newslot specialname virtual 
          instance bool  get_Resize() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_Resize
  } // end of method ASCGridVarInfoClass::get_Resize

  .method public hidebysig newslot virtual 
          instance bool  CanQuery() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::CanQuery
  } // end of method ASCGridVarInfoClass::CanQuery

  .method public hidebysig newslot virtual 
          instance int32  get_DefaultControlStyle() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_DefaultControlStyle
  } // end of method ASCGridVarInfoClass::get_DefaultControlStyle

  .method public hidebysig newslot virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCControlType 
          get_DefaultControlType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2E 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ...AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                            69 62 2E 41 53 43 43 6F 6E 74 72 6F 6C 54 79 70   // ib.ASCControlTyp
                                                                                                            65 00 00 )                                        // e..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_DefaultControlType
  } // end of method ASCGridVarInfoClass::get_DefaultControlType

  .method public hidebysig newslot specialname virtual 
          instance uint32  get_ModMask() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridVarInfo::get_ModMask
  } // end of method ASCGridVarInfoClass::get_ModMask

  .property callconv(8) string EngineName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfoClass::get_EngineName()
  } // end of property ASCGridVarInfoClass::EngineName
  .property callconv(8) string DisplayName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfoClass::get_DisplayName()
  } // end of property ASCGridVarInfoClass::DisplayName
  .property callconv(8) uint32 ColumnWidth()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance uint32 AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfoClass::get_ColumnWidth()
  } // end of property ASCGridVarInfoClass::ColumnWidth
  .property callconv(8) bool Visible()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfoClass::get_Visible()
  } // end of property ASCGridVarInfoClass::Visible
  .property callconv(8) bool ReadOnly()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfoClass::get_ReadOnly()
  } // end of property ASCGridVarInfoClass::ReadOnly
  .property callconv(8) bool Resize()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfoClass::get_Resize()
  } // end of property ASCGridVarInfoClass::Resize
  .property callconv(8) uint32 ModMask()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .get instance uint32 AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfoClass::get_ModMask()
  } // end of property ASCGridVarInfoClass::ModMask
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridVarInfoClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCGridStaticControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 32 2D 46 37 30 34   // ..$00400032-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_DefaultValue() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridStaticControl::get_DefaultValue

  .property callconv(8) string DefaultValue()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCGridStaticControl::get_DefaultValue()
  } // end of property IASCGridStaticControl::DefaultValue
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCGridStaticControl

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridStaticControl
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridStaticControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 39 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..9AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 47 72 69 64 53 74 61 74 69 63   // ib.ASCGridStatic
                                                                                                                          43 6F 6E 74 72 6F 6C 43 6C 61 73 73 00 00 )       // ControlClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 32 2D 46 37 30 34   // ..$00400032-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridStaticControl

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridStaticControlClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridStaticControl,
                  AspenTech.AspenPlus.ASCclasslib.ASCGridStaticControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 30 2D 30 38 37 41   // ..$00400030-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCGridStaticControlClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_DefaultValue() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridStaticControl::get_DefaultValue
  } // end of method ASCGridStaticControlClass::get_DefaultValue

  .property callconv(8) string DefaultValue()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCGridStaticControlClass::get_DefaultValue()
  } // end of property ASCGridStaticControlClass::DefaultValue
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridStaticControlClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 33 2D 46 37 30 34   // ..$00400033-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_DefaultValue() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridTextBoxControl::get_DefaultValue

  .method public hidebysig newslot specialname abstract virtual 
          instance uint32  get_MaxSize() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridTextBoxControl::get_MaxSize

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_VarType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridTextBoxControl::get_VarType

  .method public hidebysig newslot abstract virtual 
          instance bool  UseFormat() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridTextBoxControl::UseFormat

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_FormatType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridTextBoxControl::get_FormatType

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NumPlaces() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridTextBoxControl::get_NumPlaces

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_MaskInc() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridTextBoxControl::get_MaskInc

  .property callconv(8) object DefaultValue()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_DefaultValue()
  } // end of property IASCGridTextBoxControl::DefaultValue
  .property callconv(8) uint32 MaxSize()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance uint32 AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_MaxSize()
  } // end of property IASCGridTextBoxControl::MaxSize
  .property callconv(8) object VarType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_VarType()
  } // end of property IASCGridTextBoxControl::VarType
  .property callconv(8) object FormatType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_FormatType()
  } // end of property IASCGridTextBoxControl::FormatType
  .property callconv(8) int32 NumPlaces()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_NumPlaces()
  } // end of property IASCGridTextBoxControl::NumPlaces
  .property callconv(8) string MaskInc()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_MaskInc()
  } // end of property IASCGridTextBoxControl::MaskInc
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControl
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 3A 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..:AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 47 72 69 64 54 65 78 74 42 6F   // ib.ASCGridTextBo
                                                                                                                          78 43 6F 6E 74 72 6F 6C 43 6C 61 73 73 00 00 )    // xControlClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 33 2D 46 37 30 34   // ..$00400033-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControl

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControlClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl,
                  AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 31 2D 30 38 37 41   // ..$00400031-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCGridTextBoxControlClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_DefaultValue() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_DefaultValue
  } // end of method ASCGridTextBoxControlClass::get_DefaultValue

  .method public hidebysig newslot specialname virtual 
          instance uint32  get_MaxSize() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_MaxSize
  } // end of method ASCGridTextBoxControlClass::get_MaxSize

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_VarType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_VarType
  } // end of method ASCGridTextBoxControlClass::get_VarType

  .method public hidebysig newslot virtual 
          instance bool  UseFormat() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::UseFormat
  } // end of method ASCGridTextBoxControlClass::UseFormat

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_FormatType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_FormatType
  } // end of method ASCGridTextBoxControlClass::get_FormatType

  .method public hidebysig newslot specialname virtual 
          instance int32  get_NumPlaces() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_NumPlaces
  } // end of method ASCGridTextBoxControlClass::get_NumPlaces

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_MaskInc() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridTextBoxControl::get_MaskInc
  } // end of method ASCGridTextBoxControlClass::get_MaskInc

  .property callconv(8) object DefaultValue()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControlClass::get_DefaultValue()
  } // end of property ASCGridTextBoxControlClass::DefaultValue
  .property callconv(8) uint32 MaxSize()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance uint32 AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControlClass::get_MaxSize()
  } // end of property ASCGridTextBoxControlClass::MaxSize
  .property callconv(8) object VarType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControlClass::get_VarType()
  } // end of property ASCGridTextBoxControlClass::VarType
  .property callconv(8) object FormatType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControlClass::get_FormatType()
  } // end of property ASCGridTextBoxControlClass::FormatType
  .property callconv(8) int32 NumPlaces()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControlClass::get_NumPlaces()
  } // end of property ASCGridTextBoxControlClass::NumPlaces
  .property callconv(8) string MaskInc()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControlClass::get_MaskInc()
  } // end of property ASCGridTextBoxControlClass::MaskInc
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridTextBoxControlClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 34 2D 46 37 30 34   // ..$00400034-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState 
          get_DefaultState() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                            69 62 2E 41 53 43 43 68 65 63 6B 42 6F 78 53 74   // ib.ASCCheckBoxSt
                                                                                                            61 74 65 00 00 )                                  // ate..
  } // end of method IASCGridCheckBoxControl::get_DefaultState

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridCheckBoxControl::get_Type

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Checked() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridCheckBoxControl::get_Checked

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_UnChecked() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridCheckBoxControl::get_UnChecked

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_CheckDisplay() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridCheckBoxControl::get_CheckDisplay

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_UnCheckedDisplay() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridCheckBoxControl::get_UnCheckedDisplay

  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState
          DefaultState()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                            69 62 2E 41 53 43 43 68 65 63 6B 42 6F 78 53 74   // ib.ASCCheckBoxSt
                                                                                                            61 74 65 00 00 )                                  // ate..
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_DefaultState()
  } // end of property IASCGridCheckBoxControl::DefaultState
  .property callconv(8) object Type()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_Type()
  } // end of property IASCGridCheckBoxControl::Type
  .property callconv(8) object Checked()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_Checked()
  } // end of property IASCGridCheckBoxControl::Checked
  .property callconv(8) object UnChecked()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_UnChecked()
  } // end of property IASCGridCheckBoxControl::UnChecked
  .property callconv(8) string CheckDisplay()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_CheckDisplay()
  } // end of property IASCGridCheckBoxControl::CheckDisplay
  .property callconv(8) string UnCheckedDisplay()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_UnCheckedDisplay()
  } // end of property IASCGridCheckBoxControl::UnCheckedDisplay
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControl
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 34 2D 46 37 30 34   // ..$00400034-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 3B 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..;AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 47 72 69 64 43 68 65 63 6B 42   // ib.ASCGridCheckB
                                                                                                                          6F 78 43 6F 6E 74 72 6F 6C 43 6C 61 73 73 00 00 ) // oxControlClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControl

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControlClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl,
                  AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 32 2D 30 38 37 41   // ..$00400032-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCGridCheckBoxControlClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState 
          get_DefaultState() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                            69 62 2E 41 53 43 43 68 65 63 6B 42 6F 78 53 74   // ib.ASCCheckBoxSt
                                                                                                            61 74 65 00 00 )                                  // ate..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_DefaultState
  } // end of method ASCGridCheckBoxControlClass::get_DefaultState

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_Type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_Type
  } // end of method ASCGridCheckBoxControlClass::get_Type

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_Checked() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_Checked
  } // end of method ASCGridCheckBoxControlClass::get_Checked

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_UnChecked() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_UnChecked
  } // end of method ASCGridCheckBoxControlClass::get_UnChecked

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_CheckDisplay() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_CheckDisplay
  } // end of method ASCGridCheckBoxControlClass::get_CheckDisplay

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_UnCheckedDisplay() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridCheckBoxControl::get_UnCheckedDisplay
  } // end of method ASCGridCheckBoxControlClass::get_UnCheckedDisplay

  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState
          DefaultState()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 30 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..0AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                            69 62 2E 41 53 43 43 68 65 63 6B 42 6F 78 53 74   // ib.ASCCheckBoxSt
                                                                                                            61 74 65 00 00 )                                  // ate..
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControlClass::get_DefaultState()
  } // end of property ASCGridCheckBoxControlClass::DefaultState
  .property callconv(8) object Type()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControlClass::get_Type()
  } // end of property ASCGridCheckBoxControlClass::Type
  .property callconv(8) object Checked()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControlClass::get_Checked()
  } // end of property ASCGridCheckBoxControlClass::Checked
  .property callconv(8) object UnChecked()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControlClass::get_UnChecked()
  } // end of property ASCGridCheckBoxControlClass::UnChecked
  .property callconv(8) string CheckDisplay()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControlClass::get_CheckDisplay()
  } // end of property ASCGridCheckBoxControlClass::CheckDisplay
  .property callconv(8) string UnCheckedDisplay()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControlClass::get_UnCheckedDisplay()
  } // end of property ASCGridCheckBoxControlClass::UnCheckedDisplay
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridCheckBoxControlClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 35 2D 46 37 30 34   // ..$00400035-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_DefaultValue() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridComboBoxControl::get_DefaultValue

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridComboBoxControl::get_Type

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          Item([in] int32& Index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridComboBoxControl::Item

  .method public hidebysig newslot abstract virtual 
          instance int32  Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridComboBoxControl::Count

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( idispatch ) 
          GetEnum() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridComboBoxControl::GetEnum

  .property callconv(8) object DefaultValue()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl::get_DefaultValue()
  } // end of property IASCGridComboBoxControl::DefaultValue
  .property callconv(8) object Type()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl::get_Type()
  } // end of property IASCGridComboBoxControl::Type
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxControl
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 3B 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..;AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 47 72 69 64 43 6F 6D 62 6F 42   // ib.ASCGridComboB
                                                                                                                          6F 78 43 6F 6E 74 72 6F 6C 43 6C 61 73 73 00 00 ) // oxControlClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 35 2D 46 37 30 34   // ..$00400035-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxControl

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxControlClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl,
                  AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxControl
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 33 2D 30 38 37 41   // ..$00400033-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCGridComboBoxControlClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_DefaultValue() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl::get_DefaultValue
  } // end of method ASCGridComboBoxControlClass::get_DefaultValue

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_Type() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl::get_Type
  } // end of method ASCGridComboBoxControlClass::get_Type

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          Item([in] int32& Index) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl::Item
  } // end of method ASCGridComboBoxControlClass::Item

  .method public hidebysig newslot virtual 
          instance int32  Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl::Count
  } // end of method ASCGridComboBoxControlClass::Count

  .method public hidebysig newslot virtual 
          instance object 
          marshal( idispatch ) 
          GetEnum() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxControl::GetEnum
  } // end of method ASCGridComboBoxControlClass::GetEnum

  .property callconv(8) object DefaultValue()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxControlClass::get_DefaultValue()
  } // end of property ASCGridComboBoxControlClass::DefaultValue
  .property callconv(8) object Type()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxControlClass::get_Type()
  } // end of property ASCGridComboBoxControlClass::Type
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxControlClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 36 2D 46 37 30 34   // ..$00400036-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridComboBoxItem::get_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_DisplayName() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridComboBoxItem::get_DisplayName

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_QueryName() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCGridComboBoxItem::get_QueryName

  .property callconv(8) object Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem::get_Value()
  } // end of property IASCGridComboBoxItem::Value
  .property callconv(8) string DisplayName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem::get_DisplayName()
  } // end of property IASCGridComboBoxItem::DisplayName
  .property callconv(8) string QueryName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem::get_QueryName()
  } // end of property IASCGridComboBoxItem::QueryName
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxItem
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 38 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..8AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 47 72 69 64 43 6F 6D 62 6F 42   // ib.ASCGridComboB
                                                                                                                          6F 78 49 74 65 6D 43 6C 61 73 73 00 00 )          // oxItemClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 36 2D 46 37 30 34   // ..$00400036-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxItem

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxItemClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem,
                  AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxItem
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 34 2D 30 38 37 41   // ..$00400034-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCGridComboBoxItemClass::.ctor

  .method public hidebysig newslot specialname virtual 
          instance object 
          marshal( struct) 
          get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem::get_Value
  } // end of method ASCGridComboBoxItemClass::get_Value

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_DisplayName() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem::get_DisplayName
  } // end of method ASCGridComboBoxItemClass::get_DisplayName

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_QueryName() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridComboBoxItem::get_QueryName
  } // end of method ASCGridComboBoxItemClass::get_QueryName

  .property callconv(8) object Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxItemClass::get_Value()
  } // end of property ASCGridComboBoxItemClass::Value
  .property callconv(8) string DisplayName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxItemClass::get_DisplayName()
  } // end of property ASCGridComboBoxItemClass::DisplayName
  .property callconv(8) string QueryName()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxItemClass::get_QueryName()
  } // end of property ASCGridComboBoxItemClass::QueryName
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridComboBoxItemClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCGridColumnCollection
       implements [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 37 2D 46 37 30 34   // ..$00400037-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          Item([in] object  marshal( struct) vtVal) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method IASCGridColumnCollection::Item

  .method public hidebysig newslot abstract virtual 
          instance int32  Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method IASCGridColumnCollection::Count

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IASCGridColumnCollection::GetEnumerator

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCGridColumnCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridColumnCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 37 2D 46 37 30 34   // ..$00400037-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 3C 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..<AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 47 72 69 64 43 6F 6C 75 6D 6E   // ib.ASCGridColumn
                                                                                                                          43 6F 6C 6C 65 63 74 69 6F 6E 43 6C 61 73 73 00   // CollectionClass.
                                                                                                                          00 ) 
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollection

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridColumnCollection,
                  AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 35 2D 30 38 37 41   // ..$00400035-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCGridColumnCollectionClass::.ctor

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          Item([in] object  marshal( struct) vtVal) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridColumnCollection::Item
  } // end of method ASCGridColumnCollectionClass::Item

  .method public hidebysig newslot virtual 
          instance int32  Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridColumnCollection::Count
  } // end of method ASCGridColumnCollectionClass::Count

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridColumnCollection::GetEnumerator
  } // end of method ASCGridColumnCollectionClass::GetEnumerator

} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridColumnCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCGridStyleCollection
       implements [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 38 2D 46 37 30 34   // ..$00400038-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          Item([in] int32& pIndex,
               [out] valuetype AspenTech.AspenPlus.ASCclasslib.ASCControlType& pType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2E 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ...AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                            69 62 2E 41 53 43 43 6F 6E 74 72 6F 6C 54 79 70   // ib.ASCControlTyp
                                                                                                            65 00 00 )                                        // e..
  } // end of method IASCGridStyleCollection::Item

  .method public hidebysig newslot abstract virtual 
          instance int32  Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method IASCGridStyleCollection::Count

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
  } // end of method IASCGridStyleCollection::GetEnumerator

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCGridStyleCollection

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollection
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridStyleCollection
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 38 2D 46 37 30 34   // ..$00400038-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 3B 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..;AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 47 72 69 64 53 74 79 6C 65 43   // ib.ASCGridStyleC
                                                                                                                          6F 6C 6C 65 63 74 69 6F 6E 43 6C 61 73 73 00 00 ) // ollectionClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollection

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollectionClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCGridStyleCollection,
                  AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollection,
                  [mscorlib]System.Collections.IEnumerable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 36 2D 30 38 37 41   // ..$00400036-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 49 74 65 6D 00 00 )                      // ...Item..
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCGridStyleCollectionClass::.ctor

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          Item([in] int32& pIndex,
               [out] valuetype AspenTech.AspenPlus.ASCclasslib.ASCControlType& pType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2E 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ...AspenTech.Asp
                                                                                                            65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                            69 62 2E 41 53 43 43 6F 6E 74 72 6F 6C 54 79 70   // ib.ASCControlTyp
                                                                                                            65 00 00 )                                        // e..
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridStyleCollection::Item
  } // end of method ASCGridStyleCollectionClass::Item

  .method public hidebysig newslot virtual 
          instance int32  Count() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridStyleCollection::Count
  } // end of method ASCGridStyleCollectionClass::Count

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.Collections.IEnumerator 
          marshal( custom ("System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","")) 
          GetEnumerator() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 FC FF FF FF 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCGridStyleCollection::GetEnumerator
  } // end of method ASCGridStyleCollectionClass::GetEnumerator

} // end of class AspenTech.AspenPlus.ASCclasslib.ASCGridStyleCollectionClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 34 2D 46 37 30 34   // ..$00400044-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          AddTasks([in] string  marshal( bstr) xml) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method IASCDynamicsService::AddTasks

  .method public hidebysig newslot abstract virtual 
          instance void  ActivateTask([in] string  marshal( bstr) taskName,
                                      [in] bool active) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
  } // end of method IASCDynamicsService::ActivateTask

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveTask([in] string  marshal( bstr) taskName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
  } // end of method IASCDynamicsService::RemoveTask

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCDynamicsService
       implements AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 34 2D 46 37 30 34   // ..$00400044-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 37 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..7AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 44 79 6E 61 6D 69 63 73 53 65   // ib.ASCDynamicsSe
                                                                                                                          72 76 69 63 65 43 6C 61 73 73 00 00 )             // rviceClass..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCDynamicsService

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService2
       implements AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 35 33 2D 46 37 30 34   // ..$00400053-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          AddTasks([in] string  marshal( bstr) xml) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method IASCDynamicsService2::AddTasks

  .method public hidebysig newslot abstract virtual 
          instance void  ActivateTask([in] string  marshal( bstr) taskName,
                                      [in] bool active) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
  } // end of method IASCDynamicsService2::ActivateTask

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveTask([in] string  marshal( bstr) taskName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
  } // end of method IASCDynamicsService2::RemoveTask

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          AddTasks2([in] string  marshal( bstr) xml,
                    [in] string  marshal( bstr) scope) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
  } // end of method IASCDynamicsService2::AddTasks2

  .method public hidebysig newslot abstract virtual 
          instance void  ActivateTask2([in] string  marshal( bstr) taskName,
                                       [in] bool active,
                                       [in] string  marshal( bstr) scope) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
  } // end of method IASCDynamicsService2::ActivateTask2

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveTask2([in] string  marshal( bstr) taskName,
                                     [in] string  marshal( bstr) scope) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 00 00 00 00 ) 
  } // end of method IASCDynamicsService2::RemoveTask2

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService2

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCDynamicsServiceClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService,
                  AspenTech.AspenPlus.ASCclasslib.ASCDynamicsService,
                  AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 37 2D 30 38 37 41   // ..$00400037-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCDynamicsServiceClass::.ctor

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          AddTasks([in] string  marshal( bstr) xml) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService::AddTasks
  } // end of method ASCDynamicsServiceClass::AddTasks

  .method public hidebysig newslot virtual 
          instance void  ActivateTask([in] string  marshal( bstr) taskName,
                                      [in] bool active) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService::ActivateTask
  } // end of method ASCDynamicsServiceClass::ActivateTask

  .method public hidebysig newslot virtual 
          instance void  RemoveTask([in] string  marshal( bstr) taskName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService::RemoveTask
  } // end of method ASCDynamicsServiceClass::RemoveTask

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          IASCDynamicsService2_AddTasks([in] string  marshal( bstr) xml) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService2::AddTasks
  } // end of method ASCDynamicsServiceClass::IASCDynamicsService2_AddTasks

  .method public hidebysig newslot virtual 
          instance void  IASCDynamicsService2_ActivateTask([in] string  marshal( bstr) taskName,
                                                           [in] bool active) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService2::ActivateTask
  } // end of method ASCDynamicsServiceClass::IASCDynamicsService2_ActivateTask

  .method public hidebysig newslot virtual 
          instance void  IASCDynamicsService2_RemoveTask([in] string  marshal( bstr) taskName) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService2::RemoveTask
  } // end of method ASCDynamicsServiceClass::IASCDynamicsService2_RemoveTask

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          AddTasks2([in] string  marshal( bstr) xml,
                    [in] string  marshal( bstr) scope) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService2::AddTasks2
  } // end of method ASCDynamicsServiceClass::AddTasks2

  .method public hidebysig newslot virtual 
          instance void  ActivateTask2([in] string  marshal( bstr) taskName,
                                       [in] bool active,
                                       [in] string  marshal( bstr) scope) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService2::ActivateTask2
  } // end of method ASCDynamicsServiceClass::ActivateTask2

  .method public hidebysig newslot virtual 
          instance void  RemoveTask2([in] string  marshal( bstr) taskName,
                                     [in] string  marshal( bstr) scope) runtime managed internalcall
  {
    .override AspenTech.AspenPlus.ASCclasslib.IASCDynamicsService2::RemoveTask2
  } // end of method ASCDynamicsServiceClass::RemoveTask2

} // end of class AspenTech.AspenPlus.ASCclasslib.ASCDynamicsServiceClass

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCVariableProfile
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 35 2D 46 37 30 34   // ..$00400045-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetProfileByIndex([in] int32 varIndex,
                            [in] float64 startTime,
                            [in] float64 endTime,
                            [in] float64 interval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method IASCVariableProfile::GetProfileByIndex

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetProfileByName([in] string  marshal( bstr) varName,
                           [in] float64 startTime,
                           [in] float64 endTime,
                           [in] float64 interval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
  } // end of method IASCVariableProfile::GetProfileByName

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCVariableProfile

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCVariableProfile
       implements AspenTech.AspenPlus.ASCclasslib.IASCVariableProfile
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 37 41 73 70 65 6E 54 65 63 68 2E 41 73 70   // ..7AspenTech.Asp
                                                                                                                          65 6E 50 6C 75 73 2E 41 53 43 63 6C 61 73 73 6C   // enPlus.ASCclassl
                                                                                                                          69 62 2E 41 53 43 56 61 72 69 61 62 6C 65 50 72   // ib.ASCVariablePr
                                                                                                                          6F 66 69 6C 65 43 6C 61 73 73 00 00 )             // ofileClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 35 2D 46 37 30 34   // ..$00400045-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVariableProfile

.class public auto ansi import AspenTech.AspenPlus.ASCclasslib.ASCVariableProfileClass
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.IASCVariableProfile,
                  AspenTech.AspenPlus.ASCclasslib.ASCVariableProfile
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 38 2D 30 38 37 41   // ..$00400038-087A
                                                                                                  2D 34 44 44 39 2D 42 36 46 33 2D 41 39 39 44 37   // -4DD9-B6F3-A99D7
                                                                                                  43 42 41 31 30 33 39 00 00 )                      // CBA1039..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method assembly specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method ASCVariableProfileClass::.ctor

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetProfileByIndex([in] int32 varIndex,
                            [in] float64 startTime,
                            [in] float64 endTime,
                            [in] float64 interval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariableProfile::GetProfileByIndex
  } // end of method ASCVariableProfileClass::GetProfileByIndex

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetProfileByName([in] string  marshal( bstr) varName,
                           [in] float64 startTime,
                           [in] float64 endTime,
                           [in] float64 interval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .override AspenTech.AspenPlus.ASCclasslib.IASCVariableProfile::GetProfileByName
  } // end of method ASCVariableProfileClass::GetProfileByName

} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVariableProfileClass

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCSpec
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec ASCSpec_Calc = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec ASCSpec_Constant = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec ASCSpec_Indep = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec ASCSpec_Meas = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec ASCSpec_Param = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec ASCSpec_Optim = int32(0x00000005)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec ASCSpec_Recon = int32(0x00000006)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec ASCSpec_Initial = int32(0x00000007)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCSpec

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCActiveBound
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_NotAtBounds = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_StepLower = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_StepUpper = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_ExceededStepLower = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_ExceededStepUpper = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_Lower = int32(0x00000005)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_Upper = int32(0x00000006)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_ExceededLower = int32(0x00000007)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_ExceededUpper = int32(0x00000008)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_SoftLower = int32(0x00000009)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_SoftUpper = int32(0x0000000A)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_ExceededSoftLower = int32(0x0000000B)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_ExceededSoftUpper = int32(0x0000000C)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_RelaxedLower = int32(0x0000000D)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_RelaxedUpper = int32(0x0000000E)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_ExceededRelaxedLower = int32(0x0000000F)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_ExceededRelaxedUpper = int32(0x00000010)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound ASCActiveBound_Pinched = int32(0x00000011)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCActiveBound

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCVarQuality
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality ASCVarQuality_Good = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality ASCVarQuality_Bad = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality ASCVarQuality_Override = int32(0x00000002)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVarQuality

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType ASCVarBoundType_Hard = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType ASCVarBoundType_Relaxed = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType ASCVarBoundType_Soft = int32(0x00000002)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCPortDir
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir ASCPortDir_Unspecified = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir ASCPortDir_Input = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortDir ASCPortDir_Output = int32(0x00000002)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCPortDir

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCPortType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType ASCPortType_Unspecified = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType ASCPortType_Material = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType ASCPortType_Information = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCPortType ASCPortType_Special_Ordered_Set = int32(0x00000003)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCPortType

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess ASCReadOnly = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess ASCReadWrite = int32(0x00000001)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCParameterAccess

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method DASCSimulationMsgsEvents_OnNewLineEventHandler::.ctor

  .method public virtual instance void  Invoke([in] string  marshal( bstr) bText) runtime managed preservesig
  {
  } // end of method DASCSimulationMsgsEvents_OnNewLineEventHandler::Invoke

} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCSimEventSink
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 32 34 2D 46 37 30 34   // ..$00400024-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  OnNewEvent([in] int32 lEventId,
                                    [in] object  marshal( struct) Hint1,
                                    [in] object  marshal( struct) Hint2) runtime managed internalcall
  {
  } // end of method IASCSimEventSink::OnNewEvent

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCSimEventSink

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType ASCExternalFile_XFile = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType ASCExternalFile_VarFile = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType ASCExternalFile_FileExists = int32(0x00000002)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCExternalFileType

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCControlType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCControlType ECT_STATIC = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCControlType ECT_TEXT = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCControlType ECT_CHECKBOX = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCControlType ECT_COMBOBOX = int32(0x00000003)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCControlType

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState ECBD_UNSPECIFIED = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState ECBD_CHECKED = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState ECBD_UNCHECKED = int32(0x00000002)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCCheckBoxState

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0003
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0003 ECT_STATIC = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0003 ECT_TEXT = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0003 ECT_CHECKBOX = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0003 ECT_COMBOBOX = int32(0x00000003)
} // end of class AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0003

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0004
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0004 ECBD_UNSPECIFIED = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0004 ECBD_CHECKED = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0004 ECBD_UNCHECKED = int32(0x00000002)
} // end of class AspenTech.AspenPlus.ASCclasslib.__MIDL___MIDL_itf_ascclasslib_0000_0000_0004

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCObjectCollectionHelper
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 33 39 2D 46 37 30 34   // ..$00400039-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot abstract virtual 
          instance int32  Name2Index([in] string  marshal( bstr) bName) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
  } // end of method IASCObjectCollectionHelper::Name2Index

} // end of class AspenTech.AspenPlus.ASCclasslib.IASCObjectCollectionHelper

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCBlock2
       implements AspenTech.AspenPlus.ASCclasslib.IASCBlock
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 30 2D 46 37 30 34   // ..$00400040-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsBlockContainer() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_IsBlockContainer

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection 
          marshal( interface ) 
          get_Blocks() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_Blocks

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection 
          marshal( interface ) 
          get_Variables() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_Variables

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection 
          marshal( interface ) 
          get_Equations() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_Equations

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection 
          marshal( interface ) 
          get_Parameters() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_Parameters

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.ASCPortCollection 
          marshal( interface ) 
          get_Ports() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_Ports

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsIncluded() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCBlock2::get_IsIncluded

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_Parent()
  } // end of property IASCBlock2::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_Simulation()
  } // end of property IASCBlock2::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_Name()
  } // end of property IASCBlock2::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_IsValid()
  } // end of property IASCBlock2::IsValid
  .property callconv(8) bool IsBlockContainer()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_IsBlockContainer()
  } // end of property IASCBlock2::IsBlockContainer
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection
          Blocks()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCBlockCollection AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_Blocks()
  } // end of property IASCBlock2::Blocks
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection
          Variables()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCVariableCollection AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_Variables()
  } // end of property IASCBlock2::Variables
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection
          Equations()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCEquationCollection AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_Equations()
  } // end of property IASCBlock2::Equations
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection
          Parameters()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCParameterCollection AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_Parameters()
  } // end of property IASCBlock2::Parameters
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.ASCPortCollection
          Ports()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.ASCPortCollection AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_Ports()
  } // end of property IASCBlock2::Ports
  .property callconv(8) bool IsIncluded()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCBlock2::get_IsIncluded()
  } // end of property IASCBlock2::IsIncluded
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCBlock2

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCVariable2
       implements AspenTech.AspenPlus.ASCclasslib.IASCVariable
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 32 2D 46 37 30 34   // ..$00400042-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Value([in] float64 Value) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_LowerBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_LowerBound

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_LowerBound([in] float64 Lower) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_LowerBound

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_UpperBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_UpperBound

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UpperBound([in] float64 Upper) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_UpperBound

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec 
          get_Spec() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Spec

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Spec([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec Spec) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_Spec

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Scale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Scale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Scale([in] float64 Scale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_Scale

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_SBWeight() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_SBWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_SBWeight([in] float64 Weight) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_SBWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_ShadowPrice() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_ShadowPrice

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ShadowPrice([in] float64 Price) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_ShadowPrice

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Marked() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Marked

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Marked([in] bool Marked) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_Marked

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Modified([in] string  marshal( bstr) Attrib) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Modified

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Modified([in] string  marshal( bstr) Attrib,
                                      [in] bool Modified) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_Modified

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound 
          get_ActiveBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_ActiveBound

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality 
          get_Quality() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Quality

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Quality([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality Quality) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_Quality

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_UOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UOM([in] string  marshal( bstr) pbUOM) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Initial() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Initial

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Initial([in] float64 Initial) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_Initial

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Change() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Change

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Change([in] float64 Change) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_Change

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Number() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Number

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType 
          get_BoundType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_BoundType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_BoundType([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType BoundType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_BoundType

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_InternalScale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_InternalScale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_InternalScale([in] float64 intscale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_InternalScale

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Step() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Step

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Step([in] float64 Step) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_Step

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_PhysicalType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_PhysicalType

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_UOMList() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_UOMList

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam 
          get_HomotopyParameter() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_HomotopyParameter

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_HomotopyParameter([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_HomotopyParameter

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_HomotopyTarget() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_HomotopyTarget

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_HomotopyTarget([in] float64 Target) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::set_HomotopyTarget

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Description() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable2::get_Description

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Parent()
  } // end of property IASCVariable2::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Simulation()
  } // end of property IASCVariable2::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Name()
  } // end of property IASCVariable2::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_IsValid()
  } // end of property IASCVariable2::IsValid
  .property callconv(8) float64 Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_Value(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Value()
  } // end of property IASCVariable2::Value
  .property callconv(8) float64 LowerBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_LowerBound(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_LowerBound()
  } // end of property IASCVariable2::LowerBound
  .property callconv(8) float64 UpperBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_UpperBound()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_UpperBound(float64)
  } // end of property IASCVariable2::UpperBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec
          Spec()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Spec()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_Spec(valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec)
  } // end of property IASCVariable2::Spec
  .property callconv(8) float64 Scale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Scale()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_Scale(float64)
  } // end of property IASCVariable2::Scale
  .property callconv(8) float64 SBWeight()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_SBWeight(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_SBWeight()
  } // end of property IASCVariable2::SBWeight
  .property callconv(8) float64 ShadowPrice()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_ShadowPrice(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_ShadowPrice()
  } // end of property IASCVariable2::ShadowPrice
  .property callconv(8) bool Marked()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Marked()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_Marked(bool)
  } // end of property IASCVariable2::Marked
  .property callconv(8) bool Modified(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Modified(string)
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_Modified(string,
                                                                                   bool)
  } // end of property IASCVariable2::Modified
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound
          ActiveBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_ActiveBound()
  } // end of property IASCVariable2::ActiveBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality
          Quality()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_Quality(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality)
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Quality()
  } // end of property IASCVariable2::Quality
  .property callconv(8) string UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_UOM(string)
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_UOM()
  } // end of property IASCVariable2::UOM
  .property callconv(8) float64 Initial()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Initial()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_Initial(float64)
  } // end of property IASCVariable2::Initial
  .property callconv(8) float64 Change()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_Change(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Change()
  } // end of property IASCVariable2::Change
  .property callconv(8) int32 Number()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Number()
  } // end of property IASCVariable2::Number
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType
          BoundType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_BoundType()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_BoundType(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType)
  } // end of property IASCVariable2::BoundType
  .property callconv(8) float64 InternalScale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_InternalScale()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_InternalScale(float64)
  } // end of property IASCVariable2::InternalScale
  .property callconv(8) float64 Step()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_Step(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Step()
  } // end of property IASCVariable2::Step
  .property callconv(8) string PhysicalType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_PhysicalType()
  } // end of property IASCVariable2::PhysicalType
  .property callconv(8) object UOMList()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_UOMList()
  } // end of property IASCVariable2::UOMList
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam
          HomotopyParameter()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_HomotopyParameter()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_HomotopyParameter(valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam)
  } // end of property IASCVariable2::HomotopyParameter
  .property callconv(8) float64 HomotopyTarget()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_HomotopyTarget()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable2::set_HomotopyTarget(float64)
  } // end of property IASCVariable2::HomotopyTarget
  .property callconv(8) string Description()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable2::get_Description()
  } // end of property IASCVariable2::Description
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCVariable2

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam ASCHomotopyParam_NotAParam = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam ASCHomotopyParam_IsAParam = int32(0x00000001)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCVariable3
       implements AspenTech.AspenPlus.ASCclasslib.IASCVariable2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 33 2D 46 37 30 34   // ..$00400043-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Value([in] float64 Value) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_LowerBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_LowerBound

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_LowerBound([in] float64 Lower) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_LowerBound

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_UpperBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_UpperBound

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UpperBound([in] float64 Upper) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_UpperBound

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec 
          get_Spec() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Spec

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Spec([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec Spec) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_Spec

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Scale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Scale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Scale([in] float64 Scale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_Scale

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_SBWeight() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_SBWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_SBWeight([in] float64 Weight) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_SBWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_ShadowPrice() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_ShadowPrice

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ShadowPrice([in] float64 Price) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_ShadowPrice

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Marked() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Marked

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Marked([in] bool Marked) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_Marked

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Modified([in] string  marshal( bstr) Attrib) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Modified

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Modified([in] string  marshal( bstr) Attrib,
                                      [in] bool Modified) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_Modified

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound 
          get_ActiveBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_ActiveBound

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality 
          get_Quality() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Quality

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Quality([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality Quality) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_Quality

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_UOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UOM([in] string  marshal( bstr) pbUOM) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Initial() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Initial

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Initial([in] float64 Initial) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_Initial

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Change() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Change

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Change([in] float64 Change) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_Change

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Number() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Number

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType 
          get_BoundType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_BoundType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_BoundType([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType BoundType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_BoundType

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_InternalScale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_InternalScale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_InternalScale([in] float64 intscale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_InternalScale

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Step() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Step

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Step([in] float64 Step) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_Step

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_PhysicalType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_PhysicalType

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_UOMList() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_UOMList

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam 
          get_HomotopyParameter() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_HomotopyParameter

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_HomotopyParameter([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_HomotopyParameter

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_HomotopyTarget() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_HomotopyTarget

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_HomotopyTarget([in] float64 Target) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_HomotopyTarget

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Description() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_Description

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType 
          get_VariableType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::get_VariableType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_VariableType([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType VariableType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable3::set_VariableType

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Parent()
  } // end of property IASCVariable3::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Simulation()
  } // end of property IASCVariable3::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Name()
  } // end of property IASCVariable3::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_IsValid()
  } // end of property IASCVariable3::IsValid
  .property callconv(8) float64 Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Value()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_Value(float64)
  } // end of property IASCVariable3::Value
  .property callconv(8) float64 LowerBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_LowerBound(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_LowerBound()
  } // end of property IASCVariable3::LowerBound
  .property callconv(8) float64 UpperBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_UpperBound(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_UpperBound()
  } // end of property IASCVariable3::UpperBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec
          Spec()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Spec()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_Spec(valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec)
  } // end of property IASCVariable3::Spec
  .property callconv(8) float64 Scale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_Scale(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Scale()
  } // end of property IASCVariable3::Scale
  .property callconv(8) float64 SBWeight()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_SBWeight()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_SBWeight(float64)
  } // end of property IASCVariable3::SBWeight
  .property callconv(8) float64 ShadowPrice()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_ShadowPrice(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_ShadowPrice()
  } // end of property IASCVariable3::ShadowPrice
  .property callconv(8) bool Marked()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_Marked(bool)
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Marked()
  } // end of property IASCVariable3::Marked
  .property callconv(8) bool Modified(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Modified(string)
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_Modified(string,
                                                                                   bool)
  } // end of property IASCVariable3::Modified
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound
          ActiveBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_ActiveBound()
  } // end of property IASCVariable3::ActiveBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality
          Quality()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Quality()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_Quality(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality)
  } // end of property IASCVariable3::Quality
  .property callconv(8) string UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_UOM()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_UOM(string)
  } // end of property IASCVariable3::UOM
  .property callconv(8) float64 Initial()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Initial()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_Initial(float64)
  } // end of property IASCVariable3::Initial
  .property callconv(8) float64 Change()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Change()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_Change(float64)
  } // end of property IASCVariable3::Change
  .property callconv(8) int32 Number()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Number()
  } // end of property IASCVariable3::Number
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType
          BoundType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_BoundType(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType)
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_BoundType()
  } // end of property IASCVariable3::BoundType
  .property callconv(8) float64 InternalScale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_InternalScale()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_InternalScale(float64)
  } // end of property IASCVariable3::InternalScale
  .property callconv(8) float64 Step()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Step()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_Step(float64)
  } // end of property IASCVariable3::Step
  .property callconv(8) string PhysicalType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_PhysicalType()
  } // end of property IASCVariable3::PhysicalType
  .property callconv(8) object UOMList()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_UOMList()
  } // end of property IASCVariable3::UOMList
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam
          HomotopyParameter()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_HomotopyParameter(valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam)
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_HomotopyParameter()
  } // end of property IASCVariable3::HomotopyParameter
  .property callconv(8) float64 HomotopyTarget()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_HomotopyTarget()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_HomotopyTarget(float64)
  } // end of property IASCVariable3::HomotopyTarget
  .property callconv(8) string Description()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_Description()
  } // end of property IASCVariable3::Description
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType
          VariableType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType AspenTech.AspenPlus.ASCclasslib.IASCVariable3::get_VariableType()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable3::set_VariableType(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType)
  } // end of property IASCVariable3::VariableType
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCVariable3

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.ASCVariableType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType ASCVariableType_ALGEBRAIC = int32(0x00000000)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType ASCVariableType_STATE = int32(0x00000001)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType ASCVariableType_DIFFERENTIAL = int32(0x00000002)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType ASCVariableType_INTEGER = int32(0x00000003)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType ASCVariableType_DISCRETE_ESLACK = int32(0x00000004)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType ASCVariableType_BINARY = int32(0x00000005)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType ASCVariableType_PARTIAL_INTEGER = int32(0x00000006)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType ASCVariableType_SEMI_CONTINUOUS = int32(0x00000007)
  .field public static literal valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType ASCVariableType_SEMI_CONTINUOUS_INTEGER = int32(0x00000040)
} // end of class AspenTech.AspenPlus.ASCclasslib.ASCVariableType

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCVariable4
       implements AspenTech.AspenPlus.ASCclasslib.IASCVariable3
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 34 38 2D 46 37 30 34   // ..$00400048-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Value([in] float64 Value) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_LowerBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_LowerBound

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_LowerBound([in] float64 Lower) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_LowerBound

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_UpperBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_UpperBound

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UpperBound([in] float64 Upper) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_UpperBound

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec 
          get_Spec() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Spec

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Spec([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec Spec) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_Spec

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Scale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Scale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Scale([in] float64 Scale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_Scale

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_SBWeight() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_SBWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_SBWeight([in] float64 Weight) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_SBWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_ShadowPrice() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_ShadowPrice

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ShadowPrice([in] float64 Price) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_ShadowPrice

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Marked() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Marked

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Marked([in] bool Marked) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_Marked

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Modified([in] string  marshal( bstr) Attrib) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Modified

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Modified([in] string  marshal( bstr) Attrib,
                                      [in] bool Modified) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_Modified

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound 
          get_ActiveBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_ActiveBound

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality 
          get_Quality() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Quality

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Quality([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality Quality) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_Quality

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_UOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UOM([in] string  marshal( bstr) pbUOM) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Initial() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Initial

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Initial([in] float64 Initial) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_Initial

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Change() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Change

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Change([in] float64 Change) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_Change

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Number() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Number

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType 
          get_BoundType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_BoundType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_BoundType([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType BoundType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_BoundType

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_InternalScale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_InternalScale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_InternalScale([in] float64 intscale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_InternalScale

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Step() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Step

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Step([in] float64 Step) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_Step

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_PhysicalType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_PhysicalType

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_UOMList() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_UOMList

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam 
          get_HomotopyParameter() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_HomotopyParameter

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_HomotopyParameter([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_HomotopyParameter

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_HomotopyTarget() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_HomotopyTarget

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_HomotopyTarget([in] float64 Target) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_HomotopyTarget

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Description() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_Description

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType 
          get_VariableType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_VariableType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_VariableType([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType VariableType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_VariableType

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_ConnectionType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::get_ConnectionType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ConnectionType([in] int32 ConnType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable4::set_ConnectionType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Description([in] string  marshal( bstr) A_1) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 03 60 00 00 )                         // .. ..`..
  } // end of method IASCVariable4::set_Description

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_PhysicalType([in] string  marshal( bstr) A_1) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 03 60 00 00 )                         // ..!..`..
  } // end of method IASCVariable4::set_PhysicalType

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Parent()
  } // end of property IASCVariable4::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Simulation()
  } // end of property IASCVariable4::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Name()
  } // end of property IASCVariable4::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_IsValid()
  } // end of property IASCVariable4::IsValid
  .property callconv(8) float64 Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_Value(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Value()
  } // end of property IASCVariable4::Value
  .property callconv(8) float64 LowerBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_LowerBound()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_LowerBound(float64)
  } // end of property IASCVariable4::LowerBound
  .property callconv(8) float64 UpperBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_UpperBound(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_UpperBound()
  } // end of property IASCVariable4::UpperBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec
          Spec()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_Spec(valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec)
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Spec()
  } // end of property IASCVariable4::Spec
  .property callconv(8) float64 Scale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Scale()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_Scale(float64)
  } // end of property IASCVariable4::Scale
  .property callconv(8) float64 SBWeight()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_SBWeight()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_SBWeight(float64)
  } // end of property IASCVariable4::SBWeight
  .property callconv(8) float64 ShadowPrice()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_ShadowPrice()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_ShadowPrice(float64)
  } // end of property IASCVariable4::ShadowPrice
  .property callconv(8) bool Marked()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_Marked(bool)
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Marked()
  } // end of property IASCVariable4::Marked
  .property callconv(8) bool Modified(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_Modified(string,
                                                                                   bool)
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Modified(string)
  } // end of property IASCVariable4::Modified
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound
          ActiveBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_ActiveBound()
  } // end of property IASCVariable4::ActiveBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality
          Quality()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Quality()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_Quality(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality)
  } // end of property IASCVariable4::Quality
  .property callconv(8) string UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_UOM()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_UOM(string)
  } // end of property IASCVariable4::UOM
  .property callconv(8) float64 Initial()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Initial()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_Initial(float64)
  } // end of property IASCVariable4::Initial
  .property callconv(8) float64 Change()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Change()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_Change(float64)
  } // end of property IASCVariable4::Change
  .property callconv(8) int32 Number()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Number()
  } // end of property IASCVariable4::Number
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType
          BoundType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_BoundType()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_BoundType(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType)
  } // end of property IASCVariable4::BoundType
  .property callconv(8) float64 InternalScale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_InternalScale()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_InternalScale(float64)
  } // end of property IASCVariable4::InternalScale
  .property callconv(8) float64 Step()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Step()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_Step(float64)
  } // end of property IASCVariable4::Step
  .property callconv(8) string PhysicalType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_PhysicalType()
  } // end of property IASCVariable4::PhysicalType
  .property callconv(8) object UOMList()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_UOMList()
  } // end of property IASCVariable4::UOMList
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam
          HomotopyParameter()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_HomotopyParameter()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_HomotopyParameter(valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam)
  } // end of property IASCVariable4::HomotopyParameter
  .property callconv(8) float64 HomotopyTarget()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_HomotopyTarget()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_HomotopyTarget(float64)
  } // end of property IASCVariable4::HomotopyTarget
  .property callconv(8) string Description()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_Description()
  } // end of property IASCVariable4::Description
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType
          VariableType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_VariableType()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_VariableType(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType)
  } // end of property IASCVariable4::VariableType
  .property callconv(8) int32 ConnectionType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_ConnectionType(int32)
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCVariable4::get_ConnectionType()
  } // end of property IASCVariable4::ConnectionType
  .property callconv(8) string Description_2()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 03 60 00 00 )                         // .. ..`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_Description(string)
  } // end of property IASCVariable4::Description_2
  .property callconv(8) string PhysicalType_2()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 03 60 00 00 )                         // ..!..`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable4::set_PhysicalType(string)
  } // end of property IASCVariable4::PhysicalType_2
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCVariable4

.class interface public abstract auto ansi import AspenTech.AspenPlus.ASCclasslib.IASCVariable5
       implements AspenTech.AspenPlus.ASCclasslib.IASCVariable4
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 30 34 30 30 30 35 30 2D 46 37 30 34   // ..$00400050-F704
                                                                                                  2D 34 39 41 38 2D 39 36 39 34 2D 32 32 44 41 36   // -49A8-9694-22DA6
                                                                                                  32 30 42 38 32 38 32 00 00 )                      // 20B8282..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 40 10 00 00 00 00 )                         // ..@.....
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCObject 
          marshal( interface ) 
          get_Parent() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Parent

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation 
          marshal( interface ) 
          get_Simulation() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Simulation

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Name

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_IsValid

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( iunknown ) 
          GetService([in] string  marshal( bstr) bService) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 02 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::GetService

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Value() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Value([in] float64 Value) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_Value

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_LowerBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_LowerBound

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_LowerBound([in] float64 Lower) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_LowerBound

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_UpperBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_UpperBound

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UpperBound([in] float64 Upper) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_UpperBound

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec 
          get_Spec() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Spec

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Spec([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec Spec) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_Spec

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Scale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Scale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Scale([in] float64 Scale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_Scale

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_SBWeight() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_SBWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_SBWeight([in] float64 Weight) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_SBWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_ShadowPrice() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_ShadowPrice

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ShadowPrice([in] float64 Price) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_ShadowPrice

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Marked() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Marked

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Marked([in] bool Marked) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_Marked

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_Modified([in] string  marshal( bstr) Attrib) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Modified

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Modified([in] string  marshal( bstr) Attrib,
                                      [in] bool Modified) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_Modified

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound 
          get_ActiveBound() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_ActiveBound

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality 
          get_Quality() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Quality

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Quality([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality Quality) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_Quality

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_UOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_UOM([in] string  marshal( bstr) pbUOM) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_UOM

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Initial() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Initial

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Initial([in] float64 Initial) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_Initial

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Change() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Change

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Change([in] float64 Change) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_Change

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Number() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Number

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType 
          get_BoundType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_BoundType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_BoundType([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType BoundType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_BoundType

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_InternalScale() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_InternalScale

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_InternalScale([in] float64 intscale) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_InternalScale

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Step() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Step

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Step([in] float64 Step) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_Step

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_PhysicalType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_PhysicalType

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( struct) 
          get_UOMList() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_UOMList

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam 
          get_HomotopyParameter() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_HomotopyParameter

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_HomotopyParameter([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam param) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_HomotopyParameter

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_HomotopyTarget() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_HomotopyTarget

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_HomotopyTarget([in] float64 Target) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_HomotopyTarget

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_Description() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_Description

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType 
          get_VariableType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_VariableType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_VariableType([in] valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType VariableType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_VariableType

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_ConnectionType() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::get_ConnectionType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ConnectionType([in] int32 ConnType) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 03 60 00 00 )                         // .....`..
  } // end of method IASCVariable5::set_ConnectionType

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Description([in] string  marshal( bstr) A_1) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 03 60 00 00 )                         // .. ..`..
  } // end of method IASCVariable5::set_Description

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_PhysicalType([in] string  marshal( bstr) A_1) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 03 60 00 00 )                         // ..!..`..
  } // end of method IASCVariable5::set_PhysicalType

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_baseUOM() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 22 00 03 60 00 00 )                         // .."..`..
  } // end of method IASCVariable5::get_baseUOM

  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCObject
          Parent()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCObject AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Parent()
  } // end of property IASCVariable5::Parent
  .property callconv(8) class AspenTech.AspenPlus.ASCclasslib.IASCSimulation
          Simulation()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 02 60 00 00 )                         // .....`..
    .get instance class AspenTech.AspenPlus.ASCclasslib.IASCSimulation AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Simulation()
  } // end of property IASCVariable5::Simulation
  .property callconv(8) string Name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 02 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Name()
  } // end of property IASCVariable5::Name
  .property callconv(8) bool IsValid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 02 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_IsValid()
  } // end of property IASCVariable5::IsValid
  .property callconv(8) float64 Value()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Value()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_Value(float64)
  } // end of property IASCVariable5::Value
  .property callconv(8) float64 LowerBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_LowerBound(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_LowerBound()
  } // end of property IASCVariable5::LowerBound
  .property callconv(8) float64 UpperBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_UpperBound(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_UpperBound()
  } // end of property IASCVariable5::UpperBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec
          Spec()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Spec()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_Spec(valuetype AspenTech.AspenPlus.ASCclasslib.ASCSpec)
  } // end of property IASCVariable5::Spec
  .property callconv(8) float64 Scale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_Scale(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Scale()
  } // end of property IASCVariable5::Scale
  .property callconv(8) float64 SBWeight()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_SBWeight()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_SBWeight(float64)
  } // end of property IASCVariable5::SBWeight
  .property callconv(8) float64 ShadowPrice()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_ShadowPrice(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_ShadowPrice()
  } // end of property IASCVariable5::ShadowPrice
  .property callconv(8) bool Marked()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_Marked(bool)
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Marked()
  } // end of property IASCVariable5::Marked
  .property callconv(8) bool Modified(string)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 03 60 00 00 )                         // .....`..
    .get instance bool AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Modified(string)
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_Modified(string,
                                                                                   bool)
  } // end of property IASCVariable5::Modified
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound
          ActiveBound()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCActiveBound AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_ActiveBound()
  } // end of property IASCVariable5::ActiveBound
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality
          Quality()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Quality()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_Quality(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarQuality)
  } // end of property IASCVariable5::Quality
  .property callconv(8) string UOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_UOM()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_UOM(string)
  } // end of property IASCVariable5::UOM
  .property callconv(8) float64 Initial()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Initial()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_Initial(float64)
  } // end of property IASCVariable5::Initial
  .property callconv(8) float64 Change()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Change()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_Change(float64)
  } // end of property IASCVariable5::Change
  .property callconv(8) int32 Number()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Number()
  } // end of property IASCVariable5::Number
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType
          BoundType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_BoundType()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_BoundType(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVarBoundType)
  } // end of property IASCVariable5::BoundType
  .property callconv(8) float64 InternalScale()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_InternalScale()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_InternalScale(float64)
  } // end of property IASCVariable5::InternalScale
  .property callconv(8) float64 Step()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 03 60 00 00 )                         // .....`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_Step(float64)
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Step()
  } // end of property IASCVariable5::Step
  .property callconv(8) string PhysicalType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_PhysicalType()
  } // end of property IASCVariable5::PhysicalType
  .property callconv(8) object UOMList()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 14 00 03 60 00 00 )                         // .....`..
    .get instance object AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_UOMList()
  } // end of property IASCVariable5::UOMList
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam
          HomotopyParameter()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 15 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_HomotopyParameter()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_HomotopyParameter(valuetype AspenTech.AspenPlus.ASCclasslib.ASCHomotopyParam)
  } // end of property IASCVariable5::HomotopyParameter
  .property callconv(8) float64 HomotopyTarget()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 03 60 00 00 )                         // .....`..
    .get instance float64 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_HomotopyTarget()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_HomotopyTarget(float64)
  } // end of property IASCVariable5::HomotopyTarget
  .property callconv(8) string Description()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 03 60 00 00 )                         // .....`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_Description()
  } // end of property IASCVariable5::Description
  .property callconv(8) valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType
          VariableType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 03 60 00 00 )                         // .....`..
    .get instance valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_VariableType()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_VariableType(valuetype AspenTech.AspenPlus.ASCclasslib.ASCVariableType)
  } // end of property IASCVariable5::VariableType
  .property callconv(8) int32 ConnectionType()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 03 60 00 00 )                         // .....`..
    .get instance int32 AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_ConnectionType()
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_ConnectionType(int32)
  } // end of property IASCVariable5::ConnectionType
  .property callconv(8) string Description_2()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 03 60 00 00 )                         // .. ..`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_Description(string)
  } // end of property IASCVariable5::Description_2
  .property callconv(8) string PhysicalType_2()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 03 60 00 00 )                         // ..!..`..
    .set instance void AspenTech.AspenPlus.ASCclasslib.IASCVariable5::set_PhysicalType(string)
  } // end of property IASCVariable5::PhysicalType_2
  .property callconv(8) string baseUOM()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 22 00 03 60 00 00 )                         // .."..`..
    .get instance string AspenTech.AspenPlus.ASCclasslib.IASCVariable5::get_baseUOM()
  } // end of property IASCVariable5::baseUOM
} // end of class AspenTech.AspenPlus.ASCclasslib.IASCVariable5

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method DASCSimulationMsgsEvents2_OnNewLineEventHandler::.ctor

  .method public virtual instance void  Invoke([in] string  marshal( bstr) bText) runtime managed preservesig
  {
  } // end of method DASCSimulationMsgsEvents2_OnNewLineEventHandler::Invoke

} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method DASCSimulationMsgsEvents2_UpdateProfilesEventHandler::.ctor

  .method public virtual instance void  Invoke([in] string[]  marshal( safearray bstr) nameArray,
                                               [in] object[]  marshal( safearray variant) valArray,
                                               float64 time) runtime managed
  {
  } // end of method DASCSimulationMsgsEvents2_UpdateProfilesEventHandler::Invoke

} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method DASCSimulationMsgsEvents2_ResetSimulationEventHandler::.ctor

  .method public virtual instance void  Invoke() runtime managed
  {
  } // end of method DASCSimulationMsgsEvents2_ResetSimulationEventHandler::Invoke

} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .field public class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler m_OnNewLineDelegate
  .field public int32 m_dwCookie
  .method public virtual instance void  OnNewLine(string A_1) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::m_OnNewLineDelegate
    IL_0009:  brfalse    IL_0021

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::m_OnNewLineDelegate
    IL_0017:  ldarg      A_1
    IL_001b:  callvirt   instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler::Invoke(string)
    IL_0020:  ret

    IL_0021:  ret
  } // end of method DASCSimulationMsgsEvents_SinkHelper::OnNewLine

  .method assembly specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  4
    IL_0000:  ldarg      0
    IL_0004:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0009:  ldarg      0
    IL_000d:  ldc.i4     0x0
    IL_0012:  stfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::m_dwCookie
    IL_0017:  ldarg      0
    IL_001b:  ldnull
    IL_001c:  stfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::m_OnNewLineDelegate
    IL_0021:  ret
  } // end of method DASCSimulationMsgsEvents_SinkHelper::.ctor

} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper

.class private auto ansi sealed AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_Event,
                  [mscorlib]System.IDisposable
{
  .field private class [mscorlib]System.WeakReference m_wkConnectionPointContainer
  .field private class [mscorlib]System.Collections.ArrayList m_aEventSinkHelpers
  .field private class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint m_ConnectionPoint
  .method private instance void  Init() cil managed
  {
    // Code size       271 (0x10f)
    .maxstack  5
    .locals init (class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint V_0,
             valuetype [mscorlib]System.Guid V_1,
             uint8[] V_2)
    IL_0000:  ldnull
    IL_0001:  stloc.0
    IL_0002:  ldc.i4     0x10
    IL_0007:  newarr     [mscorlib]System.Byte
    IL_000c:  stloc.2
    IL_000d:  ldloc.2
    IL_000e:  ldc.i4     0x0
    IL_0013:  ldc.i4     0x14
    IL_0018:  stelem.i1
    IL_0019:  ldloc.2
    IL_001a:  ldc.i4     0x1
    IL_001f:  ldc.i4     0x0
    IL_0024:  stelem.i1
    IL_0025:  ldloc.2
    IL_0026:  ldc.i4     0x2
    IL_002b:  ldc.i4     0x40
    IL_0030:  stelem.i1
    IL_0031:  ldloc.2
    IL_0032:  ldc.i4     0x3
    IL_0037:  ldc.i4     0x0
    IL_003c:  stelem.i1
    IL_003d:  ldloc.2
    IL_003e:  ldc.i4     0x4
    IL_0043:  ldc.i4     0x4
    IL_0048:  stelem.i1
    IL_0049:  ldloc.2
    IL_004a:  ldc.i4     0x5
    IL_004f:  ldc.i4     0xf7
    IL_0054:  stelem.i1
    IL_0055:  ldloc.2
    IL_0056:  ldc.i4     0x6
    IL_005b:  ldc.i4     0xa8
    IL_0060:  stelem.i1
    IL_0061:  ldloc.2
    IL_0062:  ldc.i4     0x7
    IL_0067:  ldc.i4     0x49
    IL_006c:  stelem.i1
    IL_006d:  ldloc.2
    IL_006e:  ldc.i4     0x8
    IL_0073:  ldc.i4     0x96
    IL_0078:  stelem.i1
    IL_0079:  ldloc.2
    IL_007a:  ldc.i4     0x9
    IL_007f:  ldc.i4     0x94
    IL_0084:  stelem.i1
    IL_0085:  ldloc.2
    IL_0086:  ldc.i4     0xa
    IL_008b:  ldc.i4     0x22
    IL_0090:  stelem.i1
    IL_0091:  ldloc.2
    IL_0092:  ldc.i4     0xb
    IL_0097:  ldc.i4     0xda
    IL_009c:  stelem.i1
    IL_009d:  ldloc.2
    IL_009e:  ldc.i4     0xc
    IL_00a3:  ldc.i4     0x62
    IL_00a8:  stelem.i1
    IL_00a9:  ldloc.2
    IL_00aa:  ldc.i4     0xd
    IL_00af:  ldc.i4     0xb
    IL_00b4:  stelem.i1
    IL_00b5:  ldloc.2
    IL_00b6:  ldc.i4     0xe
    IL_00bb:  ldc.i4     0x82
    IL_00c0:  stelem.i1
    IL_00c1:  ldloc.2
    IL_00c2:  ldc.i4     0xf
    IL_00c7:  ldc.i4     0x82
    IL_00cc:  stelem.i1
    IL_00cd:  ldloca.s   V_1
    IL_00cf:  ldloc.2
    IL_00d0:  call       instance void [mscorlib]System.Guid::.ctor(uint8[])
    IL_00d5:  ldarg      0
    IL_00d9:  ldfld      class [mscorlib]System.WeakReference AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_wkConnectionPointContainer
    IL_00de:  callvirt   instance object [mscorlib]System.WeakReference::get_Target()
    IL_00e3:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer
    IL_00e8:  ldloca.s   V_1
    IL_00ea:  ldloca.s   V_0
    IL_00ec:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer::FindConnectionPoint(valuetype [mscorlib]System.Guid&,
                                                                                                                                        class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint&)
    IL_00f1:  ldarg      0
    IL_00f5:  ldloc.0
    IL_00f6:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint
    IL_00fb:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_ConnectionPoint
    IL_0100:  ldarg      0
    IL_0104:  newobj     instance void [mscorlib]System.Collections.ArrayList::.ctor()
    IL_0109:  stfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_aEventSinkHelpers
    IL_010e:  ret
  } // end of method DASCSimulationMsgsEvents_EventProvider::Init

  .method public virtual instance void  add_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::Init()
      IL_0022:  newobj     instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::m_OnNewLineDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method DASCSimulationMsgsEvents_EventProvider::add_OnNewLine

  .method public virtual instance void  remove_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::m_OnNewLineDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::m_OnNewLineDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method DASCSimulationMsgsEvents_EventProvider::remove_OnNewLine

  .method public specialname rtspecialname 
          instance void  .ctor(object A_1) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  6
    IL_0000:  ldarg      0
    IL_0004:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0009:  ldarg      0
    IL_000d:  ldarg      A_1
    IL_0011:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer
    IL_0016:  ldc.i4.0
    IL_0017:  newobj     instance void [mscorlib]System.WeakReference::.ctor(object,
                                                                             bool)
    IL_001c:  stfld      class [mscorlib]System.WeakReference AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_wkConnectionPointContainer
    IL_0021:  ret
  } // end of method DASCSimulationMsgsEvents_EventProvider::.ctor

  .method public virtual instance void  Finalize() cil managed
  {
    // Code size       158 (0x9e)
    .maxstack  5
    .locals init (int32 V_0,
             int32 V_1,
             class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      .try
      {
        IL_0000:  ldarg      0
        IL_0004:  ldloca.s   V_3
        IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                            bool&)
        IL_000b:  ldarg      0
        IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_ConnectionPoint
        IL_0014:  brfalse    IL_0080

        IL_0019:  ldarg      0
        IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_aEventSinkHelpers
        IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
        IL_0027:  stloc.0
        IL_0028:  ldc.i4     0x0
        IL_002d:  stloc.1
        IL_002e:  ldc.i4     0x0
        IL_0033:  ldloc.0
        IL_0034:  bge        IL_0071

        IL_0039:  ldarg      0
        IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_aEventSinkHelpers
        IL_0042:  ldloc.1
        IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
        IL_0048:  castclass  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper
        IL_004d:  stloc.2
        IL_004e:  ldarg      0
        IL_0052:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_ConnectionPoint
        IL_0057:  ldloc.2
        IL_0058:  ldfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_SinkHelper::m_dwCookie
        IL_005d:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
        IL_0062:  ldloc.1
        IL_0063:  ldc.i4     0x1
        IL_0068:  add
        IL_0069:  stloc.1
        IL_006a:  ldloc.1
        IL_006b:  ldloc.0
        IL_006c:  blt        IL_0039

        IL_0071:  ldarg      0
        IL_0075:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::m_ConnectionPoint
        IL_007a:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
        IL_007f:  pop
        IL_0080:  leave      IL_008b

      }  // end .try
      catch [mscorlib]System.Exception 
      {
        IL_0085:  pop
        IL_0086:  leave      IL_008b

      }  // end handler
      IL_008b:  leave      IL_009d

    }  // end .try
    finally
    {
      IL_0090:  ldloc.3
      IL_0091:  brfalse.s  IL_009c

      IL_0093:  ldarg      0
      IL_0097:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_009c:  endfinally
    }  // end handler
    IL_009d:  ret
  } // end of method DASCSimulationMsgsEvents_EventProvider::Finalize

  .method public virtual instance void  Dispose() cil managed
  {
    // Code size       19 (0x13)
    .maxstack  2
    IL_0000:  ldarg      0
    IL_0004:  callvirt   instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider::Finalize()
    IL_0009:  ldarg      0
    IL_000d:  call       void [mscorlib]System.GC::SuppressFinalize(object)
    IL_0012:  ret
  } // end of method DASCSimulationMsgsEvents_EventProvider::Dispose

} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents_EventProvider

.class public auto ansi sealed AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .field public class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler m_OnNewLineDelegate
  .field public class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler m_UpdateProfilesDelegate
  .field public class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler m_ResetSimulationDelegate
  .field public int32 m_dwCookie
  .method public virtual instance void  OnNewLine(string A_1) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_OnNewLineDelegate
    IL_0009:  brfalse    IL_0021

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_OnNewLineDelegate
    IL_0017:  ldarg      A_1
    IL_001b:  callvirt   instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler::Invoke(string)
    IL_0020:  ret

    IL_0021:  ret
  } // end of method DASCSimulationMsgsEvents2_SinkHelper::OnNewLine

  .method public virtual instance void  UpdateProfiles(string[] A_1,
                                                       object[] A_2,
                                                       float64 A_3) cil managed
  {
    // Code size       42 (0x2a)
    .maxstack  4
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_UpdateProfilesDelegate
    IL_0009:  brfalse    IL_0029

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_UpdateProfilesDelegate
    IL_0017:  ldarg      A_1
    IL_001b:  ldarg      A_2
    IL_001f:  ldarg      A_3
    IL_0023:  callvirt   instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler::Invoke(string[],
                                                                                                                                    object[],
                                                                                                                                    float64)
    IL_0028:  ret

    IL_0029:  ret
  } // end of method DASCSimulationMsgsEvents2_SinkHelper::UpdateProfiles

  .method public virtual instance void  ResetSimulation() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  1
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_ResetSimulationDelegate
    IL_0009:  brfalse    IL_001d

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_ResetSimulationDelegate
    IL_0017:  callvirt   instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler::Invoke()
    IL_001c:  ret

    IL_001d:  ret
  } // end of method DASCSimulationMsgsEvents2_SinkHelper::ResetSimulation

  .method assembly specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       54 (0x36)
    .maxstack  4
    IL_0000:  ldarg      0
    IL_0004:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0009:  ldarg      0
    IL_000d:  ldc.i4     0x0
    IL_0012:  stfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_dwCookie
    IL_0017:  ldarg      0
    IL_001b:  ldnull
    IL_001c:  stfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_OnNewLineDelegate
    IL_0021:  ldarg      0
    IL_0025:  ldnull
    IL_0026:  stfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_UpdateProfilesDelegate
    IL_002b:  ldarg      0
    IL_002f:  ldnull
    IL_0030:  stfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_ResetSimulationDelegate
    IL_0035:  ret
  } // end of method DASCSimulationMsgsEvents2_SinkHelper::.ctor

} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper

.class private auto ansi sealed AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider
       extends [mscorlib]System.Object
       implements AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_Event,
                  [mscorlib]System.IDisposable
{
  .field private class [mscorlib]System.WeakReference m_wkConnectionPointContainer
  .field private class [mscorlib]System.Collections.ArrayList m_aEventSinkHelpers
  .field private class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint m_ConnectionPoint
  .method private instance void  Init() cil managed
  {
    // Code size       271 (0x10f)
    .maxstack  5
    .locals init (class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint V_0,
             valuetype [mscorlib]System.Guid V_1,
             uint8[] V_2)
    IL_0000:  ldnull
    IL_0001:  stloc.0
    IL_0002:  ldc.i4     0x10
    IL_0007:  newarr     [mscorlib]System.Byte
    IL_000c:  stloc.2
    IL_000d:  ldloc.2
    IL_000e:  ldc.i4     0x0
    IL_0013:  ldc.i4     0x52
    IL_0018:  stelem.i1
    IL_0019:  ldloc.2
    IL_001a:  ldc.i4     0x1
    IL_001f:  ldc.i4     0x0
    IL_0024:  stelem.i1
    IL_0025:  ldloc.2
    IL_0026:  ldc.i4     0x2
    IL_002b:  ldc.i4     0x40
    IL_0030:  stelem.i1
    IL_0031:  ldloc.2
    IL_0032:  ldc.i4     0x3
    IL_0037:  ldc.i4     0x0
    IL_003c:  stelem.i1
    IL_003d:  ldloc.2
    IL_003e:  ldc.i4     0x4
    IL_0043:  ldc.i4     0x4
    IL_0048:  stelem.i1
    IL_0049:  ldloc.2
    IL_004a:  ldc.i4     0x5
    IL_004f:  ldc.i4     0xf7
    IL_0054:  stelem.i1
    IL_0055:  ldloc.2
    IL_0056:  ldc.i4     0x6
    IL_005b:  ldc.i4     0xa8
    IL_0060:  stelem.i1
    IL_0061:  ldloc.2
    IL_0062:  ldc.i4     0x7
    IL_0067:  ldc.i4     0x49
    IL_006c:  stelem.i1
    IL_006d:  ldloc.2
    IL_006e:  ldc.i4     0x8
    IL_0073:  ldc.i4     0x96
    IL_0078:  stelem.i1
    IL_0079:  ldloc.2
    IL_007a:  ldc.i4     0x9
    IL_007f:  ldc.i4     0x94
    IL_0084:  stelem.i1
    IL_0085:  ldloc.2
    IL_0086:  ldc.i4     0xa
    IL_008b:  ldc.i4     0x22
    IL_0090:  stelem.i1
    IL_0091:  ldloc.2
    IL_0092:  ldc.i4     0xb
    IL_0097:  ldc.i4     0xda
    IL_009c:  stelem.i1
    IL_009d:  ldloc.2
    IL_009e:  ldc.i4     0xc
    IL_00a3:  ldc.i4     0x62
    IL_00a8:  stelem.i1
    IL_00a9:  ldloc.2
    IL_00aa:  ldc.i4     0xd
    IL_00af:  ldc.i4     0xb
    IL_00b4:  stelem.i1
    IL_00b5:  ldloc.2
    IL_00b6:  ldc.i4     0xe
    IL_00bb:  ldc.i4     0x82
    IL_00c0:  stelem.i1
    IL_00c1:  ldloc.2
    IL_00c2:  ldc.i4     0xf
    IL_00c7:  ldc.i4     0x82
    IL_00cc:  stelem.i1
    IL_00cd:  ldloca.s   V_1
    IL_00cf:  ldloc.2
    IL_00d0:  call       instance void [mscorlib]System.Guid::.ctor(uint8[])
    IL_00d5:  ldarg      0
    IL_00d9:  ldfld      class [mscorlib]System.WeakReference AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_wkConnectionPointContainer
    IL_00de:  callvirt   instance object [mscorlib]System.WeakReference::get_Target()
    IL_00e3:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer
    IL_00e8:  ldloca.s   V_1
    IL_00ea:  ldloca.s   V_0
    IL_00ec:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer::FindConnectionPoint(valuetype [mscorlib]System.Guid&,
                                                                                                                                        class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint&)
    IL_00f1:  ldarg      0
    IL_00f5:  ldloc.0
    IL_00f6:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint
    IL_00fb:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
    IL_0100:  ldarg      0
    IL_0104:  newobj     instance void [mscorlib]System.Collections.ArrayList::.ctor()
    IL_0109:  stfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
    IL_010e:  ret
  } // end of method DASCSimulationMsgsEvents2_EventProvider::Init

  .method public virtual instance void  add_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::Init()
      IL_0022:  newobj     instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_OnNewLineDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method DASCSimulationMsgsEvents2_EventProvider::add_OnNewLine

  .method public virtual instance void  remove_OnNewLine(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_OnNewLineDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_OnNewLineEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_OnNewLineDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method DASCSimulationMsgsEvents2_EventProvider::remove_OnNewLine

  .method public virtual instance void  add_UpdateProfiles(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::Init()
      IL_0022:  newobj     instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_UpdateProfilesDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method DASCSimulationMsgsEvents2_EventProvider::add_UpdateProfiles

  .method public virtual instance void  remove_UpdateProfiles(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_UpdateProfilesDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_UpdateProfilesEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_UpdateProfilesDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method DASCSimulationMsgsEvents2_EventProvider::remove_UpdateProfiles

  .method public virtual instance void  add_ResetSimulation(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::Init()
      IL_0022:  newobj     instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_ResetSimulationDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method DASCSimulationMsgsEvents2_EventProvider::add_ResetSimulation

  .method public virtual instance void  remove_ResetSimulation(class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_ResetSimulationDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_ResetSimulationEventHandler AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_ResetSimulationDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method DASCSimulationMsgsEvents2_EventProvider::remove_ResetSimulation

  .method public specialname rtspecialname 
          instance void  .ctor(object A_1) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  6
    IL_0000:  ldarg      0
    IL_0004:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0009:  ldarg      0
    IL_000d:  ldarg      A_1
    IL_0011:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer
    IL_0016:  ldc.i4.0
    IL_0017:  newobj     instance void [mscorlib]System.WeakReference::.ctor(object,
                                                                             bool)
    IL_001c:  stfld      class [mscorlib]System.WeakReference AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_wkConnectionPointContainer
    IL_0021:  ret
  } // end of method DASCSimulationMsgsEvents2_EventProvider::.ctor

  .method public virtual instance void  Finalize() cil managed
  {
    // Code size       158 (0x9e)
    .maxstack  5
    .locals init (int32 V_0,
             int32 V_1,
             class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper V_2,
             bool V_3)
    .try
    {
      .try
      {
        IL_0000:  ldarg      0
        IL_0004:  ldloca.s   V_3
        IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                            bool&)
        IL_000b:  ldarg      0
        IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
        IL_0014:  brfalse    IL_0080

        IL_0019:  ldarg      0
        IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
        IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
        IL_0027:  stloc.0
        IL_0028:  ldc.i4     0x0
        IL_002d:  stloc.1
        IL_002e:  ldc.i4     0x0
        IL_0033:  ldloc.0
        IL_0034:  bge        IL_0071

        IL_0039:  ldarg      0
        IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_aEventSinkHelpers
        IL_0042:  ldloc.1
        IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
        IL_0048:  castclass  AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper
        IL_004d:  stloc.2
        IL_004e:  ldarg      0
        IL_0052:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
        IL_0057:  ldloc.2
        IL_0058:  ldfld      int32 AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_SinkHelper::m_dwCookie
        IL_005d:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
        IL_0062:  ldloc.1
        IL_0063:  ldc.i4     0x1
        IL_0068:  add
        IL_0069:  stloc.1
        IL_006a:  ldloc.1
        IL_006b:  ldloc.0
        IL_006c:  blt        IL_0039

        IL_0071:  ldarg      0
        IL_0075:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::m_ConnectionPoint
        IL_007a:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
        IL_007f:  pop
        IL_0080:  leave      IL_008b

      }  // end .try
      catch [mscorlib]System.Exception 
      {
        IL_0085:  pop
        IL_0086:  leave      IL_008b

      }  // end handler
      IL_008b:  leave      IL_009d

    }  // end .try
    finally
    {
      IL_0090:  ldloc.3
      IL_0091:  brfalse.s  IL_009c

      IL_0093:  ldarg      0
      IL_0097:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_009c:  endfinally
    }  // end handler
    IL_009d:  ret
  } // end of method DASCSimulationMsgsEvents2_EventProvider::Finalize

  .method public virtual instance void  Dispose() cil managed
  {
    // Code size       19 (0x13)
    .maxstack  2
    IL_0000:  ldarg      0
    IL_0004:  callvirt   instance void AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider::Finalize()
    IL_0009:  ldarg      0
    IL_000d:  call       void [mscorlib]System.GC::SuppressFinalize(object)
    IL_0012:  ret
  } // end of method DASCSimulationMsgsEvents2_EventProvider::Dispose

} // end of class AspenTech.AspenPlus.ASCclasslib.DASCSimulationMsgsEvents2_EventProvider


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file C:\Users\Administrator\Desktop\Aspen 逆向\.local\batch-roundtrip-20261125\work-il\clr-h5_dm54k\editable\source.res
