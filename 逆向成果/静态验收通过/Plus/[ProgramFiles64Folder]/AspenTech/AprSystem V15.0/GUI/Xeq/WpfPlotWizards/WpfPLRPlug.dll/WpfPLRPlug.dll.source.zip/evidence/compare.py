"""Compare the source-only WpfPLRPlug images using independently read PE data."""

import argparse
from collections import Counter, defaultdict
from functools import cache
import hashlib
import json
from pathlib import Path
import re
import sys


COMPILER_GENERATED = "CompilerGeneratedAttribute"
GENERATED_TYPE = re.compile(r"<>o__\d+")
CALL_SITE = re.compile(r"<>p__\d+")
DELEGATE_CACHE = re.compile(r"<>9__\d+_(\d+)")
LAMBDA = re.compile(r"<([^>]+)>b__\d+_(\d+)")


@cache
def unpack(text):
    tag, separator, payload = text.partition("(")
    if not separator or not text.endswith(")") or not tag.isalnum():
        return None
    values = []
    payload = payload[:-1]
    while payload:
        length, colon, remainder = payload.partition(":")
        if not colon or not length.isascii() or not length.isdecimal():
            return None
        count = int(length)
        if count > len(remainder):
            return None
        values.append(remainder[:count])
        payload = remainder[count:]
    return tag, tuple(values)


def encode(tag, values):
    return tag + "(" + "".join(f"{len(value)}:{value}" for value in values) + ")"


def index(items, key):
    items = list(items)
    rows = {item[key]: item for item in items}
    if len(rows) != len(items):
        raise ValueError(f"Duplicate identity in {key}")
    return rows


def fields(types):
    return index((row for item in types for row in item["Fields"]), "Identity")


def move_free_operand(operand):
    return operand["Offset"], operand["OperandOffset"], operand["Kind"]


def digest(data):
    return hashlib.sha256(json.dumps(data, ensure_ascii=False,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()


def compare(original, candidate):
    a_methods, b_methods = (index(bundle["methods"], "Identity") for bundle in (original, candidate))
    a_types, b_types = (index(bundle["types"], "identity") for bundle in (original, candidate))
    a_fields, b_fields = (fields(bundle["details"]["Types"]) for bundle in (original, candidate))
    gaps = []
    aliases = {}
    reverse = {}
    uses = defaultdict(list)
    differences = []
    field_row_order = []

    def generated(row, attr):
        return row is not None and any(COMPILER_GENERATED in entry for entry in row[attr])

    def note_alias(a, b, evidence):
        if a == b:
            return True
        if a in aliases or b in reverse:
            same = aliases.get(a) == b and reverse.get(b) == a
            if same:
                uses[a].append(evidence)
            return same
        left, right = unpack(a), unpack(b)
        if left is None or right is None or left[0] != right[0]:
            return False
        tag, (a_owner, a_name, a_signature) = left if left[0] in ("typedef", "fielddef", "methoddef") else ("unsupported", ("", "", ""))
        b_owner, b_name, b_signature = right[1] if tag != "unsupported" else ("", "", "")
        if tag == "typedef":
            # A TypeDef has declaring type, namespace, then name.
            if (a_owner != b_owner or a_name != b_name
                    or not all(GENERATED_TYPE.fullmatch(name) for name in (a_signature, b_signature))
                    or not (generated(a_types.get(a), "customAttributes")
                            and generated(b_types.get(b), "customAttributes"))):
                return False
        elif tag in ("fielddef", "methoddef"):
            if a_signature != b_signature:
                return False
            if tag == "fielddef":
                if a not in a_fields or b not in b_fields:
                    return False
                if not (a_fields[a]["Attributes"] & b_fields[b]["Attributes"] & 0x10):
                    return False
                if not (generated(a_types.get(a_owner), "customAttributes")
                        and generated(b_types.get(b_owner), "customAttributes")):
                    return False
                if CALL_SITE.fullmatch(a_name) and CALL_SITE.fullmatch(b_name):
                    if "CallSite" not in a_signature:
                        return False
                else:
                    ma, mb = DELEGATE_CACHE.fullmatch(a_name), DELEGATE_CACHE.fullmatch(b_name)
                    if ma is None or mb is None or ma.groups() != mb.groups():
                        return False
            else:
                if a not in a_methods or b not in b_methods:
                    return False
                if not ((generated(a_types.get(a_owner), "customAttributes") or generated(a_methods[a], "CustomAttributes"))
                        and (generated(b_types.get(b_owner), "customAttributes") or generated(b_methods[b], "CustomAttributes"))):
                    return False
                ma, mb = LAMBDA.fullmatch(a_name), LAMBDA.fullmatch(b_name)
                if ma is None or mb is None or ma.groups() != mb.groups():
                    return False
            if not note_alias(a_owner, b_owner, evidence):
                return False
        else:
            return False
        aliases[a] = b
        reverse[b] = a
        uses[a].append(evidence)
        return True

    for identity in sorted(a_methods.keys() & b_methods.keys()):
        a, b = a_methods[identity], b_methods[identity]
        if (a["ShapeDigest"] != b["ShapeDigest"] or
                [move_free_operand(row) for row in a["Operands"]] !=
                [move_free_operand(row) for row in b["Operands"]]):
            continue
        for x, y in zip(a["Operands"], b["Operands"], strict=True):
            if x["Resolved"] != y["Resolved"]:
                note_alias(x["Resolved"], y["Resolved"], [a["Token"], b["Token"], x["Offset"]])

    @cache
    def original_name(text):
        if text in reverse:
            return reverse[text]
        value = unpack(text)
        if value is None or value[0] == "userstring":
            return text
        tag, parts = value
        normalized = tuple(original_name(part) for part in parts)
        return text if parts == normalized else encode(tag, normalized)

    def normalize(value):
        if isinstance(value, str):
            return original_name(value)
        if isinstance(value, list):
            return [normalize(item) for item in value]
        if isinstance(value, dict):
            return {key: normalize(item) for key, item in value.items()}
        return value

    named_methods = index(normalize(candidate["methods"]), "Identity")
    a_locals, b_locals = (index(bundle["locals"], "Token") for bundle in (original, candidate))
    for identity in sorted(a_methods.keys() | named_methods.keys()):
        a, b = a_methods.get(identity), named_methods.get(identity)
        if a is None or b is None:
            gaps.append({"method_identity": identity, "missing_side": "candidate" if b is None else "original"})
            continue
        sides = (a, b)
        parts = ["Attributes", "ImplementationAttributes", "Scope", "Parameters", "CustomAttributes",
                 "ShapeDigest", "MaxStack", "InitLocals"]
        failed = [key for key in parts if a[key] != b[key]]
        if a_locals[a["Token"]]["Signature"] != original_name(b_locals[b["Token"]]["Signature"]):
            failed.append("local_signature")
        exception_shapes = [[{key: value for key, value in item.items() if key != "rawCatchToken"}
                             for item in row["ExceptionRegions"] or []] for row in sides]
        if exception_shapes[0] != exception_shapes[1]:
            failed.append("exception_regions")
        operand_shapes = [[(*move_free_operand(operand), operand["Resolved"])
                           for operand in row["Operands"]] for row in sides]
        if operand_shapes[0] != operand_shapes[1]:
            failed.append("resolved_operands")
        if failed:
            gaps.append({"method_identity": identity, "mismatch": failed})
        raw_b = b_methods[aliases.get(identity, identity)]
        differences.append({
            "identity": identity, "original_token": a["Token"], "candidate_token": b["Token"],
            "scope": a["Scope"], "passed": not failed,
            "opcode_and_non_token_operand_sha256": a["ShapeDigest"],
            "bound_operand_sha256": digest(operand_shapes[0]),
            "exception_clauses": len(exception_shapes[0]), "eh_sha256": digest(exception_shapes[0]),
            "token_operand_count": len(a["Operands"]),
            "tokens_reindexed": sum(x["RawToken"] != y["RawToken"] for x, y in zip(a["Operands"], b["Operands"])),
            "generated_bindings": sum(x["Resolved"] != y["Resolved"] for x, y in zip(a["Operands"], raw_b["Operands"])),
            "raw_cil_equal": a["RawCodeDigest"] == b["RawCodeDigest"],
        })

    def check(label, a, b):
        if a != b:
            gaps.append({"unmatched_metadata": label})

    for key in ("assembly", "assemblyReferences"):
        check(key, original[key], candidate[key])
    check("types and interfaces", a_types, index(normalize(candidate["types"]), "identity"))
    com_interfaces = []
    ordered_methods = [defaultdict(list), defaultdict(list)]
    for rows, slots in zip((original["methods"], normalize(candidate["methods"])), ordered_methods, strict=True):
        for row in rows:
            owner = unpack(row["Identity"])[1][0]
            if owner in a_types and a_types[owner]["flags"] & 0x1020 == 0x1020:
                slots[owner].append(row)
    for owner in sorted(ordered_methods[0].keys() | ordered_methods[1].keys()):
        left, right = (slots[owner] for slots in ordered_methods)
        check("COM interface method and gap slot order " + owner,
              [row["Identity"] for row in left], [row["Identity"] for row in right])
        com_interfaces.append({"type": owner, "method_count": len(left),
                               "original_tokens": [row["Token"] for row in left],
                               "candidate_tokens": [row["Token"] for row in right]})
    a_details, b_details = original["details"], normalize(candidate["details"])
    for key in ("Methods", "Types"):
        left, right = (index(bundle[key], "Identity") for bundle in (a_details, b_details))
        check(key + " identity set", sorted(left), sorted(right))
        for item in sorted(left.keys() & right.keys()):
            a, b = left[item], right[item]
            for attribute, value in a.items():
                rebuilt = b[attribute]
                if key == "Types" and attribute == "Fields" and value != rebuilt and not a_types[item]["flags"] & 0x18:
                    # This type uses CLR auto layout. Keep the ordering difference in the report.
                    unordered = index(value, "Identity") == index(rebuilt, "Identity")
                    if unordered:
                        field_row_order.append({"type": item, "original_order": [row["Identity"] for row in value],
                                                "candidate_order": [row["Identity"] for row in rebuilt]})
                        continue
                check(f"{key}/{item}/{attribute}", value, rebuilt)
    for key in ("Exports", "Resources"):
        check(key, a_details[key], b_details[key])
    for pe_field in ("machine", "clr_flags", "strong_name_bytes", "managed_resources",
                     "managed_resource_region", "win32_resources"):
        check("PE/" + pe_field, original["pe"][pe_field], candidate["pe"][pe_field])
    strict_matches = sum(all(a_methods[identity][key] == b_methods[identity][key]
                             for key in ("Attributes", "ImplementationAttributes", "Scope", "CodeDigest",
                                         "Parameters", "CustomAttributes"))
                         for identity in a_methods.keys() & b_methods.keys())
    return {
        "original_pe": original["pe"], "candidate_pe": candidate["pe"],
        "coverage": {
            "method_definitions": [len(a_methods), len(b_methods)], "strict_symbolic_matches": strict_matches,
            "matched_after_generated_name_pairing": sum(row["passed"] for row in differences),
            "method_kinds": dict(Counter(row["scope"] for row in differences)),
            "bodyless_flags": [{"method_flags": key[0], "implementation_flags": key[1], "count": count}
                               for key, count in sorted(Counter(
                                   (row["Attributes"], row["ImplementationAttributes"])
                                   for row in a_methods.values() if row["Scope"] == "declaration").items())],
            "exception_clauses": sum(row["exception_clauses"] for row in differences),
            "token_operands": sum(row["token_operand_count"] for row in differences),
            "tokens_reindexed": sum(row["tokens_reindexed"] for row in differences),
            "changed_generated_binding_uses": sum(row["generated_bindings"] for row in differences),
            "generated_identity_pairs": dict(Counter(unpack(key)[0] for key in aliases)),
            "types": len(a_types), "fields": len(a_fields), "assembly_references": len(original["assemblyReferences"]),
            "ordered_com_interfaces": len(com_interfaces),
            **{group.lower(): sum(len(row[group]) for row in a_details["Types"])
               for group in ("Properties", "Events", "Overrides")},
        },
        "generated_name_pairs": [{"original": a, "candidate": b, "uses_at_methoddef_offset": uses[a]}
                                 for a, b in sorted(aliases.items())],
        "methods": differences, "com_interface_declaration_order": com_interfaces,
        "field_order_differences": field_row_order, "gaps": gaps,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("original", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("report", type=Path)
    args = parser.parse_args()
    value = compare(*(json.loads(path.read_bytes()) for path in (args.original, args.candidate)))
    args.report.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"coverage": value["coverage"], "gaps": value["gaps"]}, ensure_ascii=False))
    return bool(value["gaps"])


if __name__ == "__main__":
    sys.exit(main())
