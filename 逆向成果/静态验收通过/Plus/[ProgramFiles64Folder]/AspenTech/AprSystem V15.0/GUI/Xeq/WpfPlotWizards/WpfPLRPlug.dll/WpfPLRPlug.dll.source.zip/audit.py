"""Recheck static metadata, CIL, resources and WPF satellite layout against the original."""

import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

from build import sha, validate
from evidence.compare import compare, unpack


SDK_VERSION = "9.0.321"
CORE_PACK_VERSION = "9.0.23"
ILSPY = {
    "ICSharpCode.Decompiler.dll": "2e47c9b7557d071935f4730d5cd692162bd0f6266ce7d29f1d13ffeb6b2dae75",
    "ICSharpCode.BamlDecompiler.dll": "0ab41a9be38d43c6be522fb9659d77b00b3991557c665fa5877d0cabe5123be2",
}
SATELLITE_SHA256 = "1719dbc432d68cfe08037fe43440f8d68a7f0b6e442a5df66d3002d994b3fc3c"
XAML_NS = "{http://schemas.microsoft.com/winfx/2006/xaml}"
EVENTS = {"Click", "DropDownClosed"}


def json_file(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def run(command, output):
    result = subprocess.run([str(part) for part in command], capture_output=True)
    output.write_bytes(result.stdout + result.stderr)
    result.check_returncode()


def compile_reader(dotnet, csc, refs, source_paths, extra_refs, output_dir, name):
    artifact = output_dir / f"{name}.dll"
    flags = ["/nologo", "/nostdlib+", "/nullable:enable", "/deterministic+", "/target:exe", f'/out:"{artifact}"']
    flags.extend(f'/reference:"{ref}"' for ref in (*refs, *extra_refs))
    flags.extend(f'"{item}"' for item in source_paths)
    response = output_dir / f"{name}.rsp"
    response.write_text("\n".join(flags) + "\n", encoding="utf-8-sig")
    run([dotnet, csc, "/noconfig", "@" + str(response)], output_dir / f"{name}.compile.log")
    json_file(artifact.with_suffix(".runtimeconfig.json"),
              {"runtimeOptions": {"tfm": "net9.0",
                                  "framework": {"name": "Microsoft.NETCore.App", "version": "9.0.0"}}})
    return artifact


def markup_keys(data):
    found = {}
    for row in data["methods"]:
        tag, (owner, name, _) = unpack(row["Identity"])
        if tag != "methoddef" or name != "InitializeComponent":
            continue
        for operand in row["Operands"]:
            entry, values = unpack(operand["Resolved"])
            if entry == "userstring" and values[0].endswith(".xaml"):
                uri, file = values[0].split(";component/")
                if uri != "/WpfPLRPlug" or file in found:
                    raise ValueError(f"Unexpected pack URI: {values[0]}")
                found[file] = {"owner": owner, "initializer_token": row["Token"], "uri": values[0]}
    return found


def wpf_layout(report_dir, shipped, original_data, candidate_data):
    files = [dict(line.split("\t", 1) for line in (report_dir / f"{side}.baml.tsv").read_text().splitlines())
             for side in ("original", "candidate")]
    baml, candidate = files
    fail = []
    if baml != candidate:
        fail.append("The satellite resource enumerations differ")
    readers = [markup_keys(data) for data in (original_data, candidate_data)]
    methods = [{unpack(row["Identity"])[1][:2] for row in data["methods"]}
               for data in (original_data, candidate_data)]
    observed = []
    filenames = sorted(f"{Path(name).stem}.xaml" for name in baml)
    if not baml or any(names.keys() != set(filenames) for names in readers):
        fail.append("WPF pack URIs do not cover the satellite entries on both sides")
    if {item.name for item in shipped.glob("*.xaml")} != set(filenames):
        fail.append("Delivered XAML names differ from the satellite entries")
    for file in filenames:
        output_paths = [report_dir / f"{side}-xaml" / file for side in ("original", "candidate")]
        original_xml = output_paths[0].read_bytes()
        if original_xml != output_paths[1].read_bytes() or original_xml != (shipped / file).read_bytes():
            fail.append(f"XAML byte mismatch for {file}")
        root = ET.fromstring(original_xml)
        type_name = root.attrib[XAML_NS + "Class"]
        events, bindings, commands, controls = [], [], [], []
        for item in root.iter():
            tag = item.tag.rsplit("}", 1)[-1]
            name = item.attrib.get("Name") or item.attrib.get(XAML_NS + "Name")
            if name:
                controls.append({"control": tag, "name": name})
            for property_name, value in item.attrib.items():
                summary = {"control": tag, "name": name, "property": property_name, "expression": value}
                if property_name in EVENTS:
                    events.append(summary)
                if "{Binding" in value or "{MultiBinding" in value or tag.endswith("Binding"):
                    bindings.append(summary)
                if property_name == "Command":
                    commands.append(summary)
        for side, bindings_index in enumerate(readers):
            marker = bindings_index.get(file, {})
            owner = marker.get("owner")
            type_parts = unpack(owner) if owner else None
            if type_parts is None or ".".join(type_parts[1][1:]) != type_name:
                fail.append(f"{file} does not bind to its declared class on side {side}")
                continue
            if (owner, "System.Windows.Markup.IComponentConnector.Connect") not in methods[side]:
                fail.append(f"{file} has no component connector on side {side}")
            if any((owner, event["expression"]) not in methods[side] for event in events):
                fail.append(f"{file} refers to an absent handler on side {side}")
        baml_name = f"{Path(file).stem}.baml"
        size, hash_value = baml[baml_name].split("\t")
        observed.append({"xaml": file, "xaml_sha256": sha(output_paths[0]), "x_class": type_name,
                         "baml_key": baml_name, "baml_bytes": int(size), "baml_sha256": hash_value,
                         "initializer_original": readers[0].get(file),
                         "initializer_candidate": readers[1].get(file),
                         "named_controls": controls, "events": events, "data_bindings": bindings,
                         "command_bindings": commands})
    return {"status": "matched" if not fail else "different", "pages": observed, "gaps": fail,
            "satellite_sha256": SATELLITE_SHA256}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("original", "candidate", "satellite", "dotnet-root", "ilspy", "framework", "xeq", "out"):
        parser.add_argument("--" + name, required=True, type=Path)
    args = parser.parse_args()
    dotnet_root = args.dotnet_root.resolve(strict=True)
    dotnet = dotnet_root / "dotnet.exe"
    csc = dotnet_root / f"sdk/{SDK_VERSION}/Roslyn/bincore/csc.dll"
    refpack = dotnet_root / f"packs/Microsoft.NETCore.App.Ref/{CORE_PACK_VERSION}/ref/net9.0"
    references = sorted(refpack.glob("*.dll"))
    if not references or not csc.is_file() or not dotnet.is_file():
        raise ValueError("The specified .NET SDK root lacks the .NET 9 compiler or reference pack.")
    package = Path(__file__).resolve().parent
    source = package / "evidence"
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=False)
    scratch = output / "reader"
    scratch.mkdir()
    locked = json.loads((package / "build-inputs.json").read_bytes())
    validate(args.original, locked["original_sha256"])
    validate(args.satellite, SATELLITE_SHA256)
    libraries = []
    for name, digest in ILSPY.items():
        path = args.ilspy / name
        validate(path, digest)
        libraries.append(Path(shutil.copyfile(path, scratch / name)))

    cil = compile_reader(dotnet, csc, references, [source / name for name in
                         ("ResolvedCilEvidence.cs", "ResolvedMetadataDetails.cs", "PeDetails.cs")],
                         [], scratch, "ReadManagedEvidence")
    markup = compile_reader(dotnet, csc, references, [source / "BamlEvidence.cs"],
                            libraries, scratch, "ReadBamlEvidence")
    assemblies = [path.resolve(strict=True) for path in (args.original, args.candidate)]
    data = []
    for name, assembly in zip(("original", "candidate"), assemblies, strict=True):
        log = output / f"{name}.json"
        run([dotnet, cil, assembly], log)
        data.append(json.loads(log.read_bytes()))
        run([dotnet, markup, assembly, args.satellite.resolve(), output / f"{name}-xaml",
             args.xeq.resolve(), args.xeq.resolve() / "WpfPlotWizards", args.framework.resolve()],
            output / f"{name}.baml.tsv")

    cil_report = compare(*data)
    wpf_report = wpf_layout(output, package / "wpf", *data)
    json_file(output / "CIL-PE-COMPARISON.json", cil_report)
    json_file(output / "WPF-LAYOUT.json", wpf_report)
    print(json.dumps({"coverage": cil_report["coverage"], "gaps": cil_report["gaps"] + wpf_report["gaps"],
                      "wpf_pages": len(wpf_report["pages"])}, ensure_ascii=False))
    return bool(cil_report["gaps"] or wpf_report["gaps"])


if __name__ == "__main__":
    sys.exit(main())
