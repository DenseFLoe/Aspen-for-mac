"""Assemble a self-contained rebuild package for one item (archive input).

Usage: package_item.py <sha8>

Writes <work>/<sha8>/package.zip containing:
  editable/<source>.cs, resources/original.res (+ managed resources)
  build-plan.json (pinned toolchain, references, fixed flags, build-input hashes)
  layout-recipe.json + original-build/* (pass items only)
  reassembled/<name> (the compiled candidate, as evidence)
  tools/pe_layout.py, tools/replay.py, tools/token_replay.py (clean-room replay)
  evidence/compile.log, compile.rsp, recipe-report.json, method-audit.json
  notes.md
"""
import json, sys, zipfile
from hashlib import sha256
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
HOME = BASE / "managed-byte-recovery"
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")
sys.path.insert(0, str(BASE)); sys.path.insert(0, str(HOME))
from probe_token_layout import cs

WORK = Path(__file__).resolve().parent.parent
LEDGER = {}
for line in open(BASE / "per-file.jsonl", encoding="utf-8"):
    r = json.loads(line)
    LEDGER[r["sha256"]] = r


def digest(b):
    return sha256(b).hexdigest()


def run(sha8):
    sha = next(s for s in LEDGER if s.startswith(sha8))
    row = LEDGER[sha]
    d = WORK / sha8
    name = row["name"]
    src = d / "src"
    build = json.loads((src / "build-inputs.json").read_text(encoding="utf-8"))
    candidate = (d / "out" / name).read_bytes()
    rsp = (d / "out" / "compile.rsp").read_text(encoding="utf-8").splitlines()
    # Only keep bare compiler switches; replay.build adds /out, /win32res, /keyfile,
    # /reference, /resource and the packaged sources itself.
    drop = ("/out:", "/win32res:", "/reference:", "/resource:", "/keyfile:", "/link:", "/publicsign+")
    flags = [line for line in rsp if line.startswith("/") and not line.startswith(drop)]
    members = {}

    def add(path, data):
        members[path] = data

    for p in sorted((src / "editable").glob("*.cs")):
        add("editable/" + p.name, p.read_bytes())
    add("resources/original.res", (src / "resources" / "original.res").read_bytes())
    for mr in build.get("managed_resources", ()):
        add("resources/" + mr["file"], (src / "resources" / mr["file"]).read_bytes())
    add("reassembled/" + name, candidate)
    add("evidence/compile.log", (d / "out" / "compile.log").read_bytes())
    add("evidence/compile.rsp", (d / "out" / "compile.rsp").read_bytes())
    if (d / "method-audit.json").is_file():
        add("evidence/method-audit.json", (d / "method-audit.json").read_bytes())
    if (d / "recipe-report.json").is_file():
        add("evidence/recipe-report.json", (d / "recipe-report.json").read_bytes())
    if (d / "notes.md").is_file():
        add("notes.md", (d / "notes.md").read_bytes())

    recipe_ready = False
    if (d / "recipe.json").is_file():
        recipe = json.loads((d / "recipe.json").read_text(encoding="utf-8"))
        if recipe.get("replay_status") == "ready":
            recipe_ready = True
            add("layout-recipe.json", (d / "recipe.json").read_bytes())
            for asset in ("clr-metadata.bin", "debug-record.bin", "certificate-table.bin",
                          "strong-name.bin", "clr-header.bin"):
                p = d / "assets" / ("original-build__" + asset)
                if p.is_file():
                    add("original-build/" + asset, p.read_bytes())
            if (d / "assets" / "build__assembly-public-key.snk").is_file():
                add("build/assembly-public-key.snk", (d / "assets" / "build__assembly-public-key.snk").read_bytes())
            for tool in ("pe_layout.py", "replay.py", "token_replay.py"):
                add("tools/" + tool, (HOME / tool).read_bytes())

    plan = {
        "assembly_name": name,
        "original_sha256": sha,
        "original_path": row["installed_location"],
        "tool_path": {"dotnet": str(cs.DOTNET), "csc": str(cs.CSC)},
        "dotnet_sha256": digest(Path(cs.DOTNET).read_bytes()),
        "csc_sha256": digest(Path(cs.CSC).read_bytes()),
        "references": build["references"],
        "fixed_flags": flags,
        "managed_resources": build.get("managed_resources", []),
        "build_input_sha256": {k: digest(v) for k, v in members.items()
                               if k.startswith(("editable/", "resources/", "build/"))},
        "candidate_sha256": digest(candidate),
        "replay_status": "ready" if recipe_ready else "blocked",
    }
    add("build-plan.json", json.dumps(plan, ensure_ascii=False, indent=1).encode("utf-8"))
    out = d / "package.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for k in sorted(members):
            z.writestr(k, members[k])
    print(json.dumps({"package": str(out), "sha256": digest(out.read_bytes()),
                      "members": len(members), "replay_status": plan["replay_status"]},
                     ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(run(sys.argv[1]))
