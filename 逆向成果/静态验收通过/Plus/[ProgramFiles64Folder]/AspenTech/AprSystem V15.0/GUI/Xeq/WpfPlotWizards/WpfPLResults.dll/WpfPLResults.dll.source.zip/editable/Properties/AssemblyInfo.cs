using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("wpfPLResults")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("wpfPLResults")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2011 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("7d438e7a-851d-4b03-9b76-5c7277f85a1f")]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: AssemblyVersion("41.0.0.614")]
