using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLCfuge;

[RibbonPlotWizardMgr("WpfPLCFUGE.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class CfugePlotWizardModule : PlotModuleBase
{
}
