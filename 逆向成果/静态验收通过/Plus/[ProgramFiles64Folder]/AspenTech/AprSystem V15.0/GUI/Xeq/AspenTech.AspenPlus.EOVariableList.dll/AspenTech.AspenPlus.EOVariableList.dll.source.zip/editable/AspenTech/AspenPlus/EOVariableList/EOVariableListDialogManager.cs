using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using AspenTech.AspenCxs.CxsViewModel;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.MMControls;
using AspenTech.AspenPlus.MMForms.GridForms.Controls;
using AspenTech.AspenPlus.UnmanagedWrapper;
using AspenTech.Visualisation.CommonShell;

namespace AspenTech.AspenPlus.EOVariableList;

internal class EOVariableListDialogManager
{
	private readonly EOVariableListExecuteManager _executeManager;

	private EOVariableListWrapper _wrapper;

	private EOVariableListDataProvider _dataProvider;

	public EOVariableListDialogManager(EOVariableListExecuteManager executeManager)
	{
		if (executeManager == null)
		{
			throw new ArgumentNullException("executeManager");
		}
		_executeManager = executeManager;
		Initialize();
	}

	private void Initialize()
	{
		IHNode currentNode = _executeManager.CurrentNode;
		object configObject = _executeManager.GetConfigObject();
		if (currentNode != null && configObject != null)
		{
			_wrapper = new EOVariableListWrapper(currentNode, configObject);
			_wrapper.MultiSelect = _executeManager.SelectionMode != SelectionMode.Single;
		}
	}

	public bool? OpenDialog()
	{
		if (_wrapper != null)
		{
			EOVariableListDialogSettings.InitializeSettings();
			VariableListDialog variableListDialog = new VariableListDialog
			{
				Title = _wrapper.DialogTitle,
				Owner = (_executeManager.SourceViewModel?.UnityContainer?.TryResolve<IShellApplication>().ActiveWindow as Window),
				SelectionMode = _executeManager.SelectionMode,
				CanQuery = _wrapper.CanQuery,
				QueryString = _wrapper.QueryString
			};
			MMHelp.SetHelpFile(variableListDialog, "eoconf.chm");
			MMHelp.SetHelpId(variableListDialog, 165);
			variableListDialog.QueryStringChanged += dialog_QueryStringChanged;
			variableListDialog.Loaded += dialog_Loaded;
			bool? result = variableListDialog.ShowDialog();
			_wrapper.QueryString = variableListDialog.QueryString;
			_wrapper.SaveProperties();
			if (result.HasValue && result.Value && variableListDialog.SelectedItems != null)
			{
				SaveSelection(variableListDialog.SelectedItems);
			}
			SaveDialogSettings(variableListDialog);
			return result;
		}
		return false;
	}

	private static void SaveDialogSettings(VariableListDialog dialog)
	{
		EOVariableListDialogSettings.UpdateVisibleColumns(from x in dialog.DataSource.Columns
			where x.Visibility == Visibility.Visible
			select x.EngineName);
		EOVariableListDialogSettings.SaveSettings();
	}

	private void dialog_Loaded(object sender, RoutedEventArgs e)
	{
		VariableListDialog obj = sender as VariableListDialog;
		List<VLDataColumn> columns = CreateColumns(_wrapper).ToList();
		_dataProvider = new EOVariableListDataProvider(_wrapper, columns);
		obj.DataSource = _dataProvider.CreateDataSource();
	}

	private void SaveSelection(IEnumerable<VLDataRow> selectedItems)
	{
		if (selectedItems != null)
		{
			List<string> selectedVariables = selectedItems.Select((VLDataRow x) => x.Header).ToList();
			List<string> physicalTypes = selectedItems.Select((VLDataRow x) => x[4].ValueAsString).ToList();
			List<string> units = selectedItems.Select((VLDataRow x) => x[2].ValueAsString).ToList();
			_executeManager.SaveSelectedVariables(selectedVariables, physicalTypes, units);
		}
	}

	private void dialog_QueryStringChanged(object sender, RoutedPropertyChangedEventArgs<string> e)
	{
		_wrapper.UpdateDataByQueryString(e.NewValue);
		_dataProvider.InvalidateData();
		(sender as VariableListDialog).DataSource = _dataProvider.CreateDataSource();
	}

	private IEnumerable<VLDataColumn> CreateColumns(EOVariableListWrapper wrapper)
	{
		List<VLDataColumn> list = new List<VLDataColumn>();
		IList<EOVariableField> columnHeaders = wrapper.GetColumnHeaders();
		if (columnHeaders != null && columnHeaders.Count > 0)
		{
			foreach (EOVariableField item in columnHeaders)
			{
				VLDataColumn vLDataColumn = new VLDataColumn
				{
					Header = item.Header,
					EngineName = item.EngineName,
					IsKeyField = item.IsKeyField,
					IsReadOnly = true,
					Visibility = Visibility.Visible,
					CanChangeVisibility = true,
					CanModify = item.CanModify,
					CanQuery = item.CanQuery,
					IsFrozen = item.IsFrozen,
					CellsItemsSource = item.ItemsSource,
					DefaultDataType = item.DataType,
					Width = ((item.InitialWidth > 0.0) ? new double?(item.InitialWidth) : ((double?)null)),
					Tag = item
				};
				if (EOVariableListDialogSettings.MustColumnEngineNames.Contains(item.EngineName))
				{
					vLDataColumn.CanChangeVisibility = false;
				}
				else if (!EOVariableListDialogSettings.AdditionalColumnEngineNames.Contains(item.EngineName))
				{
					vLDataColumn.Visibility = Visibility.Collapsed;
				}
				list.Add(vLDataColumn);
			}
		}
		return list;
	}
}
