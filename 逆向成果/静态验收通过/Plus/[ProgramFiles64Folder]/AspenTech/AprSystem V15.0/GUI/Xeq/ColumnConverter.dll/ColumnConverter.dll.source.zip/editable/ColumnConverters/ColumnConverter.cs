using System;
using System.Collections;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using AspenTech.AspenPlus.APConvert;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Localization;

namespace ColumnConverters;

[ComVisible(false)]
public class ColumnConverter : IAPBlockConverter2, IAPBlockConverter
{
	private enum CursorName
	{
		IDC_ARROW = 32512,
		IDC_WAIT = 32514
	}

	private class StreamConnection
	{
		public string streamName;

		public string streamPort;

		public string blockName;

		public string blockPort;
	}

	private class ConvertData
	{
		public string varName;

		public object Value;

		public short Units;

		public object force = Missing.Value;
	}

	private const int HAP_UNITCOL = 3;

	private const int HAP_RESULTS_ERRORS = 32;

	private const int HAP_INPUT_INCOMPLETE = 64;

	private string sBasis = "MOLE";

	private string sRatioType = "RR";

	private int Ntotal = 2;

	private int nPhase = 2;

	private int iDecanter;

	private int itemp;

	private int iTEst = 1;

	private int iXYEst = 1;

	private double[] TEst;

	private double[,] XEst;

	private double[,] YEst;

	private string sComp1 = "";

	private string sComp2 = "";

	private string sComp3 = "";

	private string stemp = "";

	private double dNFeed;

	private IHNode pVar;

	private IHNode pTemNode;

	private IntPtr gHourglassCursor;

	private IntPtr gPrevCursor;

	private ArrayList streamList;

	private ArrayList variableList;

	private ArrayList varWithUnitList;

	private object force;

	private string convertType;

	private string title = WpfMMDialogResources.ConvertTo_Title;

	public string BaseDestinationType => "RADFRAC";

	public string BaseSourceType => convertType.ToUpper();

	public string Description => WpfMMDialogResources.ConvertTo_This + " " + BaseSourceType + " " + WpfMMDialogResources.ConvertTo_ConverTo + " " + BaseDestinationType + " " + WpfMMDialogResources.ConvertTo_Model;

	public string DestLibraryFile => "";

	public string DestLibraryModelType => "";

	public string DestLibraryName => "";

	public string DisplayName => "Aspen RadFrac";

	[DllImport("user32")]
	private static extern IntPtr SetCursor(IntPtr hCursor);

	[DllImport("user32")]
	private static extern IntPtr LoadCursor(IntPtr hInstance, CursorName lpCursorName);

	public ColumnConverter(string type)
	{
		convertType = type;
		streamList = new ArrayList();
		variableList = new ArrayList();
		varWithUnitList = new ArrayList();
		force = Missing.Value;
	}

	public void PreConvert(IHNode pNode)
	{
	}

	public int PreConvert2(IHNode pNode)
	{
		gHourglassCursor = LoadCursor(IntPtr.Zero, CursorName.IDC_WAIT);
		gPrevCursor = SetCursor(gHourglassCursor);
		if (pNode == null)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Node, title);
			return 1;
		}
		itemp = (dynamic)pNode.get_AttributeValue((short)12, Type.Missing);
		if (itemp == 64)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Input_Incomplete, title);
			return 1;
		}
		if (itemp == 32)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_ErrorsArePresent, title);
			return 1;
		}
		pTemNode = pNode.FindNode("Input/IMODE");
		stemp = (dynamic)pTemNode.get_Value(force);
		if (stemp.CompareTo("DESIGN") != 0)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Material_Balance_Mode, title);
			return 1;
		}
		stemp = "Output/ACT_STAGES2";
		pTemNode = pNode.FindNode(stemp);
		if (pTemNode != null)
		{
			double num = Convert.ToDouble((dynamic)pTemNode.get_Value(force));
			if (num < 2.0 || num > 999.0)
			{
				MessageBox.Show(WpfMMDialogResources.ConvertTo_Infeasible_Design, title);
				return 1;
			}
		}
		pTemNode = pNode.FindNode("Input/SELCOMP1");
		sComp1 = (dynamic)pTemNode.get_Value(force);
		pTemNode = pNode.FindNode("Input/SELCOMP2");
		sComp2 = (dynamic)pTemNode.get_Value(force);
		pTemNode = pNode.FindNode("Input/SELCOMP3");
		sComp3 = (dynamic)pTemNode.get_Value(force);
		pTemNode = pNode.FindNode("Input/ICONFIG");
		stemp = (dynamic)pTemNode.get_Value(force);
		if (stemp.CompareTo("DECANTER") == 0)
		{
			iDecanter = 1;
		}
		else
		{
			iDecanter = 0;
		}
		try
		{
			IHNode iHNode = pNode.FindNode("Connections");
			IHNodeCol elements = iHNode.Elements;
			if (elements != null)
			{
				string text = pNode.get_Name(force);
				streamList.Clear();
				for (int i = 0; i < elements.Count; i++)
				{
					string text2 = elements.get_Label(0, i, force);
					IHNode iHNode2 = pNode.FindNode("../../Streams/" + text2 + "/Connections/" + text);
					if (iHNode2 != null)
					{
						StreamConnection streamConnection = new StreamConnection();
						IHNode iHNode3 = iHNode.FindNode(text2);
						streamConnection.streamName = text2;
						streamConnection.blockName = text;
						streamConnection.streamPort = (string)(dynamic)iHNode2.get_Value(force);
						stemp = (string)(dynamic)iHNode3.get_Value(force);
						if (stemp == "D(OUT)")
						{
							stemp = "LD(OUT)";
						}
						streamConnection.blockPort = stemp;
						streamList.Add(streamConnection);
					}
				}
			}
			variableList.Clear();
			ConvertData convertData = new ConvertData();
			stemp = "Output/ACT_STAGES2";
			pTemNode = pNode.FindNode(stemp);
			if (pTemNode != null)
			{
				double num2 = Convert.ToDouble((dynamic)pTemNode.get_Value(force));
				int num3 = Convert.ToInt16(num2);
				if (num2 > Convert.ToDouble(num3))
				{
					num3++;
				}
				Ntotal = num3;
				convertData.varName = "NSTAGE";
				convertData.Value = num3;
				variableList.Add(convertData);
			}
			convertData = new ConvertData();
			stemp = "Output/FEED_LOCATN2";
			pTemNode = pNode.FindNode(stemp);
			if (pTemNode != null)
			{
				double num4 = Convert.ToDouble((dynamic)pTemNode.get_Value(force));
				int num5 = Convert.ToInt16(num4);
				dNFeed = num4;
				if (num4 > Convert.ToDouble(num5))
				{
					num5++;
				}
				convertData.varName = "FEED_STAGE";
				convertData.Value = num5;
				variableList.Add(convertData);
			}
			convertData = new ConvertData();
			pTemNode = pNode.FindNode("Input/IBASIS");
			stemp = (dynamic)pTemNode.get_Value(force);
			if (stemp.CompareTo("MOLE") == 0)
			{
				sBasis = "MOLE";
				pTemNode = pNode.FindNode("Input/MOLE_RR");
				if (pTemNode != null && (dynamic)pTemNode.get_Value(force) != null)
				{
					sRatioType = "RR";
					convertData.varName = "MOLE_RR";
					convertData.Value = pTemNode.get_Value(force);
					variableList.Add(convertData);
				}
				else
				{
					sRatioType = "BR";
					pTemNode = pNode.FindNode("Input/MOLE_BR");
					if (pTemNode != null && (dynamic)pTemNode.get_Value(force) != null)
					{
						convertData.varName = "MOLE_BR";
						convertData.Value = pTemNode.get_Value(force);
						variableList.Add(convertData);
					}
				}
			}
			else
			{
				sBasis = "MASS";
				pTemNode = pNode.FindNode("Input/MASS_RR");
				if (pTemNode != null && (dynamic)pTemNode.get_Value(force) != null)
				{
					sRatioType = "RR";
					convertData.varName = "MASS_RR";
					convertData.Value = pTemNode.get_Value(force);
					variableList.Add(convertData);
				}
				else
				{
					pTemNode = pNode.FindNode("Input/MASS_BR");
					if (pTemNode != null && (dynamic)pTemNode.get_Value(force) != null)
					{
						sRatioType = "BR";
						convertData.varName = "MASS_BR";
						convertData.Value = pTemNode.get_Value(force);
						variableList.Add(convertData);
					}
				}
			}
			pTemNode = pNode.FindNode("Input/IPHASE");
			stemp = (dynamic)pTemNode.get_Value(force);
			if (stemp.CompareTo("VLL") == 0)
			{
				nPhase = 3;
			}
			else
			{
				nPhase = 2;
			}
			pTemNode = pNode.FindNode("Input/ICONFIG");
			stemp = (dynamic)pTemNode.get_Value(force);
			if (stemp.CompareTo("DECANTER") == 0)
			{
				iDecanter = 1;
			}
			else
			{
				iDecanter = 0;
			}
			varWithUnitList.Clear();
			convertData = new ConvertData();
			stemp = "Input/P_SPEC";
			pTemNode = pNode.FindNode(stemp);
			if (pTemNode != null)
			{
				convertData.varName = "PRES1";
				convertData.Value = pTemNode.get_Value(force);
				convertData.Units = Convert.ToInt16((dynamic)pTemNode.get_AttributeValue((short)3, force));
				varWithUnitList.Add(convertData);
			}
			convertData = new ConvertData();
			stemp = "Output/F2";
			pTemNode = pNode.FindNode(stemp);
			if (pTemNode != null)
			{
				convertData.varName = "BASIS_D";
				convertData.Value = pTemNode.get_Value(force);
				convertData.Units = Convert.ToInt16((dynamic)pTemNode.get_AttributeValue((short)3, force));
				varWithUnitList.Add(convertData);
			}
			Form1 form = new Form1();
			form.ShowDialog();
			if (form.gTemp)
			{
				iTEst = 1;
			}
			else
			{
				iTEst = 0;
			}
			if (form.gXY)
			{
				iXYEst = 1;
			}
			else
			{
				iXYEst = 0;
			}
			if (iTEst == 1)
			{
				int num6 = 0;
				TEst = new double[Ntotal];
				for (int j = 1; j < Ntotal + 1; j++)
				{
					pTemNode = pNode.FindNode("Output/B_TEMP4/" + j);
					TEst[num6] = Convert.ToDouble((dynamic)pTemNode.get_Value(force));
					num6++;
				}
			}
			if (iXYEst == 1)
			{
				int num7 = 0;
				XEst = new double[Ntotal, 3];
				YEst = new double[Ntotal, 3];
				for (int k = 1; k < Ntotal + 1; k++)
				{
					for (int l = 1; l < 4; l++)
					{
						pTemNode = pNode.FindNode("Output/X10/" + k + "/" + l);
						XEst[num7, l - 1] = Convert.ToDouble((dynamic)pTemNode.get_Value(force));
						pTemNode = pNode.FindNode("Output/Y/" + k + "/" + l);
						YEst[num7, l - 1] = Convert.ToDouble((dynamic)pTemNode.get_Value(force));
					}
					num7++;
				}
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_CannotBeConverted, title);
			throw new Exception(ex.Message.ToString());
		}
		return 0;
	}

	public void PostConvert(IHNode pNode)
	{
		IHNode iHNode = pNode.FindNode("Ports");
		IHNodeCol elements = iHNode.Elements;
		pNode?.HoldNotifies(hold: true);
		if (elements != null)
		{
			for (int i = 0; i < streamList.Count; i++)
			{
				StreamConnection streamConnection = streamList[i] as StreamConnection;
				for (int j = 0; j < elements.Count; j++)
				{
					string text = elements.get_Label(0, j, force);
					if (text.CompareTo(streamConnection.blockPort) == 0)
					{
						string streamName = streamConnection.streamName;
						IHNodeCol destinationElements = iHNode.FindNode(text).Elements;
						if (destinationElements != null)
						{
							destinationElements.Add(streamName, null, null, null, null);
						}
						break;
					}
				}
			}
		}
		pVar = pNode.FindNode("Input/CONDENSER");
		if (pVar != null)
		{
			pVar.set_Value(force, (object)"TOTAL");
		}
		pVar = pNode.FindNode("Input/NSTAGE");
		if (pVar != null)
		{
			ConvertData convertData = variableList[0] as ConvertData;
			pVar.set_Value(convertData.force, convertData.Value);
		}
		pVar = pNode.FindNode("Input/FEED_STAGE");
		if (pVar != null)
		{
			IHNode iHNode2 = pVar.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing];
			ConvertData convertData2 = variableList[1] as ConvertData;
			iHNode2.set_Value(convertData2.force, convertData2.Value);
		}
		pVar = pNode.FindNode("Input/FEED_CONVEN");
		if (pVar != null)
		{
			pVar.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].set_Value(force, (object)"ON-STAGE");
		}
		pVar = pNode.FindNode("Input/FEED_CONVE2");
		if (pVar != null)
		{
			pVar.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].set_Value(force, (object)"ON-STAGE");
		}
		if (sRatioType.CompareTo("RR") == 0)
		{
			pVar = pNode.FindNode("Input/BASIS_RR");
		}
		else
		{
			pVar = pNode.FindNode("Input/BASIS_BR");
		}
		if (pVar != null)
		{
			ConvertData convertData3 = variableList[2] as ConvertData;
			pVar.set_Value(convertData3.force, convertData3.Value);
		}
		if (sRatioType.CompareTo("RR") == 0)
		{
			pVar = pNode.FindNode("Input/RR_BASIS");
		}
		else
		{
			pVar = pNode.FindNode("Input/BR_BASIS");
		}
		if (pVar != null)
		{
			pVar.set_Value(force, (object)sBasis);
		}
		pVar = pNode.FindNode("Input/PRES1");
		if (pVar != null)
		{
			ConvertData convertData4 = varWithUnitList[0] as ConvertData;
			pVar.SetValueAndUnit(convertData4.Value, convertData4.Units, convertData4.force);
		}
		pVar = pNode.FindNode("Input/D_BASIS");
		if (pVar != null)
		{
			pVar.set_Value(force, (object)"MOLE");
		}
		pVar = pNode.FindNode("Input/BASIS_D");
		if (pVar != null)
		{
			ConvertData convertData5 = varWithUnitList[1] as ConvertData;
			pVar.SetValueUnitAndBasis(convertData5.Value, convertData5.Units, "MOLE", convertData5.force);
		}
		if (nPhase == 3)
		{
			pVar = pNode.FindNode("Input/NO_PHASE");
			if (pVar != null)
			{
				pVar.set_Value(force, (object)nPhase);
			}
			pVar = pNode.FindNode("Input/TRAY2");
			if (pVar != null)
			{
				pVar.Elements.InsertRow(0, 0);
				pVar.Elements.set_Label(0, 0, force, "1");
				pVar.Elements["1", Type.Missing, Type.Missing, Type.Missing, Type.Missing].set_Value(force, (object)Ntotal);
			}
			pVar = pNode.FindNode("Input/COMP_LIST");
			if (pVar != null)
			{
				pVar.Elements.InsertRow(0, 0);
				IHNode iHNode3 = pNode.FindNode("Input/COMP_LIST/#0");
				if (iHNode3 != null)
				{
					iHNode3.set_Value(force, (object)sComp1);
				}
			}
		}
		if (iDecanter == 1)
		{
			pVar = pNode.FindNode("Subobjects/Decanters");
			if (pVar != null)
			{
				pVar.Elements.InsertRow(0, 0);
				pVar.Elements.set_Label(0, 0, force, "1");
				IHNode iHNode4 = pNode.FindNode("Input/L2_SPEC/1");
				if (iHNode4 != null)
				{
					iHNode4.set_Value(force, (object)"0.0");
				}
			}
		}
		if (iTEst == 1)
		{
			for (int k = 1; k < Ntotal + 1; k++)
			{
				pVar = null;
				pVar = pNode.FindNode("Input/TEMP_EST");
				if (pVar != null)
				{
					pVar.Elements.InsertRow(0, k - 1);
					pVar.Elements.set_Label(0, k - 1, force, k.ToString());
					IHNode iHNode5 = pNode.FindNode("Input/TEMP_EST/" + k);
					if (iHNode5 != null && TEst[k - 1] > 0.0)
					{
						iHNode5.set_Value(force, (object)TEst[k - 1]);
					}
				}
			}
		}
		pNode?.HoldNotifies(hold: false);
		if (iXYEst == 1)
		{
			pVar = pNode.FindNode("Input/X_EST");
			if (pVar != null)
			{
				IHNodeCol elements2 = pVar.Elements;
				for (int l = 1; l < Ntotal + 1; l++)
				{
					stemp = "(" + l + "," + sComp1 + ")";
					elements2.InsertRow(0, l - 1);
					elements2.set_Label(0, l - 1, force, l.ToString());
					if (l == 1)
					{
						elements2.InsertRow(1, 0);
						elements2.set_Label(1, 0, force, sComp1);
					}
					IHNode iHNode6 = pNode.FindNode("Input/X_EST/" + stemp);
					if (iHNode6 != null && XEst[l - 1, 0] > 0.0)
					{
						iHNode6.set_Value(force, (object)XEst[l - 1, 0]);
					}
					iHNode6 = pNode.FindNode("Input/Y_EST/" + stemp);
					if (iHNode6 != null && YEst[l - 1, 0] > 0.0)
					{
						iHNode6.set_Value(force, (object)YEst[l - 1, 0]);
					}
					stemp = "(" + l + "," + sComp2 + ")";
					if (l == 1)
					{
						elements2.InsertRow(1, 1);
						elements2.set_Label(1, 1, force, sComp2);
					}
					iHNode6 = pNode.FindNode("Input/X_EST/" + stemp);
					if (iHNode6 != null && XEst[l - 1, 1] > 0.0)
					{
						iHNode6.set_Value(force, (object)XEst[l - 1, 1]);
					}
					iHNode6 = pNode.FindNode("Input/Y_EST/" + stemp);
					if (iHNode6 != null && YEst[l - 1, 1] > 0.0)
					{
						iHNode6.set_Value(force, (object)YEst[l - 1, 1]);
					}
					stemp = "(" + l + "," + sComp3 + ")";
					if (l == 1)
					{
						elements2.InsertRow(1, 2);
						elements2.set_Label(1, 2, force, sComp3);
					}
					iHNode6 = pNode.FindNode("Input/X_EST/" + stemp);
					if (iHNode6 != null && XEst[l - 1, 2] > 0.0)
					{
						iHNode6.set_Value(force, (object)XEst[l - 1, 2]);
					}
					iHNode6 = pNode.FindNode("Input/Y_EST/" + stemp);
					if (iHNode6 != null && YEst[l - 1, 2] > 0.0)
					{
						iHNode6.set_Value(force, (object)YEst[l - 1, 2]);
					}
				}
			}
		}
		SetCursor(gPrevCursor);
	}
}
