# Performance.cs

Source: editable/WpfPLCompr/Performance.cs

Source SHA-256: d8755c09416e9fbb6cf098b856f67d5d3656a754b365bd015bc142f2838f7e6d
