using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPLControls;
using WpfPlotwizard;

namespace WpfPLResults;

[ProgId("WpfPLResults.Viscosity")]
public class Viscosity : UserControl, IRibbonPlotWizardType, IPlotWizardTemplate, IComponentConnector
{
	private IHNode _context;

	private IHWizardPlot _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper("PlotWiz.hlp", 295L);

	private string _uniqueId = "Results_Viscosity";

	private string _plotName;

	private object _nodeCxs;

	private System.Drawing.Image _imgIcon;

	private bool _bHasInputDialog;

	private string _currenViscosityUnit = string.Empty;

	private string _currentConfigValue = string.Empty;

	private List<string> _absVisList = new List<string>();

	private List<string> _kinVisList = new List<string>();

	private string varname1 = string.Empty;

	private string varname2 = string.Empty;

	public static RoutedCommand OKCommand = new RoutedCommand();

	public static RoutedCommand CancelCommand = new RoutedCommand();

	private bool _bCheckDataOnly;

	internal GroupBox groupBoxOption;

	internal RadioButton radioButtonAbsVis;

	internal RadioButton radioButtonKinVis;

	internal CurvesSelectorControl CurvesSelector;

	private bool _contentLoaded;

	public string TooltipContentForRibbonItem => WpfPLResultsResources.TooltipContentForRibbonItem_Viscosity;

	public string TooltipHeaderForRibbonItem => WpfPLResultsResources.TooltipHeaderForRibbonItem_Viscosity;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgIcon;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { WpfPLResultsResources.ViscosityUnit };

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public Viscosity()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Expected O, but got Unknown
		_bHasInputDialog = true;
		if (_imgIcon == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLResults.Images.viscosity.ico");
			_imgIcon = new Bitmap(manifestResourceStream);
		}
		InitializeComponent();
		CommandBinding commandBinding = new CommandBinding(OKCommand, ExecuteOKCommand, CanExecuteOKCommand);
		CommandBinding commandBinding2 = new CommandBinding(CancelCommand, ExecuteCancelCommand);
		base.CommandBindings.Add(commandBinding);
		base.CommandBindings.Add(commandBinding2);
	}

	private void GetVarName()
	{
		varname1 = "PetroCharacterization/Results/Output/VISC";
		varname2 = "PetroCharacterization/Results/Output/KVISC";
	}

	private string SaveConfigValue()
	{
		_ = string.Empty;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("ViscosityOption=");
		stringBuilder.Append(radioButtonAbsVis.IsChecked);
		stringBuilder.Append(";");
		stringBuilder.Append("AbsVisEnable=");
		stringBuilder.Append(radioButtonAbsVis.IsEnabled);
		stringBuilder.Append(";");
		stringBuilder.Append("KinVisEnable=");
		stringBuilder.Append(radioButtonKinVis.IsEnabled);
		stringBuilder.Append(";");
		stringBuilder.Append("CurveSelection=");
		List<string> list = new List<string>(CurvesSelector.GetSelectedCurves());
		int count = list.Count;
		for (int i = 0; i < count; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(",");
			}
			stringBuilder.Append(list[i]);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("CheckAll=");
		stringBuilder.Append(CurvesSelector.IsCheckAll);
		stringBuilder.Append(";");
		return stringBuilder.ToString();
	}

	private void RestoreConfigValue(string ConfigString)
	{
		string[] array = ConfigString.Split(';');
		int num = 0;
		string value = array[num].Substring(array[num].IndexOf('=') + 1);
		radioButtonAbsVis.IsChecked = Convert.ToBoolean(value);
		radioButtonKinVis.IsChecked = !radioButtonAbsVis.IsChecked;
		num++;
		value = array[num].Substring(array[num].IndexOf('=') + 1);
		radioButtonAbsVis.IsEnabled = Convert.ToBoolean(value);
		num++;
		value = array[num].Substring(array[num].IndexOf('=') + 1);
		radioButtonKinVis.IsEnabled = Convert.ToBoolean(value);
		num++;
		value = array[num].Substring(array[num].IndexOf('=') + 1);
		SetCurves();
		string[] array2 = value.Split(',');
		List<string> list = new List<string>();
		string[] array3 = array2;
		foreach (string item in array3)
		{
			list.Add(item);
		}
		CurvesSelector.SetSelectedCurves(list.ToArray());
		num++;
		value = array[num].Substring(array[num].IndexOf('=') + 1);
		CurvesSelector.IsCheckAll = Convert.ToBoolean(value);
	}

	public void SetCaption(ref string caption)
	{
		caption = WpfPLResultsResources.Viscosity_Name;
	}

	public void SetDefaultHeight(ref double defaultHeight)
	{
		defaultHeight = 380.0;
	}

	public void SetDefaultWidth(ref double defaultWidth)
	{
		defaultWidth = 300.0;
	}

	public void SetMinHeight(ref double minHeight)
	{
		minHeight = 380.0;
	}

	public void SetMinWidth(ref double minWidth)
	{
		minWidth = 300.0;
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		if (sFieldName.CompareTo(WpfPLResultsResources.ViscosityUnit) == 0)
		{
			List<string> list = new List<string>();
			_help.LoadUnitsList(_context.Application.Tree, _wizardPlot, list);
			return list;
		}
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
		if (sFieldName.CompareTo(WpfPLResultsResources.ViscosityUnit) == 0)
		{
			sCurrentVal = _help.GetUnitString(_context.Application.Tree, _wizardPlot);
		}
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
		bool updatePlot = false;
		if (sFieldName.CompareTo(WpfPLResultsResources.ViscosityUnit) == 0)
		{
			_currenViscosityUnit = sValue;
		}
		if (updatePlot)
		{
			UpdateWizardData();
		}
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		if (sField.CompareTo(WpfPLResultsResources.ViscosityUnit) == 0)
		{
			return (RibbonControlType)1;
		}
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
		sConfigValue = _currentConfigValue;
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
		_currentConfigValue = sValue;
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot;
		GetVarName();
		int num = 0;
		string text = "";
		IHNode iHNode = _context.FindNode(varname1);
		if (iHNode != null && iHNode.Elements.Count > 0)
		{
			_absVisList.Clear();
			num = iHNode.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.Count;
			for (int i = 0; i < num; i++)
			{
				_absVisList.Add(iHNode.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.get_Label(0, i, Type.Missing));
			}
			radioButtonAbsVis.IsEnabled = true;
			radioButtonKinVis.IsEnabled = false;
		}
		iHNode = _context.FindNode(varname2);
		if (iHNode != null && iHNode.Elements.Count > 0)
		{
			_kinVisList.Clear();
			num = iHNode.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.Count;
			for (int j = 0; j < num; j++)
			{
				_kinVisList.Add(iHNode.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.get_Label(0, j, Type.Missing));
			}
			radioButtonKinVis.IsEnabled = true;
		}
		if (_absVisList.Count() > 0)
		{
			text = varname1;
			radioButtonAbsVis.IsChecked = true;
		}
		else
		{
			radioButtonAbsVis.IsEnabled = false;
			if (_kinVisList.Count() > 0)
			{
				text = varname2;
				radioButtonKinVis.IsChecked = true;
			}
			else
			{
				ierror = 1;
				return;
			}
		}
		if (string.IsNullOrEmpty(_currentConfigValue))
		{
			List<string> list = new List<string>();
			iHNode = _context.FindNode(text);
			num = iHNode.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.Count;
			for (int k = 0; k < num; k++)
			{
				string item = iHNode.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.get_Label(0, k, Type.Missing);
				if (!list.Contains(item))
				{
					list.Add(item);
				}
			}
			CurvesSelector.SetCurves(list.ToArray());
		}
		else
		{
			RestoreConfigValue(_currentConfigValue);
		}
		_wizardPlot.RemoveAllDependentVariable();
		_wizardPlot.AddDependentVariable(_context, text);
	}

	public void UpdateWizardData()
	{
		string text = "";
		string text2 = "";
		List<string> list;
		IHNode iHNode;
		bool? isAbsolute = radioButtonAbsVis.IsChecked;
		bool expected = true;
		if ((isAbsolute.GetValueOrDefault() == expected) & isAbsolute.HasValue)
		{
			text = varname1;
			text2 = WpfPLResultsResources.Viscosity_YAxisTitle_Visc;
		}
		else
		{
			text = varname2;
			text2 = WpfPLResultsResources.Viscosity_YAxisTitle_KVisc;
		}
		_wizardPlot.SetIndependentVariable(_context, "PetroCharacterization/Results/Output/VAL1");
		_wizardPlot.RemoveAllDependentVariable();
		list = new List<string>(CurvesSelector.GetSelectedCurves());
		iHNode = _context.FindNode(text);
		if (iHNode != null && list.Count > 0)
		{
			_wizardPlot.PlotVal.NVariables = list.Count;
			for (int i = 0; i < list.Count; i++)
			{
				int location = iHNode.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.get_LabelLocation(list[i], 0);
				string text3 = iHNode.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.get_Label(0, location, Type.Missing);
				if (list[i] == text3)
				{
					((IHPlotVal)_wizardPlot.PlotVal).set_Label(i, text3);
					int count = iHNode.Elements.Count;
					for (int j = 0; j < count; j++)
					{
						((IHPlotVal)_wizardPlot.PlotVal).set_YData(i, j, (short)1, (object)iHNode.Elements[j, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements[text3, Type.Missing, Type.Missing, Type.Missing, Type.Missing]);
					}
				}
			}
		}
		((IHPlotVal)_wizardPlot.PlotVal).set_YAxisTitle((object)null, text2);
		_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currenViscosityUnit);
		_currentConfigValue = SaveConfigValue();
	}

	private void ExecuteOKCommand(object sender, ExecutedRoutedEventArgs e)
	{
		UpdateWizardData();
		_help.CloseForm((UserControl)this, (bool?)true);
	}

	private void CanExecuteOKCommand(object sender, CanExecuteRoutedEventArgs e)
	{
		int num = CurvesSelector.GetSelectedCurves().Count();
		if (num == CurvesSelector.Curves.Count)
		{
			CurvesSelector.IsCheckAll = true;
		}
		else
		{
			string[] selectedCurves = CurvesSelector.GetSelectedCurves();
			CurvesSelector.IsCheckAll = false;
			CurvesSelector.SetSelectedCurves(selectedCurves);
		}
		e.CanExecute = num != 0;
	}

	private void ExecuteCancelCommand(object sender, ExecutedRoutedEventArgs e)
	{
		_help.CloseForm((UserControl)this, (bool?)false);
	}

	private void clickAbsVis(object sender, RoutedEventArgs e)
	{
		SetCurves();
	}

	private void clickKinVis(object sender, RoutedEventArgs e)
	{
		SetCurves();
	}

	private void SetCurves()
	{
		List<string> list = new List<string>();
		bool? isAbsolute = radioButtonAbsVis.IsChecked;
		bool expected = true;
		if ((isAbsolute.GetValueOrDefault() == expected) & isAbsolute.HasValue)
		{
			for (int i = 0; i < _absVisList.Count(); i++)
			{
				list.Add(_absVisList[i]);
			}
		}
		else
		{
			for (int j = 0; j < _kinVisList.Count(); j++)
			{
				list.Add(_kinVisList[j]);
			}
		}
		CurvesSelector.IsCheckAll = false;
		CurvesSelector.SetCurves(list.ToArray());
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	public void InitializeComponent()
	{
		if (_contentLoaded)
		{
			return;
		}
		_contentLoaded = true;
		Uri resourceLocator = new Uri("/WpfPLResults;component/viscosity.xaml", UriKind.Relative);
		Application.LoadComponent(this, resourceLocator);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			groupBoxOption = (GroupBox)target;
			break;
		case 2:
			radioButtonAbsVis = (RadioButton)target;
			radioButtonAbsVis.Click += clickAbsVis;
			break;
		case 3:
			radioButtonKinVis = (RadioButton)target;
			radioButtonKinVis.Click += clickKinVis;
			break;
		case 4:
			CurvesSelector = (CurvesSelectorControl)target;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}
