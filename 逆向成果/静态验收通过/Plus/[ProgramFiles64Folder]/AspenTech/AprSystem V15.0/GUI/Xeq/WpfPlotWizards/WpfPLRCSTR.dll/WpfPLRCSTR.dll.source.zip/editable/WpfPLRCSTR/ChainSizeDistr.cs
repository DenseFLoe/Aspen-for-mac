using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPLControls;
using WpfPlotwizard;

namespace WpfPLRCSTR;

[ProgId("WpfPLRCSTR.ChainSizeDistr")]
public class ChainSizeDistr : UserControl, IRibbonPlotWizardType, IPlotWizardTemplate, IComponentConnector
{
	private IHNode _context;

	private IHWizardPlot _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private string _currentConfigValue = string.Empty;

	private string _uniqueId = WpfPLRCSTRResources.ChainSizeDistr_ID;

	private string _plotName;

	private object _nodeCxs;

	private System.Drawing.Image _imgBitmap;

	private bool _bHasInputDialog;

	private string _plotStyle = WpfPLRCSTRResources.ChainSize_PlotStyle_Title_CLD;

	private string[] _varNames;

	private string _polymer;

	private string _funcLog;

	public static RoutedCommand OKCommand = new RoutedCommand();

	public static RoutedCommand CancelCommand = new RoutedCommand();

	private bool _bCheckDataOnly;

	internal CheckBox checkBoxComposite;

	internal CheckBox checkBoxProperties;

	internal CurvesSelectorControl SiteList;

	private bool _contentLoaded;

	public string TooltipContentForRibbonItem => WpfPLRCSTRResources.TooltipContentForRibbonItem_ChainSizeDistr;

	public string TooltipHeaderForRibbonItem => WpfPLRCSTRResources.TooltipHeaderForRibbonItem_ChainSizeDistr;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { WpfPLRCSTRResources.ChainSize_PlotStyle_Title };

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public ChainSizeDistr()
	{
		InitializeComponent();
		_bHasInputDialog = true;
		if (_imgBitmap == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLRCSTR.Images.chainsizdis.ico");
			_imgBitmap = System.Drawing.Image.FromStream(manifestResourceStream);
		}
		CommandBinding commandBinding = new CommandBinding(OKCommand, ExecuteOKCommand, CanExecuteOKCommand);
		CommandBinding commandBinding2 = new CommandBinding(CancelCommand, ExecuteCancelCommand);
		base.CommandBindings.Add(commandBinding);
		base.CommandBindings.Add(commandBinding2);
	}

	public void SetCaption(ref string caption)
	{
		caption = WpfPLRCSTRResources.ChainSize_WindowTitle;
	}

	public void SetDefaultHeight(ref double defaultHeight)
	{
		defaultHeight = 300.0;
	}

	public void SetDefaultWidth(ref double defaultWidth)
	{
		defaultWidth = 300.0;
	}

	public void SetMinHeight(ref double minHeight)
	{
		minHeight = 300.0;
	}

	public void SetMinWidth(ref double minWidth)
	{
		minWidth = 300.0;
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		if (sFieldName.CompareTo(WpfPLRCSTRResources.ChainSize_PlotStyle_Title) == 0)
		{
			return new List<string>
			{
				WpfPLRCSTRResources.ChainSize_PlotStyle_Title_CLD,
				WpfPLRCSTRResources.ChainSize_PlotStyle_Title_MWD
			};
		}
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
		if (sFieldName.CompareTo(WpfPLRCSTRResources.ChainSize_PlotStyle_Title) == 0)
		{
			sCurrentVal = _plotStyle;
		}
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
		if (sFieldName.CompareTo(WpfPLRCSTRResources.ChainSize_PlotStyle_Title) == 0)
		{
			_plotStyle = sValue;
		}
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		if (sField.CompareTo(WpfPLRCSTRResources.ChainSize_PlotStyle_Title) == 0)
		{
			return RibbonControlType.ComboBox;
		}
		return RibbonControlType.None;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
		sConfigValue = _currentConfigValue;
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
		_currentConfigValue = sValue;
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot;
		SetVariables();
		IHNode iHNode = _context.FindNode(_varNames[0]);
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		checkBoxComposite.IsChecked = true;
		checkBoxProperties.IsChecked = true;
		IHNode iHNode2 = _context.Application.Tree.Elements["Data", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements["Components", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements["Polymers", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements["Input", Type.Missing, Type.Missing, Type.Missing, Type.Missing];
		int num = ((int?)(dynamic)iHNode2.Elements["NSITES", Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing)).GetValueOrDefault(0);
		_polymer = iHNode2.Elements["FUNCLOG", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.get_Label(0, 0, Type.Missing);
		_funcLog = (dynamic)iHNode2.Elements["FUNCLOG", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements[_polymer, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
		if (num > 0)
		{
			IHNode iHNode3 = _context.FindNode(_varNames[2]);
			if (iHNode3 != null && iHNode3.Elements.Count > 0)
			{
				List<string> list = new List<string>();
				int count = iHNode3.Elements.Count;
				for (int i = 0; i < count; i++)
				{
					string item = "Site" + (i + 1);
					list.Add(item);
				}
				SiteList.SetCurves(list.ToArray());
				SiteList.Header = WpfPLRCSTRResources.ChainSize_Sites_Title;
			}
		}
		else
		{
			SiteList.IsEnabled = false;
		}
		if (string.IsNullOrEmpty(_currentConfigValue))
		{
			checkBoxComposite.IsChecked = true;
			checkBoxProperties.IsChecked = true;
		}
		else
		{
			RestoreConfigValue(_currentConfigValue);
		}
	}

	public void UpdateWizardData()
	{
		_wizardPlot.RemoveAllDependentVariable();
		_wizardPlot.PlotVal.RemoveAnnotationText();
		bool flag = false;
		bool flag2 = false;
		List<string> list;
		IHNode iHNode;
		object obj;
		object obj2;
		object obj3;
		object obj4;
		object obj5;
		object obj6;
		double num;
		double num2;
		double num3;
		double num4;
		double num5;
		double num6;
		bool? isChecked;
		bool expectedChecked;
		isChecked = checkBoxComposite.IsChecked;
		expectedChecked = true;
		if ((isChecked.GetValueOrDefault() == expectedChecked) & isChecked.HasValue)
		{
			flag = true;
		}
		isChecked = checkBoxProperties.IsChecked;
		expectedChecked = true;
		if ((isChecked.GetValueOrDefault() == expectedChecked) & isChecked.HasValue)
		{
			flag2 = true;
		}
		list = new List<string>(SiteList.GetSelectedCurves());
		iHNode = _context.FindNode("Output");
		if (iHNode.Elements["DPN", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.Count <= 0)
		{
			return;
		}
		obj = iHNode.Elements["DPN", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements["COMPOSITE", Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
		obj2 = iHNode.Elements["MWN", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements["COMPOSITE", Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
		obj3 = iHNode.Elements["MWS", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements["COMPOSITE", Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
		obj4 = iHNode.Elements["DPW", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements["COMPOSITE", Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
		obj5 = iHNode.Elements["MWW", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements["COMPOSITE", Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
		obj6 = iHNode.Elements["PDI", Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements["COMPOSITE", Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
		num = (dynamic)((obj is double) ? obj : ((object)double.NaN));
		num2 = (dynamic)((obj2 is double) ? obj2 : ((object)double.NaN));
		num3 = (dynamic)((obj3 is double) ? obj3 : ((object)double.NaN));
		num4 = (dynamic)((obj4 is double) ? obj4 : ((object)double.NaN));
		num5 = (dynamic)((obj5 is double) ? obj5 : ((object)double.NaN));
		num6 = (dynamic)((obj6 is double) ? obj6 : ((object)double.NaN));
		_wizardPlot.SetIndependentVariable(_context, _varNames[1]);
		((IHPlotVal)_wizardPlot.PlotVal).set_AxisScale(0, 1);
		if (flag)
		{
			_wizardPlot.PlotVal.NVariables = 1;
			IHNode iHNode2 = _context.FindNode(_varNames[0]);
			IHNode iHNode3 = _context.FindNode(_varNames[1]);
			((IHPlotVal)_wizardPlot.PlotVal).set_Label(0, WpfPLRBatchResources.ChainSizeDistr_Legend);
			double num7 = 0.0;
			double num8 = 0.0;
			double num9 = 0.0;
			for (int i = 0; i < iHNode2.Elements.Count; i++)
			{
				double num10 = (dynamic)iHNode2.Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
				((IHPlotVal)_wizardPlot.PlotVal).set_YData(0, i, (short)0, (object)num10);
				if (i == iHNode2.Elements.Count - 1)
				{
					break;
				}
				double num11 = (dynamic)iHNode3.Elements[i + 1, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing) - (dynamic)iHNode3.Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
				double num12 = 0.0;
				if (_funcLog == "YES")
				{
					num12 = ((dynamic)iHNode2.Elements[i + 1, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing) / (dynamic)iHNode3.Elements[i + 1, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing) + (dynamic)iHNode2.Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing) / (dynamic)iHNode3.Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing)) / 2;
				}
				else
				{
					num12 = ((dynamic)iHNode2.Elements[i + 1, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing) + (dynamic)iHNode2.Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing)) / 2;
				}
				double num13 = num11 * num12;
				num7 += num13;
				num8 = num8 + num13 / (((dynamic)iHNode3.Elements[i + 1, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing) + (dynamic)iHNode3.Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing)) * 0.5);
				num9 = num9 + num13 * (((dynamic)iHNode3.Elements[i + 1, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing) + (dynamic)iHNode3.Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing)) * 0.5);
			}
			double num14 = double.NaN;
			if (num7 > 1E-15)
			{
				num8 = 1.0 / num8;
				num14 = num9 / num8;
			}
			else
			{
				num8 = double.NaN;
				num9 = double.NaN;
			}
			double num15 = num8 * num3;
			double num16 = num9 * num3;
			if (flag2)
			{
				string text = " =";
				string text2 = "";
				string text3 = "";
				string text4 = "";
				string text5 = "";
				string text6 = "";
				string text7 = "";
				if (_plotStyle == WpfPLRCSTRResources.ChainSize_PlotStyle_Title_CLD)
				{
					num.ToString();
					num8.ToString();
					text5 = $"{num:#0.00}";
					text6 = $"{num8:#0.00}";
					text7 = "DPN ";
					num4.ToString();
					num9.ToString();
					text2 = $"{num4:#0.00}";
					text3 = $"{num9:#0.00}";
					text4 = "DPW ";
				}
				else if (_plotStyle == WpfPLRCSTRResources.ChainSize_PlotStyle_Title_MWD)
				{
					num2.ToString();
					num15.ToString();
					text5 = $"{num2:#0.00}";
					text6 = $"{num15:#0.00}";
					text7 = "MWN ";
					num5.ToString();
					num16.ToString();
					text2 = $"{num5:#0.00}";
					text3 = $"{num16:#0.00}";
					text4 = "MWW ";
				}
				string text8 = $"{num7:#0.0000}";
				string text9 = $"{num6:#0.0000}";
				string text10 = $"{num14:#0.0000}";
				int num17 = text3.Length + 1;
				if (num17 < 14)
				{
					num17 = 14;
				}
				string text11 = _help.GetSpaces(8) + WpfPLRCSTRResources.Distribution + _help.GetSpaces(num17 - 12) + WpfPLRCSTRResources.Moments;
				string text12 = text7 + text + _help.GetSpaces(2) + text6 + _help.GetSpaces(num17 - text6.Length) + text5;
				string text13 = text4 + text + _help.GetSpaces(2) + text3 + _help.GetSpaces(num17 - text3.Length) + text2;
				string text14 = "PDI " + text + _help.GetSpaces(2) + text10 + _help.GetSpaces(num17 - text10.Length) + text9;
				string text15 = "Area" + text + _help.GetSpaces(2) + text8;
				PLOTTEXT pLOTTEXT = default;
				pLOTTEXT.x = 0.05;
				pLOTTEXT.y = 0.3;
				pLOTTEXT.text = text11 + "\n" + text12 + "\n" + text13 + "\n" + text14 + "\n" + text15;
				pLOTTEXT.fontname = "Segoe UI";
				pLOTTEXT.size = 9;
				CHPlotVal plotVal = _wizardPlot.PlotVal;
				PLOTTEXT text16 = pLOTTEXT;
				plotVal.AddAnnotationText(ref text16);
			}
		}
		if (_plotStyle == WpfPLRCSTRResources.ChainSize_PlotStyle_Title_MWD)
		{
			IHNode iHNode4 = _context.FindNode(_varNames[1]);
			for (int j = 0; j < iHNode4.Elements.Count; j++)
			{
				double num18 = (dynamic)iHNode4.Elements[j, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing) * num3;
				((IHPlotVal)_wizardPlot.PlotVal).set_XData(0, j, (short)0, (object)num18);
			}
		}
		if (list.Count > 0)
		{
			List<string> list2 = new List<string>(SiteList.GetAllCurves());
			IHNode iHNode5 = _context.FindNode(_varNames[2]);
			if (iHNode5 != null)
			{
				int count = iHNode5.Elements[0, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements.Count;
				int count2 = list.Count;
				int nVariables = _wizardPlot.PlotVal.NVariables;
				for (int k = 0; k < count2; k++)
				{
					string text17 = list[k];
					int num19 = list2.IndexOf(text17);
					if (num19 < 0)
					{
						num19 = k;
					}
					_wizardPlot.PlotVal.NVariables = _wizardPlot.PlotVal.NVariables + 1;
					((IHPlotVal)_wizardPlot.PlotVal).set_Label(k + nVariables, text17);
					for (int l = 0; l < count; l++)
					{
						((IHPlotVal)_wizardPlot.PlotVal).set_YData(k + nVariables, l, (short)1, (object)iHNode5.Elements[num19, Type.Missing, Type.Missing, Type.Missing, Type.Missing].Elements[l, Type.Missing, Type.Missing, Type.Missing, Type.Missing]);
					}
				}
			}
		}
		if (_plotStyle == WpfPLRCSTRResources.ChainSize_PlotStyle_Title_CLD)
		{
			_wizardPlot.PlotVal.Title = WpfPLRCSTRResources.Title_CLD;
			_wizardPlot.PlotVal.XAxisTitle = WpfPLRCSTRResources.XAxisTitle_CLD;
		}
		else if (_plotStyle == WpfPLRCSTRResources.ChainSize_PlotStyle_Title_MWD)
		{
			_wizardPlot.PlotVal.Title = WpfPLRCSTRResources.Title_MWD;
			_wizardPlot.PlotVal.XAxisTitle = WpfPLRCSTRResources.XAxisTitle_MWD;
		}
		_currentConfigValue = SaveConfigValue();
	}

	private void ExecuteOKCommand(object sender, ExecutedRoutedEventArgs e)
	{
		UpdateWizardData();
		_help.CloseForm(this, true);
	}

	private void CanExecuteOKCommand(object sender, CanExecuteRoutedEventArgs e)
	{
		int num = SiteList.GetSelectedCurves().Count();
		if (num == SiteList.Curves.Count)
		{
			SiteList.IsCheckAll = true;
		}
		else
		{
			string[] selectedCurves = SiteList.GetSelectedCurves();
			SiteList.IsCheckAll = false;
			SiteList.SetSelectedCurves(selectedCurves);
		}
		if (num <= 0 && checkBoxComposite.IsChecked == false)
		{
			e.CanExecute = false;
		}
		else
		{
			e.CanExecute = true;
		}
	}

	private void ExecuteCancelCommand(object sender, ExecutedRoutedEventArgs e)
	{
		_help.CloseForm(this, false);
	}

	private void chkComp_Click(object sender, RoutedEventArgs e)
	{
		bool? compositeChecked = checkBoxComposite.IsChecked;
		bool compositeExpected = true;
		if ((compositeChecked.GetValueOrDefault() == compositeExpected) & compositeChecked.HasValue)
		{
			checkBoxProperties.IsEnabled = true;
			checkBoxProperties.IsChecked = true;
		}
		else
		{
			checkBoxProperties.IsEnabled = false;
			checkBoxProperties.IsChecked = false;
		}
	}

	private void SetVariables()
	{
		_varNames = new string[3] { "Output/POLCSDY", "Output/POLCSDX", "Output/POLCSDYS" };
	}

	private string SaveConfigValue()
	{
		_ = string.Empty;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("Composite=");
		stringBuilder.Append(checkBoxComposite.IsChecked);
		stringBuilder.Append(";");
		stringBuilder.Append("Properties=");
		stringBuilder.Append(checkBoxProperties.IsChecked);
		stringBuilder.Append(";");
		stringBuilder.Append("PropertiesEnable=");
		stringBuilder.Append(checkBoxProperties.IsEnabled);
		stringBuilder.Append(";");
		stringBuilder.Append("SiteSelection=");
		List<string> list = new List<string>(SiteList.GetSelectedCurves());
		int count = list.Count;
		for (int i = 0; i < count; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(",");
			}
			stringBuilder.Append(list[i]);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("CheckAll=");
		stringBuilder.Append(SiteList.IsCheckAll);
		stringBuilder.Append(";");
		return stringBuilder.ToString();
	}

	private void RestoreConfigValue(string ConfigString)
	{
		string[] array = ConfigString.Split(';');
		int num = 0;
		string value = array[num].Substring(array[num].IndexOf('=') + 1);
		checkBoxComposite.IsChecked = Convert.ToBoolean(value);
		num++;
		value = array[num].Substring(array[num].IndexOf('=') + 1);
		checkBoxProperties.IsChecked = Convert.ToBoolean(value);
		num++;
		value = array[num].Substring(array[num].IndexOf('=') + 1);
		checkBoxProperties.IsEnabled = Convert.ToBoolean(value);
		num++;
		value = array[num].Substring(array[num].IndexOf('=') + 1);
		string[] array2 = value.Split(',');
		List<string> list = new List<string>();
		string[] array3 = array2;
		foreach (string item in array3)
		{
			list.Add(item);
		}
		SiteList.SetSelectedCurves(list.ToArray());
		num++;
		value = array[num].Substring(array[num].IndexOf('=') + 1);
		SiteList.IsCheckAll = Convert.ToBoolean(value);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	public void InitializeComponent()
	{
		if (_contentLoaded)
		{
			return;
		}
		_contentLoaded = true;
		Uri resourceLocator = new Uri("/WpfPLRCSTR;component/chainsizedistr.xaml", UriKind.Relative);
		Application.LoadComponent(this, resourceLocator);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		switch (connectionId)
		{
		case 1:
			checkBoxComposite = (CheckBox)target;
			checkBoxComposite.Click += chkComp_Click;
			break;
		case 2:
			checkBoxProperties = (CheckBox)target;
			break;
		case 3:
			SiteList = (CurvesSelectorControl)target;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}
