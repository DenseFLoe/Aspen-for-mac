using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLSensitivity;

[RibbonPlotWizardMgr("WpfPLSENSITIVITY.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class SensitivityPlotWizardModule : PlotModuleBase
{
}
