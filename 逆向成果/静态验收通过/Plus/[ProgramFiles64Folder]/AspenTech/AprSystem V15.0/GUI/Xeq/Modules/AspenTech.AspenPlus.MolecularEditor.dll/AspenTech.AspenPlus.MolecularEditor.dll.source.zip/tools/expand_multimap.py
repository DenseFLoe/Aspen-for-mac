"""Rebuild ILSpy's hoisted-local MultiMap initializers into nested object initializers.

Usage: expand_multimap.py <file.cs>

The original assemblies write e.g.

    CxvPropertyDeclaration.Register("...", typeof(T), new CxvMultiMapProperty {
        Variables = { new CxvMultiMapVariable { ... } },
        Options = { new CxvMultiMapOption { ..., Values = { new CxvMultiMapValue { ... } } } } });

ILSpy instead hoists `Type typeFromHandle = typeof(T)`, `CxvMultiMapProperty val = ...`,
`CxvMultiMapOptionCollection options = val.Options` and explicit Add calls, adding
locals and castclasses the original never had.  This script rewrites those static
constructors back to the initializer form (statement stream -> expression).
"""
import re
import sys
from pathlib import Path


def split_statements(body):
    """Split C# statements at top-level semicolons (ignoring braces/strings)."""
    body = re.sub(r"(?m)^\s*//.*$\n?", "", body)
    out, buf, depth, in_str, esc = [], [], 0, False, False
    for ch in body:
        if in_str:
            buf.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
            buf.append(ch)
        elif ch == "{":
            depth += 1
            buf.append(ch)
        elif ch == "}":
            depth -= 1
            buf.append(ch)
        elif ch == ";" and depth == 0:
            out.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    tail = "".join(buf).strip()
    if tail:
        out.append(tail)
    return out


def ind(text, prefix="\t"):
    return "\n".join(prefix + line for line in text.splitlines())


def transform(method_text):
    head, brace, body = method_text.partition("{")
    inner = body.rsplit("}", 1)[0]
    statements = split_statements(inner)
    out, i = [], 0
    changed = False
    while i < len(statements):
        s = statements[i]
        m = re.fullmatch(r"Type (\w+) = typeof\(([\w.]+)\)", s)
        if m:
            # remember alias, drop the hoisted local
            transform.aliases[m.group(1)] = m.group(2)
            changed = True
            i += 1
            continue
        m = re.fullmatch(r"CxvMultiMapProperty (\w+) = new CxvMultiMapProperty\(\)", s)
        if m:
            obj = m.group(1)
            variables, options, extra, j = [], [], [], i + 1
            current = None
            while j < len(statements):
                t = statements[j]
                mm = re.fullmatch("(?:\\(\\(\\w+\\)" + obj + "\\)|" + obj + r")\.(\w+) = (new [^\n]*\s*\{.*\})", t, re.S)
                if mm:
                    extra.append((mm.group(1), mm.group(2)))
                    j += 1
                    continue
                mm = re.match(r"\(\(Collection<[^>]+>\)\(object\)" + obj + r"\.Variables\)\.Add\((new [^\n]*\s*\{.*\})\)$", t, re.S)
                if mm:
                    variables.append(mm.group(1))
                    j += 1
                    continue
                mm = re.fullmatch(r"CxvMultiMapOptionCollection \w+ = " + obj + r"\.Options", t)
                if mm:
                    j += 1
                    continue
                mm = re.fullmatch(r"CxvMultiMapOption (\w+) = (new CxvMultiMapOption\s*\{.*\})", t, re.S)
                if mm:
                    current = {"name": mm.group(1), "text": mm.group(2)}
                    j += 1
                    continue
                mm = re.match(r"\(\(Collection<[^>]+>\)\(object\)" + current["name"] + r"\.Values\)\.Add\((new [^\n]*\s*\{.*\})\)$", t, re.S) if current else None
                if mm:
                    current.setdefault("values", []).append(mm.group(1))
                    j += 1
                    continue
                mm = re.fullmatch(r"\(\(Collection<CxvMultiMapOption>\)\(object\)\w+\)\.Add\(" + current["name"] + r"\)", t) if current else None
                if mm:
                    options.append(current)
                    current = None
                    j += 1
                    continue
                break
            if current is not None:
                raise SystemExit("unterminated MultiMap option")
            i = j
            # find the Register assignment that consumes `obj`
            while i < len(statements):
                t = statements[i]
                rm = re.fullmatch(r"(\w+) = CxvPropertyDeclaration\.Register\(\"([^\"]*)\", (\w+), \(CxvPropertyBase\)" + obj + r"\)", t)
                if rm:
                    field, name, type_alias = rm.groups()
                    type_name = transform.aliases.get(type_alias, type_alias)
                    parts = []
                    if variables:
                        parts.append("\tVariables = { " + ", ".join(variables) + " }")
                    if options:
                        rendered = []
                        for opt in options:
                            text = opt["text"]
                            if opt.get("values"):
                                text = text.rstrip()
                                assert text.endswith("}")
                                text = (text[:-1].rstrip() + ",\n\t\t\t\t\tValues = { " +
                                        ", ".join(opt["values"]) + " }\n\t\t\t\t}")
                            rendered.append(text)
                        parts.append("\tOptions = { " + ", ".join(rendered) + " }")
                    for prop, expr_text in extra:
                        parts.append("\t%s = %s" % (prop, expr_text))
                    expr = ("%s = CxvPropertyDeclaration.Register(\"%s\", typeof(%s), (CxvPropertyBase)new CxvMultiMapProperty\n"
                            "{\n%s\n})" % (field, name, type_name, ",\n".join(parts)))
                    out.append(expr + ";")
                    changed = True
                    i += 1
                    break
                i += 1
            continue
        out.append(s + ";")
        i += 1
    if not changed:
        return method_text
    body_new = "{\n" + "\n".join("\t" + stmt for stmt in out) + "\n"
    return head + body_new + "\t}"


def process(text):
    transform.aliases = {}
    # operate on whole static constructors only
    pattern = re.compile(r"(\t\tstatic \w+\(\)\n)(\t\t\{)")
    result, pos = [], 0
    for m in pattern.finditer(text):
        # find matching closing brace of the method
        start = m.end() - 1
        depth = 0
        j = start
        while True:
            if text[j] == "{":
                depth += 1
            elif text[j] == "}":
                depth -= 1
                if depth == 0:
                    break
            j += 1
        method = text[m.start():j + 1]
        new = transform(method)
        result.append(text[pos:m.start()])
        result.append(new)
        pos = j + 1
    result.append(text[pos:])
    return "".join(result)


if __name__ == "__main__":
    p = Path(sys.argv[1])
    text = p.read_text(encoding="utf-8-sig")
    new = process(text)
    if new == text:
        raise SystemExit("no change")
    p.write_text(new, encoding="utf-8")
    print("rewrote", p.name)
