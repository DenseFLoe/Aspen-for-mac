using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Xml.Serialization;
using Infragistics;
using Infragistics.Persistence.Primitives;
using Infragistics.Shared;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("InfragisticsWPF.Persistence")]
[assembly: AssemblyDescription("Persistence Library for WPF - Release Version")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("Infragistics Inc.")]
[assembly: AssemblyProduct("Infragistics Ultimate")]
[assembly: AssemblyCopyright("Copyright (c) Infragistics, Inc. 2009 - 2021")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("e82721f6-eb23-4fe6-b1f5-f74c77ee2d06")]
[assembly: AssemblyFileVersion("21.2.20212.9")]
[assembly: SatelliteContractVersion("21.2.0.0")]
[assembly: XmlnsPrefix("http://schemas.infragistics.com/xaml", "ig")]
[assembly: XmlnsDefinition("http://schemas.infragistics.com/xaml", "Infragistics.Persistence")]
[assembly: CLSCompliant(true)]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: StringResourceLocation("Infragistics.Persistence.Strings")]
[assembly: TargetFramework(".NETFramework,Version=v4.0", FrameworkDisplayName = ".NET Framework 4")]
[assembly: AssemblyVersion("21.2.20212.9")]
internal sealed class SR
{
private static SR loader = null;

[ThreadStatic]
	private static Dictionary<DynamicResourceString.ID, DynamicResourceString> _dynamicResourceStrings = null;

private ResourceManager[] resources;

private SR()
	{
		string text3 = "Infragistics.Persistence.strings";
		string[] array = text3.Split(';');
		int num = 0;
		string[] array2 = array;
		foreach (string text in array2)
		{
			if (text != null && text.Length > 0)
			{
				num++;
			}
		}
		resources = new ResourceManager[num];
		Assembly assembly = GetType().Assembly;
		int num2 = 0;
		array2 = array;
		foreach (string text2 in array2)
		{
			if (text2 != null && text2.Length > 0)
			{
				resources[num2++] = new ResourceManager(text2, assembly);
			}
		}
	}

public static DynamicResourceString GetDynamicResourceString(string name, object[] args, CultureInfo culture)
	{
		lock (typeof(SR))
		{
			DynamicResourceString.ID key = new DynamicResourceString.ID(culture, name, args);
			DynamicResourceString value = null;
			if (_dynamicResourceStrings == null)
			{
				_dynamicResourceStrings = new Dictionary<DynamicResourceString.ID, DynamicResourceString>();
			}
			else
			{
				_dynamicResourceStrings.TryGetValue(key, out value);
			}
			if (value == null)
			{
				value = new InternalDynamicResourceString(ResourceCustomizerLocator.Customizer, culture, name, args);
				_dynamicResourceStrings.Add(key, value);
			}
			return value;
		}
	}

private static SR GetLoader()
	{
		if (loader == null)
		{
			Type type = typeof(SR);
			System.Threading.Monitor.Enter(type);
			try
			{
				if (loader == null)
				{
					loader = new SR();
				}
			}
			finally
			{
				System.Threading.Monitor.Exit(type);
			}
		}
		return loader;
	}

public static string GetString(string name)
	{
		return GetString(null, name);
	}

public static string GetString(string name, params object[] args)
	{
		return GetString(null, name, args);
	}

public static string GetString(CultureInfo culture, string name)
	{
		return GetString(culture, name, null);
	}

public static string GetString(CultureInfo culture, string name, params object[] args)
	{
		return GetStringHelper(true, culture, name, args);
	}

private static string GetStringHelper(bool allowCustomizedStrings, CultureInfo culture, string name, params object[] args)
	{
		string text = null;
		if (allowCustomizedStrings)
		{
			text = ResourceCustomizerLocator.Customizer.GetCustomizedString(name);
		}
		if (text == null)
		{
			SR sR = GetLoader();
			if (sR == null)
			{
				return string.Empty;
			}
			text = sR.GetString(name, culture);
			if (text == null)
			{
				text = string.Empty;
			}
		}
		if (args != null && args.Length != 0 && text.Length > 2)
		{
			try
			{
				text = string.Format(null, text, args);
			}
			catch
			{
			}
		}
		return text;
	}
private string GetString(string name, CultureInfo culture)
	{
		ResourceManager[] array = resources;
		for (int i = 0; i < array.Length; i++)
		{
			string text = array[i].GetString(name, culture);
			if (text != null)
			{
				return text;
			}
		}
		return null;
	}


public static string GetUncustomizedString(string name)
	{
		return GetUncustomizedString(null, name);
	}

public static string GetUncustomizedString(string name, params object[] args)
	{
		return GetUncustomizedString(null, name, args);
	}

public static string GetUncustomizedString(CultureInfo culture, string name)
	{
		return GetUncustomizedString(culture, name, null);
	}

public static string GetUncustomizedString(CultureInfo culture, string name, params object[] args)
	{
		return GetStringHelper(false, culture, name, args);
	}

public static object GetObject(string name)
	{
		return GetObject(null, name);
	}

public static object GetObject(CultureInfo culture, string name)
	{
		SR sR = GetLoader();
		if (sR == null)
		{
			return null;
		}
		return sR.GetObject(name, culture);
	}

private object GetObject(string name, CultureInfo culture)
	{
		ResourceManager[] array = resources;
		for (int i = 0; i < array.Length; i++)
		{
			object obj = array[i].GetObject(name, culture);
			if (obj != null)
			{
				return obj;
			}
		}
		return null;
	}
}
[AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = true)]
internal sealed class LocalizedCategoryAttribute : CategoryAttribute
{
	public LocalizedCategoryAttribute(string category)
		: base(category)
	{
	}

	protected override string GetLocalizedString(string value)
	{
		return SR.GetUncustomizedString(null, value);
	}
}
[AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = true)]
internal sealed class LocalizedDescriptionAttribute : DescriptionAttribute
{
private bool loaded;

public LocalizedDescriptionAttribute(string description)
		: base(description)
	{
	}

public override string Description
	{
		get
		{
			if (!loaded)
			{
				loaded = true;
				base.DescriptionValue = SR.GetUncustomizedString(null, base.Description);
			}
			return base.Description;
		}
	}
}
internal sealed class InternalDynamicResourceString : DynamicResourceString
{
	internal InternalDynamicResourceString(ResourceCustomizer customizer, CultureInfo cultureInfo, string resourceName, object[] args)
		: base(customizer, cultureInfo, resourceName, args)
	{
	}

	protected override string GetStringFromResource(string resourceName, CultureInfo culture)
	{
		return SR.GetString(culture, resourceName, null);
	}
}
internal class AssemblyRef
{
	public const string BaseResourceName = "Infragistics.Persistence.strings";

	internal const string AssemblyName = "InfragisticsWPF.Persistence";

	internal const string AssemblyProduct = "Infragistics Ultimate";

	internal const string AssemblyDescriptionBase = "Persistence Library for WPF";
}
namespace Infragistics.Persistence
{
	public abstract class PropertyPersistenceEventArgs : EventArgs
	{
protected PropertyPersistenceEventArgs(DependencyObject rootOwner, PropertyInfo pi, string propertyPath)
		{
			PropertyPath = propertyPath;
			PropertyInfo = pi;
			RootOwner = rootOwner;
		}

public string PropertyPath { get; private set; }

public PropertyInfo PropertyInfo { get; private set; }

public DependencyObject RootOwner { get; private set; }
}
	public class SavePropertyPersistenceEventArgs : PropertyPersistenceEventArgs
	{
public SavePropertyPersistenceEventArgs(DependencyObject rootOwner, PropertyInfo pi, string propertyPath, object value)
			: base(rootOwner, pi, propertyPath)
		{
			Value = value;
		}

public string Identifier { get; set; }

public string SaveValue { get; set; }

public object Value { get; set; }

public bool Cancel { get; set; }
}
	public class LoadPropertyPersistenceEventArgs : PropertyPersistenceEventArgs
	{
public LoadPropertyPersistenceEventArgs(DependencyObject rootOwner, PropertyInfo pi, string propertyPath, string savedValue, string id, object owner, object value)
			: base(rootOwner, pi, propertyPath)
		{
			SavedValue = savedValue;
			Identifier = id;
			Owner = owner;
			Value = value;
		}

public string Identifier { get; private set; }

public object Owner { get; private set; }

public string SavedValue { get; private set; }

public object Value { get; private set; }

public object LoadedValue { get; set; }

public bool Handled { get; set; }
}
	public class PersistenceSavedEventArgs : EventArgs
	{
	}
	public class PersistenceLoadedEventArgs : EventArgs
	{
public PersistenceLoadedEventArgs(ReadOnlyCollection<PropertyPersistenceExceptionDetails> exceptions)
		{
			PropertyExceptions = exceptions;
		}

public ReadOnlyCollection<PropertyPersistenceExceptionDetails> PropertyExceptions { get; private set; }
}
	public class InvalidPersistenceGroupException : Exception
	{
		public InvalidPersistenceGroupException()
			: this(SR.GetString("InvalidPersistenceGroupException"))
		{
		}

		public InvalidPersistenceGroupException(string message)
			: this(message, null)
		{
		}

		public InvalidPersistenceGroupException(string message, Exception innerException)
			: base(message, innerException)
		{
		}
	}
	public class PersistenceEvents
	{
		public event EventHandler<SavePropertyPersistenceEventArgs> SavePropertyPersistence;
		internal void OnSavePropertyPersistence(SavePropertyPersistenceEventArgs args)
		{
			if (this.SavePropertyPersistence != null)
			{
				this.SavePropertyPersistence(this, args);
			}
		}


		public event EventHandler<LoadPropertyPersistenceEventArgs> LoadPropertyPersistence;
		internal void OnLoadPropertyPersistence(LoadPropertyPersistenceEventArgs args)
		{
			if (this.LoadPropertyPersistence != null)
			{
				this.LoadPropertyPersistence(this, args);
			}
		}


		public event EventHandler<PersistenceLoadedEventArgs> PersistenceLoaded;
		internal void OnPersistenceLoaded(PersistenceLoadedEventArgs args)
		{
			if (this.PersistenceLoaded != null)
			{
				this.PersistenceLoaded(this, args);
			}
		}


		public event EventHandler<PersistenceSavedEventArgs> PersistenceSaved;
		internal void OnPersistenceSaved(PersistenceSavedEventArgs args)
		{
			if (this.PersistenceSaved != null)
			{
				this.PersistenceSaved(this, args);
			}
		}

	}
	public class PersistenceGroup
	{
private List<DependencyObject> _registeredObjects;

private ReadOnlyCollection<DependencyObject> _objects;

private PersistenceEvents _events;

public PersistenceGroup()
		{
			_registeredObjects = new List<DependencyObject>();
			_objects = new ReadOnlyCollection<DependencyObject>(_registeredObjects);
		}

public ReadOnlyCollection<DependencyObject> RegisteredObjects
	{
		get
		{
			return _objects;
		}
	}

public PersistenceEvents Events
		{
			get
			{
				if (_events == null)
				{
					_events = new PersistenceEvents();
				}
				return _events;
			}
			set
			{
				_events = value;
			}
		}

internal void RegisterObject(DependencyObject obj)
		{
			_registeredObjects.Add(obj);
		}

internal void UnregisterObject(DependencyObject obj)
		{
			_registeredObjects.Remove(obj);
		}
}
	public class PersistenceManager
	{




		private static List<Type> TypesToIgnore;

		private static Dictionary<Type, TypeConverter> PredefinedTypeConverters;

		private static List<string> NewNamespaces;

		private static Dictionary<string, string> UpgradeAssemblyDictionary;

		public static readonly DependencyProperty SettingsProperty;

		public static readonly DependencyProperty PersistenceGroupProperty;

		public static readonly DependencyProperty IdentifierProperty;

		[ThreadStatic]
		private static AssemblyLoadInfo _AssemblyLoadInfo;

		private Dictionary<int, string> _typeStore;

		private Dictionary<object, int> _objectStore;

		private Dictionary<int, object> _reverseObjectStore;

		private Dictionary<int, PropertyData> _propDataStore;

		private PersistenceSettings _settings;

		private DependencyObject _rootObject;

		private List<PropertyPersistenceExceptionDetails> _exceptions;

		private Collection<Type> _valueTypes;

		private PersistenceGroup _group;

		private int _currentPropertyDataKey;


		static PersistenceManager()
		{
			TypesToIgnore = new List<Type>
			{
				typeof(ContextMenu),
				typeof(ControlTemplate),
				typeof(DataTemplate),
				typeof(ItemsPanelTemplate),
				typeof(Style),
				typeof(ResourceDictionary)
			};
			PredefinedTypeConverters = new Dictionary<Type, TypeConverter>();
			NewNamespaces = new List<string>
			{
				"Infragistics", "Infragistics.Controls", "Infragistics.Controls.Primitives", "Infragistics.Controls.Editors", "Infragistics.Controls.Editors.Primitives", "Infragistics.Controls.Menus", "Infragistics.Controls.Menus.Primitives", "Infragistics.Controls.Interactions", "Infragistics.Controls.Interactions.Primitives", "Infragistics.Controls.Grids",
				"Infragistics.Controls.Grids.Primitives", "Infragistics.Controls.Lists", "Infragistics.Controls.Lists.Primitives"
			};
			UpgradeAssemblyDictionary = new Dictionary<string, string>();
			SettingsProperty = DependencyProperty.RegisterAttached("Settings", typeof(PersistenceSettings), typeof(PersistenceManager), new PropertyMetadata(null));
			PersistenceGroupProperty = DependencyProperty.RegisterAttached("PersistenceGroup", typeof(PersistenceGroup), typeof(PersistenceManager), new PropertyMetadata(PersistenceGroupChanged));
			IdentifierProperty = DependencyProperty.RegisterAttached("Identifier", typeof(string), typeof(PersistenceManager), new PropertyMetadata(null));
			PredefinedTypeConverters.Add(typeof(TimeSpan), new TimeSpanTypeConverter());
			PredefinedTypeConverters.Add(typeof(Duration), new DurationTypeConverter());
			PredefinedTypeConverters.Add(typeof(RepeatBehavior), new RepeatBehaviorTypeConverter());
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight", "InfragisticsWPF");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.DragDrop", "InfragisticsWPF.DragDrop");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.Compression", "InfragisticsWPF.Compression");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.Excel", "InfragisticsWPF.Documents.Excel");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.Persistence", "InfragisticsWPF.Persistence");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebEditors", "InfragisticsWPF.Controls.Editors");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebMenu", "InfragisticsWPF.Controls.Menus.XamMenu");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebHtmlViewer", "InfragisticsWPF.Controls.Interactions.XamHtmlViewer");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebDialogWindow", "InfragisticsWPF.Controls.Interactions.XamDialogWindow");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebOutlookBar", "InfragisticsWPF.Controls.Menus.XamOutlookBar");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebRibbon", "InfragisticsWPF.Controls.Menus.XamRibbon");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebGrid", "InfragisticsWPF.Controls.Grids.XamGrid");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebTagCloud", "InfragisticsWPF.Controls.Menus.XamTagCloud");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebComboEditor ", "InfragisticsWPF.Controls.Editors.XamComboEditor");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebTree", "InfragisticsWPF.Controls.Menus.XamTree");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.VirtualCollection", "InfragisticsWPF.Collections.VirtualCollection");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebSlider", "InfragisticsWPF.Controls.Editors.XamSlider");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebSpellChecker", "InfragisticsWPF.Controls.Interactions.XamSpellChecker");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.XamWebTileView", "InfragisticsWPF.Controls.Lists.XamTileView");
			UpgradeAssemblyDictionary.Add("Infragistics.Silverlight.Chart", "InfragisticsWPF.Charts.XamWebChart");
		}

		public static PersistenceSettings GetSettings(DependencyObject obj)
		{
			return (PersistenceSettings)obj.GetValue(SettingsProperty);
		}

		public static void SetSettings(DependencyObject obj, PersistenceSettings settings)
		{
			obj.SetValue(SettingsProperty, settings);
		}

		public static PersistenceGroup GetPersistenceGroup(DependencyObject obj)
		{
			return (PersistenceGroup)obj.GetValue(PersistenceGroupProperty);
		}

		public static void SetPersistenceGroup(DependencyObject obj, PersistenceGroup group)
		{
			obj.SetValue(PersistenceGroupProperty, group);
		}

		private static void PersistenceGroupChanged(DependencyObject obj, DependencyPropertyChangedEventArgs e)
		{
			if (e.OldValue != null)
			{
				((PersistenceGroup)e.OldValue).UnregisterObject(obj);
			}
			if (e.NewValue != null)
			{
				((PersistenceGroup)e.NewValue).RegisterObject(obj);
			}
		}

		public static string GetIdentifier(DependencyObject obj)
		{
			return (string)obj.GetValue(IdentifierProperty);
		}

		public static void SetIdentifier(DependencyObject obj, string id)
		{
			obj.SetValue(IdentifierProperty, id);
		}

		private static Type FixAssemblyQualifiedName(string oldAssemblyQualifiedName)
		{
			return null;
		}

		public static MemoryStream Save(PersistenceGroup group)
		{
			return SaveGroup(group, null);
		}

		public static MemoryStream Save(DependencyObject obj)
		{
			return Save(obj, GetSettings(obj));
		}

		public static MemoryStream Save(DependencyObject obj, PersistenceSettings settings)
		{
			PersistenceGroup persistenceGroup = new PersistenceGroup();
			persistenceGroup.RegisterObject(obj);
			return SaveGroup(persistenceGroup, settings);
		}

		private static MemoryStream SaveGroup(PersistenceGroup group, PersistenceSettings groupSettings)
		{
			Dictionary<int, string> dictionary = new Dictionary<int, string>();
			Collection<Type> collection = new Collection<Type>();
			Collection<ElementData> collection2 = new Collection<ElementData>();
			GroupData groupData = new GroupData();
			foreach (DependencyObject registeredObject in group.RegisteredObjects)
			{
				ElementData elementData = new ElementData();
				PersistenceSettings persistenceSettings = groupSettings;
				if (persistenceSettings == null)
				{
					persistenceSettings = GetSettings(registeredObject);
				}
				if (persistenceSettings == null)
				{
					persistenceSettings = new PersistenceSettings();
				}
				PersistenceManager persistenceManager = new PersistenceManager(group, persistenceSettings, registeredObject, dictionary, collection);
				elementData.PropertyTree = persistenceManager.BuildPropertyTree();
				Collection<PropertyDataPair> collection3 = new Collection<PropertyDataPair>();
				foreach (KeyValuePair<int, PropertyData> item in persistenceManager.PropertyDataStore)
				{
					collection3.Add(new PropertyDataPair
					{
						LookupKey = item.Key,
						Data = item.Value
					});
				}
				elementData.PropDataStore = collection3;
				elementData.TypeLookupKey = persistenceManager.StoreType(registeredObject.GetType());
				collection2.Add(elementData);
			}
			groupData.Elements = collection2;
			Collection<TypeDataPair> collection4 = new Collection<TypeDataPair>();
			foreach (KeyValuePair<int, string> item2 in dictionary)
			{
				collection4.Add(new TypeDataPair
				{
					LookupKey = item2.Key,
					TypeName = item2.Value
				});
			}
			groupData.TypeStore = collection4;
			Collection<string> collection5 = new Collection<string>();
			foreach (Type item3 in collection)
			{
				collection5.Add(item3.AssemblyQualifiedName);
			}
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(GroupData), collection.ToArray());
			StringBuilder stringBuilder = new StringBuilder();
			StringWriter textWriter = new StringWriter(stringBuilder, CultureInfo.InvariantCulture);
			xmlSerializer.Serialize(textWriter, groupData);
			MemoryStream memoryStream = new MemoryStream();
			PersistenceObject o = new PersistenceObject
			{
				Types = collection5,
				Xml = stringBuilder.ToString()
			};
			XmlSerializer xmlSerializer2 = new XmlSerializer(typeof(PersistenceObject));
			xmlSerializer2.Serialize(memoryStream, o);
			memoryStream.Position = 0L;
			PersistenceSavedEventArgs args = new PersistenceSavedEventArgs();
			group.Events.OnPersistenceSaved(args);
			return memoryStream;
		}

		public static void Load(PersistenceGroup group, Stream stream)
		{
			_AssemblyLoadInfo = new AssemblyLoadInfo();
			LoadGroup(group, stream, null);
			_AssemblyLoadInfo = null;
		}

		public static void Load(DependencyObject obj, Stream stream)
		{
			Load(obj, stream, GetSettings(obj));
		}

		public static void Load(DependencyObject obj, Stream stream, PersistenceSettings settings)
		{
			_AssemblyLoadInfo = new AssemblyLoadInfo();
			PersistenceGroup persistenceGroup = new PersistenceGroup();
			persistenceGroup.RegisterObject(obj);
			LoadGroup(persistenceGroup, stream, settings);
			_AssemblyLoadInfo = null;
		}

		private static void LoadGroup(PersistenceGroup group, Stream stream, PersistenceSettings settings)
		{
			List<PropertyPersistenceExceptionDetails> list = new List<PropertyPersistenceExceptionDetails>();
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(PersistenceObject));
			PersistenceObject persistenceObject = xmlSerializer.Deserialize(stream) as PersistenceObject;
			if (persistenceObject != null)
			{
				StringReader textReader = new StringReader(persistenceObject.Xml);
				Type[] array = new Type[persistenceObject.Types.Count];
				for (int i = 0; i < persistenceObject.Types.Count; i++)
				{
					array[i] = GetTypeFromSerializedName(persistenceObject.Types[i]);
				}
				string text5 = "";
				XmlSerializer xmlSerializer3 = new XmlSerializer(typeof(GroupData), array);
				GroupData groupData = xmlSerializer3.Deserialize(textReader) as GroupData;
				Dictionary<int, string> dictionary = new Dictionary<int, string>();
				if (text5 == "10.1")
				{
					foreach (TypeDataPair item in groupData.TypeStore)
					{
						Type type = Type.GetType(item.TypeName);
						if (type != null)
						{
							dictionary.Add(item.LookupKey, item.TypeName);
							continue;
						}
						type = FixAssemblyQualifiedName(item.TypeName);
						if (type != null)
						{
							dictionary.Add(item.LookupKey, type.AssemblyQualifiedName);
						}
					}
				}
				else
				{
					foreach (TypeDataPair item2 in groupData.TypeStore)
					{
						dictionary.Add(item2.LookupKey, SynchQualifiedTypeNameVersion(item2.TypeName));
					}
				}
				if (groupData != null)
				{
					bool flag = settings != null;
					int count = groupData.Elements.Count;
					if (count == group.RegisteredObjects.Count)
					{
					for (int j = 0; j < count; j++)
					{
						ElementData elementData = groupData.Elements[j];
						DependencyObject dependencyObject = group.RegisteredObjects[j];
						if (!flag)
						{
							settings = GetSettings(dependencyObject);
						}
						if (settings == null)
						{
							settings = new PersistenceSettings();
						}
						INeedInitializationForPersistence needInitializationForPersistence = dependencyObject as INeedInitializationForPersistence;
						if (needInitializationForPersistence != null)
						{
							needInitializationForPersistence.InitObject(null);
						}
						PersistenceManager persistenceManager = new PersistenceManager(group, settings, dependencyObject, dictionary, new Collection<Type>());
						if (persistenceManager.ResolveType(elementData.TypeLookupKey) == dependencyObject.GetType())
						{
							Dictionary<int, PropertyData> dictionary2 = new Dictionary<int, PropertyData>();
							foreach (PropertyDataPair item3 in elementData.PropDataStore)
							{
								dictionary2.Add(item3.LookupKey, item3.Data);
							}
							persistenceManager.PropertyDataStore = dictionary2;
							persistenceManager.UnloadPropertyTree(elementData.PropertyTree);
							list.AddRange(persistenceManager.Exceptions);
							continue;
						}
						throw new InvalidPersistenceGroupException();
					}
					}
					else
					{
						throw new InvalidPersistenceGroupException();
					}
				}
			}
			PersistenceLoadedEventArgs args = new PersistenceLoadedEventArgs(new ReadOnlyCollection<PropertyPersistenceExceptionDetails>(list));
			group.Events.OnPersistenceLoaded(args);
		}

		private static Type GetTypeFromSerializedName(string oldQualifiedTypeName)
		{
			return Type.GetType(SynchQualifiedTypeNameVersion(oldQualifiedTypeName));
		}

		private static string SynchQualifiedTypeNameVersion(string oldQualifiedTypeName)
		{
			if (oldQualifiedTypeName == null)
			{
				return oldQualifiedTypeName;
			}
			string[] array = oldQualifiedTypeName.Split(new string[1] { AssemblyLoadInfo.Infragistics_Literal }, StringSplitOptions.None);
			bool flag = oldQualifiedTypeName.StartsWith(AssemblyLoadInfo.Infragistics_Literal);
			if ((!flag && array.Length < 2) || (flag && array.Length >= 1 && array[1].Contains("Testing.Tests.Persistence")))
			{
				return oldQualifiedTypeName;
			}
			StringBuilder stringBuilder = new StringBuilder();
			if (!flag)
			{
				stringBuilder.Append(array[0]);
			}
			for (int i = 1; i < array.Length; i++)
			{
				stringBuilder.Append(SynchSection(array[i]));
			}
			return stringBuilder.ToString();
		}

		private static string SynchSection(string oldSection)
		{
			string[] array = oldSection.Split(new string[1] { "]" }, StringSplitOptions.None);
			if (array[0].Length <= _AssemblyLoadInfo._infragisticsSuffix.Length)
			{
				return AssemblyLoadInfo.Infragistics_Literal + oldSection;
			}
			if (_AssemblyLoadInfo._infragisticsSuffix.Length > 0 && array[0].Substring(0, _AssemblyLoadInfo._infragisticsSuffix.Length) != _AssemblyLoadInfo._infragisticsSuffix)
			{
				return AssemblyLoadInfo.Infragistics_Literal + oldSection;
			}
			string assemblyName = AssemblyLoadInfo.Infragistics_Literal + array[0];
			AssemblyName assemblyName2;
			try
			{
				assemblyName2 = new AssemblyName(assemblyName);
			}
			catch (Exception)
			{
				return AssemblyLoadInfo.Infragistics_Literal + oldSection;
			}
			if (assemblyName2.Version == _AssemblyLoadInfo._assemblyVersion)
			{
				return AssemblyLoadInfo.Infragistics_Literal + oldSection;
			}
			assemblyName2.Version = _AssemblyLoadInfo._assemblyVersion;
			StringBuilder stringBuilder = new StringBuilder();
			string fullName = assemblyName2.FullName;
			if (_AssemblyLoadInfo._platformVersionSuffix.Length == 0)
			{
				stringBuilder.Append(fullName);
			}
			else
			{
				int num = fullName.IndexOf(".", 1);
				int num2 = fullName.IndexOf(".v", num);
				if (num2 >= num)
				{
					int startIndex = fullName.IndexOf(",", num2);
					stringBuilder.Append(_AssemblyLoadInfo._infragisticsWithPlatformSuffix);
					stringBuilder.Append(_AssemblyLoadInfo._platformVersionSuffix);
					stringBuilder.Append(fullName.Substring(num, num2 - num));
					stringBuilder.Append(_AssemblyLoadInfo._versionSuffix);
					stringBuilder.Append(fullName.Substring(startIndex));
				}
			}
			for (int i = 1; i < array.Length; i++)
			{
				stringBuilder.Append("]");
				stringBuilder.Append(array[i]);
			}
			return stringBuilder.ToString();
		}

		private PersistenceManager(PersistenceGroup group, PersistenceSettings settings, DependencyObject rootObject, Dictionary<int, string> typeDataStore, Collection<Type> valueTypes)
		{
			_group = group;
			_typeStore = typeDataStore;
			_objectStore = new Dictionary<object, int>();
			_reverseObjectStore = new Dictionary<int, object>();
			_propDataStore = new Dictionary<int, PropertyData>();
			_settings = settings;
			_rootObject = rootObject;
			_valueTypes = valueTypes;
			_exceptions = new List<PropertyPersistenceExceptionDetails>();
		}

		public Collection<PropertyDataInfo> BuildPropertyTree()
		{
			StoreProperty(_rootObject, null);
			Collection<PropertyDataInfo> result = BuildPropertyTree("", _rootObject, validateAgainstIgnore: true);
			PersistenceSavedEventArgs args = new PersistenceSavedEventArgs();
			_settings.Events.OnPersistenceSaved(args);
			return result;
		}

		public void UnloadPropertyTree(Collection<PropertyDataInfo> tree)
		{
			_reverseObjectStore.Add(0, _rootObject);
			_propDataStore.Add(0, new PropertyData
			{
				Properties = tree
			});
			UnloadPropertyTree(_rootObject, tree, validateAgainstIgnore: true);
			PersistenceLoadedEventArgs args = new PersistenceLoadedEventArgs(new ReadOnlyCollection<PropertyPersistenceExceptionDetails>(_exceptions));
			_settings.Events.OnPersistenceLoaded(args);
		}

		private Collection<PropertyDataInfo> BuildPropertyTree(string propertyPath, object obj, bool validateAgainstIgnore)
		{
			Collection<PropertyDataInfo> collection = new Collection<PropertyDataInfo>();
			if (obj != null)
			{
				IProvideCustomObjectPersistence provideCustomObjectPersistence = obj as IProvideCustomObjectPersistence;
				if (provideCustomObjectPersistence != null)
				{
					object obj2 = provideCustomObjectPersistence.SaveObject();
					if (obj2 != null)
					{
						collection.Add(CreateAndStorePropertyData(obj2, "", "PersistenceCustomObject", obj2.GetType(), null, null, null, BuildPropertyTree("", obj2, validateAgainstIgnore: false)));
					}
					if (_settings == null || _settings.SavePersistenceOptions != PersistenceOption.OnlySpecified)
					{
						return collection;
					}
				}
				bool flag = obj is FrameworkElement;
				IProvidePropertyPersistenceSettings providePropertyPersistenceSettings = obj as IProvidePropertyPersistenceSettings;
				Type type = obj.GetType();
				if (providePropertyPersistenceSettings != null && providePropertyPersistenceSettings.PriorityProperties != null)
				{
					foreach (string priorityProperty in providePropertyPersistenceSettings.PriorityProperties)
					{
						PropertyInfo property = type.GetProperty(priorityProperty);
						if (property != null)
						{
							object value = property.GetValue(obj, null);
							PropertyDataInfo propertyDataInfo = SaveProperty(propertyPath, value, property, validateAgainstIgnore);
							if (propertyDataInfo != null)
							{
								collection.Add(propertyDataInfo);
							}
						}
					}
				}
				List<string> list = null;
				if (providePropertyPersistenceSettings != null)
				{
					list = providePropertyPersistenceSettings.PropertiesToIgnore;
				}
				PropertyInfo[] properties = type.GetProperties();
				foreach (PropertyInfo propertyInfo in properties)
				{
					object value2;
					bool flag2;
					string name = propertyInfo.Name;
					if (!(name == "Name"))
					{
						if (!(name == "DataContext"))
						{
						}
						else
						{
							continue;
						}
					}
					else if (flag)
					{
						continue;
					}
					if (TypesToIgnore.Contains(type))
					{
						continue;
					}
					if (list != null && list.Contains(propertyInfo.Name))
					{
						if (_settings == null)
						{
							continue;
						}
						string text = propertyPath;
						if (text.Length > 0)
						{
							text += ".";
						}
						text += propertyInfo.Name;
						if (_settings.PropertySettings.GetPropertyPersistenceInfo(propertyInfo, text) == null)
						{
							continue;
						}
					}
					value2 = null;
					flag2 = false;
					try
					{
						value2 = propertyInfo.GetValue(obj, null);
					}
					catch (Exception)
					{
						flag2 = true;
					}
					if (!flag2)
					{
						PropertyDataInfo propertyDataInfo2 = SaveProperty(propertyPath, value2, propertyInfo, validateAgainstIgnore);
						if (propertyDataInfo2 != null)
						{
							collection.Add(propertyDataInfo2);
						}
					}
				}
			}
			return collection;
		}

		private PropertyDataInfo SaveProperty(string propertyPath, object value, PropertyInfo pi, bool validateAgainstIgnore)
		{
			_currentPropertyDataKey = -1;
			string text = "";
			if (pi != null)
			{
				text = pi.Name;
				if (propertyPath.Length > 0)
				{
					propertyPath += ".";
				}
				propertyPath += text;
			}
			if (pi != null && ((pi.CanRead && pi.GetGetMethod() != null && pi.GetGetMethod().IsStatic) || (pi.CanWrite && pi.GetSetMethod() != null && pi.GetSetMethod().IsStatic)))
			{
				return null;
			}
			if (pi != null && pi.GetSetMethod() == null)
			{
				List<PropertyInfo> list = (from property in pi.PropertyType.GetProperties(BindingFlags.Instance | BindingFlags.Public)
					where property.CanWrite
					select property).ToList();
				if (value == null || (list.Count == 0 && !(value is IEnumerable)) || value is FrameworkElement)
				{
					return null;
				}
			}
			if (value == null && pi == null)
			{
				return null;
			}
			Type type = ((value != null) ? value.GetType() : pi.PropertyType);
			bool isValueType = type.IsValueType;
			bool isEnum = type.IsEnum;
			bool isNotPublic = type.IsNotPublic;
			bool isPrimitive = type.IsPrimitive;
			if (value != null && _objectStore.ContainsKey(value))
			{
				if (isValueType)
				{
					_currentPropertyDataKey = _objectStore[value];
				}
				else
				{
					if (_settings.SavePersistenceOptions == PersistenceOption.OnlySpecified && !_propDataStore.ContainsKey(_objectStore[value]) && _settings.PropertySettings.GetPropertyPersistenceInfo(pi, propertyPath) == null)
					{
						return null;
					}
					return new PropertyDataInfo
					{
						PropertyName = text,
						PropertyPath = propertyPath,
						DataKey = _objectStore[value]
					};
				}
			}
			PersistenceOption savePersistenceOptions = _settings.SavePersistenceOptions;
			PropertyPersistenceInfoBase propertyPersistenceInfo = _settings.PropertySettings.GetPropertyPersistenceInfo(pi, propertyPath);
			if (propertyPersistenceInfo != null)
			{
				string value2 = propertyPersistenceInfo.SaveValueToString(pi, propertyPath, value);
				if (string.IsNullOrEmpty(value2))
				{
					value2 = propertyPersistenceInfo.SaveValue;
				}
				if (!string.IsNullOrEmpty(value2))
				{
					return CreateAndStorePropertyData(value, text, propertyPath, type, null, propertyPersistenceInfo.SaveValue, null, null);
				}
				if (propertyPersistenceInfo.TypeConverter != null && propertyPersistenceInfo.TypeConverter.CanConvertFrom(typeof(string)) && propertyPersistenceInfo.TypeConverter.CanConvertTo(typeof(string)))
				{
					return CreateAndStorePropertyData(value, text, propertyPath, type, null, propertyPersistenceInfo.TypeConverter.ConvertToString(value), propertyPersistenceInfo.TypeConverter.GetType().AssemblyQualifiedName, null);
				}
				if (!string.IsNullOrEmpty(propertyPersistenceInfo.Identifier))
				{
					return CreateAndStorePropertyData(value, text, propertyPath, type, propertyPersistenceInfo.Identifier, null, null, null);
				}
			}
			else
			{
				if (savePersistenceOptions == PersistenceOption.OnlySpecified && validateAgainstIgnore)
				{
					if (value != null)
					{
						propertyPersistenceInfo = _settings.IgnorePropertySettings.GetPropertyPersistenceInfo(pi, propertyPath);
						if (propertyPersistenceInfo != null)
						{
							return null;
						}
						IEnumerable enumerable = value as IEnumerable;
						if (enumerable != null && value.GetType() != typeof(string))
						{
							Collection<PropertyDataInfo> collection = new Collection<PropertyDataInfo>();
							foreach (object item in enumerable)
							{
								PropertyDataInfo propertyDataInfo = SaveProperty(propertyPath + "[]", item, null, validateAgainstIgnore: true);
								if (propertyDataInfo == null)
								{
									if (value != null && _objectStore.ContainsKey(value))
									{
										int key = _objectStore[value];
										if (!_propDataStore.ContainsKey(key))
										{
											_objectStore.Remove(value);
										}
									}
									return null;
								}
								collection.Add(propertyDataInfo);
							}
							if (collection.Count > 0)
							{
								Collection<string> lookupKeys = null;
								IProvidePersistenceLookupKeys lookupKeyProvider = GetLookupKeyProvider(enumerable);
								if (lookupKeyProvider != null)
								{
									lookupKeys = lookupKeyProvider.GetLookupKeys();
								}
								return CreateAndStorePropertyData(value, text, propertyPath, type, null, false, null, null, collection, lookupKeys);
							}
						}
						else if (!(isValueType || isEnum) && !(isEnum || value is string || isPrimitive) && !(value is Color) && !TypesToIgnore.Contains(type) && type.GetConstructor(new Type[0]) != null)
						{
							StoreProperty(value, null);
							Collection<PropertyDataInfo> collection2 = BuildPropertyTree(propertyPath, value, validateAgainstIgnore: true);
							if (collection2.Count > 0)
							{
								return CreateAndStorePropertyData(value, text, propertyPath, type, null, null, null, collection2);
							}
						}
					}
					return null;
				}
				propertyPersistenceInfo = _settings.IgnorePropertySettings.GetPropertyPersistenceInfo(pi, propertyPath);
				if (propertyPersistenceInfo != null)
				{
					if (value != null && _objectStore.ContainsKey(value))
					{
						int key2 = _objectStore[value];
						if (!_propDataStore.ContainsKey(key2))
						{
							_objectStore.Remove(value);
						}
					}
					return null;
				}
			}
			SavePropertyPersistenceEventArgs e = new SavePropertyPersistenceEventArgs(_rootObject, pi, propertyPath, value);
			_settings.Events.OnSavePropertyPersistence(e);
			_group.Events.OnSavePropertyPersistence(e);
			if (e.Cancel)
			{
				if (value != null && _objectStore.ContainsKey(value))
				{
					int key3 = _objectStore[value];
					if (value != null && !_propDataStore.ContainsKey(key3))
					{
						_objectStore.Remove(value);
					}
				}
				return null;
			}
			if (!string.IsNullOrEmpty(e.SaveValue))
			{
				return CreateAndStorePropertyData(value, text, propertyPath, type, null, e.SaveValue, null, null);
			}
			if (!string.IsNullOrEmpty(e.Identifier))
			{
				return CreateAndStorePropertyData(value, text, propertyPath, type, e.Identifier, null, null, null);
			}
			value = e.Value;
			if (value != null)
			{
				StoreProperty(value, null);
				DependencyObject obj = value as DependencyObject;
				if (obj != null)
				{
					string identifier = GetIdentifier(obj);
					if (!string.IsNullOrEmpty(identifier))
					{
						return CreateAndStorePropertyData(value, text, propertyPath, type, identifier, null, null, null);
					}
				}
				if (TypesToIgnore.Contains(type) || (isNotPublic && !typeof(Type).IsAssignableFrom(type)))
				{
					int key4 = _objectStore[value];
					if (!_propDataStore.ContainsKey(key4))
					{
						_objectStore.Remove(value);
					}
					return null;
				}
				IProvideCustomPersistence provideCustomPersistence = value as IProvideCustomPersistence;
				if (provideCustomPersistence != null)
				{
					return CreateAndStorePropertyData(value, text, propertyPath, type, null, provideCustomPersistence.Save(), null, null);
				}
				bool flag = false;
				bool flag2 = false;
				string text2 = null;
				string converterTypeName = null;
				if (PredefinedTypeConverters.ContainsKey(type))
				{
					TypeConverter typeConverter = PredefinedTypeConverters[type];
					text2 = typeConverter.ConvertToString(value);
					flag2 = (flag = true);
					converterTypeName = typeConverter.GetType().FullName;
				}
				else
				{
					object[] array = ((pi != null) ? pi.GetCustomAttributes(typeof(TypeConverterAttribute), inherit: true) : null);
					if (array == null || array.Length == 0)
					{
						array = type.GetCustomAttributes(typeof(TypeConverterAttribute), inherit: true);
					}
					object[] array2 = array;
					for (int num = 0; num < array2.Length; num++)
					{
						TypeConverterAttribute typeConverterAttribute = (TypeConverterAttribute)array2[num];
						TypeConverter typeConverter2 = Type.GetType(typeConverterAttribute.ConverterTypeName).GetConstructor(new Type[0]).Invoke(null) as TypeConverter;
						typeConverter2.GetType();
						if (typeConverter2.CanConvertTo(typeof(string)))
						{
							flag = true;
							try
							{
								text2 = typeConverter2.ConvertToString(value);
							}
							catch
							{
								return null;
							}
						}
						if (typeConverter2.CanConvertFrom(typeof(string)))
						{
							converterTypeName = typeConverterAttribute.ConverterTypeName;
							flag2 = true;
						}
						try
						{
							if (flag2)
							{
								if (text2 == null)
								{
									flag = false;
									break;
								}
								typeConverter2.ConvertFromString(text2);
							}
						}
						catch (Exception)
						{
							flag = false;
						}
					}
				}
				IEnumerable enumerable2 = value as IEnumerable;
				if (flag2 && flag)
				{
					return CreateAndStorePropertyData(value, text, propertyPath, type, null, text2, converterTypeName, null);
				}
				if (enumerable2 != null && value.GetType() != typeof(string))
				{
					Collection<PropertyDataInfo> collection3 = new Collection<PropertyDataInfo>();
					foreach (object item2 in enumerable2)
					{
						PropertyDataInfo propertyDataInfo2 = SaveProperty(propertyPath + "[]", item2, null, validateAgainstIgnore: false);
						if (propertyDataInfo2 == null)
						{
							if (value != null && _objectStore.ContainsKey(value))
							{
								int key5 = _objectStore[value];
								if (!_propDataStore.ContainsKey(key5))
								{
									_objectStore.Remove(value);
								}
							}
							return null;
						}
						collection3.Add(propertyDataInfo2);
					}
					Collection<string> lookupKeys2 = null;
					IProvidePersistenceLookupKeys lookupKeyProvider2 = GetLookupKeyProvider(enumerable2);
					if (lookupKeyProvider2 != null)
					{
						lookupKeys2 = lookupKeyProvider2.GetLookupKeys();
					}
					return CreateAndStorePropertyData(value, text, propertyPath, type, null, false, null, null, collection3, lookupKeys2);
				}
				if (isValueType || isEnum)
				{
					bool flag3 = true;
					PropertyInfo property = type.GetProperty("IsEmpty");
					if (property != null)
					{
						object value3 = property.GetValue(value, null);
						if (value3 != null)
						{
							flag3 = !(bool)value3;
						}
					}
					if (flag3)
					{
						return CreateAndStorePropertyData(value, text, propertyPath, type, null, true, null, null, null);
					}
				}
				else
				{
					if (value is string || isPrimitive || value is Color)
					{
						return CreateAndStorePropertyData(value, text, propertyPath, type, null, value.ToString(), null, null);
					}
					if (type.GetConstructor(new Type[0]) != null)
					{
						string stringValue = "";
						Collection<PropertyDataInfo> collection4 = BuildPropertyTree(propertyPath, value, validateAgainstIgnore: false);
						if (collection4 == null || collection4.Count == 0)
						{
							stringValue = value.ToString();
						}
						return CreateAndStorePropertyData(value, text, propertyPath, type, null, stringValue, null, collection4);
					}
					if (value is Type)
					{
						return CreateAndStorePropertyData(value, text, propertyPath, typeof(Type), null, ((Type)value).AssemblyQualifiedName, null, null);
					}
				}
			}
			else if (pi != null)
			{
				return CreateAndStorePropertyData(null, text, propertyPath, pi.PropertyType, null, null, null, null);
			}
			if (value != null && _objectStore.ContainsKey(value))
			{
				int key6 = _objectStore[value];
				if (!_propDataStore.ContainsKey(key6))
				{
					_objectStore.Remove(value);
				}
			}
			return null;
		}

		private List<int> _allowableKeys = new List<int>();

		private class AssemblyLoadInfo
		{
			internal static readonly string Infragistics_Literal = "Infragistics";

			internal Version _assemblyVersion;

			internal string _infragisticsWithPlatformSuffix;

			internal string _infragisticsSuffix;

			internal string _platformVersionSuffix;

			internal string _versionSuffix;

			internal AssemblyLoadInfo()
			{
				string assemblyQualifiedName = typeof(AssemblyLoadInfo).AssemblyQualifiedName;
				int startIndex = assemblyQualifiedName.IndexOf(", ") + 2;
				string assemblyName = assemblyQualifiedName.Substring(startIndex);
				_assemblyVersion = new AssemblyName(assemblyName).Version;
				_infragisticsSuffix = "WPF";
				_infragisticsWithPlatformSuffix = Infragistics_Literal + _infragisticsSuffix;
				_platformVersionSuffix = string.Empty;
				_versionSuffix = string.Empty;
			}
		}

		private class LookupKeyProxy : IProvidePersistenceLookupKeys
		{
			private IList _source;

			internal LookupKeyProxy(IList source)
			{
				_source = source;
			}

			public bool CanRehydrate(Collection<string> lookupKeys)
			{
				if (lookupKeys.Count > _source.Count)
				{
					return false;
				}
				HashSet<string> hashSet = new HashSet<string>();
				for (int i = 0; i < lookupKeys.Count; i++)
				{
					string item = lookupKeys[i];
					if (hashSet.Contains(item))
					{
						return false;
					}
					hashSet.Add(item);
				}
				int num = -1;
				int num2 = 0;
				Dictionary<string, object> dictionary = null;
				for (int j = 0; j < _source.Count; j++)
				{
					DependencyObject dependencyObject = _source[j] as DependencyObject;
					if (dependencyObject == null)
					{
						if (num < 0)
						{
							num = j;
						}
						continue;
					}
					string identifier = GetIdentifier(dependencyObject);
					if (identifier == null || !hashSet.Contains(identifier))
					{
						if (num < 0)
						{
							num = j;
						}
						continue;
					}
					num2++;
					if (dictionary == null)
					{
						dictionary = new Dictionary<string, object>();
					}
					if (dictionary.ContainsKey(identifier))
					{
						return false;
					}
					dictionary[identifier] = dependencyObject;
					if (num < 0 && ((j < lookupKeys.Count) ? lookupKeys[j] : null) != identifier)
					{
						num = j;
					}
				}
				if (num2 != lookupKeys.Count)
				{
					return false;
				}
				if (num >= 0)
				{
					if (_source.IsReadOnly)
					{
						return false;
					}
					for (int k = num; k < lookupKeys.Count; k++)
					{
						string key = lookupKeys[k];
						object value;
						if (!dictionary.TryGetValue(key, out value))
						{
							return false;
						}
						int num3 = _source.IndexOf(value);
						if (num3 != k)
						{
							if (num3 < k)
							{
								return false;
							}
							_source.RemoveAt(num3);
							_source.Insert(k, value);
						}
					}
				}
				return true;
			}

			public Collection<string> GetLookupKeys()
			{
				Collection<string> collection = new Collection<string>();
				foreach (object item in _source)
				{
					DependencyObject obj = item as DependencyObject;
					if (obj != null)
					{
						string identifier = GetIdentifier(obj);
						collection.Add(identifier);
					}
				}
				return collection;
			}
		}

		private PropertyDataInfo CreateAndStorePropertyData(object value, string propertyName, string propertyPath, Type t, string id, string stringValue, string converterTypeName, Collection<PropertyDataInfo> props)
		{
			return CreateAndStorePropertyData(value, propertyName, propertyPath, t, id, false, stringValue, converterTypeName, props);
		}

		private PropertyDataInfo CreateAndStorePropertyData(object value, string propertyName, string propertyPath, Type t, string id, bool storeValue, string stringValue, string converterTypeName, Collection<PropertyDataInfo> props)
		{
			return CreateAndStorePropertyData(value, propertyName, propertyPath, t, id, storeValue, stringValue, converterTypeName, props, null);
		}

		private PropertyDataInfo CreateAndStorePropertyData(object value, string propertyName, string propertyPath, Type t, string id, bool storeValue, string stringValue, string converterTypeName, Collection<PropertyDataInfo> props, Collection<string> lookupKeys)
		{
			IProvideCustomStorage provideCustomStorage = value as IProvideCustomStorage;
			string customStorage = ((provideCustomStorage != null) ? provideCustomStorage.Save() : null);
			PropertyData propertyData = new PropertyData
			{
				AssemblyTypeKey = StoreType(t),
				Identifier = id,
				StringValue = stringValue,
				ConverterTypeName = converterTypeName,
				Properties = props,
				LookUpKeys = lookupKeys,
				CustomStorage = customStorage
			};
			if (storeValue)
			{
				propertyData.Value = value;
				if (!ValueTypes.Contains(t))
				{
					ValueTypes.Add(t);
				}
			}
			return new PropertyDataInfo
			{
				PropertyName = propertyName,
				PropertyPath = propertyPath,
				DataKey = StoreProperty(value, propertyData)
			};
		}

		private int StoreProperty(object data, PropertyData propData)
		{
			if (data == null)
			{
				data = propData;
			}
			int num = _objectStore.Count;
			if (_objectStore.ContainsKey(data))
			{
				num = _objectStore[data];
			}
			else
			{
				_objectStore.Add(data, num);
			}
			if (propData != null && !_propDataStore.ContainsKey(num))
			{
				_propDataStore.Add(num, propData);
			}
			return num;
		}

		internal int StoreType(Type t)
		{
			string assemblyQualifiedName = t.AssemblyQualifiedName;
			int hashCode = assemblyQualifiedName.GetHashCode();
			if (!_typeStore.ContainsKey(hashCode))
			{
				_typeStore.Add(hashCode, assemblyQualifiedName);
			}
			return hashCode;
		}

		private void UnloadPropertyTree(object owner, Collection<PropertyDataInfo> propertyTree, bool validateAgainstIgnore)
		{
			IProvidePropertyPersistenceSettings providePropertyPersistenceSettings = owner as IProvidePropertyPersistenceSettings;
			IProvideCustomObjectPersistence provideCustomObjectPersistence = owner as IProvideCustomObjectPersistence;
			foreach (PropertyDataInfo item in propertyTree)
			{
				if (provideCustomObjectPersistence != null && item.PropertyPath == "PersistenceCustomObject")
				{
					provideCustomObjectPersistence.LoadObject(LoadProperty(owner, item, validateAgainstIgnore: false));
				}
				else
				{
					LoadProperty(owner, item, validateAgainstIgnore);
				}
			}
			if (providePropertyPersistenceSettings != null)
			{
				providePropertyPersistenceSettings.FinishedLoadingPersistence();
			}
		}

		private void SetProperty(PropertyInfo pi, object owner, object propertyValue, Collection<PropertyDataInfo> props)
		{
			if (pi != null)
			{
				if (pi.GetSetMethod() != null)
				{
					object value = pi.GetValue(owner, null);
					if (value != propertyValue)
					{
						if (value != null)
						{
							if (!value.Equals(propertyValue))
							{
								pi.SetValue(owner, propertyValue, null);
							}
						}
						else
						{
							pi.SetValue(owner, propertyValue, null);
						}
					}
					else if (propertyValue is Style)
					{
						pi.SetValue(owner, null, null);
						pi.SetValue(owner, propertyValue, null);
					}
				}
				else
				{
					object value2 = pi.GetValue(owner, null);
					if (value2 != null)
					{
						UnloadPropertyTree(value2, props, validateAgainstIgnore: false);
					}
				}
			}
		}

		private PropertyData ResolvePropertyData(int key)
		{
			if (_propDataStore.ContainsKey(key))
			{
				return _propDataStore[key];
			}
			return null;
		}

		private object LoadProperty(object owner, PropertyDataInfo dataInfo, bool validateAgainstIgnore)
		{
			bool validateAgainstIgnore2 = false;
			bool flag = false;
			bool flag2 = false;
			int dataKey = dataInfo.DataKey;
			object obj = null;
			if (_reverseObjectStore.ContainsKey(dataKey))
			{
				obj = _reverseObjectStore[dataKey];
				flag = true;
			}
			PropertyInfo propertyInfo = null;
			if (owner != null)
			{
				propertyInfo = owner.GetType().GetProperty(dataInfo.PropertyName);
			}
			PropertyData propertyData = ResolvePropertyData(dataInfo.DataKey);
			if (propertyInfo != null)
			{
				if ((propertyInfo.CanRead && propertyInfo.GetGetMethod() != null && propertyInfo.GetGetMethod().IsStatic) || (propertyInfo.CanWrite && propertyInfo.GetSetMethod() != null && propertyInfo.GetSetMethod().IsStatic))
				{
					return null;
				}
				if (propertyData != null)
				{
					if (propertyData.Identifier == null && propertyData.LookUpKeys != null && propertyData.LookUpKeys.Count == 0 && propertyData.Properties.Count == 0 && propertyData.StringValue == null && propertyData.Value == null && propertyInfo.PropertyType.GetInterface("System.Collections.IEnumerable", ignoreCase: true) == null)
					{
						SetProperty(propertyInfo, owner, null, propertyData.Properties);
						return null;
					}
				}
				else
				{
					return null;
				}
			}
			PersistenceOption loadPersistenceOptions = _settings.LoadPersistenceOptions;
			PropertyPersistenceInfoBase propertyPersistenceInfo = _settings.PropertySettings.GetPropertyPersistenceInfo(propertyInfo, dataInfo.PropertyPath);
			if (propertyPersistenceInfo != null)
			{
				if (!string.IsNullOrEmpty(propertyData.StringValue))
				{
					obj = propertyPersistenceInfo.LoadObjectFromString(propertyInfo, dataInfo.PropertyPath, propertyData.StringValue);
				}
				if (obj == null && propertyPersistenceInfo.TypeConverter != null && propertyPersistenceInfo.TypeConverter.CanConvertFrom(typeof(string)))
				{
					obj = propertyPersistenceInfo.TypeConverter.ConvertFromString(propertyData.StringValue);
					flag2 = true;
				}
			}
			else if (loadPersistenceOptions == PersistenceOption.OnlySpecified && validateAgainstIgnore)
			{
				if (!_allowableKeys.Contains(dataInfo.DataKey))
				{
					List<int> list = CheckForPropertiesThatMatch(propertyData);
					if (list != null && list.Count > 0)
					{
						_allowableKeys.AddRange(list);
						_allowableKeys.Add(dataInfo.DataKey);
					}
				}
				validateAgainstIgnore2 = true;
				if (!_allowableKeys.Contains(dataInfo.DataKey))
				{
					return null;
				}
			}
			else
			{
				propertyPersistenceInfo = _settings.IgnorePropertySettings.GetPropertyPersistenceInfo(propertyInfo, dataInfo.PropertyPath);
				if (propertyPersistenceInfo != null)
				{
					return null;
				}
			}
			LoadPropertyPersistenceEventArgs e = new LoadPropertyPersistenceEventArgs(_rootObject, propertyInfo, dataInfo.PropertyPath, propertyData.StringValue, propertyData.Identifier, owner, propertyData.Value);
			_settings.Events.OnLoadPropertyPersistence(e);
			_group.Events.OnLoadPropertyPersistence(e);
			if (e.Handled)
			{
				return null;
			}
			if (e.LoadedValue != null)
			{
				obj = e.LoadedValue;
				flag2 = true;
			}
			if (obj == null)
			{
				bool flag3 = false;
				if (propertyData.Value != null)
				{
					obj = propertyData.Value;
				}
				else if (!string.IsNullOrEmpty(propertyData.Identifier))
				{
					if (Application.Current != null)
					{
						obj = Application.Current.Resources[propertyData.Identifier];
					}
				}
				else if (!string.IsNullOrEmpty(propertyData.StringValue))
				{
					if (!string.IsNullOrEmpty(propertyData.ConverterTypeName))
					{
						Type type = Type.GetType(propertyData.ConverterTypeName);
						if (type == null)
						{
							type = FixAssemblyQualifiedName(propertyData.ConverterTypeName);
							if (type == null)
							{
								type = GetTypeFromSerializedName(propertyData.ConverterTypeName);
							}
						}
						if (type != null)
						{
							TypeConverter typeConverter = type.GetConstructor(new Type[0]).Invoke(null) as TypeConverter;
							if (typeConverter.CanConvertFrom(typeof(string)))
							{
								obj = typeConverter.ConvertFrom(null, CultureInfo.CurrentCulture, propertyData.StringValue);
								flag2 = true;
							}
						}
					}
					else
					{
						try
						{
							Type type2 = ResolveType(propertyData.AssemblyTypeKey);
							if (type2 == typeof(Type))
							{
								obj = Type.GetType(propertyData.StringValue);
							}
							else
							{
								obj = Convert.ChangeType(propertyData.StringValue, type2, CultureInfo.CurrentCulture);
							}
						}
						catch (InvalidCastException)
						{
							flag3 = true;
						}
					}
				}
				if (!flag3 && obj != null)
				{
					if (!_reverseObjectStore.ContainsKey(dataKey))
					{
						_reverseObjectStore.Add(dataKey, obj);
					}
					IProvideCustomPersistence provideCustomPersistence = obj as IProvideCustomPersistence;
					if (provideCustomPersistence != null)
					{
						provideCustomPersistence.Load(owner, propertyData.StringValue);
					}
					else
					{
						UnloadPropertyTree(obj, propertyData.Properties, validateAgainstIgnore2);
					}
				}
				else
				{
					object obj2 = null;
					if (owner != null && !string.IsNullOrEmpty(dataInfo.PropertyName))
					{
						PropertyInfo property = owner.GetType().GetProperty(dataInfo.PropertyName);
						if (property != null)
						{
							obj2 = property.GetValue(owner, null);
						}
					}
					bool flag4 = true;
					IProvidePersistenceLookupKeys lookupKeyProvider = GetLookupKeyProvider(obj2);
					if (lookupKeyProvider != null && lookupKeyProvider.CanRehydrate(propertyData.LookUpKeys))
					{
						flag4 = false;
						obj = obj2;
						IEnumerable obj3 = (IEnumerable)obj;
						int num = 0;
						foreach (object item in obj3)
						{
							if (num >= propertyData.Properties.Count)
							{
								if (!(lookupKeyProvider is LookupKeyProxy))
								{
									flag4 = true;
								}
								break;
							}
							PropertyDataInfo propertyDataInfo = propertyData.Properties[num];
							if (!_reverseObjectStore.ContainsKey(propertyDataInfo.DataKey))
							{
								PropertyData propertyData2 = ResolvePropertyData(propertyDataInfo.DataKey);
								_reverseObjectStore.Add(propertyDataInfo.DataKey, item);
								IProvideCustomPersistence provideCustomPersistence2 = item as IProvideCustomPersistence;
								if (provideCustomPersistence2 != null)
								{
									provideCustomPersistence2.Load(owner, propertyData2.StringValue);
								}
								else
								{
									UnloadPropertyTree(item, propertyData2.Properties, validateAgainstIgnore2);
								}
							}
							num++;
						}
						if (!flag4)
						{
							return obj;
						}
					}
					if (flag4)
					{
						Type type3 = ResolveType(propertyData.AssemblyTypeKey);
						if (obj2 != null && !(obj2 is Brush) && obj2.GetType() == type3)
						{
							obj = obj2;
						}
						else if (type3 != typeof(object) && type3 != null && !TypesToIgnore.Contains(type3))
						{
							ConstructorInfo constructor = type3.GetConstructor(new Type[0]);
							if (constructor != null)
							{
								obj = constructor.Invoke(new object[0]);
								INeedInitializationForPersistence needInitializationForPersistence = obj as INeedInitializationForPersistence;
								if (needInitializationForPersistence != null)
								{
									needInitializationForPersistence.InitObject(_rootObject);
								}
							}
						}
						if (obj != null)
						{
							if (!_reverseObjectStore.ContainsKey(dataKey))
							{
								_reverseObjectStore.Add(dataKey, obj);
							}
							IProvideCustomPersistence provideCustomPersistence3 = obj as IProvideCustomPersistence;
							if (provideCustomPersistence3 != null)
							{
								provideCustomPersistence3.Load(owner, propertyData.StringValue);
							}
							else
							{
								UnloadPropertyTree(obj, propertyData.Properties, validateAgainstIgnore2);
							}
						}
					}
				}
			}
			if (propertyInfo != null)
			{
				try
				{
					if (propertyInfo.GetSetMethod() == null && propertyInfo.PropertyType.GetInterface("IList", ignoreCase: true) != null)
					{
						if (!flag)
						{
							object value = propertyInfo.GetValue(owner, null);
							IProvideCustomPersistence provideCustomPersistence4 = value as IProvideCustomPersistence;
							if (provideCustomPersistence4 != null)
							{
								provideCustomPersistence4.Load(owner, propertyData.StringValue);
							}
else
{
	IList list2 = value as IList;
	if (list2 != null && !list2.IsReadOnly)
	{
								if (!_reverseObjectStore.ContainsKey(dataKey))
								{
									_reverseObjectStore.Add(dataKey, list2);
								}
								if (!flag2)
								{
									if (!list2.IsReadOnly)
									{
										list2.Clear();
										foreach (PropertyDataInfo property2 in propertyData.Properties)
										{
											object value2 = LoadProperty(null, property2, validateAgainstIgnore2);
											list2.Add(value2);
										}
									}
								}
								else
								{
									IList list3 = obj as IList;
									if (list3 != null)
									{
										foreach (object item2 in list3)
										{
											list2.Add(item2);
										}
									}
								}
							}
}
						}
					}
					else if (obj != null)
					{
						if (!_reverseObjectStore.ContainsKey(dataKey))
						{
							_reverseObjectStore.Add(dataKey, obj);
						}
						IList list4 = obj as IList;
						if (list4 != null && !flag)
						{
							if (!flag2)
							{
								list4.Clear();
								foreach (PropertyDataInfo property3 in propertyData.Properties)
								{
									object value3 = LoadProperty(null, property3, validateAgainstIgnore2);
									list4.Add(value3);
								}
							}
							SetProperty(propertyInfo, owner, list4, propertyData.Properties);
						}
						else
						{
							SetProperty(propertyInfo, owner, obj, propertyData.Properties);
						}
					}
					else
					{
						SetProperty(propertyInfo, owner, obj, propertyData.Properties);
					}
				}
				catch (Exception ex2)
				{
					_exceptions.Add(new PropertyPersistenceExceptionDetails(ex2, propertyInfo, dataInfo.PropertyPath));
				}
			}
			IProvideCustomStorage provideCustomStorage = obj as IProvideCustomStorage;
			if (provideCustomStorage != null && propertyData != null)
			{
				provideCustomStorage.Load(propertyData.CustomStorage);
			}
			return obj;
		}

		private static IProvidePersistenceLookupKeys GetLookupKeyProvider(object currentValue)
		{
			IProvidePersistenceLookupKeys providePersistenceLookupKeys = currentValue as IProvidePersistenceLookupKeys;
			if (providePersistenceLookupKeys == null && currentValue is IList && !(currentValue is string))
			{
				int num = 0;
				foreach (object item in (ICollection)currentValue)
				{
					DependencyObject obj = item as DependencyObject;
					if (obj == null)
					{
						return null;
					}
					if (GetIdentifier(obj) == null)
					{
						return null;
					}
					num++;
				}
				if (num == 0)
				{
					return null;
				}
				return new LookupKeyProxy(currentValue as IList);
			}
			return providePersistenceLookupKeys;
		}

		internal Type ResolveType(int key)
		{
			return Type.GetType(_typeStore[key]);
		}

		private List<int> CheckForPropertiesThatMatch(PropertyData data)
		{
			List<int> list = null;
			Type type = ResolveType(data.AssemblyTypeKey);
			if (data.Properties != null && data.Properties.Count > 0)
			{
				if (type.GetInterface("System.Collections.IEnumerable", ignoreCase: true) != null)
				{
					foreach (PropertyDataInfo property2 in data.Properties)
					{
						if (_settings.PropertySettings.GetPropertyPersistenceInfo(null, property2.PropertyPath) != null)
						{
							if (list == null)
							{
								list = new List<int>();
							}
							list.Add(property2.DataKey);
							continue;
						}
						PropertyData propertyData = ResolvePropertyData(property2.DataKey);
						if (propertyData == null)
						{
							continue;
						}
						List<int> list2 = CheckForPropertiesThatMatch(propertyData);
						if (list2 != null)
						{
							if (list == null)
							{
								list = new List<int>();
							}
							list.AddRange(list2);
							list.Add(property2.DataKey);
						}
					}
				}
				else
				{
					foreach (PropertyDataInfo property3 in data.Properties)
					{
						PropertyInfo property = type.GetProperty(property3.PropertyName);
						if (!(property != null))
						{
							continue;
						}
						if (_settings.PropertySettings.GetPropertyPersistenceInfo(property, property3.PropertyPath) != null)
						{
							if (list == null)
							{
								list = new List<int>();
							}
							list.Add(property3.DataKey);
							continue;
						}
						PropertyData propertyData2 = ResolvePropertyData(property3.DataKey);
						if (propertyData2 == null)
						{
							continue;
						}
						List<int> list3 = CheckForPropertiesThatMatch(propertyData2);
						if (list3 != null)
						{
							if (list == null)
							{
								list = new List<int>();
							}
							list.AddRange(list3);
							list.Add(property3.DataKey);
						}
					}
				}
			}
			return list;
		}
	

		public Dictionary<int, PropertyData> PropertyDataStore
		{
			get
			{
				return _propDataStore;
			}
			set
			{
				_propDataStore = value;
			}
		}

		public Collection<Type> ValueTypes
		{
			get
			{
				return _valueTypes;
			}
		}

		internal List<PropertyPersistenceExceptionDetails> Exceptions
		{
			get
			{
				return _exceptions;
			}
		}
}
	public class PersistenceSettings : DependencyObject
	{
		private PropertyPersistenceInfoBaseCollection _propertySettings;

		private PropertyPersistenceInfoBaseCollection _ignorePropertySettings;

		private PersistenceEvents _events;

		public PersistenceOption SavePersistenceOptions { get; set; }

		public PersistenceOption LoadPersistenceOptions { get; set; }

		public PropertyPersistenceInfoBaseCollection PropertySettings
		{
			get
			{
				if (_propertySettings == null)
				{
					_propertySettings = new PropertyPersistenceInfoBaseCollection();
				}
				return _propertySettings;
			}
		}

		public PropertyPersistenceInfoBaseCollection IgnorePropertySettings
		{
			get
			{
				if (_ignorePropertySettings == null)
				{
					_ignorePropertySettings = new PropertyPersistenceInfoBaseCollection();
				}
				return _ignorePropertySettings;
			}
		}

		public PersistenceEvents Events
		{
			get
			{
				if (_events == null)
				{
					_events = new PersistenceEvents();
				}
				return _events;
			}
			set
			{
				_events = value;
			}
		}
	}
	public class PropertyPersistenceExceptionDetails
	{
public PropertyPersistenceExceptionDetails(Exception ex, PropertyInfo pi, string path)
		{
			Exception = ex;
			PropertyInfo = pi;
			PropertyPath = path;
		}

public PropertyInfo PropertyInfo { get; private set; }

public string PropertyPath { get; private set; }

public Exception Exception { get; private set; }
}
	public class PropertyPersistenceInfoBaseCollection : ObservableCollection<PropertyPersistenceInfoBase>
	{
		public PropertyPersistenceInfoBase GetPropertyPersistenceInfo(PropertyInfo pi, string propertyPath)
		{
			using (IEnumerator<PropertyPersistenceInfoBase> enumerator = GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					PropertyPersistenceInfoBase current = enumerator.Current;
					if (current.DoesPropertyMeetCriteria(pi, propertyPath))
					{
						return current;
					}
				}
			}
			return null;
		}
	}
	public class PropertyNamePersistenceInfo : PropertyPersistenceInfoBase
	{
public PropertyNamePersistenceInfo()
		{
			Options = PropertyNamePersistenceOptions.Contains;
		}

public string PropertyName { get; set; }

public PropertyNamePersistenceOptions Options { get; set; }

public override bool DoesPropertyMeetCriteria(PropertyInfo pi, string propertyPath)
		{
			if (pi != null && Options == PropertyNamePersistenceOptions.PropertyName)
			{
				return pi.Name == PropertyName;
			}
			if (Options == PropertyNamePersistenceOptions.PropertyPath)
			{
				return PropertyName == propertyPath;
			}
			if (Options == PropertyNamePersistenceOptions.Contains)
			{
				return propertyPath.Contains(PropertyName);
			}
			return false;
		}
}
	public abstract class PropertyPersistenceInfoBase
	{
[EditorBrowsable(EditorBrowsableState.Never)]
		public string Identifier { get; set; }
public string SaveValue { get; set; }

public TypeConverter TypeConverter { get; set; }

public abstract bool DoesPropertyMeetCriteria(PropertyInfo pi, string propertyPath);

public virtual string SaveValueToString(PropertyInfo pi, string propertyPath, object value)
		{
			return null;
		}

public virtual object LoadObjectFromString(PropertyInfo pi, string propertyPath, string value)
		{
			return null;
		}

}
	public class PropertyTypePersistenceInfo : PropertyPersistenceInfoBase
	{
		public Type PropertyType { get; set; }

		public override bool DoesPropertyMeetCriteria(PropertyInfo pi, string propertyPath)
		{
			if (pi != null)
			{
				return pi.PropertyType == PropertyType;
			}
			return false;
		}
	}
	public class DurationTypeConverter : TypeConverter
	{
		public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
		{
			return sourceType == typeof(string);
		}

		public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
		{
			return destinationType == typeof(string);
		}

		public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
		{
			string text = (string)value;
			if (text != null && text.Length > 0)
			{
				return new Duration(TimeSpan.Parse(text));
			}
			return ' ';
		}

		public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
		{
			if (value != null)
			{
				return ((Duration)value).TimeSpan.ToString();
			}
			return null;
		}
	}
	public class RepeatBehaviorTypeConverter : TypeConverter
	{
		public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
		{
			return sourceType == typeof(string);
		}

		public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
		{
			return destinationType == typeof(string);
		}

		public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
		{
			string text = (string)value;
			if (text == "Forever")
			{
				return RepeatBehavior.Forever;
			}
			string[] array = text.Split(':');
			if (array.Length == 2)
			{
				if (array[0] == "D")
				{
					return new RepeatBehavior(TimeSpan.Parse(array[1]));
				}
				if (array[0] == "C")
				{
					return new RepeatBehavior(double.Parse(array[1]));
				}
			}
			return null;
		}

		public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
		{
			if (value != null)
			{
				RepeatBehavior repeatBehavior = (RepeatBehavior)value;
				if (repeatBehavior.HasDuration)
				{
					return "D:" + repeatBehavior.Duration.ToString();
				}
				if (repeatBehavior.HasCount)
				{
					return "C:" + repeatBehavior.Count;
				}
				return "Forever";
			}
			return null;
		}
	}
	public class TimeSpanTypeConverter : TypeConverter
	{
		public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
		{
			return sourceType == typeof(string);
		}

		public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
		{
			return destinationType == typeof(string);
		}

		public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
		{
			string text = (string)value;
			if (text != null && text.Length > 0)
			{
				return TimeSpan.Parse(text);
			}
			return ' ';
		}

		public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
		{
			if (value != null)
			{
				return ((TimeSpan)value/*cast due to .constrained prefix*/).ToString();
			}
			return null;
		}
	}
}
namespace Infragistics.Persistence.Primitives
{
	public enum PersistenceOption
	{
		AllButIgnored,
		OnlySpecified
	}
	public enum PropertyNamePersistenceOptions
	{
		PropertyName,
		PropertyPath,
		Contains
	}
	public class ElementData
	{
		public Collection<PropertyDataInfo> PropertyTree { get; set; }

		public Collection<PropertyDataPair> PropDataStore { get; set; }

		public int TypeLookupKey { get; set; }
	}
	public class GroupData
	{
		public Collection<TypeDataPair> TypeStore { get; set; }

		public Collection<ElementData> Elements { get; set; }
	}
	public class PersistenceObject
	{
		public string Xml { get; set; }

		public Collection<string> Types { get; set; }
	}
	public class PropertyData
	{
public PropertyData()
		{
			LookUpKeys = new Collection<string>();
			Properties = new Collection<PropertyDataInfo>();
		}

public string ConverterTypeName { get; set; }

public int AssemblyTypeKey { get; set; }

public object Value { get; set; }

public string StringValue { get; set; }

public string CustomStorage { get; set; }

public Collection<string> LookUpKeys { get; set; }

public Collection<PropertyDataInfo> Properties { get; set; }

public string Identifier { get; set; }
}
	public class PropertyDataInfo
	{
		public string PropertyName { get; set; }

		public string PropertyPath { get; set; }

		public int DataKey { get; set; }
	}
	public class PropertyDataPair
	{
		public int LookupKey { get; set; }

		public PropertyData Data { get; set; }
	}
	public class TypeDataPair
	{
		public int LookupKey { get; set; }

		public string TypeName { get; set; }
	}
}
