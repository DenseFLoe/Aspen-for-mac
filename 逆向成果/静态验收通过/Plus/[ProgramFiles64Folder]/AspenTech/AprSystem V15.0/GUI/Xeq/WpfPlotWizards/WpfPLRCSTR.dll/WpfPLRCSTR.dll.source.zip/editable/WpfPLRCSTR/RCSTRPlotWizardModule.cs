using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLRCSTR;

[RibbonPlotWizardMgr("WpfPLRCSTR.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class RCSTRPlotWizardModule : PlotModuleBase
{
}
