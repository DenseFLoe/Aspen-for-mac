using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLCompr;

[RibbonPlotWizardMgr("WpfPLCOMPR.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class ComprPlotWizardModule : PlotModuleBase
{
}
