using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;

namespace WpfPLCfuge;

[ProgId("WpfPLCfuge.RibbonPlotWizardMgr")]
public class RibbonPlotWizardMgr : IRibbonPlotWizardMgr
{
	private static string[] supportedTypes = new string[1] { "Residual Moisture" };

	private IHNode _hnode;

	private IHWizardPlot _wizardPlot;

	private static List<PWRPlotType> _lspwrTypes = new List<PWRPlotType>();

	private PWRParser _pwrParser = new PWRParser();

	private Assembly _asm;

	private Dictionary<string, IRibbonPlotWizardType> _dicTagIdToPlotType;

	private IHWizardPlot _tempWizard = (CHWizardPlot)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("9E14C11F-6706-4067-8112-35CE9468F3A5")));

	public RibbonPlotWizardMgr()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		Initialize();
	}

	long IRibbonPlotWizardMgr.SupportedPlotTypes(ref List<string> lsTagIds)
	{
		lsTagIds.Clear();
		for (int i = 0; i < _lspwrTypes.Count; i++)
		{
			PWRPlotType val = _lspwrTypes[i];
			IRibbonPlotWizardType iplotType = null;
			_tempWizard.Clear();
			_pwrParser.FillDefaultPlotVal(val, ref _hnode, ref _tempWizard);
			if (DoesPlotTypeHaveData(val.TagId, ref iplotType, ref _tempWizard))
			{
				lsTagIds.Add(val.TagId);
			}
		}
		return _lspwrTypes.Count;
	}

	long IRibbonPlotWizardMgr.GetPlotType(string sTagId, ref IRibbonPlotWizardType plwType)
	{
		if (_dicTagIdToPlotType.ContainsKey(sTagId))
		{
			plwType = _dicTagIdToPlotType[sTagId];
			if (plwType == null)
			{
				return 0L;
			}
			PWRPlotType val = null;
			_pwrParser.FindPlotType(sTagId, ref _lspwrTypes, ref val);
			_pwrParser.FillDefaultPlotVal(val, ref _hnode, ref _wizardPlot);
		}
		return 0L;
	}

	void IRibbonPlotWizardMgr.SetContext(object oNode, ref object oWizard)
	{
		_hnode = oNode as IHNode;
		_wizardPlot = oWizard as IHWizardPlot;
	}

	void IRibbonPlotWizardMgr.ShowInputDialog(string sPlotName)
	{
	}

	private void InitializeWizardPlot()
	{
	}

	private void Initialize()
	{
		_asm = Assembly.GetExecutingAssembly();
		StreamReader streamReader = new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLCfuge.Text.Cfugepwr.txt"));
		_lspwrTypes.Clear();
		_pwrParser.ParsePwrFile(streamReader, ref _lspwrTypes);
		_dicTagIdToPlotType = new Dictionary<string, IRibbonPlotWizardType>();
		string[] array = supportedTypes;
		foreach (string text in array)
		{
			if (text == supportedTypes[0])
			{
				IRibbonPlotWizardType value = new Moisture();
				_dicTagIdToPlotType.Add(text, value);
			}
		}
	}

	private bool DoesPlotTypeHaveData(string sTagId, ref IRibbonPlotWizardType iplotType, ref IHWizardPlot iWizardPlot)
	{
		int num = 0;
		if (_dicTagIdToPlotType.ContainsKey(sTagId))
		{
			iplotType = _dicTagIdToPlotType[sTagId];
			if (iplotType == null)
			{
				return false;
			}
			object obj = iWizardPlot;
			iplotType.Context((object)_hnode, ref obj, ref num);
			if (num == 0)
			{
				return true;
			}
		}
		return false;
	}
}
