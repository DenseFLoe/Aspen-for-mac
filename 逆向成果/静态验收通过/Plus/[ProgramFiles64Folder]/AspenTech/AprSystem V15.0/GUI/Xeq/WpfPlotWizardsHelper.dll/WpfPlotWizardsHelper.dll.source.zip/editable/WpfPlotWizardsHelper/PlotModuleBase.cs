using Microsoft.Practices.Composite.Modularity;

namespace WpfPlotWizardsHelper;

public abstract class PlotModuleBase : IModule
{
	public virtual void Initialize()
	{
	}
}
