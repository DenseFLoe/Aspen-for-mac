param(
    [Parameter(Mandatory)][string]$Original,
    [Parameter(Mandatory)][string]$Assembled,
    [Parameter(Mandatory)][string]$Final,
    [Parameter(Mandatory)][string]$Cecil,
    [Parameter(Mandatory)][string]$Report
)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Resolve-Path -LiteralPath $Cecil)
function Get-Scope($TypeRef) {
    if ($null -eq $TypeRef) { return '<nil>' }
    $scope = $TypeRef.Scope
    if ($scope -is [Mono.Cecil.AssemblyNameReference]) {
        return $scope.FullName
    }
    if ($scope -is [Mono.Cecil.ModuleDefinition]) {
        return $scope.Assembly.Name.FullName
    }
    return [string]$scope
}
function Get-TypeSignature($TypeRef) {
    if ($null -eq $TypeRef) { return '<nil>' }
    $outer = '[' + (Get-Scope $TypeRef) + ']' + $TypeRef.FullName
    if ($TypeRef -is [Mono.Cecil.GenericInstanceType]) {
        return $outer + '{' + (($TypeRef.GenericArguments | ForEach-Object { Get-TypeSignature $_ }) -join ',') + '}'
    }
    return $outer
}
function Get-MethodSignature($Method) {
    return Get-JsonKey @(
        $Method.FullName,
        (Get-TypeSignature $Method.DeclaringType),
        (Get-TypeSignature $Method.ReturnType),
        @($Method.Parameters | ForEach-Object { Get-TypeSignature $_.ParameterType }),
        [int]$Method.CallingConvention,
        $Method.HasThis,
        $Method.ExplicitThis
    )
}
function Get-JsonKey($Data) {
    return ConvertTo-Json -InputObject $Data -Depth 12 -Compress
}
function Get-CustomAttributes($Provider) {
    return @($Provider.CustomAttributes | ForEach-Object {
        (Get-MethodSignature $_.Constructor) + ':' + [Convert]::ToHexString($_.GetBlob())
    } | Sort-Object -CaseSensitive)
}
function Get-InstructionOperandSignature($Value) {
    if ($null -eq $Value) { return $null }
    if ($Value -is [Mono.Cecil.TypeReference]) { return 'type:' + (Get-TypeSignature $Value) }
    if ($Value -is [Mono.Cecil.MethodReference]) { return 'method:' + (Get-MethodSignature $Value) }
    if ($Value -is [Mono.Cecil.FieldReference]) {
        return 'field:' + $Value.FullName + ':' + (Get-TypeSignature $Value.DeclaringType) +
            ':' + (Get-TypeSignature $Value.FieldType)
    }
    if ($Value -is [Mono.Cecil.Cil.Instruction]) { return 'target:' + $Value.Offset }
    if ($Value -is [Mono.Cecil.Cil.Instruction[]]) {
        return 'targets:' + (($Value | ForEach-Object Offset) -join ',')
    }
    if ($Value -is [Mono.Cecil.ParameterDefinition]) { return 'argument:' + $Value.Index }
    if ($Value -is [Mono.Cecil.Cil.VariableDefinition]) { return 'local:' + $Value.Index }
    if ($Value -is [float]) { return 'float:' + [BitConverter]::SingleToInt32Bits($Value) }
    if ($Value -is [double]) { return 'double:' + [BitConverter]::DoubleToInt64Bits($Value) }
    return $Value
}
function Read-ModuleRecords($Path) {
    $module = [Mono.Cecil.ModuleDefinition]::ReadModule((Resolve-Path -LiteralPath $Path).Path)
    try {
        $types = @($module.GetTypes())
        $result = @{
            ref = @($module.AssemblyReferences.FullName | Sort-Object -CaseSensitive)
            type = @()
            method = @()
            body = @()
            eh = @()
            locals = @()
            field = @()
            property = @()
            event = @()
        }
        foreach ($type in $types) {
            $result.type += Get-JsonKey @($type.FullName, [int]$type.Attributes,
                (Get-TypeSignature $type.BaseType), $type.PackingSize, $type.ClassSize,
                @($type.Interfaces | ForEach-Object { Get-TypeSignature $_.InterfaceType }),
                @(Get-CustomAttributes $type))
            foreach ($field in $type.Fields) {
                $result.field += Get-JsonKey @($field.FullName, [int]$field.Attributes,
                    (Get-TypeSignature $field.FieldType), $field.Offset, $field.Constant,
                    @(Get-CustomAttributes $field))
            }
            foreach ($property in $type.Properties) {
                $result.property += Get-JsonKey @($property.FullName, [int]$property.Attributes,
                    (Get-TypeSignature $property.PropertyType), $property.GetMethod.FullName,
                    $property.SetMethod.FullName, @(Get-CustomAttributes $property))
            }
            foreach ($event in $type.Events) {
                $result.event += Get-JsonKey @($event.FullName, [int]$event.Attributes,
                    (Get-TypeSignature $event.EventType), $event.AddMethod.FullName, $event.RemoveMethod.FullName)
            }
            foreach ($method in $type.Methods) {
                $token = $method.MetadataToken.ToUInt32()
                $signature = Get-MethodSignature $method
                $parameters = @($method.Parameters | ForEach-Object {
                    Get-JsonKey @($_.Name, [int]$_.Attributes, $_.Constant,
                                  $(if ($_.MarshalInfo) { [int]$_.MarshalInfo.NativeType }),
                                  @(Get-CustomAttributes $_))
                })
                $result.method += Get-JsonKey @($token, $signature, [int]$method.Attributes,
                    [int]$method.ImplAttributes, [int]$method.SemanticsAttributes,
                    $method.HasBody, $parameters, @(Get-CustomAttributes $method),
                    @($method.Overrides | ForEach-Object { Get-MethodSignature $_ }))
                if (!$method.HasBody) { continue }
                $body = $method.Body
                $instructions = @($body.Instructions | ForEach-Object {
                    Get-JsonKey @($_.Offset, $_.OpCode.Name, (Get-InstructionOperandSignature $_.Operand))
                })
                $result.body += Get-JsonKey @($token, $body.CodeSize, $instructions)
                $result.locals += Get-JsonKey @($token, $body.MaxStackSize, $body.InitLocals,
                    @($body.Variables | ForEach-Object { Get-TypeSignature $_.VariableType }))
                foreach ($handler in $body.ExceptionHandlers) {
                    $result.eh += Get-JsonKey @($token, [int]$handler.HandlerType,
                        (Get-TypeSignature $handler.CatchType),
                        $handler.TryStart.Offset, $handler.TryEnd.Offset,
                        $handler.HandlerStart.Offset, $handler.HandlerEnd.Offset,
                        $handler.FilterStart.Offset)
                }
            }
        }
        return $result
    } finally {
        $module.Dispose()
    }
}
function Compare-ModuleRecords($Expected, $Actual) {
    $report = [ordered]@{}
    foreach ($kind in 'ref','type','method','body','eh','locals','field','property','event') {
        $left = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        $right = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        foreach ($row in $Expected[$kind]) { [void]$left.Add($row) }
        foreach ($row in $Actual[$kind]) { [void]$right.Add($row) }
        $removed = @($Expected[$kind] | Where-Object { !$right.Contains($_) })
        $added = @($Actual[$kind] | Where-Object { !$left.Contains($_) })
        $report[$kind] = @{
            original = $Expected[$kind].Count
            candidate = $Actual[$kind].Count
            removed = $removed.Count
            added = $added.Count
            removed_rows = $removed
            added_rows = $added
        }
    }
    return $report
}
$oracle = Read-ModuleRecords $Original
$test = Read-ModuleRecords $Assembled
$rebuilt = Read-ModuleRecords $Final
$result = @{
    original = (Get-FileHash -LiteralPath $Original).Hash.ToLowerInvariant()
    assembled = (Get-FileHash -LiteralPath $Assembled).Hash.ToLowerInvariant()
    final = (Get-FileHash -LiteralPath $Final).Hash.ToLowerInvariant()
    cecil = (Get-FileHash -LiteralPath $Cecil).Hash.ToLowerInvariant()
    pre_patch = Compare-ModuleRecords $oracle $test
    final_comparison = Compare-ModuleRecords $oracle $rebuilt
    original_exception_regions = $oracle.eh
}
$result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $Report -Encoding UTF8
