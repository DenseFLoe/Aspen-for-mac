using System;
using System.Collections;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using AspenTech.AspenPlus.APConvert;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Localization;

namespace HeatExchanger;

[ComVisible(false)]
public class MixerConverter : IAPBlockConverter2, IAPBlockConverter
{
	private enum CursorName
	{
		IDC_ARROW = 32512,
		IDC_WAIT = 32514
	}

	private class StreamConnection
	{
		public string streamName;

		public string streamPort;

		public string blockName;

		public string blockPort;
	}

	private class ConvertData
	{
		public string varName;

		public object Value;

		public short Units;
	}

	private const int HAP_UNITCOL = 3;

	private const int HAP_COMPSTATUS = 12;

	private const int HAP_INPUT_INCOMPLETE = 64;

	private string[] varNames = new string[26]
	{
		"SPEC_OPT", "NPHASE", "PHASE", "BLKOPFREWAT", "MAXIT", "TOL", "OPSETNAME", "HENRY_COMPS", "CHEMISTRY", "FRWATEROPSET",
		"SOLU_WATER", "TRUE_COMPS", "ENERGY_BAL", "RESTART", "FLASH_METHOD", "SIM_LEVEL", "PROP_LEVEL", "STREAM_LEVEL", "TERM_LEVEL", "REPORT",
		"NEWPAGE", "TOTBAL", "INPUT", "COMPBAL", "RESULTS", "DESCRIPTION"
	};

	private string[] varWithUnit = new string[3] { "DUTY", "PRES", "T_EST" };

	private string[] commonVarNames1 = new string[34]
	{
		"EO_COMPS", "EO_FORM", "SOLVE_OPEN", "INTERACTIVE", "SPARSITY", "EO_LIGHT_KEY", "EO-HEAVY_KEY", "EO_DEP_COMPS", "DERIV_METHOD", "SOLVE_METHOD",
		"INIT_SCRIPT", "CHECK_FREE_W", "NEG_COMP_CHK", "NEG_FLOW_CHK", "INLET_PHASE", "ALWAYS_INST", "FLASH_FORM", "L2_COMP_MODE", "EO_L2_COMP", "VFRACX_TOL",
		"VFRAC_TOL", "FLOW_TOL", "ON_SMEO_DIFF", "PRES_TOL", "MIN_PRES", "SFRAC_TOL", "EO_COMP_TOL", "CHEM_METHOD", "DUTY_TOL", "AUTO_COMPS",
		"AUTO_COMPS_T", "AUTO_PHASE", "AUTO_PHASE_T", "EO_TEMP_TOL"
	};

	private string[] commonVarNames2 = new string[32]
	{
		"IVNAME", "IVVALUE", "IVLOWER", "IVUPPER", "IVSTEP", "BOUND_TYPE", "SBWEIGHT", "PHYS_QTY", "UOM", "IVSCALE",
		"IVSPEC", "IVENABLED", "EOVAR_TYPE", "THRESHOLD", "RAMPED", "IDESCRIPTION", "SC_METHOD", "USER_METHOD", "SC_TYPE", "LOCALSCRIPT",
		"GLOBALSCRIPT", "FVN_VARTYPE", "FVN_VARIABLE", "FVC_VARIABLE", "FVN_SENTENCE", "FVC_SENTENCE", "FVN_ID1", "FVC_ID1", "FVN_ID2", "FVC_ID2",
		"FVN_ID3", "FVN_ELEM"
	};

	private string[] commonVarNames3 = new string[3] { "SG_NAME", "ENABLED", "COMMENT" };

	private string[] commonVarNames4 = new string[18]
	{
		"PORT_ID", "EO_PT_VAR", "EO_PT_VALUE", "EO_PT_TYPE", "EO_PT_COMP", "THRU", "EO_PT_PHASE", "EO_PT_PHYSQT", "EO_PT_UOM", "S_CH_NAME",
		"VAR", "SG_SPEC", "HIERARCHY", "SG_VALUE", "SG_LOWER", "SG_UPPER", "SG_PHYS_QTY", "SG_UOM"
	};

	private IntPtr gHourglassCursor;

	private IntPtr gPrevCursor;

	private ArrayList streamList;

	private ArrayList variableList;

	private ArrayList varWithUnitList;

	private ArrayList commonVarList1;

	private ArrayList commentList;

	private string convertType;

	private string title = WpfMMDialogResources.ConvertTo_Title;

	public string BaseDestinationType => "HEATER";

	public string BaseSourceType => convertType.ToUpper();

	public string Description => WpfMMDialogResources.ConvertTo_This + " " + BaseSourceType + " " + WpfMMDialogResources.ConvertTo_ConverTo + " " + BaseDestinationType + " " + WpfMMDialogResources.ConvertTo_Model;

	public string DestLibraryFile => "";

	public string DestLibraryModelType => "";

	public string DestLibraryName => "";

	public string DisplayName => "";

	[DllImport("user32")]
	private static extern IntPtr SetCursor(IntPtr hCursor);

	[DllImport("user32")]
	private static extern IntPtr LoadCursor(IntPtr hInstance, CursorName lpCursorName);

	public MixerConverter(string type)
	{
		convertType = type;
		streamList = new ArrayList();
		variableList = new ArrayList();
		varWithUnitList = new ArrayList();
		commonVarList1 = new ArrayList();
		commentList = new ArrayList();
	}

	public void PreConvert(IHNode pNode)
	{
	}

	public int PreConvert2(IHNode pNode)
	{
		gHourglassCursor = LoadCursor(IntPtr.Zero, CursorName.IDC_WAIT);
		gPrevCursor = SetCursor(gHourglassCursor);
		if (pNode == null)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Node, title);
			return 1;
		}
		IHNode iHNode = pNode.FindNode("Ports/HS(IN)");
		IHNode iHNode2 = pNode.FindNode("Ports/HS(OUT)");
		IHNode iHNode3 = pNode.FindNode("Ports/WS(IN)");
		IHNode iHNode4 = pNode.FindNode("Ports/WS(OUT)");
		if ((iHNode != null && iHNode.Elements.Count > 0) || (iHNode2 != null && iHNode2.Elements.Count > 0) || (iHNode3 != null && iHNode3.Elements.Count > 0) || (iHNode4 != null && iHNode4.Elements.Count > 0))
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Mixer_Stream, title, MessageBoxButtons.OK);
			return 1;
		}
		IHNode iHNode5 = pNode.FindNode("CC Nodes/BKOP");
		if (iHNode5 != null && !Convert.ToBoolean((dynamic)iHNode5.get_Value(Type.Missing)))
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Input_Incomplete, title);
			return 1;
		}
		try
		{
			IHNode iHNode6 = pNode.FindNode("Connections");
			IHNodeCol elements = iHNode6.Elements;
			if (elements != null)
			{
				string text = pNode.get_Name(Type.Missing);
				streamList.Clear();
				for (int i = 0; i < elements.Count; i++)
				{
					string text2 = elements.get_Label(0, i, Type.Missing);
					IHNode iHNode7 = pNode.FindNode("../../Streams/" + text2 + "/Connections/" + text);
					if (iHNode7 == null)
					{
						continue;
					}
					StreamConnection streamConnection = new StreamConnection();
					IHNode iHNode8 = iHNode6.FindNode(text2);
					try
					{
						if (((dynamic)iHNode8.get_Value(Type.Missing)).ToString().Contains("WS"))
						{
							MessageBox.Show(WpfMMDialogResources.ConvertTo_WorkStream, title);
							return 1;
						}
					}
					catch (COMException)
					{
					}
					streamConnection.streamName = text2;
					streamConnection.blockName = text;
					streamConnection.streamPort = ((dynamic)iHNode7.get_Value(Type.Missing)).ToString();
					streamConnection.blockPort = ((dynamic)iHNode8.get_Value(Type.Missing)).ToString();
					streamList.Add(streamConnection);
				}
			}
			variableList.Clear();
			for (int j = 0; j < varNames.Count(); j++)
			{
				ConvertData convertData = new ConvertData();
				convertData.varName = varNames[j];
				if (j == 0)
				{
					convertData.Value = "PD";
				}
				else
				{
					string path = "Input/" + varNames[j];
					IHNode iHNode9 = pNode.FindNode(path);
					if (iHNode9 != null)
					{
						convertData.Value = iHNode9.get_Value(Type.Missing);
					}
				}
				variableList.Add(convertData);
			}
			varWithUnitList.Clear();
			for (int k = 0; k < varWithUnit.Count(); k++)
			{
				ConvertData convertData2 = new ConvertData();
				convertData2.varName = varWithUnit[k];
				if (k == 0)
				{
					convertData2.Value = 0.0;
				}
				else
				{
					string path2 = "Input/" + varWithUnit[k];
					IHNode iHNode10 = pNode.FindNode(path2);
					if (iHNode10 != null)
					{
						convertData2.Value = iHNode10.get_Value(Type.Missing);
						convertData2.Units = Convert.ToInt16((dynamic)iHNode10.get_AttributeValue((short)3, Type.Missing));
					}
				}
				varWithUnitList.Add(convertData2);
			}
			commonVarList1.Clear();
			for (int l = 0; l < commonVarNames1.Count(); l++)
			{
				ConvertData convertData3 = new ConvertData();
				convertData3.varName = commonVarNames1[l];
				string path3 = "Input/" + commonVarNames1[l];
				IHNode iHNode11 = pNode.FindNode(path3);
				if (iHNode11 != null && (dynamic)iHNode11.get_Value(Type.Missing) != null)
				{
					convertData3.Value = iHNode11.get_Value(Type.Missing);
					commonVarList1.Add(convertData3);
				}
			}
			commentList.Clear();
			IHNode iHNode12 = pNode.FindNode("Comments");
			IHNodeCol elements2 = iHNode12.Elements;
			if (elements2 != null && elements2.Count > 0)
			{
				for (int m = 0; m < elements2.Count; m++)
				{
					ConvertData convertData4 = new ConvertData();
					convertData4.varName = m.ToString();
					IHNode iHNode13 = iHNode12.Elements[m, Type.Missing, Type.Missing, Type.Missing, Type.Missing];
					if (iHNode13 != null && (dynamic)iHNode13.get_Value(Type.Missing) != null)
					{
						convertData4.Value = iHNode13.get_Value(Type.Missing);
						commentList.Add(convertData4);
					}
				}
			}
		}
		catch (Exception ex2)
		{
			MessageBox.Show("Cannot convert to Heater");
			throw new Exception(ex2.Message.ToString());
		}
		return 0;
	}

	public void PostConvert(IHNode pNode)
	{
		IHNode iHNode = pNode.FindNode("Ports");
		IHNodeCol elements = iHNode.Elements;
		try
		{
			if (elements != null)
			{
				for (int i = 0; i < streamList.Count; i++)
				{
					StreamConnection streamConnection = streamList[i] as StreamConnection;
					for (int j = 0; j < elements.Count; j++)
					{
						string text = elements.get_Label(0, j, Type.Missing);
						if (text.CompareTo(streamConnection.blockPort) == 0)
						{
							string streamName = streamConnection.streamName;
							IHNodeCol destinationElements = iHNode.FindNode(text).Elements;
							if (destinationElements != null)
							{
								destinationElements.Add(streamName, null, null, null, null);
							}
							break;
						}
					}
				}
			}
			IHNode iHNode2 = null;
			int count = variableList.Count;
			for (int k = 0; k < count; k++)
			{
				ConvertData convertData = variableList[k] as ConvertData;
				iHNode2 = pNode.FindNode("Input/" + convertData.varName);
				try
				{
					if (iHNode2 != null && convertData.Value != null)
					{
						iHNode2.set_Value(Type.Missing, convertData.Value);
					}
					else if (iHNode2 != null && convertData.Value == null && k > 5 && k < 12)
					{
						iHNode2.set_Value(Type.Missing, convertData.Value);
					}
				}
				catch
				{
				}
			}
			count = varWithUnitList.Count;
			for (int l = 0; l < count; l++)
			{
				ConvertData convertData2 = varWithUnitList[l] as ConvertData;
				iHNode2 = pNode.FindNode("Input/" + convertData2.varName);
				try
				{
					if (iHNode2 != null && convertData2.Value != null)
					{
						iHNode2.SetValueAndUnit(convertData2.Value, convertData2.Units, Type.Missing);
					}
				}
				catch
				{
				}
			}
			count = commonVarList1.Count;
			for (int m = 0; m < count; m++)
			{
				ConvertData convertData3 = commonVarList1[m] as ConvertData;
				iHNode2 = pNode.FindNode("Input/" + convertData3.varName);
				try
				{
					if (iHNode2 != null && convertData3.Value != null)
					{
						iHNode2.set_Value(Type.Missing, convertData3.Value);
					}
				}
				catch
				{
				}
			}
			count = commentList.Count;
			for (int n = 0; n < count; n++)
			{
				ConvertData convertData4 = commentList[n] as ConvertData;
				iHNode2 = pNode.FindNode("Comments");
				try
				{
					if (iHNode2 != null && convertData4.Value != null)
					{
						iHNode2.Elements.InsertRow(0, n);
						iHNode2.Elements[n, Type.Missing, Type.Missing, Type.Missing, Type.Missing].set_Value(Type.Missing, convertData4.Value);
					}
				}
				catch
				{
				}
			}
			SetCursor(gPrevCursor);
		}
		catch (Exception ex)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_CannotBeConverted, title);
			throw new Exception(ex.Message.ToString());
		}
	}
}
