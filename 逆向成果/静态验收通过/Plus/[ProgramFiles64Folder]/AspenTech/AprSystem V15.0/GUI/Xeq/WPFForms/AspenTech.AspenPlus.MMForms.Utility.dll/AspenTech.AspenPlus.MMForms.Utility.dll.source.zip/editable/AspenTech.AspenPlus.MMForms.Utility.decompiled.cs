using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenCxs;
using AspenTech.AspenCxs.CxsViewModel;
using AspenTech.AspenCxs.CxsViewModel.CompositeEvents;
using AspenTech.AspenCxs.CxsViewModel.ViewData;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Localization;
using AspenTech.AspenPlus.MMControls;
using AspenTech.WpfControls.Engineering;
using Microsoft.Practices.Composite.Events;
using Microsoft.Practices.Unity;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.MMForms.Utility")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.MMForms.Utility")]
[assembly: AssemblyCopyright("Copyright © AspenTech 2010 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/utility", "AspenTech.AspenPlus.MMForms.Utility.BlkUtility")]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/utility", "AspenTech.AspenPlus.MMForms.Utility.Coal")]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/utility", "AspenTech.AspenPlus.MMForms.Utility.Electricity")]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/utility", "AspenTech.AspenPlus.MMForms.Utility.Gas")]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/utility", "AspenTech.AspenPlus.MMForms.Utility.General")]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/utility", "AspenTech.AspenPlus.MMForms.Utility.Oil")]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/utility", "AspenTech.AspenPlus.MMForms.Utility.Refrigerant")]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/utility", "AspenTech.AspenPlus.MMForms.Utility.Steam")]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/utility", "AspenTech.AspenPlus.MMForms.Utility.Water")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]
namespace XamlGeneratedNamespace
{
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class GeneratedInternalTypeHelper : InternalTypeHelper
	{
		protected override object CreateInstance(Type type, CultureInfo culture)
		{
			return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.CreateInstance, null, null, culture);
		}

		protected override object GetPropertyValue(PropertyInfo propertyInfo, object target, CultureInfo culture)
		{
			return propertyInfo.GetValue(target, BindingFlags.Default, null, null, culture);
		}

		protected override void SetPropertyValue(PropertyInfo propertyInfo, object target, object value, CultureInfo culture)
		{
			propertyInfo.SetValue(target, value, BindingFlags.Default, null, null, culture);
		}

		protected override Delegate CreateDelegate(Type delegateType, object target, string handler)
		{
			return (Delegate)target.GetType().InvokeMember("_CreateDelegate", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, target, new object[2] { delegateType, handler }, null);
		}

		protected override void AddEventHandler(EventInfo eventInfo, object target, Delegate handler)
		{
			eventInfo.AddEventHandler(target, handler);
		}
	}
}
namespace AspenTech.AspenPlus.MMForms.Utility.General
{
	public class MMGenUtl_Input_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration FLASH_Property = CxvPropertyDeclaration.Register("FLASH", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.FLASH"
		});

		public static readonly CxvPropertyDeclaration SPEC_Property = CxvPropertyDeclaration.Register("SPEC", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SPEC"
		});

		public static readonly CxvPropertyDeclaration ENTEOP_Property = CxvPropertyDeclaration.Register("ENTEOP", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTEOP"
		});

		public static readonly CxvPropertyDeclaration ENTBLKPR_Property = CxvPropertyDeclaration.Register("ENTBLKPR", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKPR"
		});

		public static readonly CxvPropertyDeclaration PROP_Property = CxvPropertyDeclaration.Register("PROP", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.PROP"
		});

		public static readonly CxvPropertyDeclaration FLSHCHK1_Property = CxvPropertyDeclaration.Register("FLSHCHK1", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.FLSHCHK1"
		});

		public static readonly CxvPropertyDeclaration PRICE_Property = CxvPropertyDeclaration.Register("PRICE", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.PRICE"
		});

		public static readonly CxvPropertyDeclaration FLSHCHK2_Property = CxvPropertyDeclaration.Register("FLSHCHK2", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.FLSHCHK2"
		});

		public static readonly CxvPropertyDeclaration COMP_Property = CxvPropertyDeclaration.Register("COMP", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.COMP"
		});

		public static readonly CxvPropertyDeclaration BKOP_Property = CxvPropertyDeclaration.Register("BKOP", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.BKOP"
		});

		public static readonly CxvPropertyDeclaration FLSHCHK3_Property = CxvPropertyDeclaration.Register("FLSHCHK3", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.FLSHCHK3"
		});

		public static readonly CxvPropertyDeclaration TYPE_Property = CxvPropertyDeclaration.Register("TYPE", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.TYPE"
		});

		public static readonly CxvPropertyDeclaration ENTFLSO_Property = CxvPropertyDeclaration.Register("ENTFLSO", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTFLSO"
		});

		public static readonly CxvPropertyDeclaration FLSHCHK4_Property = CxvPropertyDeclaration.Register("FLSHCHK4", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.FLSHCHK4"
		});

		public static readonly CxvPropertyDeclaration FLSHCHK5_Property = CxvPropertyDeclaration.Register("FLSHCHK5", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.FLSHCHK5"
		});

		public static readonly CxvPropertyDeclaration BKOPNP_Property = CxvPropertyDeclaration.Register("BKOPNP", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.BKOPNP"
		});

		public static readonly CxvPropertyDeclaration ENTCO2_Property = CxvPropertyDeclaration.Register("ENTCO2", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTCO2"
		});

		public static readonly CxvPropertyDeclaration CO2SPC5_Property = CxvPropertyDeclaration.Register("CO2SPC5", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.CO2SPC5"
		});

		public static readonly CxvPropertyDeclaration CO2SPC6_Property = CxvPropertyDeclaration.Register("CO2SPC6", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.CO2SPC6"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMGenUtl_Input_ViewModel), new CxvTabItemProperty
		{
			CompleteDataPaths = { "@FLSHCHK3", "@PRICE", "@SPEC", "@TYPE", "@UTLREDSPC" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMGenUtl_Input_ViewModel), new CxvTabItemProperty
		{
			CompleteDataPaths = { "@COMP", "@FLSHCHK1", "@FLSHCHK2", "@FLSHCHK4", "@FLSHCHK5" },
			AccessibleDataPaths = { "@FLASH" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMGenUtl_Input_ViewModel), new CxvTabItemProperty
		{
			CompleteDataPaths = { "@BKOP" },
			AccessibleDataPaths = { "@PROP" },
			EnteredDataPaths = { "@ENTBLKPR" }
		});

		public static readonly CxvPropertyDeclaration tab3_var_Property = CxvPropertyDeclaration.Register("tab3_var", typeof(MMGenUtl_Input_ViewModel), new CxvTabItemProperty
		{
			CompleteDataPaths = { "@BKOPNP", "@FLSHCHK4" },
			AccessibleDataPaths = { "@FLASH" },
			EnteredDataPaths = { "@ENTFLSO" }
		});

		public static readonly CxvPropertyDeclaration tab5_var_Property = CxvPropertyDeclaration.Register("tab5_var", typeof(MMGenUtl_Input_ViewModel), new CxvTabItemProperty
		{
			EnteredDataPaths = { "@ENTEOP" }
		});

		public static readonly CxvPropertyDeclaration tab6_var_Property = CxvPropertyDeclaration.Register("tab6_var", typeof(MMGenUtl_Input_ViewModel), new CxvTabItemProperty
		{
			CompleteDataPaths = { "@CO2SPC5", "@CO2SPC6" },
			EnteredDataPaths = { "@ENTCO2" }
		});

		public static readonly CxvPropertyDeclaration UTLREDSPC_Property = CxvPropertyDeclaration.Register("UTLREDSPC", typeof(MMGenUtl_Input_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UTLREDSPC"
		});

		public object FLASH => GetValue(FLASH_Property);

		public object SPEC => GetValue(SPEC_Property);

		public object ENTEOP => GetValue(ENTEOP_Property);

		public object ENTBLKPR => GetValue(ENTBLKPR_Property);

		public object PROP => GetValue(PROP_Property);

		public object FLSHCHK1 => GetValue(FLSHCHK1_Property);

		public object PRICE => GetValue(PRICE_Property);

		public object FLSHCHK2 => GetValue(FLSHCHK2_Property);

		public object COMP => GetValue(COMP_Property);

		public object BKOP => GetValue(BKOP_Property);

		public object FLSHCHK3 => GetValue(FLSHCHK3_Property);

		public object TYPE => GetValue(TYPE_Property);

		public object ENTFLSO => GetValue(ENTFLSO_Property);

		public object FLSHCHK4 => GetValue(FLSHCHK4_Property);

		public object FLSHCHK5 => GetValue(FLSHCHK5_Property);

		public object BKOPNP => GetValue(BKOPNP_Property);

		public object ENTCO2 => GetValue(ENTCO2_Property);

		public object CO2SPC5 => GetValue(CO2SPC5_Property);

		public object CO2SPC6 => GetValue(CO2SPC6_Property);

		public object tab0_var => GetValue(tab0_var_Property);

		public object tab1_var => GetValue(tab1_var_Property);

		public object tab2_var => GetValue(tab2_var_Property);

		public object tab3_var => GetValue(tab3_var_Property);

		public object tab5_var => GetValue(tab5_var_Property);

		public object tab6_var => GetValue(tab6_var_Property);

		public object UTLREDSPC => GetValue(UTLREDSPC_Property);
	}
	[ProgId("MMGenUtl.MMGenUtl_Input")]
	public class MMGenUtl_Input : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabInput;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem tab3;

		internal MMTabItem tab4;

		internal MMTabItem tab5;

		internal MMTabItem tab6;

		internal MMTabItem tabInfo;

		private bool _contentLoaded;

		public MMGenUtl_Input()
		{
			base.ViewModelType = typeof(MMGenUtl_Input_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_input.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				tabInput = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				tab3 = (MMTabItem)target;
				break;
			case 6:
				tab4 = (MMTabItem)target;
				break;
			case 7:
				tab5 = (MMTabItem)target;
				break;
			case 8:
				tab6 = (MMTabItem)target;
				break;
			case 9:
				tabInfo = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMGenUtl_Input_Carbon_ViewModel : MMTabPageViewModel
	{
		public class grdComposition_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtXomponent_var1_Property = CxvPropertyDeclaration.Register("txtXomponent_var1", typeof(grdComposition_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.Id,
				DataPath = "@main.Input.EMFRAC.@COMP"
			});

			public static readonly CxvPropertyDeclaration txtValue_var1_Property = CxvPropertyDeclaration.Register("txtValue_var1", typeof(grdComposition_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.EMFRAC.@COMP"
			});

			public object txtXomponent_var1 => GetValue(txtXomponent_var1_Property);

			public object txtValue_var1 => GetValue(txtValue_var1_Property);
		}

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMGenUtl_Input_Carbon_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.CO2FACTOR",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CO2SPC4"
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText2_var1_Property = CxvPropertyDeclaration.Register("MMLBUText2_var1", typeof(MMGenUtl_Input_Carbon_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.EFFICIENCY",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CO2SPC3"
			}
		});

		public static readonly CxvPropertyDeclaration MMComboBox2_var1_Property = CxvPropertyDeclaration.Register("MMComboBox2_var1", typeof(MMGenUtl_Input_Carbon_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.FUELSOURCE",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CO2SPC2"
			}
		});

		public static readonly CxvPropertyDeclaration MMComboBox1_var1_Property = CxvPropertyDeclaration.Register("MMComboBox1_var1", typeof(MMGenUtl_Input_Carbon_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.FACTORSOURCE",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CO2SPC1"
			}
		});

		public static readonly CxvPropertyDeclaration MMCheckBox1_var1_Property = CxvPropertyDeclaration.Register("MMCheckBox1_var1", typeof(MMGenUtl_Input_Carbon_ViewModel), new CxvBooleanProperty
		{
			DataPath = "@main.Input.CALCCO2",
			TrueValue = "YES",
			FalseValue = "NO",
			DefaultValue = false
		});

		public static readonly CxvPropertyDeclaration fraComposition_state_Property = CxvPropertyDeclaration.Register("fraComposition_state", typeof(MMGenUtl_Input_Carbon_ViewModel), new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CO2SPC7"
			}
		});

		public static readonly CxvPropertyDeclaration grdComposition_GridData_Property = CxvPropertyDeclaration.Register("grdComposition_GridData", typeof(MMGenUtl_Input_Carbon_ViewModel), new CxvVectorProperty
		{
			ItemType = typeof(grdComposition_GridData_ItemTemplate),
			IndexBasis = new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.EMFRAC",
				UseChildId = true,
				Name = "COMP"
			}
		});

		public static readonly CxvPropertyDeclaration MMComboBox3_var1_Property = CxvPropertyDeclaration.Register("MMComboBox3_var1", typeof(MMGenUtl_Input_Carbon_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.EMBASIS",
			DisplayedCase = CxsDisplayedCase.Lowercase
		});

		public static readonly CxvPropertyDeclaration Scope_MultiMap_Property = CxvPropertyDeclaration.Register("Scope_MultiMap", typeof(MMGenUtl_Input_Carbon_ViewModel), new CxvMultiMapProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CO2SPC1"
			},
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "scope_var1",
					DataPath = "@main.Input.SCOPE"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Scope 1",
					DisplayResourceKey = "MMGenUtl_Input_Carbon_ViewModel__CxvMultiMapOption_Display_Scope1",
					Prompt = PromptResources.FILEPNUM_437_Prompt_195,
					Value = "Scope_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "scope_var1",
							Value = "SCOPE1"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Scope 2",
					DisplayResourceKey = "MMGenUtl_Input_Carbon_ViewModel__CxvMultiMapOption_Display_Scope2",
					Prompt = PromptResources.FILEPNUM_437_Prompt_196,
					Value = "Scope_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "scope_var1",
							Value = "SCOPE2"
						}
					}
				}
			}
		});

		public static readonly CxvPropertyDeclaration CO2Emission_var1_Property = CxvPropertyDeclaration.Register("CO2Emission_var1", typeof(MMGenUtl_Input_Carbon_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.CO2_ADJ_FAC",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CO2SPC1"
			}
		});

		public object MMLBUText1_var1 => GetValue(MMLBUText1_var1_Property);

		public object MMLBUText2_var1 => GetValue(MMLBUText2_var1_Property);

		public object MMComboBox2_var1 => GetValue(MMComboBox2_var1_Property);

		public object MMComboBox1_var1 => GetValue(MMComboBox1_var1_Property);

		public object MMCheckBox1_var1 => GetValue(MMCheckBox1_var1_Property);

		public object fraComposition_state => GetValue(fraComposition_state_Property);

		public object grdComposition_GridData => GetValue(grdComposition_GridData_Property);

		public object MMComboBox3_var1 => GetValue(MMComboBox3_var1_Property);

		public object Scope_MultiMap => GetValue(Scope_MultiMap_Property);

		public object CO2Emission_var1 => GetValue(CO2Emission_var1_Property);
	}
	[ProgId("MMGenUtl.MMGenUtl_Input_Carbon")]
	public class MMGenUtl_Input_Carbon : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMCheckBox MMCheckBox1;

		internal MMOptionGroup scopeType;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMLabel MMComboBox2_label;

		internal MMComboEdit MMComboBox2;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMLabel MMLBUText2_label;

		internal MMVariableEdit MMLBUText2;

		internal MMLabel lblEmission;

		internal MMVariableEdit txtEmission;

		internal MMGroupBox fraComposition;

		internal MMLabel MMComboBox3_label;

		internal MMComboEdit MMComboBox3;

		internal MMScrollArea grdComposition;

		private bool _contentLoaded;

		public MMGenUtl_Input_Carbon()
		{
			base.ViewModelType = typeof(MMGenUtl_Input_Carbon_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_input_carbon.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				MMCheckBox1 = (MMCheckBox)target;
				break;
			case 3:
				scopeType = (MMOptionGroup)target;
				break;
			case 4:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 5:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 6:
				MMComboBox2_label = (MMLabel)target;
				break;
			case 7:
				MMComboBox2 = (MMComboEdit)target;
				break;
			case 8:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 9:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 10:
				MMLBUText2_label = (MMLabel)target;
				break;
			case 11:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			case 12:
				lblEmission = (MMLabel)target;
				break;
			case 13:
				txtEmission = (MMVariableEdit)target;
				break;
			case 14:
				fraComposition = (MMGroupBox)target;
				break;
			case 15:
				MMComboBox3_label = (MMLabel)target;
				break;
			case 16:
				MMComboBox3 = (MMComboEdit)target;
				break;
			case 17:
				grdComposition = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMGenUtl_Input_Diagno_ViewModel : MMTabPageViewModel
	{
		protected override void OnUpdateData()
		{
			base.OnUpdateData();
			if (base.IsInitialUpdate)
			{
				ResolveUpdateParameter("Property_slider", "0");
				ResolveUpdateParameter("Stream_slider", "0");
			}
		}
	}
	[ProgId("MMGenUtl.MMGenUtl_Input_Diagno")]
	public class MMGenUtl_Input_Diagno : MMTabPage, IComponentConnector
	{
		private bool _contentLoaded;

		public MMGenUtl_Input_Diagno()
		{
			base.ViewModelType = typeof(MMGenUtl_Input_Diagno_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_input_diagno.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			_contentLoaded = true;
		}
	}
	public class MMGenUtl_Input_EOOpti_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMComboBox1_MultiMap_Property = CxvPropertyDeclaration.Register("MMComboBox1_MultiMap", typeof(MMGenUtl_Input_EOOpti_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "MMComboBox1_var1",
					DataPath = "@main.Input.SOLVE_METHOD"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Open",
					DisplayResourceKey = "MMGenUtl_Input_EOOpti_ViewModel__CxvMultiMapOption_Display_Open",
					Value = "MMComboBox1_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox1_var1",
							Value = "OPEN-PERT-IN"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Ignore block during EO solution",
					DisplayResourceKey = "MMGenUtl_Input_EOOpti_ViewModel__CxvMultiMapOption_Display_Ignore_block_during_EO_solution",
					Value = "MMComboBox1_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox1_var1",
							Value = "DO-NOT-CREAT"
						}
					}
				}
			}
		});

		public static readonly CxvPropertyDeclaration MMComboBox6_MultiMap_Property = CxvPropertyDeclaration.Register("MMComboBox6_MultiMap", typeof(MMGenUtl_Input_EOOpti_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "MMComboBox6_var1",
					DataPath = "@main.Input.ALWAYS_INST"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Yes",
					DisplayResourceKey = "MMGenUtl_Input_EOOpti_ViewModel__CxvMultiMapOption_Display_Yes",
					Value = "MMComboBox6_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox6_var1",
							Value = "YES"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "No",
					DisplayResourceKey = "MMGenUtl_Input_EOOpti_ViewModel__CxvMultiMapOption_Display_No",
					Value = "MMComboBox6_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox6_var1",
							Value = "NO"
						}
					}
				}
			}
		});

		public object MMComboBox1_MultiMap => GetValue(MMComboBox1_MultiMap_Property);

		public object MMComboBox6_MultiMap => GetValue(MMComboBox6_MultiMap_Property);
	}
	[ProgId("MMGenUtl.MMGenUtl_Input_EOOpti")]
	public class MMGenUtl_Input_EOOpti : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMLabel MMComboBox6_label;

		internal MMComboEdit MMComboBox6;

		private bool _contentLoaded;

		public MMGenUtl_Input_EOOpti()
		{
			base.ViewModelType = typeof(MMGenUtl_Input_EOOpti_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_input_eoopti.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 3:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 4:
				MMComboBox6_label = (MMLabel)target;
				break;
			case 5:
				MMComboBox6 = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMGenUtl_Input_FlashO_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration lbtuTol_display_Property = CxvPropertyDeclaration.Register("lbtuTol_display", typeof(MMGenUtl_Input_FlashO_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.TOL"
		});

		public static readonly CxvPropertyDeclaration spnMaxit_display_Property = CxvPropertyDeclaration.Register("spnMaxit_display", typeof(MMGenUtl_Input_FlashO_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.MAXIT"
		});

		public static readonly CxvPropertyDeclaration cboPhase_MultiMap_Property = CxvPropertyDeclaration.Register("cboPhase_MultiMap", typeof(MMGenUtl_Input_FlashO_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "cboPhase_var1",
					DataPath = "@main.Input.NPHASE"
				},
				new CxvMultiMapVariable
				{
					Name = "cboPhase_var2",
					DataPath = "@main.Input.PHASE"
				},
				new CxvMultiMapVariable
				{
					Name = "cboPhase_var3",
					DataPath = "@main.Input.BLKOPFREWAT"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Vapor-Only",
					DisplayResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Display_Vapor_Only",
					Value = "cboPhase_MultiMapOption_1",
					Prompt = "Only a vapor phase exists.",
					PromptResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Prompt_Only_a_vapor_phase_exists_",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var1",
							Value = "1"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var2",
							Value = "V"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var3",
							Value = "NO"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Liquid-Only",
					DisplayResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Display_Liquid_Only",
					Value = "cboPhase_MultiMapOption_2",
					Prompt = "Only a single liquid phase exists.",
					PromptResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Prompt_Only_a_single_liquid_phase_exists_",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var1",
							Value = "1"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var2",
							Value = "L"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var3",
							Value = "NO"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Solid-Only",
					DisplayResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Display_Solid_Only",
					Value = "cboPhase_MultiMapOption_3",
					Prompt = "Only pure salts (electrolytes) or solids exist.",
					PromptResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Prompt_Only_pure_salts__electrolytes__or_solids_e",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var1",
							Value = "1"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var2",
							Value = "S"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var3",
							Value = "NO"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Vapor-Liquid",
					DisplayResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid",
					Value = "cboPhase_MultiMapOption_4",
					Prompt = "2 phases (vapor and liquid) are considered in phase equilibrium calculations.",
					PromptResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Prompt_2_phases__vapor_and_liquid__are_considered",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var1",
							Value = "2"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var2"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var3",
							Value = "NO"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Vapor-Liquid-Liquid",
					DisplayResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_Liquid",
					Value = "cboPhase_MultiMapOption_5",
					Prompt = "3 phases (vapor and two liquid phases) are considered in phase equilibrium calculations.",
					PromptResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Prompt_3_phases__vapor_and_two_liquid_phases__are",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var1",
							Value = "3"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var2"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var3",
							Value = "NO"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Liquid-FreeWater",
					DisplayResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Display_Liquid_FreeWater",
					Value = "cboPhase_MultiMapOption_6",
					Prompt = "2 liquid phases (organic and pure water) are considered in phase equilibrium calculations.",
					PromptResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Prompt_2_liquid_phases__organic_and_pure_water__a",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var1",
							Value = "1"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var2",
							Value = "L"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var3",
							Value = "YES"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Vapor-Liquid-FreeWater",
					DisplayResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_FreeWater",
					Value = "cboPhase_MultiMapOption_7",
					Prompt = "3 phases (vapor, organic, and pure water) are considered in phase equilibrium calculations.",
					PromptResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Prompt_3_phases__vapor__organic__and_pure_water__",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var1",
							Value = "2"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var2"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var3",
							Value = "YES"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Liquid-DirtyWater",
					DisplayResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Display_Liquid_DirtyWater",
					Value = "cboPhase_MultiMapOption_8",
					Prompt = "2 liquid phases (organic and dirty water) are considered in phase equilibrium calculations.",
					PromptResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Prompt_2_liquid_phases__organic_and_dirty_water__",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var1",
							Value = "1"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var2",
							Value = "L"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var3",
							Value = "DIRTY"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Vapor-Liquid-DirtyWater",
					DisplayResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_DirtyWater",
					Value = "cboPhase_MultiMapOption_9",
					Prompt = "3 phases (vapor, organic, and dirty water) are considered in phase equilibrium calculations.",
					PromptResourceKey = "MMGenUtl_Input_FlashO_ViewModel__CxvMultiMapOption_Prompt_3_phases__vapor__organic__and_dirty_water_",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var1",
							Value = "2"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var2"
						},
						new CxvMultiMapValue
						{
							Variable = "cboPhase_var3",
							Value = "DIRTY"
						}
					}
				}
			}
		});

		public object lbtuTol_display => GetValue(lbtuTol_display_Property);

		public object spnMaxit_display => GetValue(spnMaxit_display_Property);

		public object cboPhase_MultiMap => GetValue(cboPhase_MultiMap_Property);
	}
	[ProgId("MMGenUtl.MMGenUtl_Input_FlashO")]
	public class MMGenUtl_Input_FlashO : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraValidPh;

		internal MMComboEdit cboPhase;

		internal MMGroupBox fraFlashOp;

		internal MMLabel spnMaxit_label;

		internal MMSpinBox spnMaxit;

		internal MMLabel lbtuTol_label;

		internal MMVariableEdit lbtuTol;

		private bool _contentLoaded;

		public MMGenUtl_Input_FlashO()
		{
			base.ViewModelType = typeof(MMGenUtl_Input_FlashO_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_input_flasho.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				fraValidPh = (MMGroupBox)target;
				break;
			case 2:
				cboPhase = (MMComboEdit)target;
				break;
			case 3:
				fraFlashOp = (MMGroupBox)target;
				break;
			case 4:
				spnMaxit_label = (MMLabel)target;
				break;
			case 5:
				spnMaxit = (MMSpinBox)target;
				break;
			case 6:
				lbtuTol_label = (MMLabel)target;
				break;
			case 7:
				lbtuTol = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMGenUtl_Input_Main_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMFrame3_state_Property = CxvPropertyDeclaration.Register("MMFrame3_state", typeof(MMGenUtl_Input_Main_ViewModel), new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CONSCK2"
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText6_var1_Property = CxvPropertyDeclaration.Register("MMLBUText6_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.MIN_TAPP",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CONSCK1"
			}
		});

		public static readonly CxvPropertyDeclaration MMComboBox3_MultiMap_Property = CxvPropertyDeclaration.Register("MMComboBox3_MultiMap", typeof(MMGenUtl_Input_Main_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "MMComboBox3_var1",
					DataPath = "@main.Input.FLOW_DIR"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Countercurrent",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Countercurrent",
					Value = "MMComboBox3_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox3_var1",
							Value = "COUNTERCURRENT"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Cocurrent",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Cocurrent",
					Value = "MMComboBox3_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox3_var1",
							Value = "COCURRENT"
						}
					}
				}
			},
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CONSCK1"
			}
		});

		public static readonly CxvPropertyDeclaration MMComboBox2_MultiMap_Property = CxvPropertyDeclaration.Register("MMComboBox2_MultiMap", typeof(MMGenUtl_Input_Main_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "MMComboBox2_var1",
					DataPath = "@main.Input.CONST_CHECK"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Ignore",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Ignore",
					Value = "MMComboBox2_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox2_var1",
							Value = "IGNORE"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Information",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Information",
					Value = "MMComboBox2_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox2_var1",
							Value = "INFORMATION"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Warning",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Warning",
					Value = "MMComboBox2_MultiMapOption_3",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox2_var1",
							Value = "WARNING"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Error",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Error",
					Value = "MMComboBox2_MultiMapOption_4",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox2_var1",
							Value = "ERROR"
						}
					}
				}
			}
		});

		public static readonly CxvPropertyDeclaration MMFrame2_state_Property = CxvPropertyDeclaration.Register("MMFrame2_state", typeof(MMGenUtl_Input_Main_ViewModel), new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.DUTY"
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText4_var1_Property = CxvPropertyDeclaration.Register("MMLBUText4_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.TOUT"
		});

		public static readonly CxvPropertyDeclaration MMLBUText3_var1_Property = CxvPropertyDeclaration.Register("MMLBUText3_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.TIN"
		});

		public static readonly CxvPropertyDeclaration lbtuHCValue_var1_Property = CxvPropertyDeclaration.Register("lbtuHCValue_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.COOLING_VALU"
		});

		public static readonly CxvPropertyDeclaration MMComboBox1_MultiMap_Property = CxvPropertyDeclaration.Register("MMComboBox1_MultiMap", typeof(MMGenUtl_Input_Main_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "MMComboBox1_var1",
					DataPath = "@main.Input.UTILITY_TYPE"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Water",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Water",
					Value = "MMComboBox1_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox1_var1",
							Value = "WATER"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Steam",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Steam",
					Value = "MMComboBox1_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox1_var1",
							Value = "STEAM"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Oil",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Oil",
					Value = "MMComboBox1_MultiMapOption_3",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox1_var1",
							Value = "OIL"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Gas",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Gas",
					Value = "MMComboBox1_MultiMapOption_4",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox1_var1",
							Value = "GAS"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Coal",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Coal",
					Value = "MMComboBox1_MultiMapOption_5",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox1_var1",
							Value = "COAL"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Electricity",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Electricity",
					Value = "MMComboBox1_MultiMapOption_6",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox1_var1",
							Value = "ELECTRICITY"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Refrigeration",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Refrigeration",
					Value = "MMComboBox1_MultiMapOption_7",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox1_var1",
							Value = "REFRIGERATIO"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "General",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_General",
					Value = "MMComboBox1_MultiMapOption_8",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "MMComboBox1_var1",
							Value = "GENERAL"
						}
					}
				}
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText2_var1_Property = CxvPropertyDeclaration.Register("MMLBUText2_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.ENERGY_PRICE",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.ENERPRIC"
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText5_var1_Property = CxvPropertyDeclaration.Register("MMLBUText5_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.ELEC_PRICE",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.ELEPRIC"
			}
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.PRICE",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.GENPRIC"
			}
		});

		public static readonly CxvPropertyDeclaration optCalculationMethod_MultiMap_Property = CxvPropertyDeclaration.Register("optCalculationMethod_MultiMap", typeof(MMGenUtl_Input_Main_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "optCalculationMethod_calopt",
					DataPath = "@main.Input.CALOPT"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Specify heating/cooling value",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Specify_heating_cooling_value",
					Value = "optCalculationMethod_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "optCalculationMethod_calopt",
							Value = "DUTY"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Specify inlet/outlet conditions",
					DisplayResourceKey = "MMGenUtl_Input_Main_ViewModel__CxvMultiMapOption_Display_Specify_inlet_outlet_conditions",
					Value = "optCalculationMethod_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "optCalculationMethod_calopt",
							Value = "FLASH"
						}
					}
				}
			},
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.CALOPT"
			}
		});

		public static CxvPropertyDeclaration genVisible_Property = CxvPropertyDeclaration.Register("genVisible", typeof(MMGenUtl_Input_Main_ViewModel), new CxvLogicalProperty
		{
			Value = true,
			Tests = 
			{
				new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.GENVISIB",
					Value = "1"
				}
			}
		});

		public static CxvPropertyDeclaration eleVisible_Property = CxvPropertyDeclaration.Register("eleVisible", typeof(MMGenUtl_Input_Main_ViewModel), new CxvLogicalProperty
		{
			Value = true,
			Tests = 
			{
				new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.ELEPRIC",
					Value = "1"
				}
			}
		});

		public static readonly CxvPropertyDeclaration Price_MultiMap_Property = CxvPropertyDeclaration.Register("Price_MultiMap", typeof(MMGenUtl_Input_Main_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "Price_calopt",
					DataPath = "@main.Input.OPT_UTI_COST"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Purchase price:",
					DisplayResourceKey = "MMGenUtl_Input_Main_Display1",
					Value = "Price_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "Price_calopt",
							Value = "PURCH-PRICE"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Energy price:",
					DisplayResourceKey = "MMGenUtl_Input_Main_Display2",
					Value = "Price_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "Price_calopt",
							Value = "ENERG-PRICE"
						}
					}
				}
			}
		});

		public static readonly CxvPropertyDeclaration MMHTC_var1_Property = CxvPropertyDeclaration.Register("MMHTC_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.HTC",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.HTCEDIT"
			}
		});

		public static readonly CxvPropertyDeclaration MMConductivity_var1_Property = CxvPropertyDeclaration.Register("MMConductivity_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.CONDUCTIVITY",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.PROEDIT"
			}
		});

		public static readonly CxvPropertyDeclaration MMViscosity_var1_Property = CxvPropertyDeclaration.Register("MMViscosity_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.VISCOSITY",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.PROEDIT"
			}
		});

		public static readonly CxvPropertyDeclaration MMDensity_var1_Property = CxvPropertyDeclaration.Register("MMDensity_var1", typeof(MMGenUtl_Input_Main_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.DENSITY",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.PROEDIT"
			}
		});

		public static readonly CxvPropertyDeclaration optHTCEnergyAnalysis_MultiMap_Property = CxvPropertyDeclaration.Register("optHTCEnergyAnalysis_MultiMap", typeof(MMGenUtl_Input_Main_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "Htc_calopt",
					DataPath = "@main.Input.OPT_ENE_ANAL"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "Specify",
					DisplayResourceKey = "MMGenUtl_Input_Main_Specify",
					Value = "optHTCEnergyAnalysis_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "Htc_calopt",
							Value = "HTC-SPECIFY"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Calculate from properties",
					DisplayResourceKey = "MMGenUtl_Input_Main_CalcFromProp",
					Value = "optHTCEnergyAnalysis_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "Htc_calopt",
							Value = "PRO-SPECIFY"
						}
					}
				}
			},
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.GENVISIB"
			}
		});

		public object MMFrame3_state => GetValue(MMFrame3_state_Property);

		public object MMLBUText6_var1 => GetValue(MMLBUText6_var1_Property);

		public object MMComboBox3_MultiMap => GetValue(MMComboBox3_MultiMap_Property);

		public object MMComboBox2_MultiMap => GetValue(MMComboBox2_MultiMap_Property);

		public object MMFrame2_state => GetValue(MMFrame2_state_Property);

		public object MMLBUText4_var1 => GetValue(MMLBUText4_var1_Property);

		public object MMLBUText3_var1 => GetValue(MMLBUText3_var1_Property);

		public object lbtuHCValue_var1 => GetValue(lbtuHCValue_var1_Property);

		public object MMComboBox1_MultiMap => GetValue(MMComboBox1_MultiMap_Property);

		public object MMLBUText2_var1 => GetValue(MMLBUText2_var1_Property);

		public object MMLBUText5_var1 => GetValue(MMLBUText5_var1_Property);

		public object MMLBUText1_var1 => GetValue(MMLBUText1_var1_Property);

		public object optCalculationMethod_MultiMap => GetValue(optCalculationMethod_MultiMap_Property);

		public object genVisible => GetValue(genVisible_Property);

		public object eleVisible => GetValue(eleVisible_Property);

		public object Price_MultiMap => GetValue(Price_MultiMap_Property);

		public object MMHTC_var1 => GetValue(MMHTC_var1_Property);

		public object MMConductivity_var1 => GetValue(MMConductivity_var1_Property);

		public object MMViscosity_var1 => GetValue(MMViscosity_var1_Property);

		public object MMDensity_var1 => GetValue(MMDensity_var1_Property);

		public object optHTCEnergyAnalysis_MultiMap => GetValue(optHTCEnergyAnalysis_MultiMap_Property);
	}
	[ProgId("MMGenUtl.MMGenUtl_Input_Main")]
	public class MMGenUtl_Input_Main : MMTabPage, IComponentConnector
	{
		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMOptionGroup optPrice;

		internal MMOptionButton MMLBUText1_opt;

		internal MMVariableEdit MMLBUText1;

		internal MMOptionButton MMLBUText2_opt;

		internal MMVariableEdit MMLBUText2;

		internal MMGroupBox MMFrame1;

		internal MMLabel MMLBUText5_label;

		internal MMVariableEdit MMLBUText5;

		internal MMGroupBox MMFrame2;

		internal MMOptionGroup optCalculationMethod;

		internal MMOptionButton optCalculationMethod_opt0;

		internal MMOptionButton optCalculationMethod_opt1;

		internal MMGroupBox MMFrame12;

		internal MMLabel lbtuHCValue_label;

		internal MMVariableEdit lbtuHCValue;

		internal MMLabel MMLBUText3_label;

		internal MMVariableEdit MMLBUText3;

		internal MMLabel MMLBUText4_label;

		internal MMVariableEdit MMLBUText4;

		internal MMGroupBox MMFrame3;

		internal MMLabel MMComboBox2_label;

		internal MMComboEdit MMComboBox2;

		internal MMLabel MMComboBox3_label;

		internal MMComboEdit MMComboBox3;

		internal MMLabel MMLBUText6_label;

		internal MMVariableEdit MMLBUText6;

		internal MMOptionGroup optHTCEnergyAnalysis;

		internal MMOptionButton optHTCEnergyAnalysis_opt0;

		internal MMOptionButton optHTCEnergyAnalysis_opt1;

		internal MMVariableEdit MMHTC;

		internal MMLabel MMViscosity_label;

		internal MMVariableEdit MMViscosity;

		internal MMLabel MMConductivity_label;

		internal MMVariableEdit MMConductivity;

		internal MMLabel MMDensity_label;

		internal MMVariableEdit MMDensity;

		private bool _contentLoaded;

		public MMGenUtl_Input_Main()
		{
			base.ViewModelType = typeof(MMGenUtl_Input_Main_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_input_main.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 2:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 3:
				optPrice = (MMOptionGroup)target;
				break;
			case 4:
				MMLBUText1_opt = (MMOptionButton)target;
				break;
			case 5:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 6:
				MMLBUText2_opt = (MMOptionButton)target;
				break;
			case 7:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			case 8:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 9:
				MMLBUText5_label = (MMLabel)target;
				break;
			case 10:
				MMLBUText5 = (MMVariableEdit)target;
				break;
			case 11:
				MMFrame2 = (MMGroupBox)target;
				break;
			case 12:
				optCalculationMethod = (MMOptionGroup)target;
				break;
			case 13:
				optCalculationMethod_opt0 = (MMOptionButton)target;
				break;
			case 14:
				optCalculationMethod_opt1 = (MMOptionButton)target;
				break;
			case 15:
				MMFrame12 = (MMGroupBox)target;
				break;
			case 16:
				lbtuHCValue_label = (MMLabel)target;
				break;
			case 17:
				lbtuHCValue = (MMVariableEdit)target;
				break;
			case 18:
				MMLBUText3_label = (MMLabel)target;
				break;
			case 19:
				MMLBUText3 = (MMVariableEdit)target;
				break;
			case 20:
				MMLBUText4_label = (MMLabel)target;
				break;
			case 21:
				MMLBUText4 = (MMVariableEdit)target;
				break;
			case 22:
				MMFrame3 = (MMGroupBox)target;
				break;
			case 23:
				MMComboBox2_label = (MMLabel)target;
				break;
			case 24:
				MMComboBox2 = (MMComboEdit)target;
				break;
			case 25:
				MMComboBox3_label = (MMLabel)target;
				break;
			case 26:
				MMComboBox3 = (MMComboEdit)target;
				break;
			case 27:
				MMLBUText6_label = (MMLabel)target;
				break;
			case 28:
				MMLBUText6 = (MMVariableEdit)target;
				break;
			case 29:
				optHTCEnergyAnalysis = (MMOptionGroup)target;
				break;
			case 30:
				optHTCEnergyAnalysis_opt0 = (MMOptionButton)target;
				break;
			case 31:
				optHTCEnergyAnalysis_opt1 = (MMOptionButton)target;
				break;
			case 32:
				MMHTC = (MMVariableEdit)target;
				break;
			case 33:
				MMViscosity_label = (MMLabel)target;
				break;
			case 34:
				MMViscosity = (MMVariableEdit)target;
				break;
			case 35:
				MMConductivity_label = (MMLabel)target;
				break;
			case 36:
				MMConductivity = (MMVariableEdit)target;
				break;
			case 37:
				MMDensity_label = (MMLabel)target;
				break;
			case 38:
				MMDensity = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMGenUtl_Input_Proper_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration fraPropOptions_state_Property = CxvPropertyDeclaration.Register("fraPropOptions_state", typeof(MMGenUtl_Input_Proper_ViewModel), new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.WATER"
			}
		});

		public static readonly CxvPropertyDeclaration fraElecCal_state_Property = CxvPropertyDeclaration.Register("fraElecCal_state", typeof(MMGenUtl_Input_Proper_ViewModel), new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.WATER"
			}
		});

		public static readonly CxvPropertyDeclaration cboFreeWatProp_var1_Property = CxvPropertyDeclaration.Register("cboFreeWatProp_var1", typeof(MMGenUtl_Input_Proper_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.FRWATEROPSET"
		});

		public static readonly CxvPropertyDeclaration cboWaterSol_MultiMap_Property = CxvPropertyDeclaration.Register("cboWaterSol_MultiMap", typeof(MMGenUtl_Input_Proper_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "cboWaterSol_var1",
					DataPath = "@main.Input.SOLU_WATER"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "0 - Saturated steam table",
					DisplayResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_0___Saturated_steam_table",
					PromptResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_0___Saturated_steam_table_Prompt",
					Value = "cboWaterSol_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboWaterSol_var1",
							Value = "0"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "1 - Saturated primary package",
					DisplayResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_1___Saturated_primary_package",
					PromptResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_1___Saturated_primary_package_Prompt",
					Value = "cboWaterSol_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboWaterSol_var1",
							Value = "1"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "2 - Unsaturated primary package",
					DisplayResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_2___Unsaturated_primary_package",
					PromptResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_2___Unsaturated_primary_package_Prompt",
					Value = "cboWaterSol_MultiMapOption_3",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboWaterSol_var1",
							Value = "2"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "3 - No correction",
					DisplayResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_3___No_correction",
					PromptResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_3___No_correction_Prompt",
					Value = "cboWaterSol_MultiMapOption_4",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboWaterSol_var1",
							Value = "3"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "4 - Water solubility is one",
					DisplayResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_4___Water_solubility_is_one",
					PromptResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_4___Water_solubility_is_one_Prompt",
					Value = "cboWaterSol_MultiMapOption_5",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboWaterSol_var1",
							Value = "4"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "5 - Unsaturated steam",
					DisplayResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_5___Unsaturated_steam",
					PromptResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_5___Unsaturated_steam_Prompt",
					Value = "cboWaterSol_MultiMapOption_6",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboWaterSol_var1",
							Value = "5"
						}
					}
				}
			},
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.WATER"
			}
		});

		public static readonly CxvPropertyDeclaration cboPropMethod_var1_Property = CxvPropertyDeclaration.Register("cboPropMethod_var1", typeof(MMGenUtl_Input_Proper_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.OPSETNAME"
		});

		public static readonly CxvPropertyDeclaration cboHenryComps_var1_Property = CxvPropertyDeclaration.Register("cboHenryComps_var1", typeof(MMGenUtl_Input_Proper_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.HENRY_COMPS",
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.HENRYL"
			}
		});

		public static readonly CxvPropertyDeclaration cboSimApp_MultiMap_Property = CxvPropertyDeclaration.Register("cboSimApp_MultiMap", typeof(MMGenUtl_Input_Proper_ViewModel), new CxvMultiMapProperty
		{
			Variables = 
			{
				new CxvMultiMapVariable
				{
					Name = "cboSimApp_var1",
					DataPath = "@main.Input.TRUE_COMPS"
				}
			},
			Options = 
			{
				new CxvMultiMapOption
				{
					Display = "True components",
					DisplayResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_True_components",
					Value = "cboSimApp_MultiMapOption_1",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSimApp_var1",
							Value = "YES"
						}
					}
				},
				new CxvMultiMapOption
				{
					Display = "Apparent components",
					DisplayResourceKey = "MMGeneric_BlockO_Proper_ViewModel__CxvMultiMapOption_Display_Apparent_components",
					Value = "cboSimApp_MultiMapOption_2",
					Values = 
					{
						new CxvMultiMapValue
						{
							Variable = "cboSimApp_var1",
							Value = "NO"
						}
					}
				}
			}
		});

		public static readonly CxvPropertyDeclaration cboChemId_var1_Property = CxvPropertyDeclaration.Register("cboChemId_var1", typeof(MMGenUtl_Input_Proper_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.CHEMISTRY"
		});

		private Visibility _electrolytesVisibility;

		private Visibility _petroleumVisibility;

		public object fraPropOptions_state => GetValue(fraPropOptions_state_Property);

		public object fraElecCal_state => GetValue(fraElecCal_state_Property);

		public object cboFreeWatProp_var1 => GetValue(cboFreeWatProp_var1_Property);

		public object cboWaterSol_MultiMap => GetValue(cboWaterSol_MultiMap_Property);

		public object cboPropMethod_var1 => GetValue(cboPropMethod_var1_Property);

		public object cboHenryComps_var1 => GetValue(cboHenryComps_var1_Property);

		public object cboSimApp_MultiMap => GetValue(cboSimApp_MultiMap_Property);

		public object cboChemId_var1 => GetValue(cboChemId_var1_Property);

		public Visibility ElectrolytesVisibility
		{
			get
			{
				return _electrolytesVisibility;
			}
			set
			{
				_electrolytesVisibility = value;
				OnPropertyChanged("ElectrolytesVisibility");
			}
		}

		public Visibility PetroleumVisibility
		{
			get
			{
				return _petroleumVisibility;
			}
			set
			{
				_petroleumVisibility = value;
				OnPropertyChanged("PetroleumVisibility");
			}
		}

		protected override void OnUpdateData()
		{
			base.OnUpdateData();
			if (base.IsInitialUpdate)
			{
				if (CxsConverter.ValueToInt32(ResolveParameter("ElecCal_Frame")) == 0)
				{
					ElectrolytesVisibility = Visibility.Collapsed;
				}
				if (CxsConverter.ValueToInt32(ResolveParameter("PetroOptions_Frame")) == 0)
				{
					PetroleumVisibility = Visibility.Collapsed;
				}
			}
		}
	}
	[ProgId("MMGenUtl.MMGenUtl_Input_Proper")]
	public class MMGenUtl_Input_Proper : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraPropOptions;

		internal MMLabel cboPropMethod_label;

		internal MMComboEdit cboPropMethod;

		internal MMLabel cboHenryComps_label;

		internal MMComboEdit cboHenryComps;

		internal MMGroupBox fraElecCal;

		internal MMLabel cboChemId_label;

		internal MMComboEdit cboChemId;

		internal MMLabel cboSimApp_label;

		internal MMComboEdit cboSimApp;

		internal MMGroupBox fraPetroOptions;

		internal MMLabel cboFreeWatProp_label;

		internal MMComboEdit cboFreeWatProp;

		internal MMLabel cboWaterSol_label;

		internal MMComboEdit cboWaterSol;

		private bool _contentLoaded;

		public MMGenUtl_Input_Proper()
		{
			base.ViewModelType = typeof(MMGenUtl_Input_Proper_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_input_proper.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				fraPropOptions = (MMGroupBox)target;
				break;
			case 2:
				cboPropMethod_label = (MMLabel)target;
				break;
			case 3:
				cboPropMethod = (MMComboEdit)target;
				break;
			case 4:
				cboHenryComps_label = (MMLabel)target;
				break;
			case 5:
				cboHenryComps = (MMComboEdit)target;
				break;
			case 6:
				fraElecCal = (MMGroupBox)target;
				break;
			case 7:
				cboChemId_label = (MMLabel)target;
				break;
			case 8:
				cboChemId = (MMComboEdit)target;
				break;
			case 9:
				cboSimApp_label = (MMLabel)target;
				break;
			case 10:
				cboSimApp = (MMComboEdit)target;
				break;
			case 11:
				fraPetroOptions = (MMGroupBox)target;
				break;
			case 12:
				cboFreeWatProp_label = (MMLabel)target;
				break;
			case 13:
				cboFreeWatProp = (MMComboEdit)target;
				break;
			case 14:
				cboWaterSol_label = (MMLabel)target;
				break;
			case 15:
				cboWaterSol = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMGenUtl_Input_Specif_ViewModel : MMTabPageViewModel
	{
		public class grdComposition_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtValue_var1_Property = CxvPropertyDeclaration.Register("txtValue_var1", typeof(grdComposition_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Input.FRAC.@COMP"
			});

			public static readonly CxvPropertyDeclaration txtXomponent_var1_Property = CxvPropertyDeclaration.Register("txtXomponent_var1", typeof(grdComposition_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.Id,
				DataPath = "@main.Input.FRAC.@COMP"
			});

			public object txtValue_var1 => GetValue(txtValue_var1_Property);

			public object txtXomponent_var1 => GetValue(txtXomponent_var1_Property);
		}

		public static readonly CxvPropertyDeclaration fraComposition_state_Property = CxvPropertyDeclaration.Register("fraComposition_state", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.COMPS"
			}
		});

		public static readonly CxvPropertyDeclaration MMComboBox1_var1_Property = CxvPropertyDeclaration.Register("MMComboBox1_var1", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.BASIS",
			DisplayedCase = CxsDisplayedCase.Lowercase
		});

		public static readonly CxvPropertyDeclaration grdComposition_GridData_Property = CxvPropertyDeclaration.Register("grdComposition_GridData", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVectorProperty
		{
			ItemType = typeof(grdComposition_GridData_ItemTemplate),
			IndexBasis = new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.FRAC",
				UseChildId = true,
				Name = "COMP"
			}
		});

		public static readonly CxvPropertyDeclaration MMSpec1_Property = CxvPropertyDeclaration.Register("MMSpec1", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvSpecProperty
		{
			Options = 
			{
				new CxvSpecOption
				{
					Display = "Temperature",
					DisplayResourceKey = "MMGenUtl_Input_Specif_ViewModel__CxvSpecOption_Display_Temperature",
					DataPath = "@main.Input.TOUT"
				},
				new CxvSpecOption
				{
					Display = "Pressure",
					DisplayResourceKey = "MMGenUtl_Input_Specif_ViewModel__CxvSpecOption_Display_Pressure",
					DataPath = "@main.Input.PRES_OUT"
				},
				new CxvSpecOption
				{
					Display = "Vapor fraction",
					DisplayResourceKey = "MMGenUtl_Input_Specif_ViewModel__CxvSpecOption_Display_Vapor_fraction",
					DataPath = "@main.Input.VFRAC_OUT"
				},
				new CxvSpecOption
				{
					Display = "Degrees of superheat",
					DisplayResourceKey = "MMGenUtl_Input_Specif_ViewModel__CxvSpecOption_Display_Degrees_of_superheat",
					DataPath = "@main.Input.DEGSUP_OUT"
				},
				new CxvSpecOption
				{
					Display = "Degrees of subcooling",
					DisplayResourceKey = "MMGenUtl_Input_Specif_ViewModel__CxvSpecOption_Display_Degrees_of_subcooling",
					DataPath = "@main.Input.DEGSUB_OUT"
				}
			},
			Count = 2
		});

		public static readonly CxvPropertyDeclaration MMSpec1_var1_Property = CxvPropertyDeclaration.Register("MMSpec1_var1", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.TOUT"
		});

		public static readonly CxvPropertyDeclaration MMSpec1_var2_Property = CxvPropertyDeclaration.Register("MMSpec1_var2", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.PRES_OUT"
		});

		public static readonly CxvPropertyDeclaration MMSpec1_var3_Property = CxvPropertyDeclaration.Register("MMSpec1_var3", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.VFRAC_OUT"
		});

		public static readonly CxvPropertyDeclaration MMSpec1_var4_Property = CxvPropertyDeclaration.Register("MMSpec1_var4", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.DEGSUP_OUT"
		});

		public static readonly CxvPropertyDeclaration MMSpec1_var5_Property = CxvPropertyDeclaration.Register("MMSpec1_var5", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.DEGSUB_OUT"
		});

		public static readonly CxvPropertyDeclaration spcSpec1_Property = CxvPropertyDeclaration.Register("spcSpec1", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvSpecProperty
		{
			Options = 
			{
				new CxvSpecOption
				{
					Display = "Temperature",
					DisplayResourceKey = "MMGenUtl_Input_Specif_ViewModel__CxvSpecOption_Display_Temperature_1",
					DataPath = "@main.Input.TIN"
				},
				new CxvSpecOption
				{
					Display = "Pressure",
					DisplayResourceKey = "MMGenUtl_Input_Specif_ViewModel__CxvSpecOption_Display_Pressure_1",
					DataPath = "@main.Input.PRES"
				},
				new CxvSpecOption
				{
					Display = "Vapor fraction",
					DisplayResourceKey = "MMGenUtl_Input_Specif_ViewModel__CxvSpecOption_Display_Vapor_fraction_1",
					DataPath = "@main.Input.VFRAC"
				},
				new CxvSpecOption
				{
					Display = "Degrees of superheat",
					DisplayResourceKey = "MMGenUtl_Input_Specif_ViewModel__CxvSpecOption_Display_Degrees_of_superheat_1",
					DataPath = "@main.Input.DEGSUP_IN"
				},
				new CxvSpecOption
				{
					Display = "Degrees of subcooling",
					DisplayResourceKey = "MMGenUtl_Input_Specif_ViewModel__CxvSpecOption_Display_Degrees_of_subcooling_1",
					DataPath = "@main.Input.DEGSUB_IN"
				}
			},
			Count = 2
		});

		public static readonly CxvPropertyDeclaration spcSpec1_var1_Property = CxvPropertyDeclaration.Register("spcSpec1_var1", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.TIN"
		});

		public static readonly CxvPropertyDeclaration spcSpec1_var2_Property = CxvPropertyDeclaration.Register("spcSpec1_var2", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.PRES"
		});

		public static readonly CxvPropertyDeclaration spcSpec1_var3_Property = CxvPropertyDeclaration.Register("spcSpec1_var3", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.VFRAC"
		});

		public static readonly CxvPropertyDeclaration spcSpec1_var4_Property = CxvPropertyDeclaration.Register("spcSpec1_var4", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.DEGSUP_IN"
		});

		public static readonly CxvPropertyDeclaration spcSpec1_var5_Property = CxvPropertyDeclaration.Register("spcSpec1_var5", typeof(MMGenUtl_Input_Specif_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Input.DEGSUB_IN"
		});

		public object fraComposition_state => GetValue(fraComposition_state_Property);

		public object MMComboBox1_var1 => GetValue(MMComboBox1_var1_Property);

		public object grdComposition_GridData => GetValue(grdComposition_GridData_Property);

		public object MMSpec1 => GetValue(MMSpec1_Property);

		public object MMSpec1_var1 => GetValue(MMSpec1_var1_Property);

		public object MMSpec1_var2 => GetValue(MMSpec1_var2_Property);

		public object MMSpec1_var3 => GetValue(MMSpec1_var3_Property);

		public object MMSpec1_var4 => GetValue(MMSpec1_var4_Property);

		public object MMSpec1_var5 => GetValue(MMSpec1_var5_Property);

		public object spcSpec1 => GetValue(spcSpec1_Property);

		public object spcSpec1_var1 => GetValue(spcSpec1_var1_Property);

		public object spcSpec1_var2 => GetValue(spcSpec1_var2_Property);

		public object spcSpec1_var3 => GetValue(spcSpec1_var3_Property);

		public object spcSpec1_var4 => GetValue(spcSpec1_var4_Property);

		public object spcSpec1_var5 => GetValue(spcSpec1_var5_Property);
	}
	[ProgId("MMGenUtl.MMGenUtl_Input_Specif")]
	public class MMGenUtl_Input_Specif : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraVariables;

		internal MMComboEdit spcSpec1_combo;

		internal MMVariableEdit spcSpec1;

		internal MMComboEdit spcSpec2_combo;

		internal MMVariableEdit spcSpec2;

		internal MMGroupBox MMFrame1;

		internal MMComboEdit MMSpec1_combo;

		internal MMVariableEdit MMSpec1;

		internal MMComboEdit MMSpec2_combo;

		internal MMVariableEdit MMSpec2;

		internal MMGroupBox fraComposition;

		internal MMLabel MMComboBox1_label;

		internal MMComboEdit MMComboBox1;

		internal MMScrollArea grdComposition;

		private bool _contentLoaded;

		public MMGenUtl_Input_Specif()
		{
			base.ViewModelType = typeof(MMGenUtl_Input_Specif_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_input_specif.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				fraVariables = (MMGroupBox)target;
				break;
			case 2:
				spcSpec1_combo = (MMComboEdit)target;
				break;
			case 3:
				spcSpec1 = (MMVariableEdit)target;
				break;
			case 4:
				spcSpec2_combo = (MMComboEdit)target;
				break;
			case 5:
				spcSpec2 = (MMVariableEdit)target;
				break;
			case 6:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 7:
				MMSpec1_combo = (MMComboEdit)target;
				break;
			case 8:
				MMSpec1 = (MMVariableEdit)target;
				break;
			case 9:
				MMSpec2_combo = (MMComboEdit)target;
				break;
			case 10:
				MMSpec2 = (MMVariableEdit)target;
				break;
			case 11:
				fraComposition = (MMGroupBox)target;
				break;
			case 12:
				MMComboBox1_label = (MMLabel)target;
				break;
			case 13:
				MMComboBox1 = (MMComboEdit)target;
				break;
			case 14:
				grdComposition = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMGenUtl_ObjMan_ViewModel : MMTabPageViewModel
	{
		public class grdChild_GridData_ItemTemplate : MMViewModel
		{
			private bool _isRenaming;

			public static readonly CxvPropertyDeclaration MMComboBox1_var1_Property = CxvPropertyDeclaration.Register("MMComboBox1_var1", typeof(grdChild_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.String,
				DataPath = "@main.@y.Input.UTILITY_TYPE",
				IsReadOnly = true,
				IsCalculated = false
			});

			public static readonly CxvPropertyDeclaration txtName_var1_Property = CxvPropertyDeclaration.Register("txtName_var1", typeof(grdChild_GridData_ItemTemplate), new CxvCustomTooltipProperty
			{
				ExposeAs = CxvVariableTypeCode.Id,
				DataPath = "@main.@y",
				IsCalculated = false
			});

			public static readonly CxvPropertyDeclaration cboStatus_Status_Property = CxvPropertyDeclaration.Register("cboStatus_Status", typeof(grdChild_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.String,
				DataPath = "@main.@y",
				DataAttribute = "status",
				IsReadOnly = true,
				IsCalculated = false
			});

			public static readonly CxvPropertyDeclaration txtDescription_var1_Property = CxvPropertyDeclaration.Register("txtDescription_var1", typeof(grdChild_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.@y.Input.DESCRIPTION"
			});

			public object MMComboBox1_var1 => GetValue(MMComboBox1_var1_Property);

			public object txtName_var1 => GetValue(txtName_var1_Property);

			public object cboStatus_Status => GetValue(cboStatus_Status_Property);

			public object txtDescription_var1 => GetValue(txtDescription_var1_Property);

			protected override void OnSubPropertyDataChanging(SubPropertyDataChangingEventArgs args)
			{
				if (!_isRenaming && args.Property.Name == "txtName_var1" && args.SubPropertyName == "Value" && !string.Equals(args.OldValue as string, args.NewValue as string, StringComparison.InvariantCultureIgnoreCase))
				{
					_isRenaming = true;
					string childId = args.NewValue as string;
					bool? flag = ShowRenameChildDialog(ExpandDataPath("@main"), ref childId, silently: true);
					bool flag2 = true;
					if (!((flag.GetValueOrDefault() == flag2) & flag.HasValue))
					{
						args.Cancel = true;
						_isRenaming = false;
						return;
					}
					_isRenaming = false;
				}
				base.OnSubPropertyDataChanging(args);
			}

			public string GetId()
			{
				return CxsConverter.ValueToString(ResolveViewPropertyPath("txtName_var1.Value", null));
			}
		}

		public static readonly CxvPropertyDeclaration chkUtlReqd_var1_Property = CxvPropertyDeclaration.Register("chkUtlReqd_var1", typeof(MMGenUtl_ObjMan_ViewModel), new CxvBooleanProperty
		{
			DataPath = "Top.appModelV8.Setup.Sim-Options.Input.UTL_REQD",
			TrueValue = "YES",
			FalseValue = "NO",
			DefaultValue = false
		});

		private ICommand _cmdAdd_Command;

		public static CxvPropertyDeclaration cmdAddCanExecuteProperty = CxvPropertyDeclaration.Register("cmdAddCanExecute", typeof(MMGenUtl_ObjMan_ViewModel), new CxvLogicalProperty
		{
			DataPath = "@main",
			Operator = CxvLogicalOperator.CanInvokeAction,
			Value = "InsertChild"
		});

		private ICommand _cmdEdit_Command;

		public static CxvPropertyDeclaration cmdEditCanExecuteProperty = CxvPropertyDeclaration.Register("cmdEditCanExecute", typeof(MMGenUtl_ObjMan_ViewModel), new CxvLogicalProperty
		{
			PropertyPath = "AllSelectedRecordsCount",
			Operator = CxvLogicalOperator.Equal,
			Value = 1
		});

		private ICommand _cmdDelete_Command;

		public static CxvPropertyDeclaration cmdDeleteCanExecuteProperty = CxvPropertyDeclaration.Register("cmdDeleteCanExecute", typeof(MMGenUtl_ObjMan_ViewModel), new CxvLogicalProperty
		{
			Operator = CxvLogicalOperator.And,
			Tests = 
			{
				new CxvLogicalTest
				{
					DataPath = "@main",
					Operator = CxvLogicalOperator.CanInvokeAction,
					Value = "DeleteChild"
				}
			}
		});

		private ICommand _cmdRename_Command;

		public static CxvPropertyDeclaration cmdRenameCanExecuteProperty = CxvPropertyDeclaration.Register("cmdRenameCanExecute", typeof(MMGenUtl_ObjMan_ViewModel), new CxvLogicalProperty
		{
			Operator = CxvLogicalOperator.And,
			Tests = 
			{
				new CxvLogicalTest
				{
					PropertyPath = "AllSelectedRecordsCount",
					Value = 1
				},
				new CxvLogicalTest
				{
					DataPath = "@main",
					Operator = CxvLogicalOperator.CanInvokeAction,
					Value = "RenameChild"
				}
			}
		});

		private ICommand _cmdHide_Command;

		public static CxvPropertyDeclaration cmdHideCanExecuteProperty = CxvPropertyDeclaration.Register("cmdHideCanExecute", typeof(MMGenUtl_ObjMan_ViewModel), new CxvLogicalProperty
		{
			Operator = CxvLogicalOperator.And,
			Tests = 
			{
				new CxvLogicalTest
				{
					PropertyPath = "AllSelectedRecordsCount",
					Operator = CxvLogicalOperator.GreaterThan,
					Value = 0
				},
				new CxvLogicalTest
				{
					DataPath = "@main",
					Operator = CxvLogicalOperator.CanInvokeAction,
					Value = "HideChild"
				}
			}
		});

		private ICommand _cmdReveal_Command;

		public static CxvPropertyDeclaration cmdRevealCanExecuteProperty = CxvPropertyDeclaration.Register("cmdRevealCanExecute", typeof(MMGenUtl_ObjMan_ViewModel), new CxvLogicalProperty
		{
			DataPath = "@main",
			Operator = CxvLogicalOperator.CanInvokeAction,
			Value = "RevealChild"
		});

		private ICommand _cmdCopy_Command;

		public static CxvPropertyDeclaration cmdCopyCanExecuteProperty = CxvPropertyDeclaration.Register("cmdCopyCanExecute", typeof(MMGenUtl_ObjMan_ViewModel), new CxvLogicalProperty
		{
			Operator = CxvLogicalOperator.And,
			Tests = 
			{
				new CxvLogicalTest
				{
					PropertyPath = "AllSelectedRecordsCount",
					Operator = CxvLogicalOperator.GreaterThan,
					Value = 0
				}
			}
		});

		private ICommand _cmdPaste_Command;

		public static CxvPropertyDeclaration cmdPaste_CommandCanExecuteProperty = CxvPropertyDeclaration.Register("cmdPaste_CommandCanExecute", typeof(MMGenUtl_ObjMan_ViewModel), new CxvLogicalProperty
		{
			Operator = CxvLogicalOperator.Equal,
			PropertyPath = "CanPaste",
			Value = true
		});

		private ICommand _cmdExport_Command;

		public static CxvPropertyDeclaration cmdExportCanExecuteProperty = CxvPropertyDeclaration.Register("cmdExportCanExecute", typeof(MMGenUtl_ObjMan_ViewModel), new CxvLogicalProperty
		{
			PropertyPath = "AllSelectedRecordsCount",
			Operator = CxvLogicalOperator.Equal,
			Value = 1
		});

		private ICommand _grid_RowDoubleClickCommand;

		private int _allSelectedRecordsCount;

		private ObservableCollection<int> _SelectedRowIndexes;

		public static readonly CxvPropertyDeclaration grdChild_GridData_Property = CxvPropertyDeclaration.Register("grdChild_GridData", typeof(MMGenUtl_ObjMan_ViewModel), new CxvVectorProperty
		{
			ItemType = typeof(grdChild_GridData_ItemTemplate),
			IndexBasis = new CxvChildCountIndexBasis
			{
				DataPath = "@main",
				UseChildId = true,
				Name = "y",
				ProxyRow = false
			}
		});

		public object chkUtlReqd_var1 => GetValue(chkUtlReqd_var1_Property);

		public ICommand cmdAdd_Command
		{
			get
			{
				if (_cmdAdd_Command == null)
				{
					_cmdAdd_Command = new CxvDelegateCommand<object>(cmdAdd_CommandExecute, this, cmdAddCanExecuteProperty.Name + ".Value");
				}
				return _cmdAdd_Command;
			}
		}

		public CxvLogicalPropertyData cmdAddCanExecute => GetValue(cmdAddCanExecuteProperty) as CxvLogicalPropertyData;

		public ICommand cmdEdit_Command
		{
			get
			{
				if (_cmdEdit_Command == null)
				{
					_cmdEdit_Command = new CxvDelegateCommand<object>(cmdEdit_CommandExecute, this, cmdEditCanExecuteProperty.Name + ".Value");
				}
				return _cmdEdit_Command;
			}
		}

		public CxvLogicalPropertyData cmdEditCanExecute => GetValue(cmdEditCanExecuteProperty) as CxvLogicalPropertyData;

		public ICommand cmdDelete_Command
		{
			get
			{
				if (_cmdDelete_Command == null)
				{
					_cmdDelete_Command = new CxvDelegateCommand<object>(cmdDelete_CommandExecute, this, cmdDeleteCanExecuteProperty.Name + ".Value");
				}
				return _cmdDelete_Command;
			}
		}

		public CxvLogicalPropertyData cmdDeleteCanExecute => GetValue(cmdDeleteCanExecuteProperty) as CxvLogicalPropertyData;

		public ICommand cmdRename_Command
		{
			get
			{
				if (_cmdRename_Command == null)
				{
					_cmdRename_Command = new CxvDelegateCommand<object>(cmdRename_CommandExecute, this, cmdRenameCanExecuteProperty.Name + ".Value");
				}
				return _cmdRename_Command;
			}
		}

		public CxvLogicalPropertyData cmdRenameCanExecute => GetValue(cmdRenameCanExecuteProperty) as CxvLogicalPropertyData;

		public ICommand cmdHide_Command
		{
			get
			{
				if (_cmdHide_Command == null)
				{
					_cmdHide_Command = new CxvDelegateCommand<object>(cmdHide_CommandExecute, this, cmdHideCanExecuteProperty.Name + ".Value");
				}
				return _cmdHide_Command;
			}
		}

		public CxvLogicalPropertyData cmdHideCanExecute => GetValue(cmdHideCanExecuteProperty) as CxvLogicalPropertyData;

		public ICommand cmdReveal_Command
		{
			get
			{
				if (_cmdReveal_Command == null)
				{
					_cmdReveal_Command = new CxvDelegateCommand<object>(cmdReveal_CommandExecute, this, cmdRevealCanExecuteProperty.Name + ".Value");
				}
				return _cmdReveal_Command;
			}
		}

		public CxvLogicalPropertyData cmdRevealCanExecute => GetValue(cmdRevealCanExecuteProperty) as CxvLogicalPropertyData;

		public ICommand cmdCopy_Command
		{
			get
			{
				if (_cmdCopy_Command == null)
				{
					_cmdCopy_Command = new CxvDelegateCommand<object>(cmdCopy_CommandExecute, this, cmdCopyCanExecuteProperty.Name + ".Value");
				}
				return _cmdCopy_Command;
			}
		}

		public CxvLogicalPropertyData cmdCopyCanExecute => GetValue(cmdCopyCanExecuteProperty) as CxvLogicalPropertyData;

		public ICommand cmdPaste_Command
		{
			get
			{
				if (_cmdPaste_Command == null)
				{
					_cmdPaste_Command = new CxvDelegateCommand<object>(cmdPaste_CommandExecute, this, cmdPaste_CommandCanExecuteProperty.Name + ".Value");
				}
				return _cmdPaste_Command;
			}
		}

		public bool CanPaste
		{
			get
			{
				if (!ClipboardWrapper.ContainsData("Aspen Plus Selection"))
				{
					return false;
				}
				if (ClipboardWrapper.ContainsData("Aspen Plus Selection Type"))
				{
					IDataObject dataObject = ClipboardWrapper.GetDataObject();
					if (dataObject != null && dataObject.GetData("Aspen Plus Selection Type", autoConvert: false) is MemoryStream stream)
					{
						string text = new StreamReader(stream).ReadToEnd();
						string path = ExpandDataPath("@main");
						try
						{
							return CxsConverter.ValueToActionStatusDetails(base.ResolvedCxsProvider.BatchGet(path, "action_status", "CanPaste:" + text)).CanInvoke;
						}
						catch (Exception)
						{
						}
					}
				}
				return true;
			}
		}

		public CxvLogicalPropertyData cmdPaste_CommandCanExecute => GetValue(cmdPaste_CommandCanExecuteProperty) as CxvLogicalPropertyData;

		public ICommand cmdExport_Command
		{
			get
			{
				if (_cmdExport_Command == null)
				{
					_cmdExport_Command = new CxvDelegateCommand<object>(cmdExport_CommandExecute, this, cmdExportCanExecuteProperty.Name + ".Value");
				}
				return _cmdExport_Command;
			}
		}

		public CxvLogicalPropertyData cmdExportCanExecute => GetValue(cmdExportCanExecuteProperty) as CxvLogicalPropertyData;

		public ICommand grid_RowDoubleClickCommand
		{
			get
			{
				if (_grid_RowDoubleClickCommand == null)
				{
					_grid_RowDoubleClickCommand = new CxvDelegateCommand<object>(grid_RowDoubleClickCommandExecute);
				}
				return _grid_RowDoubleClickCommand;
			}
		}

		public int AllSelectedRecordsCount
		{
			get
			{
				return _allSelectedRecordsCount;
			}
			set
			{
				if (value != _allSelectedRecordsCount)
				{
					_allSelectedRecordsCount = value;
					OnAllSelectedRecordsCountChanged();
				}
			}
		}

		public ObservableCollection<int> SelectedRowIndexes
		{
			get
			{
				return _SelectedRowIndexes;
			}
			set
			{
				_SelectedRowIndexes = value;
				if (_SelectedRowIndexes != null)
				{
					_SelectedRowIndexes.CollectionChanged += _SelectedRowIndexes_CollectionChanged;
				}
			}
		}

		public object grdChild_GridData => GetValue(grdChild_GridData_Property);

		public event EventHandler CanPasteChanged;

		public event EventHandler AllSelectedRecordsCountChanged;

		private void cmdAdd_CommandExecute(object parameter)
		{
			if (base.UnityContainer == null)
			{
				return;
			}
			string inputValue = ExpandDataPathAndGet("@main", "default_name") as string;
			GetCustomUserInputEventArgs e = new GetCustomUserInputEventArgs();
			e.InputValue = inputValue;
			e.CustomUserAction = GetCustomUserInputEventArgs.CustomAction.NewUtility;
			e.Parameters = new Dictionary<string, object> { 
			{
				"ExistingIDs",
				ExistingIds(ExpandDataPath("@main"))
			} };
			base.UnityContainer.Resolve<IEventAggregator>(Array.Empty<ResolverOverride>()).GetEvent<GetCustomUserInputEvent>().Publish(e);
			bool? dialogResult = e.DialogResult;
			if (dialogResult.GetValueOrDefault(false))
			{			string text = e.InputValue as string;
			CxvActionResult cxvActionResult = InvokeAction(ExpandDataPath("@main"), "InsertChild", true, text);
			if (!cxvActionResult.Succeeded)
			{
				if (!string.IsNullOrEmpty(cxvActionResult.Error))
				{
					ShowMessageBox(new ShowMessageBoxEventArgs
					{
						Message = cxvActionResult.Error,
						Title = base.ResolvedCxsProvider.GetI18nApplicationName(),
						MsgBoxButton = MessageBoxButton.OK,
						MsgBoxImage = MessageBoxImage.Asterisk
					});
				}
			}
			else
			{
				if (e.OtherInput is List<CxsBatchRequest> list)
				{
					if (base.ResolvedCxsProvider != null)
					{
						base.ResolvedCxsProvider.BatchSetNoRefresh(new CxsBatchRequestData(list.ToArray()));
					}
				}
				UpdateDisplay();
				UpdateAll();
				string path = ".!" + text;
				GoToNode(path);
			}
		}}

		private void cmdEdit_CommandExecute(object parameter)
		{
			if (AllSelectedRecordsCount != 1)
			{
				return;
			}
			foreach (string current in GetSelectedIds())
			{
				string path = ".!" + current;
				GoToNode(path);
				break;
			}
		}

		private void cmdDelete_CommandExecute(object parameter)
		{
			Collection<string> collection = new Collection<string>();
			foreach (string selectedId in GetSelectedIds())
			{
				collection.Add(selectedId);
			}
			string parentPath = CxsConverter.ValueToString(ResolveParameter("main", null));
			DeleteChildren(parentPath, collection);
		}

		private void cmdRename_CommandExecute(object parameter)
		{
			int allSelectedRecordsCount = AllSelectedRecordsCount;
			if (allSelectedRecordsCount == 0)
			{
				ShowMessageBox(new ShowMessageBoxEventArgs
				{
					Message = WpfFormsResources.MMGenUtl_ObjMan_Display1,
					Title = ""
				});
				return;
			}
			if (allSelectedRecordsCount > 1)
			{
				ShowMessageBox(new ShowMessageBoxEventArgs
				{
					Message = WpfFormsResources.MMGenUtl_ObjMan_Display2,
					Title = ""
				});
				return;
			}
			string parentPath = CxsConverter.ValueToString(ResolveParameter("main", null));
			string text = "";
			foreach (string selectedId in GetSelectedIds())
			{
				text = selectedId;
				ShowRenameChildDialog(parentPath, ref text);
			}
		}

		private void cmdHide_CommandExecute(object parameter)
		{
			Collection<string> collection = new Collection<string>();
			foreach (string selectedId in GetSelectedIds())
			{
				collection.Add(selectedId);
			}
			string parentPath = CxsConverter.ValueToString(ResolveParameter("main", null));
			HideNodeChildren(parentPath, collection);
		}

		private void cmdReveal_CommandExecute(object parameter)
		{
			string path = CxsConverter.ValueToString(ResolveParameter("main", null));
			ShowRevealNodeDialog(path);
		}

		private void cmdCopy_CommandExecute(object parameter)
		{
			if (AllSelectedRecordsCount < 1)
			{
				ShowMessageBox(new ShowMessageBoxEventArgs
				{
					Message = WpfFormsResources.MMGenUtl_ObjMan_Display3,
					Title = WpfFormsResources.MMGenUtl_ObjMan_Display4,
					MsgBoxButton = MessageBoxButton.OK,
					MsgBoxImage = MessageBoxImage.Asterisk
				});
				return;
			}
			Collection<string> collection = new Collection<string>();
			foreach (string selectedId in GetSelectedIds())
			{
				collection.Add(selectedId);
			}
			string parentPath = CxsConverter.ValueToString(ResolveParameter("main", null));
			CopyChildren(parentPath, collection);
			OnCanPasteChanged();
		}

		private void OnCanPasteChanged()
		{
			if (this.CanPasteChanged != null)
			{
				this.CanPasteChanged(this, EventArgs.Empty);
			}
			OnPropertyChanged("CanPaste");
		}

		private void cmdPaste_CommandExecute(object parameter)
		{
			if (!CanPaste)
			{
				OnCanPasteChanged();
				return;
			}
			string parentPath = CxsConverter.ValueToString(ResolveParameter("main", null));
			DoPaste(parentPath);
		}

		private void cmdExport_CommandExecute(object parameter)
		{
			if (AllSelectedRecordsCount != 1)
			{
				return;
			}
			foreach (string selectedId in GetSelectedIds())
			{
				string text = ExpandDataPath("@main." + selectedId);
				CxvActionResult cxvActionResult = InvokeAction("Top.appModelV8.Custom Actions", "HappNode", false, text);
				if (cxvActionResult.Succeeded && cxvActionResult.Result is IHNode iHNode)
				{
					iHNode.Export();
				}
			}
		}

		private void grid_RowDoubleClickCommandExecute(object parameter)
		{
			IEnumerator<string> enumerator = GetSelectedIds().GetEnumerator();
			if (enumerator.MoveNext())
			{
				string path = ".!" + enumerator.Current;
				GoToNode(path);
			}
		}

		private void OnAllSelectedRecordsCountChanged()
		{
			if (this.AllSelectedRecordsCountChanged != null)
			{
				this.AllSelectedRecordsCountChanged(this, EventArgs.Empty);
			}
			OnPropertyChanged("AllSelectedRecordsCount");
		}

		private void _SelectedRowIndexes_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			OnCanPasteChanged();
		}

		private IEnumerable<string> GetSelectedIds()
		{
			IList gridData = grdChild_GridData as IList;
			List<int> list = new List<int>();
			foreach (int selectedRowIndex in SelectedRowIndexes)
			{
				list.Add(selectedRowIndex);
			}
			foreach (int item in list)
			{
				grdChild_GridData_ItemTemplate grdChild_GridData_ItemTemplate = gridData[item] as grdChild_GridData_ItemTemplate;
				yield return grdChild_GridData_ItemTemplate.GetId();
			}
		}

		public void SetSelectedRowFromScript(int row)
		{
			if (SelectedRowIndexes == null)
			{
				SelectedRowIndexes = new ObservableCollection<int>();
			}
			SelectedRowIndexes.Clear();
			SelectedRowIndexes.Add(row);
			AllSelectedRecordsCount = 1;
		}
	}
	[ProgId("MMGenUtl.MMGenUtl_ObjMan")]
	public class MMGenUtl_ObjMan : MMTabPage, IComponentConnector
	{
		internal MMFlatButton cmdAdd;

		internal MMFlatButton cmdExport;

		internal MMFlatButton cmdEdit;

		internal MMFlatButton cmdCopy;

		internal MMFlatButton cmdPaste;

		internal MMCheckBox chkRequireUtilitiesSpec;

		internal MMScrollAreaMS grdChild;

		private bool _contentLoaded;

		public MMGenUtl_ObjMan()
		{
			base.ViewModelType = typeof(MMGenUtl_ObjMan_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_objman.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				cmdAdd = (MMFlatButton)target;
				break;
			case 2:
				cmdExport = (MMFlatButton)target;
				break;
			case 3:
				cmdEdit = (MMFlatButton)target;
				break;
			case 4:
				cmdCopy = (MMFlatButton)target;
				break;
			case 5:
				cmdPaste = (MMFlatButton)target;
				break;
			case 6:
				chkRequireUtilitiesSpec = (MMCheckBox)target;
				break;
			case 7:
				grdChild = (MMScrollAreaMS)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMGenUtl_Result_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration utl_usage_Property = CxvPropertyDeclaration.Register("utl_usage", typeof(MMGenUtl_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_USAGE"
		});

		public static readonly CxvPropertyDeclaration temp_Property = CxvPropertyDeclaration.Register("temp", typeof(MMGenUtl_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_IN_TEMP"
		});

		public static readonly CxvPropertyDeclaration pres_Property = CxvPropertyDeclaration.Register("pres", typeof(MMGenUtl_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_IN_PRES"
		});

		public static readonly CxvPropertyDeclaration hcvalue_Property = CxvPropertyDeclaration.Register("hcvalue", typeof(MMGenUtl_Result_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.HCOOL_VALUE"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMGenUtl_Result_ViewModel), new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@utl_usage" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMGenUtl_Result_ViewModel), new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@hcvalue", "@pres", "@temp" }
		});

		public object utl_usage => GetValue(utl_usage_Property);

		public object temp => GetValue(temp_Property);

		public object pres => GetValue(pres_Property);

		public object hcvalue => GetValue(hcvalue_Property);

		public object tab0_var => GetValue(tab0_var_Property);

		public object tab1_var => GetValue(tab1_var_Property);
	}
	[ProgId("MMGenUtl.MMGenUtl_Result")]
	public class MMGenUtl_Result : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabInput;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tabStatus;

		private bool _contentLoaded;

		public MMGenUtl_Result()
		{
			base.ViewModelType = typeof(MMGenUtl_Result_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_result.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				tabInput = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tabStatus = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMGenUtl_Result_State_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration lbtuHCValue_var1_Property = CxvPropertyDeclaration.Register("lbtuHCValue_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.HCOOL_VALUE"
		});

		public static readonly CxvPropertyDeclaration MMLBUText5_var1_Property = CxvPropertyDeclaration.Register("MMLBUText5_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_DEGSUB_OUT"
		});

		public static readonly CxvPropertyDeclaration MMLBUText3_var1_Property = CxvPropertyDeclaration.Register("MMLBUText3_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_DEGSUB_IN"
		});

		public static readonly CxvPropertyDeclaration MMLBUText2_var1_Property = CxvPropertyDeclaration.Register("MMLBUText2_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_DEGSUP_OUT"
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_DEGSUP_IN"
		});

		public static readonly CxvPropertyDeclaration MMLBUText7_var1_Property = CxvPropertyDeclaration.Register("MMLBUText7_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_OUT_VFRAC"
		});

		public static readonly CxvPropertyDeclaration MMLBUText4_var1_Property = CxvPropertyDeclaration.Register("MMLBUText4_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_IN_VFRAC"
		});

		public static readonly CxvPropertyDeclaration MMLBUText12_var1_Property = CxvPropertyDeclaration.Register("MMLBUText12_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_ENTH_OUT"
		});

		public static readonly CxvPropertyDeclaration MMLBUText13_var1_Property = CxvPropertyDeclaration.Register("MMLBUText13_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_ENTH_IN"
		});

		public static readonly CxvPropertyDeclaration MMLBUText8_var1_Property = CxvPropertyDeclaration.Register("MMLBUText8_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_IN_TEMP"
		});

		public static readonly CxvPropertyDeclaration MMLBUText9_var1_Property = CxvPropertyDeclaration.Register("MMLBUText9_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_OUT_TEMP"
		});

		public static readonly CxvPropertyDeclaration MMLBUText10_var1_Property = CxvPropertyDeclaration.Register("MMLBUText10_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_IN_PRES"
		});

		public static readonly CxvPropertyDeclaration MMLBUText11_var1_Property = CxvPropertyDeclaration.Register("MMLBUText11_var1", typeof(MMGenUtl_Result_State_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_OUT_PRES"
		});

		public object lbtuHCValue_var1 => GetValue(lbtuHCValue_var1_Property);

		public object MMLBUText5_var1 => GetValue(MMLBUText5_var1_Property);

		public object MMLBUText3_var1 => GetValue(MMLBUText3_var1_Property);

		public object MMLBUText2_var1 => GetValue(MMLBUText2_var1_Property);

		public object MMLBUText1_var1 => GetValue(MMLBUText1_var1_Property);

		public object MMLBUText7_var1 => GetValue(MMLBUText7_var1_Property);

		public object MMLBUText4_var1 => GetValue(MMLBUText4_var1_Property);

		public object MMLBUText12_var1 => GetValue(MMLBUText12_var1_Property);

		public object MMLBUText13_var1 => GetValue(MMLBUText13_var1_Property);

		public object MMLBUText8_var1 => GetValue(MMLBUText8_var1_Property);

		public object MMLBUText9_var1 => GetValue(MMLBUText9_var1_Property);

		public object MMLBUText10_var1 => GetValue(MMLBUText10_var1_Property);

		public object MMLBUText11_var1 => GetValue(MMLBUText11_var1_Property);
	}
	[ProgId("MMGenUtl.MMGenUtl_Result_State")]
	public class MMGenUtl_Result_State : MMTabPage, IComponentConnector
	{
		internal MMLabel MMLBUText8_label;

		internal MMVariableEdit MMLBUText8;

		internal MMLabel MMLBUText9_label;

		internal MMVariableEdit MMLBUText9;

		internal MMLabel MMLBUText10_label;

		internal MMVariableEdit MMLBUText10;

		internal MMLabel MMLBUText11_label;

		internal MMVariableEdit MMLBUText11;

		internal MMLabel MMLBUText4_label;

		internal MMVariableEdit MMLBUText4;

		internal MMLabel MMLBUText7_label;

		internal MMVariableEdit MMLBUText7;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMLabel MMLBUText2_label;

		internal MMVariableEdit MMLBUText2;

		internal MMLabel MMLBUText3_label;

		internal MMVariableEdit MMLBUText3;

		internal MMLabel MMLBUText5_label;

		internal MMVariableEdit MMLBUText5;

		internal MMLabel MMLBUText13_label;

		internal MMVariableEdit MMLBUText13;

		internal MMLabel MMLBUText12_label;

		internal MMVariableEdit MMLBUText12;

		internal MMLabel lbtuHCValue_label;

		internal MMVariableEdit lbtuHCValue;

		private bool _contentLoaded;

		public MMGenUtl_Result_State()
		{
			base.ViewModelType = typeof(MMGenUtl_Result_State_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_result_state.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				MMLBUText8_label = (MMLabel)target;
				break;
			case 2:
				MMLBUText8 = (MMVariableEdit)target;
				break;
			case 3:
				MMLBUText9_label = (MMLabel)target;
				break;
			case 4:
				MMLBUText9 = (MMVariableEdit)target;
				break;
			case 5:
				MMLBUText10_label = (MMLabel)target;
				break;
			case 6:
				MMLBUText10 = (MMVariableEdit)target;
				break;
			case 7:
				MMLBUText11_label = (MMLabel)target;
				break;
			case 8:
				MMLBUText11 = (MMVariableEdit)target;
				break;
			case 9:
				MMLBUText4_label = (MMLabel)target;
				break;
			case 10:
				MMLBUText4 = (MMVariableEdit)target;
				break;
			case 11:
				MMLBUText7_label = (MMLabel)target;
				break;
			case 12:
				MMLBUText7 = (MMVariableEdit)target;
				break;
			case 13:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 14:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 15:
				MMLBUText2_label = (MMLabel)target;
				break;
			case 16:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			case 17:
				MMLBUText3_label = (MMLabel)target;
				break;
			case 18:
				MMLBUText3 = (MMVariableEdit)target;
				break;
			case 19:
				MMLBUText5_label = (MMLabel)target;
				break;
			case 20:
				MMLBUText5 = (MMVariableEdit)target;
				break;
			case 21:
				MMLBUText13_label = (MMLabel)target;
				break;
			case 22:
				MMLBUText13 = (MMVariableEdit)target;
				break;
			case 23:
				MMLBUText12_label = (MMLabel)target;
				break;
			case 24:
				MMLBUText12 = (MMVariableEdit)target;
				break;
			case 25:
				lbtuHCValue_label = (MMLabel)target;
				break;
			case 26:
				lbtuHCValue = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMGenUtl_Result_Summar_ViewModel : MMTabPageViewModel
	{
		public class MMScrollArea1_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox6_var1_Property = CxvPropertyDeclaration.Register("MMTextBox6_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.BLK_CO2RATE.@y"
			});

			public static readonly CxvPropertyDeclaration MMTextBox1_duty_Property = CxvPropertyDeclaration.Register("MMTextBox1_duty", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.UTL_DUTY.@y"
			});

			public static readonly CxvPropertyDeclaration MMTextBox5_var1_Property = CxvPropertyDeclaration.Register("MMTextBox5_var1", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.UTL_COST.@y"
			});

			public static readonly CxvPropertyDeclaration MMTextBox4_usage_Property = CxvPropertyDeclaration.Register("MMTextBox4_usage", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.UTL_USAGE.@y"
			});

			public static readonly CxvPropertyDeclaration MMTextBox3_blktype_Property = CxvPropertyDeclaration.Register("MMTextBox3_blktype", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				DataPath = "@main.Output.BLK_TYPE.@y"
			});

			public static readonly CxvPropertyDeclaration MMTextBox2_blkid_Property = CxvPropertyDeclaration.Register("MMTextBox2_blkid", typeof(MMScrollArea1_GridData_ItemTemplate), new CxvVariableProperty
			{
				ExposeAs = CxvVariableTypeCode.Id,
				DataPath = "@main.Output.UTL_USAGE.@y"
			});

			public object MMTextBox6_var1 => GetValue(MMTextBox6_var1_Property);

			public object MMTextBox1_duty => GetValue(MMTextBox1_duty_Property);

			public object MMTextBox5_var1 => GetValue(MMTextBox5_var1_Property);

			public object MMTextBox4_usage => GetValue(MMTextBox4_usage_Property);

			public object MMTextBox3_blktype => GetValue(MMTextBox3_blktype_Property);

			public object MMTextBox2_blkid => GetValue(MMTextBox2_blkid_Property);
		}

		public static readonly CxvPropertyDeclaration MMLBUText4_var1_Property = CxvPropertyDeclaration.Register("MMLBUText4_var1", typeof(MMGenUtl_Result_Summar_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.BLK_CO2RATE"
		});

		public static readonly CxvPropertyDeclaration MMLBUText3_var1_Property = CxvPropertyDeclaration.Register("MMLBUText3_var1", typeof(MMGenUtl_Result_Summar_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_DUTY"
		});

		public static readonly CxvPropertyDeclaration MMLBUText2_var1_Property = CxvPropertyDeclaration.Register("MMLBUText2_var1", typeof(MMGenUtl_Result_Summar_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_COST"
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_var1_Property = CxvPropertyDeclaration.Register("MMLBUText1_var1", typeof(MMGenUtl_Result_Summar_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_USAGE"
		});

		public static readonly CxvPropertyDeclaration MMScrollArea1_GridData_Property = CxvPropertyDeclaration.Register("MMScrollArea1_GridData", typeof(MMGenUtl_Result_Summar_ViewModel), new CxvVectorProperty
		{
			ItemType = typeof(MMScrollArea1_GridData_ItemTemplate),
			IndexBasis = new CxvChildCountIndexBasis
			{
				DataPath = "@main.Output.UTL_USAGE",
				UseChildId = true,
				Name = "y"
			}
		});

		public object MMLBUText4_var1 => GetValue(MMLBUText4_var1_Property);

		public object MMLBUText3_var1 => GetValue(MMLBUText3_var1_Property);

		public object MMLBUText2_var1 => GetValue(MMLBUText2_var1_Property);

		public object MMLBUText1_var1 => GetValue(MMLBUText1_var1_Property);

		public object MMScrollArea1_GridData => GetValue(MMScrollArea1_GridData_Property);
	}
	[ProgId("MMGenUtl.MMGenUtl_Result_Summar")]
	public class MMGenUtl_Result_Summar : MMTabPage, IComponentConnector
	{
		internal MMScrollArea MMScrollArea1;

		private bool _contentLoaded;

		public MMGenUtl_Result_Summar()
		{
			base.ViewModelType = typeof(MMGenUtl_Result_Summar_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/general/mmgenutl_result_summar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				MMScrollArea1 = (MMScrollArea)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
}
namespace AspenTech.AspenPlus.MMForms.Utility.BlkUtility
{
	public class MMBlkUtility_Input_Specif_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMComboBox2_var1_Property = CxvPropertyDeclaration.Register("MMComboBox2_var1", typeof(MMBlkUtility_Input_Specif_ViewModel), new CxvVariableProperty
		{
			ExposeAs = CxvVariableTypeCode.String,
			DataPath = "@main.Input.UTILITY_ID",
			ShowDefaultNewItemDialog = false
		});

		private ICxsDataWatch _watch;

		private List<CxsBatchRequest> _templatedValues;

		public object MMComboBox2_var1 => GetValue(MMComboBox2_var1_Property);

		public override void GetCustomUserInput(GetCustomUserInputEventArgs args)
		{
			base.GetCustomUserInput(args);
			if (base.UnityContainer == null)
			{
				return;
			}
			args.CustomUserAction = GetCustomUserInputEventArgs.CustomAction.NewUtility;
			if (args.Parameters == null)
			{
				args.Parameters = new Dictionary<string, object>();
			}
			args.Parameters["NodeType"] = ExpandDataPathAndGet("@main", "type") as string;
			args.Parameters["ExistingIDs"] = CxsConverter.ValueToStringArray(ExpandDataPathAndGet("@main.Input.UTILITY_ID", "option_list", null));
			base.UnityContainer.Resolve<IEventAggregator>(Array.Empty<ResolverOverride>()).GetEvent<GetCustomUserInputEvent>().Publish(args);
			_templatedValues = args.OtherInput as List<CxsBatchRequest>;
		}

		protected override void OnUpdateData()
		{
			base.OnUpdateData();
			if (base.IsInitialUpdate)
			{
				_watch = CreateCxsWatch();
				_watch.AddWatch(ExpandDataPath("@main.Input.UTILITY_ID"), "option_list");
				_watch.ValuesChanged += _watch_ValuesChanged;
			}
		}

		private void _watch_ValuesChanged(object sender, EventArgs e)
		{
			if (_templatedValues != null && base.ResolvedCxsProvider != null)
			{
				base.ResolvedCxsProvider.BatchSet(new CxsBatchRequestData(_templatedValues.ToArray()));
				_templatedValues = null;
			}
		}

		public override void Unload()
		{
			base.Unload();
			if (_watch != null)
			{
				_watch.ValuesChanged -= _watch_ValuesChanged;
				_watch.Unload();
				_watch = null;
			}
		}
	}
	[ProgId("MMBlkUtility.MMBlkUtility_Input_Specif")]
	public class MMBlkUtility_Input_Specif : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMLabel MMComboBox2_label;

		internal MMComboEdit MMComboBox2;

		private bool _contentLoaded;

		public MMBlkUtility_Input_Specif()
		{
			base.ViewModelType = typeof(MMBlkUtility_Input_Specif_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/blkutility/mmblkutility_input_specif.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				MMComboBox2_label = (MMLabel)target;
				break;
			case 3:
				MMComboBox2 = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMBlkUtility_Result_Usage_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMLBUText4_uco2rate_Property = CxvPropertyDeclaration.Register("MMLBUText4_uco2rate", typeof(MMBlkUtility_Result_Usage_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTIL_CO2RATE"
		});

		public static readonly CxvPropertyDeclaration MMLBUText3_var1_Property = CxvPropertyDeclaration.Register("MMLBUText3_var1", typeof(MMBlkUtility_Result_Usage_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTIL_DUTY"
		});

		public static readonly CxvPropertyDeclaration MMLBUText2_ucost_Property = CxvPropertyDeclaration.Register("MMLBUText2_ucost", typeof(MMBlkUtility_Result_Usage_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTIL_COST"
		});

		public static readonly CxvPropertyDeclaration MMLBUText1_usg_Property = CxvPropertyDeclaration.Register("MMLBUText1_usg", typeof(MMBlkUtility_Result_Usage_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_USAGE"
		});

		public static readonly CxvPropertyDeclaration MMLBUText5_var1_Property = CxvPropertyDeclaration.Register("MMLBUText5_var1", typeof(MMBlkUtility_Result_Usage_ViewModel), new CxvVariableProperty
		{
			DataPath = "@main.Output.UTL_ID"
		});

		public object MMLBUText4_uco2rate => GetValue(MMLBUText4_uco2rate_Property);

		public object MMLBUText3_var1 => GetValue(MMLBUText3_var1_Property);

		public object MMLBUText2_ucost => GetValue(MMLBUText2_ucost_Property);

		public object MMLBUText1_usg => GetValue(MMLBUText1_usg_Property);

		public object MMLBUText5_var1 => GetValue(MMLBUText5_var1_Property);
	}
	[ProgId("MMBlkUtility.MMBlkUtility_Result_Usage")]
	public class MMBlkUtility_Result_Usage : MMTabPage, IComponentConnector
	{
		internal MMLabel MMLBUText5_label;

		internal MMVariableEdit MMLBUText5;

		internal MMLabel MMLBUText3_label;

		internal MMVariableEdit MMLBUText3;

		internal MMLabel MMLBUText1_label;

		internal MMVariableEdit MMLBUText1;

		internal MMLabel MMLBUText2_label;

		internal MMVariableEdit MMLBUText2;

		internal MMLabel MMLBUText4_label;

		internal MMVariableEdit MMLBUText4;

		private bool _contentLoaded;

		public MMBlkUtility_Result_Usage()
		{
			base.ViewModelType = typeof(MMBlkUtility_Result_Usage_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
						_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Utility;component/blkutility/mmblkutility_result_usage.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				MMLBUText5_label = (MMLabel)target;
				break;
			case 2:
				MMLBUText5 = (MMVariableEdit)target;
				break;
			case 3:
				MMLBUText3_label = (MMLabel)target;
				break;
			case 4:
				MMLBUText3 = (MMVariableEdit)target;
				break;
			case 5:
				MMLBUText1_label = (MMLabel)target;
				break;
			case 6:
				MMLBUText1 = (MMVariableEdit)target;
				break;
			case 7:
				MMLBUText2_label = (MMLabel)target;
				break;
			case 8:
				MMLBUText2 = (MMVariableEdit)target;
				break;
			case 9:
				MMLBUText4_label = (MMLabel)target;
				break;
			case 10:
				MMLBUText4 = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
}
namespace AspenTech.AspenPlus.Happ
{
	[ComImport]
	[CompilerGenerated]
	[Guid("8E567522-F9BA-11CF-90B2-0000C0A810C4")]
	[TypeIdentifier]
	public interface IHNode
	{
		void _VtblGap1_51();

		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743859)]
		void Export([In][MarshalAs(UnmanagedType.BStr)] string filename = "");
	}
}
