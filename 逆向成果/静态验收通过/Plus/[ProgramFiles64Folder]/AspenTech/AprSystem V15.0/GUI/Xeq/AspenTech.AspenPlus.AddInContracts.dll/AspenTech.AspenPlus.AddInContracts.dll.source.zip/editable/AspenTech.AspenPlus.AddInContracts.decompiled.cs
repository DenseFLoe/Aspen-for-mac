using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using AspenTech.Adb.Interfaces;
using AspenTech.Visualisation.CommonShell;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.AddInContracts")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.AddInContracts")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2012 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]
namespace AspenTech.AspenPlus.AddInContracts
{
	public interface IABEIntegration
	{
		bool IsSimulationRunUpToDate();

		string[] GetSelectedObjects();

		string GetSimulationName();

		IAdbTop GetAdbTop();

		bool IsRunTimeModeValid();

		bool IsInSafetyEnvironment();

		bool IsABEMappingDone();
	}
	public enum Sim
	{
		UNDEFINED,
		ASPEN_PLUS,
		ASPEN_HYSYS
	}
	public enum Trig
	{
		UNDEFINED,
		CONTEXT_MENU,
		OTHER
	}
	public enum ABEApp
	{
		UNDEFINED,
		ABE_EXPLORER,
		ABE_MAPPER
	}
	public class ABEIntegrationEventArgs : EventArgs
	{
		public Trig Trigger { get; set; }

		public Sim Host { get; set; }

		public ABEApp App { get; set; }

		public ABEIntegrationEventArgs()
		{
			Trigger = Trig.UNDEFINED;
			Host = Sim.UNDEFINED;
		}
	}
	public class ABEIntegrationEvent : RoutedCompositePresentationEvent<ABEIntegrationEventArgs>
	{
	}
	public class IsABEReadyRetrieveEventArgs : EventArgs
	{
		public bool IsABEReady { get; set; }
	}
	public class IsABEReadyRetrieveEvent : RoutedCompositePresentationEvent<IsABEReadyRetrieveEventArgs>
	{
		public IsABEReadyRetrieveEvent()
		{
			base.RoutingStrategy = CompositeEventRoutingStrategy.FirstOfChildrenThenParents;
		}
	}
	public class SimChangedEventArgs : EventArgs
	{
	}
	public class SimChangedEvent : RoutedCompositePresentationEvent<SimChangedEventArgs>
	{
		public SimChangedEvent()
		{
			base.RoutingStrategy = CompositeEventRoutingStrategy.Children;
		}
	}
	public interface IAIModel
	{
		ITrainModel Model { get; }

		string ModelName { get; set; }

		event EventHandler<TrainingResultStatus> TrainingCompleted;

		event EventHandler<NNIterationStepEventArgs> NNIterationStepEvent;

		event EventHandler<string> TrainingMessageEvent;

		event EventHandler<AILicenseCheckedEventArgs> AILicenseCheckedEvent;

		void Initialize(string csvConditionedData, Dictionary<string, TaggedVariable> taggedVariableDictionary, IEnumerable<TrainedVariable> trainedVariables, NeuralNetworkConfiguration nnConfig, string fnnFileName = null, bool isAITrainingOrEvaluation = false);

		void BeginTrain();

		void StopTrain();

		bool Deploy(string modelName, Dictionary<string, TaggedVariable> taggedVariableDictionary, IEnumerable<TrainedVariable> trainedVariables, string snapshotFolder, string snapshotID, TrainingModelResultsInfo resultsInfo);

		string GetResultsTable();

		IEnumerable<string> GetOutputFiles();

		bool CheckLicense();

		void BeginCheckLicense();

		string DeleteWorkingDirectory();
	}
	public interface ITrainModel
	{
	}
	public enum TaggedVariableType
	{
		Simulation,
		Custom
	}
	public class TaggedVariable
	{
		public string Name { get; set; }

		public TaggedVariableType VariableType { get; set; }

		public string CxsPath { get; set; }

		public bool IsInput { get; set; }

		public string UnitType { get; set; }

		public string UnitTypeDisplayName { get; set; }

		public bool IsCustomUnitType { get; set; }

		public string Units { get; set; }

		public bool IsCustomUnit { get; set; }

		public double LowerLimit { get; set; }

		public double UpperLimit { get; set; }

		public string Description { get; set; }

		public double Weight { get; set; }

		public bool IncludedInNN { get; set; }

		public bool IncludedInFPModel { get; set; }

		public TaggedVariable()
		{
		}

		public TaggedVariable(string name, string cxsPath, bool isInput)
		{
			Name = name;
			CxsPath = cxsPath;
			IsInput = isInput;
		}

		public TaggedVariable(string name, string cxsPath, bool isInput, string unitType, string units, TaggedVariableType type)
		{
			Name = name;
			CxsPath = cxsPath;
			IsInput = isInput;
			UnitType = unitType;
			Units = units;
			VariableType = type;
		}
	}
	public class TrainedVariable
	{
		public string Name { get; set; }

		public string CxsPath { get; set; }

		public double TrainedValue { get; set; }

		public double Initial { get; set; }

		public bool Initial_UserEntered { get; set; }

		public double LowerLimit { get; set; }

		public double UpperLimit { get; set; }

		public string UnitType { get; set; }

		public string UnitTypeDisplayName { get; set; }

		public bool IsCustomUnitType { get; set; }

		public string Units { get; set; }

		public bool IsCustomUnit { get; set; }

		public string Description { get; set; }
	}
	public enum TrainingResultStatus
	{
		NotStarted,
		Running,
		Succeeded,
		Failed,
		SucceededWithoutFnn
	}
	public class NeuralNetworkConfiguration
	{
		public int NumberOfEpochs { get; set; }

		public double LearningRate { get; set; }

		public StartOption StartOption { get; set; }

		public bool ParallelComputing { get; set; }

		public IEnumerable<NNHiddenLayer> HiddenLayers { get; set; }

		public NNOutputLayer OutputLayer { get; set; }

		public bool AdaptiveLearningRate { get; set; }

		public int BatchSize { get; set; }

		public double TrainingSetFraction { get; set; }

		public double DecayRate { get; set; }

		public NNMethod Method { get; set; }

		public int Cycles { get; set; }

		public double Momentum { get; set; }

		public double LRMultiplier { get; set; }

		public NNFitType FitType { get; set; }

		public bool FitScale { get; set; }

		public double HuberDelta { get; set; }

		public double AdamBeta1 { get; set; }

		public double AdamBeta2 { get; set; }

		public double AdamEps { get; set; }

		public bool DeleteTempFiles { get; set; }

		public double RRStop { get; set; }

		public int NumberOfStopsToTerminate { get; set; }

		public bool ShuffleTrainingSetOnEachPass { get; set; }

		public int VIPTrials { get; set; }

		public string FnnFileForLastRun { get; set; }

		public double ValidWeight { get; set; }

		public int NumTry { get; set; }

		public int TryCycle { get; set; }

		public TrainingMode Mode { get; set; }

		public bool TurnOnVIP { get; set; }

		public NeuralNetworkConfiguration()
		{
		}

		public NeuralNetworkConfiguration(int numOfEpochs, double learningRate, StartOption startOption, bool parallelComputing, IEnumerable<NNHiddenLayer> hiddenLayers, NNOutputLayer outputLayer)
		{
			NumberOfEpochs = numOfEpochs;
			LearningRate = learningRate;
			StartOption = startOption;
			ParallelComputing = parallelComputing;
			HiddenLayers = hiddenLayers;
			OutputLayer = outputLayer;
		}
	}
	public enum TrainingMode
	{
		Training,
		EvaluationWithSpecifiedValue,
		EvaluationWithCalculatedValue
	}
	public enum StartOption
	{
		Cold,
		Warm
	}
	public enum ActivationFunction
	{
		Selu,
		Relu,
		Sigmoid,
		Linear,
		LeakyRelu
	}
	public enum NNMethod
	{
		Momentum,
		SGD,
		Adam
	}
	public enum NNFitType
	{
		MeanSquareError,
		MeanAbsoluteError,
		HuberLoss,
		PseudoHuber
	}
	public class NNHiddenLayer
	{
		public int ID { get; set; }

		public int NumberOfNeurons { get; set; }

		public ActivationFunction ActivationFunction { get; set; }

		public double ActivationParameter { get; set; }

		public NNHiddenLayer()
		{
		}

		public NNHiddenLayer(int id, int numOfNeurons, ActivationFunction activationFunction, double activationParameter)
		{
			ID = id;
			NumberOfNeurons = numOfNeurons;
			ActivationFunction = activationFunction;
			ActivationParameter = activationParameter;
		}
	}
	public class NNOutputLayer
	{
		public IEnumerable<NNOutputLayerNeuron> Neurons { get; private set; }

		public NNOutputLayer(IEnumerable<NNOutputLayerNeuron> neurons)
		{
			Neurons = neurons;
		}
	}
	public class NNOutputLayerNeuron
	{
		public string Name { get; set; }

		public ActivationFunction ActivationFunction { get; set; }

		public double ActivationParameter { get; set; }

		public double Scale { get; set; }

		public NNOutputLayerNeuron(string name, ActivationFunction activationFunction, double activationParameter, double scale)
		{
			Name = name;
			ActivationFunction = activationFunction;
			ActivationParameter = activationParameter;
			Scale = scale;
		}
	}
	public class TrainingModelResultsInfo
	{
		public double? TrainingR2 { get; set; }

		public double? TrainingRMSE { get; set; }

		public double? TestingR2 { get; set; }

		public double? TestingRMSE { get; set; }

		public int ObservationCount { get; set; }
	}
	public class NNIterationStepEventArgs : EventArgs
	{
		public int Itertaion { get; set; }

		public double TestError { get; set; }

		public double ValidError { get; set; }

		public NNIterationStepEventArgs(int iter, double testErr, double validErr)
		{
			Itertaion = iter;
			TestError = testErr;
			ValidError = validErr;
		}
	}
	public class AILicenseCheckedEventArgs : EventArgs
	{
		public bool IsValid { get; set; }

		public AILicenseCheckedEventArgs(bool isValid)
		{
			IsValid = isValid;
		}
	}
	public class DeployedAIModelDisconnectedFromSnapshotEvent : RoutedCompositePresentationEvent<DeployedAIModelDisconnectedFromSnapshotEventArgs>
	{
	}
	public class DeployedAIModelDisconnectedFromSnapshotEventArgs : EventArgs
	{
		public string SnapshotID { get; private set; }

		public DeployedAIModelDisconnectedFromSnapshotEventArgs(string snapshotID)
		{
			SnapshotID = snapshotID;
		}
	}
	public class DeployedAIModelConnectedToSnapshotEvent : RoutedCompositePresentationEvent<DeployedAIModelConnectedToSnapshotEventArgs>
	{
	}
	public class DeployedAIModelConnectedToSnapshotEventArgs : EventArgs
	{
		public string SnapshotID { get; private set; }

		public DeployedAIModelConnectedToSnapshotEventArgs(string snapshotID)
		{
			SnapshotID = snapshotID;
		}
	}
	public class ShowAIModelSnapshotEvent : RoutedCompositePresentationEvent<ShowAIModelSnapshotEventArgs>
	{
	}
	public class ShowAIModelSnapshotEventArgs : EventArgs
	{
		public string SnapshotID { get; private set; }

		public ShowAIModelSnapshotEventArgs(string snapshotID)
		{
			SnapshotID = snapshotID;
		}
	}
	public class AITrainingObjectDeletedEvent : RoutedCompositePresentationEvent<AITrainingObjectDeletedEventArgs>
	{
	}
	public class AITrainingObjectDeletedEventArgs : EventArgs
	{
		public int TrainingObjectID { get; set; }

		public string TrainingObjectName { get; set; }

		public AITrainingObjectDeletedEventArgs(int trainingObjID, string trainingObjName)
		{
			TrainingObjectID = trainingObjID;
			TrainingObjectName = trainingObjName;
		}
	}
	public interface IAIModelSimulator
	{
		bool IsReady { get; }

		AISimulatorVariable GetVariable(AISimulatorVariable initialVariable = null);

		IEnumerable<AISimulatorVariable> GetMultipleVariables();
	}
	public class AISimulatorVariable
	{
		public string CxsPath { get; set; }

		public string UnitType { get; set; }

		public string UnitTypeDisplayName { get; set; }

		public AISimulatorVariable(string cxsPath, string unitType, string unitTypeDisplayName)
		{
			CxsPath = cxsPath;
			UnitType = unitType;
			UnitTypeDisplayName = unitTypeDisplayName;
		}
	}
	public class AIModelVariblesChangedInSimulatorEvent : RoutedCompositePresentationEvent<AIModelVariblesChangedInSimulatorEventArgs>
	{
	}
	public class AIModelVariblesChangedInSimulatorEventArgs : EventArgs
	{
	}
	public class AISimulationObjectRenamedEvent : RoutedCompositePresentationEvent<AISimulationObjectRenamedEventArgs>
	{
	}
	public class AISimulationObjectRenamedEventArgs : EventArgs
	{
		public string OldPath { get; }

		public string NewPath { get; }

		public AISimulationObjectRenamedEventArgs(string oldPath, string newPath)
		{
			OldPath = oldPath;
			NewPath = newPath;
		}
	}
	public class AISimulationObjectsMovedEvent : RoutedCompositePresentationEvent<AISimulationObjectsMovedEventArgs>
	{
	}
	public class AISimulationObjectsMovedEventArgs : EventArgs
	{
		public IEnumerable<string> MovedObjects { get; }

		public string TargetHierarchy { get; }

		public int MoveSelectionType { get; }

		public AISimulationObjectsMovedEventArgs(IEnumerable<string> movedObjects, string targetHierarchy, int moveSelectionType)
		{
			MovedObjects = movedObjects;
			TargetHierarchy = targetHierarchy;
			MoveSelectionType = moveSelectionType;
		}
	}
	public interface IAOLContract
	{
		string AOLTempFolderPath { get; set; }

		string AOLTempProjectName { get; set; }

		bool ShouldRecoverFromBackup { get; }

		string GetTempFileFullNameWOExtension();

		void ShowHtmlHelp(int helpId);

		bool CreateMeasurementBlock(List<MeasurementInfo> measurements, string measurementName);

		bool IsRunTimeModeValid();

		void ModifiedCase();

		void SetIsRunFromPlantData(bool isRunFromPlantData);
	}
	public class AOLSolutionMethodChangedEventArgs : EventArgs
	{
		public APlusSolutionMethod Method { get; set; }

		public AOLSolutionMethodChangedEventArgs(APlusSolutionMethod method)
		{
			Method = method;
		}
	}
	public class AOLSolutionMethodChangedEvent : RoutedCompositePresentationEvent<AOLSolutionMethodChangedEventArgs>
	{
	}
	public class AOLSaveEventArgs : EventArgs
	{
		public string FileFullName { get; set; }

		public AOLSaveEventArgs()
		{
		}

		public AOLSaveEventArgs(string fileFullName)
		{
			FileFullName = fileFullName;
		}
	}
	public class AOLSaveEvent : RoutedCompositePresentationEvent<AOLSaveEventArgs>
	{
	}
	public class AOLSaveAsEventArgs : EventArgs
	{
		public string FileFullName { get; set; }

		public bool SharedFolder { get; set; }

		public AOLSaveAsEventArgs(string fileFullName)
		{
			FileFullName = fileFullName;
			SharedFolder = false;
		}
	}
	public class AOLSaveAsEvent : RoutedCompositePresentationEvent<AOLSaveAsEventArgs>
	{
	}
	public class AOLCloseEventArgs : EventArgs
	{
	}
	public class AOLCloseEvent : RoutedCompositePresentationEvent<AOLCloseEventArgs>
	{
	}
	public class AOLExitEventArgs : EventArgs
	{
	}
	public class AOLExitEvent : RoutedCompositePresentationEvent<AOLExitEventArgs>
	{
	}
	public class AOLBeforeSaveCompoundFileEventArgs : EventArgs
	{
		public string FileFullName { get; set; }

		public string AOLZipFileFullName { get; set; }

		public bool SharedFolder { get; set; }
	}
	public class AOLBeforeSaveCompoundFileEvent : RoutedCompositePresentationEvent<AOLBeforeSaveCompoundFileEventArgs>
	{
	}
	public class AOLAfterSaveCompoundFileEventArgs : EventArgs
	{
		public string FileFullName { get; set; }
	}
	public class AOLAfterSaveCompoundFileEvent : RoutedCompositePresentationEvent<AOLAfterSaveCompoundFileEventArgs>
	{
	}
	public class AOLBeforeOpenCompoundFileEventArgs : EventArgs
	{
		public string FileFullName { get; set; }
	}
	public class AOLBeforeOpenCompoundFileEvent : RoutedCompositePresentationEvent<AOLBeforeOpenCompoundFileEventArgs>
	{
	}
	public class AOLAfterOpenCompoundFileEventArgs : EventArgs
	{
		public string FileFullName { get; set; }

		public string ExtractedDirectoryPathForHysys { get; set; }
	}
	public class AOLAfterOpenCompoundFileEvent : RoutedCompositePresentationEvent<AOLAfterOpenCompoundFileEventArgs>
	{
	}
	public class AOLUpdatePlantDataNodeEventArgs : EventArgs
	{
	}
	public class AOLUpdatePlantDataNodeEvent : RoutedCompositePresentationEvent<AOLUpdatePlantDataNodeEventArgs>
	{
	}
	public class AOLActiveDocumentChangedEventArgs : EventArgs
	{
		public HysysCaseInfo OldCase { get; set; }

		public HysysCaseInfo NewCase { get; set; }
	}
	public class AOLActiveDocumentChangedEvent : RoutedCompositePresentationEvent<AOLActiveDocumentChangedEventArgs>
	{
	}
	public class AOLHysysDynamicModeChangedEventArgs : EventArgs
	{
	}
	public class AOLHysysDynamicModeChangedEvent : RoutedCompositePresentationEvent<AOLHysysDynamicModeChangedEventArgs>
	{
	}
	public class AOLAPlusCustomUnitsChangedEventArgs : EventArgs
	{
	}
	public class AOLAPlusCustomUnitsChangedEvent : RoutedCompositePresentationEvent<AOLAPlusCustomUnitsChangedEventArgs>
	{
	}
	public class HysysUnitState
	{
		public string UnitName { get; set; }

		public int Operation { get; set; }

		public double Factor { get; set; }

		public double Offset { get; set; }
	}
	public enum HysysUnitEvents
	{
		CustomUnitsAdd,
		CustomUnitsView,
		CustomUnitsDelete
	}
	public class AOLHysysCustomUnitsChangedEventArgs : EventArgs
	{
		public HysysUnitEvents EventType { get; set; }

		public int UnitType { get; set; }

		public string UnitTypeDisplayName { get; set; }

		public HysysUnitState oldState { get; set; }

		public HysysUnitState newState { get; set; }
	}
	public class AOLHysysCustomUnitsChangedEvent : RoutedCompositePresentationEvent<AOLHysysCustomUnitsChangedEventArgs>
	{
	}
	public class MeasurementInfo
	{
		public string TagName { get; set; }

		public string Description { get; set; }

		public string DescriptionInModel { get; set; }
	}
	public class HysysCaseInfo
	{
		public long DocHandle { get; set; }

		public string FileName { get; set; }

		public string FilePath { get; set; }
	}
	public enum APlusSolutionMethod
	{
		Unknown,
		SM,
		EO,
		MIXED
	}
	public class AOLShowAITrainingScreenEvent : RoutedCompositePresentationEvent<AOLShowAITrainingScreenEventArgs>
	{
	}
	public class AOLShowAITrainingScreenEventArgs : EventArgs
	{
	}
	public class AOLCheckCanSaveEventArgs : EventArgs
	{
		public bool Cancel { get; set; }
	}
	public class AOLCheckCanSaveEvent : RoutedCompositePresentationEvent<AOLCheckCanSaveEventArgs>
	{
	}
	public class AOLCheckCanSaveAsEventArgs : EventArgs
	{
		public string FileFullName { get; set; }

		public bool Cancel { get; set; }
	}
	public class AOLCheckCanSaveAsEvent : RoutedCompositePresentationEvent<AOLCheckCanSaveAsEventArgs>
	{
	}
	public class AOLOpenFileFromNetworkDriveAndCopyLocalEventArgs : EventArgs
	{
		public string SourceFileFullName { get; set; }

		public string TargetFileFullName { get; set; }

		public string PossiblePDFolderDir { get; set; }
	}
	public class AOLOpenFileFromNetworkDriveAndCopyLocalEvent : RoutedCompositePresentationEvent<AOLOpenFileFromNetworkDriveAndCopyLocalEventArgs>
	{
	}
	public class AOLOpenFileFromNetworkDriveSaveBackEventArgs : EventArgs
	{
		public string NetworkDirectory { get; set; }

		public string LocalFileFullName { get; set; }
	}
	public class AOLOpenFileFromNetworkDriveSaveBackEvent : RoutedCompositePresentationEvent<AOLOpenFileFromNetworkDriveSaveBackEventArgs>
	{
	}
	public class SelectedViewFilterChangedEventArgs : EventArgs
	{
		public string NavigatorGroupKey { get; private set; }

		public string OldFilter { get; private set; }

		public string NewFilter { get; private set; }

		public SelectedViewFilterChangedEventArgs(string navigatorGroupKey, string oldFilter, string newFilter)
		{
			NavigatorGroupKey = navigatorGroupKey;
			OldFilter = oldFilter;
			NewFilter = newFilter;
		}
	}
	public class SelectedViewFilterChangedEvent : RoutedCompositePresentationEvent<SelectedViewFilterChangedEventArgs>
	{
	}
	public interface ISimulationServices
	{
		string FileName { get; }

		string GetCurrentModelDefinition();

		string GetCurrentAssociatedInformation();

		bool SetCurrentAssociatedInformation(string sValue);
	}
	public interface IAceScreenContract : IScreenContract
	{
		void OpenSearchWindow(object data);

		void Configure(object data);
	}
	public interface IScreenContract
	{
		string Header { get; }

		object GenerateAddInContent();
	}
}
namespace AspenTech.AspenPlus.AddInContracts.Properties
{
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

		public static Settings Default => defaultInstance;
	}
}
