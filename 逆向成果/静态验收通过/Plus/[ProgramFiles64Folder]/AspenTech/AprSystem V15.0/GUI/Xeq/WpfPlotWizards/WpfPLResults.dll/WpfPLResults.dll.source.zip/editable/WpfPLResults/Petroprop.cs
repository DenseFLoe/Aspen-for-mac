using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPLControls;
using WpfPlotwizard;

namespace WpfPLResults;

[ProgId("WpfPLResults.Petroprop")]
public class Petroprop : UserControl, IRibbonPlotWizardType, IPlotWizardTemplate, IComponentConnector
{
	private IHNode _context;

	private IHWizardPlot _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper("PlotWiz.hlp", 295L);

	private string _uniqueId = "Results_Petroprop";

	private string _plotName;

	private object _nodeCxs;

	private System.Drawing.Image _imgIcon;

	private bool _bHasInputDialog;

	private string _currentTemparetureUnit = string.Empty;

	private string _currentConfigValue = string.Empty;

	private bool _bCheckDataOnly;

	internal CurvesSelectFormControl CurvesSelector;

	private bool _contentLoaded;

	public string TooltipContentForRibbonItem => WpfPLResultsResources.TooltipContentForRibbonItem_PetroProperties;

	public string TooltipHeaderForRibbonItem => WpfPLResultsResources.TooltipHeaderForRibbonItem_PetroProperties;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgIcon;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string> { WpfPLResultsResources.Unit_Id };

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public Petroprop()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Expected O, but got Unknown
		_bHasInputDialog = true;
		if (_imgIcon == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLResults.Images.petroprop.ico");
			_imgIcon = new Bitmap(manifestResourceStream);
		}
		InitializeComponent();
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		if (sFieldName.CompareTo(WpfPLResultsResources.Unit_Id) == 0)
		{
			List<string> list = new List<string>();
			_help.LoadUnitsList(_context.Application.Tree, _wizardPlot, list);
			return list;
		}
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
		if (sFieldName.CompareTo(WpfPLResultsResources.Unit_Id) == 0)
		{
			sCurrentVal = _help.GetUnitString(_context.Application.Tree, _wizardPlot);
		}
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
		bool flag = false;
		if (sFieldName.CompareTo(WpfPLResultsResources.Unit_Id) == 0)
		{
			_currentTemparetureUnit = sValue;
			flag = true;
		}
		if (flag)
		{
			UpdateWizardData();
		}
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		if (sField.CompareTo(WpfPLResultsResources.ViscosityUnit) == 0)
		{
			return (RibbonControlType)1;
		}
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
		sConfigValue = _currentConfigValue;
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
		_currentConfigValue = sValue;
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot;
		string path = "PetroCharacterization/Results/Output/Prop Data/PPPROP";
		IHNode iHNode = _context.FindNode(path);
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		_wizardPlot.RemoveAllDependentVariable();
		int num = iHNode.Elements.get_RowCount(0);
		iHNode.Elements.get_RowCount(1);
		List<string> list = new List<string>();
		if (num > 0)
		{
			for (int i = 0; i < num; i++)
			{
				string item = iHNode.Elements.get_Label(0, i, Type.Missing);
				if (!list.Contains(item))
				{
					list.Add(item);
				}
			}
		}
		CurvesSelector.SetCurves(list.ToArray());
		if (!string.IsNullOrEmpty(_currentConfigValue))
		{
			RestoreConfigValue(_currentConfigValue);
		}
	}

	public void UpdateWizardData()
	{
		_wizardPlot.RemoveAllDependentVariable();
		string path = "PetroCharacterization/Results/Output/Prop Data/PPPROP";
		IHNode iHNode = _context.FindNode(path);
		if (iHNode == null)
		{
			return;
		}
		List<string> list = new List<string>(CurvesSelector.GetSelectedCurves());
		int num = iHNode.Elements.get_RowCount(1);
		if (list.Count > 0)
		{
			_wizardPlot.PlotVal.NVariables = list.Count;
			for (int i = 0; i < list.Count; i++)
			{
				int location = iHNode.Elements.get_LabelLocation(list[i], 0);
				string text = iHNode.Elements.get_Label(0, location, Type.Missing);
				for (int j = 0; j < num; j++)
				{
					string loc_or_name = iHNode.Elements.get_Label(1, j, Type.Missing);
					try
					{
						((IHPlotVal)_wizardPlot.PlotVal).set_YData(i, j, (short)1, (object)iHNode.Elements[text, loc_or_name, Type.Missing, Type.Missing, Type.Missing]);
					}
					catch (Exception)
					{
					}
				}
				((IHPlotVal)_wizardPlot.PlotVal).set_Label(i, text);
			}
		}
		if (!string.IsNullOrEmpty(_currentTemparetureUnit))
		{
			_help.SaveUnitsComboText(_context.Application.Tree, _wizardPlot, _currentTemparetureUnit);
		}
		_currentConfigValue = SaveConfigValue();
	}

	private void CurvesSelector_OKButtonClick(object sender, EventArgs e)
	{
		UpdateWizardData();
		_help.CloseForm((UserControl)this, (bool?)true);
	}

	private void CurvesSelector_CancelButtonClick(object sender, EventArgs e)
	{
		_help.CloseForm((UserControl)this, (bool?)false);
	}

	public void SetCaption(ref string caption)
	{
		caption = WpfPLResultsResources.Petroprop3_Name;
	}

	public void SetDefaultHeight(ref double defaultHeight)
	{
		defaultHeight = 320.0;
	}

	public void SetDefaultWidth(ref double defaultWidth)
	{
		defaultWidth = 320.0;
	}

	public void SetMinHeight(ref double minHeight)
	{
		minHeight = 320.0;
	}

	public void SetMinWidth(ref double minWidth)
	{
		minWidth = 320.0;
	}

	private string SaveConfigValue()
	{
		_ = string.Empty;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("CurveSelection=");
		List<string> list = new List<string>(CurvesSelector.GetSelectedCurves());
		int count = list.Count;
		for (int i = 0; i < count; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(",");
			}
			stringBuilder.Append(list[i]);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("CheckAll=");
		stringBuilder.Append(CurvesSelector.IsCheckAll);
		stringBuilder.Append(";");
		return stringBuilder.ToString();
	}

	private void RestoreConfigValue(string ConfigString)
	{
		string[] array = ConfigString.Split(';');
		int num = 0;
		string text = array[num].Substring(array[num].IndexOf('=') + 1);
		string[] array2 = text.Split(',');
		List<string> list = new List<string>();
		string[] array3 = array2;
		foreach (string item in array3)
		{
			list.Add(item);
		}
		CurvesSelector.SetSelectedCurves(list.ToArray());
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		CurvesSelector.IsCheckAll = Convert.ToBoolean(text);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	public void InitializeComponent()
	{
		if (_contentLoaded)
		{
			return;
		}
		_contentLoaded = true;
		Uri resourceLocator = new Uri("/WpfPLResults;component/petroprop.xaml", UriKind.Relative);
		Application.LoadComponent(this, resourceLocator);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		if (connectionId == 1)
		{
			CurvesSelector = (CurvesSelectFormControl)target;
			CurvesSelector.OKButtonClick += CurvesSelector_OKButtonClick;
			CurvesSelector.CancelButtonClick += CurvesSelector_CancelButtonClick;
		}
		else
		{
			_contentLoaded = true;
		}
	}
}
