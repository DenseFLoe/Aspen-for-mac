# AssemblyInfo.cs

Source: editable/Properties/AssemblyInfo.cs

Source SHA-256: 6499d92647f53844238741cbba8c7852ab856af705f6d82f4d07d83229234a00
