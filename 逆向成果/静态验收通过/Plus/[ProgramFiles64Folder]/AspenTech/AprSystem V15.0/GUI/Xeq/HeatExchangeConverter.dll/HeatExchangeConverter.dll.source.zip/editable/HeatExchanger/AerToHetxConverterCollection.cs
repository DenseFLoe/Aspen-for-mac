using System.Runtime.InteropServices;

namespace HeatExchanger;

[ComVisible(true)]
[Guid("9CC9A8E2-4232-4B15-925F-3B0D0B0E61E0")]
[ProgId("HeatExchanger.AerToHetxConverterCollection.41.0")]
[ClassInterface(ClassInterfaceType.None)]
public class AerToHetxConverterCollection : ConverterCollection
{
	public AerToHetxConverterCollection()
		: base("Aerotran")
	{
	}
}
