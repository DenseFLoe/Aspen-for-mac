"""Compile one item's editable source with the pinned Roslyn toolchain.

Usage: compile_item.py <sha8>
Reads  <work>/<sha8>/src/{editable,resources}/ + build-inputs.json
Writes <work>/<sha8>/out/<name>.dll + compile.rsp + compile.log
Flags follow the archived managed-rebuild-profile recipe (same as
work/impl-managed-2/drive.py compile_src).
"""
import json, os, sys, subprocess, hashlib
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
HOME = BASE / "managed-byte-recovery"
sys.path.insert(0, str(BASE)); sys.path.insert(0, str(HOME))
os.environ.setdefault("PYTHONPATH", r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")

from probe_token_layout import cs
from managed_variants import executive_headers
from recover_batch import build_flags

WORK = Path(__file__).resolve().parent.parent

LEDGER = {}
with open(BASE / "per-file.jsonl", encoding="utf-8") as f:
    for line in f:
        r = json.loads(line)
        LEDGER[r["sha256"]] = r

def row(sha8):
    for sha, r in LEDGER.items():
        if sha.startswith(sha8):
            return sha, r
    raise SystemExit("no ledger row for " + sha8)

def compile_item(sha8, out_name=None):
    sha, r = row(sha8)
    src = WORK / sha8 / "src"
    build = json.loads((src / "build-inputs.json").read_text(encoding="utf-8"))
    name = out_name or r["name"]
    out = WORK / sha8 / "out"
    out.mkdir(parents=True, exist_ok=True)
    target = out / name
    profile = build.get("profile") or "utf8_optimized"
    source = {"optimize": not profile.endswith("unoptimized"), "language": "10", "unsafe": False,
              "high_entropy": False, "compiler_features": []}
    original = Path(r["installed_location"])
    flags = build_flags(executive_headers(original), source)
    extra = WORK / sha8 / "extra-flags.txt"
    if extra.is_file():
        flags += [line.strip() for line in extra.read_text(encoding="utf-8").splitlines() if line.strip()]
    flags += ["/out:" + cs.quote(target), "/win32res:" + cs.quote(src / "resources" / "original.res")]
    flags += ["/reference:" + cs.quote(Path(p)) for p in build["references"]]
    for mr in build.get("managed_resources", ()):
        member = src / "resources" / mr["file"]
        flags += ["/resource:" + cs.quote(member) + "," + cs.quote(mr["name"]) + "," +
                  ("public" if mr["publicResource"] else "private")]
    flags += [cs.quote(p) for p in sorted((src / "editable").glob("*.cs"))]
    rsp = out / "compile.rsp"
    rsp.write_text("\n".join(flags) + "\n", encoding="utf-8")
    env = dict(os.environ, DOTNET_CLI_HOME=str(out), DOTNET_CLI_TELEMETRY_OPTOUT="1", DOTNET_NOLOGO="1")
    p = subprocess.run([str(cs.DOTNET), str(cs.CSC), "/noconfig", "@" + str(rsp)], cwd=str(out),
                       env=env, capture_output=True, timeout=600)
    (out / "compile.log").write_bytes(p.stdout + p.stderr)
    rec = {"exit": p.returncode, "target": str(target), "exists": target.is_file(),
           "sha256": hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None,
           "profile": profile}
    print(json.dumps(rec, ensure_ascii=False, indent=1))
    if p.returncode or not target.is_file():
        print((p.stdout + p.stderr).decode("utf-8", "replace")[:6000])
        return 1
    return 0

if __name__ == "__main__":
    sys.exit(compile_item(sys.argv[1]))
