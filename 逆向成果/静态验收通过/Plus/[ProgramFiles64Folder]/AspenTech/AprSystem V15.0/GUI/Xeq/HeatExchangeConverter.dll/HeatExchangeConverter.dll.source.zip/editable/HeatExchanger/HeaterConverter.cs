using System;
using System.Collections;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using AspenTech.AspenPlus.APConvert;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Localization;
using AspenTech.AspenPlus.UnmanagedWrapper;

namespace HeatExchanger;

[ComVisible(false)]
public class HeaterConverter : IAPBlockConverter2, IAPBlockConverter
{
	private enum CursorName
	{
		IDC_ARROW = 32512,
		IDC_WAIT = 32514
	}

	private class StreamConnection
	{
		public string streamName;

		public string streamPort;

		public string blockName;

		public string blockPort;
	}

	private class ConvertData
	{
		public string varName;

		public object Value;

		public short Units;
	}

	private const int HAP_UNITCOL = 3;

	private const int HAP_UNITROW = 2;

	private string side;

	private bool pspec;

	private string[] varNames = new string[14]
	{
		"ENERGY_BAL", "RESTART", "FLASH_METHOD", "SIM_LEVEL", "PROP_LEVEL", "STREAM_LEVEL", "TERM_LEVEL", "REPORT", "NEWPAGE", "TOTBAL",
		"INPUT", "COMPBAL", "RESULTS", "DESCRIPTION"
	};

	private string[] heaterVarNames = new string[12]
	{
		"NPHASE", "PHASE", "BLKOPFREWAT", "MAXIT", "TOL", "OPSETNAME", "HENRY_COMPS", "CHEMISTRY", "FRWATEROPSET", "SOLU_WATER",
		"TRUE_COMPS", "UTILITY_ID"
	};

	private string[] heatxVarNamesHot = new string[12]
	{
		"1NPHASE", "1PHASE", "1FREEWAT", "1FMAXIT", "1FTOL", "HOPSET", "HHENRY_COMPS", "HCHEMISTRY", "HFREE_WATER", "HSOLU_WATER",
		"HTRUE_COMPS", "COLD_UTIL"
	};

	private string[] heatxVarNamesCold = new string[12]
	{
		"2NPHASE", "2PHASE", "2FREEWAT", "2FMAXIT", "2FTOL", "COPSET", "CHENRY_COMPS", "CCHEMISTRY", "CFREE_WATER", "CSOLU_WATER",
		"CTRUE_COMPS", "HOT_UTIL"
	};

	private string[] heaterVarWithUnit = new string[6] { "TEMP", "DUTY", "DELT", "DEGSUB", "DEGSUP", "VFRAC" };

	private string[] commonVarNames1 = new string[34]
	{
		"EO_COMPS", "EO_FORM", "SOLVE_OPEN", "INTERACTIVE", "SPARSITY", "EO_LIGHT_KEY", "EO-HEAVY_KEY", "EO_DEP_COMPS", "DERIV_METHOD", "SOLVE_METHOD",
		"INIT_SCRIPT", "CHECK_FREE_W", "NEG_COMP_CHK", "NEG_FLOW_CHK", "INLET_PHASE", "ALWAYS_INST", "FLASH_FORM", "L2_COMP_MODE", "EO_L2_COMP", "VFRACX_TOL",
		"VFRAC_TOL", "FLOW_TOL", "ON_SMEO_DIFF", "PRES_TOL", "MIN_PRES", "SFRAC_TOL", "EO_COMP_TOL", "CHEM_METHOD", "DUTY_TOL", "AUTO_COMPS",
		"AUTO_COMPS_T", "AUTO_PHASE", "AUTO_PHASE_T", "EO_TEMP_TOL"
	};

	private string[] commonVarNames2 = new string[32]
	{
		"IVNAME", "IVVALUE", "IVLOWER", "IVUPPER", "IVSTEP", "BOUND_TYPE", "SBWEIGHT", "PHYS_QTY", "UOM", "IVSCALE",
		"IVSPEC", "IVENABLED", "EOVAR_TYPE", "THRESHOLD", "RAMPED", "IDESCRIPTION", "SC_METHOD", "USER_METHOD", "SC_TYPE", "LOCALSCRIPT",
		"GLOBALSCRIPT", "FVN_VARTYPE", "FVN_VARIABLE", "FVC_VARIABLE", "FVN_SENTENCE", "FVC_SENTENCE", "FVN_ID1", "FVC_ID1", "FVN_ID2", "FVC_ID2",
		"FVN_ID3", "FVN_ELEM"
	};

	private string[] commonVarNames3 = new string[3] { "SG_NAME", "ENABLED", "COMMENT" };

	private string[] commonVarNames4 = new string[18]
	{
		"PORT_ID", "EO_PT_VAR", "EO_PT_VALUE", "EO_PT_TYPE", "EO_PT_COMP", "THRU", "EO_PT_PHASE", "EO_PT_PHYSQT", "EO_PT_UOM", "S_CH_NAME",
		"VAR", "SG_SPEC", "HIERARCHY", "SG_VALUE", "SG_LOWER", "SG_UPPER", "SG_PHYS_QTY", "SG_UOM"
	};

	private IntPtr gHourglassCursor;

	private IntPtr gPrevCursor;

	private ArrayList streamList;

	private ArrayList variableList;

	private ArrayList varWithUnitList;

	private ArrayList commonVarList1;

	private ArrayList commentList;

	private string convertType;

	private string title = WpfMMDialogResources.ConvertTo_Title;

	public string BaseDestinationType => "HEATX";

	public string BaseSourceType => convertType.ToUpper();

	public string Description => WpfMMDialogResources.ConvertTo_This + " " + BaseSourceType + " " + WpfMMDialogResources.ConvertTo_ConverTo + " " + BaseDestinationType + " " + WpfMMDialogResources.ConvertTo_Model;

	public string DestLibraryFile => "";

	public string DestLibraryModelType => "";

	public string DestLibraryName => "";

	public string DisplayName => "Aspen Heatx";

	[DllImport("user32")]
	private static extern IntPtr SetCursor(IntPtr hCursor);

	[DllImport("user32")]
	private static extern IntPtr LoadCursor(IntPtr hInstance, CursorName lpCursorName);

	public HeaterConverter(string type)
	{
		convertType = type;
		streamList = new ArrayList();
		variableList = new ArrayList();
		varWithUnitList = new ArrayList();
		commonVarList1 = new ArrayList();
		commentList = new ArrayList();
	}

	public void PreConvert(IHNode pNode)
	{
	}

	public int PreConvert2(IHNode pNode)
	{
		gHourglassCursor = LoadCursor(IntPtr.Zero, CursorName.IDC_WAIT);
		gPrevCursor = SetCursor(gHourglassCursor);
		if (pNode == null)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Node, title);
			return 1;
		}
		side = "HOT";
		IHNode iHNode = pNode.FindNode("Output/QCALC");
		if (iHNode != null && (dynamic)iHNode.get_Value(Type.Missing) != null)
		{
			double heatDuty = Convert.ToDouble((dynamic)iHNode.get_Value(Type.Missing));
			if (heatDuty >= 0.0)
			{
				side = "COLD";
			}
		}
		else
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Heat_Duty, title);
			return 1;
		}
		IHNode iHNode2 = pNode.FindNode("Input/UTILITY_ID");
		if (iHNode2 != null && (dynamic)iHNode2.get_Value(Type.Missing) != null)
		{
			string text = (dynamic)iHNode2.get_Value(Type.Missing);
			IHNode iHNode3 = pNode.FindNode("../..");
			IHNode iHNode4 = null;
			while ((iHNode4 = iHNode3.FindNode("Utilities")) == null)
			{
				iHNode3 = iHNode3.FindNode("../../..");
			}
			IHNode iHNode5 = iHNode4.FindNode(text + "/Input/CALOPT");
			if (iHNode5 != null && (dynamic)iHNode5.get_Value(Type.Missing) != null)
			{
				string calculationOption = (dynamic)iHNode5.get_Value(Type.Missing);
				if (calculationOption != "FLASH")
				{
					MessageBox.Show(WpfMMDialogResources.ConvertTo_wrongUtility, title, MessageBoxButtons.OK);
					return 1;
				}
			}
			IHNode iHNode6 = iHNode4.FindNode(text + "/Output/HCOOL_VALUE");
			if (iHNode6 != null && (dynamic)iHNode6.get_Value(Type.Missing) != null)
			{
				double num = Convert.ToDouble((dynamic)iHNode6.get_Value(Type.Missing));
				if (side == "HOT" && num > 0.0)
				{
					MessageBox.Show(WpfMMDialogResources.ConvertTo_bothHot, title, MessageBoxButtons.OK);
					return 1;
				}
				if (side == "COLD" && num < 0.0)
				{
					MessageBox.Show(WpfMMDialogResources.ConvertTo_bothCold, title, MessageBoxButtons.OK);
					return 1;
				}
			}
		}
		IHNode iHNode7 = pNode.FindNode("Ports/F(IN)");
		if (iHNode7 != null && iHNode7.Elements.Count > 1)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_Multip_Feeds, title);
			return 1;
		}
		IHNode iHNode8 = pNode.FindNode("Ports/HS(IN)");
		IHNode iHNode9 = pNode.FindNode("Ports/HS(OUT)");
		if (((iHNode8 != null && iHNode8.Elements.Count > 0) || (iHNode9 != null && iHNode9.Elements.Count > 0)) && MessageBox.Show(WpfMMDialogResources.ConvertTo_Heat_Stream, title, MessageBoxButtons.YesNo) == DialogResult.No)
		{
			return 1;
		}
		try
		{
			IHNode iHNode10 = pNode.FindNode("Connections");
			IHNodeCol elements = iHNode10.Elements;
			if (elements != null)
			{
				string text2 = pNode.get_Name(Type.Missing);
				streamList.Clear();
				for (int i = 0; i < elements.Count; i++)
				{
					string text3 = elements.get_Label(0, i, Type.Missing);
					IHNode iHNode11 = pNode.FindNode("../../Streams/" + text3 + "/Connections/" + text2);
					if (iHNode11 != null)
					{
						StreamConnection streamConnection = new StreamConnection();
						IHNode iHNode12 = iHNode10.FindNode(text3);
						streamConnection.streamName = text3;
						streamConnection.blockName = text2;
						streamConnection.streamPort = ((dynamic)iHNode11.get_Value(Type.Missing)).ToString();
						streamConnection.blockPort = ((dynamic)iHNode12.get_Value(Type.Missing)).ToString();
						streamList.Add(streamConnection);
					}
				}
			}
			variableList.Clear();
			IHNode iHNode13 = pNode.FindNode("Input/SPEC_OPT");
			pspec = false;
			int num2 = 0;
			string text4 = "";
			if (iHNode13 != null)
			{
				ConvertData convertData = new ConvertData();
				convertData.varName = "SPEC";
				text4 = ((dynamic)iHNode13.get_Value(Type.Missing)).ToString().ToUpper();
				if (text4 == "TP" || text4 == "PDT" || text4 == "PV" || text4 == "PD" || text4 == "PDEGSUP" || text4 == "PDEGSUB" || text4 == "PQ")
				{
					pspec = true;
				}
				if (text4 == "TP" || text4 == "TV" || text4 == "TD" || text4 == "TDPPARM" || text4 == "TQ")
				{
					num2 = 0;
					if (side == "HOT")
					{
						convertData.Value = "T-HOT";
					}
					else
					{
						convertData.Value = "T-COLD";
					}
				}
				else if (text4 == "PD" || text4 == "DDPPARM" || text4 == "PQ")
				{
					num2 = 1;
					convertData.Value = "DUTY";
				}
				else if (text4 == "PDT" || text4 == "DTV" || text4 == "DTD" || text4 == "DTDPPARM" || text4 == "DTQ")
				{
					num2 = 2;
					if (side == "HOT")
					{
						convertData.Value = "DECR-HOT";
					}
					else
					{
						convertData.Value = "INCR-COLD";
					}
				}
				else if (text4 == "PDEGSUB" || text4 == "DEGSUBDPPARM")
				{
					num2 = 3;
					convertData.Value = "DEGSUB-HOT";
				}
				else if (text4 == "PDEGSUP" || text4 == "DEGSUPDPPARM")
				{
					num2 = 4;
					convertData.Value = "DEGSUP-COLD";
				}
				else if (text4 == "PV" || text4 == "VDPPARM")
				{
					num2 = 5;
					if (side == "HOT")
					{
						convertData.Value = "VFRAC-HOT";
					}
					else
					{
						convertData.Value = "VFRAC-COLD";
					}
				}
				variableList.Add(convertData);
			}
			for (int j = 0; j < varNames.Count(); j++)
			{
				ConvertData convertData2 = new ConvertData();
				convertData2.varName = varNames[j];
				string path = "Input/" + varNames[j];
				IHNode iHNode14 = pNode.FindNode(path);
				if (iHNode14 != null)
				{
					convertData2.Value = iHNode14.get_Value(Type.Missing);
				}
				variableList.Add(convertData2);
			}
			for (int k = 0; k < heaterVarNames.Count(); k++)
			{
				ConvertData convertData3 = new ConvertData();
				if (side == "HOT")
				{
					convertData3.varName = heatxVarNamesHot[k];
				}
				else
				{
					convertData3.varName = heatxVarNamesCold[k];
				}
				string path2 = "Input/" + heaterVarNames[k];
				IHNode iHNode15 = pNode.FindNode(path2);
				if (iHNode15 != null)
				{
					convertData3.Value = iHNode15.get_Value(Type.Missing);
				}
				variableList.Add(convertData3);
			}
			varWithUnitList.Clear();
			ConvertData convertData4 = new ConvertData();
			if (side == "HOT")
			{
				convertData4.varName = "PRES_HOT";
			}
			else
			{
				convertData4.varName = "PRES_COLD";
			}
			string path3 = "Input/PRES";
			if (!pspec)
			{
				path3 = "Output/B_PRES";
			}
			IHNode iHNode16 = pNode.FindNode(path3);
			if (iHNode16 != null)
			{
				convertData4.Value = iHNode16.get_Value(Type.Missing);
				convertData4.Units = Convert.ToInt16((dynamic)iHNode16.get_AttributeValue((short)3, Type.Missing));
			}
			varWithUnitList.Add(convertData4);
			convertData4 = new ConvertData();
			convertData4.varName = "VALUE";
			path3 = "Input/" + heaterVarWithUnit[num2];
			if (text4 == "PQ")
			{
				path3 = "Output/QCALC";
			}
			iHNode16 = pNode.FindNode(path3);
			if (iHNode16 != null)
			{
				object obj = iHNode16.get_Value(Type.Missing);
				double num3 = (dynamic)((obj is double) ? obj : ((object)double.NaN));
				if (num2 > 0 && num2 < 5)
				{
					int num4 = Convert.ToInt32((dynamic)iHNode16.get_AttributeValue((short)3, Type.Missing));
					int iRow = Convert.ToInt32((dynamic)iHNode16.get_AttributeValue((short)2, Type.Missing));
					convertData4.Value = ((HelperFuncs.ConvertValue(iRow, num3, num4, 1) < 0.0) ? (-num3) : num3);
					convertData4.Units = (short)num4;
				}
				else
				{
					convertData4.Value = num3;
					convertData4.Units = Convert.ToInt16((dynamic)iHNode16.get_AttributeValue((short)3, Type.Missing));
				}
			}
			varWithUnitList.Add(convertData4);
			commonVarList1.Clear();
			for (int l = 0; l < commonVarNames1.Count(); l++)
			{
				ConvertData convertData5 = new ConvertData();
				convertData5.varName = commonVarNames1[l];
				string path4 = "Input/" + commonVarNames1[l];
				IHNode iHNode17 = pNode.FindNode(path4);
				if (iHNode17 != null && (dynamic)iHNode17.get_Value(Type.Missing) != null)
				{
					convertData5.Value = iHNode17.get_Value(Type.Missing);
					commonVarList1.Add(convertData5);
				}
			}
			commentList.Clear();
			IHNode iHNode18 = pNode.FindNode("Comments");
			IHNodeCol elements2 = iHNode18.Elements;
			if (elements2 != null && elements2.Count > 0)
			{
				for (int m = 0; m < elements2.Count; m++)
				{
					ConvertData convertData6 = new ConvertData();
					convertData6.varName = m.ToString();
					IHNode iHNode19 = iHNode18.Elements[m, Type.Missing, Type.Missing, Type.Missing, Type.Missing];
					if (iHNode19 != null && (dynamic)iHNode19.get_Value(Type.Missing) != null)
					{
						convertData6.Value = iHNode19.get_Value(Type.Missing);
						commentList.Add(convertData6);
					}
				}
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(WpfMMDialogResources.ConvertTo_CannotBeConverted, title);
			throw new Exception(ex.Message.ToString());
		}
		return 0;
	}

	public void PostConvert(IHNode pNode)
	{
		IHNode iHNode = pNode.FindNode("Ports");
		string text = "";
		for (int i = 0; i < streamList.Count; i++)
		{
			text = "";
			StreamConnection streamConnection = streamList[i] as StreamConnection;
			if (streamConnection.blockPort.ToString() == "F(IN)")
			{
				if (side == "HOT")
				{
					text = "H(IN)";
				}
				else
				{
					text = "C(IN)";
				}
			}
			else if (streamConnection.blockPort.ToString() == "P(OUT)")
			{
				if (side == "HOT")
				{
					text = "H(OUT)";
				}
				else
				{
					text = "C(OUT)";
				}
			}
			if (!string.IsNullOrEmpty(text))
			{
				string streamName = streamConnection.streamName;
				IHNodeCol destinationElements = iHNode.FindNode(text).Elements;
				if (destinationElements != null)
				{
					destinationElements.Add(streamName, null, null, null, null);
				}
			}
		}
		IHNode iHNode2 = null;
		int count = variableList.Count;
		for (int j = 0; j < count; j++)
		{
			ConvertData convertData = variableList[j] as ConvertData;
			iHNode2 = pNode.FindNode("Input/" + convertData.varName);
			try
			{
				if (iHNode2 != null && convertData.Value != null)
				{
					iHNode2.set_Value(Type.Missing, convertData.Value);
				}
				else if (iHNode2 != null && convertData.Value == null && j > 4 && j < 11)
				{
					iHNode2.set_Value(Type.Missing, convertData.Value);
				}
			}
			catch
			{
			}
		}
		count = varWithUnitList.Count;
		for (int k = 0; k < count; k++)
		{
			ConvertData convertData2 = varWithUnitList[k] as ConvertData;
			iHNode2 = pNode.FindNode("Input/" + convertData2.varName);
			try
			{
				if (iHNode2 != null && convertData2.Value != null)
				{
					iHNode2.SetValueAndUnit(convertData2.Value, convertData2.Units, Type.Missing);
				}
			}
			catch
			{
			}
		}
		count = commonVarList1.Count;
		for (int l = 0; l < count; l++)
		{
			ConvertData convertData3 = commonVarList1[l] as ConvertData;
			iHNode2 = pNode.FindNode("Input/" + convertData3.varName);
			try
			{
				if (iHNode2 != null && convertData3.Value != null)
				{
					iHNode2.set_Value(Type.Missing, convertData3.Value);
				}
			}
			catch
			{
			}
		}
		count = commentList.Count;
		for (int m = 0; m < count; m++)
		{
			ConvertData convertData4 = commentList[m] as ConvertData;
			iHNode2 = pNode.FindNode("Comments");
			try
			{
				if (iHNode2 != null && convertData4.Value != null)
				{
					iHNode2.Elements.InsertRow(0, m);
					iHNode2.Elements[m, Type.Missing, Type.Missing, Type.Missing, Type.Missing].set_Value(Type.Missing, convertData4.Value);
				}
			}
			catch
			{
			}
		}
		SetCursor(gPrevCursor);
	}
}
