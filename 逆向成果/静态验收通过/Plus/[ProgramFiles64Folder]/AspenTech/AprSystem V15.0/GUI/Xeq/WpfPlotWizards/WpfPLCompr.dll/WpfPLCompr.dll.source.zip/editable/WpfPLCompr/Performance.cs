using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using WpfPlotwizard;

namespace WpfPLCompr;

[ProgId("WpfPLCompr.Performance")]
public class Performance : IRibbonPlotWizardType
{
	private IHNode _context;

	private IHWizardPlot2 _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private int _nCurves;

	private string _uniqueId = wpfPLComprResources.Performance_ID;

	private string _plotName;

	private object _nodeCxs;

	private Image _imgBitmap;

	private bool _bHasInputDialog;

	private bool _bCheckDataOnly;

	public string TooltipContentForRibbonItem => wpfPLComprResources.TooltipContentForRibbonItem_Performance;

	public string TooltipHeaderForRibbonItem => wpfPLComprResources.TooltipHeaderForRibbonItem_Performance;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot2;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string>();

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public Performance()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		_bHasInputDialog = false;
		if (_imgBitmap == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLCompr.Images.Performance.ico");
			_imgBitmap = new Bitmap(manifestResourceStream);
		}
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot2;
		bool flag = false;
		IHNode iHNode = _context.FindNode("Input/OPT_CFORMAT");
		if (((dynamic)iHNode.get_Value(Type.Missing)).ToString().ToUpper() == "TABLE")
		{
			iHNode = _context.FindNode("Input/NCURVES");
			_nCurves = ((int?)(dynamic)iHNode.get_Value(Type.Missing)).GetValueOrDefault(0);
			if (_nCurves > 0)
			{
				flag = true;
			}
		}
		if (!flag)
		{
			ierror = 1;
		}
	}

	public void UpdateWizardData()
	{
		string text = "";
		IHNode iHNode = _context.FindNode("Input/SPEC_MACHNO");
		if (((dynamic)iHNode.get_Value(Type.Missing)).ToString().ToUpper() == "YES")
		{
			iHNode = _context.FindNode("Input/MACH_NO");
			text = WpfPLMComprResources.Mach_No + " = ";
		}
		else
		{
			iHNode = _context.FindNode("Input/SHAFT_SPEED");
			text = WpfPLMComprResources.Shaft_speed + " = ";
		}
		_wizardPlot.RemoveAllIndependentVariable();
		_wizardPlot.RemoveAllDependentVariable();
		IHNode iHNode2 = _context.FindNode("Input/DEP_VAR");
		string text2 = ((dynamic)iHNode2.get_Value(Type.Missing)).ToString().ToUpper();
		for (int i = 0; i < _nCurves; i++)
		{
			string indepvar = "";
			string depvar = "";
			if (text2 == "HEAD")
			{
				indepvar = "Input/H_FLOW/" + (i + 1);
				depvar = "Input/HEAD_DATA/" + (i + 1);
			}
			else if (text2 == "HEAD-COEF")
			{
				indepvar = "Input/HC_FLOW/" + (i + 1);
				depvar = "Input/HEADC_DATA/" + (i + 1);
			}
			else if (text2 == "POWER")
			{
				indepvar = "Input/PW_FLOW/" + (i + 1);
				depvar = "Input/POWER_DATA/" + (i + 1);
			}
			else if (text2 == "PRES")
			{
				indepvar = "Input/P_FLOW/" + (i + 1);
				depvar = "Input/PRES_DATA/" + (i + 1);
			}
			else if (text2 == "PRAT")
			{
				indepvar = "Input/PR_FLOW/" + (i + 1);
				depvar = "Input/PRATIO_DATA/" + (i + 1);
			}
			else if (text2 == "DELP")
			{
				indepvar = "Input/DP_FLOW/" + (i + 1);
				depvar = "Input/DELP_DATA/" + (i + 1);
			}
			_wizardPlot.SetMultIndependentVariables(_context, indepvar);
			_wizardPlot.AddDependentVariable(_context, depvar);
			if (_nCurves > 1)
			{
				string label = text + (dynamic)iHNode.Elements[i, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing);
				((IHPlotVal)_wizardPlot.PlotVal).set_Label(i, label);
			}
		}
		string title = "";
		string text3 = wpfPLComprResources.Performance_XAxisTitle + " ";
		string text4 = "";
		string text5 = "";
		if (text2 == "HEAD")
		{
			string text9 = (dynamic)_context.FindNode("Input/HEAD_UNITS").get_Value(Type.Missing);
			text5 = (dynamic)_context.FindNode("Input/H_FLOW_UNIT").get_Value(Type.Missing);
			title = wpfPLComprResources.Performance_Title_Head;
			text4 = wpfPLComprResources.Performance_YAxisTitle_Head;
			if (!string.IsNullOrEmpty(text9))
			{
				text4 = text4 + " " + text9.ToLower();
			}
		}
		else if (text2 == "HEAD-COEF")
		{
			text5 = (dynamic)_context.FindNode("Input/HC_FLOW_UNIT").get_Value(Type.Missing);
			title = wpfPLComprResources.Performance_Title_HeadCoef;
			text4 = wpfPLComprResources.Performance_YAxisTitle_HeadCoef;
		}
		else if (text2 == "POWER")
		{
			string text8 = (dynamic)_context.FindNode("Input/POWER_UNITS").get_Value(Type.Missing);
			text5 = (dynamic)_context.FindNode("Input/PW_FLOW_UNIT").get_Value(Type.Missing);
			title = wpfPLComprResources.Performance_Title_Power;
			text4 = wpfPLComprResources.Performance_YAxisTitle_Power;
			if (!string.IsNullOrEmpty(text8))
			{
				text4 = text4 + " " + text8.ToLower();
			}
		}
		else if (text2 == "PRES")
		{
			string text7 = (dynamic)_context.FindNode("Input/PRES_UNITS").get_Value(Type.Missing);
			text5 = (dynamic)_context.FindNode("Input/P_FLOW_UNIT").get_Value(Type.Missing);
			title = wpfPLComprResources.Performance_Title_Press;
			text4 = wpfPLComprResources.Performance_YAxisTitle_Press;
			if (!string.IsNullOrEmpty(text7))
			{
				text4 = text4 + " " + text7.ToLower();
			}
		}
		else if (text2 == "PRAT")
		{
			text5 = (dynamic)_context.FindNode("Input/PR_FLOW_UNIT").get_Value(Type.Missing);
			title = wpfPLComprResources.Performance_Title_PresRatio;
			text4 = wpfPLComprResources.Performance_YAxisTitle_PressRatio;
		}
		else if (text2 == "DELP")
		{
			string text6 = (dynamic)_context.FindNode("Input/DELP_UNITS").get_Value(Type.Missing);
			text5 = (dynamic)_context.FindNode("Input/DP_FLOW_UNIT").get_Value(Type.Missing);
			title = wpfPLComprResources.Performance_Title_DeltP;
			text4 = wpfPLComprResources.Performance_YAxisTitle_DeltP;
			if (!string.IsNullOrEmpty(text6))
			{
				text4 = text4 + " " + text6.ToLower();
			}
		}
		_wizardPlot.PlotVal.Title = title;
		if (!string.IsNullOrEmpty(text5))
		{
			text3 += text5.ToLower();
		}
		_wizardPlot.PlotVal.XAxisTitle = text3;
		((IHPlotVal)_wizardPlot.PlotVal).set_YAxisTitle((object)null, text4);
	}
}
