using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLSolid;

[RibbonPlotWizardMgr("WpfPLSOLID.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class SolidPlotWizardModule : PlotModuleBase
{
}
