# Settings.cs

Source: editable/AspenTech/AspenPlus/EOVariableList/Properties/Settings.cs

Source SHA-256: 315bbb7517c9318cb60205156681c7e986066449ac125060eb1f93a47b8feabe
