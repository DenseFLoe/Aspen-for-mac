"""Minimal CLR metadata token resolver for remapping method-body operands.

Builds a semantic key for each metadata token (TypeDef/TypeRef/TypeSpec/Field/
MethodDef/MemberRef/MethodSpec and #US string offsets) so that a compiler
candidate's tokens can be matched to the original's tokens by meaning.
"""
import struct
import sys
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")
sys.path.insert(0, str(BASE / "router" / "managed"))
import clr_meta

US = 0x70
TOKEN_TABLES = {0x01: "TypeRef", 0x02: "TypeDef", 0x04: "Field", 0x06: "MethodDef",
                0x0A: "MemberRef", 0x1B: "TypeSpec", 0x2B: "MethodSpec", 0x70: "US"}


class Image:
    def __init__(self, data, label=""):
        self.data = data
        self.label = label
        self.pe, self.cli, self.root = clr_meta.read_image(data)
        self.content = self.root["bytes"]
        self.tables = self.root["tables"]
        self._typedefs = None
        self._method_owner = None
        self._field_owner = None

    # ---------- heaps
    def string(self, index):
        return clr_meta.strings(self.pe, self.cli, self.root, index)

    def blob(self, index):
        return clr_meta.blob(self.pe, self.cli, self.root, index)

    def blob_bytes(self, index):
        # botched return guard: blob() returns bytes in this reader
        value = self.blob(index)
        if isinstance(value, str):
            return value.encode()
        return value if isinstance(value, bytes) else bytes(value)

    def us(self, offset):
        heap = self.root["streams"]["#US"]
        base = self.cli["metadata_rva"] + heap["offset"] + offset
        raw = self.pe.get_data(base, heap["size"] - offset)
        if not raw:
            return ""
        b = raw[0]
        if b & 0x80 == 0:
            width, at = 1, 1
        elif b & 0xC0 == 0x80:
            width, at = 2, 2
        elif b & 0xE0 == 0xC0:
            width, at = 4, 3
        else:
            raise ValueError("bad #US length prefix")
        size = int.from_bytes(raw[1:at], "big") if width > 1 else b
        payload = raw[at:at + size]
        # ECMA-335 II.24.2.4: the length includes one trailing flag byte.
        if size % 2:
            payload = payload[:size - 1]
        return payload.decode("utf-16-le", "replace")

    # ---------- rows
    def row(self, table, index):
        return clr_meta.read_row(self.content, self.tables, table, index)

    def count(self, table):
        return self.tables["rows"].get(table, 0)

    def coded(self, name, value):
        bits, targets = clr_meta.CODED[name]
        tag = value & ((1 << bits) - 1)
        index = value >> bits
        table = targets[tag]
        return table, index

    # ---------- type names
    def _typedef_names(self):
        if self._typedefs is None:
            names = {}
            for i in range(1, self.count(0x02) + 1):
                r = self.row(0x02, i)
                names[i] = (self.string(r[2]), self.string(r[1]))
            # nested type names use the declaring type's namespace
            nested = {}
            for i in range(1, self.count(0x29) + 1):
                r = self.row(0x29, i)
                nested[r[0]] = r[1]  # nested -> enclosing
            self._typedefs = (names, nested)
        return self._typedefs

    def typedef_key(self, index):
        names, nested = self._typedefs_names()
        if index in nested:
            return self.typedef_key(nested[index]) + "/" + names[index][1]
        ns, name = names[index]
        return "T:" + ((ns + ".") if ns else "") + name

    def _typedefs_names(self):
        return self._typedef_names()

    def _scope_key(self, value):
        table, index = self.coded("ResolutionScope", value)
        if table == 0x00:      # Module
            return "module"
        if table == 0x1A:      # ModuleRef
            return "modref:" + self.string(self.row(0x1A, index)[1])
        if table == 0x23:      # AssemblyRef
            return "asmref:" + self.string(self.row(0x23, index)[6])
        if table == 0x01:      # TypeRef (nested)
            return self.typeref_key(index)
        raise ValueError("bad ResolutionScope")

    def typeref_key(self, index):
        r = self.row(0x01, index)
        ns, name = self.string(r[2]), self.string(r[1])
        return "TR:" + self._scope_key(r[0]) + "|" + ((ns + ".") if ns else "") + name

    def typespec_key(self, index):
        r = self.row(0x1B, index)
        blob = self.blob_bytes(r[0])
        try:
            value, _ = self._sig_type(blob, 0)
            return "TS:" + value
        except Exception:
            return "TS:raw:" + blob.hex()

    def type_key(self, table, index):
        if table == 0x02:
            return self.typedef_key(index)
        if table == 0x01:
            return self.typeref_key(index)
        if table == 0x1B:
            return self.typespec_key(index)
        raise ValueError("not a type")

    # ---------- signature normalization
    @staticmethod
    def _compress(data, at):
        b = data[at]
        if b & 0x80 == 0:
            return b, at + 1
        if b & 0xC0 == 0x80:
            return ((b & 0x3F) << 8) | data[at + 1], at + 2
        return ((b & 0x1F) << 24) | (data[at + 1] << 16) | (data[at + 2] << 8) | data[at + 3], at + 4

    PRIMITIVES = {0x01: "VOID", 0x02: "BOOLEAN", 0x03: "CHAR", 0x04: "I1", 0x05: "U1",
                  0x06: "I2", 0x07: "U2", 0x08: "I4", 0x09: "U4", 0x0A: "I8", 0x0B: "U8",
                  0x0C: "R4", 0x0D: "R8", 0x0E: "STRING", 0x16: "TYPEDBYREF", 0x18: "I",
                  0x19: "U", 0x1C: "OBJECT"}

    def _sig_type(self, data, at):
        et = data[at]
        at += 1
        if et in self.PRIMITIVES:
            return self.PRIMITIVES[et], at
        if et in (0x11, 0x12):  # VALUETYPE / CLASS
            value, at = self._compress(data, at)
            table, index = self.coded("TypeDefOrRef", value)
            return "[" + self.type_key(table, index) + "]", at
        if et in (0x0F, 0x10, 0x1D, 0x45):  # PTR/BYREF/SZARRAY/PINNED
            inner, at = self._sig_type(data, at)
            return {"0F": "PTR(", "10": "BYREF(", "1D": "SZARRAY(", "45": "PINNED("}[format(et, "02X")] + inner + ")", at
        if et in (0x13, 0x1E):  # VAR / MVAR
            value, at = self._compress(data, at)
            return "%s%d" % ("!" if et == 0x13 else "!!", value), at
        if et == 0x15:  # GENERICINST
            kind = data[at]
            value, at = self._compress(data, at + 1)
            table, index = self.coded("TypeDefOrRef", value)
            count, at = self._compress(data, at)
            args = []
            for _ in range(count):
                arg, at = self._sig_type(data, at)
                args.append(arg)
            return "GENERIC(%s;%s)" % (self.type_key(table, index), ",".join(args)), at
        if et == 0x14:  # ARRAY
            inner, at = self._sig_type(data, at)
            rank, at = self._compress(data, at)
            nums, at = self._compress(data, at)
            for _ in range(nums):
                _, at = self._compress(data, at)
            lows, at = self._compress(data, at)
            for _ in range(lows):
                _, at = self._compress(data, at)
            return "ARRAY%d(%s)" % (rank, inner), at
        if et in (0x1F, 0x20):  # CMOD_REQD / CMOD_OPT
            value, at = self._compress(data, at)
            table, index = self.coded("TypeDefOrRef", value)
            inner, at = self._sig_type(data, at)
            return "CMOD(%s;%s)" % (self.type_key(table, index), inner), at
        if et == 0x1B:  # FNPTR
            raise ValueError("FNPTR signatures are not normalized")
        raise ValueError("unsupported element type %02x" % et)

    def sig_norm(self, blob, kind):
        at = 0
        conv = blob[at]
        at += 1
        header = ["conv%02x" % conv]
        if kind == "method":
            count, at = self._compress(blob, at)
            ret, at = self._sig_type(blob, at)
            header.append("ret=%s" % ret)
            params = []
            if conv & 0x10:  # GENERIC
                gcount, at = self._compress(blob, at)
                params.append("gen=%d" % gcount)
            for _ in range(count):
                p, at = self._sig_type(blob, at)
                params.append(p)
            return "|".join(header + params)
        ret, at = self._sig_type(blob, at)
        return "|".join(header + ["type=%s" % ret])

    # ---------- member owners
    def _owners(self):
        if self._method_owner is None:
            owners = {}
            total = self.count(0x06)
            tcount = self.count(0x02)
            for i in range(1, tcount + 1):
                start = self.row(0x02, i)[5]
                end = self.row(0x02, i + 1)[5] if i < tcount else total + 1
                for m in range(start, end):
                    owners[m] = i
            self._method_owner = owners
            fowners = {}
            ftotal = self.count(0x04)
            for i in range(1, tcount + 1):
                start = self.row(0x02, i)[4]
                end = self.row(0x02, i + 1)[4] if i < tcount else ftotal + 1
                for f in range(start, end):
                    fowners[f] = i
            self._field_owner = fowners
        return self._method_owner, self._field_owner

    def _sig(self, index, kind):
        blob = self.blob_bytes(index)
        try:
            return self.sig_norm(blob, kind)
        except Exception:
            return "raw:" + blob.hex()

    def method_key(self, index):
        owners, _ = self._owners()
        r = self.row(0x06, index)
        return "M:" + self.typedef_key(owners.get(index, 0)) + "|" + self.string(r[3]) + "|" + self._sig(r[4], "method")

    def field_key(self, index):
        _, owners = self._owners()
        r = self.row(0x04, index)
        return "F:" + self.typedef_key(owners.get(index, 0)) + "|" + self.string(r[1]) + "|" + self._sig(r[2], "field")

    def memberref_key(self, index):
        r = self.row(0x0A, index)
        table, parent = self.coded("MemberRefParent", r[0])
        if table in (0x02, 0x01, 0x1B):
            owner = self.type_key(table, parent)
        elif table == 0x1A:
            owner = "modref:" + self.string(self.row(0x1A, parent)[1])
        elif table == 0x06:
            owner = self.method_key(parent)
        else:
            raise ValueError("bad MemberRefParent")
        kind = "field" if self.blob_bytes(r[2])[:1] == b"\x06" else "method"
        return "MR:" + owner + "|" + self.string(r[1]) + "|" + self._sig(r[2], kind)

    def methodspec_key(self, index):
        r = self.row(0x2B, index)
        table, target = self.coded("MethodDefOrRef", r[0])
        inner = self.method_key(target) if table == 0x06 else self.memberref_key(target)
        return "MS:" + inner + "|" + self._sig(r[1], "method")

    def standalonesig_key(self, index):
        r = self.row(0x11, index)
        blob = self.blob_bytes(r[0])
        try:
            if blob and blob[0] == 0x07:  # LOCAL_SIG
                count, at = self._compress(blob, 1)
                parts = []
                for _ in range(count):
                    t, at = self._sig_type(blob, at)
                    parts.append(t)
                return "L:" + ",".join(parts)
            return "SAS:" + self.sig_norm(blob, "method")
        except Exception:
            return "SAS:raw:" + blob.hex()

    def token_key(self, token):
        table = token >> 24
        index = token & 0xFFFFFF
        if table == 0x70:
            return "S:" + self.us(index)
        if table == 0x02:
            return self.typedef_key(index)
        if table == 0x01:
            return self.typeref_key(index)
        if table == 0x04:
            return self.field_key(index)
        if table == 0x06:
            return self.method_key(index)
        if table == 0x0A:
            return self.memberref_key(index)
        if table == 0x1B:
            return self.typespec_key(index)
        if table == 0x2B:
            return self.methodspec_key(index)
        if table == 0x11:
            return self.standalonesig_key(index)
        raise ValueError("no key for token %08x" % token)

    def valid_token(self, token):
        table = token >> 24
        index = token & 0xFFFFFF
        limits = {0x01: 0x01, 0x02: 0x02, 0x04: 0x04, 0x06: 0x06, 0x0A: 0x0A,
                  0x11: 0x11, 0x1B: 0x1B, 0x2B: 0x2B}
        if table == 0x70:
            heap = self.root["streams"]["#US"]
            return index < heap["size"]
        if table not in limits:
            return False
        return 1 <= index <= self.count(table)


def body_diff_map(orig_img, cand_img, orig_body, cand_body):
    """Return (remaps, leftover) where remaps map differing token operands."""
    if len(orig_body) != len(cand_body):
        return [], [{"reason": "length", "orig": len(orig_body), "cand": len(cand_body)}]
    diffs = [i for i in range(len(orig_body)) if orig_body[i] != cand_body[i]]
    if not diffs:
        return [], []
    used = set()
    remaps, leftover = [], []
    for pos in diffs:
        if pos in used:
            continue
        found = False
        for start in (pos, pos - 1, pos - 2, pos - 3):
            if start < 0 or start + 4 > len(orig_body) or start in used:
                continue
            o = struct.unpack_from("<I", orig_body, start)[0]
            c = struct.unpack_from("<I", cand_body, start)[0]
            if o == c:
                continue
            try:
                if not (orig_img.valid_token(o) and cand_img.valid_token(c)):
                    continue
                ok = orig_img.token_key(o)
                ck = cand_img.token_key(c)
            except Exception:
                continue
            if ok != ck:
                continue
            remaps.append({"method_offset": start, "candidate_token": c, "original_token": o,
                           "semantic_key": ok})
            used.update(range(start, start + 4))
            found = True
            break
        if not found and pos not in used:
            leftover.append({"offset": pos, "orig": orig_body[pos], "cand": cand_body[pos]})
            used.add(pos)
    return remaps, leftover
