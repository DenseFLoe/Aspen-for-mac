; ApwnRes.dll native implementation for the preserved PE RVA layout.
; BITS 64, NASM flat-binary output. Numeric image labels name mapped data cells.
bits 64
org 0x1000
%include "register-encoding.inc"

image_0000                                  equ $$ - 0x1000
image_003c                                  equ $$ - 0xfc4
iat_GetCurrentThreadId                      equ $$ + 0x1000
iat_RtlVirtualUnwind                        equ $$ + 0x1008
iat_RtlLookupFunctionEntry                  equ $$ + 0x1010
iat_RtlCaptureContext                       equ $$ + 0x1018
iat_SetUnhandledExceptionFilter             equ $$ + 0x1020
iat_GetCurrentProcess                       equ $$ + 0x1028
iat_IsDebuggerPresent                       equ $$ + 0x1030
iat_InitializeSListHead                     equ $$ + 0x1038
iat_GetSystemTimeAsFileTime                 equ $$ + 0x1040
iat_UnhandledExceptionFilter                equ $$ + 0x1048
iat_GetCurrentProcessId                     equ $$ + 0x1050
iat_QueryPerformanceCounter                 equ $$ + 0x1058
iat_IsProcessorFeaturePresent               equ $$ + 0x1060
iat_TerminateProcess                        equ $$ + 0x1068
iat_memcpy                                  equ $$ + 0x1078
iat___std_type_info_destroy_list            equ $$ + 0x1080
iat___C_specific_handler                    equ $$ + 0x1088
iat_memset                                  equ $$ + 0x1090
iat__cexit                                  equ $$ + 0x10a0
iat__execute_onexit_table                   equ $$ + 0x10a8
iat__initialize_onexit_table                equ $$ + 0x10b0
iat__initialize_narrow_environment          equ $$ + 0x10b8
iat__configure_narrow_argv                  equ $$ + 0x10c0
iat__seh_filter_dll                         equ $$ + 0x10c8
iat__initterm_e                             equ $$ + 0x10d0
iat__initterm                               equ $$ + 0x10d8
guard_dispatch_slot                         equ $$ + 0x10f8
image_2120                                  equ $$ + 0x1120
image_2128                                  equ $$ + 0x1128
image_2130                                  equ $$ + 0x1130
image_2138                                  equ $$ + 0x1138
raw_dllmain_hook                            equ $$ + 0x1160
gs_failure_pointers                         equ $$ + 0x1168
image_2180                                  equ $$ + 0x1180
image_2690                                  equ $$ + 0x1690
image_26a0                                  equ $$ + 0x16a0
security_cookie_complement                  equ $$ + 0x2000
security_cookie                             equ $$ + 0x2008
image_3018                                  equ $$ + 0x2018
image_301c                                  equ $$ + 0x201c
image_3020                                  equ $$ + 0x2020
image_3028                                  equ $$ + 0x2028
image_3030                                  equ $$ + 0x2030
image_3040                                  equ $$ + 0x2040
gs_failure_exception_record                 equ $$ + 0x2050
gs_failure_exception_flags                  equ $$ + 0x2054
gs_failure_exception_address                equ $$ + 0x2060
gs_failure_exception_param_count            equ $$ + 0x2068
gs_failure_exception_param                  equ $$ + 0x2070
gs_failure_context                          equ $$ + 0x20f0
gs_failure_context_rcx                      equ $$ + 0x2170
gs_failure_context_rsp                      equ $$ + 0x2188
gs_failure_context_rip                      equ $$ + 0x21e8
image_35c0                                  equ $$ + 0x25c0
image_35d0                                  equ $$ + 0x25d0
image_35d8                                  equ $$ + 0x25d8
image_35e0                                  equ $$ + 0x25e0
image_35e8                                  equ $$ + 0x25e8
image_35f0                                  equ $$ + 0x25f0
image_35f1                                  equ $$ + 0x25f1
image_35f8                                  equ $$ + 0x25f8
image_3608                                  equ $$ + 0x2608
image_3610                                  equ $$ + 0x2610
image_3620                                  equ $$ + 0x2620
image_3628                                  equ $$ + 0x2628
image_362c                                  equ $$ + 0x262c
image_3638                                  equ $$ + 0x2638

; RVA 1000  DllMain
fn_DllMain_1000:
    mov eax, 1                                                   ; 1000+5
    ret                                                          ; 1005+1
    int3                                                         ; 1006+1
    int3                                                         ; 1007+1
    int3                                                         ; 1008+1
    int3                                                         ; 1009+1
    int3                                                         ; 100a+1
    int3                                                         ; 100b+1
    int3                                                         ; 100c+1
    int3                                                         ; 100d+1
    int3                                                         ; 100e+1
    int3                                                         ; 100f+1
    int3                                                         ; 1010+1
    int3                                                         ; 1011+1
    int3                                                         ; 1012+1
    int3                                                         ; 1013+1
    int3                                                         ; 1014+1
    int3                                                         ; 1015+1
    db 0x66, 0x66, 0x0f, 0x1f, 0x84, 0x00, 0x00, 0x00, 0x00, 0x00 ; 1016+10 original multi-byte alignment NOP

; RVA 1020  __security_check_cookie
fn___security_check_cookie_1020:
    cmp rcx, qword [rel security_cookie]                         ; 1020+7
    jne short loc_1039                                           ; 1027+2
    rol rcx, 0x10                                                ; 1029+4
    test cx, 0xffff                                              ; 102d+5
    jne short loc_1035                                           ; 1032+2
    ret                                                          ; 1034+1
loc_1035:
    ror rcx, 0x10                                                ; 1035+4
loc_1039:
    jmp near fn___report_gsfailure_13d4                          ; 1039+5
    int3                                                         ; 103e+1
    int3                                                         ; 103f+1

; RVA 1040  ?dllmain_crt_dispatch@@YAHQEAUHINSTANCE__@@KQEAX@Z
fn__dllmain_crt_dispatch__YAHQEAUHINSTANCE____KQEAX_Z_1040:
    sub rsp, 0x28                                                ; 1040+4
    test edx, edx                                                ; 1044+2
    je short loc_1081                                            ; 1046+2
    sub edx, 1                                                   ; 1048+3
    je short loc_1075                                            ; 104b+2
    sub edx, 1                                                   ; 104d+3
    je short loc_1068                                            ; 1050+2
    cmp edx, 1                                                   ; 1052+3
    je short loc_1061                                            ; 1055+2
    mov eax, 1                                                   ; 1057+5
    add rsp, 0x28                                                ; 105c+4
    ret                                                          ; 1060+1
loc_1061:
    call fn___scrt_dllmain_crt_thread_detach_16c0                ; 1061+5
    jmp short loc_106d                                           ; 1066+2
loc_1068:
    call fn___scrt_dllmain_crt_thread_attach_1698                ; 1068+5
loc_106d:
    movzx eax, al                                                ; 106d+3
    add rsp, 0x28                                                ; 1070+4
    ret                                                          ; 1074+1
loc_1075:
    mov_r_rm(rdx, r8)                                            ; 1075+3
    add rsp, 0x28                                                ; 1078+4
    jmp near fn__dllmain_crt_process_attach__YAHQEAUHINSTANCE____QEAX_Z_1090 ; 107c+5
loc_1081:
    test r8, r8                                                  ; 1081+3
    setne cl                                                     ; 1084+3
    add rsp, 0x28                                                ; 1087+4
    jmp near fn__dllmain_crt_process_detach__YAH_N_Z_11a8        ; 108b+5

; RVA 1090  ?dllmain_crt_process_attach@@YAHQEAUHINSTANCE__@@QEAX@Z
fn__dllmain_crt_process_attach__YAHQEAUHINSTANCE____QEAX_Z_1090:
    mov qword [rsp + 8], rbx                                     ; 1090+5
    mov qword [rsp + 0x10], rsi                                  ; 1095+5
    mov qword [rsp + 0x20], rdi                                  ; 109a+5
    push r14                                                     ; 109f+2
    sub rsp, 0x20                                                ; 10a1+4
    mov_r_rm(rsi, rdx)                                           ; 10a5+3
    mov_r_rm(r14, rcx)                                           ; 10a8+3
    xor_r_rm(ecx, ecx)                                           ; 10ab+2
    call fn___scrt_initialize_crt_177c                           ; 10ad+5
    test al, al                                                  ; 10b2+2
    je near loc_1182                                             ; 10b4+6
    call fn___scrt_acquire_startup_lock_1610                     ; 10ba+5
    mov_r_rm(bl, al)                                             ; 10bf+2
    mov byte [rsp + 0x40], al                                    ; 10c1+4
    mov dil, 1                                                   ; 10c5+3
    cmp dword [rel image_35e0], 0                                ; 10c8+7
    jne near loc_119a                                            ; 10cf+6
    mov dword [rel image_35e0], 1                                ; 10d5+10
    call fn___scrt_dllmain_before_initialize_c_1680              ; 10df+5
    test al, al                                                  ; 10e4+2
    je short loc_1137                                            ; 10e6+2
    call fn__RTC_Initialize_1a98                                 ; 10e8+5
    call fn____scrt_initialize_type_info__YAXXZ_15c8             ; 10ed+5
    call fn___scrt_initialize_default_local_stdio_options_15f4   ; 10f2+5
    lea rdx, [rel image_2138]                                    ; 10f7+7
    lea rcx, [rel image_2130]                                    ; 10fe+7
    call fn__initterm_e_1ce8                                     ; 1105+5
    test eax, eax                                                ; 110a+2
    jne short loc_1137                                           ; 110c+2
    call fn___scrt_dllmain_after_initialize_c_164c               ; 110e+5
    test al, al                                                  ; 1113+2
    je short loc_1137                                            ; 1115+2
    lea rdx, [rel image_2128]                                    ; 1117+7
    lea rcx, [rel image_2120]                                    ; 111e+7
    call fn__initterm_1ce2                                       ; 1125+5
    mov dword [rel image_35e0], 2                                ; 112a+10
    xor_r_rm(dil, dil)                                           ; 1134+3
loc_1137:
    mov_r_rm(cl, bl)                                             ; 1137+2
    call fn___scrt_release_startup_lock_18ec                     ; 1139+5
    test dil, dil                                                ; 113e+3
    jne short loc_1182                                           ; 1141+2
    call fn___scrt_get_dyn_tls_init_callback_193c                ; 1143+5
    mov_r_rm(rbx, rax)                                           ; 1148+3
    cmp qword [rax], 0                                           ; 114b+4
    je short loc_1175                                            ; 114f+2
    mov_r_rm(rcx, rax)                                           ; 1151+3
    call fn___scrt_is_nonwritable_in_current_image_1854          ; 1154+5
    test al, al                                                  ; 1159+2
    je short loc_1175                                            ; 115b+2
    mov_r_rm(r8, rsi)                                            ; 115d+3
    mov edx, 2                                                   ; 1160+5
    mov_r_rm(rcx, r14)                                           ; 1165+3
    mov rax, qword [rbx]                                         ; 1168+3
    mov r9, qword [rel guard_dispatch_slot]                      ; 116b+7
    call r9                                                      ; 1172+3
loc_1175:
    inc dword [rel image_3040]                                   ; 1175+6
    mov eax, 1                                                   ; 117b+5
    jmp short loc_1184                                           ; 1180+2
loc_1182:
    xor_r_rm(eax, eax)                                           ; 1182+2
loc_1184:
    mov rbx, qword [rsp + 0x30]                                  ; 1184+5
    mov rsi, qword [rsp + 0x38]                                  ; 1189+5
    mov rdi, qword [rsp + 0x48]                                  ; 118e+5
    add rsp, 0x20                                                ; 1193+4
    pop r14                                                      ; 1197+2
    ret                                                          ; 1199+1
loc_119a:
    mov ecx, 7                                                   ; 119a+5
    call fn___scrt_fastfail_194c                                 ; 119f+5
    nop                                                          ; 11a4+1
    int3                                                         ; 11a5+1
    int3                                                         ; 11a6+1
    int3                                                         ; 11a7+1

; RVA 11a8  ?dllmain_crt_process_detach@@YAH_N@Z
fn__dllmain_crt_process_detach__YAH_N_Z_11a8:
    mov qword [rsp + 8], rbx                                     ; 11a8+5
    push rdi                                                     ; 11ad+1
    sub rsp, 0x30                                                ; 11ae+4
    mov_r_rm(dil, cl)                                            ; 11b2+3
    mov eax, dword [rel image_3040]                              ; 11b5+6
    test eax, eax                                                ; 11bb+2
    jg short loc_11cc                                            ; 11bd+2
    xor_r_rm(eax, eax)                                           ; 11bf+2
loc_11c1:
    mov rbx, qword [rsp + 0x40]                                  ; 11c1+5
    add rsp, 0x30                                                ; 11c6+4
    pop rdi                                                      ; 11ca+1
    ret                                                          ; 11cb+1
loc_11cc:
    dec eax                                                      ; 11cc+2
    mov dword [rel image_3040], eax                              ; 11ce+6
    call fn___scrt_acquire_startup_lock_1610                     ; 11d4+5
    mov_r_rm(bl, al)                                             ; 11d9+2
    mov byte [rsp + 0x20], al                                    ; 11db+4
    cmp dword [rel image_35e0], 2                                ; 11df+7
    jne short loc_121f                                           ; 11e6+2
    call fn___scrt_dllmain_uninitialize_c_1738                   ; 11e8+5
    call fn____scrt_uninitialize_type_info__YAXXZ_15d8           ; 11ed+5
    call fn__RTC_Terminate_1ad4                                  ; 11f2+5
    and dword [rel image_35e0], 0                                ; 11f7+7
    mov_r_rm(cl, bl)                                             ; 11fe+2
    call fn___scrt_release_startup_lock_18ec                     ; 1200+5
    xor_r_rm(edx, edx)                                           ; 1205+2
    mov_r_rm(cl, dil)                                            ; 1207+3
    call fn___scrt_uninitialize_crt_1910                         ; 120a+5
    neg al                                                       ; 120f+2
    sbb_r_rm(ebx, ebx)                                           ; 1211+2
    and ebx, 1                                                   ; 1213+3
    call fn___scrt_dllmain_uninitialize_critical_1768            ; 1216+5
    mov_r_rm(eax, ebx)                                           ; 121b+2
    jmp short loc_11c1                                           ; 121d+2
loc_121f:
    mov ecx, 7                                                   ; 121f+5
    call fn___scrt_fastfail_194c                                 ; 1224+5
    nop                                                          ; 1229+1
    nop                                                          ; 122a+1
    int3                                                         ; 122b+1

; RVA 122c  ?dllmain_dispatch@@YAHQEAUHINSTANCE__@@KQEAX@Z
fn__dllmain_dispatch__YAHQEAUHINSTANCE____KQEAX_Z_122c:
    mov_r_rm(rax, rsp)                                           ; 122c+3
    mov qword [rax + 0x20], rbx                                  ; 122f+4
    mov qword [rax + 0x18], r8                                   ; 1233+4
    mov dword [rax + 0x10], edx                                  ; 1237+3
    mov qword [rax + 8], rcx                                     ; 123a+4
    push rsi                                                     ; 123e+1
    push rdi                                                     ; 123f+1
    push r14                                                     ; 1240+2
    sub rsp, 0x40                                                ; 1242+4
    mov_r_rm(rsi, r8)                                            ; 1246+3
    mov_r_rm(edi, edx)                                           ; 1249+2
    mov_r_rm(r14, rcx)                                           ; 124b+3
    test edx, edx                                                ; 124e+2
    jne short loc_1261                                           ; 1250+2
    cmp dword [rel image_3040], edx                              ; 1252+6
    jg short loc_1261                                            ; 1258+2
    xor_r_rm(eax, eax)                                           ; 125a+2
    jmp near loc_134f                                            ; 125c+5
loc_1261:
    lea eax, [rdx - 1]                                           ; 1261+3
    cmp eax, 1                                                   ; 1264+3
    ja short loc_12ae                                            ; 1267+2
    mov rax, qword [rel raw_dllmain_hook]                        ; 1269+7
    test rax, rax                                                ; 1270+3
    jne short loc_127f                                           ; 1273+2
    mov dword [rsp + 0x30], 1                                    ; 1275+8
    jmp short loc_1293                                           ; 127d+2
loc_127f:
    call qword [rel guard_dispatch_slot]                         ; 127f+6
    mov_r_rm(ebx, eax)                                           ; 1285+2
    mov dword [rsp + 0x30], eax                                  ; 1287+4
    test eax, eax                                                ; 128b+2
    je near loc_1345                                             ; 128d+6
loc_1293:
    mov_r_rm(r8, rsi)                                            ; 1293+3
    mov_r_rm(edx, edi)                                           ; 1296+2
    mov_r_rm(rcx, r14)                                           ; 1298+3
    call fn__dllmain_crt_dispatch__YAHQEAUHINSTANCE____KQEAX_Z_1040 ; 129b+5
    mov_r_rm(ebx, eax)                                           ; 12a0+2
    mov dword [rsp + 0x30], eax                                  ; 12a2+4
    test eax, eax                                                ; 12a6+2
    je near loc_1345                                             ; 12a8+6
loc_12ae:
    mov_r_rm(r8, rsi)                                            ; 12ae+3
    mov_r_rm(edx, edi)                                           ; 12b1+2
    mov_r_rm(rcx, r14)                                           ; 12b3+3
    call fn_DllMain_1000                                         ; 12b6+5
    mov_r_rm(ebx, eax)                                           ; 12bb+2
    mov dword [rsp + 0x30], eax                                  ; 12bd+4
    cmp edi, 1                                                   ; 12c1+3
    jne short loc_12fc                                           ; 12c4+2
    test eax, eax                                                ; 12c6+2
    jne short loc_12fc                                           ; 12c8+2
    mov_r_rm(r8, rsi)                                            ; 12ca+3
    xor_r_rm(edx, edx)                                           ; 12cd+2
    mov_r_rm(rcx, r14)                                           ; 12cf+3
    call fn_DllMain_1000                                         ; 12d2+5
    test rsi, rsi                                                ; 12d7+3
    setne cl                                                     ; 12da+3
    call fn__dllmain_crt_process_detach__YAH_N_Z_11a8            ; 12dd+5
    mov rax, qword [rel raw_dllmain_hook]                        ; 12e2+7
    test rax, rax                                                ; 12e9+3
    je short loc_12fc                                            ; 12ec+2
    mov_r_rm(r8, rsi)                                            ; 12ee+3
    xor_r_rm(edx, edx)                                           ; 12f1+2
    mov_r_rm(rcx, r14)                                           ; 12f3+3
    call qword [rel guard_dispatch_slot]                         ; 12f6+6
loc_12fc:
    test edi, edi                                                ; 12fc+2
    je short loc_1305                                            ; 12fe+2
    cmp edi, 3                                                   ; 1300+3
    jne short loc_1345                                           ; 1303+2
loc_1305:
    mov_r_rm(r8, rsi)                                            ; 1305+3
    mov_r_rm(edx, edi)                                           ; 1308+2
    mov_r_rm(rcx, r14)                                           ; 130a+3
    call fn__dllmain_crt_dispatch__YAHQEAUHINSTANCE____KQEAX_Z_1040 ; 130d+5
    mov_r_rm(ebx, eax)                                           ; 1312+2
    mov dword [rsp + 0x30], eax                                  ; 1314+4
    test eax, eax                                                ; 1318+2
    je short loc_1345                                            ; 131a+2
    mov rax, qword [rel raw_dllmain_hook]                        ; 131c+7
    test rax, rax                                                ; 1323+3
    jne short loc_1331                                           ; 1326+2
    lea ebx, [rax + 1]                                           ; 1328+3
    mov dword [rsp + 0x30], ebx                                  ; 132b+4
    jmp short loc_1345                                           ; 132f+2
loc_1331:
    mov_r_rm(r8, rsi)                                            ; 1331+3
    mov_r_rm(edx, edi)                                           ; 1334+2
    mov_r_rm(rcx, r14)                                           ; 1336+3
    call qword [rel guard_dispatch_slot]                         ; 1339+6
    mov_r_rm(ebx, eax)                                           ; 133f+2
    mov dword [rsp + 0x30], eax                                  ; 1341+4
loc_1345:
    jmp short loc_134d                                           ; 1345+2
    xor_r_rm(ebx, ebx)                                           ; 1347+2
    mov dword [rsp + 0x30], ebx                                  ; 1349+4
loc_134d:
    mov_r_rm(eax, ebx)                                           ; 134d+2
loc_134f:
    mov rbx, qword [rsp + 0x78]                                  ; 134f+5
    add rsp, 0x40                                                ; 1354+4
    pop r14                                                      ; 1358+2
    pop rdi                                                      ; 135a+1
    pop rsi                                                      ; 135b+1
    ret                                                          ; 135c+1
    int3                                                         ; 135d+1
    int3                                                         ; 135e+1
    int3                                                         ; 135f+1

; RVA 1360  DllEntryPoint
fn_DllEntryPoint_1360:
    mov qword [rsp + 8], rbx                                     ; 1360+5
    mov qword [rsp + 0x10], rsi                                  ; 1365+5
    push rdi                                                     ; 136a+1
    sub rsp, 0x20                                                ; 136b+4
    mov_r_rm(rdi, r8)                                            ; 136f+3
    mov_r_rm(ebx, edx)                                           ; 1372+2
    mov_r_rm(rsi, rcx)                                           ; 1374+3
    cmp edx, 1                                                   ; 1377+3
    jne short loc_1381                                           ; 137a+2
    call fn___security_init_cookie_151c                          ; 137c+5
loc_1381:
    mov_r_rm(r8, rdi)                                            ; 1381+3
    mov_r_rm(edx, ebx)                                           ; 1384+2
    mov_r_rm(rcx, rsi)                                           ; 1386+3
    mov rbx, qword [rsp + 0x30]                                  ; 1389+5
    mov rsi, qword [rsp + 0x38]                                  ; 138e+5
    add rsp, 0x20                                                ; 1393+4
    pop rdi                                                      ; 1397+1
    jmp near fn__dllmain_dispatch__YAHQEAUHINSTANCE____KQEAX_Z_122c ; 1398+5
    int3                                                         ; 139d+1
    int3                                                         ; 139e+1
    int3                                                         ; 139f+1

; RVA 13a0  __raise_securityfailure
fn___raise_securityfailure_13a0:
    db 0x40
    push rbx                                         ; 13a0+2 original redundant REX prefix
    sub rsp, 0x20                                                ; 13a2+4
    mov_r_rm(rbx, rcx)                                           ; 13a6+3
    xor_r_rm(ecx, ecx)                                           ; 13a9+2
    call qword [rel iat_SetUnhandledExceptionFilter]             ; 13ab+6
    mov_r_rm(rcx, rbx)                                           ; 13b1+3
    call qword [rel iat_UnhandledExceptionFilter]                ; 13b4+6
    call qword [rel iat_GetCurrentProcess]                       ; 13ba+6
    mov_r_rm(rcx, rax)                                           ; 13c0+3
    mov edx, 0xc0000409                                          ; 13c3+5
    add rsp, 0x20                                                ; 13c8+4
    pop rbx                                                      ; 13cc+1
    db 0x48
    jmp qword [rel iat_TerminateProcess]             ; 13cd+7 original redundant REX.W prefix for the indirect jump

; RVA 13d4  __report_gsfailure
fn___report_gsfailure_13d4:
    mov qword [rsp + 8], rcx                                     ; 13d4+5
    sub rsp, 0x38                                                ; 13d9+4
    mov ecx, 0x17                                                ; 13dd+5
    call qword [rel iat_IsProcessorFeaturePresent]               ; 13e2+6
    test eax, eax                                                ; 13e8+2
    je short loc_13f3                                            ; 13ea+2
    mov ecx, 2                                                   ; 13ec+5
    int 0x29                                                     ; 13f1+2
loc_13f3:
    lea rcx, [rel gs_failure_context]                            ; 13f3+7
    call fn_capture_previous_context_14a8                        ; 13fa+5
    mov rax, qword [rsp + 0x38]                                  ; 13ff+5
    mov qword [rel gs_failure_context_rip], rax                  ; 1404+7
    lea rax, [rsp + 0x38]                                        ; 140b+5
    add rax, 8                                                   ; 1410+4
    mov qword [rel gs_failure_context_rsp], rax                  ; 1414+7
    mov rax, qword [rel gs_failure_context_rip]                  ; 141b+7
    mov qword [rel gs_failure_exception_address], rax            ; 1422+7
    mov rax, qword [rsp + 0x40]                                  ; 1429+5
    mov qword [rel gs_failure_context_rcx], rax                  ; 142e+7
    mov dword [rel gs_failure_exception_record], 0xc0000409      ; 1435+10
    mov dword [rel gs_failure_exception_flags], 1                ; 143f+10
    mov dword [rel gs_failure_exception_param_count], 1          ; 1449+10
    mov eax, 8                                                   ; 1453+5
    imul rax, rax, 0                                             ; 1458+4
    lea rcx, [rel gs_failure_exception_param]                    ; 145c+7
    mov qword [rcx + rax], 2                                     ; 1463+8
    mov eax, 8                                                   ; 146b+5
    imul rax, rax, 0                                             ; 1470+4
    mov rcx, qword [rel security_cookie]                         ; 1474+7
    mov qword [rsp + rax + 0x20], rcx                            ; 147b+5
    mov eax, 8                                                   ; 1480+5
    imul rax, rax, 1                                             ; 1485+4
    mov rcx, qword [rel security_cookie_complement]              ; 1489+7
    mov qword [rsp + rax + 0x20], rcx                            ; 1490+5
    lea rcx, [rel gs_failure_pointers]                           ; 1495+7
    call fn___raise_securityfailure_13a0                         ; 149c+5
    add rsp, 0x38                                                ; 14a1+4
    ret                                                          ; 14a5+1
    int3                                                         ; 14a6+1
    int3                                                         ; 14a7+1

; RVA 14a8  capture_previous_context
fn_capture_previous_context_14a8:
    db 0x40
    push rbx                                         ; 14a8+2 original redundant REX prefix
    push rsi                                                     ; 14aa+1
    push rdi                                                     ; 14ab+1
    sub rsp, 0x40                                                ; 14ac+4
    mov_r_rm(rbx, rcx)                                           ; 14b0+3
    call qword [rel iat_RtlCaptureContext]                       ; 14b3+6
    mov rsi, qword [rbx + 0xf8]                                  ; 14b9+7
    xor_r_rm(edi, edi)                                           ; 14c0+2
loc_14c2:
    xor_r_rm(r8d, r8d)                                           ; 14c2+3
    lea rdx, [rsp + 0x60]                                        ; 14c5+5
    mov_r_rm(rcx, rsi)                                           ; 14ca+3
    call qword [rel iat_RtlLookupFunctionEntry]                  ; 14cd+6
    test rax, rax                                                ; 14d3+3
    je short loc_1511                                            ; 14d6+2
    and qword [rsp + 0x38], 0                                    ; 14d8+6
    lea rcx, [rsp + 0x68]                                        ; 14de+5
    mov rdx, qword [rsp + 0x60]                                  ; 14e3+5
    mov_r_rm(r9, rax)                                            ; 14e8+3
    mov qword [rsp + 0x30], rcx                                  ; 14eb+5
    mov_r_rm(r8, rsi)                                            ; 14f0+3
    lea rcx, [rsp + 0x70]                                        ; 14f3+5
    mov qword [rsp + 0x28], rcx                                  ; 14f8+5
    xor_r_rm(ecx, ecx)                                           ; 14fd+2
    mov qword [rsp + 0x20], rbx                                  ; 14ff+5
    call qword [rel iat_RtlVirtualUnwind]                        ; 1504+6
    inc edi                                                      ; 150a+2
    cmp edi, 2                                                   ; 150c+3
    jl short loc_14c2                                            ; 150f+2
loc_1511:
    add rsp, 0x40                                                ; 1511+4
    pop rdi                                                      ; 1515+1
    pop rsi                                                      ; 1516+1
    pop rbx                                                      ; 1517+1
    ret                                                          ; 1518+1
    int3                                                         ; 1519+1
    int3                                                         ; 151a+1
    int3                                                         ; 151b+1

; RVA 151c  __security_init_cookie
fn___security_init_cookie_151c:
    mov qword [rsp + 0x18], rbx                                  ; 151c+5
    push rbp                                                     ; 1521+1
    mov_r_rm(rbp, rsp)                                           ; 1522+3
    sub rsp, 0x30                                                ; 1525+4
    mov rax, qword [rel security_cookie]                         ; 1529+7
    mov rbx, strict qword 0x2b992ddfa232                         ; 1530+10
    cmp_r_rm(rax, rbx)                                           ; 153a+3
    jne short loc_15b3                                           ; 153d+2
    and qword [rbp + 0x10], 0                                    ; 153f+5
    lea rcx, [rbp + 0x10]                                        ; 1544+4
    call qword [rel iat_GetSystemTimeAsFileTime]                 ; 1548+6
    mov rax, qword [rbp + 0x10]                                  ; 154e+4
    mov qword [rbp - 0x10], rax                                  ; 1552+4
    call qword [rel iat_GetCurrentThreadId]                      ; 1556+6
    mov_r_rm(eax, eax)                                           ; 155c+2
    xor qword [rbp - 0x10], rax                                  ; 155e+4
    call qword [rel iat_GetCurrentProcessId]                     ; 1562+6
    mov_r_rm(eax, eax)                                           ; 1568+2
    lea rcx, [rbp + 0x18]                                        ; 156a+4
    xor qword [rbp - 0x10], rax                                  ; 156e+4
    call qword [rel iat_QueryPerformanceCounter]                 ; 1572+6
    mov eax, dword [rbp + 0x18]                                  ; 1578+3
    lea rcx, [rbp - 0x10]                                        ; 157b+4
    shl rax, 0x20                                                ; 157f+4
    xor rax, qword [rbp + 0x18]                                  ; 1583+4
    xor rax, qword [rbp - 0x10]                                  ; 1587+4
    xor_r_rm(rax, rcx)                                           ; 158b+3
    mov rcx, strict qword 0xffffffffffff                         ; 158e+10
    and_r_rm(rax, rcx)                                           ; 1598+3
    mov rcx, strict qword 0x2b992ddfa233                         ; 159b+10
    cmp_r_rm(rax, rbx)                                           ; 15a5+3
    cmove rax, rcx                                               ; 15a8+4
    mov qword [rel security_cookie], rax                         ; 15ac+7
loc_15b3:
    mov rbx, qword [rsp + 0x50]                                  ; 15b3+5
    not rax                                                      ; 15b8+3
    mov qword [rel security_cookie_complement], rax              ; 15bb+7
    add rsp, 0x30                                                ; 15c2+4
    pop rbp                                                      ; 15c6+1
    ret                                                          ; 15c7+1

; RVA 15c8  ?__scrt_initialize_type_info@@YAXXZ
fn____scrt_initialize_type_info__YAXXZ_15c8:
    lea rcx, [rel image_35c0]                                    ; 15c8+7
    db 0x48
    jmp qword [rel iat_InitializeSListHead]          ; 15cf+7 original redundant REX.W prefix for the indirect jump
    int3                                                         ; 15d6+1
    int3                                                         ; 15d7+1

; RVA 15d8  ?__scrt_uninitialize_type_info@@YAXXZ
fn____scrt_uninitialize_type_info__YAXXZ_15d8:
    lea rcx, [rel image_35c0]                                    ; 15d8+7
    jmp near fn___std_type_info_destroy_list_1cd6                ; 15df+5

; RVA 15e4  __local_stdio_printf_options
fn___local_stdio_printf_options_15e4:
    lea rax, [rel image_35d0]                                    ; 15e4+7
    ret                                                          ; 15eb+1

; RVA 15ec  __local_stdio_scanf_options
fn___local_stdio_scanf_options_15ec:
    lea rax, [rel image_35d8]                                    ; 15ec+7
    ret                                                          ; 15f3+1

; RVA 15f4  __scrt_initialize_default_local_stdio_options
fn___scrt_initialize_default_local_stdio_options_15f4:
    sub rsp, 0x28                                                ; 15f4+4
    call fn___local_stdio_printf_options_15e4                    ; 15f8+5
    or qword [rax], 0x24                                         ; 15fd+4
    call fn___local_stdio_scanf_options_15ec                     ; 1601+5
    or qword [rax], 2                                            ; 1606+4
    add rsp, 0x28                                                ; 160a+4
    ret                                                          ; 160e+1
    int3                                                         ; 160f+1

; RVA 1610  __scrt_acquire_startup_lock
fn___scrt_acquire_startup_lock_1610:
    sub rsp, 0x28                                                ; 1610+4
    call fn___scrt_is_ucrt_dll_in_use_1cc0                       ; 1614+5
    test eax, eax                                                ; 1619+2
    je short loc_163e                                            ; 161b+2
    mov rax, qword [gs:0x30]                                     ; 161d+9
    mov rcx, qword [rax + 8]                                     ; 1626+4
    jmp short loc_1631                                           ; 162a+2
loc_162c:
    cmp_r_rm(rcx, rax)                                           ; 162c+3
    je short loc_1645                                            ; 162f+2
loc_1631:
    xor_r_rm(eax, eax)                                           ; 1631+2
    lock cmpxchg qword [rel image_35e8], rcx                     ; 1633+9
    jne short loc_162c                                           ; 163c+2
loc_163e:
    xor_r_rm(al, al)                                             ; 163e+2
loc_1640:
    add rsp, 0x28                                                ; 1640+4
    ret                                                          ; 1644+1
loc_1645:
    mov al, 1                                                    ; 1645+2
    jmp short loc_1640                                           ; 1647+2
    int3                                                         ; 1649+1
    int3                                                         ; 164a+1
    int3                                                         ; 164b+1

; RVA 164c  __scrt_dllmain_after_initialize_c
fn___scrt_dllmain_after_initialize_c_164c:
    sub rsp, 0x28                                                ; 164c+4
    call fn___scrt_is_ucrt_dll_in_use_1cc0                       ; 1650+5
    test eax, eax                                                ; 1655+2
    je short loc_1660                                            ; 1657+2
    call fn___isa_available_init_1b14                            ; 1659+5
    jmp short loc_1679                                           ; 165e+2
loc_1660:
    call fn_DllMain_1000                                         ; 1660+5
    mov_r_rm(ecx, eax)                                           ; 1665+2
    call fn__configure_narrow_argv_1cf4                          ; 1667+5
    test eax, eax                                                ; 166c+2
    je short loc_1674                                            ; 166e+2
    xor_r_rm(al, al)                                             ; 1670+2
    jmp short loc_167b                                           ; 1672+2
loc_1674:
    call fn__initialize_narrow_environment_1cfa                  ; 1674+5
loc_1679:
    mov al, 1                                                    ; 1679+2
loc_167b:
    add rsp, 0x28                                                ; 167b+4
    ret                                                          ; 167f+1

; RVA 1680  __scrt_dllmain_before_initialize_c
fn___scrt_dllmain_before_initialize_c_1680:
    sub rsp, 0x28                                                ; 1680+4
    xor_r_rm(ecx, ecx)                                           ; 1684+2
    call fn___scrt_initialize_onexit_tables_17c8                 ; 1686+5
    test al, al                                                  ; 168b+2
    setne al                                                     ; 168d+3
    add rsp, 0x28                                                ; 1690+4
    ret                                                          ; 1694+1
    int3                                                         ; 1695+1
    int3                                                         ; 1696+1
    int3                                                         ; 1697+1

; RVA 1698  __scrt_dllmain_crt_thread_attach
fn___scrt_dllmain_crt_thread_attach_1698:
    sub rsp, 0x28                                                ; 1698+4
    call fn___vcrt_thread_detach_1d14                            ; 169c+5
    test al, al                                                  ; 16a1+2
    jne short loc_16a9                                           ; 16a3+2
loc_16a5:
    xor_r_rm(al, al)                                             ; 16a5+2
    jmp short loc_16bb                                           ; 16a7+2
loc_16a9:
    call fn___vcrt_thread_detach_1d14                            ; 16a9+5
    test al, al                                                  ; 16ae+2
    jne short loc_16b9                                           ; 16b0+2
    call fn___vcrt_thread_detach_1d14                            ; 16b2+5
    jmp short loc_16a5                                           ; 16b7+2
loc_16b9:
    mov al, 1                                                    ; 16b9+2
loc_16bb:
    add rsp, 0x28                                                ; 16bb+4
    ret                                                          ; 16bf+1

; RVA 16c0  __scrt_dllmain_crt_thread_detach
fn___scrt_dllmain_crt_thread_detach_16c0:
    sub rsp, 0x28                                                ; 16c0+4
    call fn___vcrt_thread_detach_1d14                            ; 16c4+5
    call fn___vcrt_thread_detach_1d14                            ; 16c9+5
    mov al, 1                                                    ; 16ce+2
    add rsp, 0x28                                                ; 16d0+4
    ret                                                          ; 16d4+1
    int3                                                         ; 16d5+1
    int3                                                         ; 16d6+1
    int3                                                         ; 16d7+1

; RVA 16d8  __scrt_dllmain_exception_filter
fn___scrt_dllmain_exception_filter_16d8:
    mov qword [rsp + 8], rbx                                     ; 16d8+5
    mov qword [rsp + 0x10], rbp                                  ; 16dd+5
    mov qword [rsp + 0x18], rsi                                  ; 16e2+5
    push rdi                                                     ; 16e7+1
    sub rsp, 0x20                                                ; 16e8+4
    mov_r_rm(rdi, r9)                                            ; 16ec+3
    mov_r_rm(rsi, r8)                                            ; 16ef+3
    mov_r_rm(ebx, edx)                                           ; 16f2+2
    mov_r_rm(rbp, rcx)                                           ; 16f4+3
    call fn___scrt_is_ucrt_dll_in_use_1cc0                       ; 16f7+5
    test eax, eax                                                ; 16fc+2
    jne short loc_1716                                           ; 16fe+2
    cmp ebx, 1                                                   ; 1700+3
    jne short loc_1716                                           ; 1703+2
    mov_r_rm(r8, rsi)                                            ; 1705+3
    xor_r_rm(edx, edx)                                           ; 1708+2
    mov_r_rm(rcx, rbp)                                           ; 170a+3
    mov_r_rm(rax, rdi)                                           ; 170d+3
    call qword [rel guard_dispatch_slot]                         ; 1710+6
loc_1716:
    mov rdx, qword [rsp + 0x58]                                  ; 1716+5
    mov ecx, dword [rsp + 0x50]                                  ; 171b+4
    mov rbx, qword [rsp + 0x30]                                  ; 171f+5
    mov rbp, qword [rsp + 0x38]                                  ; 1724+5
    mov rsi, qword [rsp + 0x40]                                  ; 1729+5
    add rsp, 0x20                                                ; 172e+4
    pop rdi                                                      ; 1732+1
    jmp near fn__seh_filter_dll_1cee                             ; 1733+5

; RVA 1738  __scrt_dllmain_uninitialize_c
fn___scrt_dllmain_uninitialize_c_1738:
    sub rsp, 0x28                                                ; 1738+4
    call fn___scrt_is_ucrt_dll_in_use_1cc0                       ; 173c+5
    test eax, eax                                                ; 1741+2
    je short loc_1755                                            ; 1743+2
    lea rcx, [rel image_35f8]                                    ; 1745+7
    add rsp, 0x28                                                ; 174c+4
    jmp near fn__execute_onexit_table_1d06                       ; 1750+5
loc_1755:
    call fn__is_c_termination_complete_1d18                      ; 1755+5
    test eax, eax                                                ; 175a+2
    jne short loc_1763                                           ; 175c+2
    call fn__cexit_1d0c                                          ; 175e+5
loc_1763:
    add rsp, 0x28                                                ; 1763+4
    ret                                                          ; 1767+1

; RVA 1768  __scrt_dllmain_uninitialize_critical
fn___scrt_dllmain_uninitialize_critical_1768:
    sub rsp, 0x28                                                ; 1768+4
    xor_r_rm(ecx, ecx)                                           ; 176c+2
    call fn___vcrt_thread_detach_1d14                            ; 176e+5
    add rsp, 0x28                                                ; 1773+4
    jmp near fn___vcrt_thread_detach_1d14                        ; 1777+5

; RVA 177c  __scrt_initialize_crt
fn___scrt_initialize_crt_177c:
    db 0x40
    push rbx                                         ; 177c+2 original redundant REX prefix
    sub rsp, 0x20                                                ; 177e+4
    movzx eax, byte [rel image_35f0]                             ; 1782+7
    test ecx, ecx                                                ; 1789+2
    mov ebx, 1                                                   ; 178b+5
    cmove eax, ebx                                               ; 1790+3
    mov byte [rel image_35f0], al                                ; 1793+6
    call fn___isa_available_init_1b14                            ; 1799+5
    call fn___vcrt_thread_detach_1d14                            ; 179e+5
    test al, al                                                  ; 17a3+2
    jne short loc_17ab                                           ; 17a5+2
loc_17a7:
    xor_r_rm(al, al)                                             ; 17a7+2
    jmp short loc_17bf                                           ; 17a9+2
loc_17ab:
    call fn___vcrt_thread_detach_1d14                            ; 17ab+5
    test al, al                                                  ; 17b0+2
    jne short loc_17bd                                           ; 17b2+2
    xor_r_rm(ecx, ecx)                                           ; 17b4+2
    call fn___vcrt_thread_detach_1d14                            ; 17b6+5
    jmp short loc_17a7                                           ; 17bb+2
loc_17bd:
    mov_r_rm(al, bl)                                             ; 17bd+2
loc_17bf:
    add rsp, 0x20                                                ; 17bf+4
    pop rbx                                                      ; 17c3+1
    ret                                                          ; 17c4+1
    int3                                                         ; 17c5+1
    int3                                                         ; 17c6+1
    int3                                                         ; 17c7+1

; RVA 17c8  __scrt_initialize_onexit_tables
fn___scrt_initialize_onexit_tables_17c8:
    db 0x40
    push rbx                                         ; 17c8+2 original redundant REX prefix
    sub rsp, 0x20                                                ; 17ca+4
    cmp byte [rel image_35f1], 0                                 ; 17ce+7
    mov_r_rm(ebx, ecx)                                           ; 17d5+2
    jne short loc_1840                                           ; 17d7+2
    cmp ecx, 1                                                   ; 17d9+3
    ja short loc_1848                                            ; 17dc+2
    call fn___scrt_is_ucrt_dll_in_use_1cc0                       ; 17de+5
    test eax, eax                                                ; 17e3+2
    je short loc_180f                                            ; 17e5+2
    test ebx, ebx                                                ; 17e7+2
    jne short loc_180f                                           ; 17e9+2
    lea rcx, [rel image_35f8]                                    ; 17eb+7
    call fn__initialize_onexit_table_1d00                        ; 17f2+5
    test eax, eax                                                ; 17f7+2
    jne short loc_180b                                           ; 17f9+2
    lea rcx, [rel image_3610]                                    ; 17fb+7
    call fn__initialize_onexit_table_1d00                        ; 1802+5
    test eax, eax                                                ; 1807+2
    je short loc_1839                                            ; 1809+2
loc_180b:
    xor_r_rm(al, al)                                             ; 180b+2
    jmp short loc_1842                                           ; 180d+2
loc_180f:
    movdqa xmm0, oword [rel image_2180]                          ; 180f+8
    or rax, 0xffffffffffffffff                                   ; 1817+4
    movdqu oword [rel image_35f8], xmm0                          ; 181b+8
    mov qword [rel image_3608], rax                              ; 1823+7
    movdqu oword [rel image_3610], xmm0                          ; 182a+8
    mov qword [rel image_3620], rax                              ; 1832+7
loc_1839:
    mov byte [rel image_35f1], 1                                 ; 1839+7
loc_1840:
    mov al, 1                                                    ; 1840+2
loc_1842:
    add rsp, 0x20                                                ; 1842+4
    pop rbx                                                      ; 1846+1
    ret                                                          ; 1847+1
loc_1848:
    mov ecx, 5                                                   ; 1848+5
    call fn___scrt_fastfail_194c                                 ; 184d+5
    int3                                                         ; 1852+1
    int3                                                         ; 1853+1

; RVA 1854  __scrt_is_nonwritable_in_current_image
fn___scrt_is_nonwritable_in_current_image_1854:
    sub rsp, 0x18                                                ; 1854+4
    mov_r_rm(r8, rcx)                                            ; 1858+3
    mov eax, 0x5a4d                                              ; 185b+5
    cmp word [rel image_0000], ax                                ; 1860+7
    jne short loc_18e1                                           ; 1867+2
    movsxd rcx, dword [rel image_003c]                           ; 1869+7
    lea rdx, [rel image_0000]                                    ; 1870+7
    add_r_rm(rcx, rdx)                                           ; 1877+3
    cmp dword [rcx], 0x4550                                      ; 187a+6
    jne short loc_18e1                                           ; 1880+2
    mov eax, 0x20b                                               ; 1882+5
    cmp word [rcx + 0x18], ax                                    ; 1887+4
    jne short loc_18e1                                           ; 188b+2
    sub_r_rm(r8, rdx)                                            ; 188d+3
    movzx edx, word [rcx + 0x14]                                 ; 1890+4
    add rdx, 0x18                                                ; 1894+4
    add_r_rm(rdx, rcx)                                           ; 1898+3
    movzx eax, word [rcx + 6]                                    ; 189b+4
    lea rcx, [rax + rax*4]                                       ; 189f+4
    lea r9, [rdx + rcx*8]                                        ; 18a3+4
loc_18a7:
    mov qword [rsp], rdx                                         ; 18a7+4
    cmp_r_rm(rdx, r9)                                            ; 18ab+3
    je short loc_18c8                                            ; 18ae+2
    mov ecx, dword [rdx + 0xc]                                   ; 18b0+3
    cmp_r_rm(r8, rcx)                                            ; 18b3+3
    jb short loc_18c2                                            ; 18b6+2
    mov eax, dword [rdx + 8]                                     ; 18b8+3
    add_r_rm(eax, ecx)                                           ; 18bb+2
    cmp_r_rm(r8, rax)                                            ; 18bd+3
    jb short loc_18ca                                            ; 18c0+2
loc_18c2:
    add rdx, 0x28                                                ; 18c2+4
    jmp short loc_18a7                                           ; 18c6+2
loc_18c8:
    xor_r_rm(edx, edx)                                           ; 18c8+2
loc_18ca:
    test rdx, rdx                                                ; 18ca+3
    jne short loc_18d3                                           ; 18cd+2
    xor_r_rm(al, al)                                             ; 18cf+2
    jmp short loc_18e7                                           ; 18d1+2
loc_18d3:
    cmp dword [rdx + 0x24], 0                                    ; 18d3+4
    jge short loc_18dd                                           ; 18d7+2
    xor_r_rm(al, al)                                             ; 18d9+2
    jmp short loc_18e7                                           ; 18db+2
loc_18dd:
    mov al, 1                                                    ; 18dd+2
    jmp short loc_18e7                                           ; 18df+2
loc_18e1:
    xor_r_rm(al, al)                                             ; 18e1+2
    jmp short loc_18e7                                           ; 18e3+2
    xor_r_rm(al, al)                                             ; 18e5+2
loc_18e7:
    add rsp, 0x18                                                ; 18e7+4
    ret                                                          ; 18eb+1

; RVA 18ec  __scrt_release_startup_lock
fn___scrt_release_startup_lock_18ec:
    db 0x40
    push rbx                                         ; 18ec+2 original redundant REX prefix
    sub rsp, 0x20                                                ; 18ee+4
    mov_r_rm(bl, cl)                                             ; 18f2+2
    call fn___scrt_is_ucrt_dll_in_use_1cc0                       ; 18f4+5
    xor_r_rm(edx, edx)                                           ; 18f9+2
    test eax, eax                                                ; 18fb+2
    je short loc_190a                                            ; 18fd+2
    test bl, bl                                                  ; 18ff+2
    jne short loc_190a                                           ; 1901+2
    xchg qword [rel image_35e8], rdx                             ; 1903+7
loc_190a:
    add rsp, 0x20                                                ; 190a+4
    pop rbx                                                      ; 190e+1
    ret                                                          ; 190f+1

; RVA 1910  __scrt_uninitialize_crt
fn___scrt_uninitialize_crt_1910:
    db 0x40
    push rbx                                         ; 1910+2 original redundant REX prefix
    sub rsp, 0x20                                                ; 1912+4
    cmp byte [rel image_35f0], 0                                 ; 1916+7
    mov_r_rm(bl, cl)                                             ; 191d+2
    je short loc_1925                                            ; 191f+2
    test dl, dl                                                  ; 1921+2
    jne short loc_1931                                           ; 1923+2
loc_1925:
    call fn___vcrt_thread_detach_1d14                            ; 1925+5
    mov_r_rm(cl, bl)                                             ; 192a+2
    call fn___vcrt_thread_detach_1d14                            ; 192c+5
loc_1931:
    mov al, 1                                                    ; 1931+2
    add rsp, 0x20                                                ; 1933+4
    pop rbx                                                      ; 1937+1
    ret                                                          ; 1938+1
    int3                                                         ; 1939+1
    int3                                                         ; 193a+1
    int3                                                         ; 193b+1

; RVA 193c  __scrt_get_dyn_tls_init_callback
fn___scrt_get_dyn_tls_init_callback_193c:
    lea rax, [rel image_3638]                                    ; 193c+7
    ret                                                          ; 1943+1

; RVA 1944  __crt_debugger_hook
fn___crt_debugger_hook_1944:
    and dword [rel image_3628], 0                                ; 1944+7
    ret                                                          ; 194b+1

; RVA 194c  __scrt_fastfail
fn___scrt_fastfail_194c:
    mov qword [rsp + 8], rbx                                     ; 194c+5
    push rbp                                                     ; 1951+1
    lea rbp, [rsp - 0x4c0]                                       ; 1952+8
    sub rsp, 0x5c0                                               ; 195a+7
    mov_r_rm(ebx, ecx)                                           ; 1961+2
    mov ecx, 0x17                                                ; 1963+5
    call qword [rel iat_IsProcessorFeaturePresent]               ; 1968+6
    test eax, eax                                                ; 196e+2
    je short loc_1976                                            ; 1970+2
    mov_r_rm(ecx, ebx)                                           ; 1972+2
    int 0x29                                                     ; 1974+2
loc_1976:
    mov ecx, 3                                                   ; 1976+5
    call fn___crt_debugger_hook_1944                             ; 197b+5
    xor_r_rm(edx, edx)                                           ; 1980+2
    lea rcx, [rbp - 0x10]                                        ; 1982+4
    mov r8d, 0x4d0                                               ; 1986+6
    call fn_memset_1cdc                                          ; 198c+5
    lea rcx, [rbp - 0x10]                                        ; 1991+4
    call qword [rel iat_RtlCaptureContext]                       ; 1995+6
    mov rbx, qword [rbp + 0xe8]                                  ; 199b+7
    lea rdx, [rbp + 0x4d8]                                       ; 19a2+7
    mov_r_rm(rcx, rbx)                                           ; 19a9+3
    xor_r_rm(r8d, r8d)                                           ; 19ac+3
    call qword [rel iat_RtlLookupFunctionEntry]                  ; 19af+6
    test rax, rax                                                ; 19b5+3
    je short loc_19f6                                            ; 19b8+2
    and qword [rsp + 0x38], 0                                    ; 19ba+6
    lea rcx, [rbp + 0x4e0]                                       ; 19c0+7
    mov rdx, qword [rbp + 0x4d8]                                 ; 19c7+7
    mov_r_rm(r9, rax)                                            ; 19ce+3
    mov qword [rsp + 0x30], rcx                                  ; 19d1+5
    mov_r_rm(r8, rbx)                                            ; 19d6+3
    lea rcx, [rbp + 0x4e8]                                       ; 19d9+7
    mov qword [rsp + 0x28], rcx                                  ; 19e0+5
    lea rcx, [rbp - 0x10]                                        ; 19e5+4
    mov qword [rsp + 0x20], rcx                                  ; 19e9+5
    xor_r_rm(ecx, ecx)                                           ; 19ee+2
    call qword [rel iat_RtlVirtualUnwind]                        ; 19f0+6
loc_19f6:
    mov rax, qword [rbp + 0x4c8]                                 ; 19f6+7
    lea rcx, [rsp + 0x50]                                        ; 19fd+5
    mov qword [rbp + 0xe8], rax                                  ; 1a02+7
    xor_r_rm(edx, edx)                                           ; 1a09+2
    lea rax, [rbp + 0x4c8]                                       ; 1a0b+7
    mov r8d, 0x98                                                ; 1a12+6
    add rax, 8                                                   ; 1a18+4
    mov qword [rbp + 0x88], rax                                  ; 1a1c+7
    call fn_memset_1cdc                                          ; 1a23+5
    mov rax, qword [rbp + 0x4c8]                                 ; 1a28+7
    mov qword [rsp + 0x60], rax                                  ; 1a2f+5
    mov dword [rsp + 0x50], 0x40000015                           ; 1a34+8
    mov dword [rsp + 0x54], 1                                    ; 1a3c+8
    call qword [rel iat_IsDebuggerPresent]                       ; 1a44+6
    cmp eax, 1                                                   ; 1a4a+3
    lea rax, [rsp + 0x50]                                        ; 1a4d+5
    mov qword [rsp + 0x40], rax                                  ; 1a52+5
    lea rax, [rbp - 0x10]                                        ; 1a57+4
    sete bl                                                      ; 1a5b+3
    mov qword [rsp + 0x48], rax                                  ; 1a5e+5
    xor_r_rm(ecx, ecx)                                           ; 1a63+2
    call qword [rel iat_SetUnhandledExceptionFilter]             ; 1a65+6
    lea rcx, [rsp + 0x40]                                        ; 1a6b+5
    call qword [rel iat_UnhandledExceptionFilter]                ; 1a70+6
    test eax, eax                                                ; 1a76+2
    jne short loc_1a86                                           ; 1a78+2
    test bl, bl                                                  ; 1a7a+2
    jne short loc_1a86                                           ; 1a7c+2
    lea ecx, [rax + 3]                                           ; 1a7e+3
    call fn___crt_debugger_hook_1944                             ; 1a81+5
loc_1a86:
    mov rbx, qword [rsp + 0x5d0]                                 ; 1a86+8
    add rsp, 0x5c0                                               ; 1a8e+7
    pop rbp                                                      ; 1a95+1
    ret                                                          ; 1a96+1
    int3                                                         ; 1a97+1

; RVA 1a98  _RTC_Initialize
fn__RTC_Initialize_1a98:
    mov qword [rsp + 8], rbx                                     ; 1a98+5
    push rdi                                                     ; 1a9d+1
    sub rsp, 0x20                                                ; 1a9e+4
    lea rbx, [rel image_2690]                                    ; 1aa2+7
    lea rdi, [rel image_2690]                                    ; 1aa9+7
    jmp short loc_1ac4                                           ; 1ab0+2
loc_1ab2:
    mov rax, qword [rbx]                                         ; 1ab2+3
    test rax, rax                                                ; 1ab5+3
    je short loc_1ac0                                            ; 1ab8+2
    call qword [rel guard_dispatch_slot]                         ; 1aba+6
loc_1ac0:
    add rbx, 8                                                   ; 1ac0+4
loc_1ac4:
    cmp_r_rm(rbx, rdi)                                           ; 1ac4+3
    jb short loc_1ab2                                            ; 1ac7+2
    mov rbx, qword [rsp + 0x30]                                  ; 1ac9+5
    add rsp, 0x20                                                ; 1ace+4
    pop rdi                                                      ; 1ad2+1
    ret                                                          ; 1ad3+1

; RVA 1ad4  _RTC_Terminate
fn__RTC_Terminate_1ad4:
    mov qword [rsp + 8], rbx                                     ; 1ad4+5
    push rdi                                                     ; 1ad9+1
    sub rsp, 0x20                                                ; 1ada+4
    lea rbx, [rel image_26a0]                                    ; 1ade+7
    lea rdi, [rel image_26a0]                                    ; 1ae5+7
    jmp short loc_1b00                                           ; 1aec+2
loc_1aee:
    mov rax, qword [rbx]                                         ; 1aee+3
    test rax, rax                                                ; 1af1+3
    je short loc_1afc                                            ; 1af4+2
    call qword [rel guard_dispatch_slot]                         ; 1af6+6
loc_1afc:
    add rbx, 8                                                   ; 1afc+4
loc_1b00:
    cmp_r_rm(rbx, rdi)                                           ; 1b00+3
    jb short loc_1aee                                            ; 1b03+2
    mov rbx, qword [rsp + 0x30]                                  ; 1b05+5
    add rsp, 0x20                                                ; 1b0a+4
    pop rdi                                                      ; 1b0e+1
    ret                                                          ; 1b0f+1

; RVA 1b10  _guard_check_icall_nop
fn__guard_check_icall_nop_1b10:
    ret 0                                                        ; 1b10+3
    int3                                                         ; 1b13+1

; RVA 1b14  __isa_available_init
fn___isa_available_init_1b14:
    mov qword [rsp + 0x10], rbx                                  ; 1b14+5
    mov qword [rsp + 0x18], rsi                                  ; 1b19+5
    push rdi                                                     ; 1b1e+1
    sub rsp, 0x10                                                ; 1b1f+4
    xor_r_rm(eax, eax)                                           ; 1b23+2
    xor_r_rm(ecx, ecx)                                           ; 1b25+2
    cpuid                                                        ; 1b27+2
    mov_r_rm(r8d, ecx)                                           ; 1b29+3
    xor_r_rm(r11d, r11d)                                         ; 1b2c+3
    mov_r_rm(r10d, edx)                                          ; 1b2f+3
    xor r8d, 0x6c65746e                                          ; 1b32+7
    xor r10d, 0x49656e69                                         ; 1b39+7
    mov_r_rm(r9d, ebx)                                           ; 1b40+3
    mov_r_rm(esi, eax)                                           ; 1b43+2
    xor_r_rm(ecx, ecx)                                           ; 1b45+2
    lea eax, [r11 + 1]                                           ; 1b47+4
    or_r_rm(r10d, r8d)                                           ; 1b4b+3
    cpuid                                                        ; 1b4e+2
    xor r9d, 0x756e6547                                          ; 1b50+7
    mov dword [rsp], eax                                         ; 1b57+3
    or_r_rm(r10d, r9d)                                           ; 1b5a+3
    mov dword [rsp + 4], ebx                                     ; 1b5d+4
    mov_r_rm(edi, ecx)                                           ; 1b61+2
    mov dword [rsp + 8], ecx                                     ; 1b63+4
    mov dword [rsp + 0xc], edx                                   ; 1b67+4
    jne short loc_1bc8                                           ; 1b6b+2
    or qword [rel image_3028], 0xffffffffffffffff                ; 1b6d+8
    and eax, 0xfff3ff0                                           ; 1b75+5
    mov qword [rel image_3020], 0x8000                           ; 1b7a+11
    cmp eax, 0x106c0                                             ; 1b85+5
    je short loc_1bb4                                            ; 1b8a+2
    cmp eax, 0x20660                                             ; 1b8c+5
    je short loc_1bb4                                            ; 1b91+2
    cmp eax, 0x20670                                             ; 1b93+5
    je short loc_1bb4                                            ; 1b98+2
    add eax, 0xfffcf9b0                                          ; 1b9a+5
    cmp eax, 0x20                                                ; 1b9f+3
    ja short loc_1bc8                                            ; 1ba2+2
    mov rcx, strict qword 0x100010001                            ; 1ba4+10
    bt rcx, rax                                                  ; 1bae+4
    jae short loc_1bc8                                           ; 1bb2+2
loc_1bb4:
    mov r8d, dword [rel image_362c]                              ; 1bb4+7
    or r8d, 1                                                    ; 1bbb+4
    mov dword [rel image_362c], r8d                              ; 1bbf+7
    jmp short loc_1bcf                                           ; 1bc6+2
loc_1bc8:
    mov r8d, dword [rel image_362c]                              ; 1bc8+7
loc_1bcf:
    mov eax, 7                                                   ; 1bcf+5
    lea r9d, [rax - 5]                                           ; 1bd4+4
    cmp_r_rm(esi, eax)                                           ; 1bd8+2
    jl short loc_1c02                                            ; 1bda+2
    xor_r_rm(ecx, ecx)                                           ; 1bdc+2
    cpuid                                                        ; 1bde+2
    mov dword [rsp], eax                                         ; 1be0+3
    mov_r_rm(r11d, ebx)                                          ; 1be3+3
    mov dword [rsp + 4], ebx                                     ; 1be6+4
    mov dword [rsp + 8], ecx                                     ; 1bea+4
    mov dword [rsp + 0xc], edx                                   ; 1bee+4
    bt ebx, 9                                                    ; 1bf2+4
    jae short loc_1c02                                           ; 1bf6+2
    or_r_rm(r8d, r9d)                                            ; 1bf8+3
    mov dword [rel image_362c], r8d                              ; 1bfb+7
loc_1c02:
    mov dword [rel image_3018], 1                                ; 1c02+10
    mov dword [rel image_301c], r9d                              ; 1c0c+7
    bt edi, 0x14                                                 ; 1c13+4
    jae near loc_1cae                                            ; 1c17+6
    mov dword [rel image_3018], r9d                              ; 1c1d+7
    mov ebx, 6                                                   ; 1c24+5
    mov dword [rel image_301c], ebx                              ; 1c29+6
    bt edi, 0x1b                                                 ; 1c2f+4
    jae short loc_1cae                                           ; 1c33+2
    bt edi, 0x1c                                                 ; 1c35+4
    jae short loc_1cae                                           ; 1c39+2
    xor_r_rm(ecx, ecx)                                           ; 1c3b+2
    xgetbv                                                       ; 1c3d+3
    shl rdx, 0x20                                                ; 1c40+4
    or_r_rm(rdx, rax)                                            ; 1c44+3
    mov qword [rsp + 0x20], rdx                                  ; 1c47+5
    mov rax, qword [rsp + 0x20]                                  ; 1c4c+5
    and_r_rm(al, bl)                                             ; 1c51+2
    cmp_r_rm(al, bl)                                             ; 1c53+2
    jne short loc_1cae                                           ; 1c55+2
    mov eax, dword [rel image_301c]                              ; 1c57+6
    or eax, 8                                                    ; 1c5d+3
    mov dword [rel image_3018], 3                                ; 1c60+10
    mov dword [rel image_301c], eax                              ; 1c6a+6
    test r11b, 0x20                                              ; 1c70+4
    je short loc_1cae                                            ; 1c74+2
    or eax, 0x20                                                 ; 1c76+3
    mov dword [rel image_3018], 5                                ; 1c79+10
    mov dword [rel image_301c], eax                              ; 1c83+6
    mov eax, 0xd0030000                                          ; 1c89+5
    and_r_rm(r11d, eax)                                          ; 1c8e+3
    cmp_r_rm(r11d, eax)                                          ; 1c91+3
    jne short loc_1cae                                           ; 1c94+2
    mov rax, qword [rsp + 0x20]                                  ; 1c96+5
    and al, 0xe0                                                 ; 1c9b+2
    cmp al, 0xe0                                                 ; 1c9d+2
    jne short loc_1cae                                           ; 1c9f+2
    or dword [rel image_301c], 0x40                              ; 1ca1+7
    mov dword [rel image_3018], ebx                              ; 1ca8+6
loc_1cae:
    mov rbx, qword [rsp + 0x28]                                  ; 1cae+5
    xor_r_rm(eax, eax)                                           ; 1cb3+2
    mov rsi, qword [rsp + 0x30]                                  ; 1cb5+5
    add rsp, 0x10                                                ; 1cba+4
    pop rdi                                                      ; 1cbe+1
    ret                                                          ; 1cbf+1

; RVA 1cc0  __scrt_is_ucrt_dll_in_use
fn___scrt_is_ucrt_dll_in_use_1cc0:
    xor_r_rm(eax, eax)                                           ; 1cc0+2
    cmp dword [rel image_3030], eax                              ; 1cc2+6
    setne al                                                     ; 1cc8+3
    ret                                                          ; 1ccb+1
    int3                                                         ; 1ccc+1
    int3                                                         ; 1ccd+1
    int3                                                         ; 1cce+1
    int3                                                         ; 1ccf+1

; RVA 1cd0  __C_specific_handler
fn___C_specific_handler_1cd0:
    jmp qword [rel iat___C_specific_handler]                     ; 1cd0+6

; RVA 1cd6  __std_type_info_destroy_list
fn___std_type_info_destroy_list_1cd6:
    jmp qword [rel iat___std_type_info_destroy_list]             ; 1cd6+6

; RVA 1cdc  memset
fn_memset_1cdc:
    jmp qword [rel iat_memset]                                   ; 1cdc+6

; RVA 1ce2  _initterm
fn__initterm_1ce2:
    jmp qword [rel iat__initterm]                                ; 1ce2+6

; RVA 1ce8  _initterm_e
fn__initterm_e_1ce8:
    jmp qword [rel iat__initterm_e]                              ; 1ce8+6

; RVA 1cee  _seh_filter_dll
fn__seh_filter_dll_1cee:
    jmp qword [rel iat__seh_filter_dll]                          ; 1cee+6

; RVA 1cf4  _configure_narrow_argv
fn__configure_narrow_argv_1cf4:
    jmp qword [rel iat__configure_narrow_argv]                   ; 1cf4+6

; RVA 1cfa  _initialize_narrow_environment
fn__initialize_narrow_environment_1cfa:
    jmp qword [rel iat__initialize_narrow_environment]           ; 1cfa+6

; RVA 1d00  _initialize_onexit_table
fn__initialize_onexit_table_1d00:
    jmp qword [rel iat__initialize_onexit_table]                 ; 1d00+6

; RVA 1d06  _execute_onexit_table
fn__execute_onexit_table_1d06:
    jmp qword [rel iat__execute_onexit_table]                    ; 1d06+6

; RVA 1d0c  _cexit
fn__cexit_1d0c:
    jmp qword [rel iat__cexit]                                   ; 1d0c+6
    int3                                                         ; 1d12+1
    int3                                                         ; 1d13+1

; RVA 1d14  __vcrt_thread_detach
fn___vcrt_thread_detach_1d14:
    mov al, 1                                                    ; 1d14+2
    ret                                                          ; 1d16+1
    int3                                                         ; 1d17+1

; RVA 1d18  _is_c_termination_complete
fn__is_c_termination_complete_1d18:
    xor_r_rm(eax, eax)                                           ; 1d18+2
    ret                                                          ; 1d1a+1

; RVA 1d1b  memcpy
fn_memcpy_1d1b:
    jmp qword [rel iat_memcpy]                                   ; 1d1b+6
    int3                                                         ; 1d21+1
    int3                                                         ; 1d22+1
    int3                                                         ; 1d23+1
    int3                                                         ; 1d24+1
    int3                                                         ; 1d25+1
    int3                                                         ; 1d26+1
    int3                                                         ; 1d27+1
    int3                                                         ; 1d28+1
    int3                                                         ; 1d29+1
    int3                                                         ; 1d2a+1
    int3                                                         ; 1d2b+1
    int3                                                         ; 1d2c+1
    int3                                                         ; 1d2d+1
    int3                                                         ; 1d2e+1
    int3                                                         ; 1d2f+1
    int3                                                         ; 1d30+1
    int3                                                         ; 1d31+1
    int3                                                         ; 1d32+1
    int3                                                         ; 1d33+1
    int3                                                         ; 1d34+1
    int3                                                         ; 1d35+1
    db 0x66, 0x66, 0x0f, 0x1f, 0x84, 0x00, 0x00, 0x00, 0x00, 0x00 ; 1d36+10 original multi-byte alignment NOP

; RVA 1d40  _guard_dispatch_icall_nop
fn__guard_dispatch_icall_nop_1d40:
    jmp rax                                                      ; 1d40+2
    int3                                                         ; 1d42+1
    int3                                                         ; 1d43+1
    int3                                                         ; 1d44+1
    int3                                                         ; 1d45+1
    int3                                                         ; 1d46+1
    int3                                                         ; 1d47+1
    int3                                                         ; 1d48+1
    int3                                                         ; 1d49+1
    int3                                                         ; 1d4a+1
    int3                                                         ; 1d4b+1
    int3                                                         ; 1d4c+1
    int3                                                         ; 1d4d+1
    int3                                                         ; 1d4e+1
    int3                                                         ; 1d4f+1
    int3                                                         ; 1d50+1
    int3                                                         ; 1d51+1
    int3                                                         ; 1d52+1
    int3                                                         ; 1d53+1
    int3                                                         ; 1d54+1
    int3                                                         ; 1d55+1
    db 0x66, 0x66, 0x0f, 0x1f, 0x84, 0x00, 0x00, 0x00, 0x00, 0x00 ; 1d56+10 original multi-byte alignment NOP

; RVA 1d60  _guard_xfg_dispatch_icall_nop
fn__guard_xfg_dispatch_icall_nop_1d60:
    jmp qword [rel guard_dispatch_slot]                          ; 1d60+6

; RVA 1d66  ?fin$0@?0??dllmain_crt_process_attach@@YAHQEAUHINSTANCE__@@QEAX@Z@4HA
fn__fin_0__0__dllmain_crt_process_attach__YAHQEAUHINSTANCE____QEAX_Z_4HA_1d66:
    db 0x40
    push rbp                                         ; 1d66+2 original redundant REX prefix
    sub rsp, 0x20                                                ; 1d68+4
    mov_r_rm(rbp, rdx)                                           ; 1d6c+3
    mov cl, byte [rbp + 0x40]                                    ; 1d6f+3
    add rsp, 0x20                                                ; 1d72+4
    pop rbp                                                      ; 1d76+1
    jmp near fn___scrt_release_startup_lock_18ec                 ; 1d77+5
    int3                                                         ; 1d7c+1

; RVA 1d7d  ?fin$0@?0??dllmain_crt_process_detach@@YAH_N@Z@4HA
fn__fin_0__0__dllmain_crt_process_detach__YAH_N_Z_4HA_1d7d:
    db 0x40
    push rbp                                         ; 1d7d+2 original redundant REX prefix
    sub rsp, 0x20                                                ; 1d7f+4
    mov_r_rm(rbp, rdx)                                           ; 1d83+3
    mov cl, byte [rbp + 0x20]                                    ; 1d86+3
    call fn___scrt_release_startup_lock_18ec                     ; 1d89+5
    nop                                                          ; 1d8e+1
    add rsp, 0x20                                                ; 1d8f+4
    pop rbp                                                      ; 1d93+1
    ret                                                          ; 1d94+1
    int3                                                         ; 1d95+1

; RVA 1d96  ?fin$1@?0??dllmain_crt_process_detach@@YAH_N@Z@4HA
fn__fin_1__0__dllmain_crt_process_detach__YAH_N_Z_4HA_1d96:
    db 0x40
    push rbp                                         ; 1d96+2 original redundant REX prefix
    sub rsp, 0x20                                                ; 1d98+4
    mov_r_rm(rbp, rdx)                                           ; 1d9c+3
    add rsp, 0x20                                                ; 1d9f+4
    pop rbp                                                      ; 1da3+1
    jmp near fn___scrt_dllmain_uninitialize_critical_1768        ; 1da4+5
    int3                                                         ; 1da9+1

; RVA 1daa  ?filt$0@?0??dllmain_dispatch@@YAHQEAUHINSTANCE__@@KQEAX@Z@4HA
fn__filt_0__0__dllmain_dispatch__YAHQEAUHINSTANCE____KQEAX_Z_4HA_1daa:
    db 0x40
    push rbp                                         ; 1daa+2 original redundant REX prefix
    sub rsp, 0x30                                                ; 1dac+4
    mov_r_rm(rbp, rdx)                                           ; 1db0+3
    mov rax, qword [rcx]                                         ; 1db3+3
    mov edx, dword [rax]                                         ; 1db6+2
    mov qword [rsp + 0x28], rcx                                  ; 1db8+5
    mov dword [rsp + 0x20], edx                                  ; 1dbd+4
    lea r9, [rel fn__dllmain_crt_dispatch__YAHQEAUHINSTANCE____KQEAX_Z_1040] ; 1dc1+7
    mov r8, qword [rbp + 0x70]                                   ; 1dc8+4
    mov edx, dword [rbp + 0x68]                                  ; 1dcc+3
    mov rcx, qword [rbp + 0x60]                                  ; 1dcf+4
    call fn___scrt_dllmain_exception_filter_16d8                 ; 1dd3+5
    nop                                                          ; 1dd8+1
    add rsp, 0x30                                                ; 1dd9+4
    pop rbp                                                      ; 1ddd+1
    ret                                                          ; 1dde+1
    int3                                                         ; 1ddf+1

; RVA 1de0  __scrt_is_nonwritable_in_current_image$filt$0
fn___scrt_is_nonwritable_in_current_image_filt_0_1de0:
    db 0x40
    push rbp                                         ; 1de0+2 original redundant REX prefix
    mov_r_rm(rbp, rdx)                                           ; 1de2+3
    mov rax, qword [rcx]                                         ; 1de5+3
    xor_r_rm(ecx, ecx)                                           ; 1de8+2
    cmp dword [rax], 0xc0000005                                  ; 1dea+6
    sete cl                                                      ; 1df0+3
    mov_r_rm(eax, ecx)                                           ; 1df3+2
    pop rbp                                                      ; 1df5+1
    ret                                                          ; 1df6+1
    int3                                                         ; 1df7+1
    times 8 db 0                                                 ; 1df8+8 file alignment
