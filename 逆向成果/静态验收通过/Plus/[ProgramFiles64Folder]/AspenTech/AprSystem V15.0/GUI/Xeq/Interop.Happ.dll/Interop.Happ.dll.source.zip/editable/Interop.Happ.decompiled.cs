using System;
using System.Collections;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Threading;

[assembly: ImportedFromTypeLib("Happ")]
[assembly: TypeLibVersion(22, 0)]
[assembly: Guid("8E567520-F9BA-11CF-90B2-0000C0A810C4")]
[assembly: AssemblyVersion("22.0.0.0")]
namespace AspenTech.AspenPlus.Happ;

[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[DefaultMember("Name")]
[Guid("8E567521-F9BA-11CF-90B2-0000C0A810C4")]
public interface IHapp
{
	[DispId(1610743808)]
	IHapp Application
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	IHapp Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	string FullName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(0)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	bool Visible
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[param: In]
		set;
	}

	[DispId(1610743814)]
	IHapp New
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743815)]
	void Restore([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743816)]
	void InitNew([Optional][In][MarshalAs(UnmanagedType.Struct)] object filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	void InitFromFile([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object @readonly);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	void InitFromArchive([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[DispId(1610743819)]
	IHNode Tree
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	void Save();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743821)]
	void SaveAs([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743822)]
	void WriteArchive([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743823)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	void Run();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743824)]
	void Close([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[DispId(1610743825)]
	IHNode Choose
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743826)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IHSelection NewSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[DispId(1610743827)]
	IHSelection Selection
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743827)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	void DeleteSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	void SaveSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	void Reinit();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743831)]
	void InitFromTemplate([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IHNode CreateRouteTree([In][MarshalAs(UnmanagedType.BStr)] ref string propname, [In][MarshalAs(UnmanagedType.BStr)] ref string routeid, [In][MarshalAs(UnmanagedType.BStr)] ref string opsetid, [In] short flag);

	[DispId(1610743833)]
	IHapp NewAsync
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743833)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743834)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	void SetAsync();

	[DispId(1610743835)]
	IHAPEngine Engine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743836)]
	void SaveLink([In][MarshalAs(UnmanagedType.Interface)] IStream pStrm, [In] int format);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743837)]
	void LoadLink([In][MarshalAs(UnmanagedType.Interface)] IStream pStrm, [In] int format);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743838)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	void RefreshExportedLinks();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743839)]
	void Activate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	void SetCompat([In] int flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void Reconcile([In] int code);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	void AdviseParent(int dAdviseType, int lParam);

	[DispId(1610743843)]
	IHapp New2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[DispId(1610743843)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743844)]
	void Generate([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int mode = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743845)]
	void Readback([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int mode = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743846)]
	void SetParent([In][MarshalAs(UnmanagedType.Interface)] IParentAdviseSink pParentAdviseSink, [In] int dwCookie);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	void WriteArchive2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [In] int bSaveChildren);

	[DispId(1610743848)]
	IHapp New3
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743848)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743849)]
	object Restore2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743849)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743850)]
	void InitNew2([Optional][In][MarshalAs(UnmanagedType.Struct)] object notused, [Optional][In][MarshalAs(UnmanagedType.Struct)] object notused2, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743851)]
	void InitFromFile2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object @readonly, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	void InitFromArchive2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743853)]
	void Run2([Optional][In][MarshalAs(UnmanagedType.Struct)] object async);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743854)]
	void InitFromTemplate2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[DispId(1610743855)]
	IHAPLibRef LibRef
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743856)]
	int SuppressDialogs
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743856)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743856)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743858)]
	void Export([In] HAPEXPType reptype, [In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743859)]
	void UIDisable([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[DispId(1610743860)]
	object EngineSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743860)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743861)]
	object EngineServer
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743862)]
	void InitFromXML([In][MarshalAs(UnmanagedType.BStr)] string argument);

	[DispId(1610743863)]
	int ProcessId
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743863)]
		get;
	}

	[DispId(1610743864)]
	object RootModel
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743865)]
	void InitFromArchive3([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [In][MarshalAs(UnmanagedType.Struct)] object open_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743866)]
	void Import([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[DispId(1610743867)]
	int StrongReferences
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743867)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743868)]
	void EditCompoundDocument([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[DispId(1610743869)]
	bool RefreshOff
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743869)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743869)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743871)]
	void RunScript([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743872)]
	void AutoSave();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743873)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	void Save2();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743874)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	void SaveAs2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743875)]
	void Quit([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743876)]
	void CloseDocument([Optional][In][MarshalAs(UnmanagedType.Struct)] object Save);

	[DispId(1610743877)]
	string FailedToOpenKey
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743877)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743878)]
	string FailedToOpenDescription
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743878)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDispatchable)]
[Guid("503FD632-F63E-11D1-8D3E-0000C033EAF2")]
[InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
public interface IAPHappEvents
{
	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(100)]
	void OnDialogSuppressed([In][MarshalAs(UnmanagedType.BStr)] string msg, [In][MarshalAs(UnmanagedType.BStr)] string result);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(101)]
	void OnControlPanelMessage([In] int Clear, [In][MarshalAs(UnmanagedType.BStr)] string msg);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(102)]
	void OnGUIClosing();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(103)]
	void OnInClosing([In] int Clear, [In][MarshalAs(UnmanagedType.BStr)] string msg);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(104)]
	void OnDataChanged([In][MarshalAs(UnmanagedType.IDispatch)] object pObj);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(105)]
	void OnUpdateMessage([In] int msg_code, [In][MarshalAs(UnmanagedType.BStr)] string msg_hint, [In][MarshalAs(UnmanagedType.IDispatch)] object msg_object, [In] int source_handle);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(106)]
	void OnEngineCommandCompleted();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(107)]
	void OnBeforeCalculate([In] bool IsStep, [In] ref bool Cancel);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(108)]
	void OnBeforeSave([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] ref bool Cancel);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(109)]
	void OnCalculationCompleted();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(110)]
	void OnCalculationStopped();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(111)]
	void OnGUIClosed();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(112)]
	void OnDocumentClosing();
}
[ComEventInterface(typeof(IAPHappEvents), typeof(IAPHappEvents_EventProvider))]
[ComVisible(false)]
[TypeLibType(TypeLibTypeFlags.FHidden)]
public interface IAPHappEvents_Event
{
	event IAPHappEvents_OnDialogSuppressedEventHandler OnDialogSuppressed;

	event IAPHappEvents_OnControlPanelMessageEventHandler OnControlPanelMessage;

	event IAPHappEvents_OnGUIClosingEventHandler OnGUIClosing;

	event IAPHappEvents_OnInClosingEventHandler OnInClosing;

	event IAPHappEvents_OnDataChangedEventHandler OnDataChanged;

	event IAPHappEvents_OnUpdateMessageEventHandler OnUpdateMessage;

	event IAPHappEvents_OnEngineCommandCompletedEventHandler OnEngineCommandCompleted;

	event IAPHappEvents_OnBeforeCalculateEventHandler OnBeforeCalculate;

	event IAPHappEvents_OnBeforeSaveEventHandler OnBeforeSave;

	event IAPHappEvents_OnCalculationCompletedEventHandler OnCalculationCompleted;

	event IAPHappEvents_OnCalculationStoppedEventHandler OnCalculationStopped;

	event IAPHappEvents_OnGUIClosedEventHandler OnGUIClosed;

	event IAPHappEvents_OnDocumentClosingEventHandler OnDocumentClosing;
}
[ComImport]
[Guid("8E567521-F9BA-11CF-90B2-0000C0A810C4")]
[CoClass(typeof(HappLSClass))]
public interface HappLS : IHapp, IAPHappEvents_Event
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FOleAutomation)]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("503FD631-F63E-11D1-8D3E-0000C033EAF2")]
public interface IParentAdviseSink
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OnDataChange([In] int dwCookie, [In] int nSeverity);
}
[ComImport]
[Guid("ADBB8C5B-2BC3-4320-80E9-1173394ED542")]
[TypeLibType(TypeLibTypeFlags.FHidden | TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IHAPHandle
{
	[DispId(1610743808)]
	int MainHWnd
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		get;
	}

	[DispId(1610743809)]
	int ProcessHandle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		get;
	}
}
[ComImport]
[DefaultMember("Name")]
[Guid("8EDFE38B-7513-45D6-9A63-B161FCC3832E")]
[ClassInterface(ClassInterfaceType.None)]
[ComSourceInterfaces("AspenTech.AspenPlus.Happ.IAPHappEvents\0\0")]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
public class HappLSClass
{
	[DispId(1610743808)]
	public virtual extern IHapp Application
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	public virtual extern IHapp Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern string FullName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(0)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool Visible
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[param: In]
		set;
	}

	[DispId(1610743814)]
	public virtual extern IHapp New
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743819)]
	public virtual extern IHNode Tree
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743825)]
	public virtual extern IHNode Choose
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743827)]
	public virtual extern IHSelection Selection
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743827)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743833)]
	public virtual extern IHapp NewAsync
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743833)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743835)]
	public virtual extern IHAPEngine Engine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743843)]
	public virtual extern IHapp New2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743848)]
	public virtual extern IHapp New3
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743848)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743849)]
	public virtual extern object Restore2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743849)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610743855)]
	public virtual extern IHAPLibRef LibRef
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743856)]
	public virtual extern int SuppressDialogs
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743856)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743856)]
		[param: In]
		set;
	}

	[DispId(1610743860)]
	public virtual extern object EngineSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743860)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743861)]
	public virtual extern object EngineServer
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743863)]
	public virtual extern int ProcessId
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743863)]
		get;
	}

	[DispId(1610743864)]
	public virtual extern object RootModel
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743864)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743867)]
	public virtual extern int StrongReferences
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743867)]
		get;
	}

	[DispId(1610743869)]
	public virtual extern bool RefreshOff
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743869)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743869)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[param: In]
		set;
	}

	[DispId(1610743877)]
	public virtual extern string FailedToOpenKey
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743877)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743878)]
	public virtual extern string FailedToOpenDescription
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743878)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	public virtual extern int MainHWnd
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern int ProcessHandle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern event IAPHappEvents_OnDialogSuppressedEventHandler OnDialogSuppressed;

	public virtual extern event IAPHappEvents_OnControlPanelMessageEventHandler OnControlPanelMessage;

	public virtual extern event IAPHappEvents_OnGUIClosingEventHandler OnGUIClosing;

	public virtual extern event IAPHappEvents_OnInClosingEventHandler OnInClosing;

	public virtual extern event IAPHappEvents_OnDataChangedEventHandler OnDataChanged;

	public virtual extern event IAPHappEvents_OnUpdateMessageEventHandler OnUpdateMessage;

	public virtual extern event IAPHappEvents_OnEngineCommandCompletedEventHandler OnEngineCommandCompleted;

	public virtual extern event IAPHappEvents_OnBeforeCalculateEventHandler OnBeforeCalculate;

	public virtual extern event IAPHappEvents_OnBeforeSaveEventHandler OnBeforeSave;

	public virtual extern event IAPHappEvents_OnCalculationCompletedEventHandler OnCalculationCompleted;

	public virtual extern event IAPHappEvents_OnCalculationStoppedEventHandler OnCalculationStopped;

	public virtual extern event IAPHappEvents_OnGUIClosedEventHandler OnGUIClosed;

	public virtual extern event IAPHappEvents_OnDocumentClosingEventHandler OnDocumentClosing;

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743815)]
	public virtual extern void Restore([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743816)]
	public virtual extern void InitNew([Optional][In][MarshalAs(UnmanagedType.Struct)] object filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743817)]
	public virtual extern void InitFromFile([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object @readonly);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void InitFromArchive([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	public virtual extern void Save();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743821)]
	public virtual extern void SaveAs([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743822)]
	public virtual extern void WriteArchive([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743823)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void Run();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743824)]
	public virtual extern void Close([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743826)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IHSelection NewSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	public virtual extern void DeleteSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	public virtual extern void SaveSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	public virtual extern void Reinit();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743831)]
	public virtual extern void InitFromTemplate([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IHNode CreateRouteTree([In][MarshalAs(UnmanagedType.BStr)] ref string propname, [In][MarshalAs(UnmanagedType.BStr)] ref string routeid, [In][MarshalAs(UnmanagedType.BStr)] ref string opsetid, [In] short flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743834)]
	public virtual extern void SetAsync();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743836)]
	public virtual extern void SaveLink([In][MarshalAs(UnmanagedType.Interface)] IStream pStrm, [In] int format);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743837)]
	public virtual extern void LoadLink([In][MarshalAs(UnmanagedType.Interface)] IStream pStrm, [In] int format);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743838)]
	public virtual extern void RefreshExportedLinks();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743839)]
	public virtual extern void Activate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	public virtual extern void SetCompat([In] int flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	public virtual extern void Reconcile([In] int code);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	public virtual extern void AdviseParent(int dAdviseType, int lParam);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743844)]
	public virtual extern void Generate([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int mode = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743845)]
	public virtual extern void Readback([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int mode = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743846)]
	public virtual extern void SetParent([In][MarshalAs(UnmanagedType.Interface)] IParentAdviseSink pParentAdviseSink, [In] int dwCookie);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	public virtual extern void WriteArchive2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [In] int bSaveChildren);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743850)]
	public virtual extern void InitNew2([Optional][In][MarshalAs(UnmanagedType.Struct)] object notused, [Optional][In][MarshalAs(UnmanagedType.Struct)] object notused2, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743851)]
	public virtual extern void InitFromFile2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object @readonly, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	public virtual extern void InitFromArchive2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743853)]
	public virtual extern void Run2([Optional][In][MarshalAs(UnmanagedType.Struct)] object async);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743854)]
	public virtual extern void InitFromTemplate2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743858)]
	public virtual extern void Export([In] HAPEXPType reptype, [In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743859)]
	public virtual extern void UIDisable([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743862)]
	public virtual extern void InitFromXML([In][MarshalAs(UnmanagedType.BStr)] string argument);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743865)]
	public virtual extern void InitFromArchive3([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [In][MarshalAs(UnmanagedType.Struct)] object open_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743866)]
	public virtual extern void Import([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743868)]
	public virtual extern void EditCompoundDocument([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743871)]
	public virtual extern void RunScript([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743872)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void AutoSave();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743873)]
	public virtual extern void Save2();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743874)]
	public virtual extern void SaveAs2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743875)]
	public virtual extern void Quit([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743876)]
	public virtual extern void CloseDocument([Optional][In][MarshalAs(UnmanagedType.Struct)] object Save);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void OnDataChange([In] int dwCookie, [In] int nSeverity);
}
[ComImport]
[CoClass(typeof(HappIPClass))]
[Guid("8E567521-F9BA-11CF-90B2-0000C0A810C4")]
public interface HappIP : IHapp, IAPHappEvents_Event
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
[DefaultMember("Name")]
[ClassInterface(ClassInterfaceType.None)]
[ComSourceInterfaces("AspenTech.AspenPlus.Happ.IAPHappEvents\0\0")]
[Guid("23E2E724-16C8-442C-8398-2AC1AF9405BA")]
public class HappIPClass
{
	[DispId(1610743808)]
	public virtual extern IHapp Application
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	public virtual extern IHapp Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern string FullName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(0)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool Visible
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[param: In]
		set;
	}

	[DispId(1610743814)]
	public virtual extern IHapp New
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743819)]
	public virtual extern IHNode Tree
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743825)]
	public virtual extern IHNode Choose
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743827)]
	public virtual extern IHSelection Selection
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743827)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743833)]
	public virtual extern IHapp NewAsync
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743833)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743835)]
	public virtual extern IHAPEngine Engine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743843)]
	public virtual extern IHapp New2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743848)]
	public virtual extern IHapp New3
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743848)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743849)]
	public virtual extern object Restore2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743849)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610743855)]
	public virtual extern IHAPLibRef LibRef
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743856)]
	public virtual extern int SuppressDialogs
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743856)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743856)]
		[param: In]
		set;
	}

	[DispId(1610743860)]
	public virtual extern object EngineSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743860)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743861)]
	public virtual extern object EngineServer
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743863)]
	public virtual extern int ProcessId
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743863)]
		get;
	}

	[DispId(1610743864)]
	public virtual extern object RootModel
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743867)]
	public virtual extern int StrongReferences
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743867)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		get;
	}

	[DispId(1610743869)]
	public virtual extern bool RefreshOff
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743869)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743869)]
		[param: In]
		set;
	}

	[DispId(1610743877)]
	public virtual extern string FailedToOpenKey
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743877)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743878)]
	public virtual extern string FailedToOpenDescription
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743878)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	public virtual extern int MainHWnd
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern int ProcessHandle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern event IAPHappEvents_OnDialogSuppressedEventHandler OnDialogSuppressed;

	public virtual extern event IAPHappEvents_OnControlPanelMessageEventHandler OnControlPanelMessage;

	public virtual extern event IAPHappEvents_OnGUIClosingEventHandler OnGUIClosing;

	public virtual extern event IAPHappEvents_OnInClosingEventHandler OnInClosing;

	public virtual extern event IAPHappEvents_OnDataChangedEventHandler OnDataChanged;

	public virtual extern event IAPHappEvents_OnUpdateMessageEventHandler OnUpdateMessage;

	public virtual extern event IAPHappEvents_OnEngineCommandCompletedEventHandler OnEngineCommandCompleted;

	public virtual extern event IAPHappEvents_OnBeforeCalculateEventHandler OnBeforeCalculate;

	public virtual extern event IAPHappEvents_OnBeforeSaveEventHandler OnBeforeSave;

	public virtual extern event IAPHappEvents_OnCalculationCompletedEventHandler OnCalculationCompleted;

	public virtual extern event IAPHappEvents_OnCalculationStoppedEventHandler OnCalculationStopped;

	public virtual extern event IAPHappEvents_OnGUIClosedEventHandler OnGUIClosed;

	public virtual extern event IAPHappEvents_OnDocumentClosingEventHandler OnDocumentClosing;

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void Restore([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void InitNew([Optional][In][MarshalAs(UnmanagedType.Struct)] object filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void InitFromFile([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object @readonly);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void InitFromArchive([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	public virtual extern void Save();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743821)]
	public virtual extern void SaveAs([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743822)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void WriteArchive([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743823)]
	public virtual extern void Run();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743824)]
	public virtual extern void Close([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743826)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IHSelection NewSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	public virtual extern void DeleteSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	public virtual extern void SaveSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	public virtual extern void Reinit();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743831)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void InitFromTemplate([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IHNode CreateRouteTree([In][MarshalAs(UnmanagedType.BStr)] ref string propname, [In][MarshalAs(UnmanagedType.BStr)] ref string routeid, [In][MarshalAs(UnmanagedType.BStr)] ref string opsetid, [In] short flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743834)]
	public virtual extern void SetAsync();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743836)]
	public virtual extern void SaveLink([In][MarshalAs(UnmanagedType.Interface)] IStream pStrm, [In] int format);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743837)]
	public virtual extern void LoadLink([In][MarshalAs(UnmanagedType.Interface)] IStream pStrm, [In] int format);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743838)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	public virtual extern void RefreshExportedLinks();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743839)]
	public virtual extern void Activate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	public virtual extern void SetCompat([In] int flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	public virtual extern void Reconcile([In] int code);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	public virtual extern void AdviseParent(int dAdviseType, int lParam);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743844)]
	public virtual extern void Generate([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int mode = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743845)]
	public virtual extern void Readback([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int mode = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743846)]
	public virtual extern void SetParent([In][MarshalAs(UnmanagedType.Interface)] IParentAdviseSink pParentAdviseSink, [In] int dwCookie);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	public virtual extern void WriteArchive2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [In] int bSaveChildren);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743850)]
	public virtual extern void InitNew2([Optional][In][MarshalAs(UnmanagedType.Struct)] object notused, [Optional][In][MarshalAs(UnmanagedType.Struct)] object notused2, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743851)]
	public virtual extern void InitFromFile2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object @readonly, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	public virtual extern void InitFromArchive2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743853)]
	public virtual extern void Run2([Optional][In][MarshalAs(UnmanagedType.Struct)] object async);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743854)]
	public virtual extern void InitFromTemplate2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743858)]
	public virtual extern void Export([In] HAPEXPType reptype, [In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743859)]
	public virtual extern void UIDisable([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743862)]
	public virtual extern void InitFromXML([In][MarshalAs(UnmanagedType.BStr)] string argument);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743865)]
	public virtual extern void InitFromArchive3([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [In][MarshalAs(UnmanagedType.Struct)] object open_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743866)]
	public virtual extern void Import([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743868)]
	public virtual extern void EditCompoundDocument([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743871)]
	public virtual extern void RunScript([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743872)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void AutoSave();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743873)]
	public virtual extern void Save2();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743874)]
	public virtual extern void SaveAs2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743875)]
	public virtual extern void Quit([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743876)]
	public virtual extern void CloseDocument([Optional][In][MarshalAs(UnmanagedType.Struct)] object Save);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void OnDataChange([In] int dwCookie, [In] int nSeverity);
}
[ComImport]
[Guid("72F9FD70-9ED4-11D0-9475-0000C07972E4")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IHComposite
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void AddChild([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Interface)] IHNode child);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void RemoveChild([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IHNode GetChild([In] int index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetChildName([In] int index);

	[DispId(1610743812)]
	int ChildCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void DumpToDataBase([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.BStr)] string tablename, [In] int create);
}
[ComImport]
[Guid("72F9FD70-9ED4-11D0-9475-0000C07972E4")]
[CoClass(typeof(CHReadOnlyCompositeNodeClass))]
public interface CHReadOnlyCompositeNode : IHComposite
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
[Guid("DC1CB955-9A15-4582-BFD8-C6EB0FC59C87")]
[ClassInterface(ClassInterfaceType.None)]
public class CHReadOnlyCompositeNodeClass
{
	[DispId(1610743812)]
	public virtual extern int ChildCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	public virtual extern void AddChild([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Interface)] IHNode child);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void RemoveChild([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IHNode GetChild([In] int index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	[return: MarshalAs(UnmanagedType.BStr)]
	public virtual extern string GetChildName([In] int index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	public virtual extern void DumpToDataBase([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.BStr)] string tablename, [In] int create);
}
[ComImport]
[CoClass(typeof(CHReadWriteCompositeNodeClass))]
[Guid("72F9FD70-9ED4-11D0-9475-0000C07972E4")]
public interface CHReadWriteCompositeNode : IHComposite
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[Guid("2BBA61D9-88D4-4A7E-8C50-577889CC32A5")]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
public class CHReadWriteCompositeNodeClass
{
	[DispId(1610743812)]
	public virtual extern int ChildCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	public virtual extern void AddChild([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Interface)] IHNode child);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void RemoveChild([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IHNode GetChild([In] int index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	[return: MarshalAs(UnmanagedType.BStr)]
	public virtual extern string GetChildName([In] int index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	public virtual extern void DumpToDataBase([In][MarshalAs(UnmanagedType.BStr)] string filename, [In][MarshalAs(UnmanagedType.BStr)] string tablename, [In] int create);
}
[ComImport]
[Guid("11677780-B72B-11D0-A943-0000C0A118DB")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IHPlotVal
{
	[DispId(1610743808)]
	IHNode Context
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743810)]
	string Title
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743811)]
	string TitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743813)]
	string XAxisTitle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743814)]
	string XAxisTitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743816)]
	string YAxisTitle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743817)]
	string YAxisTitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743819)]
	string Label
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743820)]
	string LabelInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743822)]
	int NPoints
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		[param: In]
		set;
	}

	[DispId(1610743824)]
	int NVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[param: In]
		set;
	}

	[DispId(1610743826)]
	int NXVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[param: In]
		set;
	}

	[DispId(1610743828)]
	double XDataValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743828)]
		get;
	}

	[DispId(1610743829)]
	object XData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743829)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743830)]
	double YDataValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		get;
	}

	[DispId(1610743831)]
	object YData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	void GetXData([In] int index, [In] int datano, out short attr, [MarshalAs(UnmanagedType.Struct)] out object Value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743833)]
	void GetYData([In] int index, [In] int datano, out short attr, [MarshalAs(UnmanagedType.Struct)] out object Value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743834)]
	void Clear();

	[DispId(1610743835)]
	bool SwapAxises
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		[param: In]
		set;
	}

	[DispId(1610743837)]
	bool ReverseXAxis
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743837)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743837)]
		[param: In]
		set;
	}

	[DispId(1610743839)]
	bool AddTimeStamp
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743839)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743839)]
		[param: In]
		set;
	}

	[DispId(1610743841)]
	bool ShowLegend
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743841)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743841)]
		[param: In]
		set;
	}

	[DispId(1610743843)]
	int PlotType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		[param: In]
		set;
	}

	[DispId(1610743845)]
	bool Parametric
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743845)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743845)]
		[param: In]
		set;
	}

	[DispId(1610743847)]
	string ZAxisTitle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743847)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743847)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743848)]
	string ZAxisTitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743848)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743850)]
	bool Live
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743850)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743850)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	void AddAnnotationText([In] ref PLOTTEXT text);

	[DispId(1610743853)]
	int AnnotationCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743853)]
		get;
	}

	[DispId(1610743854)]
	PLOTTEXT AnnotationText
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743854)]
		get;
	}

	[DispId(1610743855)]
	short GridType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		[param: In]
		set;
	}

	[DispId(1610743857)]
	short MarkerSize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743857)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743857)]
		[param: In]
		set;
	}

	[DispId(1610743859)]
	bool ShowDiagonalLine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743859)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743859)]
		[param: In]
		set;
	}

	[DispId(1610743861)]
	short LineStyle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		[param: In]
		set;
	}

	[DispId(1610743863)]
	bool XDataInteger
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743863)]
		get;
	}

	[DispId(1610743864)]
	bool ShowZeroLine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		[param: In]
		set;
	}

	[DispId(1610743866)]
	int AxisMap
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743866)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743866)]
		[param: In]
		set;
	}

	[DispId(1610743868)]
	int CurveStyle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743868)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743868)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743870)]
	void RemoveAnnotationText();

	[DispId(1610743871)]
	bool SquarePlot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743871)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743871)]
		[param: In]
		set;
	}

	[DispId(1610743873)]
	bool CanLive
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743873)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743873)]
		[param: In]
		set;
	}

	[DispId(1610743875)]
	int AxisScale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743875)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743875)]
		[param: In]
		set;
	}
}
[ComImport]
[Guid("11677780-B72B-11D0-A943-0000C0A118DB")]
[CoClass(typeof(CHPlotValClass))]
public interface CHPlotVal : IHPlotVal
{
}
[ComImport]
[Guid("01FFE11C-7323-42FE-AAF4-ED713E6E04FF")]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
[ClassInterface(ClassInterfaceType.None)]
public class CHPlotValClass
{
	[DispId(1610743808)]
	public virtual extern IHNode Context
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743810)]
	public virtual extern string Title
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743811)]
	public virtual extern string TitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743813)]
	public virtual extern string XAxisTitle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743814)]
	public virtual extern string XAxisTitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743816)]
	public virtual extern string YAxisTitle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743817)]
	public virtual extern string YAxisTitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743819)]
	public virtual extern string Label
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743820)]
	public virtual extern string LabelInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743822)]
	public virtual extern int NPoints
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		[param: In]
		set;
	}

	[DispId(1610743824)]
	public virtual extern int NVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[param: In]
		set;
	}

	[DispId(1610743826)]
	public virtual extern int NXVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[param: In]
		set;
	}

	[DispId(1610743828)]
	public virtual extern double XDataValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743828)]
		get;
	}

	[DispId(1610743829)]
	public virtual extern object XData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743829)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743830)]
	public virtual extern double YDataValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		get;
	}

	[DispId(1610743831)]
	public virtual extern object YData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743835)]
	public virtual extern bool SwapAxises
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		[param: In]
		set;
	}

	[DispId(1610743837)]
	public virtual extern bool ReverseXAxis
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743837)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743837)]
		[param: In]
		set;
	}

	[DispId(1610743839)]
	public virtual extern bool AddTimeStamp
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743839)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743839)]
		[param: In]
		set;
	}

	[DispId(1610743841)]
	public virtual extern bool ShowLegend
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743841)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743841)]
		[param: In]
		set;
	}

	[DispId(1610743843)]
	public virtual extern int PlotType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		[param: In]
		set;
	}

	[DispId(1610743845)]
	public virtual extern bool Parametric
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743845)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743845)]
		[param: In]
		set;
	}

	[DispId(1610743847)]
	public virtual extern string ZAxisTitle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743847)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743847)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743848)]
	public virtual extern string ZAxisTitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743848)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743850)]
	public virtual extern bool Live
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743850)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743850)]
		[param: In]
		set;
	}

	[DispId(1610743853)]
	public virtual extern int AnnotationCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743853)]
		get;
	}

	[DispId(1610743854)]
	public virtual extern PLOTTEXT AnnotationText
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743854)]
		get;
	}

	[DispId(1610743855)]
	public virtual extern short GridType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		[param: In]
		set;
	}

	[DispId(1610743857)]
	public virtual extern short MarkerSize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743857)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743857)]
		[param: In]
		set;
	}

	[DispId(1610743859)]
	public virtual extern bool ShowDiagonalLine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743859)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743859)]
		[param: In]
		set;
	}

	[DispId(1610743861)]
	public virtual extern short LineStyle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		[param: In]
		set;
	}

	[DispId(1610743863)]
	public virtual extern bool XDataInteger
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743863)]
		get;
	}

	[DispId(1610743864)]
	public virtual extern bool ShowZeroLine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		[param: In]
		set;
	}

	[DispId(1610743866)]
	public virtual extern int AxisMap
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743866)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743866)]
		[param: In]
		set;
	}

	[DispId(1610743868)]
	public virtual extern int CurveStyle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743868)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743868)]
		[param: In]
		set;
	}

	[DispId(1610743871)]
	public virtual extern bool SquarePlot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743871)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743871)]
		[param: In]
		set;
	}

	[DispId(1610743873)]
	public virtual extern bool CanLive
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743873)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743873)]
		[param: In]
		set;
	}

	[DispId(1610743875)]
	public virtual extern int AxisScale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743875)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743875)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	public virtual extern void GetXData([In] int index, [In] int datano, out short attr, [MarshalAs(UnmanagedType.Struct)] out object Value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743833)]
	public virtual extern void GetYData([In] int index, [In] int datano, out short attr, [MarshalAs(UnmanagedType.Struct)] out object Value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743834)]
	public virtual extern void Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	public virtual extern void AddAnnotationText([In] ref PLOTTEXT text);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743870)]
	public virtual extern void RemoveAnnotationText();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("8008C730-1A3E-11D1-8A4D-0000C0237DF9")]
public interface IHWizardPlot
{
	[DispId(1610743808)]
	CHPlotVal PlotVal
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	int basis
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		set;
	}

	[DispId(1610743811)]
	int unitrow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		set;
	}

	[DispId(1610743813)]
	int unitcol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void SetIndependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	void AddDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	void RemoveDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	void RemoveAllDependentVariable();

	[DispId(1610743819)]
	bool HasDependentVariable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	void AddVariablePair([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar, [In][MarshalAs(UnmanagedType.BStr)] string depvar, [In] short sort);

	[DispId(1610743821)]
	object WizardData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743823)]
	void Clear();

	[DispId(1610743824)]
	int ErrorNumber
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		get;
	}

	[DispId(1610743825)]
	bool ErrorStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		[param: In]
		set;
	}

	[DispId(1610743826)]
	string RefreshCallBack
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	void GetIndependentVariable([MarshalAs(UnmanagedType.BStr)] out string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	void GetDependentVariable([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] ref string[] depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	void GetPlotList([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_DISPATCH)] ref CHPlotVal[] plots);

	[DispId(1610743831)]
	CHPlotVal AddToPlot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743833)]
	int XUnitRow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743833)]
		get;
	}

	[DispId(1610743834)]
	int XUnitCol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		[param: In]
		set;
	}
}
[ComImport]
[Guid("8008C730-1A3E-11D1-8A4D-0000C0237DF9")]
[CoClass(typeof(CHWizardPlotClass))]
public interface CHWizardPlot : IHWizardPlot
{
}
[ComImport]
[Guid("0000010C-0000-0000-C000-000000000046")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IPersist
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetClassID(out Guid pClassID);
}
[ComImport]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("00000109-0000-0000-C000-000000000046")]
public interface IPersistStream : IPersist
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	new void GetClassID(out Guid pClassID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void IsDirty();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Load([In][MarshalAs(UnmanagedType.Interface)] IStream pstm);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Save([In][MarshalAs(UnmanagedType.Interface)] IStream pstm, [In] int fClearDirty);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetSizeMax(out ULARGE_INTEGER pcbSize);
}
[ComImport]
[Guid("5DA88FB5-5B29-4EAE-ACDF-E45DE2319D99")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IHWizardPlot2 : IHWizardPlot
{
	[DispId(1610743808)]
	new CHPlotVal PlotVal
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	new int basis
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		set;
	}

	[DispId(1610743811)]
	new int unitrow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		set;
	}

	[DispId(1610743813)]
	new int unitcol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	new void SetIndependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	new void AddDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	new void RemoveDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	new void RemoveAllDependentVariable();

	[DispId(1610743819)]
	new bool HasDependentVariable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	new void AddVariablePair([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar, [In][MarshalAs(UnmanagedType.BStr)] string depvar, [In] short sort);

	[DispId(1610743821)]
	new object WizardData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743823)]
	new void Clear();

	[DispId(1610743824)]
	new int ErrorNumber
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		get;
	}

	[DispId(1610743825)]
	new bool ErrorStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		[param: In]
		set;
	}

	[DispId(1610743826)]
	new string RefreshCallBack
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	new void GetIndependentVariable([MarshalAs(UnmanagedType.BStr)] out string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	new void GetDependentVariable([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] ref string[] depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	new void GetPlotList([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_DISPATCH)] ref CHPlotVal[] plots);

	[DispId(1610743831)]
	new CHPlotVal AddToPlot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743833)]
	new int XUnitRow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743833)]
		get;
	}

	[DispId(1610743834)]
	new int XUnitCol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809344)]
	void SetMultIndependentVariables([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809345)]
	void RemoveIndependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar, int index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809346)]
	void RemoveAllIndependentVariable();
}
[ComImport]
[Guid("9E14C11F-6706-4067-8112-35CE9468F3A5")]
[ClassInterface(ClassInterfaceType.None)]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
public class CHWizardPlotClass
{
	[DispId(1610743808)]
	public virtual extern CHPlotVal PlotVal
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	public virtual extern int basis
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		set;
	}

	[DispId(1610743811)]
	public virtual extern int unitrow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		set;
	}

	[DispId(1610743813)]
	public virtual extern int unitcol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		set;
	}

	[DispId(1610743819)]
	public virtual extern bool HasDependentVariable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		get;
	}

	[DispId(1610743821)]
	public virtual extern object WizardData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	[DispId(1610743824)]
	public virtual extern int ErrorNumber
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		get;
	}

	[DispId(1610743825)]
	public virtual extern bool ErrorStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		[param: In]
		set;
	}

	[DispId(1610743826)]
	public virtual extern string RefreshCallBack
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743831)]
	public virtual extern CHPlotVal AddToPlot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743833)]
	public virtual extern int XUnitRow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743833)]
		get;
	}

	[DispId(1610743834)]
	public virtual extern int XUnitCol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		[param: In]
		set;
	}

	public virtual extern CHPlotVal IHWizardPlot2_PlotVal
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern int IHWizardPlot2_basis
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern int IHWizardPlot2_unitrow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern int IHWizardPlot2_unitcol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern bool IHWizardPlot2_HasDependentVariable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern object IHWizardPlot2_WizardData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	public virtual extern int IHWizardPlot2_ErrorNumber
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern bool IHWizardPlot2_ErrorStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern string IHWizardPlot2_RefreshCallBack
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	public virtual extern CHPlotVal IHWizardPlot2_AddToPlot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	public virtual extern int IHWizardPlot2_XUnitRow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern int IHWizardPlot2_XUnitCol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetIndependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	public virtual extern void AddDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	public virtual extern void RemoveDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	public virtual extern void RemoveAllDependentVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	public virtual extern void AddVariablePair([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar, [In][MarshalAs(UnmanagedType.BStr)] string depvar, [In] short sort);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743823)]
	public virtual extern void Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	public virtual extern void GetIndependentVariable([MarshalAs(UnmanagedType.BStr)] out string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	public virtual extern void GetDependentVariable([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] ref string[] depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	public virtual extern void GetPlotList([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_DISPATCH)] ref CHPlotVal[] plots);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetClassID(out Guid pClassID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IsDirty();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Load([In][MarshalAs(UnmanagedType.Interface)] IStream pstm);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Save([In][MarshalAs(UnmanagedType.Interface)] IStream pstm, [In] int fClearDirty);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetSizeMax(out ULARGE_INTEGER pcbSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_SetIndependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_AddDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_RemoveDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_RemoveAllDependentVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_AddVariablePair([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar, [In][MarshalAs(UnmanagedType.BStr)] string depvar, [In] short sort);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_GetIndependentVariable([MarshalAs(UnmanagedType.BStr)] out string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_GetDependentVariable([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] ref string[] depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_GetPlotList([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_DISPATCH)] ref CHPlotVal[] plots);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void SetMultIndependentVariables([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void RemoveIndependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar, int index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void RemoveAllIndependentVariable();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("623A7830-34F0-11D1-8A58-0000C0237DF9")]
public interface IHAdhocPlot
{
	[DispId(1610743808)]
	CHPlotVal PlotVal
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void ReadyToPlot();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void SetIndependentVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void SetDependentVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void SetParametricVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void Refresh();
}
[ComImport]
[CoClass(typeof(CHAdhocPlotClass))]
[Guid("623A7830-34F0-11D1-8A58-0000C0237DF9")]
public interface CHAdhocPlot : IHAdhocPlot
{
}
[ComImport]
[Guid("C571BF3D-A5E9-449A-A363-C9C2362C218D")]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
[ClassInterface(ClassInterfaceType.None)]
public class CHAdhocPlotClass
{
	[DispId(1610743808)]
	public virtual extern CHPlotVal PlotVal
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void ReadyToPlot();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void SetIndependentVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	public virtual extern void SetDependentVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	public virtual extern void SetParametricVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	public virtual extern void Refresh();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetClassID(out Guid pClassID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IsDirty();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Load([In][MarshalAs(UnmanagedType.Interface)] IStream pstm);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Save([In][MarshalAs(UnmanagedType.Interface)] IStream pstm, [In] int fClearDirty);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetSizeMax(out ULARGE_INTEGER pcbSize);
}
[ComImport]
[CoClass(typeof(HappAPropClass))]
[Guid("8E567521-F9BA-11CF-90B2-0000C0A810C4")]
public interface HappAProp : IHapp, IAPHappEvents_Event
{
}
[ComImport]
[ClassInterface(ClassInterfaceType.None)]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
[DefaultMember("Name")]
[Guid("41B64F41-B22F-4236-9FDB-E6ECAD7591BA")]
[ComSourceInterfaces("AspenTech.AspenPlus.Happ.IAPHappEvents\0\0")]
public class HappAPropClass
{
	[DispId(1610743808)]
	public virtual extern IHapp Application
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	public virtual extern IHapp Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern string FullName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(0)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool Visible
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[param: In]
		set;
	}

	[DispId(1610743814)]
	public virtual extern IHapp New
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743819)]
	public virtual extern IHNode Tree
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743825)]
	public virtual extern IHNode Choose
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743827)]
	public virtual extern IHSelection Selection
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743827)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743833)]
	public virtual extern IHapp NewAsync
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[DispId(1610743833)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743835)]
	public virtual extern IHAPEngine Engine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743843)]
	public virtual extern IHapp New2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[DispId(1610743843)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743848)]
	public virtual extern IHapp New3
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743848)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743849)]
	public virtual extern object Restore2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743849)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610743855)]
	public virtual extern IHAPLibRef LibRef
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743856)]
	public virtual extern int SuppressDialogs
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743856)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743856)]
		[param: In]
		set;
	}

	[DispId(1610743860)]
	public virtual extern object EngineSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743860)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743861)]
	public virtual extern object EngineServer
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743863)]
	public virtual extern int ProcessId
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743863)]
		get;
	}

	[DispId(1610743864)]
	public virtual extern object RootModel
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743867)]
	public virtual extern int StrongReferences
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743867)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		get;
	}

	[DispId(1610743869)]
	public virtual extern bool RefreshOff
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743869)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743869)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[param: In]
		set;
	}

	[DispId(1610743877)]
	public virtual extern string FailedToOpenKey
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743877)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743878)]
	public virtual extern string FailedToOpenDescription
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743878)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	public virtual extern int MainHWnd
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern int ProcessHandle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern event IAPHappEvents_OnDialogSuppressedEventHandler OnDialogSuppressed;

	public virtual extern event IAPHappEvents_OnControlPanelMessageEventHandler OnControlPanelMessage;

	public virtual extern event IAPHappEvents_OnGUIClosingEventHandler OnGUIClosing;

	public virtual extern event IAPHappEvents_OnInClosingEventHandler OnInClosing;

	public virtual extern event IAPHappEvents_OnDataChangedEventHandler OnDataChanged;

	public virtual extern event IAPHappEvents_OnUpdateMessageEventHandler OnUpdateMessage;

	public virtual extern event IAPHappEvents_OnEngineCommandCompletedEventHandler OnEngineCommandCompleted;

	public virtual extern event IAPHappEvents_OnBeforeCalculateEventHandler OnBeforeCalculate;

	public virtual extern event IAPHappEvents_OnBeforeSaveEventHandler OnBeforeSave;

	public virtual extern event IAPHappEvents_OnCalculationCompletedEventHandler OnCalculationCompleted;

	public virtual extern event IAPHappEvents_OnCalculationStoppedEventHandler OnCalculationStopped;

	public virtual extern event IAPHappEvents_OnGUIClosedEventHandler OnGUIClosed;

	public virtual extern event IAPHappEvents_OnDocumentClosingEventHandler OnDocumentClosing;

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void Restore([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743816)]
	public virtual extern void InitNew([Optional][In][MarshalAs(UnmanagedType.Struct)] object filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743817)]
	public virtual extern void InitFromFile([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object @readonly);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void InitFromArchive([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	public virtual extern void Save();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743821)]
	public virtual extern void SaveAs([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743822)]
	public virtual extern void WriteArchive([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743823)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void Run();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743824)]
	public virtual extern void Close([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743826)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IHSelection NewSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	public virtual extern void DeleteSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	public virtual extern void SaveSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	public virtual extern void Reinit();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743831)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void InitFromTemplate([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IHNode CreateRouteTree([In][MarshalAs(UnmanagedType.BStr)] ref string propname, [In][MarshalAs(UnmanagedType.BStr)] ref string routeid, [In][MarshalAs(UnmanagedType.BStr)] ref string opsetid, [In] short flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743834)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	public virtual extern void SetAsync();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743836)]
	public virtual extern void SaveLink([In][MarshalAs(UnmanagedType.Interface)] IStream pStrm, [In] int format);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743837)]
	public virtual extern void LoadLink([In][MarshalAs(UnmanagedType.Interface)] IStream pStrm, [In] int format);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743838)]
	public virtual extern void RefreshExportedLinks();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743839)]
	public virtual extern void Activate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	public virtual extern void SetCompat([In] int flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	public virtual extern void Reconcile([In] int code);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	public virtual extern void AdviseParent(int dAdviseType, int lParam);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743844)]
	public virtual extern void Generate([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int mode = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743845)]
	public virtual extern void Readback([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int mode = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743846)]
	public virtual extern void SetParent([In][MarshalAs(UnmanagedType.Interface)] IParentAdviseSink pParentAdviseSink, [In] int dwCookie);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	public virtual extern void WriteArchive2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [In] int bSaveChildren);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743850)]
	public virtual extern void InitNew2([Optional][In][MarshalAs(UnmanagedType.Struct)] object notused, [Optional][In][MarshalAs(UnmanagedType.Struct)] object notused2, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743851)]
	public virtual extern void InitFromFile2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object @readonly, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	public virtual extern void InitFromArchive2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743853)]
	public virtual extern void Run2([Optional][In][MarshalAs(UnmanagedType.Struct)] object async);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743854)]
	public virtual extern void InitFromTemplate2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743858)]
	public virtual extern void Export([In] HAPEXPType reptype, [In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743859)]
	public virtual extern void UIDisable([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743862)]
	public virtual extern void InitFromXML([In][MarshalAs(UnmanagedType.BStr)] string argument);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743865)]
	public virtual extern void InitFromArchive3([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [In][MarshalAs(UnmanagedType.Struct)] object open_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743866)]
	public virtual extern void Import([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743868)]
	public virtual extern void EditCompoundDocument([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743871)]
	public virtual extern void RunScript([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743872)]
	public virtual extern void AutoSave();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743873)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void Save2();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743874)]
	public virtual extern void SaveAs2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743875)]
	public virtual extern void Quit([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743876)]
	public virtual extern void CloseDocument([Optional][In][MarshalAs(UnmanagedType.Struct)] object Save);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void OnDataChange([In] int dwCookie, [In] int nSeverity);
}
[ComImport]
[Guid("8E567521-F9BA-11CF-90B2-0000C0A810C4")]
[CoClass(typeof(HappAPropIPClass))]
public interface HappAPropIP : IHapp, IAPHappEvents_Event
{
}
[ComImport]
[DefaultMember("Name")]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
[ComSourceInterfaces("AspenTech.AspenPlus.Happ.IAPHappEvents\0\0")]
[ClassInterface(ClassInterfaceType.None)]
[Guid("F46D3BEA-8D56-4403-BCC9-4748EE792868")]
public class HappAPropIPClass
{
	[DispId(1610743808)]
	public virtual extern IHapp Application
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	public virtual extern IHapp Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	public virtual extern string FullName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(0)]
	public virtual extern string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	public virtual extern bool Visible
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[param: In]
		set;
	}

	[DispId(1610743814)]
	public virtual extern IHapp New
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743819)]
	public virtual extern IHNode Tree
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743825)]
	public virtual extern IHNode Choose
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743827)]
	public virtual extern IHSelection Selection
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743827)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743833)]
	public virtual extern IHapp NewAsync
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743833)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743835)]
	public virtual extern IHAPEngine Engine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743843)]
	public virtual extern IHapp New2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[DispId(1610743843)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743848)]
	public virtual extern IHapp New3
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743848)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743849)]
	public virtual extern object Restore2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743849)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610743855)]
	public virtual extern IHAPLibRef LibRef
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743856)]
	public virtual extern int SuppressDialogs
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743856)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743856)]
		[param: In]
		set;
	}

	[DispId(1610743860)]
	public virtual extern object EngineSimulation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743860)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743861)]
	public virtual extern object EngineServer
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743863)]
	public virtual extern int ProcessId
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743863)]
		get;
	}

	[DispId(1610743864)]
	public virtual extern object RootModel
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743864)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[DispId(1610743867)]
	public virtual extern int StrongReferences
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743867)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		get;
	}

	[DispId(1610743869)]
	public virtual extern bool RefreshOff
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743869)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743869)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[param: In]
		set;
	}

	[DispId(1610743877)]
	public virtual extern string FailedToOpenKey
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743877)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743878)]
	public virtual extern string FailedToOpenDescription
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[DispId(1610743878)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	public virtual extern int MainHWnd
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern int ProcessHandle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern event IAPHappEvents_OnDialogSuppressedEventHandler OnDialogSuppressed;

	public virtual extern event IAPHappEvents_OnControlPanelMessageEventHandler OnControlPanelMessage;

	public virtual extern event IAPHappEvents_OnGUIClosingEventHandler OnGUIClosing;

	public virtual extern event IAPHappEvents_OnInClosingEventHandler OnInClosing;

	public virtual extern event IAPHappEvents_OnDataChangedEventHandler OnDataChanged;

	public virtual extern event IAPHappEvents_OnUpdateMessageEventHandler OnUpdateMessage;

	public virtual extern event IAPHappEvents_OnEngineCommandCompletedEventHandler OnEngineCommandCompleted;

	public virtual extern event IAPHappEvents_OnBeforeCalculateEventHandler OnBeforeCalculate;

	public virtual extern event IAPHappEvents_OnBeforeSaveEventHandler OnBeforeSave;

	public virtual extern event IAPHappEvents_OnCalculationCompletedEventHandler OnCalculationCompleted;

	public virtual extern event IAPHappEvents_OnCalculationStoppedEventHandler OnCalculationStopped;

	public virtual extern event IAPHappEvents_OnGUIClosedEventHandler OnGUIClosed;

	public virtual extern event IAPHappEvents_OnDocumentClosingEventHandler OnDocumentClosing;

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743815)]
	public virtual extern void Restore([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743816)]
	public virtual extern void InitNew([Optional][In][MarshalAs(UnmanagedType.Struct)] object filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743817)]
	public virtual extern void InitFromFile([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object @readonly);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void InitFromArchive([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	public virtual extern void Save();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743821)]
	public virtual extern void SaveAs([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743822)]
	public virtual extern void WriteArchive([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743823)]
	public virtual extern void Run();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743824)]
	public virtual extern void Close([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743826)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IHSelection NewSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	public virtual extern void DeleteSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	public virtual extern void SaveSelection([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	public virtual extern void Reinit();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743831)]
	public virtual extern void InitFromTemplate([In][MarshalAs(UnmanagedType.BStr)] ref string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	[return: MarshalAs(UnmanagedType.Interface)]
	public virtual extern IHNode CreateRouteTree([In][MarshalAs(UnmanagedType.BStr)] ref string propname, [In][MarshalAs(UnmanagedType.BStr)] ref string routeid, [In][MarshalAs(UnmanagedType.BStr)] ref string opsetid, [In] short flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743834)]
	public virtual extern void SetAsync();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743836)]
	public virtual extern void SaveLink([In][MarshalAs(UnmanagedType.Interface)] IStream pStrm, [In] int format);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743837)]
	public virtual extern void LoadLink([In][MarshalAs(UnmanagedType.Interface)] IStream pStrm, [In] int format);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743838)]
	public virtual extern void RefreshExportedLinks();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743839)]
	public virtual extern void Activate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	public virtual extern void SetCompat([In] int flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	public virtual extern void Reconcile([In] int code);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	public virtual extern void AdviseParent(int dAdviseType, int lParam);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743844)]
	public virtual extern void Generate([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int mode = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743845)]
	public virtual extern void Readback([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int mode = 0);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743846)]
	public virtual extern void SetParent([In][MarshalAs(UnmanagedType.Interface)] IParentAdviseSink pParentAdviseSink, [In] int dwCookie);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	public virtual extern void WriteArchive2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [In] int bSaveChildren);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743850)]
	public virtual extern void InitNew2([Optional][In][MarshalAs(UnmanagedType.Struct)] object notused, [Optional][In][MarshalAs(UnmanagedType.Struct)] object notused2, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743851)]
	public virtual extern void InitFromFile2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object @readonly, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	public virtual extern void InitFromArchive2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743853)]
	public virtual extern void Run2([Optional][In][MarshalAs(UnmanagedType.Struct)] object async);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743854)]
	public virtual extern void InitFromTemplate2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743858)]
	public virtual extern void Export([In] HAPEXPType reptype, [In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743859)]
	public virtual extern void UIDisable([In][MarshalAs(UnmanagedType.BStr)] string Key);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743862)]
	public virtual extern void InitFromXML([In][MarshalAs(UnmanagedType.BStr)] string argument);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743865)]
	public virtual extern void InitFromArchive3([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [In][MarshalAs(UnmanagedType.Struct)] object open_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory, [Optional][In][MarshalAs(UnmanagedType.Struct)] object failmode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743866)]
	public virtual extern void Import([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743868)]
	public virtual extern void EditCompoundDocument([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743871)]
	public virtual extern void RunScript([In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743872)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void AutoSave();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743873)]
	public virtual extern void Save2();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743874)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	public virtual extern void SaveAs2([In][MarshalAs(UnmanagedType.BStr)] ref string filename, [Optional][In][MarshalAs(UnmanagedType.Struct)] object overwrite);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743875)]
	public virtual extern void Quit([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743876)]
	public virtual extern void CloseDocument([Optional][In][MarshalAs(UnmanagedType.Struct)] object Save);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void OnDataChange([In] int dwCookie, [In] int nSeverity);
}
[ComImport]
[CoClass(typeof(CHAdhocPlotAPropClass))]
[Guid("623A7830-34F0-11D1-8A58-0000C0237DF9")]
public interface CHAdhocPlotAProp : IHAdhocPlot
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
[ClassInterface(ClassInterfaceType.None)]
[Guid("8B5DC2F7-DD28-4C19-8013-82E027FBD94F")]
public class CHAdhocPlotAPropClass
{
	[DispId(1610743808)]
	public virtual extern CHPlotVal PlotVal
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	public virtual extern void ReadyToPlot();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	public virtual extern void SetIndependentVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	public virtual extern void SetDependentVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	public virtual extern void SetParametricVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	public virtual extern void Refresh();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetClassID(out Guid pClassID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IsDirty();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Load([In][MarshalAs(UnmanagedType.Interface)] IStream pstm);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Save([In][MarshalAs(UnmanagedType.Interface)] IStream pstm, [In] int fClearDirty);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetSizeMax(out ULARGE_INTEGER pcbSize);
}
[ComImport]
[Guid("8008C730-1A3E-11D1-8A4D-0000C0237DF9")]
[CoClass(typeof(CHWizardPlotAPropClass))]
public interface CHWizardPlotAProp : IHWizardPlot
{
}
[ComImport]
[Guid("34184F9F-A0D5-4ACD-BDA9-D3B94D350453")]
[TypeLibType(TypeLibTypeFlags.FAppObject | TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FPreDeclId)]
[ClassInterface(ClassInterfaceType.None)]
public class CHWizardPlotAPropClass
{
	[DispId(1610743808)]
	public virtual extern CHPlotVal PlotVal
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	public virtual extern int basis
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		set;
	}

	[DispId(1610743811)]
	public virtual extern int unitrow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		set;
	}

	[DispId(1610743813)]
	public virtual extern int unitcol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		set;
	}

	[DispId(1610743819)]
	public virtual extern bool HasDependentVariable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		get;
	}

	[DispId(1610743821)]
	public virtual extern object WizardData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	[DispId(1610743824)]
	public virtual extern int ErrorNumber
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		get;
	}

	[DispId(1610743825)]
	public virtual extern bool ErrorStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		[param: In]
		set;
	}

	[DispId(1610743826)]
	public virtual extern string RefreshCallBack
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743831)]
	public virtual extern CHPlotVal AddToPlot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743833)]
	public virtual extern int XUnitRow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743833)]
		get;
	}

	[DispId(1610743834)]
	public virtual extern int XUnitCol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		[param: In]
		set;
	}

	public virtual extern CHPlotVal IHWizardPlot2_PlotVal
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	public virtual extern int IHWizardPlot2_basis
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern int IHWizardPlot2_unitrow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern int IHWizardPlot2_unitcol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern bool IHWizardPlot2_HasDependentVariable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern object IHWizardPlot2_WizardData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	public virtual extern int IHWizardPlot2_ErrorNumber
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern bool IHWizardPlot2_ErrorStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	public virtual extern string IHWizardPlot2_RefreshCallBack
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	public virtual extern CHPlotVal IHWizardPlot2_AddToPlot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	public virtual extern int IHWizardPlot2_XUnitRow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	public virtual extern int IHWizardPlot2_XUnitCol
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	public virtual extern void SetIndependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	public virtual extern void AddDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	public virtual extern void RemoveDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	public virtual extern void RemoveAllDependentVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	public virtual extern void AddVariablePair([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar, [In][MarshalAs(UnmanagedType.BStr)] string depvar, [In] short sort);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743823)]
	public virtual extern void Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	public virtual extern void GetIndependentVariable([MarshalAs(UnmanagedType.BStr)] out string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	public virtual extern void GetDependentVariable([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] ref string[] depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	public virtual extern void GetPlotList([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_DISPATCH)] ref CHPlotVal[] plots);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetClassID(out Guid pClassID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IsDirty();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Load([In][MarshalAs(UnmanagedType.Interface)] IStream pstm);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Save([In][MarshalAs(UnmanagedType.Interface)] IStream pstm, [In] int fClearDirty);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetSizeMax(out ULARGE_INTEGER pcbSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_SetIndependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_AddDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_RemoveDependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_RemoveAllDependentVariable();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_AddVariablePair([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar, [In][MarshalAs(UnmanagedType.BStr)] string depvar, [In] short sort);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_GetIndependentVariable([MarshalAs(UnmanagedType.BStr)] out string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_GetDependentVariable([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_BSTR)] ref string[] depvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void IHWizardPlot2_GetPlotList([In][Out][MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_DISPATCH)] ref CHPlotVal[] plots);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void SetMultIndependentVariables([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void RemoveIndependentVariable([In][MarshalAs(UnmanagedType.Interface)] IHNode pContext, [In][MarshalAs(UnmanagedType.BStr)] string indepvar, int index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void RemoveAllIndependentVariable();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("8E567522-F9BA-11CF-90B2-0000C0A810C4")]
public interface IHNode
{
	[DispId(1610743808)]
	IHapp Application
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	IHapp Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743812)]
	int Dimension
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610743813)]
	short ValueType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
	}

	[DispId(1610743814)]
	object Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	void SetValueAndUnit([In][MarshalAs(UnmanagedType.Struct)] object Value, [In] short unitcol, [Optional][In][MarshalAs(UnmanagedType.Struct)] object force);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	void SetValueUnitAndBasis([In][MarshalAs(UnmanagedType.Struct)] object Value, [In] short unitcol, [In][MarshalAs(UnmanagedType.BStr)] string basis, [Optional][In][MarshalAs(UnmanagedType.Struct)] object force);

	[DispId(1610743818)]
	bool HasAttribute
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		get;
	}

	[DispId(1610743819)]
	short AttributeType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		get;
	}

	[DispId(1610743820)]
	object AttributeValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743822)]
	bool HasClassAttribute
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		get;
	}

	[DispId(1610743823)]
	short ClassAttributeType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743823)]
		get;
	}

	[DispId(1610743824)]
	object ClassAttributeValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743826)]
	IHNodeCol Elements
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743827)]
	int Process
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[DispId(1610743827)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	void Delete();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	void RemoveAll();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	void AddClassAttribute([In][MarshalAs(UnmanagedType.BStr)] string classid, [In] short type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743831)]
	void DeleteClassAttribute([In][MarshalAs(UnmanagedType.BStr)] string classid);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743832)]
	void Copy();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743833)]
	void CopyWithFormat();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743834)]
	void PrintUseful([In] short append, [In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743835)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IHNode FindNode([In][MarshalAs(UnmanagedType.BStr)] string path);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743836)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	bool Paste();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743837)]
	bool PasteSpecial();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743838)]
	bool IsLinked();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743839)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	void RemoveLink();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string NextIncomplete([Optional][MarshalAs(UnmanagedType.Struct)] out object code);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743841)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string BrowseNext([In] short direction, [In] short io);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	void Dummy([In] HAPAttributeNumber __MIDL__IHNode0000, [In] HAPCompStatusCode __MIDL__IHNode0001);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743843)]
	void Hide([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743844)]
	void Reveal([In][MarshalAs(UnmanagedType.BStr)] string Name = "");

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743845)]
	void Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743846)]
	void NotifyRunStep();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	void HoldNotifies([In] bool hold);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743848)]
	bool IsValid();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743849)]
	void NewChild([In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743850)]
	void RenameChild([In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743851)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	bool IsSpecialType([In] HAPSpecialNodeType type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	void Reaquire();

	[DispId(1610743853)]
	string UnitString
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743853)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743854)]
	object ValueForUnit
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743854)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743855)]
	void PFSSelectModel();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743856)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	void PFSClearSelection();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743857)]
	void Reconcile([In] int code);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743858)]
	void NewID([In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743859)]
	void Export([In][MarshalAs(UnmanagedType.BStr)] string filename = "");

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743860)]
	short DoObjectVerb([In] int oleverb);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743861)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	void AppendTemplate([In][MarshalAs(UnmanagedType.IUnknown)] object pUnkTempl, [Optional][In][MarshalAs(UnmanagedType.Struct)] object flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743862)]
	void Import([In][MarshalAs(UnmanagedType.BStr)] string filename = "");

	[DispId(1610743863)]
	bool RefreshOff
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743863)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[param: In]
		set;
	}

	[DispId(1610743864)]
	IAdsNode SharedData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("71F9FD70-9ED4-11D0-9475-0000C07972E4")]
public interface IHSelection
{
	[DispId(1610743808)]
	IHapp Application
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	IHapp Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}

	[DispId(0)]
	object this[[In][MarshalAs(UnmanagedType.Struct)] object loc_or_name]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610743812)]
	short ItemType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610743813)]
	string Key
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743814)]
	string Label
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	void Add([In][MarshalAs(UnmanagedType.Struct)] object loc_or_name, [In] short type, [In][MarshalAs(UnmanagedType.Struct)] object Item, [In][MarshalAs(UnmanagedType.IDispatch)] object owner, [Optional][In][MarshalAs(UnmanagedType.Struct)] object scrollarea, [Optional][In][MarshalAs(UnmanagedType.Struct)] object row, [Optional][In][MarshalAs(UnmanagedType.Struct)] object col, [Optional][In][MarshalAs(UnmanagedType.Struct)] object index, [Optional][In][MarshalAs(UnmanagedType.Struct)] object xtwip, [Optional][In][MarshalAs(UnmanagedType.Struct)] object ytwip);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	void Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	void Remove([In][MarshalAs(UnmanagedType.Struct)] object loc_or_name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743819)]
	bool Find([In][MarshalAs(UnmanagedType.Struct)] object @object);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	void Copy();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743821)]
	void CopyWithFormat();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743822)]
	bool Paste();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743823)]
	bool PasteSpecial([Optional][In][MarshalAs(UnmanagedType.Struct)] object format, [Optional][In][MarshalAs(UnmanagedType.Struct)] object link);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743824)]
	void Lock([In] bool fLock);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743825)]
	void ClearOwned([In][MarshalAs(UnmanagedType.IDispatch)] object owner);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743826)]
	bool CanPrint();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743827)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object PreparePrinting();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("472C18A0-2603-11D1-9B33-0000C07EE8F2")]
public interface IHAPEngine
{
	[DispId(1610743808)]
	bool RunControl
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[param: In]
		set;
	}

	[DispId(1610743810)]
	bool ControlPanel
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[param: In]
		set;
	}

	[DispId(1610743812)]
	bool Ready
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743813)]
	void Run();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void Step();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void Stop();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	void Reinit([Optional][In][MarshalAs(UnmanagedType.Struct)] object object_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object object_id);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	void MoveTo([In] IAP_MOVETO_TYPE object_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object object_id);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	void ConnectionDialog();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743819)]
	bool Host([In] int host_type, [Optional][In][MarshalAs(UnmanagedType.Struct)] object node, [Optional][In][MarshalAs(UnmanagedType.Struct)] object username, [Optional][In][MarshalAs(UnmanagedType.Struct)] object password, [Optional][In][MarshalAs(UnmanagedType.Struct)] object working_directory);

	[DispId(1610743820)]
	int HostCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743821)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string HostDescription([In] int host_type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743822)]
	void RunSettings();

	[DispId(1610743823)]
	string EngineFilesSettings
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743823)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743823)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743825)]
	bool OptionSettings
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743825)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743827)]
	void StopPoints();

	[DispId(1610743828)]
	int StopPointCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743828)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	void GetStopPoint([In] int index, out IAP_STOPPOINT_TYPE type, [MarshalAs(UnmanagedType.BStr)] out string object_id, out int before_or_after);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	void AddStopPoint([In] IAP_STOPPOINT_TYPE type, [In][MarshalAs(UnmanagedType.BStr)] string object_id, [In] int before_or_after);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743831)]
	void DeleteStopPoint([In] int index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	void ClearStopPoints();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743833)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	void Dummy([In] IAP_REINIT_TYPE rtype);

	[DispId(1610743834)]
	bool IsRunning
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743835)]
	void Run2([Optional][In][MarshalAs(UnmanagedType.Struct)] object async);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	[DispId(1610743836)]
	void ProcessInput();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743837)]
	void ExportReport([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] HAPReportType contents, [Optional][In][MarshalAs(UnmanagedType.Struct)] object object_id);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743838)]
	void SynchronizeEO([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743839)]
	void ReinitializeEO([Optional][In][MarshalAs(UnmanagedType.Struct)] object reserved);
}
[ComImport]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("0C733A30-2A1C-11CE-ADE5-00AA0044773D")]
public interface ISequentialStream
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteRead(out byte pv, [In] uint cb, out uint pcbRead);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteWrite([In] ref byte pv, [In] uint cb, out uint pcbWritten);
}
[ComImport]
[Guid("0000000C-0000-0000-C000-000000000046")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IStream : ISequentialStream
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	new void RemoteRead(out byte pv, [In] uint cb, out uint pcbRead);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	new void RemoteWrite([In] ref byte pv, [In] uint cb, out uint pcbWritten);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteSeek([In] LARGE_INTEGER dlibMove, [In] uint dwOrigin, out ULARGE_INTEGER plibNewPosition);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetSize([In] ULARGE_INTEGER libNewSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteCopyTo([In][MarshalAs(UnmanagedType.Interface)] IStream pstm, [In] ULARGE_INTEGER cb, out ULARGE_INTEGER pcbRead, out ULARGE_INTEGER pcbWritten);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Commit([In] uint grfCommitFlags);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Revert();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void LockRegion([In] ULARGE_INTEGER libOffset, [In] ULARGE_INTEGER cb, [In] uint dwLockType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void UnlockRegion([In] ULARGE_INTEGER libOffset, [In] ULARGE_INTEGER cb, [In] uint dwLockType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Stat(out STATSTG pstatstg, [In] uint grfStatFlag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Clone([MarshalAs(UnmanagedType.Interface)] out IStream ppstm);
}
[ComImport]
[Guid("8E567525-F9BA-11CF-90B2-0000C0A810C4")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IHAPLibRef
{
	[DispId(1610743808)]
	short CountLibs
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		get;
	}

	[DispId(1610743809)]
	string LibraryName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743810)]
	string LibraryPath
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string InsertLibrary([In][MarshalAs(UnmanagedType.BStr)] string path, [In] short location);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void RemoveLibrary([In] short location);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void MoveLibrary([In] short fromloc, [In] short toloc);

	[DispId(1610743814)]
	string CategoryName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743815)]
	short CategorySelected
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		[param: In]
		set;
	}

	[DispId(1610743817)]
	short CategoryLocSelected
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743819)]
	void MoveCategory([In] short fromloc, [In] short toloc);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743820)]
	void Enum([MarshalAs(UnmanagedType.Interface)] out IEnumAModelLibrary ppEnum);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743821)]
	void SetLibraryActive([In][MarshalAs(UnmanagedType.BStr)] string displayname);
}
public enum HAPEXPType
{
	HAPEXP_USRDEF,
	HAPEXP_BACKUP,
	HAPEXP_REPORT,
	HAPEXP_SUMMARY,
	HAPEXP_INPUT,
	HAPEXP_INPUT_GRAPHICS,
	HAPEXP_RUNMSG,
	HAPEXP_REPORT_INPUT,
	HAPEXP_REPORT_SUMMARY,
	HAPEXP_FLOWDYN,
	HAPEXP_PDYN,
	HAPEXP_DXF,
	HAPEXP_SUMXML,
	HAPEXP_HISTORY,
	HAPEXP_PFS,
	HAPEXP_PDF,
	HAPEXP_EOATSLV,
	HAPEXP_EOATACT,
	HAPEXP_INPUT_WITH_GRAPHICS,
	HAPEXP_APRBACKUP,
	HAPEXP_APRPDF,
	HAPEXP_APRREPORT,
	HAPEXP_ODI,
	HAPEXP_EDITRUNINPUT,
	HAPEXP_ADS_SUMMARY,
	HAPEXP_APROPINPUT
}
[ComVisible(false)]
public delegate void IAPHappEvents_OnDialogSuppressedEventHandler([In][MarshalAs(UnmanagedType.BStr)] string msg, [In][MarshalAs(UnmanagedType.BStr)] string result);
[ComVisible(false)]
public delegate void IAPHappEvents_OnControlPanelMessageEventHandler([In] int Clear, [In][MarshalAs(UnmanagedType.BStr)] string msg);
[ComVisible(false)]
public delegate void IAPHappEvents_OnGUIClosingEventHandler();
[ComVisible(false)]
public delegate void IAPHappEvents_OnInClosingEventHandler([In] int Clear, [In][MarshalAs(UnmanagedType.BStr)] string msg);
[ComVisible(false)]
public delegate void IAPHappEvents_OnDataChangedEventHandler([In][MarshalAs(UnmanagedType.IDispatch)] object pObj);
[ComVisible(false)]
public delegate void IAPHappEvents_OnUpdateMessageEventHandler([In] int msg_code, [In][MarshalAs(UnmanagedType.BStr)] string msg_hint, [In][MarshalAs(UnmanagedType.IDispatch)] object msg_object, [In] int source_handle);
[ComVisible(false)]
public delegate void IAPHappEvents_OnEngineCommandCompletedEventHandler();
[ComVisible(false)]
public delegate void IAPHappEvents_OnBeforeCalculateEventHandler([In] bool IsStep, [In] ref bool Cancel);
[ComVisible(false)]
public delegate void IAPHappEvents_OnBeforeSaveEventHandler([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] ref bool Cancel);
[ComVisible(false)]
public delegate void IAPHappEvents_OnCalculationCompletedEventHandler();
[ComVisible(false)]
public delegate void IAPHappEvents_OnCalculationStoppedEventHandler();
[ComVisible(false)]
public delegate void IAPHappEvents_OnGUIClosedEventHandler();
[ComVisible(false)]
public delegate void IAPHappEvents_OnDocumentClosingEventHandler();
[StructLayout(LayoutKind.Sequential, Pack = 8)]
[Guid("24B82EB0-4A1F-11D1-8A70-0000C0237DF9")]
public struct PLOTTEXT
{
	public double x;

	public double y;

	[MarshalAs(UnmanagedType.BStr)]
	public string text;

	public int color;

	[MarshalAs(UnmanagedType.BStr)]
	public string fontname;

	public short alignment;

	public short size;

	public short style;

	public short pad;
}
[ComImport]
[Guid("89E81F60-019A-11D0-9BE7-0000C05375D5")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IHNodeCol : IEnumerable
{
	[DispId(1610743808)]
	IHapp Application
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	IHapp Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}

	[DispId(1610743811)]
	int RowCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(1610743812)]
	int Dimension
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610743813)]
	bool IsNamedDimension
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
	}

	[DispId(0)]
	IHNode this[[In][MarshalAs(UnmanagedType.Struct)] object loc_or_name, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name2, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name3, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name4, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name5]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743815)]
	string ItemName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743817)]
	string Label
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743819)]
	IHNode LabelNode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743820)]
	int LabelLocation
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		get;
	}

	[DispId(1610743821)]
	object LabelAttribute
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743823)]
	short LabelAttributeType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743823)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743825)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IHNode Add([Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name2, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name3, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name4, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name5);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743826)]
	void Insert([In][MarshalAs(UnmanagedType.Interface)] IHNode element, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name2, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name3, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name4, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name5);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743827)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IHNode Remove([In][MarshalAs(UnmanagedType.Struct)] object loc_or_name, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name2, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name3, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name4, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name5);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	void InsertRow([In] int Dimension, [In] int location);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	void RemoveRow([In] int Dimension, [In] int location);

	[DispId(1610743830)]
	string DimensionName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743831)]
	void Reorder([In][MarshalAs(UnmanagedType.Struct)] object loc_or_name, [In] short dir);

	[DispId(1610743832)]
	object[] Values
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743832)]
		[return: MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)]
		get;
	}
}
public enum HAPAttributeNumber
{
	HAP_VALUE = 0,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_RESERVED1 = 1,
	HAP_UNITROW = 2,
	HAP_UNITCOL = 3,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_RESERVED2 = 4,
	HAP_OPTIONLIST = 5,
	HAP_RECORDTYPE = 6,
	HAP_ENTERABLE = 7,
	HAP_UPPERLIMIT = 8,
	HAP_LOWERLIMIT = 9,
	HAP_VALUEDEFAULT = 10,
	HAP_USERENTERED = 11,
	HAP_COMPSTATUS = 12,
	HAP_BASIS = 13,
	HAP_INOUT = 14,
	HAP_PORTSEX = 15,
	HAP_MULTIPORT = 16,
	HAP_PORTTYPE = 17,
	HAP_OUTVAR = 18,
	HAP_PROMPT = 19,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_PRETENDNOTENTERED = 20,
	HAP_HELPFILENAME = 21,
	HAP_HELPID = 22,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_FIRSTPAIR = 23,
	HAP_NODENAME = 24,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_METHOD = 25,
	HAP_MARKED = 26,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_VOLATILE = 27,
	HAP_SECTION = 28,
	HAP_DEFNAME = 29,
	HAP_CANADD = 30,
	HAP_CANDELETE = 31,
	HAP_CANRENAME = 32,
	HAP_CANHIDE = 33,
	HAP_CANREVEAL = 34,
	HAP_CANCLEAR = 35,
	HAP_CANCOPY = 36,
	HAP_CANPASTE = 37,
	HAP_HASCHILDREN = 38,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_PLOTLABEL = 39,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_BIRDCAGE = 40,
	HAP_STREAMCLASS = 42,
	HAP_HASCOMMENTS = 43,
	HAP_CANHAVECOMMENTS = 44,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_UNDERLYINGPATH = 45,
	HAP_ISHIDDEN = 47,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_HIDEVIEW = 48,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_ANALYSISFLAG = 49,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_SPECSTREAM = 50,
	HAP_REORDER = 51,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_ISREALSYMBOL = 52,
	HAP_CANEXPORT = 58,
	HAP_BASETYPE = 59,
	HAP_HIERARCHYFLAG = 63,
	HAP_HIERPATH = 64,
	HAP_FULLNAME = 65,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_CANTEMPLAPPEND = 66,
	HAP_ACTIVATESTATE = 67,
	HAP_CANIMPORT = 68,
	HAP_HASEOMSG = 69,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_SHOWEOMSG = 70,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_EOEXPORT = 72,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_EOIMPORT = 73,
	[TypeLibVar(TypeLibVarFlags.FHidden)]
	HAP_NAVPATH = 74,
	HAP_HIERNAME = 76,
	HAP_REVEALLIST = 77,
	HAP_DEFRECONCILE = 78,
	HAP_EONODENAME = 79,
	HAP_UOM = 81,
	HAP_UOMSET = 82
}
public enum HAPCompStatusCode
{
	HAP_RESULTS_SUCCESS = 1,
	HAP_NORESULTS = 2,
	HAP_RESULTS_WARNINGS = 4,
	HAP_RESULTS_INACCESS = 8,
	HAP_RESULTS_INCOMPAT = 16,
	HAP_RESULTS_ERRORS = 32,
	HAP_INPUT_INCOMPLETE = 64,
	HAP_INPUT_COMPLETE = 128,
	HAP_INPUT_INACCESS = 256,
	HAP_INPUT_NEUTRAL = 512,
	HAP_UNRECONCILED = 1024,
	HAP_RECONCILED = 2048,
	HAP_DISABLED = 4096,
	HAP_ENABLED = 8192,
	HAP_EOSYNC = 16384,
	HAP_EOSYNC_WARNINGS = 32768,
	HAP_EOSYNC_ERRORS = 65536,
	HAP_EODISABLE = 2097152,
	HAP_EOFAIL = 262144,
	HAP_EOERROR = 524288,
	HAP_EOSYNC_UNSYNC = 1048576,
	HAP_NOT_RUN = 2097152
}
public enum HAPSpecialNodeType
{
	HAP_SPECIAL_ANALYSIS,
	HAP_SPECIAL_PURE,
	HAP_SPECIAL_UNIGROUP,
	HAP_SPECIAL_PSD,
	HAP_SPECIAL_SUBOBJECT,
	HAP_SPECIAL_STREAM
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("DC3CE393-6463-4AA9-BA35-57A3D6FC0FF3")]
public interface IAdsNode
{
	[DispId(1610743808)]
	IAdsNodeCol Elements
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	object Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[DispId(1610743810)]
	string UnitString
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743811)]
	int unitrow
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}

	[DispId(1610743812)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743813)]
	short ValueType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IAdsNode FindNode([In][MarshalAs(UnmanagedType.BStr)] string path);
}
public enum IAP_MOVETO_TYPE
{
	IAP_MOVETO_BLOCK = 0,
	IAP_MOVETO_CONVERGENCE = 1,
	IAP_MOVETO_SENSITIVITY = 2,
	IAP_MOVETO_CALCULATOR = 3,
	IAP_MOVETO_TRANSFER = 4,
	IAP_MOVETO_EQUIPMENT = 5,
	IAP_MOVETO_ECONOMIC = 6,
	IAP_MOVETO_UTILITY = 7,
	IAP_MOVETO_PRESRELIEF = 8,
	IAP_MOVETO_REGRESSION = 9,
	IAP_MOVETO_BALANCE = 10,
	IAP_MOVETO_START = 11,
	IAP_MOVETO_MEASUREMENT = 20
}
public enum IAP_ENGINEFILES
{
	IAP_PP1A,
	IAP_PP1B,
	IAP_PP2A,
	IAP_PP2B,
	IAP_PP2C,
	IAP_INSERTLIB,
	IAP_COST,
	IAP_STREAMLIB,
	IAP_RUNDEF,
	IAP_LINKEROPT
}
public enum IAP_RUN_OPTION
{
	IAP_RUN_EXPRESS,
	IAP_RUN_INTERTACTIVE,
	IAP_RUN_MUSTBECOMPLETE,
	IAP_RUN_COPY_DRS_PCES,
	IAP_RUN_COPY_DRS,
	IAP_RUN_COPY_PCES,
	IAP_RUN_COPY_RETRIEVED
}
public enum IAP_STOPPOINT_TYPE
{
	IAP_STOPPOINT_BLOCK = 1,
	IAP_STOPPOINT_CONVERGENCE,
	IAP_STOPPOINT_SENSITIVITY,
	IAP_STOPPOINT_CALCULATOR,
	IAP_STOPPOINT_TRANSFER,
	IAP_STOPPOINT_EQUIPMENT,
	IAP_STOPPOINT_ECONOMIC,
	IAP_STOPPOINT_UTILITY,
	IAP_STOPPOINT_PRESRELIEF,
	IAP_STOPPOINT_REGRESSION,
	IAP_STOPPOINT_BALANCE
}
public enum IAP_REINIT_TYPE
{
	IAP_REINIT_SIMULATION = 4,
	IAP_REINIT_BLOCK = 1,
	IAP_REINIT_CONVERGENCE = 2,
	IAP_REINIT_STREAM = 3
}
public enum HAPReportType
{
	HAP_REPORT_INTERACTIVE,
	HAP_REPORT_BLOCK,
	HAP_REPORT_CONVERGENCE,
	HAP_REPORT_COST,
	HAP_REPORT_ECONOMIC,
	HAP_REPORT_SENSITIVITY,
	HAP_REPORT_TRANSFER,
	HAP_REPORT_CALCULATOR,
	HAP_REPORT_UTILITY,
	HAP_REPORT_STREAMS,
	HAP_REPORT_BALANCE,
	HAP_REPORT_PRES_RELIEF,
	HAP_REPORT_REGRESSION,
	HAP_REPORT_REPORT,
	HAP_REPORT_TOC,
	HAP_REPORT_FLOWSHEET_BALANCE,
	HAP_REPORT_PROP_TABLE,
	HAP_REPORT_DESIGN_SPEC,
	HAP_REPORT_CONNECTING_STREAMS,
	HAP_REPORT_CONSTRAINT,
	HAP_REPORT_OPTIMIZATION
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct LARGE_INTEGER
{
	public long QuadPart;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct ULARGE_INTEGER
{
	public ulong QuadPart;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct STATSTG
{
	[MarshalAs(UnmanagedType.LPWStr)]
	public string pwcsName;

	public uint type;

	public ULARGE_INTEGER cbSize;

	public FILETIME mtime;

	public FILETIME ctime;

	public FILETIME atime;

	public uint grfMode;

	public uint grfLocksSupported;

	public Guid clsid;

	public uint grfStateBits;

	public uint reserved;
}
[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct FILETIME
{
	public uint dwLowDateTime;

	public uint dwHighDateTime;
}
[ComImport]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("8AD467D8-0C32-11D2-9B42-0000C07EE8F2")]
[TypeLibType(TypeLibTypeFlags.FOleAutomation | TypeLibTypeFlags.FRestricted)]
public interface IEnumAModelLibrary
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Next([In] uint uCount, [MarshalAs(UnmanagedType.IUnknown)] out object ppModel, out uint pnumFetched);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Skip([In] uint uCount);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Clone([MarshalAs(UnmanagedType.Interface)] out IEnumAModelLibrary ppEnum);
}
[ComImport]
[Guid("9DFBF9D8-A97F-404A-8BC8-ED73A8FFECC5")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAdsNodeCol
{
	[DispId(0)]
	IAdsNode this[[In][MarshalAs(UnmanagedType.Struct)] object loc_or_name, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name2, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name3, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name4, [Optional][In][MarshalAs(UnmanagedType.Struct)] object loc_or_name5]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
	}

	[DispId(1610743810)]
	object[] Values
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.SafeArray, SafeArraySubType = VarEnum.VT_VARIANT)]
		get;
	}
}
[ComImport]
[Guid("657E4330-ED8D-11D0-A991-0000C0237DF9")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IScrollAreaInfo
{
	[DispId(1610743808)]
	IHNode NodeAt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void GetMaximum([In][Out] ref int pRow, [In][Out] ref short pRowExt, [In][Out] ref int pCol, [In][Out] ref short pColExt);
}
[ComImport]
[Guid("EE89DDB7-133D-4657-A64A-4A36E3564C89")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IHPlotVal2 : IHPlotVal
{
	[DispId(1610743808)]
	new IHNode Context
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743810)]
	new string Title
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743811)]
	new string TitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743813)]
	new string XAxisTitle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743814)]
	new string XAxisTitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743816)]
	new string YAxisTitle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743817)]
	new string YAxisTitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743817)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743819)]
	new string Label
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743820)]
	new string LabelInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743822)]
	new int NPoints
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		[param: In]
		set;
	}

	[DispId(1610743824)]
	new int NVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[param: In]
		set;
	}

	[DispId(1610743826)]
	new int NXVariables
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[param: In]
		set;
	}

	[DispId(1610743828)]
	new double XDataValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743828)]
		get;
	}

	[DispId(1610743829)]
	new object XData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743829)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743830)]
	new double YDataValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		get;
	}

	[DispId(1610743831)]
	new object YData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743831)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	new void GetXData([In] int index, [In] int datano, out short attr, [MarshalAs(UnmanagedType.Struct)] out object Value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743833)]
	new void GetYData([In] int index, [In] int datano, out short attr, [MarshalAs(UnmanagedType.Struct)] out object Value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743834)]
	new void Clear();

	[DispId(1610743835)]
	new bool SwapAxises
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743835)]
		[param: In]
		set;
	}

	[DispId(1610743837)]
	new bool ReverseXAxis
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743837)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743837)]
		[param: In]
		set;
	}

	[DispId(1610743839)]
	new bool AddTimeStamp
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743839)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743839)]
		[param: In]
		set;
	}

	[DispId(1610743841)]
	new bool ShowLegend
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743841)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743841)]
		[param: In]
		set;
	}

	[DispId(1610743843)]
	new int PlotType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		[param: In]
		set;
	}

	[DispId(1610743845)]
	new bool Parametric
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743845)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743845)]
		[param: In]
		set;
	}

	[DispId(1610743847)]
	new string ZAxisTitle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743847)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743847)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743848)]
	new string ZAxisTitleInt
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743848)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743850)]
	new bool Live
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743850)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743850)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	new void AddAnnotationText([In] ref PLOTTEXT text);

	[DispId(1610743853)]
	new int AnnotationCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743853)]
		get;
	}

	[DispId(1610743854)]
	new PLOTTEXT AnnotationText
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743854)]
		get;
	}

	[DispId(1610743855)]
	new short GridType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743855)]
		[param: In]
		set;
	}

	[DispId(1610743857)]
	new short MarkerSize
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743857)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743857)]
		[param: In]
		set;
	}

	[DispId(1610743859)]
	new bool ShowDiagonalLine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743859)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743859)]
		[param: In]
		set;
	}

	[DispId(1610743861)]
	new short LineStyle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743861)]
		[param: In]
		set;
	}

	[DispId(1610743863)]
	new bool XDataInteger
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743863)]
		get;
	}

	[DispId(1610743864)]
	new bool ShowZeroLine
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		[param: In]
		set;
	}

	[DispId(1610743866)]
	new int AxisMap
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743866)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743866)]
		[param: In]
		set;
	}

	[DispId(1610743868)]
	new int CurveStyle
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743868)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743868)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743870)]
	new void RemoveAnnotationText();

	[DispId(1610743871)]
	new bool SquarePlot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743871)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743871)]
		[param: In]
		set;
	}

	[DispId(1610743873)]
	new bool CanLive
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743873)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743873)]
		[param: In]
		set;
	}

	[DispId(1610743875)]
	new int AxisScale
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743875)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743875)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809344)]
	short GetVarLineInfo(out short iColor, out short iLineType, out short iMarker, out short iSize);

	[DispId(1610809345)]
	short VarLineInfo
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809345)]
		[param: In]
		set;
	}

	[DispId(1610809346)]
	short LineColor
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809346)]
		[param: In]
		set;
	}

	[DispId(1610809348)]
	short LineType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809348)]
		[param: In]
		set;
	}

	[DispId(1610809350)]
	short MarkerType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809350)]
		[param: In]
		set;
	}

	[DispId(1610809352)]
	short MarkerSize_2
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610809352)]
		[param: In]
		set;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("D6FECDE0-BA92-11D1-9B3F-0000C07EE8F2")]
public interface IAPPDF
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void GetAPPDF([In][MarshalAs(UnmanagedType.BStr)] string filename, [In] int flags);
}
[ComImport]
[Guid("0B61E982-00B4-4308-994E-66C15D8F5CAC")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPropData
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void GetAvailableDatabanks(out int plNumDatabanks, [MarshalAs(UnmanagedType.Struct)] out object pvtDatabankArray);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void GetDefaultDatabanks(out int plNumDatabanks, [MarshalAs(UnmanagedType.Struct)] out object pvtDatabankArray);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void SetQueryForComponents([In][MarshalAs(UnmanagedType.Struct)] object vtDatabanksArray, [In][MarshalAs(UnmanagedType.BStr)] string bstrMatchNameAlias, [In] int bMatchAlternate, [In] int bMatchStringBeginOnly, [In][MarshalAs(UnmanagedType.BStr)] string bstrCompClass, [In][MarshalAs(UnmanagedType.BStr)] string bstrCASRN, [In] double dblMWfrom, [In] double dblMWto, [In] double dblBPfrom, [In] double dblBPto, [In][MarshalAs(UnmanagedType.BStr)] string bstrBPUnit);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void FetchNextComponent([In] int bInit, [MarshalAs(UnmanagedType.BStr)] out string bstrAlias, [MarshalAs(UnmanagedType.BStr)] out string bstrName, out double dblBP, out double dblMW, [MarshalAs(UnmanagedType.BStr)] out string bstrDatabank, [MarshalAs(UnmanagedType.BStr)] out string bstrCASRN, [MarshalAs(UnmanagedType.BStr)] out string bstrCompClass, [MarshalAs(UnmanagedType.BStr)] out string bstrSynonym);
}
[ComImport]
[Guid("681C2534-74A1-4094-9939-73276031FCB4")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPPasteItems : IEnumerable
{
	[DispId(0)]
	IAPPasteItem this[[In][MarshalAs(UnmanagedType.Struct)] object index]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743810)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("681C2533-74A1-4094-9939-73276031FCB4")]
public interface IAPPasteItem
{
	[DispId(1610743808)]
	string displayname
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743809)]
	string ID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743811)]
	bool Deleted
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		set;
	}

	[DispId(1610743813)]
	int PathLen
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
	}

	[DispId(1610743814)]
	string path
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743815)]
	bool HasChildren
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		get;
	}

	[DispId(1610743816)]
	IAPPasteItems Items
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}
}
public enum HAPP_RECONCILE_CODE
{
	HAPP_RECONCILE_INPUT = 1,
	HAPP_RECONCILE_ONLY = 2,
	HAPP_RECONCILE_TP = 4,
	HAPP_RECONCILE_TV = 8,
	HAPP_RECONCILE_PV = 16,
	HAPP_RECONCILE_CF = 32,
	HAPP_RECONCILE_TF = 64,
	HAPP_RECONCILE_MICFMOLE = 128,
	HAPP_RECONCILE_MICFMASS = 256,
	HAPP_RECONCILE_MICFSTDVOL = 512,
	HAPP_RECONCILE_MITFMOLE = 1024,
	HAPP_RECONCILE_MITFMASS = 2048,
	HAPP_RECONCILE_MITFSTDVOL = 4096,
	HAPP_RECONCILE_CICFMOLE = 16384,
	HAPP_RECONCILE_CICFMASS = 32768,
	HAPP_RECONCILE_CITFMOLE = 65536,
	HAPP_RECONCILE_CITFMASS = 131072,
	HAPP_RECONCILE_QUIET = 1048576,
	HAPP_RECONCILE_DONTASKWARN = 2097152,
	HAPP_RECONCILE_ONLYSTREAMS = 16777216,
	HAPP_RECONCILE_NOSTREAMS = 33554432,
	HAPP_RECONCILE_TEARSTREAMS = 67108864,
	HAPP_RECONCILE_FEEDSTREAMS = 4194304
}
public enum HAPP_ENABLE_CODE
{
	HAPP_ENABLE_DEACTIVATE,
	HAPP_ENABLE_ACTIVATE,
	HAPP_ENABLE_NOT_APPLICABLE
}
public enum SIM_CONTAINER_EVENT
{
	SIM_EVENT_OBJECT_SOLVING = 1000,
	SIM_EVENT_OBJECT_DELETED,
	SIM_EVENT_SHOWDATABROWSER,
	SIM_EVENT_UPDATE_BROWSER,
	SIM_EVENT_UPDATE_STATUS,
	SIM_EVENT_REFRESH,
	SIM_SET_SEQUENCE,
	SIM_EVENT_WAIT_CURSOR,
	SIM_EVENT_CONNECTING,
	SIM_EVENT_STOPPOINT,
	SIM_EVENT_REMOVE_STOPPOINT,
	SIM_EVENT_REMOVEALL_STOPPOINT,
	SIM_EVENT_CLOSE,
	SIM_EVENT_VISIBLE,
	SIM_EVENT_AUTOMATION_OPEN,
	SIM_EVENT_SAVED,
	SIM_EVENT_SHOW_ITEM,
	SIM_EVENT_QUIT,
	SIM_START_PSV_ACTION,
	SIM_EVENT_PSV_ERROR_STATUS,
	SIM_EVENT_TRACKITEM,
	SIM_EVENT_STREAM_PROPERTY_CHANGE,
	SIM_EVENT_SHOWSTREAMPLOT,
	SIM_EVENT_ENTER_SAFETY
}
[ComImport]
[Guid("F66C0817-DA74-4D72-A4AD-60FB6895701F")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IHNode2 : IHNode
{
	[DispId(1610743808)]
	new IHapp Application
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	new IHapp Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	new string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743812)]
	new int Dimension
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610743813)]
	new short ValueType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
	}

	[DispId(1610743814)]
	new object Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	new void SetValueAndUnit([In][MarshalAs(UnmanagedType.Struct)] object Value, [In] short unitcol, [Optional][In][MarshalAs(UnmanagedType.Struct)] object force);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	new void SetValueUnitAndBasis([In][MarshalAs(UnmanagedType.Struct)] object Value, [In] short unitcol, [In][MarshalAs(UnmanagedType.BStr)] string basis, [Optional][In][MarshalAs(UnmanagedType.Struct)] object force);

	[DispId(1610743818)]
	new bool HasAttribute
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		get;
	}

	[DispId(1610743819)]
	new short AttributeType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743819)]
		get;
	}

	[DispId(1610743820)]
	new object AttributeValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743822)]
	new bool HasClassAttribute
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		get;
	}

	[DispId(1610743823)]
	new short ClassAttributeType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743823)]
		get;
	}

	[DispId(1610743824)]
	new object ClassAttributeValue
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[DispId(1610743826)]
	new IHNodeCol Elements
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743827)]
	new int Process
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
		[DispId(1610743827)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	new void Delete();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743829)]
	new void RemoveAll();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743830)]
	new void AddClassAttribute([In][MarshalAs(UnmanagedType.BStr)] string classid, [In] short type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743831)]
	new void DeleteClassAttribute([In][MarshalAs(UnmanagedType.BStr)] string classid);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743832)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	new void Copy();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743833)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	new void CopyWithFormat();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743834)]
	new void PrintUseful([In] short append, [In][MarshalAs(UnmanagedType.BStr)] string filename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743835)]
	[return: MarshalAs(UnmanagedType.Interface)]
	new IHNode FindNode([In][MarshalAs(UnmanagedType.BStr)] string path);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743836)]
	new bool Paste();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743837)]
	new bool PasteSpecial();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743838)]
	new bool IsLinked();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743839)]
	new void RemoveLink();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	[return: MarshalAs(UnmanagedType.BStr)]
	new string NextIncomplete([Optional][MarshalAs(UnmanagedType.Struct)] out object code);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743841)]
	[return: MarshalAs(UnmanagedType.BStr)]
	new string BrowseNext([In] short direction, [In] short io);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	new void Dummy([In] HAPAttributeNumber __MIDL__IHNode0000, [In] HAPCompStatusCode __MIDL__IHNode0001);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743843)]
	new void Hide([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743844)]
	new void Reveal([In][MarshalAs(UnmanagedType.BStr)] string Name = "");

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743845)]
	new void Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743846)]
	new void NotifyRunStep();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743847)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	new void HoldNotifies([In] bool hold);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743848)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	new bool IsValid();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743849)]
	new void NewChild([In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743850)]
	new void RenameChild([In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	[DispId(1610743851)]
	new bool IsSpecialType([In] HAPSpecialNodeType type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	new void Reaquire();

	[DispId(1610743853)]
	new string UnitString
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743853)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743854)]
	new object ValueForUnit
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743854)]
		[return: MarshalAs(UnmanagedType.Struct)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743855)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	new void PFSSelectModel();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743856)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	new void PFSClearSelection();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743857)]
	new void Reconcile([In] int code);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743858)]
	new void NewID([In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743859)]
	new void Export([In][MarshalAs(UnmanagedType.BStr)] string filename = "");

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743860)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	new short DoObjectVerb([In] int oleverb);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743861)]
	[TypeLibFunc(TypeLibFuncFlags.FRestricted)]
	new void AppendTemplate([In][MarshalAs(UnmanagedType.IUnknown)] object pUnkTempl, [Optional][In][MarshalAs(UnmanagedType.Struct)] object flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743862)]
	[TypeLibFunc(TypeLibFuncFlags.FHidden)]
	new void Import([In][MarshalAs(UnmanagedType.BStr)] string filename = "");

	[DispId(1610743863)]
	new bool RefreshOff
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743863)]
		[TypeLibFunc(TypeLibFuncFlags.FHidden)]
		[param: In]
		set;
	}

	[DispId(1610743864)]
	new IAdsNode SharedData
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743864)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610809344)]
	void Clear2([In] int code);
}
[TypeLibType(TypeLibTypeFlags.FHidden)]
public enum HASELTYPE
{
	HASEL_UNDEFINED = -1,
	HASEL_CHNODE = 0,
	HASEL_SELECTION = 1,
	HASEL_LABEL = 2,
	HASEL_LABELNODE = 3,
	HASEL_VOLATILECHNODE = 4,
	HASEL_HEADERLABEL = 90,
	HASEL_LBTU_UNITS = 96,
	HASEL_LBTU_BASIS = 97,
	HASEL_LBTU_UNITS_BASIS = 98,
	HASEL_UNDERLYINGNODE = 99,
	HASEL_SELECT_INDIRECT = 100
}
[ComImport]
[Guid("3E9D8E11-DBF3-4A5E-8922-5D9A7A4A6EBD")]
[TypeLibType(TypeLibTypeFlags.FHidden)]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IHSelectionCallback
{
	[DispId(1610678272)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void LoadSelection([In][MarshalAs(UnmanagedType.Interface)] IHSelection arg1);

	[DispId(1610678274)]
	int EditsAllowed
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}
}
[ComImport]
[Guid("F9688B90-65A9-11D1-8A9D-0000C0237DF9")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IMMControlVerb
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void EnumVerbs([In][Out][MarshalAs(UnmanagedType.Struct)] ref object pEnumOleVerb);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void DoVerb([In] int iVerb);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("F98A1533-D1C7-4222-903C-87E3D47589AA")]
public interface IHappServiceProvider
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	[return: MarshalAs(UnmanagedType.IUnknown)]
	object GetService([In][MarshalAs(UnmanagedType.BStr)] string bService);
}
public enum IAP_CONFLICT_OPTION
{
	IAP_CONF_UNKNOWN = -1,
	IAP_CONF_NOACTION = 0,
	IAP_CONF_REPLACE = 2,
	IAP_CONF_MERGE = 3,
	IAP_CONF_HIDE = 4
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("681C2530-74A1-4094-9939-73276031FCB4")]
public interface IAPConflict
{
	[DispId(1610743808)]
	string displayname
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743809)]
	string ID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743811)]
	bool Merge
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		set;
	}

	[DispId(1610743813)]
	IAP_CONFLICT_OPTION Action
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		[param: In]
		set;
	}
}
[ComImport]
[DefaultMember("Item")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("681C2531-74A1-4094-9939-73276031FCB4")]
public interface IAPConflicts : IEnumerable
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(0)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IAPConflict Item([In][MarshalAs(UnmanagedType.Struct)] object index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void Clear();

	[DispId(1610743811)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		get;
	}
}
[ComImport]
[Guid("681C2532-74A1-4094-9939-73276031FCB4")]
[DefaultMember("Item")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPGroup : IEnumerable
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void Add([In][MarshalAs(UnmanagedType.Struct)] object Item);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void Remove([In][MarshalAs(UnmanagedType.Struct)] object Item);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(0)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object Item([In][MarshalAs(UnmanagedType.Struct)] object index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743813)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743813)]
		get;
	}

	[DispId(1610743814)]
	object DataObject
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.IUnknown)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void Export([In][MarshalAs(UnmanagedType.BStr)] string filename = "");

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	void CopyToClipboard();
}
[ComImport]
[Guid("681C2535-74A1-4094-9939-73276031FCB4")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPPasteParam
{
	[DispId(1610743808)]
	string ID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743809)]
	string Label
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(1610743811)]
	string Value
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}
}
[ComImport]
[Guid("681C2536-74A1-4094-9939-73276031FCB4")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPPasteParams : IEnumerable
{
	[DispId(0)]
	IAPPasteParam this[[In][MarshalAs(UnmanagedType.Struct)] object index]
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(0)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-4)]
	[return: MarshalAs(UnmanagedType.CustomMarshaler, MarshalType = "System.Runtime.InteropServices.CustomMarshalers.EnumeratorToEnumVariantMarshaler, CustomMarshalers, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
	new IEnumerator GetEnumerator();

	[DispId(1610743810)]
	int Count
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}
}
[ComImport]
[Guid("681C2537-74A1-4094-9939-73276031FCB4")]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
public interface IAPPasteBuffer
{
	[DispId(1610743808)]
	IAPPasteItems Items
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743809)]
	IAPPasteParams Params
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743810)]
	IAPConflicts Conflicts
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[DispId(1610743811)]
	object Context
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743811)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Struct)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void Import([In][MarshalAs(UnmanagedType.BStr)] string filename = "");

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void Export([In][MarshalAs(UnmanagedType.BStr)] string filename = "");

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void Commit([Optional][In][MarshalAs(UnmanagedType.Struct)] object force, [Optional][In][MarshalAs(UnmanagedType.Struct)] object errorLog);
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDual | TypeLibTypeFlags.FDispatchable)]
[Guid("D5DFF720-922A-40BD-8A2C-229913792D9C")]
public interface IHNodeSelection
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	[return: MarshalAs(UnmanagedType.Interface)]
	IHSelection Select([In][MarshalAs(UnmanagedType.BStr)] string nodePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object SelectNodes([In][MarshalAs(UnmanagedType.BStr)] string nodePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object SelectValues([In][MarshalAs(UnmanagedType.BStr)] string nodePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object SelectAttributes([In][MarshalAs(UnmanagedType.BStr)] string nodePath, [In][MarshalAs(UnmanagedType.Struct)] object attributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object SelectLabelAttributes([In][MarshalAs(UnmanagedType.BStr)] string nodePath, [In] int Dimension, [In][MarshalAs(UnmanagedType.Struct)] object attributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object SelectSingleNodeAttributes([In][MarshalAs(UnmanagedType.BStr)] string nodePath, [In][MarshalAs(UnmanagedType.Struct)] object attributes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object SelectAttributesOnNodes([In][MarshalAs(UnmanagedType.Struct)] object nodePathArray, [In][MarshalAs(UnmanagedType.Struct)] object attributes);
}
[ComImport]
[Guid("35F04526-F10A-4D0D-9C6D-193E8CCD3A5F")]
[TypeLibType(TypeLibTypeFlags.FOleAutomation | TypeLibTypeFlags.FDispatchable)]
public interface IHappConnectInfo
{
	[DispId(1610743808)]
	string Version
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743809)]
	string filename
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743810)]
	string RunID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743811)]
	string ClientDirectory
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743812)]
	bool IsRemote
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	[DispId(1610743813)]
	string username
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743814)]
	string Server
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(1610743815)]
	string ServerDirectory
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}
}
[ComImport]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("35DD0090-488A-11D0-A90E-0000C0A118DB")]
[ComConversionLoss]
[TypeLibType(TypeLibTypeFlags.FOleAutomation)]
public interface IHWinApp
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetVisible(ref int pbVisible);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetVisible(int bVisible);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetDefaultDir(IntPtr pDefDir);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkInitNew(int bAutomation);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkOpenFile(ref sbyte fn, int bAutomation);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkRestoreFile(ref sbyte fn, int bAutomation, int openType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkSaveFile(ref sbyte fn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void AutoSave();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkClose();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void DeleteCompoundFileDirectory();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkRefreshForms(int lFlags, ref sbyte szcHint);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetActiveDocStorage(ref IntPtr pStg);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetFrameworkUsingApt(ref int pbUsingApt);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetFrameworkUsingApt(int bUsingApt);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetSimpanelVisible(ref int retval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetSimpanelVisible(int bShow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetRunControlVisible(ref int retval);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetRunControlVisible(int bShow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetPlotList(IntPtr plots);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void DriveNewDialog(IntPtr pHnode, [MarshalAs(UnmanagedType.BStr)] ref string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void DriveRenameDialog(IntPtr pHnode, [MarshalAs(UnmanagedType.BStr)] ref string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void DriveReorderDialog(IntPtr pHnode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void DriveNewIDDialog(IntPtr pHnode, [MarshalAs(UnmanagedType.BStr)] ref string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Activate();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkHappNotify(ushort cNotifyFlag, IntPtr pObject);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetEmbedding(ref sbyte Name, [MarshalAs(UnmanagedType.IUnknown)] ref object ppobj);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkLinkSourceDataChange(int bAdd, IntPtr pLinkSource);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkLinkContainerDataChange(IntPtr pLinkContainer);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void PFSSelectModel([MarshalAs(UnmanagedType.IUnknown)] object pUnk);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void PFSClearSelection();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkDoObjectVerb(int oleverb, [MarshalAs(UnmanagedType.IUnknown)] object pObj);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ExportDocument(ref sbyte szcFilename, int nFiletype);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ImportDocument(ref sbyte szcFilename);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void DisableMenuItem(ref sbyte szcItem);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void get_MainHWnd([ComAliasName("AspenTech.AspenPlus.Happ.wireHWND")] IntPtr lphWnd);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void get_ProcessHandle(ref IntPtr lphproc);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void get_RealCLSID_Happ(ref Guid clsid);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void DoEvents();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void UpdateIdleStatus();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void EditCompoundDocument([MarshalAs(UnmanagedType.BStr)] string fn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FrameworkExit();
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
[ComConversionLoss]
public struct SAFEARRAY
{
	public ushort cDims;

	public ushort fFeatures;

	public uint cbElements;

	public uint cLocks;

	public IntPtr pvData;

	[ComConversionLoss]
	public IntPtr rgsabound;
}
[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct RemotableHandle
{
	public int fContext;

	public __MIDL_IWinTypes_0009 u;
}
[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct SAFEARRAYBOUND
{
	public uint cElements;

	public int lLbound;
}
[StructLayout(LayoutKind.Explicit, Pack = 4, Size = 4)]
public struct __MIDL_IWinTypes_0009
{
	[FieldOffset(0)]
	public int hInproc;

	[FieldOffset(0)]
	public int hRemote;
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FOleAutomation)]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("A6C7BBA9-6496-45C3-8C2E-88C43C87CA2B")]
public interface IHSimContainer64
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SerializeAllViews([MarshalAs(UnmanagedType.Interface)] IStorage pStg, int bLoad);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ShowSimView(int bShow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OnMessage(uint msg, ulong wparam, ulong lParam, out long result);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetEventDelegate([MarshalAs(UnmanagedType.IUnknown)] object pEventDelegate);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void DocumentClosed();
}
[ComImport]
[Guid("0000000B-0000-0000-C000-000000000046")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IStorage
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CreateStream([In][MarshalAs(UnmanagedType.LPWStr)] string pwcsName, [In] uint grfMode, [In] uint reserved1, [In] uint reserved2, [MarshalAs(UnmanagedType.Interface)] out IStream ppstm);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteOpenStream([In][MarshalAs(UnmanagedType.LPWStr)] string pwcsName, [In] uint cbReserved1, [In] ref byte reserved1, [In] uint grfMode, [In] uint reserved2, [MarshalAs(UnmanagedType.Interface)] out IStream ppstm);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void CreateStorage([In][MarshalAs(UnmanagedType.LPWStr)] string pwcsName, [In] uint grfMode, [In] uint reserved1, [In] uint reserved2, [MarshalAs(UnmanagedType.Interface)] out IStorage ppstg);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void OpenStorage([In][MarshalAs(UnmanagedType.LPWStr)] string pwcsName, [In][MarshalAs(UnmanagedType.Interface)] IStorage pstgPriority, [In] uint grfMode, [In][ComAliasName("AspenTech.AspenPlus.Happ.wireSNB")] ref RemSNB snbExclude, [In] uint reserved, [MarshalAs(UnmanagedType.Interface)] out IStorage ppstg);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteCopyTo([In] uint ciidExclude, [In] ref Guid rgiidExclude, [In][ComAliasName("AspenTech.AspenPlus.Happ.wireSNB")] ref RemSNB snbExclude, [In][MarshalAs(UnmanagedType.Interface)] IStorage pstgDest);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void MoveElementTo([In][MarshalAs(UnmanagedType.LPWStr)] string pwcsName, [In][MarshalAs(UnmanagedType.Interface)] IStorage pstgDest, [In][MarshalAs(UnmanagedType.LPWStr)] string pwcsNewName, [In] uint grfFlags);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Commit([In] uint grfCommitFlags);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Revert();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteEnumElements([In] uint reserved1, [In] uint cbReserved2, [In] ref byte reserved2, [In] uint reserved3, [MarshalAs(UnmanagedType.Interface)] out IEnumSTATSTG ppEnum);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void DestroyElement([In][MarshalAs(UnmanagedType.LPWStr)] string pwcsName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RenameElement([In][MarshalAs(UnmanagedType.LPWStr)] string pwcsOldName, [In][MarshalAs(UnmanagedType.LPWStr)] string pwcsNewName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetElementTimes([In][MarshalAs(UnmanagedType.LPWStr)] string pwcsName, [In] ref FILETIME pctime, [In] ref FILETIME patime, [In] ref FILETIME pmtime);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetClass([In] ref Guid clsid);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetStateBits([In] uint grfStateBits, [In] uint grfMask);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Stat(out STATSTG pstatstg, [In] uint grfStatFlag);
}
[StructLayout(LayoutKind.Sequential, Pack = 4)]
[ComConversionLoss]
public struct RemSNB
{
	public uint ulCntStr;

	public uint ulCntChar;

	[ComConversionLoss]
	public IntPtr rgString;
}
[ComImport]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[Guid("0000000D-0000-0000-C000-000000000046")]
public interface IEnumSTATSTG
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteNext([In] uint celt, out STATSTG rgelt, out uint pceltFetched);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Skip([In] uint celt);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Clone([MarshalAs(UnmanagedType.Interface)] out IEnumSTATSTG ppEnum);
}
[ComImport]
[Guid("0068A3B4-DCAA-4A11-ADD1-D5FF7D837306")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
[TypeLibType(TypeLibTypeFlags.FOleAutomation)]
public interface IHSafety
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void EnterSafetyEnvironment();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RunAllLineSizing();
}
[TypeLibType(TypeLibTypeFlags.FHidden)]
[ClassInterface(ClassInterfaceType.None)]
public sealed class IAPHappEvents_SinkHelper : IAPHappEvents
{
	public IAPHappEvents_OnDialogSuppressedEventHandler m_OnDialogSuppressedDelegate;

	public IAPHappEvents_OnControlPanelMessageEventHandler m_OnControlPanelMessageDelegate;

	public IAPHappEvents_OnGUIClosingEventHandler m_OnGUIClosingDelegate;

	public IAPHappEvents_OnInClosingEventHandler m_OnInClosingDelegate;

	public IAPHappEvents_OnDataChangedEventHandler m_OnDataChangedDelegate;

	public IAPHappEvents_OnUpdateMessageEventHandler m_OnUpdateMessageDelegate;

	public IAPHappEvents_OnEngineCommandCompletedEventHandler m_OnEngineCommandCompletedDelegate;

	public IAPHappEvents_OnBeforeCalculateEventHandler m_OnBeforeCalculateDelegate;

	public IAPHappEvents_OnBeforeSaveEventHandler m_OnBeforeSaveDelegate;

	public IAPHappEvents_OnCalculationCompletedEventHandler m_OnCalculationCompletedDelegate;

	public IAPHappEvents_OnCalculationStoppedEventHandler m_OnCalculationStoppedDelegate;

	public IAPHappEvents_OnGUIClosedEventHandler m_OnGUIClosedDelegate;

	public IAPHappEvents_OnDocumentClosingEventHandler m_OnDocumentClosingDelegate;

	public int m_dwCookie;

	public void OnDialogSuppressed(string P_0, string P_1)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnDialogSuppressedDelegate != null)
		{
			m_OnDialogSuppressedDelegate(P_0, P_1);
		}
	}

	public void OnControlPanelMessage(int P_0, string P_1)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnControlPanelMessageDelegate != null)
		{
			m_OnControlPanelMessageDelegate(P_0, P_1);
		}
	}

	public void OnGUIClosing()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnGUIClosingDelegate != null)
		{
			m_OnGUIClosingDelegate();
		}
	}

	public void OnInClosing(int P_0, string P_1)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnInClosingDelegate != null)
		{
			m_OnInClosingDelegate(P_0, P_1);
		}
	}

	public void OnDataChanged(object P_0)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnDataChangedDelegate != null)
		{
			m_OnDataChangedDelegate(P_0);
		}
	}

	public void OnUpdateMessage(int P_0, string P_1, object P_2, int P_3)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnUpdateMessageDelegate != null)
		{
			m_OnUpdateMessageDelegate(P_0, P_1, P_2, P_3);
		}
	}

	public void OnEngineCommandCompleted()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnEngineCommandCompletedDelegate != null)
		{
			m_OnEngineCommandCompletedDelegate();
		}
	}

	public void OnBeforeCalculate(bool P_0, ref bool P_1)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnBeforeCalculateDelegate != null)
		{
			m_OnBeforeCalculateDelegate(P_0, ref P_1);
		}
	}

	public void OnBeforeSave(string P_0, ref bool P_1)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnBeforeSaveDelegate != null)
		{
			m_OnBeforeSaveDelegate(P_0, ref P_1);
		}
	}

	public void OnCalculationCompleted()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnCalculationCompletedDelegate != null)
		{
			m_OnCalculationCompletedDelegate();
		}
	}

	public void OnCalculationStopped()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnCalculationStoppedDelegate != null)
		{
			m_OnCalculationStoppedDelegate();
		}
	}

	public void OnGUIClosed()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnGUIClosedDelegate != null)
		{
			m_OnGUIClosedDelegate();
		}
	}

	public void OnDocumentClosing()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_OnDocumentClosingDelegate != null)
		{
			m_OnDocumentClosingDelegate();
		}
	}

	internal IAPHappEvents_SinkHelper()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		m_dwCookie = 0;
		m_OnDialogSuppressedDelegate = null;
		m_OnControlPanelMessageDelegate = null;
		m_OnGUIClosingDelegate = null;
		m_OnInClosingDelegate = null;
		m_OnDataChangedDelegate = null;
		m_OnUpdateMessageDelegate = null;
		m_OnEngineCommandCompletedDelegate = null;
		m_OnBeforeCalculateDelegate = null;
		m_OnBeforeSaveDelegate = null;
		m_OnCalculationCompletedDelegate = null;
		m_OnCalculationStoppedDelegate = null;
		m_OnGUIClosedDelegate = null;
		m_OnDocumentClosingDelegate = null;
	}
}
internal sealed class IAPHappEvents_EventProvider : IDisposable
{
	private WeakReference m_wkConnectionPointContainer;

	private ArrayList m_aEventSinkHelpers;

	private IConnectionPoint m_ConnectionPoint;

	private void Init()
	{
		IConnectionPoint ppCP = null;
		byte[] guidBytes = new byte[16];
guidBytes[0] = 50;
guidBytes[1] = 214;
guidBytes[2] = 63;
guidBytes[3] = 80;
guidBytes[4] = 62;
guidBytes[5] = 246;
guidBytes[6] = 209;
guidBytes[7] = 17;
guidBytes[8] = 141;
guidBytes[9] = 62;
guidBytes[10] = 0;
guidBytes[11] = 0;
guidBytes[12] = 192;
guidBytes[13] = 51;
guidBytes[14] = 234;
guidBytes[15] = 242;
Guid riid = new Guid(guidBytes);
		((IConnectionPointContainer)m_wkConnectionPointContainer.Target).FindConnectionPoint(ref riid, out ppCP);
		m_ConnectionPoint = ppCP;
		m_aEventSinkHelpers = new ArrayList();
	}

	public void add_OnDialogSuppressed(IAPHappEvents_OnDialogSuppressedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnDialogSuppressedDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnDialogSuppressed(IAPHappEvents_OnDialogSuppressedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnDialogSuppressedDelegate != null && ((iAPHappEvents_SinkHelper.m_OnDialogSuppressedDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnControlPanelMessage(IAPHappEvents_OnControlPanelMessageEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnControlPanelMessageDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnControlPanelMessage(IAPHappEvents_OnControlPanelMessageEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnControlPanelMessageDelegate != null && ((iAPHappEvents_SinkHelper.m_OnControlPanelMessageDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnGUIClosing(IAPHappEvents_OnGUIClosingEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnGUIClosingDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnGUIClosing(IAPHappEvents_OnGUIClosingEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnGUIClosingDelegate != null && ((iAPHappEvents_SinkHelper.m_OnGUIClosingDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnInClosing(IAPHappEvents_OnInClosingEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnInClosingDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnInClosing(IAPHappEvents_OnInClosingEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnInClosingDelegate != null && ((iAPHappEvents_SinkHelper.m_OnInClosingDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnDataChanged(IAPHappEvents_OnDataChangedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnDataChangedDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnDataChanged(IAPHappEvents_OnDataChangedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnDataChangedDelegate != null && ((iAPHappEvents_SinkHelper.m_OnDataChangedDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnUpdateMessage(IAPHappEvents_OnUpdateMessageEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnUpdateMessageDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnUpdateMessage(IAPHappEvents_OnUpdateMessageEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnUpdateMessageDelegate != null && ((iAPHappEvents_SinkHelper.m_OnUpdateMessageDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnEngineCommandCompleted(IAPHappEvents_OnEngineCommandCompletedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnEngineCommandCompletedDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnEngineCommandCompleted(IAPHappEvents_OnEngineCommandCompletedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnEngineCommandCompletedDelegate != null && ((iAPHappEvents_SinkHelper.m_OnEngineCommandCompletedDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnBeforeCalculate(IAPHappEvents_OnBeforeCalculateEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnBeforeCalculateDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnBeforeCalculate(IAPHappEvents_OnBeforeCalculateEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnBeforeCalculateDelegate != null && ((iAPHappEvents_SinkHelper.m_OnBeforeCalculateDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnBeforeSave(IAPHappEvents_OnBeforeSaveEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnBeforeSaveDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnBeforeSave(IAPHappEvents_OnBeforeSaveEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnBeforeSaveDelegate != null && ((iAPHappEvents_SinkHelper.m_OnBeforeSaveDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnCalculationCompleted(IAPHappEvents_OnCalculationCompletedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnCalculationCompletedDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnCalculationCompleted(IAPHappEvents_OnCalculationCompletedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnCalculationCompletedDelegate != null && ((iAPHappEvents_SinkHelper.m_OnCalculationCompletedDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnCalculationStopped(IAPHappEvents_OnCalculationStoppedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnCalculationStoppedDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnCalculationStopped(IAPHappEvents_OnCalculationStoppedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnCalculationStoppedDelegate != null && ((iAPHappEvents_SinkHelper.m_OnCalculationStoppedDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnGUIClosed(IAPHappEvents_OnGUIClosedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnGUIClosedDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnGUIClosed(IAPHappEvents_OnGUIClosedEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnGUIClosedDelegate != null && ((iAPHappEvents_SinkHelper.m_OnGUIClosedDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_OnDocumentClosing(IAPHappEvents_OnDocumentClosingEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = new IAPHappEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(iAPHappEvents_SinkHelper, out pdwCookie);
			iAPHappEvents_SinkHelper.m_dwCookie = pdwCookie;
			iAPHappEvents_SinkHelper.m_OnDocumentClosingDelegate = P_0;
			m_aEventSinkHelpers.Add(iAPHappEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_OnDocumentClosing(IAPHappEvents_OnDocumentClosingEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (iAPHappEvents_SinkHelper.m_OnDocumentClosingDelegate != null && ((iAPHappEvents_SinkHelper.m_OnDocumentClosingDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public IAPHappEvents_EventProvider(object P_0)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		m_wkConnectionPointContainer = new WeakReference((IConnectionPointContainer)P_0, trackResurrection: false);
	}

	public void Finalize()
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
				do
				{
					IAPHappEvents_SinkHelper iAPHappEvents_SinkHelper = (IAPHappEvents_SinkHelper)m_aEventSinkHelpers[num];
					m_ConnectionPoint.Unadvise(iAPHappEvents_SinkHelper.m_dwCookie);
					num++;
				}
				while (num < count);
			}
			Marshal.ReleaseComObject(m_ConnectionPoint);
			}
		}
		catch (Exception)
		{
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void Dispose()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		Finalize();
		GC.SuppressFinalize(this);
	}
}
