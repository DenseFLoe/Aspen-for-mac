# 第三方代码与许可证

| 成员或依赖 | 版本 | 许可证原文 | 来源 |
| --- | --- | --- | --- |
| `tools/pefile.py`、`tools/ordlookup/*.py` | pefile 2024.8.26 | [MIT](licenses/pefile.LICENSE) | [pefile 上游固定版本 v2024.8.26](https://github.com/erocarrera/pefile/tree/v2024.8.26) |
| 构建参数 `--cecil` 引用的 `Mono.Cecil.dll` | Mono.Cecil 0.11.6，程序集 0.11.6.0，`lib/netstandard2.0` | [MIT](licenses/Mono.Cecil.LICENSE) | [NuGet 0.11.6](https://www.nuget.org/packages/Mono.Cecil/0.11.6) · [Cecil 上游固定版本 0.11.6](https://github.com/jbevain/cecil/tree/0.11.6) |

pefile 与 ordlookup 文本取自上游固定版本，`pefile.py` SHA-256 为 `0d0eb68f0f169182613dc64b3ab50b20855508c1c1d2faafe8fccf23edb6a345`。逐文件指纹列于 `SHA256SUMS.json`。pefile 上游 `LICENSE` 与 Cecil 上游 `LICENSE.txt` 按原始字节收入 `licenses/`。

Mono.Cecil 用于构建和运行源码版 OperandDump，以及可选的静态证据脚本。ZIP 只包含许可证原文。构建要求从官方 NuGet 包提取的上述 DLL，SHA-256 为 `831dca77470d85cb6ffbea3072daa7a3df5b7c9fcfd9c3f43674a9be99d4bfcf`。本包的第一方辅助工具以源码形式交付。
