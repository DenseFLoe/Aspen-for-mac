# source.il

安装原件 SHA-256 c839a5f398b42f8449c065fe088e2492eade05ae50dabe5100fdf073ec653fde。从原件重新导出并逐行核对 1,585 行。源码包含所有 COM 类型、字段及声明、属性和引用。
