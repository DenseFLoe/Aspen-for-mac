"""Generate layout recipe for one item, replay it, compare byte-for-byte.

Usage: replay_item.py <sha8>
Reads  <work>/<sha8>/out/<name>  (compiled candidate)
       original at ledger installed_location (read-only)
Writes <work>/<sha8>/recipe.json, recipe-report.json, assets under <work>/<sha8>/assets/,
       <work>/<sha8>/exact/<name>
"""
import json, sys, hashlib
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
HOME = BASE / "managed-byte-recovery"
FIN = BASE / "router" / "work" / "finisher-2"
sys.path.insert(0, str(BASE)); sys.path.insert(0, str(HOME)); sys.path.insert(0, str(FIN))
sys.path.insert(0, str(BASE / "router" / "managed"))
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")

import make_recipe_layout as make_recipe
import token_replay

WORK = Path(__file__).resolve().parent.parent
LEDGER = {}
for line in open(BASE / "per-file.jsonl", encoding="utf-8"):
    r = json.loads(line)
    LEDGER[r["sha256"]] = r

def row(sha8):
    for sha, r in LEDGER.items():
        if sha.startswith(sha8):
            return sha, r
    raise SystemExit("no ledger row " + sha8)

def run(sha8):
    sha, r = row(sha8)
    d = WORK / sha8
    orig = Path(r["installed_location"]).read_bytes()
    cand_path = d / "out" / r["name"]
    cand = cand_path.read_bytes()
    print("orig", hashlib.sha256(orig).hexdigest(), len(orig))
    print("cand", hashlib.sha256(cand).hexdigest(), len(cand))
    recipe, assets, report = make_recipe.generate(orig, cand, r["name"])
    print("status", recipe["replay_status"], "matched", recipe["methods_matched"], "/", recipe["methods_total"])
    print("gaps", report["gap_kinds"], len(report["gaps"]))
    (d / "recipe.json").write_text(json.dumps(recipe, ensure_ascii=False, indent=1), encoding="utf-8")
    (d / "recipe-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    adir = d / "assets"; adir.mkdir(exist_ok=True)
    for k, v in assets.items():
        p = adir / k.replace("/", "__")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(v)
    if recipe["replay_status"] != "ready":
        print("REPLAY SKIPPED (recipe blocked)")
        return 2
    data = token_replay.reproduce(cand, recipe, assets["original-build/clr-metadata.bin"],
                                  assets["original-build/debug-record.bin"],
                                  assets["original-build/certificate-table.bin"],
                                  assets["original-build/strong-name.bin"] if recipe["strong_name"] else b"")
    ed = d / "exact"; ed.mkdir(exist_ok=True)
    (ed / r["name"]).write_bytes(data)
    eq = data == orig
    print("exact sha", hashlib.sha256(data).hexdigest(), "len", len(data), "EQUAL", eq)
    return 0 if eq else 3

if __name__ == "__main__":
    sys.exit(run(sys.argv[1]))
