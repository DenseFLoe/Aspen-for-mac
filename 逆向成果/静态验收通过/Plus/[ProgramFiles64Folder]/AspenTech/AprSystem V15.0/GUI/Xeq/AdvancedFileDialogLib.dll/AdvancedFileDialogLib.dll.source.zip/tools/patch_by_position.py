# -*- coding: utf-8 -*-
"""Position-based token re-anchoring for an ilasm-assembled candidate.

For every IL operand recorded by OperandDump on the original, copy the raw
4-byte token operand at the same body-relative position into the candidate.
Also copy EH clause type tokens positionally.  This avoids Cecil's normalization
of TypeSpec tokens to GenericParam tokens (0x2A??????), which the semantic
token_patch.py cannot map back to the encoded TypeSpec token (0x1B??????).

Precondition: method order/count equal and non-token bytes equal (verified after).
Usage: patch_by_position.py <orig.dll> <cand.dll> <orig.operands.json> <out.dll> <report.json>
"""
import json
import struct
import sys
from hashlib import sha256
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "vendor"))
import clr_meta


def bodies(path):
    data = Path(path).read_bytes()
    pe, cli, root = clr_meta.read_image(data)
    out = []
    for m in clr_meta.method_defs(pe, cli, root):
        if m["rva"]:
            size, head, code, flags = clr_meta.method_extent(pe, m["rva"])
            off = pe.get_offset_from_rva(m["rva"])
            out.append({"token": m["token"], "rva": m["rva"], "head": head,
                        "size": size, "off": off, "body": data[off:off + size],
                        "flags": flags})
        else:
            out.append({"token": m["token"], "rva": 0, "head": 0, "size": 0,
                        "off": 0, "body": b"", "flags": 0})
    return data, pe, cli, root, out


def eh_token_positions(pe, method):
    """Yield positions of the 4-byte value field in each small/fat EH clause."""
    if not method["rva"] or not (method["flags"] & 8):
        return []
    body = method["body"]
    _, head, code, _ = clr_meta.method_extent(pe, method["rva"])
    at = (head + code + 3) & ~3
    if body[at] == 0x01:
        data_size, clause_size, value_offset = body[at + 1], 12, 8
    elif body[at] == 0x41:
        data_size, clause_size, value_offset = int.from_bytes(body[at + 1:at + 4], "little"), 24, 20
    else:
        raise ValueError("the replay requires exactly one small or fat EH section")
    if data_size != len(body) - at or (data_size - 4) % clause_size:
        raise ValueError("invalid exception-handling section extent")
    return range(at + 4 + value_offset, at + data_size, clause_size)


def main(orig_path, cand_path, ops_json, out_path, report_path):
    ops = json.loads(Path(ops_json).read_text(encoding="utf-8"))
    od, ope, ocli, oroot, ob = bodies(orig_path)
    cd, cpe, ccli, croot, cb = bodies(cand_path)
    if len(ob) != len(cb):
        raise SystemExit("method count differs %d vs %d" % (len(ob), len(cb)))
    by_method = {}
    for row in ops:
        by_method.setdefault(row["method"], []).append(row)
    data = bytearray(cd)
    patched = 0
    for i, (o, c) in enumerate(zip(ob, cb)):
        if not o["rva"] or not c["rva"]:
            continue
        # ilasm/ildasm round-trip keeps method tokens stable here; fall back to
        # matching token, else positional index.
        # fat header LocalVarSigTok (body offset 8..11); not an IL operand
        if o["head"] == 12 and c["head"] == 12:
            old = bytes(data[c["off"] + 8:c["off"] + 12])
            new = o["body"][8:12]
            if old != new:
                data[c["off"] + 8:c["off"] + 12] = new
                patched += 1
        rows = by_method.get(o["token"])
        if rows is None:
            continue
        for row in rows:
            pos = o["head"] + row["offset"] + row["opcode_size"]
            stop = pos + 4
            if stop > len(o["body"]) or stop > len(c["body"]):
                raise SystemExit("operand outside body method %d" % i)
            old = bytes(data[c["off"] + pos:c["off"] + pos + 4])
            new = o["body"][pos:pos + 4]
            if old != new:
                data[c["off"] + pos:c["off"] + pos + 4] = new
                patched += 1
        for pos in eh_token_positions(ope, o):
            old = bytes(data[c["off"] + pos:c["off"] + pos + 4])
            new = o["body"][pos:pos + 4]
            if old != new:
                data[c["off"] + pos:c["off"] + pos + 4] = new
                patched += 1
    Path(out_path).write_bytes(bytes(data))
    nd, npe, ncli, nroot, nb = bodies(out_path)
    bad = [i + 1 for i, (a, b) in enumerate(zip(ob, nb)) if a["body"] != b["body"]]
    report = {"patched": patched, "methods": len(nb),
              "body_mismatches": bad[:20], "body_mismatch_count": len(bad),
              "input_sha256": sha256(cd).hexdigest(),
              "output_sha256": sha256(bytes(data)).hexdigest()}
    Path(report_path).write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main(*sys.argv[1:6])
