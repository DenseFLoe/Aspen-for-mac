# AssemblyInfo.cs

Source: editable/Properties/AssemblyInfo.cs

Source SHA-256: 757835a5a990ce2dd5da3097fcdcf59e1f3008c997cc19715a03c2889a40bdc6
