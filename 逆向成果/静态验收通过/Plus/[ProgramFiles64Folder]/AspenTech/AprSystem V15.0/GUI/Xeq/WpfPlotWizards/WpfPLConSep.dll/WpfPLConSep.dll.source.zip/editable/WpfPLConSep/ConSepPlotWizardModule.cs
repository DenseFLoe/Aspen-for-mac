using AspenTech.AspenPlus.Infrastructure;
using WpfPlotWizardsHelper;

namespace WpfPLConSep;

[RibbonPlotWizardMgr("WpfPLCONSEP.RibbonPlotWizardMgr", typeof(RibbonPlotWizardMgr))]
public class ConSepPlotWizardModule : PlotModuleBase
{
}
