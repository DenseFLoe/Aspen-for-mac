"""Build TreeMap from C# and optionally compare the resulting DLL to an original."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_file(path, expected):
    observed = digest(path)
    if observed != expected:
        raise ValueError(f"SHA-256 mismatch for {path}: {observed} (expected {expected})")
    return observed


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def build(args, out):
    plan = json.loads((ROOT / "build-plan.json").read_text(encoding="utf-8"))
    compiler = plan["compiler"]
    csc = args.csc.resolve()
    compiler_sha = check_file(csc, compiler["sha256"])
    for support in compiler["sidecars"]:
        check_file(csc.with_name(support["file"]), support["sha256"])

    framework_root = args.framework_refs.resolve()
    references = []
    for ref in plan["framework_references"]:
        path = framework_root / ref["file"]
        check_file(path, ref["sha256"])
        references.append(path)
    app_dependency = args.devexpress_data.resolve()
    dependency = plan["application_reference"]
    check_file(app_dependency, dependency["sha256"])
    references.append(app_dependency)

    source = ROOT / plan["source"]["file"]
    resource = ROOT / plan["resource"]["file"]
    key = ROOT / plan["public_key"]["file"]
    check_file(key, plan["public_key"]["sha256"])

    out.mkdir(parents=True, exist_ok=True)
    if any(out.iterdir()):
        raise ValueError(f"output directory must be empty: {out}")
    temp = out / "temp"
    temp.mkdir()
    env = {**os.environ, "TMP": str(temp), "TEMP": str(temp), "TMPDIR": str(temp)}
    version = subprocess.check_output(
        [str(csc), "/version"], cwd=out, env=env, text=True, encoding="utf-8"
    ).strip()
    if version != compiler["version"]:
        raise ValueError(f"compiler version mismatch: {version}")

    assembly = plan["assembly"]
    pdb = Path(assembly).with_suffix(".pdb").name
    flags = [
        *plan["flags"], f'/out:"{assembly}"', f'/pdb:"{pdb}"',
        f'/pathmap:"{ROOT}=/_/TreeMap,{out}=/_/out"',
        f'/keyfile:"{key}"', f'/win32res:"{resource}"',
        *(f'/reference:"{ref}"' for ref in references),
        f'"{source}"',
    ]
    response = out / "compile.rsp"
    response.write_text("\n".join(flags) + "\n", encoding="utf-8-sig")
    command = [str(csc), "/noconfig", "@" + str(response)]
    process = subprocess.run(command, cwd=out, env=env, capture_output=True, timeout=120)
    (out / "compile.log").write_bytes(process.stdout + process.stderr)
    if process.returncode:
        raise ValueError(f"Roslyn exited {process.returncode}; see {out / 'compile.log'}")
    target = out / assembly
    result = {
        "compiler": {"version": version, "sha256": compiler_sha},
        "command": command,
        "framework": plan["framework"],
        "framework_reference_count": len(references) - 1,
        "application_reference": dependency,
        "source_sha256": digest(source),
        "resource_sha256": digest(resource),
        "public_key_sha256": digest(key),
        "output_sha256": digest(target),
        "output_bytes": target.stat().st_size,
    }
    write_json(out / "build.json", result)
    return target, result, temp


def resource_inventory(reader, image):
    return {
        key: {
            "rva": rva, "size": size, "code_page": page, "sha256": sha,
        }
        for key, (rva, size, page, sha, _payload) in reader(image).items()
    }


def compare_resources(reader, original, candidate):
    left, right = (resource_inventory(reader, image) for image in (original, candidate))
    rows = []
    for key in sorted(left.keys() | right.keys()):
        before, after = left.get(key), right.get(key)
        equal = (before is not None and after is not None
                 and all(before[field] == after[field] for field in ("size", "code_page", "sha256")))
        rows.append({"identity": key, "original": before, "candidate": after, "equal": equal})
    return {"equal": all(row["equal"] for row in rows), "rows": rows}


def image_context(pefile, data):
    """Report headers and loader dependencies separately from signatures/debug layout."""
    with pefile.PE(data=data, fast_load=True) as pe:
        pe.parse_data_directories(directories=[
            pefile.DIRECTORY_ENTRY[name] for name in (
                "IMAGE_DIRECTORY_ENTRY_IMPORT", "IMAGE_DIRECTORY_ENTRY_BASERELOC",
                "IMAGE_DIRECTORY_ENTRY_DEBUG",
            )
        ])
        header = pe.OPTIONAL_HEADER
        cli = header.DATA_DIRECTORY[14]
        strong_rva = pe.get_dword_at_rva(cli.VirtualAddress + 32)
        strong_size = pe.get_dword_at_rva(cli.VirtualAddress + 36)
        signature = pe.get_data(strong_rva, strong_size) if strong_size else b""
        if len(signature) != strong_size:
            raise ValueError("truncated CLI strong-name slot")
        cert = header.DATA_DIRECTORY[4]
        if cert.VirtualAddress + cert.Size > len(data):
            raise ValueError("truncated Authenticode certificate table")
        imports = list(getattr(pe, "DIRECTORY_ENTRY_IMPORT", ()))
        entry_rva = header.AddressOfEntryPoint
        stub = pe.get_data(entry_rva, 6)
        target = int.from_bytes(stub[2:], "little") if len(stub) == 6 and stub[:2] == b"\xff\x25" else None
        imported_target = [
            [dll.dll.decode("ascii"), imp.name.decode("ascii")]
            for dll in imports for imp in dll.imports if imp.address == target and imp.name is not None
        ]
        relocations = [
            entry for block in getattr(pe, "DIRECTORY_ENTRY_BASERELOC", ()) for entry in block.entries
        ]
        return {
            "abi": {
                "machine": pe.FILE_HEADER.Machine,
                "characteristics": pe.FILE_HEADER.Characteristics,
                "pe_magic": header.Magic,
                "dll_characteristics": header.DllCharacteristics,
                "subsystem": header.Subsystem,
                "subsystem_version": [header.MajorSubsystemVersion, header.MinorSubsystemVersion],
                "image_base": header.ImageBase,
                "section_alignment": header.SectionAlignment,
                "file_alignment": header.FileAlignment,
                "imports": [
                    [dll.dll.decode("ascii"), [
                        imp.name.decode("ascii") if imp.name is not None else imp.ordinal
                        for imp in dll.imports
                    ]] for dll in imports
                ],
                "entry_stub_targets": imported_target,
                "nonpadding_relocations_from_entry": [
                    [entry.type, entry.rva - entry_rva] for entry in relocations if entry.type != 0
                ],
            },
            "layout": {
                "timestamp": pe.FILE_HEADER.TimeDateStamp,
                "pe_checksum": header.CheckSum,
                "entry_rva": entry_rva,
                "entry_stub_hex": stub.hex(),
                "debug_types": [entry.struct.Type for entry in getattr(pe, "DIRECTORY_ENTRY_DEBUG", ())],
                "relocations": [[entry.type, entry.rva] for entry in relocations],
                "sections": [
                    [section.Name.rstrip(b"\0").decode("ascii"), section.VirtualAddress,
                     section.Misc_VirtualSize, section.PointerToRawData, section.SizeOfRawData]
                    for section in pe.sections
                ],
                "strong_name_rva": strong_rva,
                "strong_name_bytes": strong_size,
                "strong_name_nonzero": any(signature),
                "strong_name_sha256": hashlib.sha256(signature).hexdigest() if signature else None,
                "authenticode_offset": cert.VirtualAddress,
                "authenticode_bytes": cert.Size,
            },
        }


def compare(args, out, target, build_result, temp):
    if args.pefile_dir is not None:
        sys.path.insert(0, str(args.pefile_dir.resolve()))
    sys.path.insert(0, str(ROOT / "tools"))
    import managed
    import pefile
    import pe_resources

    if pefile.__version__ != "2024.8.26":
        raise ValueError(f"expected pefile 2024.8.26; observed {pefile.__version__}")
    # managed.check writes and deletes its temporary read-only copy of the original.
    tempfile.tempdir = str(temp)
    for name in ("TMP", "TEMP", "TMPDIR"):
        os.environ[name] = str(temp)
    # Adapt only .NET 7 Stream API calls in the temporary reader, for .NET 6.
    reader_source = managed.READER.read_text(encoding="utf-8")
    stream_hash = "string hash = Convert.ToHexString(SHA256.HashData(fs)).ToLowerInvariant();"
    if reader_source.count(stream_hash) != 1:
        raise ValueError("unexpected managed reader stream hash expression")
    managed.READER = temp / "ManagedEvidence.cs"
    managed.READER.write_text(
        reader_source.replace(stream_hash, "using var sha = SHA256.Create();\n"
                              "        string hash = Convert.ToHexString(sha.ComputeHash(fs)).ToLowerInvariant();"),
        encoding="utf-8",
    )
    os.environ["TREEMAP_STREAM_COMPAT"] = str(ROOT / "tools" / "StreamReadExactly.cs")
    command = "Add-Type -Path $env:ASPEN_CLR_READER"
    if managed.COMMAND.count(command) != 1:
        raise ValueError("unexpected managed reader compile command")
    managed.COMMAND = managed.COMMAND.replace(
        command, "Add-Type -Path @($env:ASPEN_CLR_READER, $env:TREEMAP_STREAM_COMPAT)"
    )
    pwsh_version = subprocess.check_output(
        ["pwsh", "-NoProfile", "-NonInteractive", "-Command", "$PSVersionTable.PSVersion.ToString()"],
        text=True, encoding="utf-8", timeout=20,
    ).strip()
    original = args.original.read_bytes()
    rebuilt = target.read_bytes()
    clr = managed.check(original, target)
    resources = compare_resources(pe_resources._rows, original, rebuilt)
    old_context, new_context = (image_context(pefile, image) for image in (original, rebuilt))
    abi_equal = bool(old_context["abi"]["entry_stub_targets"]) and old_context["abi"] == new_context["abi"]
    report = {
        "status": "pass" if clr["status"] == "pass" and resources["equal"] and abi_equal
                  else "differences_require_review",
        "original_sha256": hashlib.sha256(original).hexdigest(),
        "output_sha256": build_result["output_sha256"],
        "managed": clr,
        "win32_resources": resources,
        "pe": {"abi_equal": abi_equal, "original": old_context, "candidate": new_context},
        "tools": {
            "managed.py": digest(ROOT / "tools" / "managed.py"),
            "ManagedEvidence.cs": digest(ROOT / "tools" / "ManagedEvidence.cs"),
            "adapted_ManagedEvidence.cs": digest(managed.READER),
            "pe_resources.py": digest(ROOT / "tools" / "pe_resources.py"),
            "version_resource.py": digest(ROOT / "tools" / "version_resource.py"),
            "StreamReadExactly.cs": digest(ROOT / "tools" / "StreamReadExactly.cs"),
            "powershell": pwsh_version,
            "pefile_version": pefile.__version__,
            "pefile_sha256": digest(Path(pefile.__file__)),
        },
    }
    write_json(out / "comparison.json", report)
    return report["status"] == "pass"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csc", type=Path, required=True)
    parser.add_argument("--framework-refs", type=Path, required=True)
    parser.add_argument("--devexpress-data", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--original", type=Path, help="compare the fresh output to this installed original")
    parser.add_argument("--pefile-dir", type=Path, help="optional directory containing pefile 2024.8.26")
    args = parser.parse_args()
    out = args.out.resolve()
    try:
        target, build_result, temp = build(args, out)
        if args.original and not compare(args, out, target, build_result, temp):
            print(f"differences require review: {out / 'comparison.json'}", file=sys.stderr)
            return 2
    except (OSError, ValueError, ImportError, subprocess.SubprocessError) as exc:
        print(f"reproduce: {exc}", file=sys.stderr)
        return 1
    print(f"{build_result['output_sha256']}  {target}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
