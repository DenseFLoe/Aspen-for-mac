# AssemblyInfo.cs

Source: editable/Properties/AssemblyInfo.cs

Source SHA-256: 4deded856795ae77b4cd618893eaae0402c48fc4f6c85e65e3af8917fcf5f524
