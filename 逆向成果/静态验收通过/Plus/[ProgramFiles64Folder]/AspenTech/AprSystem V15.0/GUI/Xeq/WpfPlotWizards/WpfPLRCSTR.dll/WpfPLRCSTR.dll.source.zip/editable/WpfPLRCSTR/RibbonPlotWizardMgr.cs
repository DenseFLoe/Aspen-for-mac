using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;

namespace WpfPLRCSTR;

[ProgId("WpfPLRCSTR.RibbonPlotWizardMgr")]
public class RibbonPlotWizardMgr : IRibbonPlotWizardMgr
{
	private static string supportedTypes = "Chain Size Distr.";

	private IHNode _hnode;

	private IHWizardPlot _wizardPlot;

	private static List<PWRPlotType> _lspwrTypes = new List<PWRPlotType>();

	private PWRParser _pwrParser = new PWRParser();

	private Assembly _asm;

	private Dictionary<string, IRibbonPlotWizardType> _dicTagIdToPlotType;

	private IHWizardPlot _tempWizard = (CHWizardPlot)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("9E14C11F-6706-4067-8112-35CE9468F3A5")));

	public RibbonPlotWizardMgr()
	{
		Initialize();
	}

	long IRibbonPlotWizardMgr.SupportedPlotTypes(ref List<string> lsTagIds)
	{
		lsTagIds.Clear();
		for (int i = 0; i < _lspwrTypes.Count; i++)
		{
			PWRPlotType pWRPlotType = _lspwrTypes[i];
			IRibbonPlotWizardType iplotType = null;
			_tempWizard.Clear();
			_pwrParser.FillDefaultPlotVal(pWRPlotType, ref _hnode, ref _tempWizard);
			if (DoesPlotTypeHaveData(pWRPlotType.TagId, ref iplotType, ref _tempWizard))
			{
				lsTagIds.Add(pWRPlotType.TagId);
			}
		}
		return _lspwrTypes.Count;
	}

	long IRibbonPlotWizardMgr.GetPlotType(string sTagId, ref IRibbonPlotWizardType plwType)
	{
		if (_dicTagIdToPlotType.ContainsKey(sTagId))
		{
			plwType = _dicTagIdToPlotType[sTagId];
			if (plwType == null)
			{
				return 0L;
			}
			PWRPlotType pwrPlotType = null;
			_pwrParser.FindPlotType(sTagId, ref _lspwrTypes, ref pwrPlotType);
			_pwrParser.FillDefaultPlotVal(pwrPlotType, ref _hnode, ref _wizardPlot);
		}
		return 0L;
	}

	void IRibbonPlotWizardMgr.SetContext(object oNode, ref object oWizard)
	{
		_hnode = oNode as IHNode;
		_wizardPlot = oWizard as IHWizardPlot;
	}

	void IRibbonPlotWizardMgr.ShowInputDialog(string sPlotName)
	{
	}

	private void InitializeWizardPlot()
	{
	}

	private void Initialize()
	{
		_asm = Assembly.GetExecutingAssembly();
		StreamReader sr = new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLRCSTR.Text.RCSTRpwr.txt"));
		_lspwrTypes.Clear();
		_pwrParser.ParsePwrFile(sr, ref _lspwrTypes);
		_dicTagIdToPlotType = new Dictionary<string, IRibbonPlotWizardType>();
		IRibbonPlotWizardType value = new ChainSizeDistr();
		_dicTagIdToPlotType.Add(supportedTypes, value);
	}

	private bool DoesPlotTypeHaveData(string sTagId, ref IRibbonPlotWizardType iplotType, ref IHWizardPlot iWizardPlot)
	{
		int ierror = 0;
		if (_dicTagIdToPlotType.ContainsKey(sTagId))
		{
			iplotType = _dicTagIdToPlotType[sTagId];
			if (iplotType == null)
			{
				return false;
			}
			object oPlotWizardComponent = iWizardPlot;
			iplotType.Context(_hnode, ref oPlotWizardComponent, ref ierror);
			if (ierror == 0)
			{
				return true;
			}
		}
		return false;
	}
}
