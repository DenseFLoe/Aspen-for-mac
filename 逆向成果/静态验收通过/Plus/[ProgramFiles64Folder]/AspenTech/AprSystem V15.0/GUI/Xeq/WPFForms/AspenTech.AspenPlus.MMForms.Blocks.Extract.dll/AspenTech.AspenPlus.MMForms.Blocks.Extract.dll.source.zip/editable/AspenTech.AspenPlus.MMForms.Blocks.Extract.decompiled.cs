using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenCxs;
using AspenTech.AspenCxs.CxsViewModel;
using AspenTech.AspenCxs.CxsViewModel.CompositeEvents;
using AspenTech.AspenCxs.CxsViewModel.Converters;
using AspenTech.AspenCxs.CxsViewModel.ViewData;
using AspenTech.AspenPlus.Localization.Properties;
using AspenTech.AspenPlus.MMControls;
using AspenTech.AspenPlus.MMControls.CompositeEvents;
using AspenTech.AspenPlus.MMControls.ViewModelExtensions;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.MMForms.Blocks.Extract")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.MMForms.Blocks.Extract")]
[assembly: AssemblyCopyright("Copyright © AspenTech 2009 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/extract", "AspenTech.AspenPlus.MMForms.Blocks.Extract")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]

namespace AspenTech.AspenPlus.MMForms.Blocks.Extract
{
	public class MMExtract_BlockO_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration ENTBLKPR_Property = CxvPropertyDeclaration.Register("ENTBLKPR", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKPR"
		});

		public static readonly CxvPropertyDeclaration ENTBLKSIB_Property = CxvPropertyDeclaration.Register("ENTBLKSIB", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKSIB"
		});

		public static readonly CxvPropertyDeclaration ENTBLKDG_Property = CxvPropertyDeclaration.Register("ENTBLKDG", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKDG"
		});

		public static readonly CxvPropertyDeclaration ENTBLKRP_Property = CxvPropertyDeclaration.Register("ENTBLKRP", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTBLKRP"
		});

		public static readonly CxvPropertyDeclaration GENBLKOP_Property = CxvPropertyDeclaration.Register("GENBLKOP", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.GENBLKOP"
		});

		public static readonly CxvPropertyDeclaration BKOP_Property = CxvPropertyDeclaration.Register("BKOP", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.BKOP"
		});

		public static readonly CxvPropertyDeclaration entitp_Property = CxvPropertyDeclaration.Register("entitp", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTIPT"
		});

		public static readonly CxvPropertyDeclaration entadd_Property = CxvPropertyDeclaration.Register("entadd", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTADD"
		});

		public static readonly CxvPropertyDeclaration entmod_Property = CxvPropertyDeclaration.Register("entmod", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ENTEOMOD"
		});

		public static readonly CxvPropertyDeclaration smspec_Property = CxvPropertyDeclaration.Register("smspec", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SMSPEC"
		});

		public static readonly CxvPropertyDeclaration sment_Property = CxvPropertyDeclaration.Register("sment", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SMENT"
		});

		public static readonly CxvPropertyDeclaration eodef_Property = CxvPropertyDeclaration.Register("eodef", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.EODEF"
		});

		public static readonly CxvPropertyDeclaration eoent_Property = CxvPropertyDeclaration.Register("eoent", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.EOENT"
		});

		public static readonly CxvPropertyDeclaration varno_Property = CxvPropertyDeclaration.Register("varno", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "varno"
		});

		public static readonly CxvPropertyDeclaration L2CP2_Property = CxvPropertyDeclaration.Register("L2CP2", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.L2CP2"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@BKOP", "@GENBLKOP" },
			EnteredDataPaths = { "@ENTBLKPR" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@ENTBLKSIB" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@ENTBLKDG" }
		});

		public static readonly CxvPropertyDeclaration tab3_var_Property = CxvPropertyDeclaration.Register("tab3_var", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@L2CP2", "@smspec" },
			EnteredDataPaths = { "@entadd", "@entitp", "@entmod", "@sment" }
		});

		public static readonly CxvPropertyDeclaration tab4_var_Property = CxvPropertyDeclaration.Register("tab4_var", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@eodef" },
			EnteredDataPaths = { "@eoent" }
		});

		public static readonly CxvPropertyDeclaration tab5_var_Property = CxvPropertyDeclaration.Register("tab5_var", typeof(MMExtract_BlockO_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@ENTBLKPR" }
		});

		public object ENTBLKPR => ((CxvViewModel)this).GetValue(ENTBLKPR_Property);

		public object ENTBLKSIB => ((CxvViewModel)this).GetValue(ENTBLKSIB_Property);

		public object ENTBLKDG => ((CxvViewModel)this).GetValue(ENTBLKDG_Property);

		public object ENTBLKRP => ((CxvViewModel)this).GetValue(ENTBLKRP_Property);

		public object GENBLKOP => ((CxvViewModel)this).GetValue(GENBLKOP_Property);

		public object BKOP => ((CxvViewModel)this).GetValue(BKOP_Property);

		public object entitp => ((CxvViewModel)this).GetValue(entitp_Property);

		public object entadd => ((CxvViewModel)this).GetValue(entadd_Property);

		public object entmod => ((CxvViewModel)this).GetValue(entmod_Property);

		public object smspec => ((CxvViewModel)this).GetValue(smspec_Property);

		public object sment => ((CxvViewModel)this).GetValue(sment_Property);

		public object eodef => ((CxvViewModel)this).GetValue(eodef_Property);

		public object eoent => ((CxvViewModel)this).GetValue(eoent_Property);

		public object varno => ((CxvViewModel)this).GetValue(varno_Property);

		public object L2CP2 => ((CxvViewModel)this).GetValue(L2CP2_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);

		public object tab3_var => ((CxvViewModel)this).GetValue(tab3_var_Property);

		public object tab4_var => ((CxvViewModel)this).GetValue(tab4_var_Property);

		public object tab5_var => ((CxvViewModel)this).GetValue(tab5_var_Property);
	}
	[ProgId("MMExtract.MMExtract_BlockO")]
	public class MMExtract_BlockO : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabBlkOpt;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem tab3;

		internal MMTabItem tab4;

		internal MMTabItem tab5;

		private bool _contentLoaded;

		public MMExtract_BlockO()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_BlockO_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_blocko.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Expected O, but got Unknown
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_003f: Expected O, but got Unknown
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_004c: Expected O, but got Unknown
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Expected O, but got Unknown
			//IL_005c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Expected O, but got Unknown
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Expected O, but got Unknown
			//IL_0076: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabBlkOpt = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				tab3 = (MMTabItem)target;
				break;
			case 6:
				tab4 = (MMTabItem)target;
				break;
			case 7:
				tab5 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_BlockO_Simula_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration Balance_ChkBox_Property = CxvPropertyDeclaration.Register("Balance_ChkBox", typeof(MMExtract_BlockO_Simula_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "Balance_ChkBox",
			Value = 0
		});

		public object Balance_ChkBox => ((CxvViewModel)this).GetValue(Balance_ChkBox_Property);

		protected override void OnUpdateData()
		{
			base.OnUpdateData();
			if (((CxvViewModel)this).IsInitialUpdate)
			{
				((CxvViewModel)this).ResolveUpdateParameter("Balance_ChkBox", (object)0);
			}
		}
	}
	[ProgId("MMExtract.MMExtract_BlockO_Simula")]
	public class MMExtract_BlockO_Simula : MMTabPage, IComponentConnector
	{
		private bool _contentLoaded;

		public MMExtract_BlockO_Simula()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_BlockO_Simula_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_blocko_simula.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			_contentLoaded = true;
		}
	}
	public class MMExtract_Conver_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration UENTCVGO_Property = CxvPropertyDeclaration.Register("UENTCVGO", typeof(MMExtract_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCVGO"
		});

		public static readonly CxvPropertyDeclaration UENTCVGI_Property = CxvPropertyDeclaration.Register("UENTCVGI", typeof(MMExtract_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCVGI"
		});

		public static readonly CxvPropertyDeclaration UENTCVGD_Property = CxvPropertyDeclaration.Register("UENTCVGD", typeof(MMExtract_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCVGD"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMExtract_Conver_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@UENTCVGO" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMExtract_Conver_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@UENTCVGI" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMExtract_Conver_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@UENTCVGD" }
		});

		public object UENTCVGO => ((CxvViewModel)this).GetValue(UENTCVGO_Property);

		public object UENTCVGI => ((CxvViewModel)this).GetValue(UENTCVGI_Property);

		public object UENTCVGD => ((CxvViewModel)this).GetValue(UENTCVGD_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);
	}
	[ProgId("MMExtract.MMExtract_Conver")]
	public class MMExtract_Conver : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabConver;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		private bool _contentLoaded;

		public MMExtract_Conver()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Conver_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_conver.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabConver = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Conver_Diagno_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration sldOLVAR1_var1_Property = CxvPropertyDeclaration.Register("sldOLVAR1_var1", typeof(MMExtract_Conver_Diagno_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.TERM"
		});

		public static readonly CxvPropertyDeclaration sldMAIN_var1_Property = CxvPropertyDeclaration.Register("sldMAIN_var1", typeof(MMExtract_Conver_Diagno_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.MAIN"
		});

		public object sldOLVAR1_var1 => ((CxvViewModel)this).GetValue(sldOLVAR1_var1_Property);

		public object sldMAIN_var1 => ((CxvViewModel)this).GetValue(sldMAIN_var1_Property);
	}
	[ProgId("MMExtract.MMExtract_Conver_Diagno")]
	public class MMExtract_Conver_Diagno : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraDiagno;

		internal MMLabel lblNo;

		internal MMLabel lblFull;

		internal MMLabel lbl0_0;

		internal MMLabel lblFive_0;

		internal MMLabel lbl10_0;

		internal MMLabel lblMain;

		internal MMSlider sldMAIN;

		internal MMLabel lblTerm;

		internal MMSlider sldOLVAR1;

		internal MMLabel lbl0_1;

		internal MMLabel lblFive_1;

		internal MMLabel lbl10_1;

		private bool _contentLoaded;

		public MMExtract_Conver_Diagno()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Conver_Diagno_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_conver_diagno.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			//IL_0050: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Expected O, but got Unknown
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0067: Expected O, but got Unknown
			//IL_006a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0074: Expected O, but got Unknown
			//IL_0077: Unknown result type (might be due to invalid IL or missing references)
			//IL_0081: Expected O, but got Unknown
			//IL_0084: Unknown result type (might be due to invalid IL or missing references)
			//IL_008e: Expected O, but got Unknown
			//IL_0091: Unknown result type (might be due to invalid IL or missing references)
			//IL_009b: Expected O, but got Unknown
			//IL_009e: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a8: Expected O, but got Unknown
			//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b5: Expected O, but got Unknown
			//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c2: Expected O, but got Unknown
			//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cf: Expected O, but got Unknown
			//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00dc: Expected O, but got Unknown
			//IL_00df: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e9: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraDiagno = (MMGroupBox)target;
				break;
			case 2:
				lblNo = (MMLabel)target;
				break;
			case 3:
				lblFull = (MMLabel)target;
				break;
			case 4:
				lbl0_0 = (MMLabel)target;
				break;
			case 5:
				lblFive_0 = (MMLabel)target;
				break;
			case 6:
				lbl10_0 = (MMLabel)target;
				break;
			case 7:
				lblMain = (MMLabel)target;
				break;
			case 8:
				sldMAIN = (MMSlider)target;
				break;
			case 9:
				lblTerm = (MMLabel)target;
				break;
			case 10:
				sldOLVAR1 = (MMSlider)target;
				break;
			case 11:
				lbl0_1 = (MMLabel)target;
				break;
			case 12:
				lblFive_1 = (MMLabel)target;
				break;
			case 13:
				lbl10_1 = (MMLabel)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Conver_Inside_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration lbtuQMINBWIL_var1_Property = CxvPropertyDeclaration.Register("lbtuQMINBWIL_var1", typeof(MMExtract_Conver_Inside_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.QMINBWIL"
		});

		public static readonly CxvPropertyDeclaration lbtuQMAXBWIL_var1_Property = CxvPropertyDeclaration.Register("lbtuQMAXBWIL_var1", typeof(MMExtract_Conver_Inside_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.QMAXBWIL"
		});

		public static readonly CxvPropertyDeclaration lbtuTOLILFAC_var1_Property = CxvPropertyDeclaration.Register("lbtuTOLILFAC_var1", typeof(MMExtract_Conver_Inside_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.TOLILFAC"
		});

		public static readonly CxvPropertyDeclaration lbtuTOLILMIN_var1_Property = CxvPropertyDeclaration.Register("lbtuTOLILMIN_var1", typeof(MMExtract_Conver_Inside_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.TOLILMIN"
		});

		public static readonly CxvPropertyDeclaration lbtuTOLIL0_var1_Property = CxvPropertyDeclaration.Register("lbtuTOLIL0_var1", typeof(MMExtract_Conver_Inside_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.TOLIL0"
		});

		public static readonly CxvPropertyDeclaration cboILMETH_var1_Property = CxvPropertyDeclaration.Register("cboILMETH_var1", typeof(MMExtract_Conver_Inside_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.ILMETH",
			DisplayedCase = (CxsDisplayedCase)2
		});

		public static readonly CxvPropertyDeclaration spnMAXOL_var1_Property = CxvPropertyDeclaration.Register("spnMAXOL_var1", typeof(MMExtract_Conver_Inside_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.MAXIL"
		});

		public object lbtuQMINBWIL_var1 => ((CxvViewModel)this).GetValue(lbtuQMINBWIL_var1_Property);

		public object lbtuQMAXBWIL_var1 => ((CxvViewModel)this).GetValue(lbtuQMAXBWIL_var1_Property);

		public object lbtuTOLILFAC_var1 => ((CxvViewModel)this).GetValue(lbtuTOLILFAC_var1_Property);

		public object lbtuTOLILMIN_var1 => ((CxvViewModel)this).GetValue(lbtuTOLILMIN_var1_Property);

		public object lbtuTOLIL0_var1 => ((CxvViewModel)this).GetValue(lbtuTOLIL0_var1_Property);

		public object cboILMETH_var1 => ((CxvViewModel)this).GetValue(cboILMETH_var1_Property);

		public object spnMAXOL_var1 => ((CxvViewModel)this).GetValue(spnMAXOL_var1_Property);
	}
	[ProgId("MMExtract.MMExtract_Conver_Inside")]
	public class MMExtract_Conver_Inside : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraInside;

		internal MMLabel cboILMETH_label;

		internal MMComboEdit cboILMETH;

		internal MMLabel spnMAXOL_label;

		internal MMSpinBox spnMAXOL;

		internal MMLabel lbtuTOLIL0_label;

		internal MMVariableEdit lbtuTOLIL0;

		internal MMLabel lbtuTOLILMIN_label;

		internal MMVariableEdit lbtuTOLILMIN;

		internal MMLabel lbtuTOLILFAC_label;

		internal MMVariableEdit lbtuTOLILFAC;

		internal MMGroupBox fraWegstein;

		internal MMLabel lbtuQMAXBWIL_label;

		internal MMVariableEdit lbtuQMAXBWIL;

		internal MMLabel lbtuQMINBWIL_label;

		internal MMVariableEdit lbtuQMINBWIL;

		private bool _contentLoaded;

		public MMExtract_Conver_Inside()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Conver_Inside_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_conver_inside.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Expected O, but got Unknown
			//IL_005c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Expected O, but got Unknown
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Expected O, but got Unknown
			//IL_0076: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Expected O, but got Unknown
			//IL_0083: Unknown result type (might be due to invalid IL or missing references)
			//IL_008d: Expected O, but got Unknown
			//IL_0090: Unknown result type (might be due to invalid IL or missing references)
			//IL_009a: Expected O, but got Unknown
			//IL_009d: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Expected O, but got Unknown
			//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b4: Expected O, but got Unknown
			//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c1: Expected O, but got Unknown
			//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ce: Expected O, but got Unknown
			//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00db: Expected O, but got Unknown
			//IL_00de: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e8: Expected O, but got Unknown
			//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f5: Expected O, but got Unknown
			//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_0102: Expected O, but got Unknown
			//IL_0105: Unknown result type (might be due to invalid IL or missing references)
			//IL_010f: Expected O, but got Unknown
			//IL_0112: Unknown result type (might be due to invalid IL or missing references)
			//IL_011c: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraInside = (MMGroupBox)target;
				break;
			case 2:
				cboILMETH_label = (MMLabel)target;
				break;
			case 3:
				cboILMETH = (MMComboEdit)target;
				break;
			case 4:
				spnMAXOL_label = (MMLabel)target;
				break;
			case 5:
				spnMAXOL = (MMSpinBox)target;
				break;
			case 6:
				lbtuTOLIL0_label = (MMLabel)target;
				break;
			case 7:
				lbtuTOLIL0 = (MMVariableEdit)target;
				break;
			case 8:
				lbtuTOLILMIN_label = (MMLabel)target;
				break;
			case 9:
				lbtuTOLILMIN = (MMVariableEdit)target;
				break;
			case 10:
				lbtuTOLILFAC_label = (MMLabel)target;
				break;
			case 11:
				lbtuTOLILFAC = (MMVariableEdit)target;
				break;
			case 12:
				fraWegstein = (MMGroupBox)target;
				break;
			case 13:
				lbtuQMAXBWIL_label = (MMLabel)target;
				break;
			case 14:
				lbtuQMAXBWIL = (MMVariableEdit)target;
				break;
			case 15:
				lbtuQMINBWIL_label = (MMLabel)target;
				break;
			case 16:
				lbtuQMINBWIL = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Conver_Outsid_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration lbtuRMSOL1_var1_Property = CxvPropertyDeclaration.Register("lbtuRMSOL1_var1", typeof(MMExtract_Conver_Outsid_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.RMSOL1"
		});

		public static readonly CxvPropertyDeclaration lbtuTOLOL_var1_Property = CxvPropertyDeclaration.Register("lbtuTOLOL_var1", typeof(MMExtract_Conver_Outsid_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.TOLOL"
		});

		public static readonly CxvPropertyDeclaration spnMAXOL_var1_Property = CxvPropertyDeclaration.Register("spnMAXOL_var1", typeof(MMExtract_Conver_Outsid_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.MAXOL"
		});

		public static readonly CxvPropertyDeclaration cboOLMETH_var1_Property = CxvPropertyDeclaration.Register("cboOLMETH_var1", typeof(MMExtract_Conver_Outsid_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)2,
			DataPath = "@main.Input.OLMETH",
			DisplayedCase = (CxsDisplayedCase)2
		});

		public static readonly CxvPropertyDeclaration lbtuQMINBWOL_var1_Property = CxvPropertyDeclaration.Register("lbtuQMINBWOL_var1", typeof(MMExtract_Conver_Outsid_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.QMINBWOL"
		});

		public static readonly CxvPropertyDeclaration lbtuQMAXBWOL_var1_Property = CxvPropertyDeclaration.Register("lbtuQMAXBWOL_var1", typeof(MMExtract_Conver_Outsid_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.QMAXBWOL"
		});

		public static readonly CxvPropertyDeclaration lbtuFMINFAC_var1_Property = CxvPropertyDeclaration.Register("lbtuFMINFAC_var1", typeof(MMExtract_Conver_Outsid_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.FMINFAC"
		});

		public static readonly CxvPropertyDeclaration lbtuMAXIP_var1_Property = CxvPropertyDeclaration.Register("lbtuMAXIP_var1", typeof(MMExtract_Conver_Outsid_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.MAXIP"
		});

		public object lbtuRMSOL1_var1 => ((CxvViewModel)this).GetValue(lbtuRMSOL1_var1_Property);

		public object lbtuTOLOL_var1 => ((CxvViewModel)this).GetValue(lbtuTOLOL_var1_Property);

		public object spnMAXOL_var1 => ((CxvViewModel)this).GetValue(spnMAXOL_var1_Property);

		public object cboOLMETH_var1 => ((CxvViewModel)this).GetValue(cboOLMETH_var1_Property);

		public object lbtuQMINBWOL_var1 => ((CxvViewModel)this).GetValue(lbtuQMINBWOL_var1_Property);

		public object lbtuQMAXBWOL_var1 => ((CxvViewModel)this).GetValue(lbtuQMAXBWOL_var1_Property);

		public object lbtuFMINFAC_var1 => ((CxvViewModel)this).GetValue(lbtuFMINFAC_var1_Property);

		public object lbtuMAXIP_var1 => ((CxvViewModel)this).GetValue(lbtuMAXIP_var1_Property);
	}
	[ProgId("MMExtract.MMExtract_Conver_Outsid")]
	public class MMExtract_Conver_Outsid : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraOutside;

		internal MMLabel cboOLMETH_label;

		internal MMComboEdit cboOLMETH;

		internal MMLabel spnMAXOL_label;

		internal MMSpinBox spnMAXOL;

		internal MMLabel lbtuTOLOL_label;

		internal MMVariableEdit lbtuTOLOL;

		internal MMLabel lbtuRMSOL1_label;

		internal MMVariableEdit lbtuRMSOL1;

		internal MMGroupBox fraOptions_1;

		internal MMLabel lbtuQMAXBWOL_label;

		internal MMVariableEdit lbtuQMAXBWOL;

		internal MMLabel lbtuQMINBWOL_label;

		internal MMVariableEdit lbtuQMINBWOL;

		internal MMGroupBox fraOptions_0;

		internal MMLabel lbtuMAXIP_label;

		internal MMVariableEdit lbtuMAXIP;

		internal MMLabel lbtuFMINFAC_label;

		internal MMVariableEdit lbtuFMINFAC;

		private bool _contentLoaded;

		public MMExtract_Conver_Outsid()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Conver_Outsid_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_conver_outsid.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Expected O, but got Unknown
			//IL_0068: Unknown result type (might be due to invalid IL or missing references)
			//IL_0072: Expected O, but got Unknown
			//IL_0075: Unknown result type (might be due to invalid IL or missing references)
			//IL_007f: Expected O, but got Unknown
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_008c: Expected O, but got Unknown
			//IL_008f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0099: Expected O, but got Unknown
			//IL_009c: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a6: Expected O, but got Unknown
			//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b3: Expected O, but got Unknown
			//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c0: Expected O, but got Unknown
			//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cd: Expected O, but got Unknown
			//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00da: Expected O, but got Unknown
			//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e7: Expected O, but got Unknown
			//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f4: Expected O, but got Unknown
			//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0101: Expected O, but got Unknown
			//IL_0104: Unknown result type (might be due to invalid IL or missing references)
			//IL_010e: Expected O, but got Unknown
			//IL_0111: Unknown result type (might be due to invalid IL or missing references)
			//IL_011b: Expected O, but got Unknown
			//IL_011e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0128: Expected O, but got Unknown
			//IL_012b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0135: Expected O, but got Unknown
			//IL_0138: Unknown result type (might be due to invalid IL or missing references)
			//IL_0142: Expected O, but got Unknown
			//IL_0145: Unknown result type (might be due to invalid IL or missing references)
			//IL_014f: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraOutside = (MMGroupBox)target;
				break;
			case 2:
				cboOLMETH_label = (MMLabel)target;
				break;
			case 3:
				cboOLMETH = (MMComboEdit)target;
				break;
			case 4:
				spnMAXOL_label = (MMLabel)target;
				break;
			case 5:
				spnMAXOL = (MMSpinBox)target;
				break;
			case 6:
				lbtuTOLOL_label = (MMLabel)target;
				break;
			case 7:
				lbtuTOLOL = (MMVariableEdit)target;
				break;
			case 8:
				lbtuRMSOL1_label = (MMLabel)target;
				break;
			case 9:
				lbtuRMSOL1 = (MMVariableEdit)target;
				break;
			case 10:
				fraOptions_1 = (MMGroupBox)target;
				break;
			case 11:
				lbtuQMAXBWOL_label = (MMLabel)target;
				break;
			case 12:
				lbtuQMAXBWOL = (MMVariableEdit)target;
				break;
			case 13:
				lbtuQMINBWOL_label = (MMLabel)target;
				break;
			case 14:
				lbtuQMINBWOL = (MMVariableEdit)target;
				break;
			case 15:
				fraOptions_0 = (MMGroupBox)target;
				break;
			case 16:
				lbtuMAXIP_label = (MMLabel)target;
				break;
			case 17:
				lbtuMAXIP = (MMVariableEdit)target;
				break;
			case 18:
				lbtuFMINFAC_label = (MMLabel)target;
				break;
			case 19:
				lbtuFMINFAC = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Dynam_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration dyncsh0_Property = CxvPropertyDeclaration.Register("dyncsh0", typeof(MMExtract_Dynam_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.DYNCSH0"
		});

		public static readonly CxvPropertyDeclaration sht0_Property = CxvPropertyDeclaration.Register("sht0", typeof(MMExtract_Dynam_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SHT0"
		});

		public static readonly CxvPropertyDeclaration ucsh0_Property = CxvPropertyDeclaration.Register("ucsh0", typeof(MMExtract_Dynam_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UCSH0"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMExtract_Dynam_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@dyncsh0" },
			AccessibleDataPaths = { "@sht0" },
			EnteredDataPaths = { "@ucsh0" }
		});

		public object dyncsh0 => ((CxvViewModel)this).GetValue(dyncsh0_Property);

		public object sht0 => ((CxvViewModel)this).GetValue(sht0_Property);

		public object ucsh0 => ((CxvViewModel)this).GetValue(ucsh0_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);
	}
	[ProgId("MMExtract.MMExtract_Dynam")]
	public class MMExtract_Dynam : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabDynam;

		internal MMTabItem tab0;

		private bool _contentLoaded;

		public MMExtract_Dynam()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Dynam_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_dynam.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabDynam = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Dynam_StgVol_ViewModel : MMTabPageViewModel
	{
		public class grdDynStgVol_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(grdDynStgVol_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@main.Input.VOLRATIO.@stage"
			});

			public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(grdDynStgVol_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.VOLRATIO.@stage"
			});

			public object MMTextBox2_var1 => ((CxvViewModel)this).GetValue(MMTextBox2_var1_Property);

			public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);
		}

		public static readonly CxvPropertyDeclaration lbtuDynStgVol_stagevol_Property = CxvPropertyDeclaration.Register("lbtuDynStgVol_stagevol", typeof(MMExtract_Dynam_StgVol_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.STAGEVOL"
		});

		public static readonly CxvPropertyDeclaration grdDynStgVol_GridData_Property = CxvPropertyDeclaration.Register("grdDynStgVol_GridData", typeof(MMExtract_Dynam_StgVol_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdDynStgVol_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.VOLRATIO",
				UseChildId = true,
				Name = "stage"
			}
		});

		public object lbtuDynStgVol_stagevol => ((CxvViewModel)this).GetValue(lbtuDynStgVol_stagevol_Property);

		public object grdDynStgVol_GridData => ((CxvViewModel)this).GetValue(grdDynStgVol_GridData_Property);
	}
	[ProgId("MMExtract.MMExtract_Dynam_StgVol")]
	public class MMExtract_Dynam_StgVol : MMTabPage, IComponentConnector
	{
		internal MMLabel lbtuDynStgVol_label;

		internal MMVariableEdit lbtuDynStgVol;

		internal MMGroupBox fraDynStg;

		internal MMScrollArea grdDynStgVol;

		private bool _contentLoaded;

		public MMExtract_Dynam_StgVol()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Dynam_StgVol_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_dynam_stgvol.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				lbtuDynStgVol_label = (MMLabel)target;
				break;
			case 2:
				lbtuDynStgVol = (MMVariableEdit)target;
				break;
			case 3:
				fraDynStg = (MMGroupBox)target;
				break;
			case 4:
				grdDynStgVol = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Effici_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration SEFF_Property = CxvPropertyDeclaration.Register("SEFF", typeof(MMExtract_Effici_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SEFF"
		});

		public static readonly CxvPropertyDeclaration CEFF_Property = CxvPropertyDeclaration.Register("CEFF", typeof(MMExtract_Effici_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.CEFF"
		});

		public static readonly CxvPropertyDeclaration EFMTHA_Property = CxvPropertyDeclaration.Register("EFMTHA", typeof(MMExtract_Effici_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.EFMTHA"
		});

		public static readonly CxvPropertyDeclaration EFMTHB_Property = CxvPropertyDeclaration.Register("EFMTHB", typeof(MMExtract_Effici_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.EFMTHB"
		});

		public static readonly CxvPropertyDeclaration UENTOPTEFF_Property = CxvPropertyDeclaration.Register("UENTOPTEFF", typeof(MMExtract_Effici_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTOPTEFF"
		});

		public static readonly CxvPropertyDeclaration UENTSTGEFF_Property = CxvPropertyDeclaration.Register("UENTSTGEFF", typeof(MMExtract_Effici_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTSTGEFF"
		});

		public static readonly CxvPropertyDeclaration UENTCOMPEFF_Property = CxvPropertyDeclaration.Register("UENTCOMPEFF", typeof(MMExtract_Effici_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCOMPEFF"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMExtract_Effici_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@UENTOPTEFF" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMExtract_Effici_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@SEFF" },
			AccessibleDataPaths = { "@EFMTHA" },
			EnteredDataPaths = { "@UENTSTGEFF" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMExtract_Effici_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@CEFF" },
			AccessibleDataPaths = { "@EFMTHB" },
			EnteredDataPaths = { "@UENTCOMPEFF" }
		});

		public object SEFF => ((CxvViewModel)this).GetValue(SEFF_Property);

		public object CEFF => ((CxvViewModel)this).GetValue(CEFF_Property);

		public object EFMTHA => ((CxvViewModel)this).GetValue(EFMTHA_Property);

		public object EFMTHB => ((CxvViewModel)this).GetValue(EFMTHB_Property);

		public object UENTOPTEFF => ((CxvViewModel)this).GetValue(UENTOPTEFF_Property);

		public object UENTSTGEFF => ((CxvViewModel)this).GetValue(UENTSTGEFF_Property);

		public object UENTCOMPEFF => ((CxvViewModel)this).GetValue(UENTCOMPEFF_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);
	}
	[ProgId("MMExtract.MMExtract_Effici")]
	public class MMExtract_Effici : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabEfficiencies;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		private bool _contentLoaded;

		public MMExtract_Effici()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Effici_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_effici.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabEfficiencies = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Effici_Compon_ViewModel : MMTabPageViewModel
	{
		public class grdComp2_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration spnL2_CEFF_var1_Property = CxvPropertyDeclaration.Register("spnL2_CEFF_var1", typeof(grdComp2_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.COMP_EFF.@y"
			});

			public static readonly CxvPropertyDeclaration inner_Property = CxvPropertyDeclaration.Register("inner", typeof(grdComp2_GridData_ItemTemplate), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdComp2_GridData_ItemTemplate_inner_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@main.Input.COMP_EFF.#0",
					UseChildId = true,
					Name = "x"
				}
			});

			public object spnL2_CEFF_var1 => ((CxvViewModel)this).GetValue(spnL2_CEFF_var1_Property);

			public object inner => ((CxvViewModel)this).GetValue(inner_Property);
		}

		public class grdComp2_GridData_ItemTemplate_inner_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtL2_CEFF_var1_Property = CxvPropertyDeclaration.Register("txtL2_CEFF_var1", typeof(grdComp2_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.COMP_EFF.@y.@x"
			});

			public static readonly CxvPropertyDeclaration cboL2_CEFF_var1_Property = CxvPropertyDeclaration.Register("cboL2_CEFF_var1", typeof(grdComp2_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.COMP_EFF.@y.@x",
				ExposeAs = (CxvVariableTypeCode)7
			});

			public object txtL2_CEFF_var1 => ((CxvViewModel)this).GetValue(txtL2_CEFF_var1_Property);

			public object cboL2_CEFF_var1 => ((CxvViewModel)this).GetValue(cboL2_CEFF_var1_Property);
		}

		public static readonly CxvPropertyDeclaration grdComp2_GridData_Property = CxvPropertyDeclaration.Register("grdComp2_GridData", typeof(MMExtract_Effici_Compon_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdComp2_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.COMP_EFF",
				UseChildId = true,
				Name = "y"
			}
		});

		public object grdComp2_GridData => ((CxvViewModel)this).GetValue(grdComp2_GridData_Property);
	}
	[ProgId("MMExtract.MMExtract_Effici_Compon")]
	public class MMExtract_Effici_Compon : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraPress_Profile;

		internal MMScrollArea grdComp2;

		private bool _contentLoaded;

		public MMExtract_Effici_Compon()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Effici_Compon_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_effici_compon.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraPress_Profile = (MMGroupBox)target;
				break;
			case 2:
				grdComp2 = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Effici_Option_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration ogrOPT_EFF_METH_MultiMap_Property;

		public object ogrOPT_EFF_METH_MultiMap => ((CxvViewModel)this).GetValue(ogrOPT_EFF_METH_MultiMap_Property);

		public MMExtract_Effici_Option_ViewModel()
		{
		}

		static MMExtract_Effici_Option_ViewModel()
		{
	ogrOPT_EFF_METH_MultiMap_Property = CxvPropertyDeclaration.Register("ogrOPT_EFF_METH_MultiMap", typeof(MMExtract_Effici_Option_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "ogrOPT_EFF_METH_display",
				DataPath = "@main.Input.OPT_EFF_METH"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Specify stage efficiencies ",
				DisplayResourceKey = "MMExtract_Effici_Option_ViewModel__CxvMultiMapOption_Display_Specify_stage_efficiencies",
				Value = "ogrOPT_EFF_METH_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrOPT_EFF_METH_display",
				Value = "STAGE"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Specify efficiencies for individual components",
				DisplayResourceKey = "MMExtract_Effici_Option_ViewModel__CxvMultiMapOption_Display_Specify_efficiencies_for_individual_com",
				Value = "ogrOPT_EFF_METH_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrOPT_EFF_METH_display",
				Value = "COMPONENT"
			} }
				} }
});
	}
	}
	[ProgId("MMExtract.MMExtract_Effici_Option")]
	public class MMExtract_Effici_Option : MMTabPage, IComponentConnector
	{
		internal MMOptionGroup ogrOPT_EFF_METH;

		internal MMOptionButton ogrOPT_EFF_METH_opt0;

		internal MMOptionButton ogrOPT_EFF_METH_opt1;

		private bool _contentLoaded;

		public MMExtract_Effici_Option()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Effici_Option_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_effici_option.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Expected O, but got Unknown
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				ogrOPT_EFF_METH = (MMOptionGroup)target;
				break;
			case 2:
				ogrOPT_EFF_METH_opt0 = (MMOptionButton)target;
				break;
			case 3:
				ogrOPT_EFF_METH_opt1 = (MMOptionButton)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Effici_Stage_ViewModel : MMTabPageViewModel
	{
		public class grdPress_Prof_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration spnSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("spnSTAGE_PRES_var1", typeof(grdPress_Prof_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.STAGE_EFF.@y"
			});

			public static readonly CxvPropertyDeclaration txtSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("txtSTAGE_PRES_var1", typeof(grdPress_Prof_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.STAGE_EFF.@y"
			});

			public object spnSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(spnSTAGE_PRES_var1_Property);

			public object txtSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(txtSTAGE_PRES_var1_Property);
		}

		public static readonly CxvPropertyDeclaration grdPress_Prof_GridData_Property = CxvPropertyDeclaration.Register("grdPress_Prof_GridData", typeof(MMExtract_Effici_Stage_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdPress_Prof_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.STAGE_EFF",
				UseChildId = true,
				Name = "y"
			}
		});

		public object grdPress_Prof_GridData => ((CxvViewModel)this).GetValue(grdPress_Prof_GridData_Property);
	}
	[ProgId("MMExtract.MMExtract_Effici_Stage")]
	public class MMExtract_Effici_Stage : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraPress_Profile;

		internal MMScrollArea grdPress_Prof;

		private bool _contentLoaded;

		public MMExtract_Effici_Stage()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Effici_Stage_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_effici_stage.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraPress_Profile = (MMGroupBox)target;
				break;
			case 2:
				grdPress_Prof = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Estima_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration XEST_Property = CxvPropertyDeclaration.Register("XEST", typeof(MMExtract_Estima_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.XEST"
		});

		public static readonly CxvPropertyDeclaration TEST_Property = CxvPropertyDeclaration.Register("TEST", typeof(MMExtract_Estima_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.TEST"
		});

		public static readonly CxvPropertyDeclaration UENTTEST_Property = CxvPropertyDeclaration.Register("UENTTEST", typeof(MMExtract_Estima_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTTEST"
		});

		public static readonly CxvPropertyDeclaration UENTXEST_Property = CxvPropertyDeclaration.Register("UENTXEST", typeof(MMExtract_Estima_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTXEST"
		});

		public static readonly CxvPropertyDeclaration NO2TEMPS_Property = CxvPropertyDeclaration.Register("NO2TEMPS", typeof(MMExtract_Estima_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.NO2TEMPS"
		});

		public static readonly CxvPropertyDeclaration NEED1TEMP_Property = CxvPropertyDeclaration.Register("NEED1TEMP", typeof(MMExtract_Estima_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.NEED1TEMP"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMExtract_Estima_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@TEST", "@NO2TEMPS", "@NEED1TEMP" },
			EnteredDataPaths = { "@UENTTEST" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMExtract_Estima_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@XEST" },
			EnteredDataPaths = { "@UENTXEST" }
		});

		public object XEST => ((CxvViewModel)this).GetValue(XEST_Property);

		public object TEST => ((CxvViewModel)this).GetValue(TEST_Property);

		public object UENTTEST => ((CxvViewModel)this).GetValue(UENTTEST_Property);

		public object UENTXEST => ((CxvViewModel)this).GetValue(UENTXEST_Property);

		public object NO2TEMPS => ((CxvViewModel)this).GetValue(NO2TEMPS_Property);

		public object NEED1TEMP => ((CxvViewModel)this).GetValue(NEED1TEMP_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);
	}
	[ProgId("MMExtract.MMExtract_Estima")]
	public class MMExtract_Estima : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabEstimates;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		private bool _contentLoaded;

		public MMExtract_Estima()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Estima_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_estima.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Expected O, but got Unknown
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabEstimates = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Estima_Compos_ViewModel : MMTabPageViewModel
	{
		public class grdComp2_0_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration spnL2_CEFF_0_var1_Property = CxvPropertyDeclaration.Register("spnL2_CEFF_0_var1", typeof(grdComp2_0_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.X1_EST.@y"
			});

			public static readonly CxvPropertyDeclaration inner_Property = CxvPropertyDeclaration.Register("inner", typeof(grdComp2_0_GridData_ItemTemplate), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdComp2_0_GridData_ItemTemplate_inner_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@main.Input.X1_EST.#0",
					UseChildId = true,
					Name = "x"
				}
			});

			public object spnL2_CEFF_0_var1 => ((CxvViewModel)this).GetValue(spnL2_CEFF_0_var1_Property);

			public object inner => ((CxvViewModel)this).GetValue(inner_Property);
		}

		public class grdComp2_1_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration spnL2_CEFF_1_var1_Property = CxvPropertyDeclaration.Register("spnL2_CEFF_1_var1", typeof(grdComp2_1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.X2_EST.@y"
			});

			public static readonly CxvPropertyDeclaration inner_Property = CxvPropertyDeclaration.Register("inner", typeof(grdComp2_1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdComp2_1_GridData_ItemTemplate_inner_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@main.Input.X2_EST.#0",
					UseChildId = true,
					Name = "x"
				}
			});

			public object spnL2_CEFF_1_var1 => ((CxvViewModel)this).GetValue(spnL2_CEFF_1_var1_Property);

			public object inner => ((CxvViewModel)this).GetValue(inner_Property);
		}

		public class grdComp2_0_GridData_ItemTemplate_inner_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration cboL2_CEFF_0_var1_Property = CxvPropertyDeclaration.Register("cboL2_CEFF_0_var1", typeof(grdComp2_0_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "x"
			});

			public static readonly CxvPropertyDeclaration txtL2_CEFF_0_var1_Property = CxvPropertyDeclaration.Register("txtL2_CEFF_0_var1", typeof(grdComp2_0_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.X1_EST.@y.@x"
			});

			public object cboL2_CEFF_0_var1 => ((CxvViewModel)this).GetValue(cboL2_CEFF_0_var1_Property);

			public object txtL2_CEFF_0_var1 => ((CxvViewModel)this).GetValue(txtL2_CEFF_0_var1_Property);
		}

		public class grdComp2_1_GridData_ItemTemplate_inner_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration cboL2_CEFF_1_var1_Property = CxvPropertyDeclaration.Register("cboL2_CEFF_1_var1", typeof(grdComp2_1_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "x"
			});

			public static readonly CxvPropertyDeclaration txtL2_CEFF_1_var1_Property = CxvPropertyDeclaration.Register("txtL2_CEFF_1_var1", typeof(grdComp2_1_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.X2_EST.@y.@x"
			});

			public object cboL2_CEFF_1_var1 => ((CxvViewModel)this).GetValue(cboL2_CEFF_1_var1_Property);

			public object txtL2_CEFF_1_var1 => ((CxvViewModel)this).GetValue(txtL2_CEFF_1_var1_Property);
		}

		public class grdComp2_0_GridHeader_HeaderTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration var1_Property = CxvPropertyDeclaration.Register("var1_Property", typeof(grdComp2_0_GridHeader_HeaderTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.X1_EST.#0.@x"
			});

			public object var1 => ((CxvViewModel)this).GetValue(var1_Property);
		}

		public class grdComp2_1_GridHeader_HeaderTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration var1_Property = CxvPropertyDeclaration.Register("var1_Property", typeof(grdComp2_1_GridHeader_HeaderTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.X2_EST.#0.@x"
			});

			public object var1 => ((CxvViewModel)this).GetValue(var1_Property);
		}

		private ICommand _cmdGenerate_Command;

		public static readonly CxvPropertyDeclaration grdComp2_0_GridData_Property = CxvPropertyDeclaration.Register("grdComp2_0_GridData", typeof(MMExtract_Estima_Compos_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdComp2_0_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.X1_EST",
				UseChildId = true,
				Name = "y"
			}
		});

		public static readonly CxvPropertyDeclaration grdComp2_1_GridData_Property = CxvPropertyDeclaration.Register("grdComp2_1_GridData", typeof(MMExtract_Estima_Compos_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdComp2_1_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.X2_EST",
				UseChildId = true,
				Name = "y"
			}
		});

		public static readonly CxvPropertyDeclaration grdComp2_0_GridHeader_Property = CxvPropertyDeclaration.Register("grdComp2_0_GridHeader", typeof(MMExtract_Estima_Compos_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdComp2_0_GridHeader_HeaderTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.X1_EST.#0",
				UseChildId = false,
				Name = "x"
			}
		});

		public static readonly CxvPropertyDeclaration grdComp2_1_GridHeader_Property = CxvPropertyDeclaration.Register("grdComp2_1_GridHeader", typeof(MMExtract_Estima_Compos_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdComp2_1_GridHeader_HeaderTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.X2_EST.#0",
				UseChildId = false,
				Name = "x"
			}
		});

		public ICommand cmdGenerate_Command
		{
			get
			{
				if (_cmdGenerate_Command == null)
				{
					_cmdGenerate_Command = (ICommand)new CxvDelegateCommand<object>((Action<object>)cmdGenerate_CommandExecute);
				}
				return _cmdGenerate_Command;
			}
		}

		public object grdComp2_0_GridData => ((CxvViewModel)this).GetValue(grdComp2_0_GridData_Property);

		public object grdComp2_1_GridData => ((CxvViewModel)this).GetValue(grdComp2_1_GridData_Property);

		public object grdComp2_0_GridHeader => ((CxvViewModel)this).GetValue(grdComp2_0_GridHeader_Property);

		public object grdComp2_1_GridHeader => ((CxvViewModel)this).GetValue(grdComp2_1_GridHeader_Property);

		private void cmdGenerate_CommandExecute(object parameter)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Expected O, but got Unknown
			DisplayFormEventArgs e = new DisplayFormEventArgs
			{
				FormType = typeof(MMExtract_Estima_Genera),
				LegacyFlags = 0,
				HelpId = 62,
				HelpFile = "Extract.hlp",
				ShowPrompts = false,
				ShortName = AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Estima_Compos_ViewModel_GenerateCommandHeader
			};
			e.Parameters.Add("TEMP", "NO");
			e.Parameters.Add("FRAC", "YES");
			e.Parameters.Add("UPDATE", "CUSTOM");
			((MMViewModel)this).DisplayForm(e);
		}
	}
	[ProgId("MMExtract.MMExtract_Estima_Compos")]
	public class MMExtract_Estima_Compos : MMTabPage, IComponentConnector
	{
		internal MMCmdButton cmdGenerate;

		internal MMLabel fraPress_Profile_0;

		internal MMScrollArea grdComp2_0;

		internal MMLabel fraPress_Profile_1;

		internal MMScrollArea grdComp2_1;

		private bool _contentLoaded;

		public MMExtract_Estima_Compos()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Estima_Compos_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_estima_compos.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Expected O, but got Unknown
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Expected O, but got Unknown
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Expected O, but got Unknown
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				cmdGenerate = (MMCmdButton)target;
				break;
			case 2:
				fraPress_Profile_0 = (MMLabel)target;
				break;
			case 3:
				grdComp2_0 = (MMScrollArea)target;
				break;
			case 4:
				fraPress_Profile_1 = (MMLabel)target;
				break;
			case 5:
				grdComp2_1 = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Estima_Genera_ViewModel : MMTabPageViewModel
	{
		private ICommand _cmdGenerate_Command;

		private ICommand _cmdClose_Command;

		public static readonly CxvPropertyDeclaration MMOptionGroup1_MultiMap_Property;

		private const string nstage_node = "@main.Input.NSTAGE";

		private const string feed_node = "@main.Input.FEED_STAGE";

		private const string x1est_node = "@main.Input.X1_EST";

		private const string x2est_node = "@main.Input.X2_EST";

		private const string test_node = "@main.Input.TEMP_EST";

		private const string tres_node = "@main.Output.B_TEMP";

		private const string x1res_node = "@main.Output.X1";

		private const string x2res_node = "@main.Output.X2";

		public static readonly CxvPropertyDeclaration MMCheckBox2_var1_Property;

		public static readonly CxvPropertyDeclaration chkTemperature_var1_Property;

		public ICommand cmdGenerate_Command
		{
			get
			{
				if (_cmdGenerate_Command == null)
				{
					_cmdGenerate_Command = (ICommand)new CxvDelegateCommand<object>((Action<object>)cmdGenerate_CommandExecute);
				}
				return _cmdGenerate_Command;
			}
		}

		public ICommand cmdClose_Command
		{
			get
			{
				if (_cmdClose_Command == null)
				{
					_cmdClose_Command = (ICommand)new CxvDelegateCommand<object>((Action<object>)cmdClose_CommandExecute);
				}
				return _cmdClose_Command;
			}
		}

		public object MMOptionGroup1_MultiMap => ((CxvViewModel)this).GetValue(MMOptionGroup1_MultiMap_Property);

		public object MMCheckBox2_var1 => ((CxvViewModel)this).GetValue(MMCheckBox2_var1_Property);

		public object chkTemperature_var1 => ((CxvViewModel)this).GetValue(chkTemperature_var1_Property);

		private void cmdGenerate_CommandExecute(object parameter)
		{
			//IL_0101: Unknown result type (might be due to invalid IL or missing references)
			//IL_0106: Unknown result type (might be due to invalid IL or missing references)
			//IL_0111: Unknown result type (might be due to invalid IL or missing references)
			//IL_0122: Expected O, but got Unknown
			//IL_0668: Unknown result type (might be due to invalid IL or missing references)
			//IL_066d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0678: Unknown result type (might be due to invalid IL or missing references)
			//IL_0689: Expected O, but got Unknown
			//IL_0692: Unknown result type (might be due to invalid IL or missing references)
			//IL_0697: Unknown result type (might be due to invalid IL or missing references)
			//IL_06a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_06b3: Expected O, but got Unknown
			//IL_06b8: Unknown result type (might be due to invalid IL or missing references)
			//IL_06bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_06c8: Unknown result type (might be due to invalid IL or missing references)
			//IL_06d9: Expected O, but got Unknown
			//IL_06df: Unknown result type (might be due to invalid IL or missing references)
			//IL_06e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_06ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_0700: Expected O, but got Unknown
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			bool flag4 = false;
			bool flag5 = false;
			bool flag6 = false;
			bool flag7 = false;
			bool flag8 = false;
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			double num4 = 0.0;
			int num5 = 0;
			int[] array = null;
			string text6;
			string text9;
			string text10;
			int? num6 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.NSTAGE", "value"));
			int? num7 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.B_TEMP", "child_count"));
			int? num8 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.TEMP_EST", "child_count"));
			int? num9 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.X1_EST", "child_count"));
			string text = CxsConverter.ValueToString(((CxvViewModel)this).ResolveParameter("TEMP"));
			string text2 = CxsConverter.ValueToString(((CxvViewModel)this).ResolveParameter("FRAC"));
			string text3 = CxsConverter.ValueToString(((CxvViewModel)this).ResolveParameter("UPDATE"));
			if (text3 == "PROFILE")
			{
				flag = true;
			}
			else if (text3 == "CUSTOM")
			{
				flag = true;
				flag2 = true;
			}
			if (text == "NO" && text2 == "NO")
			{
				((CxvViewModel)this).ShowMessageBox(new ShowMessageBoxEventArgs
				{
					Message = AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Estima_Genera_ViewModel_SelectOneVarToGenerate,
					Title = ((MMViewModel)this).GetProductI18nName()
				});
				return;
			}
			if (text2 == "YES")
			{
				if (flag2)
				{
					int? num10 = num6;
					if (num10.HasValue)
					{
						int? num11 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.FEED_STAGE", "child_count"));
						int? num12 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.FEED_STAGE", "child_count"));
						if (num11.HasValue && num12.HasValue)
						{
							num5 = num11.Value + num12.Value;
							if (num5 < 2)
							{
								num5 = 2;
							}
							array = new int[num5];
							int[] array2 = new int[num5];
							int num13 = 0;
							string[] array3 = CxsConverter.ValueToStringArray(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.FEED_STAGE", "child_ids"));
							string[] array4 = CxsConverter.ValueToStringArray(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.FEED_STAGE", "child_ids"));
							string[] array5 = array3;
							foreach (string text4 in array5)
							{
								int? num14 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.FEED_STAGE." + text4, "value"));
								if (num14.HasValue)
								{
									array2[num13] = num14.Value;
								}
								num13++;
							}
							array5 = array4;
							foreach (string text5 in array5)
							{
								int? num15 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.FEED_STAGE." + text5, "value"));
								if (num15.HasValue)
								{
									array2[num13] = num15.Value;
								}
								num13++;
							}
							int num16;
							for (int j = 0; j < num5 - 1; j++)
							{
								num16 = array2[j];
								for (int k = j + 1; k < num5; k++)
								{
									if (num16 > array2[k])
									{
										array2[j] = array2[k];
										array2[k] = num16;
										num16 = array2[j];
									}
								}
							}
							num16 = 0;
							num13 = 0;
							for (int l = 0; l < num5; l++)
							{
								if (num16 != array2[l])
								{
									if (array2[l] >= num10)
									{
										array[num13] = num10.Value;
										num13++;
										break;
									}
									array[num13] = array2[l];
									num16 = array2[l];
									num13++;
								}
							}
						}
					}
				}
				else if (flag)
				{
					int? num17 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X1", "child_count"));
					if (num17.HasValue)
					{
						num5 = num17.Value;
						array = new int[num5];
						for (int m = 0; m < num5; m++)
						{
							array[m] = m + 1;
						}
					}
				}
			}
			else
			{
				num5 = 0;
			}
			if (text == "YES")
			{
				if (num6 != num7)
				{
					flag3 = true;
				}
				if (!flag)
				{
					if (num8.HasValue && num8.Value != 0)
					{
						num = num8.Value;
					}
					else
					{
						flag4 = true;
					}
				}
				if (num7.HasValue && num7.Value != 0)
				{
					if (flag)
					{
						num = num7.Value;
					}
				}
				else
				{
					flag6 = true;
				}
			}
			if (text2 == "YES")
			{
				int? num18 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X1", "child_count"));
				if (num6 != num18)
				{
					flag3 = true;
				}
				Collection<string> collection = CxsConverter.ValueToStringCollection(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.X1_EST", "child_ids"));
				Collection<string> collection2 = CxsConverter.ValueToStringCollection(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X1", "child_ids"));
				if (collection != null && collection.Count > 0 && collection2 != null && collection2.Count > 0)
				{
					Collection<string> collection3 = CxsConverter.ValueToStringCollection(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.X1_EST." + collection[0], "child_ids"));
					Collection<string> collection4 = CxsConverter.ValueToStringCollection(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X1." + collection2[0], "child_ids"));
					if (collection3 != null && collection4 != null)
					{
						foreach (string item in collection3)
						{
							if (!collection4.Contains(item))
							{
								flag8 = true;
								break;
							}
						}
					}
				}
				int? num19 = null;
				if (collection != null && collection.Count > 0)
				{
					int? num20 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.X1_EST." + collection[0], "child_count"));
					if (num20.HasValue)
					{
						num19 = num20.Value;
					}
				}
				if (!flag)
				{
					int? num21 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.X2_EST", "child_count"));
					if (num9.HasValue && num9.Value != 0 && num21.HasValue && num21.Value != 0)
					{
						if (num19.HasValue)
						{
							num2 = num9.Value * num19.Value;
						}
					}
					else
					{
						flag5 = true;
					}
				}
				int? num22 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X2", "child_count"));
				if (num22.HasValue && num22.Value != 0 && num18.HasValue && num18.Value != 0)
				{
					if (flag && num19.HasValue)
					{
						num2 = num5 * num19.Value;
					}
				}
				else
				{
					flag7 = true;
				}
			}
			if (flag5 || flag4)
			{
				((CxvViewModel)this).ShowMessageBox(new ShowMessageBoxEventArgs
				{
					Message = AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Estima_Genera_ViewModel_FracError,
					Title = ((MMViewModel)this).GetProductI18nName()
				});
				return;
			}
			if (flag7 || flag6)
			{
				((CxvViewModel)this).ShowMessageBox(new ShowMessageBoxEventArgs
				{
					Message = AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Estima_Genera_ViewModel_ResultError,
					Title = ((MMViewModel)this).GetProductI18nName()
				});
				return;
			}
			if (flag3)
			{
				((CxvViewModel)this).ShowMessageBox(new ShowMessageBoxEventArgs
				{
					Message = AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Estima_Genera_ViewModel_NStageError,
					Title = ((MMViewModel)this).GetProductI18nName()
				});
				return;
			}
			if (flag8)
			{
				((CxvViewModel)this).ShowMessageBox(new ShowMessageBoxEventArgs
				{
					Message = AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Estima_Genera_ViewModel_NCompsError,
					Title = ((MMViewModel)this).GetProductI18nName()
				});
				return;
			}
			num3 = num + num2;
			MmgExtensions.GxDriveDialog2((MMViewModel)this, "ProgressBar", new object[5] { 4, 1, 0, num3, 1 });
			if (text == "YES" && !flag6)
			{
				if (flag)
				{
					string[] array6 = CxsConverter.ValueToStringArray(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.B_TEMP", "child_ids"));
					for (int n = 0; n < num7.Value; n++)
					{
						if ((double)MmgExtensions.GxDriveDialog2((MMViewModel)this, "ProgressBar", new object[2] { 2, 2 }) != 0.0)
						{
							Post_Generate();
							return;
						}
						text6 = array6[n];
						double? num23 = CxsConverter.ValueToDouble(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.B_TEMP." + text6, "value"));
						if (num23.HasValue)
						{
							string text7 = CxsConverter.ValueToString(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.B_TEMP." + text6, "uom"));
							((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.TEMP_EST." + text6, "value", text7, (object)Round(num23.Value, -1));
						}
					}
				}
				else
				{
					string[] array7 = CxsConverter.ValueToStringArray(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.TEMP_EST", "child_ids"));
					for (int num24 = 0; num24 < num8.Value; num24++)
					{
						text6 = array7[num24];
						double? num25 = CxsConverter.ValueToDouble(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.B_TEMP." + text6, "value"));
						if (num25.HasValue)
						{
							string text8 = CxsConverter.ValueToString(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.B_TEMP." + text6, "uom"));
							((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.TEMP_EST." + text6, "value", text8, (object)Round(num25.Value, -1));
						}
					}
				}
			}
			if (text2 == "YES" && !flag7)
			{
				if (flag)
				{
					ClearFracData();
					for (int num26 = 0; num26 < num5; num26++)
					{
						text9 = array[num26].ToString(CultureInfo.CurrentCulture);
						int? num27 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X1." + text9, "child_count"));
						CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X2." + text9, "child_count"));
						string[] array8 = CxsConverter.ValueToStringArray(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X1." + text9, "child_ids"));
						if (!num27.HasValue || array8 == null)
						{
							continue;
						}
						for (int num28 = 0; num28 < num27.Value; num28++)
						{
							if ((double)MmgExtensions.GxDriveDialog2((MMViewModel)this, "ProgressBar", new object[2] { 2, 2 }) != 0.0)
							{
								Post_Generate();
								return;
							}
							text10 = array8[num28];
							double? num29 = CxsConverter.ValueToDouble(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X1." + text9 + "." + text10, "value"));
							if (num29.HasValue)
							{
								num4 = num29.Value;
								if (num4 < 1E+35 && num4 > 1E-25)
								{
									((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.X1_EST." + text9, "id", (object)text9);
									((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.X1_EST." + text9 + "." + text10, "value", "", (object)SigFigs(num4, 5));
								}
							}
							double? num30 = CxsConverter.ValueToDouble(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X2." + text9 + "." + text10, "value"));
							if (num30.HasValue)
							{
								num4 = num30.Value;
								if (num4 < 1E+35 && num4 > 1E-25)
								{
									((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.X2_EST." + text9, "id", (object)text9);
									((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.X2_EST." + text9 + "." + text10, "value", "", (object)SigFigs(num4, 5));
								}
							}
						}
					}
				}
				else
				{
					string[] array9 = CxsConverter.ValueToStringArray(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.X1_EST", "child_ids"));
					for (int num31 = 0; num31 < num9.Value; num31++)
					{
						text9 = array9[num31];
						int? num32 = CxsConverter.ValueToInt32(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.X1_EST." + text9, "child_count"));
						if (!num32.HasValue)
						{
							continue;
						}
						string[] array10 = CxsConverter.ValueToStringArray(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X1." + text9, "child_ids"));
						for (int num33 = 0; num33 < num32.Value; num33++)
						{
							if ((double)MmgExtensions.GxDriveDialog2((MMViewModel)this, "ProgressBar", new object[2] { 2, 2 }) != 0.0)
							{
								Post_Generate();
								return;
							}
							text10 = array10[num33];
							double? num34 = CxsConverter.ValueToDouble(((CxvViewModel)this).ExpandDataPathAndGet("@main.Input.X1_EST." + text9 + "." + text10, "value"));
							if (num34.HasValue)
							{
								num4 = num34.Value;
								if (num4 < 1E+35 && num4 > 1E-25)
								{
									((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.X1_EST." + text9, "id", (object)text9);
									((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.X1_EST." + text9 + "." + text10, "value", "", (object)SigFigs(num4, 5));
								}
							}
							double? num35 = CxsConverter.ValueToDouble(((CxvViewModel)this).ExpandDataPathAndGet("@main.Output.X2." + text9 + "." + text10, "value"));
							if (num35.HasValue)
							{
								num4 = num35.Value;
								if (num4 < 1E+35 && num4 > 1E-25)
								{
									((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.X2_EST." + text9, "id", (object)text9);
									((CxvViewModel)this).ExpandDataPathAndSet("@main.Input.X2_EST." + text9 + "." + text10, "value", "", (object)SigFigs(num4, 5));
								}
							}
						}
					}
				}
			}
			((MMViewModel)this).CloseForm();
		}

		private void Post_Generate()
		{
			MmgExtensions.GxDriveDialog2((MMViewModel)this, "ProgressBar", new object[2] { 1, 3 });
			((MMViewModel)this).CloseForm();
			((MMViewModel)this).UpdateAll();
		}

		private static double SigFigs(double value, int places)
		{
			int num = 0;
			if (value == 0.0 || value == 1E+35)
			{
				return 0.0;
			}
			num = (int)(Math.Log(Math.Abs(value)) / Math.Log(10.0));
			return Round(value * Math.Pow(10.0, -num), -(places - 1)) * Math.Pow(10.0, num);
		}

		private static double Round(double value, int places)
		{
			return Convert.ToDouble(Convert.ToInt64(value * Math.Pow(10.0, -places))) / Math.Pow(10.0, -places);
		}

		private void ClearFracData()
		{
			string text = "@main.Input.X1_EST";
			string text2 = "@main.Input.X2_EST";
			string[] array = CxsConverter.ValueToStringArray(((CxvViewModel)this).ExpandDataPathAndGet(text, "child_ids"));
			if (array != null && array.Length != 0)
			{
				((MMViewModel)this).DeleteChildren(text, (IEnumerable<string>)array, true);
			}
			string[] array2 = CxsConverter.ValueToStringArray(((CxvViewModel)this).ExpandDataPathAndGet(text2, "child_ids"));
			if (array2 != null && array2.Length != 0)
			{
				((MMViewModel)this).DeleteChildren(text2, (IEnumerable<string>)array2, true);
			}
		}

		private void cmdClose_CommandExecute(object parameter)
		{
			((MMViewModel)this).CloseForm();
		}

		public MMExtract_Estima_Genera_ViewModel()
		{
		}

		static MMExtract_Estima_Genera_ViewModel()
		{
	MMOptionGroup1_MultiMap_Property = CxvPropertyDeclaration.Register("MMOptionGroup1_MultiMap", typeof(MMExtract_Estima_Genera_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "MMOptionGroup1_var1",
				Parameter = "UPDATE"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Currently specified stages",
				DisplayResourceKey = "MMExtract_Estima_Genera_ViewModel__CxvMultiMapOption_Display_Currently_specified_stages",
				Value = "MMOptionGroup1_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMOptionGroup1_var1",
				Value = "SPECIFIED"
			} }
				}, new CxvMultiMapOption
			{
				Display = "All stages for temperatures and flows;     Feed and product locations for compositions",
				DisplayResourceKey = "MMExtract_Estima_Genera_ViewModel__CxvMultiMapOption_Display_All_stages_for_temperatures_and_flows__",
				Value = "MMOptionGroup1_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMOptionGroup1_var1",
				Value = "CUSTOM"
			} }
				}, new CxvMultiMapOption
			{
				Display = "All stages",
				DisplayResourceKey = "MMExtract_Estima_Genera_ViewModel__CxvMultiMapOption_Display_All_stages",
				Value = "MMOptionGroup1_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "MMOptionGroup1_var1",
				Value = "PROFILE"
			} }
				} }
});
	MMCheckBox2_var1_Property = CxvPropertyDeclaration.Register("MMCheckBox2_var1", typeof(MMExtract_Estima_Genera_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
			{
				Parameter = "FRAC",
				TrueValue = "YES",
				FalseValue = "NO",
				DefaultValue = false
			});
	chkTemperature_var1_Property = CxvPropertyDeclaration.Register("chkTemperature_var1", typeof(MMExtract_Estima_Genera_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
			{
				Parameter = "TEMP",
				TrueValue = "YES",
				FalseValue = "NO",
				DefaultValue = false
			});
	}
	}
	[ProgId("MMExtract.MMExtract_Estima_Genera")]
	public class MMExtract_Estima_Genera : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraGenerate;

		internal MMCheckBox chkTemperature;

		internal MMCheckBox MMCheckBox2;

		internal MMOptionGroup MMOptionGroup1;

		internal MMOptionButton MMOptionGroup1_opt0;

		internal MMOptionButton MMOptionGroup1_opt1;

		internal MMOptionButton MMOptionGroup1_opt2;

		internal MMCmdButton cmdGenerate;

		internal MMCmdButton cmdClose;

		private bool _contentLoaded;

		public MMExtract_Estima_Genera()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Estima_Genera_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_estima_genera.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Expected O, but got Unknown
			//IL_003d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Expected O, but got Unknown
			//IL_004a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Expected O, but got Unknown
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			//IL_0061: Expected O, but got Unknown
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Expected O, but got Unknown
			//IL_0071: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Expected O, but got Unknown
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0088: Expected O, but got Unknown
			//IL_008b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0095: Expected O, but got Unknown
			//IL_0098: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a2: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraGenerate = (MMGroupBox)target;
				break;
			case 2:
				chkTemperature = (MMCheckBox)target;
				break;
			case 3:
				MMCheckBox2 = (MMCheckBox)target;
				break;
			case 4:
				MMOptionGroup1 = (MMOptionGroup)target;
				break;
			case 5:
				MMOptionGroup1_opt0 = (MMOptionButton)target;
				break;
			case 6:
				MMOptionGroup1_opt1 = (MMOptionButton)target;
				break;
			case 7:
				MMOptionGroup1_opt2 = (MMOptionButton)target;
				break;
			case 8:
				cmdGenerate = (MMCmdButton)target;
				break;
			case 9:
				cmdClose = (MMCmdButton)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Estima_Temper_ViewModel : MMTabPageViewModel
	{
		public class grdPress_Prof_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration spnSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("spnSTAGE_PRES_var1", typeof(grdPress_Prof_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.TEMP_EST.@y"
			});

			public static readonly CxvPropertyDeclaration txtSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("txtSTAGE_PRES_var1", typeof(grdPress_Prof_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.TEMP_EST.@y"
			});

			public object spnSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(spnSTAGE_PRES_var1_Property);

			public object txtSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(txtSTAGE_PRES_var1_Property);
		}

		private ICommand _cmdGenerate_Command;

		public static readonly CxvPropertyDeclaration lbtuSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("lbtuSTAGE_PRES_var1", typeof(MMExtract_Estima_Temper_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.TEMP_EST"
		});

		public static readonly CxvPropertyDeclaration grdPress_Prof_GridData_Property = CxvPropertyDeclaration.Register("grdPress_Prof_GridData", typeof(MMExtract_Estima_Temper_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdPress_Prof_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.TEMP_EST",
				UseChildId = true,
				Name = "y"
			}
		});

		public ICommand cmdGenerate_Command
		{
			get
			{
				if (_cmdGenerate_Command == null)
				{
					_cmdGenerate_Command = (ICommand)new CxvDelegateCommand<object>((Action<object>)cmdGenerate_CommandExecute);
				}
				return _cmdGenerate_Command;
			}
		}

		public object lbtuSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(lbtuSTAGE_PRES_var1_Property);

		public object grdPress_Prof_GridData => ((CxvViewModel)this).GetValue(grdPress_Prof_GridData_Property);

		private void cmdGenerate_CommandExecute(object parameter)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0047: Expected O, but got Unknown
			DisplayFormEventArgs e = new DisplayFormEventArgs
			{
				FormType = typeof(MMExtract_Estima_Genera),
				LegacyFlags = 0,
				HelpId = 62,
				HelpFile = "Extract.hlp",
				ShowPrompts = false,
				ShortName = AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Estima_Compos_ViewModel_GenerateCommandHeader
			};
			e.Parameters.Add("TEMP", "YES");
			e.Parameters.Add("FRAC", "NO");
			e.Parameters.Add("UPDATE", "CUSTOM");
			((MMViewModel)this).DisplayForm(e);
		}
	}
	[ProgId("MMExtract.MMExtract_Estima_Temper")]
	public class MMExtract_Estima_Temper : MMTabPage, IComponentConnector
	{
		internal MMLabel fraPress_Profile;

		internal MMCmdButton cmdGenerate;

		internal MMScrollArea grdPress_Prof;

		private bool _contentLoaded;

		public MMExtract_Estima_Temper()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Estima_Temper_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_estima_temper.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Expected O, but got Unknown
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraPress_Profile = (MMLabel)target;
				break;
			case 2:
				cmdGenerate = (MMCmdButton)target;
				break;
			case 3:
				grdPress_Prof = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_KLL_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration KLLA_Property = CxvPropertyDeclaration.Register("KLLA", typeof(MMExtract_KLL_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.KLLA"
		});

		public static readonly CxvPropertyDeclaration KLLB_Property = CxvPropertyDeclaration.Register("KLLB", typeof(MMExtract_KLL_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.KLLB"
		});

		public static readonly CxvPropertyDeclaration KLL_Property = CxvPropertyDeclaration.Register("KLL", typeof(MMExtract_KLL_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.KLL"
		});

		public static readonly CxvPropertyDeclaration KLT_Property = CxvPropertyDeclaration.Register("KLT", typeof(MMExtract_KLL_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.KLT"
		});

		public static readonly CxvPropertyDeclaration SUBR_Property = CxvPropertyDeclaration.Register("SUBR", typeof(MMExtract_KLL_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SUBR"
		});

		public static readonly CxvPropertyDeclaration KLL1_Property = CxvPropertyDeclaration.Register("KLL1", typeof(MMExtract_KLL_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.KLL1"
		});

		public static readonly CxvPropertyDeclaration UENTOPTKLL_Property = CxvPropertyDeclaration.Register("UENTOPTKLL", typeof(MMExtract_KLL_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTOPTKLL"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMExtract_KLL_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@UENTOPTKLL" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMExtract_KLL_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@KLL", "@KLL1", "@KLT" },
			AccessibleDataPaths = { "@KLLA" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMExtract_KLL_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@SUBR" },
			AccessibleDataPaths = { "@KLLB" }
		});

		public object KLLA => ((CxvViewModel)this).GetValue(KLLA_Property);

		public object KLLB => ((CxvViewModel)this).GetValue(KLLB_Property);

		public object KLL => ((CxvViewModel)this).GetValue(KLL_Property);

		public object KLT => ((CxvViewModel)this).GetValue(KLT_Property);

		public object SUBR => ((CxvViewModel)this).GetValue(SUBR_Property);

		public object KLL1 => ((CxvViewModel)this).GetValue(KLL1_Property);

		public object UENTOPTKLL => ((CxvViewModel)this).GetValue(UENTOPTKLL_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);
	}
	[ProgId("MMExtract.MMExtract_KLL")]
	public class MMExtract_KLL : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabSubroutine;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		private bool _contentLoaded;

		public MMExtract_KLL()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_KLL_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_kll.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabSubroutine = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_KLL_KLLCor_ViewModel : MMTabPageViewModel
	{
		public class grdCorrelations_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(grdCorrelations_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.KLL_D.@x"
			});

			public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(grdCorrelations_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.KLL_C.@x"
			});

			public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(grdCorrelations_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.KLL_B.@x"
			});

			public static readonly CxvPropertyDeclaration txtKLL_CID_var1_Property = CxvPropertyDeclaration.Register("txtKLL_CID_var1", typeof(grdCorrelations_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.KLL_A.@x"
			});

			public static readonly CxvPropertyDeclaration cboKLL_CIDa_var1_Property = CxvPropertyDeclaration.Register("cboKLL_CIDa_var1", typeof(grdCorrelations_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.KLL_A.@x"
			});

			public object MMTextBox3_var1 => ((CxvViewModel)this).GetValue(MMTextBox3_var1_Property);

			public object MMTextBox2_var1 => ((CxvViewModel)this).GetValue(MMTextBox2_var1_Property);

			public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);

			public object txtKLL_CID_var1 => ((CxvViewModel)this).GetValue(txtKLL_CID_var1_Property);

			public object cboKLL_CIDa_var1 => ((CxvViewModel)this).GetValue(cboKLL_CIDa_var1_Property);
		}

		public static readonly CxvPropertyDeclaration cboKLL_BASIS_MultiMap_Property;

		public static readonly CxvPropertyDeclaration grdCorrelations_GridData_Property;

		public object cboKLL_BASIS_MultiMap => ((CxvViewModel)this).GetValue(cboKLL_BASIS_MultiMap_Property);

		public object grdCorrelations_GridData => ((CxvViewModel)this).GetValue(grdCorrelations_GridData_Property);

		public MMExtract_KLL_KLLCor_ViewModel()
		{
		}

		static MMExtract_KLL_KLLCor_ViewModel()
		{
	cboKLL_BASIS_MultiMap_Property = CxvPropertyDeclaration.Register("cboKLL_BASIS_MultiMap", typeof(MMExtract_KLL_KLLCor_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboKLL_BASIS_var1",
				DataPath = "@main.Input.KLL_BASIS"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Mole",
				DisplayResourceKey = "MMExtract_KLL_KLLCor_ViewModel__CxvMultiMapOption_Display_Mole",
				Value = "cboKLL_BASIS_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboKLL_BASIS_var1",
				Value = "MOLE"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Mass",
				DisplayResourceKey = "MMExtract_KLL_KLLCor_ViewModel__CxvMultiMapOption_Display_Mass",
				Value = "cboKLL_BASIS_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboKLL_BASIS_var1",
				Value = "MASS"
			} }
				}, new CxvMultiMapOption
			{
				Display = "StdVol",
				DisplayResourceKey = "MMExtract_KLL_KLLCor_ViewModel__CxvMultiMapOption_Display_StdVol",
				Value = "cboKLL_BASIS_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboKLL_BASIS_var1",
				Value = "STDVOL"
			} }
				} }
});
	grdCorrelations_GridData_Property = CxvPropertyDeclaration.Register("grdCorrelations_GridData", typeof(MMExtract_KLL_KLLCor_ViewModel), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdCorrelations_GridData_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@main.Input.KLL_A",
					UseChildId = false,
					Name = "x"
				}
			});
	}
	}
	[ProgId("MMExtract.MMExtract_KLL_KLLCor")]
	public class MMExtract_KLL_KLLCor : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraLiqid;

		internal MMLabel cboKLL_BASIS_label;

		internal MMComboEdit cboKLL_BASIS;

		internal MMLabel lblBasis_1;

		internal MMScrollAreaHorizontal grdCorrelations;

		private bool _contentLoaded;

		public MMExtract_KLL_KLLCor()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_KLL_KLLCor_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_kll_kllcor.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Expected O, but got Unknown
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Expected O, but got Unknown
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Expected O, but got Unknown
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraLiqid = (MMGroupBox)target;
				break;
			case 2:
				cboKLL_BASIS_label = (MMLabel)target;
				break;
			case 3:
				cboKLL_BASIS = (MMComboEdit)target;
				break;
			case 4:
				lblBasis_1 = (MMLabel)target;
				break;
			case 5:
				grdCorrelations = (MMScrollAreaHorizontal)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_KLL_KLLSub_ViewModel : MMTabPageViewModel
	{
		public class grdParamArray_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtReal_RVALUE_LIST_Property = CxvPropertyDeclaration.Register("txtReal_RVALUE_LIST", typeof(grdParamArray_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.RVALUE_LIST.@Row"
			});

			public static readonly CxvPropertyDeclaration txtInteger_VALUE_LIST_Property = CxvPropertyDeclaration.Register("txtInteger_VALUE_LIST", typeof(grdParamArray_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.VALUE_LIST.@Row"
			});

			public static readonly CxvPropertyDeclaration txtRowNo_RowNo_Property = CxvPropertyDeclaration.Register("txtRowNo_RowNo", typeof(grdParamArray_GridData_ItemTemplate), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "Row",
				IsReadOnly = true,
				Converter = typeof(CxvIndexToRowConverter)
			});

			public static readonly CxvPropertyDeclaration snpInteger_valuelist_Property = CxvPropertyDeclaration.Register("snpInteger_valuelist", typeof(grdParamArray_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.PIVALUE_LIST.@row"
			});

			public object txtReal_RVALUE_LIST => ((CxvViewModel)this).GetValue(txtReal_RVALUE_LIST_Property);

			public object txtInteger_VALUE_LIST => ((CxvViewModel)this).GetValue(txtInteger_VALUE_LIST_Property);

			public object txtRowNo_RowNo => ((CxvViewModel)this).GetValue(txtRowNo_RowNo_Property);

			public object snpInteger_valuelist => ((CxvViewModel)this).GetValue(snpInteger_valuelist_Property);

			public grdParamArray_GridData_ItemTemplate()
			{
				((CxvViewModel)this).NotifyUpdates = false;
			}
		}

		public static readonly CxvPropertyDeclaration lbtuSubModel_KLL_Property = CxvPropertyDeclaration.Register("lbtuSubModel_KLL", typeof(MMExtract_KLL_KLLSub_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.KLL",
			DisplayedCase = (CxsDisplayedCase)1
		});

		public static readonly CxvPropertyDeclaration spnInteger_NINT_Property = CxvPropertyDeclaration.Register("spnInteger_NINT", typeof(MMExtract_KLL_KLLSub_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.NINT"
		});

		public static readonly CxvPropertyDeclaration spnReal_NREAL_Property = CxvPropertyDeclaration.Register("spnReal_NREAL", typeof(MMExtract_KLL_KLLSub_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.NREAL"
		});

		public static readonly CxvPropertyDeclaration grdParamArray_Int_GridData_Property = CxvPropertyDeclaration.Register("grdParamArray_Int_GridData", typeof(MMExtract_KLL_KLLSub_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdParamArray_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.VALUE_LIST",
				UseChildId = true,
				ProxyRow = false,
				Name = "Row"
			},
			IsVisibleCondition = new CxvLogicalTest
			{
				Parameter = "ParamArrayIntVisible",
				Operator = (CxvLogicalOperator)0,
				Value = "1"
			}
		});

		public static readonly CxvPropertyDeclaration grdParamArray_Real_GridData_Property = CxvPropertyDeclaration.Register("grdParamArray_Real_GridData", typeof(MMExtract_KLL_KLLSub_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdParamArray_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.RVALUE_LIST",
				UseChildId = true,
				ProxyRow = false,
				Name = "Row"
			},
			IsVisibleCondition = new CxvLogicalTest
			{
				Parameter = "ParamArrayRealVisible",
				Operator = (CxvLogicalOperator)0,
				Value = "1"
			}
		});

		public object lbtuSubModel_KLL => ((CxvViewModel)this).GetValue(lbtuSubModel_KLL_Property);

		public object spnInteger_NINT => ((CxvViewModel)this).GetValue(spnInteger_NINT_Property);

		public object spnReal_NREAL => ((CxvViewModel)this).GetValue(spnReal_NREAL_Property);

		public object grdParamArray_Int_GridData => ((CxvViewModel)this).GetValue(grdParamArray_Int_GridData_Property);

		public object grdParamArray_Real_GridData => ((CxvViewModel)this).GetValue(grdParamArray_Real_GridData_Property);

		protected override void OnSubPropertyDataChanged(CxvPropertyDeclaration pd, string subPropertyName)
		{
			if ((pd.Name == "spnInteger_NINT" || pd.Name == "spnReal_NREAL") && subPropertyName == "Value")
			{
				ChangeGridVisiblity();
			}
			base.OnSubPropertyDataChanged(pd, subPropertyName);
		}

		private void ChangeGridVisiblity()
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			int? num = CxsConverter.ValueToInt32(((CxvVariableData)spnInteger_NINT).Value);
			int? num2 = CxsConverter.ValueToInt32(((CxvVariableData)spnReal_NREAL).Value);
			CxvVectorPropertyData val = grdParamArray_Int_GridData as CxvVectorPropertyData;
			CxvVectorPropertyData val2 = grdParamArray_Real_GridData as CxvVectorPropertyData;
			if (num.HasValue && num2.HasValue && num.HasValue && num2.HasValue)
			{
			if (num.Value >= num2.Value)
			{
				((CxvViewModel)this).ResolveUpdateParameter("ParamArrayIntVisible", (object)"1");
				((CxvViewModel)this).ResolveUpdateParameter("ParamArrayRealVisible", (object)"0");
				for (int i = 0; i < num2.Value; i++)
				{
					if (i < val.Count && val[i] is grdParamArray_GridData_ItemTemplate grdParamArray_GridData_ItemTemplate)
					{
						((grdParamArray_GridData_ItemTemplate.txtReal_RVALUE_LIST as CxvVariableData)).UnsetReadOnly();
						((grdParamArray_GridData_ItemTemplate.txtReal_RVALUE_LIST as CxvVariableData)).IsCalculated = null;
					}
				}
				for (int j = num2.Value; j < num.Value; j++)
				{
					if (j < val.Count && val[j] is grdParamArray_GridData_ItemTemplate grdParamArray_GridData_ItemTemplate2)
					{
						((grdParamArray_GridData_ItemTemplate2.txtReal_RVALUE_LIST as CxvVariableData)).IsReadOnly = true;
						((grdParamArray_GridData_ItemTemplate2.txtReal_RVALUE_LIST as CxvVariableData)).IsCalculated = false;
					}
				}
				return;
			}
			((CxvViewModel)this).ResolveUpdateParameter("ParamArrayIntVisible", (object)"0");
			((CxvViewModel)this).ResolveUpdateParameter("ParamArrayRealVisible", (object)"1");
			for (int k = 0; k < num.Value; k++)
			{
				if (k < val2.Count && val2[k] is grdParamArray_GridData_ItemTemplate grdParamArray_GridData_ItemTemplate3)
				{
					((grdParamArray_GridData_ItemTemplate3.snpInteger_valuelist as CxvVariableData)).UnsetReadOnly();
					((grdParamArray_GridData_ItemTemplate3.snpInteger_valuelist as CxvVariableData)).IsCalculated = null;
				}
			}
			for (int l = num.Value; l < num2.Value; l++)
			{
				if (l < val2.Count && val2[l] is grdParamArray_GridData_ItemTemplate grdParamArray_GridData_ItemTemplate4)
				{
					((grdParamArray_GridData_ItemTemplate4.snpInteger_valuelist as CxvVariableData)).IsReadOnly = true;
					((grdParamArray_GridData_ItemTemplate4.snpInteger_valuelist as CxvVariableData)).IsCalculated = false;
				}
			}
		}
		}
	}
	[ProgId("MMExtract.MMExtract_KLL_KLLSub")]
	public class MMExtract_KLL_KLLSub : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMLabel lbtuSubModel_label;

		internal MMVariableEdit lbtuSubModel;

		internal MMGroupBox MMFrame5;

		internal MMLabel spnInteger_label;

		internal MMSpinBox spnInteger;

		internal MMLabel spnReal_label;

		internal MMSpinBox spnReal;

		internal MMLabel MMLabel7;

		internal MMGroupBox MMFrame4;

		internal MMScrollArea grdParamArray_Int;

		internal MMScrollArea grdParamArray_Real;

		private bool _contentLoaded;

		public MMExtract_KLL_KLLSub()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_KLL_KLLSub_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_kll_kllsub.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Expected O, but got Unknown
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0056: Expected O, but got Unknown
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Expected O, but got Unknown
			//IL_0066: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Expected O, but got Unknown
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_007d: Expected O, but got Unknown
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Expected O, but got Unknown
			//IL_008d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0097: Expected O, but got Unknown
			//IL_009a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a4: Expected O, but got Unknown
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Expected O, but got Unknown
			//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00be: Expected O, but got Unknown
			//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cb: Expected O, but got Unknown
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d8: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				lbtuSubModel_label = (MMLabel)target;
				break;
			case 3:
				lbtuSubModel = (MMVariableEdit)target;
				break;
			case 4:
				MMFrame5 = (MMGroupBox)target;
				break;
			case 5:
				spnInteger_label = (MMLabel)target;
				break;
			case 6:
				spnInteger = (MMSpinBox)target;
				break;
			case 7:
				spnReal_label = (MMLabel)target;
				break;
			case 8:
				spnReal = (MMSpinBox)target;
				break;
			case 9:
				MMLabel7 = (MMLabel)target;
				break;
			case 10:
				MMFrame4 = (MMGroupBox)target;
				break;
			case 11:
				grdParamArray_Int = (MMScrollArea)target;
				break;
			case 12:
				grdParamArray_Real = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_KLL_Option_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration ogrKLL_Corr_MultiMap_Property;

		public object ogrKLL_Corr_MultiMap => ((CxvViewModel)this).GetValue(ogrKLL_Corr_MultiMap_Property);

		public MMExtract_KLL_Option_ViewModel()
		{
		}

		static MMExtract_KLL_Option_ViewModel()
		{
	ogrKLL_Corr_MultiMap_Property = CxvPropertyDeclaration.Register("ogrKLL_Corr_MultiMap", typeof(MMExtract_KLL_Option_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "ogrKLL_Corr_OPT_KLL",
				DataPath = "@main.Input.OPT_KLL"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Property method",
				DisplayResourceKey = "MMExtract_KLL_Option_ViewModel__CxvMultiMapOption_Display_Property_method",
				Value = "ogrKLL_Corr_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrKLL_Corr_OPT_KLL",
				Value = "PROPMETH"
			} }
				}, new CxvMultiMapOption
			{
				Display = "KLL correlation",
				DisplayResourceKey = "MMExtract_KLL_Option_ViewModel__CxvMultiMapOption_Display_KLL_correlation",
				Value = "ogrKLL_Corr_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrKLL_Corr_OPT_KLL",
				Value = "COEFFICIENT"
			} }
				}, new CxvMultiMapOption
			{
				Display = "User KLL subroutine",
				DisplayResourceKey = "MMExtract_KLL_Option_ViewModel__CxvMultiMapOption_Display_User_KLL_subroutine",
				Value = "ogrKLL_Corr_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrKLL_Corr_OPT_KLL",
				Value = "SUBROUTINE"
			} }
				} }
});
	}
	}
	[ProgId("MMExtract.MMExtract_KLL_Option")]
	public class MMExtract_KLL_Option : MMTabPage, IComponentConnector
	{
		internal MMOptionGroup ogrKLL_Corr;

		internal MMOptionButton ogrKLL_Corr_opt0;

		internal MMOptionButton ogrKLL_Corr_opt1;

		internal MMOptionButton ogrKLL_Corr_opt2;

		private bool _contentLoaded;

		public MMExtract_KLL_Option()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_KLL_Option_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_kll_option.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				ogrKLL_Corr = (MMOptionGroup)target;
				break;
			case 2:
				ogrKLL_Corr_opt0 = (MMOptionButton)target;
				break;
			case 3:
				ogrKLL_Corr_opt1 = (MMOptionButton)target;
				break;
			case 4:
				ogrKLL_Corr_opt2 = (MMOptionButton)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Profil_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration ExComp_Property = CxvPropertyDeclaration.Register("ExComp", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "ExComp"
		});

		public static readonly CxvPropertyDeclaration property_Property = CxvPropertyDeclaration.Register("property", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "property"
		});

		public static readonly CxvPropertyDeclaration tpfq_Property = CxvPropertyDeclaration.Register("tpfq", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "tpfq"
		});

		public static readonly CxvPropertyDeclaration one_Property = CxvPropertyDeclaration.Register("one", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "one"
		});

		public static readonly CxvPropertyDeclaration two_Property = CxvPropertyDeclaration.Register("two", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "two"
		});

		public static readonly CxvPropertyDeclaration three_Property = CxvPropertyDeclaration.Register("three", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "three"
		});

		public static readonly CxvPropertyDeclaration four_Property = CxvPropertyDeclaration.Register("four", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "four"
		});

		public static readonly CxvPropertyDeclaration five_Property = CxvPropertyDeclaration.Register("five", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "five"
		});

		public static readonly CxvPropertyDeclaration six_Property = CxvPropertyDeclaration.Register("six", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "six"
		});

		public static readonly CxvPropertyDeclaration seven_Property = CxvPropertyDeclaration.Register("seven", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "seven"
		});

		public static readonly CxvPropertyDeclaration eight_Property = CxvPropertyDeclaration.Register("eight", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "eight"
		});

		public static readonly CxvPropertyDeclaration nine_Property = CxvPropertyDeclaration.Register("nine", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "nine"
		});

		public static readonly CxvPropertyDeclaration ten_Property = CxvPropertyDeclaration.Register("ten", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "ten"
		});

		public static readonly CxvPropertyDeclaration eleven_Property = CxvPropertyDeclaration.Register("eleven", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "eleven"
		});

		public static readonly CxvPropertyDeclaration X1_Property = CxvPropertyDeclaration.Register("X1", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X1"
		});

		public static readonly CxvPropertyDeclaration X2_Property = CxvPropertyDeclaration.Register("X2", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.X2"
		});

		public static readonly CxvPropertyDeclaration KLL_OUT_Property = CxvPropertyDeclaration.Register("KLL_OUT", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.KLL_OUT"
		});

		public static readonly CxvPropertyDeclaration B_TEMP_Property = CxvPropertyDeclaration.Register("B_TEMP", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_TEMP"
		});

		public static readonly CxvPropertyDeclaration B_PRES_Property = CxvPropertyDeclaration.Register("B_PRES", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.B_PRES"
		});

		public static readonly CxvPropertyDeclaration TRAY_REP_Property = CxvPropertyDeclaration.Register("TRAY_REP", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.Prop Data.TRAY_REP"
		});

		public static readonly CxvPropertyDeclaration EFFICIENCY_Property = CxvPropertyDeclaration.Register("EFFICIENCY", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMP_EFF"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@B_PRES", "@B_TEMP" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@X1", "@X2" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@KLL_OUT" }
		});

		public static readonly CxvPropertyDeclaration tab3_var_Property = CxvPropertyDeclaration.Register("tab3_var", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@EFFICIENCY" }
		});

		public static readonly CxvPropertyDeclaration tab4_var_Property = CxvPropertyDeclaration.Register("tab4_var", typeof(MMExtract_Profil_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@TRAY_REP" }
		});

		public object ExComp => ((CxvViewModel)this).GetValue(ExComp_Property);

		public object property => ((CxvViewModel)this).GetValue(property_Property);

		public object tpfq => ((CxvViewModel)this).GetValue(tpfq_Property);

		public object one => ((CxvViewModel)this).GetValue(one_Property);

		public object two => ((CxvViewModel)this).GetValue(two_Property);

		public object three => ((CxvViewModel)this).GetValue(three_Property);

		public object four => ((CxvViewModel)this).GetValue(four_Property);

		public object five => ((CxvViewModel)this).GetValue(five_Property);

		public object six => ((CxvViewModel)this).GetValue(six_Property);

		public object seven => ((CxvViewModel)this).GetValue(seven_Property);

		public object eight => ((CxvViewModel)this).GetValue(eight_Property);

		public object nine => ((CxvViewModel)this).GetValue(nine_Property);

		public object ten => ((CxvViewModel)this).GetValue(ten_Property);

		public object eleven => ((CxvViewModel)this).GetValue(eleven_Property);

		public object X1 => ((CxvViewModel)this).GetValue(X1_Property);

		public object X2 => ((CxvViewModel)this).GetValue(X2_Property);

		public object KLL_OUT => ((CxvViewModel)this).GetValue(KLL_OUT_Property);

		public object B_TEMP => ((CxvViewModel)this).GetValue(B_TEMP_Property);

		public object B_PRES => ((CxvViewModel)this).GetValue(B_PRES_Property);

		public object TRAY_REP => ((CxvViewModel)this).GetValue(TRAY_REP_Property);

		public object EFFICIENCY => ((CxvViewModel)this).GetValue(EFFICIENCY_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);

		public object tab3_var => ((CxvViewModel)this).GetValue(tab3_var_Property);

		public object tab4_var => ((CxvViewModel)this).GetValue(tab4_var_Property);
	}
	[ProgId("MMExtract.MMExtract_Profil")]
	public class MMExtract_Profil : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabProfiles;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem tab3;

		internal MMTabItem tab4;

		private bool _contentLoaded;

		public MMExtract_Profil()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Profil_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_profil.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Expected O, but got Unknown
			//IL_0031: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Expected O, but got Unknown
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Expected O, but got Unknown
			//IL_004b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Expected O, but got Unknown
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_0062: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabProfiles = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				tab3 = (MMTabItem)target;
				break;
			case 6:
				tab4 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Profil_Compos_ViewModel : MMTabPageViewModel
	{
		public class grdX5_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtX5_2_var1_Property = CxvPropertyDeclaration.Register("txtX5_2_var1", typeof(grdX5_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@compoutp.@y",
				DisplayedCase = (CxsDisplayedCase)1
			});

			public static readonly CxvPropertyDeclaration inner_Property = CxvPropertyDeclaration.Register("inner", typeof(grdX5_GridData_ItemTemplate), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdX5_GridData_ItemTemplate_inner_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@compoutp.@y",
					UseChildId = true,
					Name = "x"
				}
			});

			public object txtX5_2_var1 => ((CxvViewModel)this).GetValue(txtX5_2_var1_Property);

			public object inner => ((CxvViewModel)this).GetValue(inner_Property);
		}

		public class grdX5_GridData_ItemTemplate_inner_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtX5_0_var1_Property = CxvPropertyDeclaration.Register("txtX5_0_var1", typeof(grdX5_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "x"
			});

			public static readonly CxvPropertyDeclaration txtX5_1_var1_Property = CxvPropertyDeclaration.Register("txtX5_1_var1", typeof(grdX5_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@compoutp.@y.@x"
			});

			public object txtX5_0_var1 => ((CxvViewModel)this).GetValue(txtX5_0_var1_Property);

			public object txtX5_1_var1 => ((CxvViewModel)this).GetValue(txtX5_1_var1_Property);
		}

		public static CxvPropertyDeclaration Basis_Selected_Property = CxvPropertyDeclaration.Register("Basis_Selected", typeof(MMExtract_Profil_Compos_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "bcomp"
		});

		public static CxvPropertyDeclaration advcboBasis_AdvCollection_Property = CxvPropertyDeclaration.Register("advcboBasis_AdvCollection", typeof(MMExtract_Profil_Compos_ViewModel), (CxvPropertyBase)new CxvAdvCollectionProperty
		{
			UseItemsCollection = true,
			Items = 
			{
				new CxvAdvCollectionItem
				{
					Display = "Mole",
					DisplayResourceKey = "MMRadfrac_Profil_Compos_ViewModel__CxvAdvCollectionItem_Display_Mole"
				},
				new CxvAdvCollectionItem
				{
					Display = "Mass",
					DisplayResourceKey = "MMRadfrac_Profil_Compos_ViewModel__CxvAdvCollectionItem_Display_Mass"
				}
			},
			SelectedItemBinding = "Basis_Selected.Value",
			IsCalculated = true
		});

		public static readonly CxvPropertyDeclaration grdX5_GridData_Property = CxvPropertyDeclaration.Register("grdX5_GridData", typeof(MMExtract_Profil_Compos_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdX5_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@compoutp",
				UseChildId = true,
				Name = "y"
			}
		});

		public static CxvPropertyDeclaration Views_Selected_Property = CxvPropertyDeclaration.Register("Views_Selected", typeof(MMExtract_Profil_Compos_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "ExComp"
		});

		public static CxvPropertyDeclaration advcboExComp_AdvCollection_Property = CxvPropertyDeclaration.Register("advcboExComp_AdvCollection", typeof(MMExtract_Profil_Compos_ViewModel), (CxvPropertyBase)new CxvAdvCollectionProperty
		{
			UseItemsCollection = true,
			Items = 
			{
				new CxvAdvCollectionItem
				{
					Display = "1st liquid",
					DisplayResourceKey = "MMExtract_Profil_Compos_ViewModel__CxvAdvCollectionItem_Display_1st_liquid"
				},
				new CxvAdvCollectionItem
				{
					Display = "2nd liquid",
					DisplayResourceKey = "MMExtract_Profil_Compos_ViewModel__CxvAdvCollectionItem_Display_2nd_liquid"
				}
			},
			SelectedItemBinding = "Views_Selected.Value",
			CreateNewPrompt = "View:",
			CreateNewPromptResourceKey = "MMExtract_Profil_Compos_ViewModel__CxvAdvCollectionProperty_CreateNewPrompt_View_",
			IsCalculated = true
		});

		public static CxvPropertyDeclaration compoutp_Property;

		public object Basis_Selected => ((CxvViewModel)this).GetValue(Basis_Selected_Property);

		public object advcboBasis_AdvCollection => ((CxvViewModel)this).GetValue(advcboBasis_AdvCollection_Property);

		public object grdX5_GridData => ((CxvViewModel)this).GetValue(grdX5_GridData_Property);

		public object Views_Selected => ((CxvViewModel)this).GetValue(Views_Selected_Property);

		public object advcboExComp_AdvCollection => ((CxvViewModel)this).GetValue(advcboExComp_AdvCollection_Property);

		public object compoutp => ((CxvViewModel)this).GetValue(compoutp_Property);

		public MMExtract_Profil_Compos_ViewModel()
		{
		}

		static MMExtract_Profil_Compos_ViewModel()
		{
	compoutp_Property = CxvPropertyDeclaration.Register("compoutp", typeof(MMExtract_Profil_Compos_ViewModel), (CxvPropertyBase)new CxvPropertySelector
			{
				Choices = 
				{
				new CxvPropertyChoice
				{
					Conditions = 
					{
						new CxvLogicalTest
						{
							PropertyPath = "Views_Selected.Value",
							Value = "1st liquid"
						},
						new CxvLogicalTest
						{
							PropertyPath = "Basis_Selected.Value",
							Value = "Mole"
						}
					},
					Operator = (CxvLogicalOperator)8,
					Property = (CxvPropertyBase)new CxvVariableProperty
					{
						DataPath = "@main.Output.X1"
					}
				},
				new CxvPropertyChoice
				{
					Conditions = 
					{
						new CxvLogicalTest
						{
							PropertyPath = "Views_Selected.Value",
							Value = "2nd liquid"
						},
						new CxvLogicalTest
						{
							PropertyPath = "Basis_Selected.Value",
							Value = "Mole"
						}
					},
					Operator = (CxvLogicalOperator)8,
					Property = (CxvPropertyBase)new CxvVariableProperty
					{
						DataPath = "@main.Output.X2"
					}
				},
				new CxvPropertyChoice
				{
					Conditions = 
					{
						new CxvLogicalTest
						{
							PropertyPath = "Views_Selected.Value",
							Value = "1st liquid"
						},
						new CxvLogicalTest
						{
							PropertyPath = "Basis_Selected.Value",
							Value = "Mass"
						}
					},
					Operator = (CxvLogicalOperator)8,
					Property = (CxvPropertyBase)new CxvVariableProperty
					{
						DataPath = "@main.Output.X1_MS"
					}
				},
				new CxvPropertyChoice
				{
					Conditions = 
					{
						new CxvLogicalTest
						{
							PropertyPath = "Views_Selected.Value",
							Value = "2nd liquid"
						},
						new CxvLogicalTest
						{
							PropertyPath = "Basis_Selected.Value",
							Value = "Mass"
						}
					},
					Operator = (CxvLogicalOperator)8,
					Property = (CxvPropertyBase)new CxvVariableProperty
					{
						DataPath = "@main.Output.X2_MS"
					}
				}
				}
			});
	}
	}
	[ProgId("MMExtract.MMExtract_Profil_Compos")]
	public class MMExtract_Profil_Compos : MMTabPage, IComponentConnector
	{
		internal MMLabel advcboExComp_label;

		internal MMComboEdit advcboExComp;

		internal MMLabel advcboBasis_label;

		internal MMComboEdit advcboBasis;

		internal MMGroupBox fr1;

		internal MMScrollAreaMS grdX5;

		private bool _contentLoaded;

		public MMExtract_Profil_Compos()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Profil_Compos_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_profil_compos.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Expected O, but got Unknown
			//IL_0031: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Expected O, but got Unknown
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Expected O, but got Unknown
			//IL_004b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Expected O, but got Unknown
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_0062: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				advcboExComp_label = (MMLabel)target;
				break;
			case 2:
				advcboExComp = (MMComboEdit)target;
				break;
			case 3:
				advcboBasis_label = (MMLabel)target;
				break;
			case 4:
				advcboBasis = (MMComboEdit)target;
				break;
			case 5:
				fr1 = (MMGroupBox)target;
				break;
			case 6:
				grdX5 = (MMScrollAreaMS)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Profil_Effici_ViewModel : MMTabPageViewModel
	{
		public class grdComp_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtBK2_var1_Property = CxvPropertyDeclaration.Register("txtBK2_var1", typeof(grdComp_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@effoutp.@y",
				DisplayedCase = (CxsDisplayedCase)1
			});

			public static readonly CxvPropertyDeclaration inner_Property = CxvPropertyDeclaration.Register("inner", typeof(grdComp_GridData_ItemTemplate), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdComp_GridData_ItemTemplate_inner_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@effoutp.#0",
					UseChildId = true,
					Name = "x"
				}
			});

			public object txtBK2_var1 => ((CxvViewModel)this).GetValue(txtBK2_var1_Property);

			public object inner => ((CxvViewModel)this).GetValue(inner_Property);
		}

		public class grdComp_GridData_ItemTemplate_inner_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtY_4_var1_Property = CxvPropertyDeclaration.Register("txtY_4_var1", typeof(grdComp_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "x"
			});

			public static readonly CxvPropertyDeclaration txtCOMP_EFF_var1_Property = CxvPropertyDeclaration.Register("txtCOMP_EFF_var1", typeof(grdComp_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@effoutp.@y.@x"
			});

			public object txtY_4_var1 => ((CxvViewModel)this).GetValue(txtY_4_var1_Property);

			public object txtCOMP_EFF_var1 => ((CxvViewModel)this).GetValue(txtCOMP_EFF_var1_Property);
		}

		public static readonly CxvPropertyDeclaration effoutp_Property = CxvPropertyDeclaration.Register("effoutp", typeof(MMExtract_Profil_Effici_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COMP_EFF"
		});

		public static readonly CxvPropertyDeclaration grdComp_GridData_Property = CxvPropertyDeclaration.Register("grdComp_GridData", typeof(MMExtract_Profil_Effici_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdComp_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@effoutp",
				UseChildId = true,
				Name = "y"
			}
		});

		public object effoutp => ((CxvViewModel)this).GetValue(effoutp_Property);

		public object grdComp_GridData => ((CxvViewModel)this).GetValue(grdComp_GridData_Property);
	}
	[ProgId("MMExtract.MMExtract_Profil_Effici")]
	public class MMExtract_Profil_Effici : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraCmpEff;

		internal MMScrollAreaMS grdComp;

		private bool _contentLoaded;

		public MMExtract_Profil_Effici()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Profil_Effici_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_profil_effici.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraCmpEff = (MMGroupBox)target;
				break;
			case 2:
				grdComp = (MMScrollAreaMS)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Profil_KValue_ViewModel : MMTabPageViewModel
	{
		public class grdX2_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtY_3_var1_Property = CxvPropertyDeclaration.Register("txtY_3_var1", typeof(grdX2_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@koutp.@y",
				DisplayedCase = (CxsDisplayedCase)1
			});

			public static readonly CxvPropertyDeclaration inner_Property = CxvPropertyDeclaration.Register("inner", typeof(grdX2_GridData_ItemTemplate), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdX2_GridData_ItemTemplate_inner_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@koutp.#0",
					UseChildId = true,
					Name = "x"
				}
			});

			public object txtY_3_var1 => ((CxvViewModel)this).GetValue(txtY_3_var1_Property);

			public object inner => ((CxvViewModel)this).GetValue(inner_Property);
		}

		public class grdX2_GridData_ItemTemplate_inner_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtY_4_var1_Property = CxvPropertyDeclaration.Register("txtY_4_var1", typeof(grdX2_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "x"
			});

			public static readonly CxvPropertyDeclaration txtY_5_var1_Property = CxvPropertyDeclaration.Register("txtY_5_var1", typeof(grdX2_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@koutp.@y.@x"
			});

			public object txtY_4_var1 => ((CxvViewModel)this).GetValue(txtY_4_var1_Property);

			public object txtY_5_var1 => ((CxvViewModel)this).GetValue(txtY_5_var1_Property);
		}

		public static readonly CxvPropertyDeclaration koutp_Property = CxvPropertyDeclaration.Register("koutp", typeof(MMExtract_Profil_KValue_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.KLL_OUT"
		});

		public static readonly CxvPropertyDeclaration grdX2_GridData_Property = CxvPropertyDeclaration.Register("grdX2_GridData", typeof(MMExtract_Profil_KValue_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdX2_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@koutp",
				UseChildId = true,
				Name = "y"
			}
		});

		public object koutp => ((CxvViewModel)this).GetValue(koutp_Property);

		public object grdX2_GridData => ((CxvViewModel)this).GetValue(grdX2_GridData_Property);
	}
	[ProgId("MMExtract.MMExtract_Profil_KValue")]
	public class MMExtract_Profil_KValue : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraKvalues;

		internal MMScrollAreaMS grdX2;

		private bool _contentLoaded;

		public MMExtract_Profil_KValue()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Profil_KValue_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_profil_kvalue.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraKvalues = (MMGroupBox)target;
				break;
			case 2:
				grdX2 = (MMScrollAreaMS)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Profil_TPFQ_ViewModel : MMTabPageViewModel
	{
		public class SelectedView_ADV1_VM : MMViewModel
		{
			public class GridData_VM : MMViewModel
			{
				public static CxvPropertyDeclaration y_Property = CxvPropertyDeclaration.Register("y", typeof(GridData_VM), (CxvPropertyBase)new CxvParameterProperty
				{
					IsLocal = true
				});

				public static CxvPropertyDeclaration indexLabel_Property = CxvPropertyDeclaration.Register("indexLabel_Property", typeof(GridData_VM), (CxvPropertyBase)new CxvParameterProperty
				{
					Parameter = "y",
					IsReadOnly = true
				});

				public static CxvPropertyDeclaration TempCell_Property = CxvPropertyDeclaration.Register("TempCell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.B_TEMP.@y"
				});

				public static CxvPropertyDeclaration PressureCell_Property = CxvPropertyDeclaration.Register("PressureCell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.B_PRES.@y"
				});

				public static CxvPropertyDeclaration PressureCellMs_Property = CxvPropertyDeclaration.Register("PressureCellMs", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.B_PRES2.@y"
				});

				public static CxvPropertyDeclaration HeatDutyCell_Property = CxvPropertyDeclaration.Register("HeatDutycell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.DUTY.@y"
				});

				public static CxvPropertyDeclaration HeatDutyCellMs_Property = CxvPropertyDeclaration.Register("HeatDutycellMs", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.DUTY2.@y"
				});

				public static CxvPropertyDeclaration LiquidFlow1Cell_Property = CxvPropertyDeclaration.Register("LiquidFlow1Cell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.L1_FLOW.@y"
				});

				public static CxvPropertyDeclaration LiquidFlow1CellMs_Property = CxvPropertyDeclaration.Register("LiquidFlow1CellMs", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.LIQ_FLOW.@y"
				});

				public static CxvPropertyDeclaration LiquidFlow2Cell_Property = CxvPropertyDeclaration.Register("LiquidFlow2Cell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.L2_FLOW.@y"
				});

				public static CxvPropertyDeclaration LiquidFlow2CellMs_Property = CxvPropertyDeclaration.Register("LiquidFlow2CellMs", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.VAP_FLOW.@y"
				});

				public static CxvPropertyDeclaration FeedCell_Property = CxvPropertyDeclaration.Register("FeedCell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.FEED_FLOW.@y"
				});

				public static CxvPropertyDeclaration FeedCellMs_Property = CxvPropertyDeclaration.Register("FeedCellMs", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.FEED_FLOW2.@y"
				});

				public static CxvPropertyDeclaration LiquidProduct1Cell_Property = CxvPropertyDeclaration.Register("LiquidProduct1Cell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.PROD_L1FLOW.@y"
				});

				public static CxvPropertyDeclaration LiquidProduct1CellMs_Property = CxvPropertyDeclaration.Register("LiquidProduct1CellMs", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.PROD_LFLOW.@y"
				});

				public static CxvPropertyDeclaration LiquidProduct2Cell_Property = CxvPropertyDeclaration.Register("LiquidProduct2Cell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.PROD_L2FLOW.@y"
				});

				public static CxvPropertyDeclaration LiquidProduct2CellMs_Property = CxvPropertyDeclaration.Register("LiquidProduct2CellMs", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.PROD_VFLOW.@y"
				});

				public static CxvPropertyDeclaration LiquidEnthalpy1Cell_Property = CxvPropertyDeclaration.Register("LiquidEnthalpy1Cell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.L1_ENTH.@y"
				});

				public static CxvPropertyDeclaration LiquidEnthalpy2Cell_Property = CxvPropertyDeclaration.Register("LiquidEnthalpy2Cell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.L2_ENTH.@y"
				});

				public static CxvPropertyDeclaration LiquidFlowRatioCell_Property = CxvPropertyDeclaration.Register("LiquidFlowRatiocell", typeof(GridData_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.LL_RATIO.@y"
				});

				public object y => ((CxvViewModel)this).GetValue(y_Property);

				public object indexLabel => ((CxvViewModel)this).GetValue(indexLabel_Property);

				public object TempCell => ((CxvViewModel)this).GetValue(TempCell_Property);

				public object PressureCell => ((CxvViewModel)this).GetValue(PressureCell_Property);

				public object PressureCellMs => ((CxvViewModel)this).GetValue(PressureCellMs_Property);

				public object HeatDutyCell => ((CxvViewModel)this).GetValue(HeatDutyCell_Property);

				public object HeatDutyCellMs => ((CxvViewModel)this).GetValue(HeatDutyCellMs_Property);

				public object LiquidFlow1Cell => ((CxvViewModel)this).GetValue(LiquidFlow1Cell_Property);

				public object LiquidFlow1CellMs => ((CxvViewModel)this).GetValue(LiquidFlow1CellMs_Property);

				public object LiquidFlow2Cell => ((CxvViewModel)this).GetValue(LiquidFlow2Cell_Property);

				public object LiquidFlow2CellMs => ((CxvViewModel)this).GetValue(LiquidFlow2CellMs_Property);

				public object FeedCell => ((CxvViewModel)this).GetValue(FeedCell_Property);

				public object FeedCellMs => ((CxvViewModel)this).GetValue(FeedCellMs_Property);

				public object LiquidProduct1Cell => ((CxvViewModel)this).GetValue(LiquidProduct1Cell_Property);

				public object LiquidProduct1CellMs => ((CxvViewModel)this).GetValue(LiquidProduct1CellMs_Property);

				public object LiquidProduct2Cell => ((CxvViewModel)this).GetValue(LiquidProduct2Cell_Property);

				public object LiquidProduct2CellMs => ((CxvViewModel)this).GetValue(LiquidProduct2CellMs_Property);

				public object LiquidEnthalpy1Cell => ((CxvViewModel)this).GetValue(LiquidEnthalpy1Cell_Property);

				public object LiquidEnthalpy2Cell => ((CxvViewModel)this).GetValue(LiquidEnthalpy2Cell_Property);

				public object LiquidFlowRatioCell => ((CxvViewModel)this).GetValue(LiquidFlowRatioCell_Property);
			}

			public static CxvPropertyDeclaration TempUnits_Property = CxvPropertyDeclaration.Register("TempUnits", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.B_TEMP"
			});

			public static CxvPropertyDeclaration PressureUnits_Property = CxvPropertyDeclaration.Register("PressureUnits", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.B_PRES"
			});

			public static CxvPropertyDeclaration PressureUnitsMs_Property = CxvPropertyDeclaration.Register("PressureUnitsMs", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.B_PRES2"
			});

			public static CxvPropertyDeclaration HeatDutyUnits_Property = CxvPropertyDeclaration.Register("HeatDutyUnits", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.DUTY"
			});

			public static CxvPropertyDeclaration HeatDutyUnitsMs_Property = CxvPropertyDeclaration.Register("HeatDutyUnitsMs", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.DUTY2"
			});

			public static CxvPropertyDeclaration LiquidFlow1Units_Property = CxvPropertyDeclaration.Register("LiquidFlow1Units", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.L1_FLOW"
			});

			public static CxvPropertyDeclaration LiquidFlow1UnitsMs_Property = CxvPropertyDeclaration.Register("LiquidFlow1UnitsMs", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.LIQ_FLOW"
			});

			public static CxvPropertyDeclaration LiquidFlow2Units_Property = CxvPropertyDeclaration.Register("LiquidFlow2Units", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.L2_FLOW"
			});

			public static CxvPropertyDeclaration LiquidFlow2UnitsMs_Property = CxvPropertyDeclaration.Register("LiquidFlow2UnitsMs", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.VAP_FLOW"
			});

			public static CxvPropertyDeclaration FeedUnits_Property = CxvPropertyDeclaration.Register("FeedUnits", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.FEED_FLOW"
			});

			public static CxvPropertyDeclaration FeedUnitsMs_Property = CxvPropertyDeclaration.Register("FeedUnitsMs", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.FEED_FLOW2"
			});

			public static CxvPropertyDeclaration LiquidProduct1Units_Property = CxvPropertyDeclaration.Register("LiquidProduct1Units", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.PROD_L1FLOW"
			});

			public static CxvPropertyDeclaration LiquidProduct1UnitsMs_Property = CxvPropertyDeclaration.Register("LiquidProduct1UnitsMs", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.PROD_LFLOW"
			});

			public static CxvPropertyDeclaration LiquidProduct2Units_Property = CxvPropertyDeclaration.Register("LiquidProduct2Units", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.PROD_L2FLOW"
			});

			public static CxvPropertyDeclaration LiquidProduct2UnitsMs_Property = CxvPropertyDeclaration.Register("LiquidProduct2UnitsMs", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.PROD_VFLOW"
			});

			public static CxvPropertyDeclaration LiquidEnthalpy1Units_Property = CxvPropertyDeclaration.Register("LiquidEnthalpy1Units", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.L1_ENTH"
			});

			public static CxvPropertyDeclaration LiquidEnthalpy2Units_Property = CxvPropertyDeclaration.Register("LiquidEnthalpy2Units", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.L2_ENTH"
			});

			public static CxvPropertyDeclaration LiquidFlowRatioUnits_Property = CxvPropertyDeclaration.Register("LiquidFlowRatioUnits", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.LL_RATIO"
			});

			public static CxvPropertyDeclaration GridData_Property = CxvPropertyDeclaration.Register("GridData", typeof(SelectedView_ADV1_VM), (CxvPropertyBase)new CxvVectorProperty
			{
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					Name = "y",
					DataPath = "@main.Output.B_TEMP",
					UseChildId = true
				},
				ItemType = typeof(GridData_VM)
			});

			public object TempUnits => ((CxvViewModel)this).GetValue(TempUnits_Property);

			public object PressureUnits => ((CxvViewModel)this).GetValue(PressureUnits_Property);

			public object PressureUnitsMs => ((CxvViewModel)this).GetValue(PressureUnitsMs_Property);

			public object HeatDutyUnits => ((CxvViewModel)this).GetValue(HeatDutyUnits_Property);

			public object HeatDutyUnitsMs => ((CxvViewModel)this).GetValue(HeatDutyUnitsMs_Property);

			public object LiquidFlow1Units => ((CxvViewModel)this).GetValue(LiquidFlow1Units_Property);

			public object LiquidFlow1UnitsMs => ((CxvViewModel)this).GetValue(LiquidFlow1UnitsMs_Property);

			public object LiquidFlow2Units => ((CxvViewModel)this).GetValue(LiquidFlow2Units_Property);

			public object LiquidFlow2UnitsMs => ((CxvViewModel)this).GetValue(LiquidFlow2UnitsMs_Property);

			public object FeedUnits => ((CxvViewModel)this).GetValue(FeedUnits_Property);

			public object FeedUnitsMs => ((CxvViewModel)this).GetValue(FeedUnitsMs_Property);

			public object LiquidProduct1Units => ((CxvViewModel)this).GetValue(LiquidProduct1Units_Property);

			public object LiquidProduct1UnitsMs => ((CxvViewModel)this).GetValue(LiquidProduct1UnitsMs_Property);

			public object LiquidProduct2Units => ((CxvViewModel)this).GetValue(LiquidProduct2Units_Property);

			public object LiquidProduct2UnitsMs => ((CxvViewModel)this).GetValue(LiquidProduct2UnitsMs_Property);

			public object LiquidEnthalpy1Units => ((CxvViewModel)this).GetValue(LiquidEnthalpy1Units_Property);

			public object LiquidEnthalpy2Units => ((CxvViewModel)this).GetValue(LiquidEnthalpy2Units_Property);

			public object LiquidFlowRatioUnits => ((CxvViewModel)this).GetValue(LiquidFlowRatioUnits_Property);

			public object GridData => ((CxvViewModel)this).GetValue(GridData_Property);
		}

		public static readonly CxvPropertyDeclaration advcbo1_var1_Property = CxvPropertyDeclaration.Register("advcbo1_var1", typeof(MMExtract_Profil_TPFQ_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "tpfq"
		});

		public static readonly CxvPropertyDeclaration advcbo1_AdvCollection_Property = CxvPropertyDeclaration.Register("advcbo1_AdvCollection", typeof(MMExtract_Profil_TPFQ_ViewModel), (CxvPropertyBase)new CxvAdvCollectionProperty
		{
			UseItemsCollection = true,
			Items = 
			{
				new CxvAdvCollectionItem
				{
					Display = "Summary",
					DisplayResourceKey = "MMExtract_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Summary"
				},
				new CxvAdvCollectionItem
				{
					Display = "Feeds / Products",
					DisplayResourceKey = "MMExtract_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Feeds___Products"
				},
				new CxvAdvCollectionItem
				{
					Display = "Heat duty / Enthalpy",
					DisplayResourceKey = "MMExtract_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Heat_duty___Enthalpy"
				},
				new CxvAdvCollectionItem
				{
					Display = "All",
					DisplayResourceKey = "MMExtract_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_All"
				}
			},
			SelectedItemBinding = "advcbo1_var1.Value",
			CreateNewPrompt = "View:",
			CreateNewPromptResourceKey = "MMExtract_Profil_TPFQ_ViewModel__CxvAdvCollectionProperty_CreateNewPrompt_View_",
			IsCalculated = true
		});

		public static readonly CxvPropertyDeclaration advcboBasis1_AdvCollection_Property = CxvPropertyDeclaration.Register("advcboBasis1_AdvCollection", typeof(MMExtract_Profil_TPFQ_ViewModel), (CxvPropertyBase)new CxvPropertySelector
		{
			Choices = 
			{
				new CxvPropertyChoice
				{
					Operator = (CxvLogicalOperator)8,
					Property = (CxvPropertyBase)new CxvAdvCollectionProperty
					{
						UseItemsCollection = true,
						Items = 
						{
							new CxvAdvCollectionItem
							{
								Display = "Mole",
								DisplayResourceKey = "MMRadfrac_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Mole"
							},
							new CxvAdvCollectionItem
							{
								Display = "Mass",
								DisplayResourceKey = "MMRadfrac_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Mass"
							}
						},
						SelectedItemBinding = "advcboBasis1_var1.Value",
						CreateNewPrompt = "Basis:",
						CreateNewPromptResourceKey = "MMRadfrac_Profil_TPFQ_ViewModel__CxvAdvCollectionProperty_CreateNewPrompt_Basis_",
						IsCalculated = true
					}
				}
			}
		});

		public static readonly CxvPropertyDeclaration basisVisible_Property = CxvPropertyDeclaration.Register("basisVisible", typeof(MMExtract_Profil_TPFQ_ViewModel), (CxvPropertyBase)new CxvLogicalProperty
		{
			PropertyPath = "advcbo1_var1.Value",
			Operator = (CxvLogicalOperator)1,
			Value = "Heat duty / Enthalpy"
		});

		public static CxvPropertyDeclaration No_RATIO_Property;

		private MMScrollAreaColumnSet _selectedColumnData;

		public static readonly CxvPropertyDeclaration advcboBasis1_var1_Property;

		public static CxvPropertyDeclaration SelectedView_Property;

		public object advcbo1_var1 => ((CxvViewModel)this).GetValue(advcbo1_var1_Property);

		public object advcbo1_AdvCollection => ((CxvViewModel)this).GetValue(advcbo1_AdvCollection_Property);

		public object advcboBasis1_AdvCollection => ((CxvViewModel)this).GetValue(advcboBasis1_AdvCollection_Property);

		public object basisVisible => ((CxvViewModel)this).GetValue(basisVisible_Property);

		public object No_RATIO => ((CxvViewModel)this).GetValue(No_RATIO_Property);

		public MMScrollAreaColumnSet SelectedColumnData
		{
			get
			{
				return _selectedColumnData;
			}
			set
			{
				_selectedColumnData = value;
				OnPropertyChanged("SelectedColumnData");
			}
		}

		public object advcboBasis1_var1 => ((CxvViewModel)this).GetValue(advcboBasis1_var1_Property);

		public object SelectedView => ((CxvViewModel)this).GetValue(SelectedView_Property);

		protected override void OnUpdateData()
		{
			base.OnUpdateData();
			UpdateColumnSet();
		}

		protected override void OnSubPropertyDataChanged(CxvPropertyDeclaration pd, string subPropertyName)
		{
			base.OnSubPropertyDataChanged(pd, subPropertyName);
			if ((pd.Name == "advcbo1_var1" || pd.Name == "advcboBasis1_var1") && subPropertyName == "Value")
			{
				UpdateColumnSet();
			}
		}

		private void UpdateColumnSet()
		{
			//IL_0049: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			//IL_0105: Unknown result type (might be due to invalid IL or missing references)
			//IL_010a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0115: Unknown result type (might be due to invalid IL or missing references)
			//IL_0121: Unknown result type (might be due to invalid IL or missing references)
			//IL_0131: Expected O, but got Unknown
			//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c5: Expected O, but got Unknown
			//IL_0075: Unknown result type (might be due to invalid IL or missing references)
			//IL_007a: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Expected O, but got Unknown
			//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f1: Expected O, but got Unknown
			//IL_0157: Unknown result type (might be due to invalid IL or missing references)
			//IL_015c: Unknown result type (might be due to invalid IL or missing references)
			//IL_016c: Expected O, but got Unknown
			//IL_0180: Unknown result type (might be due to invalid IL or missing references)
			//IL_0185: Unknown result type (might be due to invalid IL or missing references)
			//IL_0195: Expected O, but got Unknown
			CxvAdvCollectionPropertyData val = advcbo1_AdvCollection as CxvAdvCollectionPropertyData;
			CxvAdvCollectionPropertyData val2 = advcboBasis1_AdvCollection as CxvAdvCollectionPropertyData;
			if (val != null && val2 != null)
			{
			if (val.SelectedItem == AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Summary)
			{
				if (val2.SelectedItem == AspenTech.AspenPlus.Localization.Properties.Resources.MMRadfrac_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Mole)
				{
					UpdateMMScrollAreaColumnSet(new MMScrollAreaColumnSet
					{
						FieldNames = "Stage,Temperature,Pressure,HeatDuty,LiquidFlow1,LiquidFlow2,LiquidFlowRatio"
					});
				}
				else if (val2.SelectedItem == AspenTech.AspenPlus.Localization.Properties.Resources.MMRadfrac_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Mass)
				{
					UpdateMMScrollAreaColumnSet(new MMScrollAreaColumnSet
					{
						FieldNames = "Stage,Temperature,PressureMs,HeatDutyMs,LiquidFlow1Ms,LiquidFlow2Ms,LiquidFlowRatio"
					});
				}
			}
			else if (val.SelectedItem == AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Feeds___Products)
			{
				if (val2.SelectedItem == AspenTech.AspenPlus.Localization.Properties.Resources.MMRadfrac_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Mole)
				{
					UpdateMMScrollAreaColumnSet(new MMScrollAreaColumnSet
					{
						FieldNames = "Stage,Temperature,Feed,LiquidProduct1,LiquidProduct2,LiquidFlowRatio"
					});
				}
				else if (val2.SelectedItem == AspenTech.AspenPlus.Localization.Properties.Resources.MMRadfrac_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Mass)
				{
					UpdateMMScrollAreaColumnSet(new MMScrollAreaColumnSet
					{
						FieldNames = "Stage,Temperature,FeedMs,LiquidProduct1Ms,LiquidProduct2Ms,LiquidFlowRatio"
					});
				}
			}
			else if (val.SelectedItem == AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Heat_duty___Enthalpy)
			{
				UpdateMMScrollAreaColumnSet(new MMScrollAreaColumnSet
				{
					Name = "DutyEnthalpy",
					Display = val.SelectedItem,
					FieldNames = "Stage,Temperature,HeatDuty,LiquidEnthalpy1,LiquidEnthalpy2,LiquidFlowRatio"
				});
			}
			else if (val.SelectedItem == AspenTech.AspenPlus.Localization.Properties.Resources.MMExtract_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_All)
			{
				if (val2.SelectedItem == AspenTech.AspenPlus.Localization.Properties.Resources.MMRadfrac_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Mole)
				{
					UpdateMMScrollAreaColumnSet(new MMScrollAreaColumnSet
					{
						FieldNames = "Stage,Temperature,Pressure,HeatDuty,LiquidFlow1,LiquidFlow2,Feed,LiquidProduct1,LiquidProduct2,LiquidEnthalpy1,LiquidEnthalpy2,LiquidFlowRatio"
					});
				}
				else if (val2.SelectedItem == AspenTech.AspenPlus.Localization.Properties.Resources.MMRadfrac_Profil_TPFQ_ViewModel__CxvAdvCollectionItem_Display_Mass)
				{
					UpdateMMScrollAreaColumnSet(new MMScrollAreaColumnSet
					{
						FieldNames = "Stage,Temperature,PressureMs,HeatDutyMs,LiquidFlow1Ms,LiquidFlow2Ms,FeedMs,LiquidProduct1Ms,LiquidProduct2Ms,LiquidEnthalpy1,LiquidEnthalpy2,LiquidFlowRatio"
					});
				}
			}
			}
		}

		private void UpdateMMScrollAreaColumnSet(MMScrollAreaColumnSet set)
		{
			SelectedColumnData = set;
		}

		public MMExtract_Profil_TPFQ_ViewModel()
		{
		}

		static MMExtract_Profil_TPFQ_ViewModel()
		{
	No_RATIO_Property = CxvPropertyDeclaration.Register("No_RATIO", typeof(MMExtract_Profil_TPFQ_ViewModel), (CxvPropertyBase)new CxvLogicalProperty
			{
				Operator = (CxvLogicalOperator)0,
				Tests = 
				{
					new CxvLogicalTest
					{
						DataPath = "@main.Output.LL_RATIO",
						DataAttribute = "has_children",
						Value = "1"
					}
				}
			});
	advcboBasis1_var1_Property = CxvPropertyDeclaration.Register("advcboBasis1_var1", typeof(MMExtract_Profil_TPFQ_ViewModel), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "_3tpfqbasis"
			});
	SelectedView_Property = CxvPropertyDeclaration.Register("SelectedView", typeof(MMExtract_Profil_TPFQ_ViewModel), (CxvPropertyBase)new CxvPropertySelector
			{
				Name = "SelectedView",
				Choices = 
				{
					new CxvPropertyChoice
					{
						Property = (CxvPropertyBase)new CxvSubModelProperty
						{
							SubModelType = typeof(SelectedView_ADV1_VM)
						}
					}
				}
			});
	}
	}
	[ProgId("MMExtract.MMExtract_Profil_TPFQ")]
	public class MMExtract_Profil_TPFQ : MMTabPage, IComponentConnector
	{
		internal MMLabel advcbo1_label;

		internal MMComboEdit advcbo1;

		internal MMLabel basis;

		internal MMComboEdit cbBasis;

		internal MMGroupBox fraProfiles;

		internal MMScrollAreaMS grdSummary;

		private bool _contentLoaded;

		public MMExtract_Profil_TPFQ()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Profil_TPFQ_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_profil_tpfq.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Expected O, but got Unknown
			//IL_0031: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Expected O, but got Unknown
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Expected O, but got Unknown
			//IL_004b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Expected O, but got Unknown
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_0062: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				advcbo1_label = (MMLabel)target;
				break;
			case 2:
				advcbo1 = (MMComboEdit)target;
				break;
			case 3:
				basis = (MMLabel)target;
				break;
			case 4:
				cbBasis = (MMComboEdit)target;
				break;
			case 5:
				fraProfiles = (MMGroupBox)target;
				break;
			case 6:
				grdSummary = (MMScrollAreaMS)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Profil_TrayRe_ViewModel : MMTabPageViewModel
	{
		public class MMScrollArea1_GridData_ItemTemplate_inner_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(MMScrollArea1_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@trayoutp.@y.@z"
			});

			public object MMTextBox3_var1 => ((CxvViewModel)this).GetValue(MMTextBox3_var1_Property);
		}

		public class GridData_Column_VM : MMViewModel
		{
			public static CxvPropertyDeclaration z_Property = CxvPropertyDeclaration.Register("z", typeof(GridData_Column_VM), (CxvPropertyBase)new CxvParameterProperty
			{
				IsLocal = true
			});

			public static CxvPropertyDeclaration indexLabel_Property = CxvPropertyDeclaration.Register("indexLabel", typeof(GridData_Column_VM), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "z",
				IsReadOnly = true
			});

			public static CxvPropertyDeclaration Uom_Property = CxvPropertyDeclaration.Register("Uom", typeof(GridData_Column_VM), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.Prop Data.TRAY_REP.@z.1"
			});

			public object z => ((CxvViewModel)this).GetValue(z_Property);

			public object indexLabel => ((CxvViewModel)this).GetValue(indexLabel_Property);

			public object Uom => ((CxvViewModel)this).GetValue(Uom_Property);
		}

		public class GridData_Row_VM : MMViewModel
		{
			public class GridData_Inner_VM : MMViewModel
			{
				public static CxvPropertyDeclaration x_Propertx = CxvPropertyDeclaration.Register("x", typeof(GridData_Inner_VM), (CxvPropertyBase)new CxvParameterProperty
				{
					IsLocal = true
				});

				public static CxvPropertyDeclaration CellValue_Property = CxvPropertyDeclaration.Register("CellValue", typeof(GridData_Inner_VM), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Output.Prop Data.TRAY_REP.@x.@y"
				});

				public object x => ((CxvViewModel)this).GetValue(x_Propertx);

				public object CellValue => ((CxvViewModel)this).GetValue(CellValue_Property);
			}

			public static CxvPropertyDeclaration y_Property = CxvPropertyDeclaration.Register("y", typeof(GridData_Row_VM), (CxvPropertyBase)new CxvParameterProperty
			{
				IsLocal = true
			});

			public static CxvPropertyDeclaration indexLabel_Property = CxvPropertyDeclaration.Register("indexLabel", typeof(GridData_Row_VM), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "y",
				IsReadOnly = true
			});

			public static CxvPropertyDeclaration GridData_Inner_Property = CxvPropertyDeclaration.Register("GridData_Inner", typeof(GridData_Row_VM), (CxvPropertyBase)new CxvVectorProperty
			{
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					Name = "x",
					DataPath = "@main.Output.Prop Data.TRAY_REP",
					UseChildId = true
				},
				ItemType = typeof(GridData_Inner_VM)
			});

			public object y => ((CxvViewModel)this).GetValue(y_Property);

			public object indexLabel => ((CxvViewModel)this).GetValue(indexLabel_Property);

			public object GridData_Inner => ((CxvViewModel)this).GetValue(GridData_Inner_Property);
		}

		public static CxvPropertyDeclaration GridData_Column_Property = CxvPropertyDeclaration.Register("GridData_Column", typeof(MMExtract_Profil_TrayRe_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				Name = "z",
				DataPath = "@main.Output.Prop Data.TRAY_REP",
				UseChildId = true
			},
			ItemType = typeof(GridData_Column_VM)
		});

		public static CxvPropertyDeclaration GridData_Row_Property = CxvPropertyDeclaration.Register("GridData_Row", typeof(MMExtract_Profil_TrayRe_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			IndexBasis = (CxvIndexBasisBase)new CxvSecondLevelChildCountIndexBasis
			{
				Name = "y",
				DataPath = "@main.Output.Prop Data.TRAY_REP",
				UseChildId = true
			},
			ItemType = typeof(GridData_Row_VM)
		});

		public object GridData_Column => ((CxvViewModel)this).GetValue(GridData_Column_Property);

		public object GridData_Row => ((CxvViewModel)this).GetValue(GridData_Row_Property);
	}
	[ProgId("MMExtract.MMExtract_Profil_TrayRe")]
	public class MMExtract_Profil_TrayRe : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMScrollAreaMS MMScrollArea1;

		private bool _contentLoaded;

		public MMExtract_Profil_TrayRe()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Profil_TrayRe_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_profil_trayre.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				MMScrollArea1 = (MMScrollAreaMS)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Report_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration EXPS_Property = CxvPropertyDeclaration.Register("EXPS", typeof(MMExtract_Report_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.EXPS"
		});

		public static readonly CxvPropertyDeclaration PS1_Property = CxvPropertyDeclaration.Register("PS1", typeof(MMExtract_Report_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.PS1"
		});

		public static readonly CxvPropertyDeclaration TRAY_Property = CxvPropertyDeclaration.Register("TRAY", typeof(MMExtract_Report_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.TRAY"
		});

		public static readonly CxvPropertyDeclaration plotid_Property = CxvPropertyDeclaration.Register("plotid", typeof(MMExtract_Report_ViewModel), (CxvPropertyBase)new CxvParameterProperty
		{
			Parameter = "plotid"
		});

		public static readonly CxvPropertyDeclaration UENTRPT0_Property = CxvPropertyDeclaration.Register("UENTRPT0", typeof(MMExtract_Report_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTRPT0"
		});

		public static readonly CxvPropertyDeclaration UENTRPT1_Property = CxvPropertyDeclaration.Register("UENTRPT1", typeof(MMExtract_Report_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTRPT1"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMExtract_Report_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			EnteredDataPaths = { "@UENTRPT0" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMExtract_Report_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@TRAY" },
			EnteredDataPaths = { "@UENTRPT1" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMExtract_Report_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@PS1" },
			AccessibleDataPaths = { "@EXPS" }
		});

		public object EXPS => ((CxvViewModel)this).GetValue(EXPS_Property);

		public object PS1 => ((CxvViewModel)this).GetValue(PS1_Property);

		public object TRAY => ((CxvViewModel)this).GetValue(TRAY_Property);

		public object plotid => ((CxvViewModel)this).GetValue(plotid_Property);

		public object UENTRPT0 => ((CxvViewModel)this).GetValue(UENTRPT0_Property);

		public object UENTRPT1 => ((CxvViewModel)this).GetValue(UENTRPT1_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);
	}
	[ProgId("MMExtract.MMExtract_Report")]
	public class MMExtract_Report : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabReport;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		private bool _contentLoaded;

		public MMExtract_Report()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Report_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_report.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabReport = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Report_Profil_ViewModel : MMTabPageViewModel
	{
		public class grdPhase_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration spnTRAY2_var1_Property = CxvPropertyDeclaration.Register("spnTRAY2_var1", typeof(grdPhase_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.INC_TRAY2.@y"
			});

			public static readonly CxvPropertyDeclaration spnTRAY1_var1_Property = CxvPropertyDeclaration.Register("spnTRAY1_var1", typeof(grdPhase_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.INC_TRAY1.@y",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.INCLTR"
				}
			});

			public object spnTRAY2_var1 => ((CxvViewModel)this).GetValue(spnTRAY2_var1_Property);

			public object spnTRAY1_var1 => ((CxvViewModel)this).GetValue(spnTRAY1_var1_Property);
		}

		public static readonly CxvPropertyDeclaration cboFormat_MultiMap_Property;

		public static readonly CxvPropertyDeclaration cboOrder_MultiMap_Property;

		public static readonly CxvPropertyDeclaration cboTR_Wide_MultiMap_Property;

		public static readonly CxvPropertyDeclaration ogrTRAY_OPTION_MultiMap_Property;

		public static readonly CxvPropertyDeclaration MMFrame1_state_Property;

		public static readonly CxvPropertyDeclaration grdPhase_GridData_Property;

		public object cboFormat_MultiMap => ((CxvViewModel)this).GetValue(cboFormat_MultiMap_Property);

		public object cboOrder_MultiMap => ((CxvViewModel)this).GetValue(cboOrder_MultiMap_Property);

		public object cboTR_Wide_MultiMap => ((CxvViewModel)this).GetValue(cboTR_Wide_MultiMap_Property);

		public object ogrTRAY_OPTION_MultiMap => ((CxvViewModel)this).GetValue(ogrTRAY_OPTION_MultiMap_Property);

		public object MMFrame1_state => ((CxvViewModel)this).GetValue(MMFrame1_state_Property);

		public object grdPhase_GridData => ((CxvViewModel)this).GetValue(grdPhase_GridData_Property);

		public MMExtract_Report_Profil_ViewModel()
		{
		}

		static MMExtract_Report_Profil_ViewModel()
		{
	cboFormat_MultiMap_Property = CxvPropertyDeclaration.Register("cboFormat_MultiMap", typeof(MMExtract_Report_Profil_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboFormat_display",
				DataPath = "@main.Input.FORMAT"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Stagewise profiles for each property",
				DisplayResourceKey = "MMExtract_Report_Profil_ViewModel__CxvMultiMapOption_Display_Stagewise_profiles_for_each_property",
				Value = "cboFormat_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboFormat_display",
				Value = "PROFILE"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Property reports for individual stages",
				DisplayResourceKey = "MMExtract_Report_Profil_ViewModel__CxvMultiMapOption_Display_Property_reports_for_individual_stages",
				Value = "cboFormat_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboFormat_display",
				Value = "STAGE"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Both stagewise profiles and stage reports",
				DisplayResourceKey = "MMExtract_Report_Profil_ViewModel__CxvMultiMapOption_Display_Both_stagewise_profiles_and_stage_repor",
				Value = "cboFormat_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboFormat_display",
				Value = "COMBINED"
			} }
				} }
});
	cboOrder_MultiMap_Property = CxvPropertyDeclaration.Register("cboOrder_MultiMap", typeof(MMExtract_Report_Profil_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboOrder_display",
				DataPath = "@main.Input.ORDER"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Number the stages from top to bottom",
				DisplayResourceKey = "MMExtract_Report_Profil_ViewModel__CxvMultiMapOption_Display_Number_the_stages_from_top_to_bottom",
				Value = "cboOrder_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboOrder_display",
				Value = "TOP-DOWN"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Number the stages from bottom to top",
				DisplayResourceKey = "MMExtract_Report_Profil_ViewModel__CxvMultiMapOption_Display_Number_the_stages_from_bottom_to_top",
				Value = "cboOrder_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboOrder_display",
				Value = "BOTTOM-UP"
			} }
				} }
});
	cboTR_Wide_MultiMap_Property = CxvPropertyDeclaration.Register("cboTR_Wide_MultiMap", typeof(MMExtract_Report_Profil_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboTR_Wide_display",
				DataPath = "@main.Input.TR_WIDE"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Standard (80 characters)",
				DisplayResourceKey = "MMExtract_Report_Profil_ViewModel__CxvMultiMapOption_Display_Standard__80_columns_",
				Value = "cboTR_Wide_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboTR_Wide_display",
				Value = "NO"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Wide (132 characters)",
				DisplayResourceKey = "MMExtract_Report_Profil_ViewModel__CxvMultiMapOption_Display_Wide__132_columns_",
				Value = "cboTR_Wide_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboTR_Wide_display",
				Value = "YES"
			} }
				} }
});
	ogrTRAY_OPTION_MultiMap_Property = CxvPropertyDeclaration.Register("ogrTRAY_OPTION_MultiMap", typeof(MMExtract_Report_Profil_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "ogrTRAY_OPTION_display",
				DataPath = "@main.Input.TRAY_OPTION"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Stages having a feed, product, heater, maximum or minimum flow and adjacent stages",
				DisplayResourceKey = "MMExtract_Report_Profil_ViewModel__CxvMultiMapOption_Display_Stages_having_a_feed__product__heater__",
				Value = "ogrTRAY_OPTION_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrTRAY_OPTION_display",
				Value = "BRIEF"
			} }
				}, new CxvMultiMapOption
			{
				Display = "All stages",
				DisplayResourceKey = "MMExtract_Report_Profil_ViewModel__CxvMultiMapOption_Display_All_stages",
				Value = "ogrTRAY_OPTION_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrTRAY_OPTION_display",
				Value = "ALL-TRAYS"
			} }
				}, new CxvMultiMapOption
			{
				Display = "User-specified stages",
				DisplayResourceKey = "MMExtract_Report_Profil_ViewModel__CxvMultiMapOption_Display_User_specified_stages",
				Value = "ogrTRAY_OPTION_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrTRAY_OPTION_display",
				Value = "INCL-TRAYS"
			} }
				} }
});
	MMFrame1_state_Property = CxvPropertyDeclaration.Register("MMFrame1_state", typeof(MMExtract_Report_Profil_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
			{
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.INCLTR"
				}
			});
	grdPhase_GridData_Property = CxvPropertyDeclaration.Register("grdPhase_GridData", typeof(MMExtract_Report_Profil_ViewModel), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdPhase_GridData_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@main.Input.INC_TRAY2",
					UseChildId = true,
					Name = "y"
				}
			});
	}
	}
	[ProgId("MMExtract.MMExtract_Report_Profil")]
	public class MMExtract_Report_Profil : MMTabPage, IComponentConnector
	{
		internal MMOptionGroup ogrTRAY_OPTION;

		internal MMOptionButton ogrTRAY_OPTION_opt0;

		internal MMOptionButton ogrTRAY_OPTION_opt1;

		internal MMOptionButton ogrTRAY_OPTION_opt2;

		internal MMGroupBox MMFrame1;

		internal MMScrollArea grdPhase;

		internal MMGroupBox fraFormat;

		internal MMLabel cboFormat_label;

		internal MMComboEdit cboFormat;

		internal MMLabel cboOrder_label;

		internal MMComboEdit cboOrder;

		internal MMLabel cboTR_Wide_label;

		internal MMComboEdit cboTR_Wide;

		private bool _contentLoaded;

		public MMExtract_Report_Profil()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Report_Profil_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_report_profil.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			//IL_0050: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Expected O, but got Unknown
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0067: Expected O, but got Unknown
			//IL_006a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0074: Expected O, but got Unknown
			//IL_0077: Unknown result type (might be due to invalid IL or missing references)
			//IL_0081: Expected O, but got Unknown
			//IL_0084: Unknown result type (might be due to invalid IL or missing references)
			//IL_008e: Expected O, but got Unknown
			//IL_0091: Unknown result type (might be due to invalid IL or missing references)
			//IL_009b: Expected O, but got Unknown
			//IL_009e: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a8: Expected O, but got Unknown
			//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b5: Expected O, but got Unknown
			//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c2: Expected O, but got Unknown
			//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cf: Expected O, but got Unknown
			//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00dc: Expected O, but got Unknown
			//IL_00df: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e9: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				ogrTRAY_OPTION = (MMOptionGroup)target;
				break;
			case 2:
				ogrTRAY_OPTION_opt0 = (MMOptionButton)target;
				break;
			case 3:
				ogrTRAY_OPTION_opt1 = (MMOptionButton)target;
				break;
			case 4:
				ogrTRAY_OPTION_opt2 = (MMOptionButton)target;
				break;
			case 5:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 6:
				grdPhase = (MMScrollArea)target;
				break;
			case 7:
				fraFormat = (MMGroupBox)target;
				break;
			case 8:
				cboFormat_label = (MMLabel)target;
				break;
			case 9:
				cboFormat = (MMComboEdit)target;
				break;
			case 10:
				cboOrder_label = (MMLabel)target;
				break;
			case 11:
				cboOrder = (MMComboEdit)target;
				break;
			case 12:
				cboTR_Wide_label = (MMLabel)target;
				break;
			case 13:
				cboTR_Wide = (MMComboEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Report_Proper_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMCheckBox1_var1_Property = CxvPropertyDeclaration.Register("MMCheckBox1_var1", typeof(MMExtract_Report_Proper_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
		{
			DataPath = "@main.Input.LLRATIO_REP",
			TrueValue = "YES",
			FalseValue = "NO",
			DefaultValue = false
		});

		public static readonly CxvPropertyDeclaration chkENTH_var1_Property = CxvPropertyDeclaration.Register("chkENTH_var1", typeof(MMExtract_Report_Proper_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
		{
			DataPath = "@main.Input.ENTH",
			TrueValue = "ENTH",
			FalseValue = "NOENTH",
			DefaultValue = true
		});

		public static readonly CxvPropertyDeclaration chkCOMPS_var1_Property = CxvPropertyDeclaration.Register("chkCOMPS_var1", typeof(MMExtract_Report_Proper_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
		{
			DataPath = "@main.Input.COMPS",
			TrueValue = "COMPS",
			FalseValue = "NOCOMPS",
			DefaultValue = true
		});

		public static readonly CxvPropertyDeclaration chkprofile_var1_Property = CxvPropertyDeclaration.Register("chkprofile_var1", typeof(MMExtract_Report_Proper_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
		{
			DataPath = "@main.Input.PROFILE",
			TrueValue = "PROFILE",
			FalseValue = "NOPROFILE",
			DefaultValue = true
		});

		public static readonly CxvPropertyDeclaration lstpTR_PROPS_var1_Property = CxvPropertyDeclaration.Register("lstpTR_PROPS_var1", typeof(MMExtract_Report_Proper_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)5,
			DataPath = "@main.Input.TR_PROPS",
			AllowSort = false
		});

		public object MMCheckBox1_var1 => ((CxvViewModel)this).GetValue(MMCheckBox1_var1_Property);

		public object chkENTH_var1 => ((CxvViewModel)this).GetValue(chkENTH_var1_Property);

		public object chkCOMPS_var1 => ((CxvViewModel)this).GetValue(chkCOMPS_var1_Property);

		public object chkprofile_var1 => ((CxvViewModel)this).GetValue(chkprofile_var1_Property);

		public object lstpTR_PROPS_var1 => ((CxvViewModel)this).GetValue(lstpTR_PROPS_var1_Property);
	}
	[ProgId("MMExtract.MMExtract_Report_Proper")]
	public class MMExtract_Report_Proper : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraStandard;

		internal MMCheckBox chkprofile;

		internal MMCheckBox chkCOMPS;

		internal MMCheckBox chkENTH;

		internal MMCheckBox MMCheckBox1;

		internal MMListPicker lstpTR_PROPS;

		private bool _contentLoaded;

		public MMExtract_Report_Proper()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Report_Proper_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_report_proper.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Expected O, but got Unknown
			//IL_0031: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Expected O, but got Unknown
			//IL_003e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0048: Expected O, but got Unknown
			//IL_004b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Expected O, but got Unknown
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_0062: Expected O, but got Unknown
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006f: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraStandard = (MMGroupBox)target;
				break;
			case 2:
				chkprofile = (MMCheckBox)target;
				break;
			case 3:
				chkCOMPS = (MMCheckBox)target;
				break;
			case 4:
				chkENTH = (MMCheckBox)target;
				break;
			case 5:
				MMCheckBox1 = (MMCheckBox)target;
				break;
			case 6:
				lstpTR_PROPS = (MMListPicker)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Report_Pseudo_ViewModel : MMTabPageViewModel
	{
		public class MMScrollArea1_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@main.Input.PSEUDO_STAGE.@y",
				DisplayedCase = (CxsDisplayedCase)1
			});

			public static readonly CxvPropertyDeclaration spnL1_CEFF_var1_Property = CxvPropertyDeclaration.Register("spnL1_CEFF_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.PSEUDO_STAGE.@y"
			});

			public static readonly CxvPropertyDeclaration lbtuFlow_var1_Property = CxvPropertyDeclaration.Register("lbtuFlow_var1", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.PSEUDO_FLOW.@y"
			});

			public static readonly CxvPropertyDeclaration cboPhase_MultiMap_Property;

			public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);

			public object spnL1_CEFF_var1 => ((CxvViewModel)this).GetValue(spnL1_CEFF_var1_Property);

			public object lbtuFlow_var1 => ((CxvViewModel)this).GetValue(lbtuFlow_var1_Property);

			public object cboPhase_MultiMap => ((CxvViewModel)this).GetValue(cboPhase_MultiMap_Property);

			static MMScrollArea1_GridData_ItemTemplate()
			{
				cboPhase_MultiMap_Property = CxvPropertyDeclaration.Register("cboPhase_MultiMap", typeof(MMScrollArea1_GridData_ItemTemplate), (CxvPropertyBase)new CxvMultiMapProperty
				{
					Variables = 
					{
						new CxvMultiMapVariable
						{
							Name = "cboPhase_var1",
							DataPath = "@main.Input.PSEUDO_PHASE.@y"
						}
					},
					Options = 
					{
						new CxvMultiMapOption
						{
							Display = "1st liquid",
							DisplayResourceKey = "MMExtract_Report_Pseudo_ViewModel__CxvMultiMapOption_Display_1st_liquid",
							Value = "cboPhase_MultiMapOption_1",
							Values = 
							{
								new CxvMultiMapValue
								{
									Variable = "cboPhase_var1",
									Value = "L1"
								}
							}
						},
						new CxvMultiMapOption
						{
							Display = "2nd liquid",
							DisplayResourceKey = "MMExtract_Report_Pseudo_ViewModel__CxvMultiMapOption_Display_2nd_liquid",
							Value = "cboPhase_MultiMapOption_2",
							Values = 
							{
								new CxvMultiMapValue
								{
									Variable = "cboPhase_var1",
									Value = "L2"
								}
							}
						}
					}
				});
			}
		}

		public static readonly CxvPropertyDeclaration MMScrollArea1_GridData_Property = CxvPropertyDeclaration.Register("MMScrollArea1_GridData", typeof(MMExtract_Report_Pseudo_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(MMScrollArea1_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.PSEUDO_STAGE",
				UseChildId = true,
				Name = "y"
			}
		});

		public object MMScrollArea1_GridData => ((CxvViewModel)this).GetValue(MMScrollArea1_GridData_Property);
	}
	[ProgId("MMExtract.MMExtract_Report_Pseudo")]
	public class MMExtract_Report_Pseudo : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraPseudostream;

		internal MMScrollArea MMScrollArea1;

		private bool _contentLoaded;

		public MMExtract_Report_Pseudo()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Report_Pseudo_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_report_pseudo.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraPseudostream = (MMGroupBox)target;
				break;
			case 2:
				MMScrollArea1 = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Result_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MASS_CONC_Property = CxvPropertyDeclaration.Register("MASS_CONC", typeof(MMExtract_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.MASS_CONC"
		});

		public static readonly CxvPropertyDeclaration TIME_Property = CxvPropertyDeclaration.Register("TIME", typeof(MMExtract_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TIME"
		});

		public static readonly CxvPropertyDeclaration TOP_TEMP_Property = CxvPropertyDeclaration.Register("TOP_TEMP", typeof(MMExtract_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TOP_TEMP"
		});

		public static readonly CxvPropertyDeclaration TOP_L1FLOW_Property = CxvPropertyDeclaration.Register("TOP_L1FLOW", typeof(MMExtract_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TOP_L1FLOW"
		});

		public static readonly CxvPropertyDeclaration BAL_MOLI_TFL_Property = CxvPropertyDeclaration.Register("BAL_MOLI_TFL", typeof(MMExtract_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BAL_MOLI_TFL"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMExtract_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@TOP_L1FLOW", "@TOP_TEMP" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMExtract_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@BAL_MOLI_TFL" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMExtract_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@MASS_CONC", "@TIME" }
		});

		public object MASS_CONC => ((CxvViewModel)this).GetValue(MASS_CONC_Property);

		public object TIME => ((CxvViewModel)this).GetValue(TIME_Property);

		public object TOP_TEMP => ((CxvViewModel)this).GetValue(TOP_TEMP_Property);

		public object TOP_L1FLOW => ((CxvViewModel)this).GetValue(TOP_L1FLOW_Property);

		public object BAL_MOLI_TFL => ((CxvViewModel)this).GetValue(BAL_MOLI_TFL_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);
	}
	[ProgId("MMExtract.MMExtract_Result")]
	public class MMExtract_Result : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabResults;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem info;

		private bool _contentLoaded;

		public MMExtract_Result()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Result_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_result.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Expected O, but got Unknown
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Expected O, but got Unknown
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Expected O, but got Unknown
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabResults = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				info = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Result_Splitf_ViewModel : MMTabPageViewModel
	{
		public class grdSplitFraction_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtComp_0_var1_Property = CxvPropertyDeclaration.Register("txtComp_0_var1", typeof(grdSplitFraction_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@main.Output.MASS_CONC.@y",
				DisplayedCase = (CxsDisplayedCase)1
			});

			public static readonly CxvPropertyDeclaration inner_Property = CxvPropertyDeclaration.Register("inner", typeof(grdSplitFraction_GridData_ItemTemplate), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdSplitFraction_GridData_ItemTemplate_inner_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@main.Output.MASS_CONC.#0",
					UseChildId = true,
					Name = "x"
				}
			});

			public object txtComp_0_var1 => ((CxvViewModel)this).GetValue(txtComp_0_var1_Property);

			public object inner => ((CxvViewModel)this).GetValue(inner_Property);
		}

		public class grdSplitFraction_GridData_ItemTemplate_inner_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtBtms_0_var1_Property = CxvPropertyDeclaration.Register("txtBtms_0_var1", typeof(grdSplitFraction_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvParameterProperty
			{
				Parameter = "x"
			});

			public static readonly CxvPropertyDeclaration txtDliq_0_var1_Property = CxvPropertyDeclaration.Register("txtDliq_0_var1", typeof(grdSplitFraction_GridData_ItemTemplate_inner_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.MASS_CONC.@y.@x"
			});

			public object txtBtms_0_var1 => ((CxvViewModel)this).GetValue(txtBtms_0_var1_Property);

			public object txtDliq_0_var1 => ((CxvViewModel)this).GetValue(txtDliq_0_var1_Property);
		}

		public static readonly CxvPropertyDeclaration grdSplitFraction_GridData_Property = CxvPropertyDeclaration.Register("grdSplitFraction_GridData", typeof(MMExtract_Result_Splitf_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdSplitFraction_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Output.MASS_CONC",
				UseChildId = true,
				Name = "y"
			}
		});

		public object grdSplitFraction_GridData => ((CxvViewModel)this).GetValue(grdSplitFraction_GridData_Property);
	}
	[ProgId("MMExtract.MMExtract_Result_Splitf")]
	public class MMExtract_Result_Splitf : MMTabPage, IComponentConnector
	{
		internal MMScrollArea grdSplitFraction;

		private bool _contentLoaded;

		public MMExtract_Result_Splitf()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Result_Splitf_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_result_splitf.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			if (connectionId == 1)
			{
				grdSplitFraction = (MMScrollArea)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMExtract_Result_Summar_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration lbtuBOT_L2FLOW_var1_Property = CxvPropertyDeclaration.Register("lbtuBOT_L2FLOW_var1", typeof(MMExtract_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOT_L2FLOW"
		});

		public static readonly CxvPropertyDeclaration lbtuBOT_L1FLOW_var1_Property = CxvPropertyDeclaration.Register("lbtuBOT_L1FLOW_var1", typeof(MMExtract_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOT_L1FLOW"
		});

		public static readonly CxvPropertyDeclaration lbtuBOTTOM_TEMP_var1_Property = CxvPropertyDeclaration.Register("lbtuBOTTOM_TEMP_var1", typeof(MMExtract_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOTTOM_TEMP"
		});

		public static readonly CxvPropertyDeclaration lbtuTOP_L2FLOW_var1_Property = CxvPropertyDeclaration.Register("lbtuTOP_L2FLOW_var1", typeof(MMExtract_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TOP_L2FLOW"
		});

		public static readonly CxvPropertyDeclaration lbtuTOP_L1FLOW_var1_Property = CxvPropertyDeclaration.Register("lbtuTOP_L1FLOW_var1", typeof(MMExtract_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TOP_L1FLOW"
		});

		public static readonly CxvPropertyDeclaration lbtuTOP_TEMP_var1_Property = CxvPropertyDeclaration.Register("lbtuTOP_TEMP_var1", typeof(MMExtract_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.TOP_TEMP"
		});

		public object lbtuBOT_L2FLOW_var1 => ((CxvViewModel)this).GetValue(lbtuBOT_L2FLOW_var1_Property);

		public object lbtuBOT_L1FLOW_var1 => ((CxvViewModel)this).GetValue(lbtuBOT_L1FLOW_var1_Property);

		public object lbtuBOTTOM_TEMP_var1 => ((CxvViewModel)this).GetValue(lbtuBOTTOM_TEMP_var1_Property);

		public object lbtuTOP_L2FLOW_var1 => ((CxvViewModel)this).GetValue(lbtuTOP_L2FLOW_var1_Property);

		public object lbtuTOP_L1FLOW_var1 => ((CxvViewModel)this).GetValue(lbtuTOP_L1FLOW_var1_Property);

		public object lbtuTOP_TEMP_var1 => ((CxvViewModel)this).GetValue(lbtuTOP_TEMP_var1_Property);
	}
	[ProgId("MMExtract.MMExtract_Result_Summar")]
	public class MMExtract_Result_Summar : MMTabPage, IComponentConnector
	{
		internal MMLabel lbtuTOP_TEMP_label;

		internal MMVariableEdit lbtuTOP_TEMP;

		internal MMLabel lbtuTOP_L1FLOW_label;

		internal MMVariableEdit lbtuTOP_L1FLOW;

		internal MMLabel lbtuTOP_L2FLOW_label;

		internal MMVariableEdit lbtuTOP_L2FLOW;

		internal MMLabel lbtuBOTTOM_TEMP_label;

		internal MMVariableEdit lbtuBOTTOM_TEMP;

		internal MMLabel lbtuBOT_L1FLOW_label;

		internal MMVariableEdit lbtuBOT_L1FLOW;

		internal MMLabel lbtuBOT_L2FLOW_label;

		internal MMVariableEdit lbtuBOT_L2FLOW;

		private bool _contentLoaded;

		public MMExtract_Result_Summar()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Result_Summar_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_result_summar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Expected O, but got Unknown
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0056: Expected O, but got Unknown
			//IL_0059: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Expected O, but got Unknown
			//IL_0066: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Expected O, but got Unknown
			//IL_0073: Unknown result type (might be due to invalid IL or missing references)
			//IL_007d: Expected O, but got Unknown
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Expected O, but got Unknown
			//IL_008d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0097: Expected O, but got Unknown
			//IL_009a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a4: Expected O, but got Unknown
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b1: Expected O, but got Unknown
			//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00be: Expected O, but got Unknown
			//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cb: Expected O, but got Unknown
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d8: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				lbtuTOP_TEMP_label = (MMLabel)target;
				break;
			case 2:
				lbtuTOP_TEMP = (MMVariableEdit)target;
				break;
			case 3:
				lbtuTOP_L1FLOW_label = (MMLabel)target;
				break;
			case 4:
				lbtuTOP_L1FLOW = (MMVariableEdit)target;
				break;
			case 5:
				lbtuTOP_L2FLOW_label = (MMLabel)target;
				break;
			case 6:
				lbtuTOP_L2FLOW = (MMVariableEdit)target;
				break;
			case 7:
				lbtuBOTTOM_TEMP_label = (MMLabel)target;
				break;
			case 8:
				lbtuBOTTOM_TEMP = (MMVariableEdit)target;
				break;
			case 9:
				lbtuBOT_L1FLOW_label = (MMLabel)target;
				break;
			case 10:
				lbtuBOT_L1FLOW = (MMVariableEdit)target;
				break;
			case 11:
				lbtuBOT_L2FLOW_label = (MMLabel)target;
				break;
			case 12:
				lbtuBOT_L2FLOW = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Setup_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MAIN1_Property = CxvPropertyDeclaration.Register("MAIN1", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.MAIN1"
		});

		public static readonly CxvPropertyDeclaration KCOMP_Property = CxvPropertyDeclaration.Register("KCOMP", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.KCOMP"
		});

		public static readonly CxvPropertyDeclaration STRM_Property = CxvPropertyDeclaration.Register("STRM", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.STRM"
		});

		public static readonly CxvPropertyDeclaration HSTRM_Property = CxvPropertyDeclaration.Register("HSTRM", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.HSTRM"
		});

		public static readonly CxvPropertyDeclaration SPEC_Property = CxvPropertyDeclaration.Register("SPEC", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SPEC"
		});

		public static readonly CxvPropertyDeclaration PSPEC_Property = CxvPropertyDeclaration.Register("PSPEC", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.PSPEC"
		});

		public static readonly CxvPropertyDeclaration QORHSTRM_Property = CxvPropertyDeclaration.Register("QORHSTRM", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.QORHSTRM"
		});

		public static readonly CxvPropertyDeclaration UENTHSTRM_Property = CxvPropertyDeclaration.Register("UENTHSTRM", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTHSTRM"
		});

		public static readonly CxvPropertyDeclaration NO2TEMPS_Property = CxvPropertyDeclaration.Register("NO2TEMPS", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.NO2TEMPS"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@MAIN1", "@NO2TEMPS", "@QORHSTRM", "@SPEC" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@KCOMP" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@STRM" }
		});

		public static readonly CxvPropertyDeclaration tab3_var_Property = CxvPropertyDeclaration.Register("tab3_var", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@PSPEC" }
		});

		public static readonly CxvPropertyDeclaration tab4_var_Property = CxvPropertyDeclaration.Register("tab4_var", typeof(MMExtract_Setup_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@HSTRM" },
			EnteredDataPaths = { "@UENTHSTRM" }
		});

		public object MAIN1 => ((CxvViewModel)this).GetValue(MAIN1_Property);

		public object KCOMP => ((CxvViewModel)this).GetValue(KCOMP_Property);

		public object STRM => ((CxvViewModel)this).GetValue(STRM_Property);

		public object HSTRM => ((CxvViewModel)this).GetValue(HSTRM_Property);

		public object SPEC => ((CxvViewModel)this).GetValue(SPEC_Property);

		public object PSPEC => ((CxvViewModel)this).GetValue(PSPEC_Property);

		public object QORHSTRM => ((CxvViewModel)this).GetValue(QORHSTRM_Property);

		public object UENTHSTRM => ((CxvViewModel)this).GetValue(UENTHSTRM_Property);

		public object NO2TEMPS => ((CxvViewModel)this).GetValue(NO2TEMPS_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);

		public object tab3_var => ((CxvViewModel)this).GetValue(tab3_var_Property);

		public object tab4_var => ((CxvViewModel)this).GetValue(tab4_var_Property);
	}
	[ProgId("MMExtract.MMExtract_Setup")]
	public class MMExtract_Setup : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabSetup;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem tab3;

		internal MMTabItem tab4;

		internal MMTabItem tabInfo;

		private bool _contentLoaded;

		public MMExtract_Setup()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Setup_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_setup.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0028: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Expected O, but got Unknown
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_003f: Expected O, but got Unknown
			//IL_0042: Unknown result type (might be due to invalid IL or missing references)
			//IL_004c: Expected O, but got Unknown
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0059: Expected O, but got Unknown
			//IL_005c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Expected O, but got Unknown
			//IL_0069: Unknown result type (might be due to invalid IL or missing references)
			//IL_0073: Expected O, but got Unknown
			//IL_0076: Unknown result type (might be due to invalid IL or missing references)
			//IL_0080: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabSetup = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				tab3 = (MMTabItem)target;
				break;
			case 6:
				tab4 = (MMTabItem)target;
				break;
			case 7:
				tabInfo = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Setup_Heatst_ViewModel : MMTabPageViewModel
	{
		public class grdOutlet_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration spnPROD_STAGE_var1_Property = CxvPropertyDeclaration.Register("spnPROD_STAGE_var1", typeof(grdOutlet_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.H_PROD_STAGE.@y",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCHPRODS"
				}
			});

			public static readonly CxvPropertyDeclaration txtPROD_STAGE_var1_Property = CxvPropertyDeclaration.Register("txtPROD_STAGE_var1", typeof(grdOutlet_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@main.Input.H_PROD_STAGE.@y",
				DisplayedCase = (CxsDisplayedCase)1,
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCHPRODS"
				}
			});

			public object spnPROD_STAGE_var1 => ((CxvViewModel)this).GetValue(spnPROD_STAGE_var1_Property);

			public object txtPROD_STAGE_var1 => ((CxvViewModel)this).GetValue(txtPROD_STAGE_var1_Property);
		}

		public class grdInlet_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration spnFEED_STAGE_var1_Property = CxvPropertyDeclaration.Register("spnFEED_STAGE_var1", typeof(grdInlet_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.H_FEED_STAGE.@y",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCHFEEDS"
				}
			});

			public static readonly CxvPropertyDeclaration txtFEED_STAGE_var1_Property = CxvPropertyDeclaration.Register("txtFEED_STAGE_var1", typeof(grdInlet_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@main.Input.H_FEED_STAGE.@y",
				DisplayedCase = (CxsDisplayedCase)1,
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCHFEEDS"
				}
			});

			public object spnFEED_STAGE_var1 => ((CxvViewModel)this).GetValue(spnFEED_STAGE_var1_Property);

			public object txtFEED_STAGE_var1 => ((CxvViewModel)this).GetValue(txtFEED_STAGE_var1_Property);
		}

		public static readonly CxvPropertyDeclaration grdOutlet_GridData_Property = CxvPropertyDeclaration.Register("grdOutlet_GridData", typeof(MMExtract_Setup_Heatst_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdOutlet_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.H_PROD_STAGE",
				UseChildId = true,
				Name = "y"
			},
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.LCHPRODS"
			}
		});

		public static readonly CxvPropertyDeclaration grdInlet_GridData_Property = CxvPropertyDeclaration.Register("grdInlet_GridData", typeof(MMExtract_Setup_Heatst_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdInlet_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.H_FEED_STAGE",
				UseChildId = true,
				Name = "y"
			},
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.LCHFEEDS"
			}
		});

		public object grdOutlet_GridData => ((CxvViewModel)this).GetValue(grdOutlet_GridData_Property);

		public object grdInlet_GridData => ((CxvViewModel)this).GetValue(grdInlet_GridData_Property);
	}
	[ProgId("MMExtract.MMExtract_Setup_Heatst")]
	public class MMExtract_Setup_Heatst : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraInlet;

		internal MMScrollArea grdInlet;

		internal MMGroupBox fraOutlet;

		internal MMScrollArea grdOutlet;

		private bool _contentLoaded;

		public MMExtract_Setup_Heatst()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Setup_Heatst_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_setup_heatst.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraInlet = (MMGroupBox)target;
				break;
			case 2:
				grdInlet = (MMScrollArea)target;
				break;
			case 3:
				fraOutlet = (MMGroupBox)target;
				break;
			case 4:
				grdOutlet = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Setup_Keycom_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration lstpSPFLOW_var1_Property = CxvPropertyDeclaration.Register("lstpSPFLOW_var1", typeof(MMExtract_Setup_Keycom_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)5,
			DataPath = "@main.Input.COMP1_LIST",
			AllowSort = false
		});

		public static readonly CxvPropertyDeclaration lstpSecond_var1_Property = CxvPropertyDeclaration.Register("lstpSecond_var1", typeof(MMExtract_Setup_Keycom_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			ExposeAs = (CxvVariableTypeCode)5,
			DataPath = "@main.Input.COMP2_LIST",
			AllowSort = false
		});

		public object lstpSPFLOW_var1 => ((CxvViewModel)this).GetValue(lstpSPFLOW_var1_Property);

		public object lstpSecond_var1 => ((CxvViewModel)this).GetValue(lstpSecond_var1_Property);
	}
	[ProgId("MMExtract.MMExtract_Setup_Keycom")]
	public class MMExtract_Setup_Keycom : MMTabPage, IComponentConnector
	{
		internal MMListPicker lstpSPFLOW;

		internal MMListPicker lstpSecond;

		private bool _contentLoaded;

		public MMExtract_Setup_Keycom()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Setup_Keycom_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_setup_keycom.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				lstpSPFLOW = (MMListPicker)target;
				break;
			case 2:
				lstpSecond = (MMListPicker)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Setup_Pressu_ViewModel : MMTabPageViewModel
	{
		public class grdPress_Prof_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("txtSTAGE_PRES_var1", typeof(grdPress_Prof_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.STAGE_PRES.@y"
			});

			public static readonly CxvPropertyDeclaration spnSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("spnSTAGE_PRES_var1", typeof(grdPress_Prof_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.STAGE_PRES.@y"
			});

			public object txtSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(txtSTAGE_PRES_var1_Property);

			public object spnSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(spnSTAGE_PRES_var1_Property);
		}

		public static readonly CxvPropertyDeclaration lbtuSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("lbtuSTAGE_PRES_var1", typeof(MMExtract_Setup_Pressu_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.STAGE_PRES"
		});

		public static readonly CxvPropertyDeclaration grdPress_Prof_GridData_Property = CxvPropertyDeclaration.Register("grdPress_Prof_GridData", typeof(MMExtract_Setup_Pressu_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdPress_Prof_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.STAGE_PRES",
				UseChildId = true,
				Name = "y"
			}
		});

		public object lbtuSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(lbtuSTAGE_PRES_var1_Property);

		public object grdPress_Prof_GridData => ((CxvViewModel)this).GetValue(grdPress_Prof_GridData_Property);
	}
	[ProgId("MMExtract.MMExtract_Setup_Pressu")]
	public class MMExtract_Setup_Pressu : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraPress_Profile;

		internal MMScrollArea grdPress_Prof;

		private bool _contentLoaded;

		public MMExtract_Setup_Pressu()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Setup_Pressu_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_setup_pressu.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0023: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraPress_Profile = (MMGroupBox)target;
				break;
			case 2:
				grdPress_Prof = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Setup_Specif_ViewModel : MMTabPageViewModel
	{
		public class grdPress_Prof_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("txtSTAGE_PRES_var1", typeof(grdPress_Prof_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.TSPEC_TEMP.@y"
			});

			public static readonly CxvPropertyDeclaration spnSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("spnSTAGE_PRES_var1", typeof(grdPress_Prof_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.TSPEC_TEMP.@y"
			});

			public object txtSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(txtSTAGE_PRES_var1_Property);

			public object spnSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(spnSTAGE_PRES_var1_Property);
		}

		public class grdHeat_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration spnHeat_var1_Property = CxvPropertyDeclaration.Register("spnHeat_var1", typeof(grdHeat_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)7,
				DataPath = "@main.Input.HEATER_DUTY.@y"
			});

			public static readonly CxvPropertyDeclaration txtHeat_var1_Property = CxvPropertyDeclaration.Register("txtHeat_var1", typeof(grdHeat_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.HEATER_DUTY.@y"
			});

			public object spnHeat_var1 => ((CxvViewModel)this).GetValue(spnHeat_var1_Property);

			public object txtHeat_var1 => ((CxvViewModel)this).GetValue(txtHeat_var1_Property);
		}

		public static readonly CxvPropertyDeclaration ogrThermal_MultiMap_Property;

		public static readonly CxvPropertyDeclaration spnStages_var1_Property;

		public static readonly CxvPropertyDeclaration fraPress_Profile_state_Property;

		public static readonly CxvPropertyDeclaration lbtuSTAGE_PRES_var1_Property;

		public static readonly CxvPropertyDeclaration grdPress_Prof_GridData_Property;

		public static readonly CxvPropertyDeclaration fraHeat_state_Property;

		public static readonly CxvPropertyDeclaration lbtuHeat_var1_Property;

		public static readonly CxvPropertyDeclaration grdHeat_GridData_Property;

		public object ogrThermal_MultiMap => ((CxvViewModel)this).GetValue(ogrThermal_MultiMap_Property);

		public object spnStages_var1 => ((CxvViewModel)this).GetValue(spnStages_var1_Property);

		public object fraPress_Profile_state => ((CxvViewModel)this).GetValue(fraPress_Profile_state_Property);

		public object lbtuSTAGE_PRES_var1 => ((CxvViewModel)this).GetValue(lbtuSTAGE_PRES_var1_Property);

		public object grdPress_Prof_GridData => ((CxvViewModel)this).GetValue(grdPress_Prof_GridData_Property);

		public object fraHeat_state => ((CxvViewModel)this).GetValue(fraHeat_state_Property);

		public object lbtuHeat_var1 => ((CxvViewModel)this).GetValue(lbtuHeat_var1_Property);

		public object grdHeat_GridData => ((CxvViewModel)this).GetValue(grdHeat_GridData_Property);

		public MMExtract_Setup_Specif_ViewModel()
		{
		}

		static MMExtract_Setup_Specif_ViewModel()
		{
	ogrThermal_MultiMap_Property = CxvPropertyDeclaration.Register("ogrThermal_MultiMap", typeof(MMExtract_Setup_Specif_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "ogrThermal_var1",
				DataPath = "@main.Input.OPT_THERMAL"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Adiabatic",
				DisplayResourceKey = "MMExtract_Setup_Specif_ViewModel__CxvMultiMapOption_Display_Adiabatic",
				Value = "ogrThermal_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrThermal_var1",
				Value = "ADIABATIC"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Specify temperature profile",
				DisplayResourceKey = "MMExtract_Setup_Specif_ViewModel__CxvMultiMapOption_Display_Specify_temperature_profile",
				Value = "ogrThermal_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrThermal_var1",
				Value = "TEMP"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Specify heat duty profile",
				DisplayResourceKey = "MMExtract_Setup_Specif_ViewModel__CxvMultiMapOption_Display_Specify_heat_duty_profile",
				Value = "ogrThermal_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrThermal_var1",
				Value = "DUTY"
			} }
				} }
});
	spnStages_var1_Property = CxvPropertyDeclaration.Register("spnStages_var1", typeof(MMExtract_Setup_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.NSTAGE"
			});
	fraPress_Profile_state_Property = CxvPropertyDeclaration.Register("fraPress_Profile_state", typeof(MMExtract_Setup_Specif_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
			{
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.TSPEC"
				}
			});
	lbtuSTAGE_PRES_var1_Property = CxvPropertyDeclaration.Register("lbtuSTAGE_PRES_var1", typeof(MMExtract_Setup_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.TSPEC_TEMP"
			});
	grdPress_Prof_GridData_Property = CxvPropertyDeclaration.Register("grdPress_Prof_GridData", typeof(MMExtract_Setup_Specif_ViewModel), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdPress_Prof_GridData_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@main.Input.TSPEC_TEMP",
					UseChildId = true,
					Name = "y"
				}
			});
	fraHeat_state_Property = CxvPropertyDeclaration.Register("fraHeat_state", typeof(MMExtract_Setup_Specif_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
			{
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.DSPEC"
				}
			});
	lbtuHeat_var1_Property = CxvPropertyDeclaration.Register("lbtuHeat_var1", typeof(MMExtract_Setup_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.HEATER_DUTY"
			});
	grdHeat_GridData_Property = CxvPropertyDeclaration.Register("grdHeat_GridData", typeof(MMExtract_Setup_Specif_ViewModel), (CxvPropertyBase)new CxvVectorProperty
			{
				ItemType = typeof(grdHeat_GridData_ItemTemplate),
				IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
				{
					DataPath = "@main.Input.HEATER_DUTY",
					UseChildId = true,
					Name = "y"
				}
			});
	}
	}
	[ProgId("MMExtract.MMExtract_Setup_Specif")]
	public class MMExtract_Setup_Specif : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraSetup;

		internal MMLabel spnStages_label;

		internal MMSpinBox spnStages;

		internal MMOptionGroup ogrThermal;

		internal MMOptionButton ogrThermal_opt0;

		internal MMOptionButton ogrThermal_opt1;

		internal MMOptionButton ogrThermal_opt2;

		internal MMGroupBox fraPress_Profile;

		internal MMScrollArea grdPress_Prof;

		internal MMGroupBox fraHeat;

		internal MMScrollArea grdHeat;

		private bool _contentLoaded;

		public MMExtract_Setup_Specif()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Setup_Specif_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_setup_specif.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0045: Expected O, but got Unknown
			//IL_0048: Unknown result type (might be due to invalid IL or missing references)
			//IL_0052: Expected O, but got Unknown
			//IL_0055: Unknown result type (might be due to invalid IL or missing references)
			//IL_005f: Expected O, but got Unknown
			//IL_0062: Unknown result type (might be due to invalid IL or missing references)
			//IL_006c: Expected O, but got Unknown
			//IL_006f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0079: Expected O, but got Unknown
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0086: Expected O, but got Unknown
			//IL_0089: Unknown result type (might be due to invalid IL or missing references)
			//IL_0093: Expected O, but got Unknown
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a0: Expected O, but got Unknown
			//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ad: Expected O, but got Unknown
			//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ba: Expected O, but got Unknown
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c7: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraSetup = (MMGroupBox)target;
				break;
			case 2:
				spnStages_label = (MMLabel)target;
				break;
			case 3:
				spnStages = (MMSpinBox)target;
				break;
			case 4:
				ogrThermal = (MMOptionGroup)target;
				break;
			case 5:
				ogrThermal_opt0 = (MMOptionButton)target;
				break;
			case 6:
				ogrThermal_opt1 = (MMOptionButton)target;
				break;
			case 7:
				ogrThermal_opt2 = (MMOptionButton)target;
				break;
			case 8:
				fraPress_Profile = (MMGroupBox)target;
				break;
			case 9:
				grdPress_Prof = (MMScrollArea)target;
				break;
			case 10:
				fraHeat = (MMGroupBox)target;
				break;
			case 11:
				grdHeat = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMExtract_Setup_Stream_ViewModel : MMTabPageViewModel
	{
		public class grdOutlet_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtPROD_STAGE_var1_Property = CxvPropertyDeclaration.Register("txtPROD_STAGE_var1", typeof(grdOutlet_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@main.Input.PROD_STAGE.@y",
				DisplayedCase = (CxsDisplayedCase)1,
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCPRODS"
				}
			});

			public static readonly CxvPropertyDeclaration cboPhase_MultiMap_Property;

			public static readonly CxvPropertyDeclaration lbtuBasis_var1_Property;

			public static readonly CxvPropertyDeclaration spnPROD_STAGE_var1_Property;

			public object txtPROD_STAGE_var1 => ((CxvViewModel)this).GetValue(txtPROD_STAGE_var1_Property);

			public object cboPhase_MultiMap => ((CxvViewModel)this).GetValue(cboPhase_MultiMap_Property);

			public object lbtuBasis_var1 => ((CxvViewModel)this).GetValue(lbtuBasis_var1_Property);

			public object spnPROD_STAGE_var1 => ((CxvViewModel)this).GetValue(spnPROD_STAGE_var1_Property);

			static grdOutlet_GridData_ItemTemplate()
			{
				//IL_000f: Unknown result type (might be due to invalid IL or missing references)
				//IL_0014: Unknown result type (might be due to invalid IL or missing references)
				//IL_001b: Unknown result type (might be due to invalid IL or missing references)
				//IL_0026: Unknown result type (might be due to invalid IL or missing references)
				//IL_0032: Unknown result type (might be due to invalid IL or missing references)
				//IL_0033: Unknown result type (might be due to invalid IL or missing references)
				//IL_0038: Unknown result type (might be due to invalid IL or missing references)
				//IL_0048: Expected O, but got Unknown
				//IL_004d: Expected O, but got Unknown
				//IL_0061: Unknown result type (might be due to invalid IL or missing references)
				//IL_0066: Unknown result type (might be due to invalid IL or missing references)
				//IL_006c: Unknown result type (might be due to invalid IL or missing references)
				//IL_0071: Unknown result type (might be due to invalid IL or missing references)
				//IL_007c: Unknown result type (might be due to invalid IL or missing references)
				//IL_008c: Expected O, but got Unknown
				//IL_008c: Unknown result type (might be due to invalid IL or missing references)
				//IL_0092: Unknown result type (might be due to invalid IL or missing references)
				//IL_0097: Unknown result type (might be due to invalid IL or missing references)
				//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
				//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
				//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
				//IL_00be: Unknown result type (might be due to invalid IL or missing references)
				//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
				//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
				//IL_00de: Expected O, but got Unknown
				//IL_00e3: Expected O, but got Unknown
				//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
				//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
				//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
				//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
				//IL_0104: Unknown result type (might be due to invalid IL or missing references)
				//IL_010f: Unknown result type (might be due to invalid IL or missing references)
				//IL_0115: Unknown result type (might be due to invalid IL or missing references)
				//IL_011a: Unknown result type (might be due to invalid IL or missing references)
				//IL_0125: Unknown result type (might be due to invalid IL or missing references)
				//IL_0135: Expected O, but got Unknown
				//IL_013a: Expected O, but got Unknown
				//IL_013a: Unknown result type (might be due to invalid IL or missing references)
				//IL_013b: Unknown result type (might be due to invalid IL or missing references)
				//IL_0140: Unknown result type (might be due to invalid IL or missing references)
				//IL_0150: Expected O, but got Unknown
				//IL_0155: Expected O, but got Unknown
				//IL_0169: Unknown result type (might be due to invalid IL or missing references)
				//IL_016e: Unknown result type (might be due to invalid IL or missing references)
				//IL_0179: Unknown result type (might be due to invalid IL or missing references)
				//IL_017a: Unknown result type (might be due to invalid IL or missing references)
				//IL_017f: Unknown result type (might be due to invalid IL or missing references)
				//IL_018f: Expected O, but got Unknown
				//IL_0194: Expected O, but got Unknown
				//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
				//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
				//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
				//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
				//IL_01be: Unknown result type (might be due to invalid IL or missing references)
				//IL_01ce: Expected O, but got Unknown
				//IL_01d3: Expected O, but got Unknown
				cboPhase_MultiMap_Property = CxvPropertyDeclaration.Register("cboPhase_MultiMap", typeof(grdOutlet_GridData_ItemTemplate), (CxvPropertyBase)new CxvMultiMapProperty
				{
					Variables = 
					{
						new CxvMultiMapVariable
						{
							Name = "cboPhase_var1",
							DataPath = "@main.Input.PROD_PHASE.@y"
						}
					},
					Options = 
					{
						new CxvMultiMapOption
						{
							Display = "1st liquid",
							DisplayResourceKey = "MMExtract_Setup_Stream_ViewModel__CxvMultiMapOption_Display_1st_liquid",
							Value = "cboPhase_MultiMapOption_1",
							Values = 
							{
								new CxvMultiMapValue
								{
									Variable = "cboPhase_var1",
									Value = "L1"
								}
							}
						},
						new CxvMultiMapOption
						{
							Display = "2nd liquid",
							DisplayResourceKey = "MMExtract_Setup_Stream_ViewModel__CxvMultiMapOption_Display_2nd_liquid",
							Value = "cboPhase_MultiMapOption_2",
							Values = 
							{
								new CxvMultiMapValue
								{
									Variable = "cboPhase_var1",
									Value = "L2"
								}
							}
						}
					},
					IsEnabledCondition = new CxvLogicalTest
					{
						DataPath = "@main.CC Nodes.LCPRODS"
					}
				});
				lbtuBasis_var1_Property = CxvPropertyDeclaration.Register("lbtuBasis_var1", typeof(grdOutlet_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Input.PROD_FLOW.@y",
					IsEnabledCondition = new CxvLogicalTest
					{
						DataPath = "@main.CC Nodes.LCPRODS"
					}
				});
				spnPROD_STAGE_var1_Property = CxvPropertyDeclaration.Register("spnPROD_STAGE_var1", typeof(grdOutlet_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
				{
					DataPath = "@main.Input.PROD_STAGE.@y",
					IsEnabledCondition = new CxvLogicalTest
					{
						DataPath = "@main.CC Nodes.LCPRODS"
					}
				});
			}
		}

		public class grdInlet_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration txtFEED_STAGE_var1_Property = CxvPropertyDeclaration.Register("txtFEED_STAGE_var1", typeof(grdInlet_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@main.Input.FEED_STAGE.@y",
				DisplayedCase = (CxsDisplayedCase)1,
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCFEEDS"
				}
			});

			public static readonly CxvPropertyDeclaration spnFEED_STAGE_var1_Property = CxvPropertyDeclaration.Register("spnFEED_STAGE_var1", typeof(grdInlet_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.FEED_STAGE.@y",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.LCFEEDS"
				}
			});

			public object txtFEED_STAGE_var1 => ((CxvViewModel)this).GetValue(txtFEED_STAGE_var1_Property);

			public object spnFEED_STAGE_var1 => ((CxvViewModel)this).GetValue(spnFEED_STAGE_var1_Property);
		}

		public static readonly CxvPropertyDeclaration grdOutlet_GridData_Property = CxvPropertyDeclaration.Register("grdOutlet_GridData", typeof(MMExtract_Setup_Stream_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdOutlet_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.PROD_STAGE",
				UseChildId = true,
				Name = "y"
			}
		});

		public static readonly CxvPropertyDeclaration grdInlet_GridData_Property = CxvPropertyDeclaration.Register("grdInlet_GridData", typeof(MMExtract_Setup_Stream_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdInlet_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Input.FEED_STAGE",
				UseChildId = true,
				Name = "y"
			}
		});

		public object grdOutlet_GridData => ((CxvViewModel)this).GetValue(grdOutlet_GridData_Property);

		public object grdInlet_GridData => ((CxvViewModel)this).GetValue(grdInlet_GridData_Property);
	}
	[ProgId("MMExtract.MMExtract_Setup_Stream")]
	public class MMExtract_Setup_Stream : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraInlet;

		internal MMScrollArea grdInlet;

		internal MMGroupBox fraOutlet;

		internal MMScrollArea grdOutlet;

		private bool _contentLoaded;

		public MMExtract_Setup_Stream()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMExtract_Setup_Stream_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Extract;component/mmextract_setup_stream.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Expected O, but got Unknown
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_0036: Unknown result type (might be due to invalid IL or missing references)
			//IL_0040: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraInlet = (MMGroupBox)target;
				break;
			case 2:
				grdInlet = (MMScrollArea)target;
				break;
			case 3:
				fraOutlet = (MMGroupBox)target;
				break;
			case 4:
				grdOutlet = (MMScrollArea)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
}
namespace XamlGeneratedNamespace
{
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class GeneratedInternalTypeHelper : InternalTypeHelper
	{
		protected override object CreateInstance(Type type, CultureInfo culture)
		{
			return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.CreateInstance, null, null, culture);
		}

		protected override object GetPropertyValue(PropertyInfo propertyInfo, object target, CultureInfo culture)
		{
			return propertyInfo.GetValue(target, BindingFlags.Default, null, null, culture);
		}

		protected override void SetPropertyValue(PropertyInfo propertyInfo, object target, object value, CultureInfo culture)
		{
			propertyInfo.SetValue(target, value, BindingFlags.Default, null, null, culture);
		}

		protected override Delegate CreateDelegate(Type delegateType, object target, string handler)
		{
			return (Delegate)target.GetType().InvokeMember("_CreateDelegate", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, target, new object[2] { delegateType, handler }, null);
		}

		protected override void AddEventHandler(EventInfo eventInfo, object target, Delegate handler)
		{
			eventInfo.AddEventHandler(target, handler);
		}
	}
}
