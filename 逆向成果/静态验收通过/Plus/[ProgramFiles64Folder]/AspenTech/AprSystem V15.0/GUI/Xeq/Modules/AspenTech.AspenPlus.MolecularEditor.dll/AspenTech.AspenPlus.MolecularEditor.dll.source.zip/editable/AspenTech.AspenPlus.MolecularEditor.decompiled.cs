using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Media;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.MMControls;
using AspenTech.AspenPlus.MolecularDrawing.Helpers;
using AspenTech.AspenPlus.MolecularDrawing.Interop;
using AspenTech.AspenPlus.UnmanagedWrapper;
using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Unity;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.MolecularEditor")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.MolecularEditor")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology 2011 - 2021")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]
namespace AspenTech.AspenPlus.MolecularEditor
{
	public class MolecularEditorModule : IModule
	{
		private readonly IUnityContainer _unityContainer;

		public MolecularEditorModule(IUnityContainer unityContainer)
		{
			if (unityContainer == null)
			{
				throw new ArgumentNullException("unityContainer");
			}
			_unityContainer = unityContainer;
		}

		public void Initialize()
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Expected O, but got Unknown
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Expected O, but got Unknown
			UnityContainerExtensions.RegisterType<IMolecularEditorPresenter, MolecularEditorPresenter>(_unityContainer, (LifetimeManager)new ContainerControlledLifetimeManager(), Array.Empty<InjectionMember>());
			UnityContainerExtensions.RegisterType<IMoleculeDrawingProxy, MolecularEditorPresenter>(_unityContainer, (LifetimeManager)new ContainerControlledLifetimeManager(), Array.Empty<InjectionMember>());
		}
	}
	public class MolecularEditorPresenter : IMolecularEditorPresenter, IMoleculeDrawingProxy
	{
		private IMoleculeRenderEngine _moleculeRenderEngine;

		private IMoleculeDrawingEngine _moleculeDrawingEngine;

		private IMoleculeRenderEngine MoleculeRenderEngine => _moleculeRenderEngine ?? (_moleculeRenderEngine = MolecularEditorNetEngine.CreateMoleculeRenderEngine());

		private IMoleculeDrawingEngine MoleculeDrawingEngine => _moleculeDrawingEngine ?? (_moleculeDrawingEngine = MolecularEditorNetEngine.CreateMoleculeDrawingEngine());

		public void SimplyOpenMolecularEditor()
		{
			MoleculeDrawingEngine.SimplyOpenMolecularEditor();
		}

		public string[] OpenMolecularEditor(string[] molefileContentAsLines, bool forTDE, ref string fragmentName, out int fragmentConsistency, out bool changed)
		{
			return MoleculeDrawingEngine.OpenMolecularEditor(molefileContentAsLines, forTDE, ref fragmentName, out fragmentConsistency, out changed);
		}

		public string[] CheckMolecularEditor(string[] molefileContentAsLines, out int fragmentConsistency)
		{
			return MoleculeDrawingEngine.CheckMolecularEditor(molefileContentAsLines, out fragmentConsistency);
		}

		public object CreateBitmapForMolefile(string[] molefileContentAsLines)
		{
			return MoleculeDrawingEngine.CreateBitmapForMolefile(molefileContentAsLines);
		}

		public object CreateBitmapForMolefileInSpecialSize(string[] molefileContentAsLines, double width, double height)
		{
			return MoleculeDrawingEngine.CreateBitmapForMolefileInSpecialSize(molefileContentAsLines, width, height);
		}

		public void GenerateConnectionTable(string[] molefileContentAsLines, out int[] startAtomIndexes, out int[] endAtomIndexes, out string[] startAtomSymbols, out string[] endAtomSymbols, out int[] bondTypes, out string[] formulaAtomSymbols, out int[] formularAtomCounts)
		{
			MoleculeDrawingEngine.GenerateConnectionTable(molefileContentAsLines, out startAtomIndexes, out endAtomIndexes, out startAtomSymbols, out endAtomSymbols, out bondTypes, out formulaAtomSymbols, out formularAtomCounts);
		}

		string IMoleculeDrawingProxy.CompressText(string text)
		{
			return MoleStructCompressor.CompressText(text);
		}

		string IMoleculeDrawingProxy.DecompressText(string text)
		{
			return MoleStructCompressor.DecompressText(text);
		}

		string[] IMoleculeDrawingProxy.OpenMolecularEditor(string[] molefileContentAsLines, bool forTDE, ref string fragmentName, out int fragmentConsistency, out bool changed)
		{
			return OpenMolecularEditor(molefileContentAsLines, forTDE, ref fragmentName, out fragmentConsistency, out changed);
		}

		string[] IMoleculeDrawingProxy.CheckMolecularEditor(string[] molefileContentAsLines, out int fragmentConsistency)
		{
			return CheckMolecularEditor(molefileContentAsLines, out fragmentConsistency);
		}

		ImageSource IMoleculeDrawingProxy.CreateBitmapForMolefileInSpecialSize(string[] molefileContentAsLines, double width, double height)
		{
			IMoleculeImage moleculeImage = MoleculeRenderEngine.GetMoleculeImage(molefileContentAsLines);
			return ImageHelper.GetRenderTargetBitmapLessThanTargetSize(moleculeImage.VectorImage, moleculeImage.Size, new Size(width, height));
		}

		void IMoleculeDrawingProxy.GenerateConnectionTable(string[] molefileContentAsLines, out int[] startAtomIndexes, out int[] endAtomIndexes, out string[] startAtomSymbols, out string[] endAtomSymbols, out int[] bondTypes, out string[] formulaAtomSymbols, out int[] formularAtomCounts)
		{
			GenerateConnectionTable(molefileContentAsLines, out startAtomIndexes, out endAtomIndexes, out startAtomSymbols, out endAtomSymbols, out bondTypes, out formulaAtomSymbols, out formularAtomCounts);
		}

		public string[] GenerateMolStringsFromSMILES(string smiles)
		{
			return MoleculeDrawingEngine.GenerateMolStringsFromSMILES(smiles);
		}
	}
}
namespace AspenTech.AspenPlus.MolecularEditor.Properties
{
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

		public static Settings Default => defaultInstance;
	}
}
