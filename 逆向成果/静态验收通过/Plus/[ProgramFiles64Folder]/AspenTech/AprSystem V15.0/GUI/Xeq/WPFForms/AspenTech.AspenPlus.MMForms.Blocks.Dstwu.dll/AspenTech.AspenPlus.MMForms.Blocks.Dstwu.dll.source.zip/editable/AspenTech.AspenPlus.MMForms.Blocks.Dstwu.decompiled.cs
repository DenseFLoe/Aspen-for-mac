using System;
using System.CodeDom.Compiler;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Markup;
using AspenTech.AspenCxs.CxsViewModel;
using AspenTech.AspenPlus.MMControls;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyFileVersion("41.0.0.614")]
[assembly: AssemblyTitle("AspenTech.AspenPlus.MMForms.Blocks.Dstwu")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("AspenTech.AspenPlus.MMForms.Blocks.Dstwu")]
[assembly: AssemblyCopyright("Copyright © AspenTech 2009 - 2024")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US", UltimateResourceFallbackLocation.Satellite)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: XmlnsDefinition("http://schemas.aspentech.com/xaml/presentation/aspenplus/forms/dstwu", "AspenTech.AspenPlus.MMForms.Blocks.Dstwu")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.614")]

namespace AspenTech.AspenPlus.MMForms.Blocks.Dstwu
{
	public class MMDstwu_Input_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration ISMAINCNODE_Property = CxvPropertyDeclaration.Register("ISMAINCNODE", typeof(MMDstwu_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.ISMAINCNODE"
		});

		public static readonly CxvPropertyDeclaration UENTCALC_Property = CxvPropertyDeclaration.Register("UENTCALC", typeof(MMDstwu_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCALC"
		});

		public static readonly CxvPropertyDeclaration UENTCVG_Property = CxvPropertyDeclaration.Register("UENTCVG", typeof(MMDstwu_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.UENTCVG"
		});

		public static readonly CxvPropertyDeclaration FREE2_Property = CxvPropertyDeclaration.Register("FREE2", typeof(MMDstwu_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.FREE2"
		});

		public static readonly CxvPropertyDeclaration SPEC2_Property = CxvPropertyDeclaration.Register("SPEC2", typeof(MMDstwu_Input_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.CC Nodes.SPEC2"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMDstwu_Input_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@ISMAINCNODE" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMDstwu_Input_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@SPEC2" },
			EnteredDataPaths = { "@UENTCALC" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMDstwu_Input_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			CompleteDataPaths = { "@FREE2" },
			EnteredDataPaths = { "@UENTCVG" }
		});

		public object ISMAINCNODE => ((CxvViewModel)this).GetValue(ISMAINCNODE_Property);

		public object UENTCALC => ((CxvViewModel)this).GetValue(UENTCALC_Property);

		public object UENTCVG => ((CxvViewModel)this).GetValue(UENTCVG_Property);

		public object FREE2 => ((CxvViewModel)this).GetValue(FREE2_Property);

		public object SPEC2 => ((CxvViewModel)this).GetValue(SPEC2_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);
	}
	[ProgId("MMDstwu.MMDstwu_Input")]
	public class MMDstwu_Input : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabDstwu;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem tabInfo;

		private bool _contentLoaded;

		public MMDstwu_Input()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDstwu_Input_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Dstwu;component/mmdstwu_input.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Expected O, but got Unknown
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Expected O, but got Unknown
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Expected O, but got Unknown
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabDstwu = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				tabInfo = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDstwu_Input_Calcul_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MMCheckBox2_OPT_CALHETP_Property = CxvPropertyDeclaration.Register("MMCheckBox2_OPT_CALHETP", typeof(MMDstwu_Input_Calcul_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
		{
			DataPath = "@main.Input.OPT_CALHETP",
			TrueValue = "YES",
			FalseValue = "NO",
			DefaultValue = false
		});

		public static readonly CxvPropertyDeclaration MMCheckBox1_var1_Property = CxvPropertyDeclaration.Register("MMCheckBox1_var1", typeof(MMDstwu_Input_Calcul_ViewModel), (CxvPropertyBase)new CxvBooleanProperty
		{
			DataPath = "@main.Input.PLOT",
			TrueValue = "YES",
			FalseValue = "NO",
			DefaultValue = false
		});

		public static readonly CxvPropertyDeclaration fraHetp_state_Property = CxvPropertyDeclaration.Register("fraHetp_state", typeof(MMDstwu_Input_Calcul_ViewModel), (CxvPropertyBase)new CxvGroupBoxProperty
		{
			IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.GEPACKHT"
			}
		});

		public static readonly CxvPropertyDeclaration lbtuPtop_1_var1_Property = CxvPropertyDeclaration.Register("lbtuPtop_1_var1", typeof(MMDstwu_Input_Calcul_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.PACK_HEIGHT"
		});

		public static readonly CxvPropertyDeclaration ogrOPT_SZNO_MultiMap_Property;

		public static readonly CxvPropertyDeclaration lbtuPtop_0_var1_Property;

		public static readonly CxvPropertyDeclaration lbtuPtop_2_var1_Property;

		public static readonly CxvPropertyDeclaration cboHight_Precision_MultiMap_Property;

		public static readonly CxvPropertyDeclaration _txtNpoint_display__Property;

		public static readonly CxvPropertyDeclaration txtIncr_display_Property;

		public object MMCheckBox2_OPT_CALHETP => ((CxvViewModel)this).GetValue(MMCheckBox2_OPT_CALHETP_Property);

		public object MMCheckBox1_var1 => ((CxvViewModel)this).GetValue(MMCheckBox1_var1_Property);

		public object fraHetp_state => ((CxvViewModel)this).GetValue(fraHetp_state_Property);

		public object lbtuPtop_1_var1 => ((CxvViewModel)this).GetValue(lbtuPtop_1_var1_Property);

		public object ogrOPT_SZNO_MultiMap => ((CxvViewModel)this).GetValue(ogrOPT_SZNO_MultiMap_Property);

		public object lbtuPtop_0_var1 => ((CxvViewModel)this).GetValue(lbtuPtop_0_var1_Property);

		public object lbtuPtop_2_var1 => ((CxvViewModel)this).GetValue(lbtuPtop_2_var1_Property);

		public object cboHight_Precision_MultiMap => ((CxvViewModel)this).GetValue(cboHight_Precision_MultiMap_Property);

		public object _txtNpoint_display_ => ((CxvViewModel)this).GetValue(_txtNpoint_display__Property);

		public object txtIncr_display => ((CxvViewModel)this).GetValue(txtIncr_display_Property);

		public MMDstwu_Input_Calcul_ViewModel()
		{
		}

		static MMDstwu_Input_Calcul_ViewModel()
		{
	ogrOPT_SZNO_MultiMap_Property = CxvPropertyDeclaration.Register("ogrOPT_SZNO_MultiMap", typeof(MMDstwu_Input_Calcul_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "ogrOPT_SZNO_display",
				DataPath = "@main.Input.OPT_SZNO"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Increment size for number of stages:",
				DisplayResourceKey = "MMDstwu_Input_Calcul_ViewModel__CxvMultiMapOption_Display_Increment_size_for_number_of_stages_",
				Value = "ogrOPT_SZNO_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrOPT_SZNO_display",
				Value = "SIZE"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Number of values in table:",
				DisplayResourceKey = "MMDstwu_Input_Calcul_ViewModel__CxvMultiMapOption_Display_Number_of_values_in_table_",
				Value = "ogrOPT_SZNO_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrOPT_SZNO_display",
				Value = "NUMBER"
			} }
				} },
	IsEnabledCondition = new CxvLogicalTest
			{
				DataPath = "@main.CC Nodes.GERRTPARAM"
			}
});
	lbtuPtop_0_var1_Property = CxvPropertyDeclaration.Register("lbtuPtop_0_var1", typeof(MMDstwu_Input_Calcul_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.LOWER"
			});
	lbtuPtop_2_var1_Property = CxvPropertyDeclaration.Register("lbtuPtop_2_var1", typeof(MMDstwu_Input_Calcul_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.UPPER"
			});
	cboHight_Precision_MultiMap_Property = CxvPropertyDeclaration.Register("cboHight_Precision_MultiMap", typeof(MMDstwu_Input_Calcul_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "_cboHight_Precision_display__",
				DataPath = "@main.Input.PRECISION"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "7",
				Value = "cboHight_Precision_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "_cboHight_Precision_display__",
				Value = "HIGH"
			} }
				}, new CxvMultiMapOption
			{
				Display = "5",
				Value = "cboHight_Precision_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "_cboHight_Precision_display__",
				Value = "STD"
			} }
				} }
});
	_txtNpoint_display__Property = CxvPropertyDeclaration.Register("_txtNpoint_display_", typeof(MMDstwu_Input_Calcul_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.NPOINT",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.SZB"
				}
			});
	txtIncr_display_Property = CxvPropertyDeclaration.Register("txtIncr_display", typeof(MMDstwu_Input_Calcul_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.INCR",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.SZA"
				}
			});
	}
	}
	[ProgId("MMDstwu.MMDstwu_Input_Calcul")]
	public class MMDstwu_Input_Calcul : MMTabPage, IComponentConnector
	{
		internal MMGroupBox MMFrame1;

		internal MMCheckBox MMCheckBox1;

		internal MMCheckBox MMCheckBox2;

		internal MMOptionGroup ogrOPT_SZNO;

		internal MMLabel lbtuPtop_0_label;

		internal MMVariableEdit lbtuPtop_0;

		internal MMLabel lbtuPtop_2_label;

		internal MMVariableEdit lbtuPtop_2;

		internal MMOptionButton ogrOPT_SZNO_opt0;

		internal MMValueEdit txtIncr;

		internal MMOptionButton ogrOPT_SZNO_opt1;

		internal MMValueEdit txtNpoint;

		internal MMLabel cboHight_Precision_label;

		internal MMComboEdit cboHight_Precision;

		internal MMGroupBox fraHetp;

		internal MMLabel lbtuPtop_1_label;

		internal MMVariableEdit lbtuPtop_1;

		private bool _contentLoaded;

		public MMDstwu_Input_Calcul()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDstwu_Input_Calcul_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Dstwu;component/mmdstwu_input_calcul.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			//IL_005d: Expected O, but got Unknown
			//IL_0060: Unknown result type (might be due to invalid IL or missing references)
			//IL_006a: Expected O, but got Unknown
			//IL_006d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0077: Expected O, but got Unknown
			//IL_007a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0084: Expected O, but got Unknown
			//IL_0087: Unknown result type (might be due to invalid IL or missing references)
			//IL_0091: Expected O, but got Unknown
			//IL_0094: Unknown result type (might be due to invalid IL or missing references)
			//IL_009e: Expected O, but got Unknown
			//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ab: Expected O, but got Unknown
			//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b8: Expected O, but got Unknown
			//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c5: Expected O, but got Unknown
			//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d2: Expected O, but got Unknown
			//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00df: Expected O, but got Unknown
			//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ec: Expected O, but got Unknown
			//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f9: Expected O, but got Unknown
			//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0106: Expected O, but got Unknown
			//IL_0109: Unknown result type (might be due to invalid IL or missing references)
			//IL_0113: Expected O, but got Unknown
			//IL_0116: Unknown result type (might be due to invalid IL or missing references)
			//IL_0120: Expected O, but got Unknown
			//IL_0123: Unknown result type (might be due to invalid IL or missing references)
			//IL_012d: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				MMFrame1 = (MMGroupBox)target;
				break;
			case 2:
				MMCheckBox1 = (MMCheckBox)target;
				break;
			case 3:
				MMCheckBox2 = (MMCheckBox)target;
				break;
			case 4:
				ogrOPT_SZNO = (MMOptionGroup)target;
				break;
			case 5:
				lbtuPtop_0_label = (MMLabel)target;
				break;
			case 6:
				lbtuPtop_0 = (MMVariableEdit)target;
				break;
			case 7:
				lbtuPtop_2_label = (MMLabel)target;
				break;
			case 8:
				lbtuPtop_2 = (MMVariableEdit)target;
				break;
			case 9:
				ogrOPT_SZNO_opt0 = (MMOptionButton)target;
				break;
			case 10:
				txtIncr = (MMValueEdit)target;
				break;
			case 11:
				ogrOPT_SZNO_opt1 = (MMOptionButton)target;
				break;
			case 12:
				txtNpoint = (MMValueEdit)target;
				break;
			case 13:
				cboHight_Precision_label = (MMLabel)target;
				break;
			case 14:
				cboHight_Precision = (MMComboEdit)target;
				break;
			case 15:
				fraHetp = (MMGroupBox)target;
				break;
			case 16:
				lbtuPtop_1_label = (MMLabel)target;
				break;
			case 17:
				lbtuPtop_1 = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDstwu_Input_Conver_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration lbtuPtop_0_var1_Property = CxvPropertyDeclaration.Register("lbtuPtop_0_var1", typeof(MMDstwu_Input_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.K_TOL"
		});

		public static readonly CxvPropertyDeclaration spnMAXIT_var1_Property = CxvPropertyDeclaration.Register("spnMAXIT_var1", typeof(MMDstwu_Input_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.MAXIT"
		});

		public static readonly CxvPropertyDeclaration lbtuPtop_1_var1_Property = CxvPropertyDeclaration.Register("lbtuPtop_1_var1", typeof(MMDstwu_Input_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.TEMP_TOL"
		});

		public static readonly CxvPropertyDeclaration lbtuPtop_2_var1_Property = CxvPropertyDeclaration.Register("lbtuPtop_2_var1", typeof(MMDstwu_Input_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Input.FLASH_TOL"
		});

		public static readonly CxvPropertyDeclaration cboPhases_MultiMap_Property;

		public static readonly CxvPropertyDeclaration spnFLASH_MAXIT_var1_Property;

		public object lbtuPtop_0_var1 => ((CxvViewModel)this).GetValue(lbtuPtop_0_var1_Property);

		public object spnMAXIT_var1 => ((CxvViewModel)this).GetValue(spnMAXIT_var1_Property);

		public object lbtuPtop_1_var1 => ((CxvViewModel)this).GetValue(lbtuPtop_1_var1_Property);

		public object lbtuPtop_2_var1 => ((CxvViewModel)this).GetValue(lbtuPtop_2_var1_Property);

		public object cboPhases_MultiMap => ((CxvViewModel)this).GetValue(cboPhases_MultiMap_Property);

		public object spnFLASH_MAXIT_var1 => ((CxvViewModel)this).GetValue(spnFLASH_MAXIT_var1_Property);

		public MMDstwu_Input_Conver_ViewModel()
		{
		}

		static MMDstwu_Input_Conver_ViewModel()
		{
	cboPhases_MultiMap_Property = CxvPropertyDeclaration.Register("cboPhases_MultiMap", typeof(MMDstwu_Input_Conver_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "cboPhases_var1",
				DataPath = "@main.Input.BLKOPFREWAT"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Vapor-Liquid",
				DisplayResourceKey = "MMDstwu_Input_Conver_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid",
				Value = "cboPhases_MultiMapOption_1",
				Prompt = "2 phases (vapor and liquid) are considered in phase equilibrium \r\ncalculations.",
				PromptResourceKey = "MMDstwu_Input_Conver_ViewModel__CxvMultiMapOption_Prompt_2_phases__vapor_and_liquid__are_considered_",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboPhases_var1",
				Value = "NO"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Vapor-Liquid-FreeWaterCondenser",
				DisplayResourceKey = "MMDstwu_Input_Conver_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_FreeWaterCondenser",
				Value = "cboPhases_MultiMapOption_2",
				Prompt = "3 phases (vapor, organic, and pure water) are considered in  \r\ncondenser calculations.",
				PromptResourceKey = "MMDstwu_Input_Conver_ViewModel__CxvMultiMapOption_Prompt_3_phases__vapor__organic__and_pure_water__a",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboPhases_var1",
				Value = "YES"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Vapor-Liquid-DirtyWaterCondenser",
				DisplayResourceKey = "MMDstwu_Input_Conver_ViewModel__CxvMultiMapOption_Display_Vapor_Liquid_DirtyWaterCondenser",
				Value = "cboPhases_MultiMapOption_3",
				Prompt = "3 phases (vapor, organic, and dirty water) are considered in  \r\ncondenser calculations.",
				PromptResourceKey = "MMDstwu_Input_Conver_ViewModel__CxvMultiMapOption_Prompt_3_phases__vapor__organic__and_dirty_water__",
					Values = { new CxvMultiMapValue
			{
				Variable = "cboPhases_var1",
				Value = "DIRTY"
			} }
				} }
});
	spnFLASH_MAXIT_var1_Property = CxvPropertyDeclaration.Register("spnFLASH_MAXIT_var1", typeof(MMDstwu_Input_Conver_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.FLASH_MAXIT"
			});
	}
	}
	[ProgId("MMDstwu.MMDstwu_Input_Conver")]
	public class MMDstwu_Input_Conver : MMTabPage, IComponentConnector
	{
		internal MMGroupBox fraFlash_Calculations;

		internal MMLabel cboPhases_label;

		internal MMComboEdit cboPhases;

		internal MMLabel spnFLASH_MAXIT_label;

		internal MMSpinBox spnFLASH_MAXIT;

		internal MMLabel lbtuPtop_2_label;

		internal MMVariableEdit lbtuPtop_2;

		internal MMGroupBox fraMin_StagesCal;

		internal MMLabel spnMAXIT_label;

		internal MMSpinBox spnMAXIT;

		internal MMLabel lbtuPtop_0_label;

		internal MMVariableEdit lbtuPtop_0;

		internal MMLabel lbtuPtop_1_label;

		internal MMVariableEdit lbtuPtop_1;

		private bool _contentLoaded;

		public MMDstwu_Input_Conver()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDstwu_Input_Conver_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Dstwu;component/mmdstwu_input_conver.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			//IL_0061: Unknown result type (might be due to invalid IL or missing references)
			//IL_006b: Expected O, but got Unknown
			//IL_006e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Expected O, but got Unknown
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Expected O, but got Unknown
			//IL_0088: Unknown result type (might be due to invalid IL or missing references)
			//IL_0092: Expected O, but got Unknown
			//IL_0095: Unknown result type (might be due to invalid IL or missing references)
			//IL_009f: Expected O, but got Unknown
			//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Expected O, but got Unknown
			//IL_00af: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d3: Expected O, but got Unknown
			//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e0: Expected O, but got Unknown
			//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ed: Expected O, but got Unknown
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fa: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				fraFlash_Calculations = (MMGroupBox)target;
				break;
			case 2:
				cboPhases_label = (MMLabel)target;
				break;
			case 3:
				cboPhases = (MMComboEdit)target;
				break;
			case 4:
				spnFLASH_MAXIT_label = (MMLabel)target;
				break;
			case 5:
				spnFLASH_MAXIT = (MMSpinBox)target;
				break;
			case 6:
				lbtuPtop_2_label = (MMLabel)target;
				break;
			case 7:
				lbtuPtop_2 = (MMVariableEdit)target;
				break;
			case 8:
				fraMin_StagesCal = (MMGroupBox)target;
				break;
			case 9:
				spnMAXIT_label = (MMLabel)target;
				break;
			case 10:
				spnMAXIT = (MMSpinBox)target;
				break;
			case 11:
				lbtuPtop_0_label = (MMLabel)target;
				break;
			case 12:
				lbtuPtop_0 = (MMVariableEdit)target;
				break;
			case 13:
				lbtuPtop_1_label = (MMLabel)target;
				break;
			case 14:
				lbtuPtop_1 = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDstwu_Input_Specif_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration ogrOPT_RDV_MultiMap_Property;

		public static readonly CxvPropertyDeclaration lbtuRDV_var1_Property;

		public static readonly CxvPropertyDeclaration lbtuRECOVL_var1_Property;

		public static readonly CxvPropertyDeclaration lbtuRECOVH_var1_Property;

		public static readonly CxvPropertyDeclaration _cboHeavykey_display__Property;

		public static readonly CxvPropertyDeclaration _cboLightkey_display__Property;

		public static readonly CxvPropertyDeclaration ogrOPT_NTRR_MultiMap_Property;

		public static readonly CxvPropertyDeclaration spnNstage_display_Property;

		public static readonly CxvPropertyDeclaration txtRR_display_Property;

		public static readonly CxvPropertyDeclaration lbtuPtop_0_var1_Property;

		public static readonly CxvPropertyDeclaration lbtuPbot_var1_Property;

		public object ogrOPT_RDV_MultiMap => ((CxvViewModel)this).GetValue(ogrOPT_RDV_MultiMap_Property);

		public object lbtuRDV_var1 => ((CxvViewModel)this).GetValue(lbtuRDV_var1_Property);

		public object lbtuRECOVL_var1 => ((CxvViewModel)this).GetValue(lbtuRECOVL_var1_Property);

		public object lbtuRECOVH_var1 => ((CxvViewModel)this).GetValue(lbtuRECOVH_var1_Property);

		public object _cboHeavykey_display_ => ((CxvViewModel)this).GetValue(_cboHeavykey_display__Property);

		public object _cboLightkey_display_ => ((CxvViewModel)this).GetValue(_cboLightkey_display__Property);

		public object ogrOPT_NTRR_MultiMap => ((CxvViewModel)this).GetValue(ogrOPT_NTRR_MultiMap_Property);

		public object spnNstage_display => ((CxvViewModel)this).GetValue(spnNstage_display_Property);

		public object txtRR_display => ((CxvViewModel)this).GetValue(txtRR_display_Property);

		public object lbtuPtop_0_var1 => ((CxvViewModel)this).GetValue(lbtuPtop_0_var1_Property);

		public object lbtuPbot_var1 => ((CxvViewModel)this).GetValue(lbtuPbot_var1_Property);

		public MMDstwu_Input_Specif_ViewModel()
		{
		}

		static MMDstwu_Input_Specif_ViewModel()
		{
	ogrOPT_RDV_MultiMap_Property = CxvPropertyDeclaration.Register("ogrOPT_RDV_MultiMap", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "ogrOPT_RDV_display",
				DataPath = "@main.Input.OPT_RDV"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Total condenser",
				DisplayResourceKey = "MMDstwu_Input_Specif_ViewModel__CxvMultiMapOption_Display_Total_condenser",
				Value = "ogrOPT_RDV_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrOPT_RDV_display",
				Value = "LIQUID"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Partial condenser with all vapor distillate",
				DisplayResourceKey = "MMDstwu_Input_Specif_ViewModel__CxvMultiMapOption_Display_Partial_condenser_with_all_vapor_distillat",
				Value = "ogrOPT_RDV_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrOPT_RDV_display",
				Value = "VAPOR"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Partial condenser with vapor and liquid distillate",
				DisplayResourceKey = "MMDstwu_Input_Specif_ViewModel__CxvMultiMapOption_Display_Partial_condenser_with_vapor_and_liquid_di",
				Value = "ogrOPT_RDV_MultiMapOption_3",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrOPT_RDV_display",
				Value = "VAPLIQ"
			} }
				} }
});
	lbtuRDV_var1_Property = CxvPropertyDeclaration.Register("lbtuRDV_var1", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.RDV",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.RDVA"
				}
			});
	lbtuRECOVL_var1_Property = CxvPropertyDeclaration.Register("lbtuRECOVL_var1", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.RECOVL"
			});
	lbtuRECOVH_var1_Property = CxvPropertyDeclaration.Register("lbtuRECOVH_var1", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.RECOVH"
			});
	_cboHeavykey_display__Property = CxvPropertyDeclaration.Register("_cboHeavykey_display_", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.HEAVYKEY"
			});
	_cboLightkey_display__Property = CxvPropertyDeclaration.Register("_cboLightkey_display_", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)2,
				DataPath = "@main.Input.LIGHTKEY"
			});
	ogrOPT_NTRR_MultiMap_Property = CxvPropertyDeclaration.Register("ogrOPT_NTRR_MultiMap", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvMultiMapProperty
{
	Variables = { new CxvMultiMapVariable
			{
				Name = "ogrOPT_NTRR_display",
				DataPath = "@main.Input.OPT_NTRR"
			} },
	Options = { new CxvMultiMapOption
			{
				Display = "Number of stages:",
				DisplayResourceKey = "MMDstwu_Input_Specif_ViewModel__CxvMultiMapOption_Display_Number_of_stages_",
				Value = "ogrOPT_NTRR_MultiMapOption_1",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrOPT_NTRR_display",
				Value = "NSTAGE"
			} }
				}, new CxvMultiMapOption
			{
				Display = "Reflux ratio:",
				DisplayResourceKey = "MMDstwu_Input_Specif_ViewModel__CxvMultiMapOption_Display_Reflux_ratio_",
				Value = "ogrOPT_NTRR_MultiMapOption_2",
					Values = { new CxvMultiMapValue
			{
				Variable = "ogrOPT_NTRR_display",
				Value = "RR"
			} }
				} }
});
	spnNstage_display_Property = CxvPropertyDeclaration.Register("spnNstage_display", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.NSTAGE",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.NTRB"
				}
			});
	txtRR_display_Property = CxvPropertyDeclaration.Register("txtRR_display", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.RR",
				IsEnabledCondition = new CxvLogicalTest
				{
					DataPath = "@main.CC Nodes.NTRA"
				}
			});
	lbtuPtop_0_var1_Property = CxvPropertyDeclaration.Register("lbtuPtop_0_var1", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.PTOP"
			});
	lbtuPbot_var1_Property = CxvPropertyDeclaration.Register("lbtuPbot_var1", typeof(MMDstwu_Input_Specif_ViewModel), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Input.PBOT"
			});
	}
	}
	[ProgId("MMDstwu.MMDstwu_Input_Specif")]
	public class MMDstwu_Input_Specif : MMTabPage, IComponentConnector
	{
		internal MMOptionGroup ogrOPT_NTRR;

		internal MMOptionButton ogrOPT_NTRR_opt0;

		internal MMSpinBox spnNstage;

		internal MMOptionButton ogrOPT_NTRR_opt1;

		internal MMValueEdit txtRR;

		internal MMGroupBox fraPressure;

		internal MMLabel lbtuPtop_0_label;

		internal MMVariableEdit lbtuPtop_0;

		internal MMLabel lbtuPbot_label;

		internal MMVariableEdit lbtuPbot;

		internal MMGroupBox fraRecoveries;

		internal MMLabel MMLabel1;

		internal MMLabel cboLightkey_label;

		internal MMComboEdit cboLightkey;

		internal MMLabel lbtuRECOVL_label;

		internal MMVariableEdit lbtuRECOVL;

		internal MMLabel lblHeavykey;

		internal MMLabel cboHeavykey_label;

		internal MMComboEdit cboHeavykey;

		internal MMLabel lbtuRECOVH_label;

		internal MMVariableEdit lbtuRECOVH;

		internal MMOptionGroup ogrOPT_RDV;

		internal MMOptionButton ogrOPT_RDV_opt0;

		internal MMOptionButton ogrOPT_RDV_opt1;

		internal MMOptionButton ogrOPT_RDV_opt2;

		internal MMLabel lbtuRDV_label;

		internal MMVariableEdit lbtuRDV;

		private bool _contentLoaded;

		public MMDstwu_Input_Specif()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDstwu_Input_Specif_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Dstwu;component/mmdstwu_input_specif.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0085: Expected O, but got Unknown
			//IL_0088: Unknown result type (might be due to invalid IL or missing references)
			//IL_0092: Expected O, but got Unknown
			//IL_0095: Unknown result type (might be due to invalid IL or missing references)
			//IL_009f: Expected O, but got Unknown
			//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ac: Expected O, but got Unknown
			//IL_00af: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b9: Expected O, but got Unknown
			//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Expected O, but got Unknown
			//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d3: Expected O, but got Unknown
			//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e0: Expected O, but got Unknown
			//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ed: Expected O, but got Unknown
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fa: Expected O, but got Unknown
			//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0107: Expected O, but got Unknown
			//IL_010a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0114: Expected O, but got Unknown
			//IL_0117: Unknown result type (might be due to invalid IL or missing references)
			//IL_0121: Expected O, but got Unknown
			//IL_0124: Unknown result type (might be due to invalid IL or missing references)
			//IL_012e: Expected O, but got Unknown
			//IL_0131: Unknown result type (might be due to invalid IL or missing references)
			//IL_013b: Expected O, but got Unknown
			//IL_013e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0148: Expected O, but got Unknown
			//IL_014b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0155: Expected O, but got Unknown
			//IL_0158: Unknown result type (might be due to invalid IL or missing references)
			//IL_0162: Expected O, but got Unknown
			//IL_0165: Unknown result type (might be due to invalid IL or missing references)
			//IL_016f: Expected O, but got Unknown
			//IL_0172: Unknown result type (might be due to invalid IL or missing references)
			//IL_017c: Expected O, but got Unknown
			//IL_017f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0189: Expected O, but got Unknown
			//IL_018c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0196: Expected O, but got Unknown
			//IL_0199: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a3: Expected O, but got Unknown
			//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b0: Expected O, but got Unknown
			//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
			//IL_01bd: Expected O, but got Unknown
			//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ca: Expected O, but got Unknown
			//IL_01cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d7: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				ogrOPT_NTRR = (MMOptionGroup)target;
				break;
			case 2:
				ogrOPT_NTRR_opt0 = (MMOptionButton)target;
				break;
			case 3:
				spnNstage = (MMSpinBox)target;
				break;
			case 4:
				ogrOPT_NTRR_opt1 = (MMOptionButton)target;
				break;
			case 5:
				txtRR = (MMValueEdit)target;
				break;
			case 6:
				fraPressure = (MMGroupBox)target;
				break;
			case 7:
				lbtuPtop_0_label = (MMLabel)target;
				break;
			case 8:
				lbtuPtop_0 = (MMVariableEdit)target;
				break;
			case 9:
				lbtuPbot_label = (MMLabel)target;
				break;
			case 10:
				lbtuPbot = (MMVariableEdit)target;
				break;
			case 11:
				fraRecoveries = (MMGroupBox)target;
				break;
			case 12:
				MMLabel1 = (MMLabel)target;
				break;
			case 13:
				cboLightkey_label = (MMLabel)target;
				break;
			case 14:
				cboLightkey = (MMComboEdit)target;
				break;
			case 15:
				lbtuRECOVL_label = (MMLabel)target;
				break;
			case 16:
				lbtuRECOVL = (MMVariableEdit)target;
				break;
			case 17:
				lblHeavykey = (MMLabel)target;
				break;
			case 18:
				cboHeavykey_label = (MMLabel)target;
				break;
			case 19:
				cboHeavykey = (MMComboEdit)target;
				break;
			case 20:
				lbtuRECOVH_label = (MMLabel)target;
				break;
			case 21:
				lbtuRECOVH = (MMVariableEdit)target;
				break;
			case 22:
				ogrOPT_RDV = (MMOptionGroup)target;
				break;
			case 23:
				ogrOPT_RDV_opt0 = (MMOptionButton)target;
				break;
			case 24:
				ogrOPT_RDV_opt1 = (MMOptionButton)target;
				break;
			case 25:
				ogrOPT_RDV_opt2 = (MMOptionButton)target;
				break;
			case 26:
				lbtuRDV_label = (MMLabel)target;
				break;
			case 27:
				lbtuRDV = (MMVariableEdit)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDstwu_Result_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration MIN_REFLUX_Property = CxvPropertyDeclaration.Register("MIN_REFLUX", typeof(MMDstwu_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.MIN_REFLUX"
		});

		public static readonly CxvPropertyDeclaration FEED_LOCATN_Property = CxvPropertyDeclaration.Register("FEED_LOCATN", typeof(MMDstwu_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FEED_LOCATN"
		});

		public static readonly CxvPropertyDeclaration RR_OUT_Property = CxvPropertyDeclaration.Register("RR_OUT", typeof(MMDstwu_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.RR_OUT"
		});

		public static readonly CxvPropertyDeclaration BAL_MOLI_TFL_Property = CxvPropertyDeclaration.Register("BAL_MOLI_TFL", typeof(MMDstwu_Result_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BAL_MOLI_TFL"
		});

		public static readonly CxvPropertyDeclaration tab0_var_Property = CxvPropertyDeclaration.Register("tab0_var", typeof(MMDstwu_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@FEED_LOCATN", "@MIN_REFLUX" }
		});

		public static readonly CxvPropertyDeclaration tab1_var_Property = CxvPropertyDeclaration.Register("tab1_var", typeof(MMDstwu_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@BAL_MOLI_TFL" }
		});

		public static readonly CxvPropertyDeclaration tab2_var_Property = CxvPropertyDeclaration.Register("tab2_var", typeof(MMDstwu_Result_ViewModel), (CxvPropertyBase)new CxvTabItemProperty
		{
			AccessibleDataPaths = { "@RR_OUT" }
		});

		public object MIN_REFLUX => ((CxvViewModel)this).GetValue(MIN_REFLUX_Property);

		public object FEED_LOCATN => ((CxvViewModel)this).GetValue(FEED_LOCATN_Property);

		public object RR_OUT => ((CxvViewModel)this).GetValue(RR_OUT_Property);

		public object BAL_MOLI_TFL => ((CxvViewModel)this).GetValue(BAL_MOLI_TFL_Property);

		public object tab0_var => ((CxvViewModel)this).GetValue(tab0_var_Property);

		public object tab1_var => ((CxvViewModel)this).GetValue(tab1_var_Property);

		public object tab2_var => ((CxvViewModel)this).GetValue(tab2_var_Property);
	}
	[ProgId("MMDstwu.MMDstwu_Result")]
	public class MMDstwu_Result : MMTabTemplate, IComponentConnector
	{
		internal MMTabStrip tabDstwu;

		internal MMTabItem tab0;

		internal MMTabItem tab1;

		internal MMTabItem tab2;

		internal MMTabItem info;

		private bool _contentLoaded;

		public MMDstwu_Result()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDstwu_Result_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Dstwu;component/mmdstwu_result.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0020: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Expected O, but got Unknown
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Expected O, but got Unknown
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Expected O, but got Unknown
			//IL_0047: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			switch (connectionId)
			{
			case 1:
				tabDstwu = (MMTabStrip)target;
				break;
			case 2:
				tab0 = (MMTabItem)target;
				break;
			case 3:
				tab1 = (MMTabItem)target;
				break;
			case 4:
				tab2 = (MMTabItem)target;
				break;
			case 5:
				info = (MMTabItem)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public class MMDstwu_Result_RRProf_ViewModel : MMTabPageViewModel
	{
		public class grdStages_GridData_ItemTemplate : MMViewModel
		{
			public static readonly CxvPropertyDeclaration MMTextBox7_var1_Property = CxvPropertyDeclaration.Register("MMTextBox7_var1", typeof(grdStages_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				DataPath = "@main.Output.RR_OUT.@y"
			});

			public static readonly CxvPropertyDeclaration MMTextBox6_var1_Property = CxvPropertyDeclaration.Register("MMTextBox6_var1", typeof(grdStages_GridData_ItemTemplate), (CxvPropertyBase)new CxvVariableProperty
			{
				ExposeAs = (CxvVariableTypeCode)6,
				DataPath = "@main.Output.RR_OUT.@y"
			});

			public object MMTextBox7_var1 => ((CxvViewModel)this).GetValue(MMTextBox7_var1_Property);

			public object MMTextBox6_var1 => ((CxvViewModel)this).GetValue(MMTextBox6_var1_Property);
		}

		public static readonly CxvPropertyDeclaration grdStages_GridData_Property = CxvPropertyDeclaration.Register("grdStages_GridData", typeof(MMDstwu_Result_RRProf_ViewModel), (CxvPropertyBase)new CxvVectorProperty
		{
			ItemType = typeof(grdStages_GridData_ItemTemplate),
			IndexBasis = (CxvIndexBasisBase)new CxvChildCountIndexBasis
			{
				DataPath = "@main.Output.RR_OUT",
				UseChildId = true,
				Name = "y"
			}
		});

		public object grdStages_GridData => ((CxvViewModel)this).GetValue(grdStages_GridData_Property);
	}
	[ProgId("MMDstwu.MMDstwu_Result_RRProf")]
	public class MMDstwu_Result_RRProf : MMTabPage, IComponentConnector
	{
		internal MMScrollArea grdStages;

		private bool _contentLoaded;

		public MMDstwu_Result_RRProf()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDstwu_Result_RRProf_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Dstwu;component/mmdstwu_result_rrprof.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			if (connectionId == 1)
			{
				grdStages = (MMScrollArea)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
	public class MMDstwu_Result_Summar_ViewModel : MMTabPageViewModel
	{
		public static readonly CxvPropertyDeclaration lbtuHETP_var1_Property = CxvPropertyDeclaration.Register("lbtuHETP_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.HETP"
		});

		public static readonly CxvPropertyDeclaration TXTRR_0_var1_Property = CxvPropertyDeclaration.Register("TXTRR_0_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.HETP"
		});

		public static readonly CxvPropertyDeclaration MMTextBox5_var1_Property = CxvPropertyDeclaration.Register("MMTextBox5_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.DIST_VS_FEED"
		});

		public static readonly CxvPropertyDeclaration MMTextBox4_var1_Property = CxvPropertyDeclaration.Register("MMTextBox4_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOTTOM_TEMP"
		});

		public static readonly CxvPropertyDeclaration MMTextBox3_var1_Property = CxvPropertyDeclaration.Register("MMTextBox3_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.DISTIL_TEMP"
		});

		public static readonly CxvPropertyDeclaration MMTextBox2_var1_Property = CxvPropertyDeclaration.Register("MMTextBox2_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COND_DUTY"
		});

		public static readonly CxvPropertyDeclaration MMTextBox1_var1_Property = CxvPropertyDeclaration.Register("MMTextBox1_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.REB_DUTY"
		});

		public static readonly CxvPropertyDeclaration TXTRR_1_var1_Property = CxvPropertyDeclaration.Register("TXTRR_1_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.RECT_STAGES"
		});

		public static readonly CxvPropertyDeclaration txtTOP_VFLOW_var1_Property = CxvPropertyDeclaration.Register("txtTOP_VFLOW_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.FEED_LOCATN"
		});

		public static readonly CxvPropertyDeclaration txtTOP_LFLOW_var1_Property = CxvPropertyDeclaration.Register("txtTOP_LFLOW_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.ACT_STAGES"
		});

		public static readonly CxvPropertyDeclaration txtSCDUTY_var1_Property = CxvPropertyDeclaration.Register("txtSCDUTY_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.MIN_STAGES"
		});

		public static readonly CxvPropertyDeclaration txtCOND_DUTY_var1_Property = CxvPropertyDeclaration.Register("txtCOND_DUTY_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.ACT_REFLUX"
		});

		public static readonly CxvPropertyDeclaration txtTOP_TEMP_var1_Property = CxvPropertyDeclaration.Register("txtTOP_TEMP_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.MIN_REFLUX"
		});

		public static readonly CxvPropertyDeclaration lbtuTOP_TEMPu_var1_Property = CxvPropertyDeclaration.Register("lbtuTOP_TEMPu_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.REB_DUTY"
		});

		public static readonly CxvPropertyDeclaration lvtuCOND_DUTYu_var1_Property = CxvPropertyDeclaration.Register("lvtuCOND_DUTYu_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.COND_DUTY"
		});

		public static readonly CxvPropertyDeclaration lbtuSCDUTYu_var1_Property = CxvPropertyDeclaration.Register("lbtuSCDUTYu_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.DISTIL_TEMP"
		});

		public static readonly CxvPropertyDeclaration lbtuTOP_LFLOWu_var1_Property = CxvPropertyDeclaration.Register("lbtuTOP_LFLOWu_var1", typeof(MMDstwu_Result_Summar_ViewModel), (CxvPropertyBase)new CxvVariableProperty
		{
			DataPath = "@main.Output.BOTTOM_TEMP"
		});

		public object lbtuHETP_var1 => ((CxvViewModel)this).GetValue(lbtuHETP_var1_Property);

		public object TXTRR_0_var1 => ((CxvViewModel)this).GetValue(TXTRR_0_var1_Property);

		public object MMTextBox5_var1 => ((CxvViewModel)this).GetValue(MMTextBox5_var1_Property);

		public object MMTextBox4_var1 => ((CxvViewModel)this).GetValue(MMTextBox4_var1_Property);

		public object MMTextBox3_var1 => ((CxvViewModel)this).GetValue(MMTextBox3_var1_Property);

		public object MMTextBox2_var1 => ((CxvViewModel)this).GetValue(MMTextBox2_var1_Property);

		public object MMTextBox1_var1 => ((CxvViewModel)this).GetValue(MMTextBox1_var1_Property);

		public object TXTRR_1_var1 => ((CxvViewModel)this).GetValue(TXTRR_1_var1_Property);

		public object txtTOP_VFLOW_var1 => ((CxvViewModel)this).GetValue(txtTOP_VFLOW_var1_Property);

		public object txtTOP_LFLOW_var1 => ((CxvViewModel)this).GetValue(txtTOP_LFLOW_var1_Property);

		public object txtSCDUTY_var1 => ((CxvViewModel)this).GetValue(txtSCDUTY_var1_Property);

		public object txtCOND_DUTY_var1 => ((CxvViewModel)this).GetValue(txtCOND_DUTY_var1_Property);

		public object txtTOP_TEMP_var1 => ((CxvViewModel)this).GetValue(txtTOP_TEMP_var1_Property);

		public object lbtuTOP_TEMPu_var1 => ((CxvViewModel)this).GetValue(lbtuTOP_TEMPu_var1_Property);

		public object lvtuCOND_DUTYu_var1 => ((CxvViewModel)this).GetValue(lvtuCOND_DUTYu_var1_Property);

		public object lbtuSCDUTYu_var1 => ((CxvViewModel)this).GetValue(lbtuSCDUTYu_var1_Property);

		public object lbtuTOP_LFLOWu_var1 => ((CxvViewModel)this).GetValue(lbtuTOP_LFLOWu_var1_Property);
	}
	[ProgId("MMDstwu.MMDstwu_Result_Summar")]
	public class MMDstwu_Result_Summar : MMTabPage, IComponentConnector
	{
		internal MMScrollAreaManualLayout grdSummary;

		private bool _contentLoaded;

		public MMDstwu_Result_Summar()
		{
			((MMViewModelContainer)this).ViewModelType = typeof(MMDstwu_Result_Summar_ViewModel);
			InitializeComponent();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/AspenTech.AspenPlus.MMForms.Blocks.Dstwu;component/mmdstwu_result_summar.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			if (connectionId == 1)
			{
				grdSummary = (MMScrollAreaManualLayout)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
}
namespace XamlGeneratedNamespace
{
	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	public sealed class GeneratedInternalTypeHelper : InternalTypeHelper
	{
		protected override object CreateInstance(Type type, CultureInfo culture)
		{
			return Activator.CreateInstance(type, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.CreateInstance, null, null, culture);
		}

		protected override object GetPropertyValue(PropertyInfo propertyInfo, object target, CultureInfo culture)
		{
			return propertyInfo.GetValue(target, BindingFlags.Default, null, null, culture);
		}

		protected override void SetPropertyValue(PropertyInfo propertyInfo, object target, object value, CultureInfo culture)
		{
			propertyInfo.SetValue(target, value, BindingFlags.Default, null, null, culture);
		}

		protected override Delegate CreateDelegate(Type delegateType, object target, string handler)
		{
			return (Delegate)target.GetType().InvokeMember("_CreateDelegate", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, target, new object[2] { delegateType, handler }, null);
		}

		protected override void AddEventHandler(EventInfo eventInfo, object target, Delegate handler)
		{
			eventInfo.AddEventHandler(target, handler);
		}
	}
}
