using System.Runtime.InteropServices;

namespace HeatExchanger;

[ComVisible(true)]
[Guid("8F469C74-CB90-4154-BBB4-8C7FC320C766")]
[ProgId("HeatExchanger.HetToHetxConverterCollection.41.0")]
[ClassInterface(ClassInterfaceType.None)]
public class HetToHetxConverterCollection : ConverterCollection
{
	public HetToHetxConverterCollection()
		: base("Hetran")
	{
	}
}
