using System;
using System.Linq;
using System.Reflection.Metadata;

static partial class ResolvedCilEvidence
{
    static string Literal(MetadataReader reader, ConstantHandle handle)
    {
        if (handle.IsNil)
            return "";
        var value = reader.GetConstant(handle);
        return Part("constant", value.TypeCode.ToString(), Convert.ToHexString(reader.GetBlobBytes(value.Value)));
    }

    static object Parameters(MetadataReader reader, Signatures names, GenericParameterHandleCollection handles) =>
        handles.Select(reader.GetGenericParameter).OrderBy(p => p.Index).Select(p => new
        {
            p.Index, Name = reader.GetString(p.Name), Attributes = (int)p.Attributes,
            Constraints = p.GetConstraints().Select(reader.GetGenericParameterConstraint).Select(c => new
            {
                Type = names.Entity(c.Type), Attributes = Attributes(reader, names, c.GetCustomAttributes()).Order().ToArray(),
            }).OrderBy(c => c.Type, StringComparer.Ordinal).ToArray(),
            Custom = Attributes(reader, names, p.GetCustomAttributes()).Order().ToArray(),
        }).ToArray();

    static string ExportTarget(MetadataReader reader, Signatures names, EntityHandle handle, int depth = 0)
    {
        if (depth > 20)
            throw new BadImageFormatException("Nested exported type ownership exceeds its expected depth");
        if (handle.Kind != HandleKind.ExportedType)
            return names.Entity(handle);
        var def = reader.GetExportedType((ExportedTypeHandle)handle);
        return Part("export", reader.GetString(def.Namespace), reader.GetString(def.Name), ExportTarget(reader, names, def.Implementation, depth + 1));
    }

    static object Details(MetadataReader reader, Signatures names) => new
    {
        Types = reader.TypeDefinitions.Select(h =>
        {
            var type = reader.GetTypeDefinition(h);
            var layout = type.GetLayout();
            return new
            {
                Identity = names.Entity(h), Layout = new { layout.IsDefault, layout.Size, layout.PackingSize },
                GenericParameters = Parameters(reader, names, type.GetGenericParameters()),
                Fields = type.GetFields().Select(f =>
                {
                    var def = reader.GetFieldDefinition(f);
                    return new
                    {
                        Identity = names.Entity(f), Attributes = (int)def.Attributes, Offset = def.GetOffset(),
                        HasRva = def.GetRelativeVirtualAddress() != 0, Constant = Literal(reader, def.GetDefaultValue()),
                        Marshal = Convert.ToHexString(reader.GetBlobBytes(def.GetMarshallingDescriptor())),
                        Custom = Attributes(reader, names, def.GetCustomAttributes()).Order().ToArray(),
                    };
                }).ToArray(),
                Properties = type.GetProperties().Select(reader.GetPropertyDefinition).Select(p =>
                {
                    var signature = p.DecodeSignature(names, 0);
                    var access = p.GetAccessors();
                    return new
                    {
                        Name = reader.GetString(p.Name), Attributes = (int)p.Attributes, Signature = new
                        {
                            Header = signature.Header.RawValue, signature.ReturnType, Parameters = signature.ParameterTypes.ToArray(),
                        },
                        Constant = Literal(reader, p.GetDefaultValue()), Getter = names.Entity(access.Getter), Setter = names.Entity(access.Setter),
                        Other = access.Others.Select(h => names.Entity(h)).Order().ToArray(),
                        Custom = Attributes(reader, names, p.GetCustomAttributes()).Order().ToArray(),
                    };
                }).OrderBy(p => p.Name, StringComparer.Ordinal).ToArray(),
                Events = type.GetEvents().Select(reader.GetEventDefinition).Select(e =>
                {
                    var access = e.GetAccessors();
                    return new
                    {
                        Name = reader.GetString(e.Name), Attributes = (int)e.Attributes, Type = names.Entity(e.Type),
                        Add = names.Entity(access.Adder), Remove = names.Entity(access.Remover), Raise = names.Entity(access.Raiser),
                        Other = access.Others.Select(h => names.Entity(h)).Order().ToArray(),
                        Custom = Attributes(reader, names, e.GetCustomAttributes()).Order().ToArray(),
                    };
                }).OrderBy(e => e.Name, StringComparer.Ordinal).ToArray(),
                Overrides = type.GetMethodImplementations().Select(reader.GetMethodImplementation)
                    .Select(m => Part("override", names.Entity(m.MethodDeclaration), names.Entity(m.MethodBody))).Order().ToArray(),
            };
        }).OrderBy(t => t.Identity, StringComparer.Ordinal).ToArray(),
        Methods = reader.MethodDefinitions.Select(h =>
        {
            var def = reader.GetMethodDefinition(h);
            var import = def.GetImport();
            return new
            {
                Identity = names.Entity(h), GenericParameters = Parameters(reader, names, def.GetGenericParameters()),
                Import = import.Module.IsNil ? "" : Part("pinvoke", names.Entity(import.Module), reader.GetString(import.Name), ((int)import.Attributes).ToString()),
            };
        }).OrderBy(m => m.Identity, StringComparer.Ordinal).ToArray(),
        Exports = reader.ExportedTypes.Select(h =>
        {
            var definition = reader.GetExportedType(h);
            return Part("export", reader.GetString(definition.Namespace), reader.GetString(definition.Name),
                definition.IsForwarder.ToString(), ((int)definition.Attributes).ToString(), ExportTarget(reader, names, definition.Implementation));
        }).Order().ToArray(),
        Resources = reader.ManifestResources.Select(h =>
        {
            var manifest = reader.GetManifestResource(h);
            return Part("resource", reader.GetString(manifest.Name), ((int)manifest.Attributes).ToString(), names.Entity(manifest.Implementation));
        }).Order().ToArray(),
    };
}
