using System.Reflection;
using System.Windows;
using System.Windows.Controls;

[assembly: AssemblyVersion("20.2.20202.38")]

namespace Infragistics.Windows.Controls
{
    public class XamScreenTip : ContentControl
    {
        public object Header { get; set; }
        public Visibility FooterSeparatorVisibility { get; set; }
    }
}
