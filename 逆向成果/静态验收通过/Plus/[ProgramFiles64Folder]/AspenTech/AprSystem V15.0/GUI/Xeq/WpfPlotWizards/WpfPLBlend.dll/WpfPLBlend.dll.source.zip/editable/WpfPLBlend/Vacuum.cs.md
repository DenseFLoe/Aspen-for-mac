# Vacuum.cs

Source: editable/WpfPLBlend/Vacuum.cs

Source SHA-256: 6f9864859348060f9b274e273a336b219e9aeeabae61fa8f2c6be7e4e25e91be
