# RibbonPlotWizardMgr.cs

Source: editable/WpfPLBlend/RibbonPlotWizardMgr.cs

Source SHA-256: e666dd2123acbd3e9ad0e2359f854fe06c3cce87bf111e4b427d1f3fe0df76cc
