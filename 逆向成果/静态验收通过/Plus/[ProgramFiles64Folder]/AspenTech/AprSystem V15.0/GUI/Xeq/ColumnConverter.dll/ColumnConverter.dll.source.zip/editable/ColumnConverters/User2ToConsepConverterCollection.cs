using System.Runtime.InteropServices;

namespace ColumnConverters;

[ComVisible(true)]
[Guid("707B9B61-93C2-4A1B-9677-E7884843B19D")]
[ProgId("Column.User2ToConsepConverterCollection.41.0")]
[ClassInterface(ClassInterfaceType.None)]
public class User2ToConsepConverterCollection : ConverterCollection
{
	public User2ToConsepConverterCollection()
		: base("User2")
	{
	}
}
