; Original DOS and PE header fields for an unsigned rebuild.
bits 16

    dw 0x5a4d                                                  ; +0x0000 DOS.e_magic
    dw 0x90                                                    ; +0x0002 DOS.e_cblp
    dw 0x3                                                     ; +0x0004 DOS.e_cp
    dw 0x0                                                     ; +0x0006 DOS.e_crlc
    dw 0x4                                                     ; +0x0008 DOS.e_cparhdr
    dw 0x0                                                     ; +0x000a DOS.e_minalloc
    dw 0xffff                                                  ; +0x000c DOS.e_maxalloc
    dw 0x0                                                     ; +0x000e DOS.e_ss
    dw 0xb8                                                    ; +0x0010 DOS.e_sp
    dw 0x0                                                     ; +0x0012 DOS.e_csum
    dw 0x0                                                     ; +0x0014 DOS.e_ip
    dw 0x0                                                     ; +0x0016 DOS.e_cs
    dw 0x40                                                    ; +0x0018 DOS.e_lfarlc
    dw 0x0                                                     ; +0x001a DOS.e_ovno
    dq 0x0                                                     ; +0x001c DOS.e_res
    dw 0x0                                                     ; +0x0024 DOS.e_oemid
    dw 0x0                                                     ; +0x0026 DOS.e_oeminfo
    times 20 db 0                                              ; +0x0028 DOS.e_res2
    dd 0xf8                                                    ; +0x003c DOS.e_lfanew
    dos_stub: push cs
    pop ds
    mov dx, dos_message - dos_stub
    mov ah, 9
    int 0x21
    mov ax, 0x4c01
    int 0x21
dos_message: db 'This program cannot be run in DOS mode.', 13, 13, 10, '$' ; +0x0040 MSVC DOS status message and exit stub
    times 0x7 db 0  ; zero fill at +0x79
    dd 0x95a63322                                              ; +0x0080 MSVC Rich build provenance
    dd 0xc6c85266                                              ; +0x0084 MSVC Rich build provenance
    dd 0xc6c85266                                              ; +0x0088 MSVC Rich build provenance
    dd 0xc6c85266                                              ; +0x008c MSVC Rich build provenance
    dd 0xc65b2a6f                                              ; +0x0090 MSVC Rich build provenance
    dd 0xc6c85264                                              ; +0x0094 MSVC Rich build provenance
    dd 0xc7c92d73                                              ; +0x0098 MSVC Rich build provenance
    dd 0xc6c85265                                              ; +0x009c MSVC Rich build provenance
    dd 0xc7cd2d73                                              ; +0x00a0 MSVC Rich build provenance
    dd 0xc6c8526c                                              ; +0x00a4 MSVC Rich build provenance
    dd 0xc7cc2d73                                              ; +0x00a8 MSVC Rich build provenance
    dd 0xc6c8526e                                              ; +0x00ac MSVC Rich build provenance
    dd 0xc7cb2d73                                              ; +0x00b0 MSVC Rich build provenance
    dd 0xc6c85265                                              ; +0x00b4 MSVC Rich build provenance
    dd 0xc7c92a2d                                              ; +0x00b8 MSVC Rich build provenance
    dd 0xc6c85264                                              ; +0x00bc MSVC Rich build provenance
    dd 0xc6c95266                                              ; +0x00c0 MSVC Rich build provenance
    dd 0xc6c85244                                              ; +0x00c4 MSVC Rich build provenance
    dd 0xc7c1d25e                                              ; +0x00c8 MSVC Rich build provenance
    dd 0xc6c85265                                              ; +0x00cc MSVC Rich build provenance
    dd 0xc637d25e                                              ; +0x00d0 MSVC Rich build provenance
    dd 0xc6c85267                                              ; +0x00d4 MSVC Rich build provenance
    dd 0xc65f5266                                              ; +0x00d8 MSVC Rich build provenance
    dd 0xc6c85267                                              ; +0x00dc MSVC Rich build provenance
    dd 0xc7cad25e                                              ; +0x00e0 MSVC Rich build provenance
    dd 0xc6c85267                                              ; +0x00e4 MSVC Rich build provenance
    dd 0x68636952                                              ; +0x00e8 MSVC Rich build provenance
    dd 0xc6c85266                                              ; +0x00ec MSVC Rich build provenance
    times 0x8 db 0  ; zero fill at +0xf0
    dd 0x4550                                                  ; +0x00f8 NT signature.Signature
    dw 0x8664                                                  ; +0x00fc COFF.Machine
    dw 0x6                                                     ; +0x00fe COFF.NumberOfSections
    dd 0x67fd0853                                              ; +0x0100 COFF.TimeDateStamp
    dd 0x0                                                     ; +0x0104 COFF.PointerToSymbolTable
    dd 0x0                                                     ; +0x0108 COFF.NumberOfSymbols
    dw 0xf0                                                    ; +0x010c COFF.SizeOfOptionalHeader
    dw 0x2022                                                  ; +0x010e COFF.Characteristics
    dw 0x20b                                                   ; +0x0110 PE32+.Magic
    db 0xe                                                     ; +0x0112 PE32+.MajorLinkerVersion
    db 0x25                                                    ; +0x0113 PE32+.MinorLinkerVersion
    dd 0xe00                                                   ; +0x0114 PE32+.SizeOfCode
    dd 0x56a000                                                ; +0x0118 PE32+.SizeOfInitializedData
    dd 0x0                                                     ; +0x011c PE32+.SizeOfUninitializedData
    dd 0x1360                                                  ; +0x0120 PE32+.AddressOfEntryPoint
    dd 0x1000                                                  ; +0x0124 PE32+.BaseOfCode
    dq 0x180000000                                             ; +0x0128 PE32+.ImageBase
    dd 0x1000                                                  ; +0x0130 PE32+.SectionAlignment
    dd 0x200                                                   ; +0x0134 PE32+.FileAlignment
    dw 0x6                                                     ; +0x0138 PE32+.MajorOperatingSystemVersion
    dw 0x0                                                     ; +0x013a PE32+.MinorOperatingSystemVersion
    dw 0x0                                                     ; +0x013c PE32+.MajorImageVersion
    dw 0x0                                                     ; +0x013e PE32+.MinorImageVersion
    dw 0x6                                                     ; +0x0140 PE32+.MajorSubsystemVersion
    dw 0x0                                                     ; +0x0142 PE32+.MinorSubsystemVersion
    dd 0x0                                                     ; +0x0144 PE32+.Reserved1
    dd 0x56f000                                                ; +0x0148 PE32+.SizeOfImage
    dd 0x400                                                   ; +0x014c PE32+.SizeOfHeaders
    dd 0                                                       ; +0x0150 PE32+.CheckSum
    dw 0x2                                                     ; +0x0154 PE32+.Subsystem
    dw 0x160                                                   ; +0x0156 PE32+.DllCharacteristics
    dq 0x100000                                                ; +0x0158 PE32+.SizeOfStackReserve
    dq 0x1000                                                  ; +0x0160 PE32+.SizeOfStackCommit
    dq 0x100000                                                ; +0x0168 PE32+.SizeOfHeapReserve
    dq 0x1000                                                  ; +0x0170 PE32+.SizeOfHeapCommit
    dd 0x0                                                     ; +0x0178 PE32+.LoaderFlags
    dd 0x10                                                    ; +0x017c PE32+.NumberOfRvaAndSizes
    dd 0x0                                                     ; +0x0180 EXPORT.VirtualAddress
    dd 0x0                                                     ; +0x0184 EXPORT.Size
    dd 0x282c                                                  ; +0x0188 IMPORT.VirtualAddress
    dd 0x50                                                    ; +0x018c IMPORT.Size
    dd 0x5000                                                  ; +0x0190 RESOURCE.VirtualAddress
    dd 0x568700                                                ; +0x0194 RESOURCE.Size
    dd 0x4000                                                  ; +0x0198 EXCEPTION.VirtualAddress
    dd 0x1a4                                                   ; +0x019c EXCEPTION.Size
    dd 0                                                       ; +0x01a0 SECURITY.VirtualAddress
    dd 0                                                       ; +0x01a4 SECURITY.Size
    dd 0x56e000                                                ; +0x01a8 BASERELOC.VirtualAddress
    dd 0x2c                                                    ; +0x01ac BASERELOC.Size
    dd 0x22d0                                                  ; +0x01b0 DEBUG.VirtualAddress
    dd 0x70                                                    ; +0x01b4 DEBUG.Size
    dd 0x0                                                     ; +0x01b8 COPYRIGHT.VirtualAddress
    dd 0x0                                                     ; +0x01bc COPYRIGHT.Size
    dd 0x0                                                     ; +0x01c0 GLOBALPTR.VirtualAddress
    dd 0x0                                                     ; +0x01c4 GLOBALPTR.Size
    dd 0x0                                                     ; +0x01c8 TLS.VirtualAddress
    dd 0x0                                                     ; +0x01cc TLS.Size
    dd 0x2190                                                  ; +0x01d0 LOAD_CONFIG.VirtualAddress
    dd 0x140                                                   ; +0x01d4 LOAD_CONFIG.Size
    dd 0x0                                                     ; +0x01d8 BOUND_IMPORT.VirtualAddress
    dd 0x0                                                     ; +0x01dc BOUND_IMPORT.Size
    dd 0x2000                                                  ; +0x01e0 IAT.VirtualAddress
    dd 0xe8                                                    ; +0x01e4 IAT.Size
    dd 0x0                                                     ; +0x01e8 DELAY_IMPORT.VirtualAddress
    dd 0x0                                                     ; +0x01ec DELAY_IMPORT.Size
    dd 0x0                                                     ; +0x01f0 COM_DESCRIPTOR.VirtualAddress
    dd 0x0                                                     ; +0x01f4 COM_DESCRIPTOR.Size
    dd 0x0                                                     ; +0x01f8 RESERVED.VirtualAddress
    dd 0x0                                                     ; +0x01fc RESERVED.Size
    dq 0x747865742e                                            ; +0x0200 .text.Name
    dd 0xdf8                                                   ; +0x0208 .text.Misc
    dd 0x1000                                                  ; +0x020c .text.VirtualAddress
    dd 0xe00                                                   ; +0x0210 .text.SizeOfRawData
    dd 0x400                                                   ; +0x0214 .text.PointerToRawData
    dd 0x0                                                     ; +0x0218 .text.PointerToRelocations
    dd 0x0                                                     ; +0x021c .text.PointerToLinenumbers
    dw 0x0                                                     ; +0x0220 .text.NumberOfRelocations
    dw 0x0                                                     ; +0x0222 .text.NumberOfLinenumbers
    dd 0x60000020                                              ; +0x0224 .text.Characteristics
    dq 0x61746164722e                                          ; +0x0228 .rdata.Name
    dd 0xbe6                                                   ; +0x0230 .rdata.Misc
    dd 0x2000                                                  ; +0x0234 .rdata.VirtualAddress
    dd 0xc00                                                   ; +0x0238 .rdata.SizeOfRawData
    dd 0x1200                                                  ; +0x023c .rdata.PointerToRawData
    dd 0x0                                                     ; +0x0240 .rdata.PointerToRelocations
    dd 0x0                                                     ; +0x0244 .rdata.PointerToLinenumbers
    dw 0x0                                                     ; +0x0248 .rdata.NumberOfRelocations
    dw 0x0                                                     ; +0x024a .rdata.NumberOfLinenumbers
    dd 0x40000040                                              ; +0x024c .rdata.Characteristics
    dq 0x617461642e                                            ; +0x0250 .data.Name
    dd 0x640                                                   ; +0x0258 .data.Misc
    dd 0x3000                                                  ; +0x025c .data.VirtualAddress
    dd 0x200                                                   ; +0x0260 .data.SizeOfRawData
    dd 0x1e00                                                  ; +0x0264 .data.PointerToRawData
    dd 0x0                                                     ; +0x0268 .data.PointerToRelocations
    dd 0x0                                                     ; +0x026c .data.PointerToLinenumbers
    dw 0x0                                                     ; +0x0270 .data.NumberOfRelocations
    dw 0x0                                                     ; +0x0272 .data.NumberOfLinenumbers
    dd 0xc0000040                                              ; +0x0274 .data.Characteristics
    dq 0x61746164702e                                          ; +0x0278 .pdata.Name
    dd 0x1a4                                                   ; +0x0280 .pdata.Misc
    dd 0x4000                                                  ; +0x0284 .pdata.VirtualAddress
    dd 0x200                                                   ; +0x0288 .pdata.SizeOfRawData
    dd 0x2000                                                  ; +0x028c .pdata.PointerToRawData
    dd 0x0                                                     ; +0x0290 .pdata.PointerToRelocations
    dd 0x0                                                     ; +0x0294 .pdata.PointerToLinenumbers
    dw 0x0                                                     ; +0x0298 .pdata.NumberOfRelocations
    dw 0x0                                                     ; +0x029a .pdata.NumberOfLinenumbers
    dd 0x40000040                                              ; +0x029c .pdata.Characteristics
    dq 0x637273722e                                            ; +0x02a0 .rsrc.Name
    dd 0x568700                                                ; +0x02a8 .rsrc.Misc
    dd 0x5000                                                  ; +0x02ac .rsrc.VirtualAddress
    dd 0x568800                                                ; +0x02b0 .rsrc.SizeOfRawData
    dd 0x2200                                                  ; +0x02b4 .rsrc.PointerToRawData
    dd 0x0                                                     ; +0x02b8 .rsrc.PointerToRelocations
    dd 0x0                                                     ; +0x02bc .rsrc.PointerToLinenumbers
    dw 0x0                                                     ; +0x02c0 .rsrc.NumberOfRelocations
    dw 0x0                                                     ; +0x02c2 .rsrc.NumberOfLinenumbers
    dd 0x40000040                                              ; +0x02c4 .rsrc.Characteristics
    dq 0x636f6c65722e                                          ; +0x02c8 .reloc.Name
    dd 0x2c                                                    ; +0x02d0 .reloc.Misc
    dd 0x56e000                                                ; +0x02d4 .reloc.VirtualAddress
    dd 0x200                                                   ; +0x02d8 .reloc.SizeOfRawData
    dd 0x56aa00                                                ; +0x02dc .reloc.PointerToRawData
    dd 0x0                                                     ; +0x02e0 .reloc.PointerToRelocations
    dd 0x0                                                     ; +0x02e4 .reloc.PointerToLinenumbers
    dw 0x0                                                     ; +0x02e8 .reloc.NumberOfRelocations
    dw 0x0                                                     ; +0x02ea .reloc.NumberOfLinenumbers
    dd 0x42000040                                              ; +0x02ec .reloc.Characteristics
    times 0x110 db 0  ; zero fill at +0x2f0
