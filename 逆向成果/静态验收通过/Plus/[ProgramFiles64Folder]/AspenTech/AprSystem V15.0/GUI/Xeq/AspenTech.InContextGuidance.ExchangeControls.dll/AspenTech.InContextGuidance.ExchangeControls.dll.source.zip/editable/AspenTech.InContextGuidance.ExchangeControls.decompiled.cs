using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using AspenTech.InContextGuidance.ExchangeControls.Images;
using AspenTech.InContextGuidance.ExchangeIntegration;
using AspenTech.InContextGuidance.Localization;
using Infragistics.Windows.Ribbon;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology 2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("15.0.0.0")]
[assembly: AssemblyTitle("AspenTech.InContextGuidance.ExchangeControls")]
[assembly: AssemblyDescription("InContextGuidance exchange controls library.")]
[assembly: AssemblyProduct("AspenTech.InContextGuidance.ExchangeControls")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("15.0.0.0")]
namespace AspenTech.InContextGuidance.ExchangeControls
{
	public class ELearningRibbonButtonTool : ButtonTool
	{
		private class ToolTipContentConverter : IValueConverter
		{
			public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
			{
				if (!(bool)value)
				{
					return InContextGuidanceResources.ExchangeTools_ELearningRibbon_Tooltip_Disabled;
				}
				return InContextGuidanceResources.ExchangeTools_ELearningRibbon_Tooltip_Enabled;
			}

			public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
			{
				throw new NotImplementedException();
			}
		}

		public ELearningRibbonButtonTool()
		{
			base.Caption = InContextGuidanceResources.ExchangeTools_ELearningRibbon_Caption;
			base.LargeImage = ImageResources.ELearningButtonImg;
			SetBinding(UIElement.IsEnabledProperty, new Binding("SuccessfullyInitialized")
			{
				Source = ExchangeAdapter.Default,
				Mode = BindingMode.OneWay
			});
			RibbonGroup.SetMaximumSize(this, RibbonToolSizingMode.ImageAndTextLarge);
			XamRibbonScreenTip xamRibbonScreenTip = new XamRibbonScreenTip
			{
				Header = InContextGuidanceResources.ExchangeTools_ELearningRibbon_Caption,
				FooterSeparatorVisibility = Visibility.Hidden
			};
			xamRibbonScreenTip.SetBinding(ContentControl.ContentProperty, new Binding
			{
				Source = this,
				Path = new PropertyPath(UIElement.IsEnabledProperty),
				Converter = new ToolTipContentConverter(),
				Mode = BindingMode.OneWay
			});
			base.ToolTip = xamRibbonScreenTip;
		}

		protected override void OnClick()
		{
			ExchangeAdapter.Default.OpenElearning();
			base.OnClick();
		}
	}
	public class ExchangeRibbonButtonTool : ButtonTool
	{
		private class ToolTipContentConverter : IValueConverter
		{
			public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
			{
				if (!(bool)value)
				{
					return InContextGuidanceResources.ExchangeTools_AspenKnowledgeRibbon_Tooltip_Disabled;
				}
				return InContextGuidanceResources.ExchangeTools_AspenKnowledgeRibbon_Tooltip_Enabled;
			}

			public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
			{
				throw new NotImplementedException();
			}
		}

		public ExchangeRibbonButtonTool()
		{
			base.Caption = InContextGuidanceResources.ExchangeTools_AspenKnowledgeRibbon_Caption;
			base.LargeImage = ImageResources.AspenONEExchangeButtonImg;
			SetBinding(UIElement.IsEnabledProperty, new Binding("SuccessfullyInitialized")
			{
				Source = ExchangeAdapter.Default,
				Mode = BindingMode.OneWay
			});
			RibbonGroup.SetMaximumSize(this, RibbonToolSizingMode.ImageAndTextLarge);
			XamRibbonScreenTip xamRibbonScreenTip = new XamRibbonScreenTip
			{
				Header = InContextGuidanceResources.ExchangeTools_AspenKnowledgeRibbon_Caption,
				FooterSeparatorVisibility = Visibility.Hidden
			};
			xamRibbonScreenTip.SetBinding(ContentControl.ContentProperty, new Binding
			{
				Source = this,
				Path = new PropertyPath(UIElement.IsEnabledProperty),
				Converter = new ToolTipContentConverter(),
				Mode = BindingMode.OneWay
			});
			base.ToolTip = xamRibbonScreenTip;
		}

		protected override void OnClick()
		{
			ExchangeAdapter.Default.SearchExchange();
			base.OnClick();
		}
	}
}
namespace AspenTech.InContextGuidance.ExchangeControls.Properties
{
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

		public static Settings Default => defaultInstance;
	}
}
namespace AspenTech.InContextGuidance.ExchangeControls.Images
{
	internal static class ImageResources
	{
		private static readonly Dictionary<string, ImageSource> _imageSources = new Dictionary<string, ImageSource>();

		public static ImageSource AspenONEExchangeButtonImg => GetImageSource("InContextGuidance.png");

		public static ImageSource ELearningButtonImg => GetImageSource("eLearning.png");

		private static ImageSource GetImageSource(string imageFileName)
		{
			if (!_imageSources.ContainsKey(imageFileName))
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append("pack://application:,,,/");
				stringBuilder.Append(typeof(ImageResources).Assembly.FullName);
				stringBuilder.Append(";component/Images/");
				stringBuilder.Append(imageFileName);
				_imageSources.Add(imageFileName, new BitmapImage(new Uri(stringBuilder.ToString(), UriKind.RelativeOrAbsolute)));
			}
			return _imageSources[imageFileName];
		}
	}
}
