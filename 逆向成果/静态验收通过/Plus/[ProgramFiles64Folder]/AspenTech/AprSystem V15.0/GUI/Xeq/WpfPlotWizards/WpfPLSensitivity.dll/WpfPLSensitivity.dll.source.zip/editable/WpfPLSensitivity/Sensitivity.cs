using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using AspenTech.AspenPlus.Happ;
using AspenTech.AspenPlus.Infrastructure;
using AspenTech.AspenPlus.Localization.WpfPlotWizards;
using AspenTech.WpfControls.Engineering;
using WpfPLControls;
using WpfPlotwizard;

namespace WpfPLSensitivity;

[ProgId("WpfPLSensitivity.Sensitivity")]
public class Sensitivity : UserControl, IRibbonPlotWizardType, IPlotWizardTemplate, IComponentConnector
{
	private IHNode _context;

	private IHWizardPlot _wizardPlot;

	private PlotwizardHelper _help = new PlotwizardHelper();

	private string _uniqueId = WpfPLSensitivityResources.ID;

	private string _plotName;

	private object _nodeCxs;

	private System.Drawing.Image _imgBitmap;

	private bool _bHasInputDialog;

	private string _currentConfigValue = string.Empty;

	private string[] _varName;

	public static RoutedCommand OKCommand = new RoutedCommand();

	public static RoutedCommand CancelCommand = new RoutedCommand();

	public static RoutedCommand ClearCommand = new RoutedCommand();

	private bool _bCheckDataOnly;

	internal GroupBox groupBoxOption;

	internal AesLabel lblXAxis;

	internal ComboBox ComboBoxXAxis;

	internal CheckBox chkParaVar;

	internal AesLabel lblParaVar;

	internal ComboBox ComboBoxParaVar;

	internal CurvesSelectorControl CurveList;

	internal AesCmdButton btnClear;

	private bool _contentLoaded;

	public string TooltipContentForRibbonItem => WpfPLSensitivityResources.TooltipContentForRibbonItem_Sensitivity;

	public string TooltipHeaderForRibbonItem => WpfPLSensitivityResources.TooltipHeaderForRibbonItem_Sensitivity;

	string IRibbonPlotWizardType.TagID
	{
		get
		{
			return _uniqueId;
		}
		set
		{
			_uniqueId = value;
		}
	}

	string IRibbonPlotWizardType.Name
	{
		get
		{
			return _plotName;
		}
		set
		{
			_plotName = value;
		}
	}

	object IRibbonPlotWizardType.WizardPlot
	{
		get
		{
			return _wizardPlot;
		}
		set
		{
			_wizardPlot = value as IHWizardPlot;
		}
	}

	object IRibbonPlotWizardType.CxsNode
	{
		get
		{
			return _nodeCxs;
		}
		set
		{
			_nodeCxs = value;
		}
	}

	System.Drawing.Image IRibbonPlotWizardType.ImageIcon => _imgBitmap;

	bool IRibbonPlotWizardType.HasInputDialog => _bHasInputDialog;

	string IRibbonPlotWizardType.HelpFile => _help.GetHelpFileName();

	long IRibbonPlotWizardType.HelpID => _help.GetHelpID();

	List<string> IRibbonPlotWizardType.SupportedDataFields => new List<string>();

	List<string> IRibbonPlotWizardType.SupportedStyleFields => new List<string>();

	public bool CheckDataOnly
	{
		get
		{
			return _bCheckDataOnly;
		}
		set
		{
			_bCheckDataOnly = value;
		}
	}

	public Sensitivity()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		InitializeComponent();
		SetVariables();
		_bHasInputDialog = true;
		if (_imgBitmap == null)
		{
			Assembly.GetExecutingAssembly();
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("WpfPLSensitivity.Images.DataPropt.ico");
			_imgBitmap = System.Drawing.Image.FromStream(manifestResourceStream);
		}
		CommandBinding commandBinding = new CommandBinding(OKCommand, ExecuteOKCommand, CanExecuteOKCommand);
		CommandBinding commandBinding2 = new CommandBinding(CancelCommand, ExecuteCancelCommand);
		CommandBinding commandBinding3 = new CommandBinding(ClearCommand, ExecuteClearCommand);
		base.CommandBindings.Add(commandBinding);
		base.CommandBindings.Add(commandBinding2);
		base.CommandBindings.Add(commandBinding3);
	}

	public void SetCaption(ref string caption)
	{
		caption = WpfPLSensitivityResources.Window_Title;
	}

	public void SetDefaultHeight(ref double defaultHeight)
	{
		defaultHeight = 380.0;
	}

	public void SetDefaultWidth(ref double defaultWidth)
	{
		defaultWidth = 450.0;
	}

	public void SetMinHeight(ref double minHeight)
	{
		minHeight = 380.0;
	}

	public void SetMinWidth(ref double minWidth)
	{
		minWidth = 450.0;
	}

	List<string> IRibbonPlotWizardType.FieldDataOptionList(string sFieldName)
	{
		return null;
	}

	void IRibbonPlotWizardType.GetFieldData(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldData(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.ShowInputDialog()
	{
	}

	RibbonControlType IRibbonPlotWizardType.GetFieldCtrlType(string sField)
	{
		return (RibbonControlType)0;
	}

	void IRibbonPlotWizardType.GetFieldStyle(string sFieldName, ref string sCurrentVal)
	{
	}

	void IRibbonPlotWizardType.SetFieldStyle(string sFieldName, string sValue)
	{
	}

	void IRibbonPlotWizardType.GetConfigData(ref string sConfigValue)
	{
		sConfigValue = _currentConfigValue;
	}

	void IRibbonPlotWizardType.SetConfigData(string sValue)
	{
		_currentConfigValue = sValue;
	}

	void IRibbonPlotWizardType.Context(object HNode, ref object HWizardPlot, ref int ierror)
	{
		if (HWizardPlot == null || HNode == null)
		{
			ierror = 1;
			return;
		}
		_context = HNode as IHNode;
		_wizardPlot = HWizardPlot as IHWizardPlot;
		IHNode iHNode = _context.FindNode(_varName[0]);
		if (iHNode == null || iHNode.Elements.Count <= 0)
		{
			ierror = 1;
			return;
		}
		ComboBoxXAxis.Items.Clear();
		ComboBoxParaVar.Items.Clear();
		List<string> list = new List<string>();
		CurveList.IsCheckAll = false;
		int count = iHNode.Elements.Count;
		for (int i = 0; i < count; i++)
		{
			string text = "";
			for (int j = 0; j < _varName.GetLength(0); j++)
			{
				string path = _varName[j] + "/" + (i + 1);
				string text2 = (dynamic)_context.FindNode(path).get_Value(Type.Missing);
				if (!string.IsNullOrEmpty(text2))
				{
					text2 = text2.Trim();
					text += text2;
					text += " ";
				}
			}
			text = text.Trim();
			ComboBoxXAxis.Items.Add(text);
			ComboBoxParaVar.Items.Add(text);
			list.Add(text);
			CurveList.SetCurves(list.ToArray());
		}
		int num = _context.FindNode("Input/VARY_VARTYPE").Elements.Count;
		IHNode iHNode2 = _context.FindNode("Input/DISABLE");
		for (int k = 0; k < num; k++)
		{
			if ((dynamic)iHNode2.Elements[k, Type.Missing, Type.Missing, Type.Missing, Type.Missing].get_Value(Type.Missing) == "YES")
			{
				num--;
			}
		}
		chkParaVar.IsChecked = false;
		if (string.IsNullOrEmpty(_currentConfigValue))
		{
			ComboBoxXAxis.Text = ComboBoxXAxis.Items[0].ToString();
			if (ComboBoxParaVar.Items.Count > 1 && num > 1)
			{
				ComboBoxParaVar.Text = ComboBoxParaVar.Items[1].ToString();
				chkParaVar.IsChecked = true;
			}
			int num2 = 0;
			List<string> list2 = new List<string>();
			for (int l = num; l < count; l++)
			{
				if (num2 >= 5)
				{
					break;
				}
				list2.Add(list[l].ToString());
				num2++;
			}
			CurveList.SetSelectedCurves(list2.ToArray());
		}
		if (!string.IsNullOrEmpty(_currentConfigValue))
		{
			RestoreConfigValue(_currentConfigValue);
		}
	}

	public void UpdateWizardData()
	{
		int selectedIndex = ComboBoxXAxis.SelectedIndex;
		string indepvar = "Output/SENSVAR2/" + (selectedIndex + 1);
		_wizardPlot.SetIndependentVariable(_context, indepvar);
		_wizardPlot.RemoveAllDependentVariable();
		_wizardPlot.PlotVal.Parametric = false;
		List<string> list;
		List<string> list2;
		int count;
		bool? parameterChecked;
		bool expectedChecked;
		parameterChecked = chkParaVar.IsChecked;
		expectedChecked = true;
		if (((parameterChecked.GetValueOrDefault() == expectedChecked) & parameterChecked.HasValue))
		{
			_wizardPlot.PlotVal.Parametric = true;
			int selectedIndex2 = ComboBoxParaVar.SelectedIndex;
			string depvar = "Output/SENSVAR2/" + (selectedIndex2 + 1);
			_wizardPlot.AddDependentVariable(_context, depvar);
		}
		list = new List<string>(CurveList.GetSelectedCurves());
		list2 = new List<string>();
		count = list.Count;
		for (int i = 0; i < count; i++)
		{
			string text = list[i];
			int selectedCurveIndex = CurveList.GetSelectedCurveIndex(text);
			string depvar2 = "Output/SENSVAR2/" + (selectedCurveIndex + 1);
			_wizardPlot.AddDependentVariable(_context, depvar2);
			((IHPlotVal)_wizardPlot.PlotVal).set_AxisMap(i, i);
			((IHPlotVal)_wizardPlot.PlotVal).set_YAxisTitle((object)i, text);
			list2.Add(text);
			parameterChecked = chkParaVar.IsChecked;
			expectedChecked = true;
			if (((parameterChecked.GetValueOrDefault() == expectedChecked) & parameterChecked.HasValue))
			{
				((IHPlotVal)_wizardPlot.PlotVal).set_Label(i + 1, ComboBoxParaVar.Text + " = %param%");
			}
			else
			{
				((IHPlotVal)_wizardPlot.PlotVal).set_Label(i, text);
			}
		}
		parameterChecked = chkParaVar.IsChecked;
		expectedChecked = true;
		if (!((parameterChecked.GetValueOrDefault() == expectedChecked) & parameterChecked.HasValue))
		{
			for (int j = 0; j < count; j++)
			{
				((IHPlotVal)_wizardPlot.PlotVal).set_AxisMap(j, count - j - 1);
			}
		}
		else if (list2.Contains(ComboBoxParaVar.Text))
		{
			for (int k = 0; k < count; k++)
			{
				((IHPlotVal)_wizardPlot.PlotVal).set_AxisMap(k, count - k);
			}
		}
		_wizardPlot.PlotVal.Title = WpfPLSensitivityResources.Title;
		_wizardPlot.PlotVal.XAxisTitle = ComboBoxXAxis.Text;
		_currentConfigValue = SaveConfigValue();
	}

	private void chkParaVar_Click(object sender, RoutedEventArgs e)
	{
		bool? parameterChecked;
		bool expectedChecked;
		parameterChecked = chkParaVar.IsChecked;
		expectedChecked = true;
		if (((parameterChecked.GetValueOrDefault() == expectedChecked) & parameterChecked.HasValue))
		{
			_wizardPlot.PlotVal.Parametric = true;
		}
		else
		{
			_wizardPlot.PlotVal.Parametric = false;
		}
	}

	private void ExecuteOKCommand(object sender, ExecutedRoutedEventArgs e)
	{
		UpdateWizardData();
		_help.CloseForm((UserControl)this, (bool?)true);
	}

	private void CanExecuteOKCommand(object sender, CanExecuteRoutedEventArgs e)
	{
		int selectedIndex = ComboBoxXAxis.SelectedIndex;
		int num = CurveList.GetSelectedCurves().Count();
		if (num == CurveList.Curves.Count)
		{
			CurveList.IsCheckAll = true;
		}
		else
		{
			string[] selectedCurves = CurveList.GetSelectedCurves();
			CurveList.IsCheckAll = false;
			CurveList.SetSelectedCurves(selectedCurves);
		}
		if (selectedIndex >= 0 && num > 0)
		{
			e.CanExecute = true;
		}
		else
		{
			e.CanExecute = false;
		}
	}

	private void ExecuteCancelCommand(object sender, ExecutedRoutedEventArgs e)
	{
		_help.CloseForm((UserControl)this, (bool?)false);
	}

	private void ExecuteClearCommand(object sender, ExecutedRoutedEventArgs e)
	{
		ComboBoxXAxis.Text = "";
		ComboBoxParaVar.Text = "";
		chkParaVar.IsChecked = false;
		CurveList.IsCheckAll = false;
		int count = new List<string>(CurveList.GetSelectedCurves()).Count;
		for (int i = 0; i < count; i++)
		{
			CurveList.SetItemsIsChecked(isChecked: false);
		}
	}

	private void SetVariables()
	{
		_varName = new string[7] { "Output/LINE1", "Output/LINE2", "Output/LINE3", "Output/LINE4", "Output/LINE5", "Output/LINE6", "Output/LINE7" };
	}

	private string SaveConfigValue()
	{
		_ = string.Empty;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("X-Axis=");
		stringBuilder.Append(ComboBoxXAxis.Text.ToString());
		stringBuilder.Append(";");
		stringBuilder.Append("ParamatricChecked=");
		List<string> list;
		int count;
		bool? parameterChecked;
		bool expectedChecked;
		parameterChecked = chkParaVar.IsChecked;
		expectedChecked = true;
		if (((parameterChecked.GetValueOrDefault() == expectedChecked) & parameterChecked.HasValue))
		{
			stringBuilder.Append(1);
		}
		else
		{
			stringBuilder.Append(0);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("Parametric=");
		stringBuilder.Append(ComboBoxParaVar.Text.ToString());
		stringBuilder.Append(";");
		stringBuilder.Append("CurveSelection=");
		list = new List<string>(CurveList.GetSelectedCurves());
		count = list.Count;
		for (int i = 0; i < count; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(",");
			}
			string value = list[i];
			stringBuilder.Append(value);
		}
		stringBuilder.Append(";");
		stringBuilder.Append("CheckAll=");
		stringBuilder.Append(CurveList.IsCheckAll);
		stringBuilder.Append(";");
		return stringBuilder.ToString();
	}

	private void RestoreConfigValue(string ConfigString)
	{
		string[] array = ConfigString.Split(';');
		int num = 0;
		string text = array[num].Substring(array[num].IndexOf('=') + 1);
		ComboBoxXAxis.Text = text;
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		if (Convert.ToInt16(text) == 1)
		{
			chkParaVar.IsChecked = true;
		}
		else
		{
			chkParaVar.IsChecked = false;
		}
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		ComboBoxParaVar.Text = text;
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		string[] array2 = text.Split(',');
		List<string> list = new List<string>();
		string[] array3 = array2;
		foreach (string item in array3)
		{
			list.Add(item);
		}
		CurveList.SetSelectedCurves(list.ToArray());
		num++;
		text = array[num].Substring(array[num].IndexOf('=') + 1);
		CurveList.IsCheckAll = Convert.ToBoolean(text);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	public void InitializeComponent()
	{
		if (_contentLoaded)
		{
			return;
		}
		_contentLoaded = true;
		Uri resourceLocator = new Uri("/WpfPLSensitivity;component/sensitivity.xaml", UriKind.Relative);
		Application.LoadComponent(this, resourceLocator);
	}

	[DebuggerNonUserCode]
	[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	void IComponentConnector.Connect(int connectionId, object target)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Expected O, but got Unknown
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Expected O, but got Unknown
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Expected O, but got Unknown
		switch (connectionId)
		{
		case 1:
			groupBoxOption = (GroupBox)target;
			break;
		case 2:
			lblXAxis = (AesLabel)target;
			break;
		case 3:
			ComboBoxXAxis = (ComboBox)target;
			break;
		case 4:
			chkParaVar = (CheckBox)target;
			chkParaVar.Click += chkParaVar_Click;
			break;
		case 5:
			lblParaVar = (AesLabel)target;
			break;
		case 6:
			ComboBoxParaVar = (ComboBox)target;
			break;
		case 7:
			CurveList = (CurvesSelectorControl)target;
			break;
		case 8:
			btnClear = (AesCmdButton)target;
			break;
		default:
			_contentLoaded = true;
			break;
		}
	}
}
