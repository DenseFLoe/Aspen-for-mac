using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using AspenTech.AspenPlus.APConvert;
using AspenTech.AspenPlus.Happ;

namespace HeatExchanger;

[ComVisible(false)]
public class HeatExchangeConverter : IAPBlockConverter
{
	private enum CursorName
	{
		IDC_ARROW = 32512,
		IDC_WAIT = 32514
	}

	private class StreamConnection
	{
		public string streamName;

		public string streamPort;

		public string blockName;

		public string blockPort;
	}

	private class ConvertData
	{
		public string varName;

		public object Value;

		public short Units;

		public object force = Missing.Value;
	}

	private const int HAP_UNITCOL = 3;

	private string[] varNames = new string[46]
	{
		"MODE", "PROGRAM_MODE", "INPUT_FILE", "SPEC", "VALUE", "SPECUN", "SAV_ANA_PARM", "SAV_CLD_STRM", "SAV_DSG_PARM", "SAV_HOT_STRM",
		"HGENERATE", "CGENERATE", "HUPDATE", "CUPDATE", "HINDP_DEV", "CINDP_DEV", "HCTYPE", "CCTYPE", "HOT_PFACTOR", "HOT_FFACTOR",
		"COLD_PFACTOR", "COLD_FFACTOR", "1NPHASE", "1PHASE", "1FREEWAT", "1FMAXIT", "1FTOL", "2NPHASE", "2PHASE", "2FREEWAT",
		"2FMAXIT", "2FTOL", "HOPSET", "COPSET", "HCHEMISTRY", "CCHEMISTRY", "HFREE_WATER", "CFREE_WATER", "HHENRY_COMPS", "CHENRY_COMPS",
		"HTRUE_COMPS", "CTRUE_COMPS", "HSOLU_WATER", "CSOLU_WATER", "FOUL_OPTION", "FOUL_RATIO"
	};

	private string[] varWithUnit = new string[6] { "HOT_FOULING", "HOT_MAX_DP", "HOT_FILM", "COLD_FOULING", "COLD_MAX_DP", "COLD_FILM" };

	private IntPtr gHourglassCursor;

	private IntPtr gPrevCursor;

	private ArrayList streamList;

	private ArrayList variableList;

	private ArrayList varWithUnitList;

	private object force;

	private string convertType;

	public string BaseDestinationType => "HEATX";

	public string BaseSourceType => convertType.ToUpper();

	public string Description => "Converts Aspen Plus " + convertType + " model into a Heatx model.";

	public string DestLibraryFile => "";

	public string DestLibraryModelType => "";

	public string DestLibraryName => "";

	public string DisplayName => "Aspen Heatx";

	[DllImport("user32")]
	private static extern IntPtr SetCursor(IntPtr hCursor);

	[DllImport("user32")]
	private static extern IntPtr LoadCursor(IntPtr hInstance, CursorName lpCursorName);

	public HeatExchangeConverter(string type)
	{
		convertType = type;
		streamList = new ArrayList();
		variableList = new ArrayList();
		varWithUnitList = new ArrayList();
		force = Missing.Value;
	}

	public void PreConvert(IHNode pNode)
	{
		gHourglassCursor = LoadCursor(IntPtr.Zero, CursorName.IDC_WAIT);
		gPrevCursor = SetCursor(gHourglassCursor);
		if (pNode == null)
		{
			MessageBox.Show("pNode is not available.");
			return;
		}
		MessageBox.Show("Converter will not convert the external data outside of " + convertType + " block.");
		try
		{
			IHNode iHNode = pNode.FindNode("Connections");
			IHNodeCol elements = iHNode.Elements;
			if (elements != null)
			{
				string text = pNode.get_Name(force);
				streamList.Clear();
				for (int i = 0; i < elements.Count; i++)
				{
					string text2 = elements.get_Label(0, i, force);
					IHNode iHNode2 = pNode.FindNode("../../Streams/" + text2 + "/Connections/" + text);
					if (iHNode2 != null)
					{
						StreamConnection streamConnection = new StreamConnection();
						IHNode iHNode3 = iHNode.FindNode(text2);
						streamConnection.streamName = text2;
						streamConnection.blockName = text;
						streamConnection.streamPort = (string)(dynamic)iHNode2.get_Value(force);
						streamConnection.blockPort = (string)(dynamic)iHNode3.get_Value(force);
						streamList.Add(streamConnection);
					}
				}
			}
			variableList.Clear();
			for (int j = 0; j < varNames.Count(); j++)
			{
				ConvertData convertData = new ConvertData();
				convertData.varName = varNames[j];
				if (j == 0)
				{
					if (convertType.CompareTo("Aerotran") == 0)
					{
						convertData.Value = "AEROTRAN-RIG";
					}
					else
					{
						convertData.Value = "HETRAN-RIG";
					}
				}
				else
				{
					string path = "Input/" + varNames[j];
					IHNode iHNode4 = pNode.FindNode(path);
					if (iHNode4 != null)
					{
						convertData.Value = iHNode4.get_Value(force);
					}
				}
				variableList.Add(convertData);
			}
			varWithUnitList.Clear();
			for (int k = 0; k < varWithUnit.Count(); k++)
			{
				ConvertData convertData2 = new ConvertData();
				convertData2.varName = varWithUnit[k];
				string path2 = "Input/" + varWithUnit[k];
				IHNode iHNode5 = pNode.FindNode(path2);
				if (iHNode5 != null)
				{
					convertData2.Value = iHNode5.get_Value(force);
					convertData2.Units = Convert.ToInt16((dynamic)iHNode5.get_AttributeValue((short)3, force));
				}
				varWithUnitList.Add(convertData2);
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show("Cannot convert to Heatx");
			throw new Exception(ex.Message.ToString());
		}
	}

	public void PostConvert(IHNode pNode)
	{
		IHNode iHNode = pNode.FindNode("Ports");
		IHNodeCol elements = iHNode.Elements;
		if (elements != null)
		{
			for (int i = 0; i < streamList.Count; i++)
			{
				StreamConnection streamConnection = streamList[i] as StreamConnection;
				for (int j = 0; j < elements.Count; j++)
				{
					string text = elements.get_Label(0, j, force);
					if (text.CompareTo(streamConnection.blockPort) == 0)
					{
						string streamName = streamConnection.streamName;
						IHNodeCol destinationElements = iHNode.FindNode(text).Elements;
						if (destinationElements != null)
						{
							destinationElements.Add(streamName, null, null, null, null);
						}
						break;
					}
				}
			}
		}
		IHNode iHNode2 = null;
		int length = varNames.GetLength(0);
		for (int k = 0; k < length; k++)
		{
			iHNode2 = pNode.FindNode("Input/" + varNames[k]);
			if (iHNode2 != null)
			{
				ConvertData convertData = variableList[k] as ConvertData;
				iHNode2.set_Value(convertData.force, convertData.Value);
			}
		}
		length = varWithUnit.GetLength(0);
		for (int l = 0; l < length; l++)
		{
			iHNode2 = pNode.FindNode("Input/" + varWithUnit[l]);
			if (iHNode2 != null)
			{
				ConvertData convertData2 = varWithUnitList[l] as ConvertData;
				iHNode2.SetValueAndUnit(convertData2.Value, convertData2.Units, convertData2.force);
			}
		}
		SetCursor(gPrevCursor);
	}
}
