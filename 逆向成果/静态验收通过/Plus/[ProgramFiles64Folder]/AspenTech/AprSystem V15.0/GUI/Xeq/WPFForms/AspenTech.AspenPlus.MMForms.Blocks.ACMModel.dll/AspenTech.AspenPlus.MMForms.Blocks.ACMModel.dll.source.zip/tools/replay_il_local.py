# -*- coding: utf-8 -*-
"""Replay the IL-spliced candidate with the legacy replay chain.

Only one step is replaced: `pe_layout.move_bootstrap`, which assumes the
candidate's import directory shares the original's byte layout.  ilasm 4.0.30319
pads the hint/name block to 16 bytes, so its import tail is 8 bytes longer than
the original's (Roslyn/mscoree layout).  `compat_move_bootstrap` rebuilds the
tail *from the candidate's own import strings* at the original's offsets and
then gates the result on the recipe's `import_tail_sha256` (which is the
original tail's hash), so a wrong reconstruction is rejected.

Usage: replay_il_local.py <recipe.json> <candidate.dll> <original.dll> <outdir>
"""
import json
import struct
import sys
from hashlib import sha256
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
HERE = Path(__file__).resolve().parent
# Self-contained archive layout (tools/legacy + tools/clr_meta.py) first; the
# project tree layout is the development fallback.
LEGACY = HERE / "legacy" if (HERE / "legacy" / "token_replay.py").is_file() else BASE / "managed-byte-recovery"
MANAGED = HERE if (HERE / "clr_meta.py").is_file() else BASE / "router" / "managed"
sys.path.insert(0, str(LEGACY))
sys.path.insert(0, str(MANAGED))
sys.path.insert(0, str(HERE))
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")

import token_replay as legacy  # noqa: E402
import clr_meta  # noqa: E402
import pe_layout  # noqa: E402


def make_compat(recipe):
    expected = recipe.get("import_tail_sha256")

    def compat_move_bootstrap(pe, before, after):
        if before["iat"] != after["iat"]:
            raise ValueError("CLR import/IAT structure changed")
        if not expected:
            raise ValueError("Recipe has no import tail fingerprint")
        directory = bytearray(pe.get_data(before["start"], 20))
        struct.pack_into("<I", directory, 0, after["thunk"])
        struct.pack_into("<I", directory, 12, after["module_name"])
        struct.pack_into("<I", directory, 16, after["iat"])
        hint_bytes = pe.get_data(before["hint"], before["module_name"] - before["hint"])
        name_len = before["data_length"] - (before["module_name"] - before["start"])
        name_bytes = pe.get_data(before["module_name"], name_len)
        total = after["entry"] + 6 - after["start"]
        payload = bytearray(total)
        payload[0:20] = directory
        struct.pack_into("<II", payload, after["thunk"] - after["start"], after["hint"], 0)
        hint_at = after["hint"] - after["start"]
        payload[hint_at:hint_at + len(hint_bytes)] = hint_bytes
        name_at = after["module_name"] - after["start"]
        payload[name_at:name_at + len(name_bytes)] = name_bytes
        stub = pe.get_data(before["entry"], 6)
        payload[total - 6:total] = stub
        if sha256(bytes(payload)).hexdigest() != expected:
            raise ValueError("Rebuilt import tail differs from the original fingerprint")
        return bytes(payload)

    return compat_move_bootstrap


def make_finish(original):
    """`pe_layout.finish_image` with the original section VAs written into the
    candidate headers.

    The pinned implementation rewrites section size / raw-offset but not
    VirtualAddress, and it patches the `.reloc` entry at
    `original_reloc_rva - candidate_section_VA`.  ilasm 4.0.30319 lays out
    .rsrc/.reloc at virtual addresses chosen for its own (larger) .text, and
    forcing those VAs onto the candidate would make .rsrc overlap .text and
    break pefile's RVA mapping of the metadata heap.  The candidate therefore
    keeps ilasm's non-overlapping VAs, and this wrapper supplies the original
    section VAs (`original_vas`) at header-rewrite time.
    """
    pe_o, _ = pe_layout.identified_image(original)
    original_vas = {name: s.VirtualAddress for name, s in pe_layout.names(pe_o).items()}
    original_dirs = [(d.VirtualAddress, d.Size) for d in pe_o.OPTIONAL_HEADER.DATA_DIRECTORY]

    def finish(compiled, pe, recipe, text, certificate, strong_name):
        source_sections = pe_layout.names(pe)
        old_boot = recipe["x86_bootstrap"]
        allowance = recipe["sections"][".text"]
        if allowance["virtual_bytes"] != len(text) or len(text) > allowance["file_bytes"]:
            raise ValueError("Repositioned debug data does not fit the original text extent")
        head = bytearray(compiled[:pe.OPTIONAL_HEADER.SizeOfHeaders])
        original_layout = recipe["sections"]
        opt = pe.OPTIONAL_HEADER
        coff = pe.FILE_HEADER
        struct.pack_into("<I", head, coff.get_field_absolute_offset("TimeDateStamp"), recipe["coff_timestamp"])
        for field, value in (("MajorLinkerVersion", recipe["linker_major"]),
                             ("MinorLinkerVersion", recipe["linker_minor"])):
            struct.pack_into("<B", head, opt.get_field_absolute_offset(field), value)
        struct.pack_into("<H", head, opt.get_field_absolute_offset("DllCharacteristics"),
                         recipe["original_dll_characteristics"])
        stack = recipe.get("stack_reservation")
        if stack:
            field = "<Q" if opt.Magic == 0x20B else "<I"
            if (opt.SizeOfStackReserve != stack["compiler"] or opt.SizeOfStackCommit != stack["commit"]
                    or not 0 < stack["commit"] <= stack["original"] or stack["original"] % 4096):
                raise ValueError("The recorded stack reservation does not match the verified PE build fields")
            struct.pack_into(field, head, opt.get_field_absolute_offset("SizeOfStackReserve"),
                             stack["original"])
        for name, section in source_sections.items():
            recorded = original_layout[name]
            if name != ".text" and (section.Misc_VirtualSize != recorded["virtual_bytes"]
                                    or section.SizeOfRawData != recorded["file_bytes"]):
                raise ValueError("Resource section changed")
            for field, key in (("Misc_VirtualSize", "virtual_bytes"),
                               ("SizeOfRawData", "file_bytes"),
                               ("PointerToRawData", "file_offset")):
                struct.pack_into("<I", head, section.get_field_absolute_offset(field), recorded[key])
            struct.pack_into("<I", head, section.get_field_absolute_offset("VirtualAddress"),
                             original_vas[name])
        struct.pack_into("<I", head, opt.get_field_absolute_offset("SizeOfCode"), allowance["file_bytes"])
        if old_boot:
            struct.pack_into("<I", head, opt.get_field_absolute_offset("AddressOfEntryPoint"),
                             old_boot["entry"])
            struct.pack_into("<II", head, opt.DATA_DIRECTORY[1].get_file_offset(),
                             old_boot["start"], old_boot["import_size"])
        struct.pack_into("<II", head, opt.DATA_DIRECTORY[6].get_file_offset(),
                         recipe.get("debug_rva", opt.DATA_DIRECTORY[6].VirtualAddress),
                         recipe["debug_directory_bytes"])
        sec = opt.DATA_DIRECTORY[4].get_file_offset()
        struct.pack_into("<II", head, sec, recipe["certificate_offset"], recipe["certificate_size"])
        # All data directories are original layout record: write the original
        # values (ilasm's .rsrc/.reloc directory RVAs differ from the replay
        # layout; [1]/[4]/[6] are rewritten above with the same values).
        for index, (directory, (va, size)) in enumerate(zip(opt.DATA_DIRECTORY, original_dirs)):
            struct.pack_into("<II", head, directory.get_file_offset(), va, size)
        checksum = opt.get_field_absolute_offset("CheckSum")
        struct.pack_into("<I", head, checksum, 0)
        content = head
        for name, layout in sorted(original_layout.items(), key=lambda item: item[1]["file_offset"]):
            if len(content) != layout["file_offset"]:
                raise ValueError("Original sections do not align to the recovered raw layout")
            section = source_sections[name]
            if name == ".text":
                block = text
            else:
                block = bytearray(compiled[section.PointerToRawData:
                                           section.PointerToRawData + section.SizeOfRawData])
                if name == ".reloc" and old_boot:
                    raw = old_boot["reloc_rva"] - original_vas[".reloc"]
                    block[raw:raw + 12] = pe_layout.make_reloc(old_boot["entry"])
            content += block.ljust(layout["file_bytes"], b"\0")
        if len(content) != recipe["certificate_offset"]:
            raise ValueError("Rebuilt signed payload does not end at its recorded certificate boundary")
        restored = pe_layout.pefile.PE(data=bytes(content), fast_load=True)
        strong = recipe["strong_name"]
        if strong:
            start, amount = strong["file_offset"], strong["width"]
            if (any(content[start:start + amount]) or len(strong_name) != amount
                    or sha256(strong_name).hexdigest() != strong["signature_sha256"]
                    or pe_layout.covered_hash(content, restored, len(content),
                                              erase_strong_name=(start, amount))
                    != strong["payload_with_blank_strong_name_sha256"]):
                raise ValueError("Rebuilt PE bytes differ from the masked original; strong-name signature not applied")
            content[start:start + amount] = strong_name
        elif strong_name:
            raise ValueError("An unexpected strong-name signature is present")
        if pe_layout.covered_hash(content, restored, len(content)) != recipe["authenticode_payload_sha256"]:
            raise ValueError("Reconstructed Authenticode payload differs from the original; certificate not applied")
        if len(certificate) != recipe["certificate_size"] \
                or sha256(certificate).hexdigest() != recipe["certificate_sha256"]:
            raise ValueError("The saved original certificate table changed")
        content += certificate
        reconstructed = pe_layout.pefile.PE(data=bytes(content), fast_load=True)
        actual = reconstructed.generate_checksum()
        if actual != recipe["original_checksum"]:
            raise ValueError("Recomputed PE checksum differs from the original")
        struct.pack_into("<I", content, checksum, actual)
        if sha256(content).hexdigest() != recipe["original_sha256"]:
            raise ValueError("Reconstructed file is still not byte-identical to the original")
        return bytes(content)

    return finish


def main(recipe_path, cand_path, orig_path, out_dir):
    recipe = json.loads(Path(recipe_path).read_text(encoding="utf-8"))
    cand = Path(cand_path).read_bytes()
    orig = Path(orig_path).read_bytes()
    if sha256(cand).hexdigest() != recipe["compiler_output_sha256"]:
        raise SystemExit("candidate does not match recipe compiler_output_sha256")
    pe, cli, root = clr_meta.read_image(orig)
    # The legacy recipe has no import-tail field; derive it from the original
    # exactly as build_recipe2 does and pin it into the recipe copy we replay.
    if "import_tail_sha256" not in recipe:
        boot = recipe["x86_bootstrap"]
        text = pe_layout.names(pe)[".text"]
        start = pe.get_offset_from_rva(boot["start"])
        end = pe.get_offset_from_rva(boot["entry"]) + 6
        recipe["import_tail_sha256"] = sha256(orig[start:end]).hexdigest()
    metadata = pe.get_data(cli["metadata_rva"], cli["metadata_size"])
    debug = pe_layout.debug_tail(orig, pe)
    cert_dir = pe.OPTIONAL_HEADER.DATA_DIRECTORY[4]
    certificate = orig[cert_dir.VirtualAddress:cert_dir.VirtualAddress + cert_dir.Size]
    legacy.move_bootstrap = make_compat(recipe)
    # pe_layout3 (from rebuild/df5c39b2's replay-v1 package) extends the pinned
    # finish_image with section VirtualAddress restoration (recipe
    # sections[].virtual_address), native-resource RVA relocation and the
    # resource/reloc data-directory records.
    sys.path.insert(0, str(HERE))
    import pe_layout3
    legacy.finish_image = pe_layout3.finish_image
    data = legacy.reproduce(cand, recipe, metadata, debug, certificate,
                            b"" if not recipe["strong_name"] else None)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    artifact = out / Path(orig_path).name
    artifact.write_bytes(data)
    digest = sha256(data).hexdigest()
    print(json.dumps({"artifact": str(artifact), "sha256": digest,
                      "original_sha256": recipe["original_sha256"],
                      "match": digest == recipe["original_sha256"]}, ensure_ascii=False))
    return 0 if digest == recipe["original_sha256"] else 1


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:5]))
