# AspenTech.NGP.Infrastructure.decompiled.cs

Source: editable/AspenTech.NGP.Infrastructure.decompiled.cs

Source SHA-256: f72189d260e909123203647b3d7f94c0ee15830745612743b9cb015c2d9a2bbf
