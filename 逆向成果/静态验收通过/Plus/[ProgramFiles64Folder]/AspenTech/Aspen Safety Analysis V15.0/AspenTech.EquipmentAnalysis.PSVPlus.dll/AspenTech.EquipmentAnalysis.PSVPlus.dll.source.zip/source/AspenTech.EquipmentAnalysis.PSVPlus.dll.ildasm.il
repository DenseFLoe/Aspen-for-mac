﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication
  AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer
  AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject
  AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources
  AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings
  AspenTech.EquipmentAnalysis.PSVPlus.My.MySettingsProperty
  AspenTech.EquipmentAnalysis.PSVPlus.CxsHost
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase
  AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager
  AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/MyWebServices
  AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__31-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__32-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__34-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__36-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__39-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__40-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__42-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__43-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__49-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__66-0'
  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__
  AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager/'_Closure$__7-0'
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern System
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern Microsoft.VisualBasic
{
  .publickeytoken = (B0 3F 5F 7F 11 D5 0A 3A )                         // .?_....:
  .ver 10:0:0:0
}
.assembly extern AspenTech.EquipmentAnalysis.Infrastructure
{
  .ver 41:0:0:0
}
.assembly extern AspenTech.AspenCxs
{
  .publickeytoken = (5D 73 34 E0 D1 73 8A D6 )                         // ]s4..s..
  .ver 41:0:0:57
}
.assembly extern WindowsBase
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern Microsoft.Practices.Unity
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 3:5:0:0
}
.assembly extern AspenTech.Visualisation.CommonShell.Infrastructure.Wpf
{
  .publickeytoken = (B0 56 89 B3 9D EE FB CD )                         // .V......
  .ver 31:0:0:5
}
.assembly extern AspenTech.Visualisation.CommonShell.Wpf
{
  .publickeytoken = (B0 56 89 B3 9D EE FB CD )                         // .V......
  .ver 31:0:0:5
}
.assembly extern AspenTech.EquipmentAnalysis.PSVModelLibrary
{
  .ver 41:0:0:0
}
.assembly extern AdbComInterfaces
{
  .ver 41:0:0:0
}
.assembly extern AspenTech.EquipmentAnalysis.Models
{
  .ver 41:0:0:0
}
.assembly extern PSVSizingEngine
{
  .ver 41:0:0:0
}
.assembly extern AspenTech.EquipmentAnalysis.PSVControlLibrary
{
  .ver 41:0:0:0
}
.assembly extern System.Core
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern AspenDataShareCS
{
  .ver 41:0:0:0
}
.assembly extern Microsoft.Practices.Composite
{
  .publickeytoken = (8A F4 53 88 06 95 A9 B8 )                         // ..S.....
  .ver 2:0:1:0
}
.assembly extern AspenTech.AspenCxs.CxsViewModel
{
  .ver 41:0:0:0
}
.assembly extern Microsoft.Practices.Composite.Presentation
{
  .publickeytoken = (8A F4 53 88 06 95 A9 B8 )                         // ..S.....
  .ver 2:0:1:0
}
.assembly extern AspenTech.EquipmentAnalysis.PSVControlResources
{
  .ver 41:0:0:0
}
.assembly extern AspenTech.EquipmentAnalysis.DataMigration
{
  .ver 41:0:0:0
}
.assembly extern System.Windows.Forms
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern PresentationFramework
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly AspenTech.EquipmentAnalysis.PSVPlus
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.

  // --- The following custom attribute is added automatically, do not uncomment -------
  //  .custom instance void [mscorlib]System.Diagnostics.DebuggableAttribute::.ctor(valuetype [mscorlib]System.Diagnostics.DebuggableAttribute/DebuggingModes) = ( 01 00 02 00 00 00 00 00 ) 

  .custom instance void [mscorlib]System.Reflection.AssemblyFileVersionAttribute::.ctor(string) = ( 01 00 09 34 31 2E 30 2E 30 2E 38 33 00 00 )       // ...41.0.0.83..
  .custom instance void [mscorlib]System.Reflection.AssemblyCompanyAttribute::.ctor(string) = ( 01 00 15 41 73 70 65 6E 54 65 63 68 20 43 6F 72   // ...AspenTech Cor
                                                                                                70 6F 72 61 74 69 6F 6E 00 00 )                   // poration..
  .custom instance void [mscorlib]System.Reflection.AssemblyProductAttribute::.ctor(string) = ( 01 00 21 41 73 70 65 6E 20 53 61 66 65 74 79 20   // ..!Aspen Safety 
                                                                                                41 6E 61 6C 79 73 69 73 20 45 6E 76 69 72 6F 6E   // Analysis Environ
                                                                                                6D 65 6E 74 00 00 )                               // ment..
  .custom instance void [mscorlib]System.Reflection.AssemblyCopyrightAttribute::.ctor(string) = ( 01 00 27 43 6F 70 79 72 69 67 68 74 20 C2 A9 20   // ..'Copyright .. 
                                                                                                  41 73 70 65 6E 54 65 63 68 20 43 6F 72 70 6F 72   // AspenTech Corpor
                                                                                                  61 74 69 6F 6E 20 32 30 32 34 00 00 )             // ation 2024..
  .custom instance void [mscorlib]System.Reflection.AssemblyTitleAttribute::.ctor(string) = ( 01 00 23 41 73 70 65 6E 54 65 63 68 2E 45 71 75   // ..#AspenTech.Equ
                                                                                              69 70 6D 65 6E 74 41 6E 61 6C 79 73 69 73 2E 50   // ipmentAnalysis.P
                                                                                              53 56 50 6C 75 73 00 00 )                         // SVPlus..
  .custom instance void [mscorlib]System.Reflection.AssemblyDescriptionAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyTrademarkAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 63 65 35 30 64 36 30 37 2D 63 35 38 65   // ..$ce50d607-c58e
                                                                                                  2D 34 64 39 61 2D 38 35 64 65 2D 66 30 34 37 35   // -4d9a-85de-f0475
                                                                                                  37 38 64 37 62 66 63 00 00 )                      // 78d7bfc..
  .custom instance void [mscorlib]System.Runtime.Versioning.TargetFrameworkAttribute::.ctor(string) = ( 01 00 1A 2E 4E 45 54 46 72 61 6D 65 77 6F 72 6B   // ....NETFramework
                                                                                                        2C 56 65 72 73 69 6F 6E 3D 76 34 2E 38 01 00 54   // ,Version=v4.8..T
                                                                                                        0E 14 46 72 61 6D 65 77 6F 72 6B 44 69 73 70 6C   // ..FrameworkDispl
                                                                                                        61 79 4E 61 6D 65 12 2E 4E 45 54 20 46 72 61 6D   // ayName..NET Fram
                                                                                                        65 77 6F 72 6B 20 34 2E 38 )                      // ework 4.8
  .hash algorithm 0x00008004
  .ver 41:0:0:0
}
.mresource public AspenTech.EquipmentAnalysis.PSVPlus.Resources.resources
{
  // Offset: 0x00000000 Length: 0x000000B4
  // WARNING: managed resource file AspenTech.EquipmentAnalysis.PSVPlus.Resources.resources created
}
.module AspenTech.EquipmentAnalysis.PSVPlus.dll
// MVID: {44b55228-2751-4da9-b244-2b9ddbcc5857}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000001    //  ILONLY
// Image base: 0x000002B352F50000


// =============== CLASS MEMBERS DECLARATION ===================

.class private auto ansi AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication
       extends [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.ApplicationBase
{
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 0A 4D 79 54 65 6D 70 6C 61 74 65 08 31 31   // ...MyTemplate.11
                                                                                                  2E 30 2E 30 2E 30 00 00 )                         // .0.0.0..
  .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.ApplicationBase::.ctor()
    IL_0006:  ret
  } // end of method MyApplication::.ctor

} // end of class AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication

.class private auto ansi AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer
       extends [Microsoft.VisualBasic]Microsoft.VisualBasic.Devices.Computer
{
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 0A 4D 79 54 65 6D 70 6C 61 74 65 08 31 31   // ...MyTemplate.11
                                                                                                  2E 30 2E 30 2E 30 00 00 )                         // .0.0.0..
  .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.Devices.Computer::.ctor()
    IL_0006:  ret
  } // end of method MyComputer::.ctor

} // end of class AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer

.class private auto ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject
       extends [mscorlib]System.Object
{
  .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.StandardModuleAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.HideModuleNameAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 0A 4D 79 54 65 6D 70 6C 61 74 65 08 31 31   // ...MyTemplate.11
                                                                                                  2E 30 2E 30 2E 30 00 00 )                         // .0.0.0..
  .class auto ansi sealed nested assembly MyWebServices
         extends [mscorlib]System.Object
  {
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.MyGroupCollectionAttribute::.ctor(string,
                                                                                                         string,
                                                                                                         string,
                                                                                                         string) = ( 01 00 34 53 79 73 74 65 6D 2E 57 65 62 2E 53 65   // ..4System.Web.Se
                                                                                                                     72 76 69 63 65 73 2E 50 72 6F 74 6F 63 6F 6C 73   // rvices.Protocols
                                                                                                                     2E 53 6F 61 70 48 74 74 70 43 6C 69 65 6E 74 50   // .SoapHttpClientP
                                                                                                                     72 6F 74 6F 63 6F 6C 12 43 72 65 61 74 65 5F 5F   // rotocol.Create__
                                                                                                                     49 6E 73 74 61 6E 63 65 5F 5F 13 44 69 73 70 6F   // Instance__.Dispo
                                                                                                                     73 65 5F 5F 49 6E 73 74 61 6E 63 65 5F 5F 00 00   // se__Instance__..
                                                                                                                     00 ) 
    .method public hidebysig strict virtual 
            instance bool  Equals(object o) cil managed
    {
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       13 (0xd)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldarg.1
      IL_0002:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
      IL_0007:  call       instance bool [mscorlib]System.Object::Equals(object)
      IL_000c:  ret
    } // end of method MyWebServices::Equals

    .method public hidebysig strict virtual 
            instance int32  GetHashCode() cil managed
    {
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance int32 [mscorlib]System.Object::GetHashCode()
      IL_0006:  ret
    } // end of method MyWebServices::GetHashCode

    .method assembly hidebysig instance class [mscorlib]System.Type 
            GetType() cil managed
    {
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       11 (0xb)
      .maxstack  8
      IL_0000:  ldtoken    AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/MyWebServices
      IL_0005:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_000a:  ret
    } // end of method MyWebServices::GetType

    .method public hidebysig strict virtual 
            instance string  ToString() cil managed
    {
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance string [mscorlib]System.Object::ToString()
      IL_0006:  ret
    } // end of method MyWebServices::ToString

    .method private static !!T  Create__Instance__<.ctor T>(!!T 'instance') cil managed
    {
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       20 (0x14)
      .maxstack  1
      .locals init (!!T V_0)
      IL_0000:  ldarg.0
      IL_0001:  box        !!T
      IL_0006:  brtrue.s   IL_0010

      IL_0008:  call       !!0 [mscorlib]System.Activator::CreateInstance<!!0>()
      IL_000d:  stloc.0
      IL_000e:  br.s       IL_0012

      IL_0010:  ldarg.0
      IL_0011:  stloc.0
      IL_0012:  ldloc.0
      IL_0013:  ret
    } // end of method MyWebServices::Create__Instance__

    .method private instance void  Dispose__Instance__<T>(!!T& 'instance') cil managed
    {
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       8 (0x8)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  initobj    !!T
      IL_0007:  ret
    } // end of method MyWebServices::Dispose__Instance__

    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method MyWebServices::.ctor

  } // end of class MyWebServices

  .class auto ansi sealed nested assembly ThreadSafeObjectProvider`1<.ctor T>
         extends [mscorlib]System.Object
  {
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
    .field private initonly class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!T> m_Context
    .method assembly specialname instance !T 
            get_GetInstance() cil managed
    {
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       40 (0x28)
      .maxstack  2
      .locals init (!T V_0)
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!0> class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<!T>::m_Context
      IL_0006:  callvirt   instance !0 class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!T>::get_Value()
      IL_000b:  stloc.0
      IL_000c:  ldloc.0
      IL_000d:  box        !T
      IL_0012:  brtrue.s   IL_0026

      IL_0014:  call       !!0 [mscorlib]System.Activator::CreateInstance<!T>()
      IL_0019:  stloc.0
      IL_001a:  ldarg.0
      IL_001b:  ldfld      class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!0> class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<!T>::m_Context
      IL_0020:  ldloc.0
      IL_0021:  callvirt   instance void class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!T>::set_Value(!0)
      IL_0026:  ldloc.0
      IL_0027:  ret
    } // end of method ThreadSafeObjectProvider`1::get_GetInstance

    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      // Code size       18 (0x12)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ldarg.0
      IL_0007:  newobj     instance void class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!T>::.ctor()
      IL_000c:  stfld      class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!0> class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<!T>::m_Context
      IL_0011:  ret
    } // end of method ThreadSafeObjectProvider`1::.ctor

    .property instance callconv(8) !T GetInstance()
    {
      .get instance !T AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1::get_GetInstance()
    } // end of property ThreadSafeObjectProvider`1::GetInstance
  } // end of class ThreadSafeObjectProvider`1

  .field private static initonly class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer> m_ComputerObjectProvider
  .field private static initonly class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication> m_AppObjectProvider
  .field private static initonly class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User> m_UserObjectProvider
  .field private static initonly class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/MyWebServices> m_MyWebServicesObjectProvider
  .method private specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       41 (0x29)
    .maxstack  8
    IL_0000:  newobj     instance void class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer>::.ctor()
    IL_0005:  stsfld     class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer> AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::m_ComputerObjectProvider
    IL_000a:  newobj     instance void class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication>::.ctor()
    IL_000f:  stsfld     class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication> AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::m_AppObjectProvider
    IL_0014:  newobj     instance void class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User>::.ctor()
    IL_0019:  stsfld     class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User> AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::m_UserObjectProvider
    IL_001e:  newobj     instance void class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/MyWebServices>::.ctor()
    IL_0023:  stsfld     class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/MyWebServices> AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::m_MyWebServicesObjectProvider
    IL_0028:  ret
  } // end of method MyProject::.cctor

  .method assembly specialname static class AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer 
          get_Computer() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       11 (0xb)
    .maxstack  8
    IL_0000:  ldsfld     class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer> AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::m_ComputerObjectProvider
    IL_0005:  callvirt   instance !0 class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer>::get_GetInstance()
    IL_000a:  ret
  } // end of method MyProject::get_Computer

  .method assembly specialname static class AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication 
          get_Application() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       11 (0xb)
    .maxstack  8
    IL_0000:  ldsfld     class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication> AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::m_AppObjectProvider
    IL_0005:  callvirt   instance !0 class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication>::get_GetInstance()
    IL_000a:  ret
  } // end of method MyProject::get_Application

  .method assembly specialname static class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User 
          get_User() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       11 (0xb)
    .maxstack  8
    IL_0000:  ldsfld     class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User> AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::m_UserObjectProvider
    IL_0005:  callvirt   instance !0 class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User>::get_GetInstance()
    IL_000a:  ret
  } // end of method MyProject::get_User

  .method assembly specialname static class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/MyWebServices 
          get_WebServices() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       11 (0xb)
    .maxstack  8
    IL_0000:  ldsfld     class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/MyWebServices> AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::m_MyWebServicesObjectProvider
    IL_0005:  callvirt   instance !0 class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/ThreadSafeObjectProvider`1<class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/MyWebServices>::get_GetInstance()
    IL_000a:  ret
  } // end of method MyProject::get_WebServices

  .property callconv(8) class AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer
          Computer()
  {
    .custom instance void [System]System.ComponentModel.Design.HelpKeywordAttribute::.ctor(string) = ( 01 00 0B 4D 79 2E 43 6F 6D 70 75 74 65 72 00 00 ) // ...My.Computer..
    .get class AspenTech.EquipmentAnalysis.PSVPlus.My.MyComputer AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::get_Computer()
  } // end of property MyProject::Computer
  .property callconv(8) class AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication
          Application()
  {
    .custom instance void [System]System.ComponentModel.Design.HelpKeywordAttribute::.ctor(string) = ( 01 00 0E 4D 79 2E 41 70 70 6C 69 63 61 74 69 6F   // ...My.Applicatio
                                                                                                       6E 00 00 )                                        // n..
    .get class AspenTech.EquipmentAnalysis.PSVPlus.My.MyApplication AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::get_Application()
  } // end of property MyProject::Application
  .property callconv(8) class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User
          User()
  {
    .custom instance void [System]System.ComponentModel.Design.HelpKeywordAttribute::.ctor(string) = ( 01 00 07 4D 79 2E 55 73 65 72 00 00 )             // ...My.User..
    .get class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::get_User()
  } // end of property MyProject::User
  .property callconv(8) class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/MyWebServices
          WebServices()
  {
    .custom instance void [System]System.ComponentModel.Design.HelpKeywordAttribute::.ctor(string) = ( 01 00 0E 4D 79 2E 57 65 62 53 65 72 76 69 63 65   // ...My.WebService
                                                                                                       73 00 00 )                                        // s..
    .get class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject/MyWebServices AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject::get_WebServices()
  } // end of property MyProject::WebServices
} // end of class AspenTech.EquipmentAnalysis.PSVPlus.My.MyProject

.class private auto ansi sealed AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources
       extends [mscorlib]System.Object
{
  .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.StandardModuleAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 33 53 79 73 74 65 6D 2E 52 65 73 6F 75 72   // ..3System.Resour
                                                                                                  63 65 73 2E 54 6F 6F 6C 73 2E 53 74 72 6F 6E 67   // ces.Tools.Strong
                                                                                                  6C 79 54 79 70 65 64 52 65 73 6F 75 72 63 65 42   // lyTypedResourceB
                                                                                                  75 69 6C 64 65 72 08 31 36 2E 30 2E 30 2E 30 00   // uilder.16.0.0.0.
                                                                                                  00 ) 
  .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.HideModuleNameAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private static class [mscorlib]System.Resources.ResourceManager resourceMan
  .field private static class [mscorlib]System.Globalization.CultureInfo resourceCulture
  .method assembly specialname static class [mscorlib]System.Resources.ResourceManager 
          get_ResourceManager() cil managed
  {
    // Code size       49 (0x31)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.Resources.ResourceManager AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources::resourceMan
    IL_0005:  ldnull
    IL_0006:  call       bool [mscorlib]System.Object::ReferenceEquals(object,
                                                                       object)
    IL_000b:  brfalse.s  IL_002b

    IL_000d:  ldstr      "AspenTech.EquipmentAnalysis.PSVPlus.Resources"
    IL_0012:  ldtoken    AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources
    IL_0017:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_001c:  callvirt   instance class [mscorlib]System.Reflection.Assembly [mscorlib]System.Type::get_Assembly()
    IL_0021:  newobj     instance void [mscorlib]System.Resources.ResourceManager::.ctor(string,
                                                                                         class [mscorlib]System.Reflection.Assembly)
    IL_0026:  stsfld     class [mscorlib]System.Resources.ResourceManager AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources::resourceMan
    IL_002b:  ldsfld     class [mscorlib]System.Resources.ResourceManager AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources::resourceMan
    IL_0030:  ret
  } // end of method Resources::get_ResourceManager

  .method assembly specialname static class [mscorlib]System.Globalization.CultureInfo 
          get_Culture() cil managed
  {
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.Globalization.CultureInfo AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources::resourceCulture
    IL_0005:  ret
  } // end of method Resources::get_Culture

  .method assembly specialname static void 
          set_Culture(class [mscorlib]System.Globalization.CultureInfo Value) cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  stsfld     class [mscorlib]System.Globalization.CultureInfo AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources::resourceCulture
    IL_0006:  ret
  } // end of method Resources::set_Culture

  .property callconv(8) class [mscorlib]System.Resources.ResourceManager
          ResourceManager()
  {
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 02 00 00 00 00 00 ) 
    .get class [mscorlib]System.Resources.ResourceManager AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources::get_ResourceManager()
  } // end of property Resources::ResourceManager
  .property callconv(8) class [mscorlib]System.Globalization.CultureInfo
          Culture()
  {
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 02 00 00 00 00 00 ) 
    .get class [mscorlib]System.Globalization.CultureInfo AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources::get_Culture()
    .set void AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources::set_Culture(class [mscorlib]System.Globalization.CultureInfo)
  } // end of property Resources::Culture
} // end of class AspenTech.EquipmentAnalysis.PSVPlus.My.Resources.Resources

.class private auto ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings
       extends [System]System.Configuration.ApplicationSettingsBase
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 4B 4D 69 63 72 6F 73 6F 66 74 2E 56 69 73   // ..KMicrosoft.Vis
                                                                                                  75 61 6C 53 74 75 64 69 6F 2E 45 64 69 74 6F 72   // ualStudio.Editor
                                                                                                  73 2E 53 65 74 74 69 6E 67 73 44 65 73 69 67 6E   // s.SettingsDesign
                                                                                                  65 72 2E 53 65 74 74 69 6E 67 73 53 69 6E 67 6C   // er.SettingsSingl
                                                                                                  65 46 69 6C 65 47 65 6E 65 72 61 74 6F 72 09 31   // eFileGenerator.1
                                                                                                  36 2E 31 30 2E 30 2E 30 00 00 )                   // 6.10.0.0..
  .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 02 00 00 00 00 00 ) 
  .field private static class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings defaultInstance
  .method private specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings::.ctor()
    IL_0005:  call       class [System]System.Configuration.SettingsBase [System]System.Configuration.SettingsBase::Synchronized(class [System]System.Configuration.SettingsBase)
    IL_000a:  castclass  AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings
    IL_000f:  stsfld     class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings::defaultInstance
    IL_0014:  ret
  } // end of method MySettings::.cctor

  .method public specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [System]System.Configuration.ApplicationSettingsBase::.ctor()
    IL_0006:  ret
  } // end of method MySettings::.ctor

  .method public specialname static class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings 
          get_Default() cil managed
  {
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  ldsfld     class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings::defaultInstance
    IL_0005:  ret
  } // end of method MySettings::get_Default

  .property callconv(8) class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings
          Default()
  {
    .get class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings::get_Default()
  } // end of property MySettings::Default
} // end of class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings

.class private auto ansi sealed AspenTech.EquipmentAnalysis.PSVPlus.My.MySettingsProperty
       extends [mscorlib]System.Object
{
  .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.StandardModuleAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.HideModuleNameAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method assembly specialname static class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings 
          get_Settings() cil managed
  {
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  call       class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings::get_Default()
    IL_0005:  ret
  } // end of method MySettingsProperty::get_Settings

  .property callconv(8) class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings
          Settings()
  {
    .custom instance void [System]System.ComponentModel.Design.HelpKeywordAttribute::.ctor(string) = ( 01 00 0B 4D 79 2E 53 65 74 74 69 6E 67 73 00 00 ) // ...My.Settings..
    .get class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettings AspenTech.EquipmentAnalysis.PSVPlus.My.MySettingsProperty::get_Settings()
  } // end of property MySettingsProperty::Settings
} // end of class AspenTech.EquipmentAnalysis.PSVPlus.My.MySettingsProperty

.class public auto ansi AspenTech.EquipmentAnalysis.PSVPlus.CxsHost
       extends [mscorlib]System.Object
       implements [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost
{
  .field private initonly class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer _container
  .field private string _DataPath
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary _Simulator
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method private specialname instance string 
          get_DataPath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_DataPath
    IL_0006:  ret
  } // end of method CxsHost::get_DataPath

  .method private specialname instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary 
          get_Simulator() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_Simulator
    IL_0006:  ret
  } // end of method CxsHost::get_Simulator

  .method public specialname rtspecialname 
          instance void  .ctor(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer container) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_container
    IL_000d:  ret
  } // end of method CxsHost::.ctor

  .method public newslot strict virtual final 
          instance void  AddStatus(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel level,
                                   int32 count,
                                   string message) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::AddStatus
    // Code size       76 (0x4c)
    .maxstack  8
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0006:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVCommands()
    IL_000b:  ldstr      "Level"
    IL_0010:  ldarga.s   level
    IL_0012:  constrained. [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel
    IL_0018:  callvirt   instance string [mscorlib]System.Enum::ToString()
    IL_001d:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0022:  ldarg.2
    IL_0023:  ldarg.3
    IL_0024:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands::PSVAddStatus(string,
                                                                                                                                                              int32,
                                                                                                                                                              string)
    IL_0029:  stloc.0
    IL_002a:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_002f:  ldarg.0
    IL_0030:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_DataPath()
    IL_0035:  ldstr      "SendMessage"
    IL_003a:  ldc.i4.0
    IL_003b:  ldc.i4.1
    IL_003c:  newarr     [mscorlib]System.Object
    IL_0041:  dup
    IL_0042:  ldc.i4.0
    IL_0043:  ldloc.0
    IL_0044:  stelem.ref
    IL_0045:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::InvokeAction(string,
                                                                                                                                                                                                                        string,
                                                                                                                                                                                                                        bool,
                                                                                                                                                                                                                        object[])
    IL_004a:  pop
    IL_004b:  ret
  } // end of method CxsHost::AddStatus

  .method public newslot strict virtual final 
          instance void  ClearStatus() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::ClearStatus
    // Code size       51 (0x33)
    .maxstack  8
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0006:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVCommands()
    IL_000b:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands::get_PSVClearStatus()
    IL_0010:  stloc.0
    IL_0011:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0016:  ldarg.0
    IL_0017:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_DataPath()
    IL_001c:  ldstr      "SendMessage"
    IL_0021:  ldc.i4.0
    IL_0022:  ldc.i4.1
    IL_0023:  newarr     [mscorlib]System.Object
    IL_0028:  dup
    IL_0029:  ldc.i4.0
    IL_002a:  ldloc.0
    IL_002b:  stelem.ref
    IL_002c:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::InvokeAction(string,
                                                                                                                                                                                                                        string,
                                                                                                                                                                                                                        bool,
                                                                                                                                                                                                                        object[])
    IL_0031:  pop
    IL_0032:  ret
  } // end of method CxsHost::ClearStatus

  .method public newslot strict virtual final 
          instance void  Initialize(string dataPath,
                                    class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary simulator) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::Initialize
    // Code size       15 (0xf)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_DataPath
    IL_0007:  ldarg.0
    IL_0008:  ldarg.2
    IL_0009:  stfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_Simulator
    IL_000e:  ret
  } // end of method CxsHost::Initialize

  .method public newslot strict virtual final 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetStreamTemperature() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetStreamTemperature
    // Code size       76 (0x4c)
    .maxstack  4
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_DataPath()
    IL_0006:  ldstr      "."
    IL_000b:  ldarg.0
    IL_000c:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0011:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0016:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_PSVStreamTemperature()
    IL_001b:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0020:  stloc.0
    IL_0021:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0026:  ldloc.0
    IL_0027:  ldstr      "value"
    IL_002c:  ldarg.0
    IL_002d:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0032:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
    IL_0037:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Temperature_C()
    IL_003c:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchGet(string,
                                                                                                                                    string,
                                                                                                                                    string)
    IL_0041:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0046:  call       valuetype [mscorlib]System.Nullable`1<float64> [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToDouble(object)
    IL_004b:  ret
  } // end of method CxsHost::GetStreamTemperature

  .method public newslot strict virtual final 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetStreamPressure() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetStreamPressure
    // Code size       76 (0x4c)
    .maxstack  4
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_DataPath()
    IL_0006:  ldstr      "."
    IL_000b:  ldarg.0
    IL_000c:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0011:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0016:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_StreamPress()
    IL_001b:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0020:  stloc.0
    IL_0021:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0026:  ldloc.0
    IL_0027:  ldstr      "value"
    IL_002c:  ldarg.0
    IL_002d:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0032:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
    IL_0037:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Pressure_kPa()
    IL_003c:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchGet(string,
                                                                                                                                    string,
                                                                                                                                    string)
    IL_0041:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0046:  call       valuetype [mscorlib]System.Nullable`1<float64> [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToDouble(object)
    IL_004b:  ret
  } // end of method CxsHost::GetStreamPressure

  .method public newslot strict virtual final 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetStreamMassFlow(string scenarioPath) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetStreamMassFlow
    // Code size       91 (0x5b)
    .maxstack  4
    .locals init (valuetype [mscorlib]System.Nullable`1<float64> V_0,
             string V_1)
    IL_0000:  ldarg.1
    IL_0001:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0006:  brfalse.s  IL_0012

    IL_0008:  ldloca.s   V_0
    IL_000a:  initobj    valuetype [mscorlib]System.Nullable`1<float64>
    IL_0010:  br.s       IL_0059

    IL_0012:  ldarg.1
    IL_0013:  ldstr      "."
    IL_0018:  ldarg.0
    IL_0019:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_001e:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0023:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioRefStreamMassFlow()
    IL_0028:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_002d:  stloc.1
    IL_002e:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0033:  ldloc.1
    IL_0034:  ldstr      "value"
    IL_0039:  ldarg.0
    IL_003a:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_003f:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
    IL_0044:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_MassFlow_kg_h()
    IL_0049:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchGet(string,
                                                                                                                                    string,
                                                                                                                                    string)
    IL_004e:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0053:  call       valuetype [mscorlib]System.Nullable`1<float64> [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToDouble(object)
    IL_0058:  stloc.0
    IL_0059:  ldloc.0
    IL_005a:  ret
  } // end of method CxsHost::GetStreamMassFlow

  .method public newslot strict virtual final 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetRefStreamTemperature(string scenarioPath) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetRefStreamTemperature
    // Code size       91 (0x5b)
    .maxstack  4
    .locals init (valuetype [mscorlib]System.Nullable`1<float64> V_0,
             string V_1)
    IL_0000:  ldarg.1
    IL_0001:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0006:  brfalse.s  IL_0012

    IL_0008:  ldloca.s   V_0
    IL_000a:  initobj    valuetype [mscorlib]System.Nullable`1<float64>
    IL_0010:  br.s       IL_0059

    IL_0012:  ldarg.1
    IL_0013:  ldstr      "."
    IL_0018:  ldarg.0
    IL_0019:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_001e:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0023:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioRefStreamTemperature()
    IL_0028:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_002d:  stloc.1
    IL_002e:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0033:  ldloc.1
    IL_0034:  ldstr      "value"
    IL_0039:  ldarg.0
    IL_003a:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_003f:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
    IL_0044:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Temperature_C()
    IL_0049:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchGet(string,
                                                                                                                                    string,
                                                                                                                                    string)
    IL_004e:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0053:  call       valuetype [mscorlib]System.Nullable`1<float64> [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToDouble(object)
    IL_0058:  stloc.0
    IL_0059:  ldloc.0
    IL_005a:  ret
  } // end of method CxsHost::GetRefStreamTemperature

  .method public newslot strict virtual final 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetRefStreamPressure(string scenarioPath) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetRefStreamPressure
    // Code size       91 (0x5b)
    .maxstack  4
    .locals init (valuetype [mscorlib]System.Nullable`1<float64> V_0,
             string V_1)
    IL_0000:  ldarg.1
    IL_0001:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0006:  brfalse.s  IL_0012

    IL_0008:  ldloca.s   V_0
    IL_000a:  initobj    valuetype [mscorlib]System.Nullable`1<float64>
    IL_0010:  br.s       IL_0059

    IL_0012:  ldarg.1
    IL_0013:  ldstr      "."
    IL_0018:  ldarg.0
    IL_0019:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_001e:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0023:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_StreamPress()
    IL_0028:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_002d:  stloc.1
    IL_002e:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0033:  ldloc.1
    IL_0034:  ldstr      "value"
    IL_0039:  ldarg.0
    IL_003a:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_003f:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
    IL_0044:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Pressure_kPa()
    IL_0049:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchGet(string,
                                                                                                                                    string,
                                                                                                                                    string)
    IL_004e:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0053:  call       valuetype [mscorlib]System.Nullable`1<float64> [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToDouble(object)
    IL_0058:  stloc.0
    IL_0059:  ldloc.0
    IL_005a:  ret
  } // end of method CxsHost::GetRefStreamPressure

  .method public newslot strict virtual final 
          instance valuetype [mscorlib]System.Nullable`1<bool> 
          GetDirtyState(string objectPath) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetDirtyState
    // Code size       56 (0x38)
    .maxstack  4
    .locals init (string V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldstr      "."
    IL_0006:  ldarg.0
    IL_0007:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_000c:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0011:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioIsDirty()
    IL_0016:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_001b:  stloc.0
    IL_001c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0021:  ldloc.0
    IL_0022:  ldstr      "value"
    IL_0027:  ldnull
    IL_0028:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchGet(string,
                                                                                                                                    string,
                                                                                                                                    string)
    IL_002d:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0032:  call       valuetype [mscorlib]System.Nullable`1<bool> [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToBoolean(object)
    IL_0037:  ret
  } // end of method CxsHost::GetDirtyState

  .method public newslot strict virtual final 
          instance void  SetDirtyState(string objectPath,
                                       bool 'value') cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::SetDirtyState
    // Code size       53 (0x35)
    .maxstack  5
    .locals init (string V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldstr      "."
    IL_0006:  ldarg.0
    IL_0007:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_000c:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0011:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioIsDirty()
    IL_0016:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_001b:  stloc.0
    IL_001c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0021:  ldloc.0
    IL_0022:  ldstr      "value"
    IL_0027:  ldnull
    IL_0028:  ldarg.2
    IL_0029:  box        [mscorlib]System.Boolean
    IL_002e:  callvirt   instance bool [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchSet(string,
                                                                                                                                  string,
                                                                                                                                  string,
                                                                                                                                  object)
    IL_0033:  pop
    IL_0034:  ret
  } // end of method CxsHost::SetDirtyState

  .method public newslot strict virtual final 
          instance bool  DuplicateScenario(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey key,
                                           [opt] string scenarioPath) cil managed
  {
    .param [2] = nullref
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::DuplicateScenario
    // Code size       66 (0x42)
    .maxstack  8
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0006:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVCommands()
    IL_000b:  ldarg.1
    IL_000c:  call       class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey::op_Implicit(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey)
    IL_0011:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands::PSVDuplicate_Scenario(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey)
    IL_0016:  stloc.0
    IL_0017:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_001c:  ldarg.2
    IL_001d:  dup
    IL_001e:  brtrue.s   IL_0027

    IL_0020:  pop
    IL_0021:  ldarg.0
    IL_0022:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_DataPath()
    IL_0027:  ldstr      "SendMessage"
    IL_002c:  ldc.i4.0
    IL_002d:  ldc.i4.1
    IL_002e:  newarr     [mscorlib]System.Object
    IL_0033:  dup
    IL_0034:  ldc.i4.0
    IL_0035:  ldloc.0
    IL_0036:  stelem.ref
    IL_0037:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::InvokeAction(string,
                                                                                                                                                                                                                        string,
                                                                                                                                                                                                                        bool,
                                                                                                                                                                                                                        object[])
    IL_003c:  callvirt   instance bool [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult::get_Succeeded()
    IL_0041:  ret
  } // end of method CxsHost::DuplicateScenario

  .method public newslot strict virtual final 
          instance bool  PasteScenario(string newScenarioName,
                                       [opt] string scenarioPath) cil managed
  {
    .param [2] = nullref
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::PasteScenario
    // Code size       61 (0x3d)
    .maxstack  8
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0006:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVCommands()
    IL_000b:  ldarg.1
    IL_000c:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands::PSVCreate_Scenario(string)
    IL_0011:  stloc.0
    IL_0012:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0017:  ldarg.2
    IL_0018:  dup
    IL_0019:  brtrue.s   IL_0022

    IL_001b:  pop
    IL_001c:  ldarg.0
    IL_001d:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_DataPath()
    IL_0022:  ldstr      "SendMessage"
    IL_0027:  ldc.i4.0
    IL_0028:  ldc.i4.1
    IL_0029:  newarr     [mscorlib]System.Object
    IL_002e:  dup
    IL_002f:  ldc.i4.0
    IL_0030:  ldloc.0
    IL_0031:  stelem.ref
    IL_0032:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::InvokeAction(string,
                                                                                                                                                                                                                        string,
                                                                                                                                                                                                                        bool,
                                                                                                                                                                                                                        object[])
    IL_0037:  callvirt   instance bool [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult::get_Succeeded()
    IL_003c:  ret
  } // end of method CxsHost::PasteScenario

  .method private instance float64  _GetEmptyValue(float64 'value') cil managed
  {
    // Code size       20 (0x14)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0006:  brtrue.s   IL_000a

    IL_0008:  ldarg.1
    IL_0009:  ret

    IL_000a:  ldc.r8     -32767
    IL_0013:  ret
  } // end of method CxsHost::_GetEmptyValue

  .method public newslot strict virtual final 
          instance void  SetValveData(string prdSystemPath,
                                      float64 calcOrifice,
                                      float64 selectedOrifice,
                                      string orificeDesignation,
                                      bool isSizingCase,
                                      float64 inletFlangeSize,
                                      float64 outletFlangeSize) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::SetValveData
    // Code size       451 (0x1c3)
    .maxstack  7
    .locals init (class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData V_0,
             string V_1,
             string V_2,
             string V_3,
             string V_4,
             object V_5,
             string V_6,
             string V_7)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_container
    IL_0006:  ldc.i4.0
    IL_0007:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_000c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0011:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::.ctor()
    IL_0016:  stloc.0
    IL_0017:  ldarg.1
    IL_0018:  ldstr      "."
    IL_001d:  ldarg.0
    IL_001e:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0023:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0028:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioCalcOrificeSize()
    IL_002d:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0032:  stloc.1
    IL_0033:  ldloc.0
    IL_0034:  ldloc.1
    IL_0035:  ldstr      "value"
    IL_003a:  ldarg.0
    IL_003b:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0040:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
    IL_0045:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Area_cm2()
    IL_004a:  ldarg.0
    IL_004b:  ldarg.2
    IL_004c:  call       instance float64 AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_GetEmptyValue(float64)
    IL_0051:  box        [mscorlib]System.Double
    IL_0056:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                     string,
                                                                                                     string,
                                                                                                     object)
    IL_005b:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
    IL_0060:  ldarg.1
    IL_0061:  ldstr      "."
    IL_0066:  ldarg.0
    IL_0067:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_006c:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0071:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioSelOrificeSize()
    IL_0076:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_007b:  stloc.2
    IL_007c:  ldloc.0
    IL_007d:  ldloc.2
    IL_007e:  ldstr      "value"
    IL_0083:  ldarg.0
    IL_0084:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0089:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
    IL_008e:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Area_cm2()
    IL_0093:  ldarg.0
    IL_0094:  ldarg.3
    IL_0095:  call       instance float64 AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_GetEmptyValue(float64)
    IL_009a:  box        [mscorlib]System.Double
    IL_009f:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                     string,
                                                                                                     string,
                                                                                                     object)
    IL_00a4:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
    IL_00a9:  ldarg.1
    IL_00aa:  ldstr      "."
    IL_00af:  ldarg.0
    IL_00b0:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_00b5:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_00ba:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioOrificeDesignation()
    IL_00bf:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_00c4:  stloc.3
    IL_00c5:  ldloc.0
    IL_00c6:  ldloc.3
    IL_00c7:  ldstr      "value"
    IL_00cc:  ldnull
    IL_00cd:  ldarg.s    orificeDesignation
    IL_00cf:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                     string,
                                                                                                     string,
                                                                                                     object)
    IL_00d4:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
    IL_00d9:  ldarg.1
    IL_00da:  ldstr      "."
    IL_00df:  ldarg.0
    IL_00e0:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_00e5:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_00ea:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioIsSizingCase()
    IL_00ef:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_00f4:  stloc.s    V_4
    IL_00f6:  ldarg.s    isSizingCase
    IL_00f8:  callvirt   instance object [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::GetFlagValue(bool)
    IL_00fd:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0102:  stloc.s    V_5
    IL_0104:  ldloc.0
    IL_0105:  ldloc.s    V_4
    IL_0107:  ldstr      "value"
    IL_010c:  ldnull
    IL_010d:  ldloc.s    V_5
    IL_010f:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0114:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                     string,
                                                                                                     string,
                                                                                                     object)
    IL_0119:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
    IL_011e:  ldarg.1
    IL_011f:  ldstr      "."
    IL_0124:  ldarg.0
    IL_0125:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_012a:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_012f:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioInletPipeID()
    IL_0134:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0139:  stloc.s    V_6
    IL_013b:  ldloc.0
    IL_013c:  ldloc.s    V_6
    IL_013e:  ldstr      "value"
    IL_0143:  ldarg.0
    IL_0144:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0149:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
    IL_014e:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Length_in()
    IL_0153:  ldarg.0
    IL_0154:  ldarg.s    inletFlangeSize
    IL_0156:  call       instance float64 AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_GetEmptyValue(float64)
    IL_015b:  box        [mscorlib]System.Double
    IL_0160:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                     string,
                                                                                                     string,
                                                                                                     object)
    IL_0165:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
    IL_016a:  ldarg.1
    IL_016b:  ldstr      "."
    IL_0170:  ldarg.0
    IL_0171:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0176:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_017b:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioOutletPipeID()
    IL_0180:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_0185:  stloc.s    V_7
    IL_0187:  ldloc.0
    IL_0188:  ldloc.s    V_7
    IL_018a:  ldstr      "value"
    IL_018f:  ldarg.0
    IL_0190:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0195:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
    IL_019a:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Length_in()
    IL_019f:  ldarg.0
    IL_01a0:  ldarg.s    outletFlangeSize
    IL_01a2:  call       instance float64 AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_GetEmptyValue(float64)
    IL_01a7:  box        [mscorlib]System.Double
    IL_01ac:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                     string,
                                                                                                     string,
                                                                                                     object)
    IL_01b1:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
    IL_01b6:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_01bb:  ldloc.0
    IL_01bc:  callvirt   instance bool [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchSet(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData)
    IL_01c1:  pop
    IL_01c2:  ret
  } // end of method CxsHost::SetValveData

  .method public newslot strict virtual final 
          instance void  InvokeOnUi(object 'instance',
                                    class [mscorlib]System.Delegate 'method',
                                    object[] args) cil managed
  {
    .param [3]
    .custom instance void [mscorlib]System.ParamArrayAttribute::.ctor() = ( 01 00 00 00 ) 
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::InvokeOnUi
    // Code size       48 (0x30)
    .maxstack  3
    .locals init (class [WindowsBase]System.Windows.Threading.Dispatcher V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [WindowsBase]System.Windows.Threading.Dispatcher AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_GetDispatcher()
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  brfalse.s  IL_001c

    IL_000a:  ldloc.0
    IL_000b:  call       class [WindowsBase]System.Windows.Threading.Dispatcher [WindowsBase]System.Windows.Threading.Dispatcher::get_CurrentDispatcher()
    IL_0010:  beq.s      IL_001c

    IL_0012:  ldloc.0
    IL_0013:  ldarg.2
    IL_0014:  ldarg.3
    IL_0015:  callvirt   instance class [WindowsBase]System.Windows.Threading.DispatcherOperation [WindowsBase]System.Windows.Threading.Dispatcher::BeginInvoke(class [mscorlib]System.Delegate,
                                                                                                                                                                object[])
    IL_001a:  pop
    IL_001b:  ret

    IL_001c:  ldarg.2
    IL_001d:  callvirt   instance class [mscorlib]System.Reflection.MethodInfo [mscorlib]System.Delegate::get_Method()
    IL_0022:  ldarg.1
    IL_0023:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0028:  ldarg.3
    IL_0029:  callvirt   instance object [mscorlib]System.Reflection.MethodBase::Invoke(object,
                                                                                        object[])
    IL_002e:  pop
    IL_002f:  ret
  } // end of method CxsHost::InvokeOnUi

  .method private instance class [WindowsBase]System.Windows.Threading.Dispatcher 
          _GetDispatcher() cil managed
  {
    // Code size       49 (0x31)
    .maxstack  2
    .locals init (class [WindowsBase]System.Windows.Threading.Dispatcher V_0,
             class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.IShellApplication V_1,
             class [AspenTech.Visualisation.CommonShell.Wpf]AspenTech.Visualisation.CommonShell.CommonShellWindow V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_container
    IL_0006:  ldc.i4.0
    IL_0007:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_000c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.IShellApplication>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                         class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0011:  stloc.1
    IL_0012:  ldloc.1
    IL_0013:  brfalse.s  IL_002d

    IL_0015:  ldloc.1
    IL_0016:  callvirt   instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.IShellMainWindow [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.IShellApplication::get_ActiveWindow()
    IL_001b:  isinst     [AspenTech.Visualisation.CommonShell.Wpf]AspenTech.Visualisation.CommonShell.CommonShellWindow
    IL_0020:  stloc.2
    IL_0021:  ldloc.2
    IL_0022:  brfalse.s  IL_002d

    IL_0024:  ldloc.2
    IL_0025:  callvirt   instance class [WindowsBase]System.Windows.Threading.Dispatcher [WindowsBase]System.Windows.Threading.DispatcherObject::get_Dispatcher()
    IL_002a:  stloc.0
    IL_002b:  br.s       IL_002f

    IL_002d:  ldnull
    IL_002e:  stloc.0
    IL_002f:  ldloc.0
    IL_0030:  ret
  } // end of method CxsHost::_GetDispatcher

  .method public newslot strict virtual final 
          instance string  GetRefStreamName(string scenarioPath) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetRefStreamName
    // Code size       24 (0x18)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_container
    IL_0006:  ldc.i4.0
    IL_0007:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_000c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0011:  ldarg.1
    IL_0012:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::GetScenarioStreamName(string)
    IL_0017:  ret
  } // end of method CxsHost::GetRefStreamName

  .method public newslot strict virtual final 
          instance bool  GetTankUsesPropertyPackage(string tankPath) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetTankUsesPropertyPackage
    // Code size       65 (0x41)
    .maxstack  4
    .locals init (string V_0,
             valuetype [mscorlib]System.Nullable`1<bool> V_1)
    IL_0000:  ldarg.1
    IL_0001:  ldstr      "."
    IL_0006:  ldarg.0
    IL_0007:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_000c:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0011:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_TankUseRefStream()
    IL_0016:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_001b:  stloc.0
    IL_001c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0021:  ldloc.0
    IL_0022:  ldstr      "value"
    IL_0027:  ldnull
    IL_0028:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchGet(string,
                                                                                                                                    string,
                                                                                                                                    string)
    IL_002d:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0032:  call       valuetype [mscorlib]System.Nullable`1<bool> [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToBoolean(object)
    IL_0037:  stloc.1
    IL_0038:  ldloca.s   V_1
    IL_003a:  ldc.i4.0
    IL_003b:  call       instance !0 valuetype [mscorlib]System.Nullable`1<bool>::GetValueOrDefault(!0)
    IL_0040:  ret
  } // end of method CxsHost::GetTankUsesPropertyPackage

  .method public newslot strict virtual final 
          instance void  SetTankUsesPropertyPackage(string tankPath,
                                                    bool 'value') cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::SetTankUsesPropertyPackage
    // Code size       63 (0x3f)
    .maxstack  5
    .locals init (string V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldstr      "."
    IL_0006:  ldarg.0
    IL_0007:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_000c:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_0011:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_TankUseRefStream()
    IL_0016:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_001b:  stloc.0
    IL_001c:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0021:  ldloc.0
    IL_0022:  ldstr      "value"
    IL_0027:  ldnull
    IL_0028:  ldarg.2
    IL_0029:  box        [mscorlib]System.Boolean
    IL_002e:  callvirt   instance bool [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchSet(string,
                                                                                                                                  string,
                                                                                                                                  string,
                                                                                                                                  object)
    IL_0033:  pop
    IL_0034:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0039:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::UpdateDataCache()
    IL_003e:  ret
  } // end of method CxsHost::SetTankUsesPropertyPackage

  .method public newslot strict virtual final 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetTankStreamTemperature(string tankPath,
                                   string streamName) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetTankStreamTemperature
    // Code size       68 (0x44)
    .maxstack  4
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_container
    IL_0006:  ldc.i4.0
    IL_0007:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_000c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0011:  ldarg.1
    IL_0012:  ldarg.2
    IL_0013:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::GetTankStreamTemperaturePath(string,
                                                                                                                                                                           string)
    IL_0018:  stloc.0
    IL_0019:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_001e:  ldloc.0
    IL_001f:  ldstr      "value"
    IL_0024:  ldarg.0
    IL_0025:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_002a:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
    IL_002f:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Temperature_C()
    IL_0034:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchGet(string,
                                                                                                                                    string,
                                                                                                                                    string)
    IL_0039:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_003e:  call       valuetype [mscorlib]System.Nullable`1<float64> [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToDouble(object)
    IL_0043:  ret
  } // end of method CxsHost::GetTankStreamTemperature

  .method public newslot strict virtual final 
          instance string  GetTankUpdatedId(string tankPath,
                                            string newTankName) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetTankUpdatedId
    // Code size       23 (0x17)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
    IL_0006:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_000b:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_TankDirectory()
    IL_0010:  ldarg.2
    IL_0011:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0016:  ret
  } // end of method CxsHost::GetTankUpdatedId

  .method public newslot strict virtual final 
          instance valuetype [mscorlib]System.Nullable`1<bool> 
          GetTankDirtyState(string tankId) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetTankDirtyState
    // Code size       33 (0x21)
    .maxstack  4
    .locals init (class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_container
    IL_0006:  ldc.i4.0
    IL_0007:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_000c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0011:  stloc.0
    IL_0012:  ldloc.0
    IL_0013:  ldarg.1
    IL_0014:  ldloc.0
    IL_0015:  ldarg.1
    IL_0016:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::GetTankStreamName(string)
    IL_001b:  callvirt   instance valuetype [mscorlib]System.Nullable`1<bool> [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::GetTankDirtyState(string,
                                                                                                                                                                                                     string)
    IL_0020:  ret
  } // end of method CxsHost::GetTankDirtyState

  .method public newslot strict virtual final 
          instance void  SetTankDirtyState(string tankId,
                                           bool 'value') cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::SetTankDirtyState
    // Code size       34 (0x22)
    .maxstack  4
    .locals init (class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_container
    IL_0006:  ldc.i4.0
    IL_0007:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_000c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0011:  stloc.0
    IL_0012:  ldloc.0
    IL_0013:  ldarg.1
    IL_0014:  ldloc.0
    IL_0015:  ldarg.1
    IL_0016:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::GetTankStreamName(string)
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::SetTankDirtyState(string,
                                                                                                                                                              string,
                                                                                                                                                              bool)
    IL_0021:  ret
  } // end of method CxsHost::SetTankDirtyState

  .method public newslot strict virtual final 
          instance string  GetTankStreamName(string tankId) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost::GetTankStreamName
    // Code size       24 (0x18)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::_container
    IL_0006:  ldc.i4.0
    IL_0007:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_000c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0011:  ldarg.1
    IL_0012:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::GetTankStreamName(string)
    IL_0017:  ret
  } // end of method CxsHost::GetTankStreamName

  .property instance callconv(8) string DataPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_DataPath()
  } // end of property CxsHost::DataPath
  .property instance callconv(8) class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary
          Simulator()
  {
    .get instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary AspenTech.EquipmentAnalysis.PSVPlus.CxsHost::get_Simulator()
  } // end of property CxsHost::Simulator
} // end of class AspenTech.EquipmentAnalysis.PSVPlus.CxsHost

.class public auto ansi AspenTech.EquipmentAnalysis.PSVPlus.PsvCase
       extends [mscorlib]System.Object
       implements [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase
{
  .class auto ansi sealed nested assembly '_Closure$__31-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey $VB$Local_prdSysKey
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__31-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement ppr) cil managed
    {
      // Code size       20 (0x14)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::get_LegacyKey()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__31-0'::$VB$Local_prdSysKey
      IL_000c:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_0011:  ceq
      IL_0013:  ret
    } // end of method '_Closure$__31-0'::_Lambda$__0

  } // end of class '_Closure$__31-0'

  .class auto ansi sealed nested assembly '_Closure$__32-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey $VB$Local_prdSysKey
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__32-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel prds) cil managed
    {
      // Code size       20 (0x14)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::get_LegacyKey()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__32-0'::$VB$Local_prdSysKey
      IL_000c:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_0011:  ceq
      IL_0013:  ret
    } // end of method '_Closure$__32-0'::_Lambda$__0

  } // end of class '_Closure$__32-0'

  .class auto ansi sealed nested assembly '_Closure$__34-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement $VB$Local_ppr
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__34-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel psm) cil managed
    {
      // Code size       15 (0xf)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__34-0'::$VB$Local_ppr
      IL_0006:  ldarg.1
      IL_0007:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::get_Model()
      IL_000c:  ceq
      IL_000e:  ret
    } // end of method '_Closure$__34-0'::_Lambda$__0

  } // end of class '_Closure$__34-0'

  .class auto ansi sealed nested assembly '_Closure$__36-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public int32 $VB$Local_legacyKey
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__36-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition pcd) cil managed
    {
      // Code size       15 (0xf)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition::get_LegacyKey()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      int32 AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__36-0'::$VB$Local_legacyKey
      IL_000c:  ceq
      IL_000e:  ret
    } // end of method '_Closure$__36-0'::_Lambda$__0

  } // end of class '_Closure$__36-0'

  .class auto ansi sealed nested assembly '_Closure$__39-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey $VB$Local_PRDSystemKey
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__39-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement ppr) cil managed
    {
      // Code size       20 (0x14)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::get_LegacyKey()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__39-0'::$VB$Local_PRDSystemKey
      IL_000c:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_0011:  ceq
      IL_0013:  ret
    } // end of method '_Closure$__39-0'::_Lambda$__0

  } // end of class '_Closure$__39-0'

  .class auto ansi sealed nested assembly '_Closure$__40-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition $VB$Local_prdConstraints
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__40-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel psm) cil managed
    {
      // Code size       25 (0x19)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::get_Model()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__40-0'::$VB$Local_prdConstraints
      IL_000c:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition::get_ReliefScenario()
      IL_0011:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario::get_PressureProtectionRequirement()
      IL_0016:  ceq
      IL_0018:  ret
    } // end of method '_Closure$__40-0'::_Lambda$__0

  } // end of class '_Closure$__40-0'

  .class auto ansi sealed nested assembly '_Closure$__42-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey $VB$Local_tankKey
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__42-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank st) cil managed
    {
      // Code size       20 (0x14)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank::get_LegacyKey()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__42-0'::$VB$Local_tankKey
      IL_000c:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_0011:  ceq
      IL_0013:  ret
    } // end of method '_Closure$__42-0'::_Lambda$__0

  } // end of class '_Closure$__42-0'

  .class auto ansi sealed nested assembly '_Closure$__43-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey $VB$Local_tankKey
    .method public specialname rtspecialname 
            instance void  .ctor(class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__43-0' arg0) cil managed
    {
      // Code size       22 (0x16)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ldarg.1
      IL_0007:  brfalse.s  IL_0015

      IL_0009:  ldarg.0
      IL_000a:  ldarg.1
      IL_000b:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__43-0'::$VB$Local_tankKey
      IL_0010:  stfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__43-0'::$VB$Local_tankKey
      IL_0015:  ret
    } // end of method '_Closure$__43-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel st) cil managed
    {
      // Code size       20 (0x14)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel::get_LegacyKey()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__43-0'::$VB$Local_tankKey
      IL_000c:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_0011:  ceq
      IL_0013:  ret
    } // end of method '_Closure$__43-0'::_Lambda$__0

  } // end of class '_Closure$__43-0'

  .class auto ansi sealed nested assembly '_Closure$__49-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel $VB$Local_oldScenario
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__49-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel psv) cil managed
    {
      // Code size       18 (0x12)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance class [mscorlib]System.Collections.Generic.IList`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel> [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::get_OverallScenarioModels()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__49-0'::$VB$Local_oldScenario
      IL_000c:  callvirt   instance bool class [mscorlib]System.Collections.Generic.ICollection`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel>::Contains(!0)
      IL_0011:  ret
    } // end of method '_Closure$__49-0'::_Lambda$__0

  } // end of class '_Closure$__49-0'

  .class auto ansi sealed nested assembly '_Closure$__62-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey $VB$Local_key
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__62-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank st) cil managed
    {
      // Code size       20 (0x14)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank::get_LegacyKey()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::$VB$Local_key
      IL_000c:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_0011:  ceq
      IL_0013:  ret
    } // end of method '_Closure$__62-0'::_Lambda$__0

    .method assembly specialname instance bool 
            _Lambda$__1(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement ppr) cil managed
    {
      // Code size       20 (0x14)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::get_LegacyKey()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::$VB$Local_key
      IL_000c:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_0011:  ceq
      IL_0013:  ret
    } // end of method '_Closure$__62-0'::_Lambda$__1

    .method assembly specialname instance bool 
            _Lambda$__2(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition pcd) cil managed
    {
      // Code size       20 (0x14)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition::get_LegacyKey()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::$VB$Local_key
      IL_000c:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_0011:  ceq
      IL_0013:  ret
    } // end of method '_Closure$__62-0'::_Lambda$__2

  } // end of class '_Closure$__62-0'

  .class auto ansi sealed nested assembly '_Closure$__66-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey $VB$Local_prdSysKey
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__66-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement ppr) cil managed
    {
      // Code size       20 (0x14)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::get_LegacyKey()
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__66-0'::$VB$Local_prdSysKey
      IL_000c:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_0011:  ceq
      IL_0013:  ret
    } // end of method '_Closure$__66-0'::_Lambda$__0

  } // end of class '_Closure$__66-0'

  .class auto ansi serializable sealed nested assembly _Closure$__
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static initonly class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__ $I
    .field public static class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32> '$I66-1'
    .field public static class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32> '$I66-2'
    .field public static class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel,object> '$I69-0'
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method _Closure$__::.ctor

    .method private specialname rtspecialname static 
            void  .cctor() cil managed
    {
      // Code size       11 (0xb)
      .maxstack  8
      IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::.ctor()
      IL_0005:  stsfld     class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__ AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::$I
      IL_000a:  ret
    } // end of method _Closure$__::.cctor

    .method assembly specialname instance int32 
            '_Lambda$__66-1'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey> kvp) cil managed
    {
      // Code size       13 (0xd)
      .maxstack  8
      IL_0000:  ldarga.s   kvp
      IL_0002:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>::get_Key()
      IL_0007:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_000c:  ret
    } // end of method _Closure$__::'_Lambda$__66-1'

    .method assembly specialname instance int32 
            '_Lambda$__66-2'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey> kvp) cil managed
    {
      // Code size       13 (0xd)
      .maxstack  8
      IL_0000:  ldarga.s   kvp
      IL_0002:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>::get_Value()
      IL_0007:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
      IL_000c:  ret
    } // end of method _Closure$__::'_Lambda$__66-2'

    .method assembly specialname instance object 
            '_Lambda$__69-0'(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel m) cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance object [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_DataModel()
      IL_0006:  ret
    } // end of method _Closure$__::'_Lambda$__69-0'

  } // end of class _Closure$__

  .field private class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer myContainer
  .field private class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator myEventAggregator
  .field private class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> myPRDSystemModels
  .field private class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> myStorageTankModels
  .field private bool myWarningIssued
  .field private class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase SafetyAnalysisCase
  .field private class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator _parentAggregator
  .field private class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken _activeScreenChangedToken
  .field private string _host
  .field private string m_caseKey
  .field private class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop _AdbTop
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer parentUnityContainer) cil managed
  {
    // Code size       193 (0xc1)
    .maxstack  3
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::.ctor()
    IL_000c:  stfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
    IL_0011:  ldarg.0
    IL_0012:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>::.ctor()
    IL_0017:  stfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myStorageTankModels
    IL_001c:  ldarg.0
    IL_001d:  ldc.i4.0
    IL_001e:  stfld      bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myWarningIssued
    IL_0023:  ldarg.0
    IL_0024:  ldarg.1
    IL_0025:  callvirt   instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer::CreateChildContainer()
    IL_002a:  castclass  [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer
    IL_002f:  stfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0034:  ldarg.0
    IL_0035:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_003a:  newobj     instance void [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ContainerControlledLifetimeManager::.ctor()
    IL_003f:  ldc.i4.0
    IL_0040:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.InjectionMember
    IL_0045:  call       class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::RegisterType<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator,class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutingEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                                                                                                                                                                                                     class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.LifetimeManager,
                                                                                                                                                                                                                                                                                                                                                                                                                     class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.InjectionMember[])
    IL_004a:  pop
    IL_004b:  ldarg.0
    IL_004c:  ldarg.0
    IL_004d:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0052:  ldc.i4.0
    IL_0053:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0058:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_005d:  stfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myEventAggregator
    IL_0062:  ldarg.0
    IL_0063:  ldarg.1
    IL_0064:  ldc.i4.0
    IL_0065:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_006a:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_006f:  stfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_parentAggregator
    IL_0074:  ldarg.0
    IL_0075:  ldfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_parentAggregator
    IL_007a:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVDesignCodeChangedEvent>()
    IL_007f:  ldarg.0
    IL_0080:  ldftn      instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::OnDefaultDesignCodeChanged(class [mscorlib]System.EventArgs)
    IL_0086:  newobj     instance void class [mscorlib]System.Action`1<class [mscorlib]System.EventArgs>::.ctor(object,
                                                                                                                native int)
    IL_008b:  callvirt   instance class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::Subscribe(class [mscorlib]System.Action`1<!0>)
    IL_0090:  pop
    IL_0091:  ldarg.0
    IL_0092:  ldfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_parentAggregator
    IL_0097:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.HostDeactivatedEvent>()
    IL_009c:  ldarg.0
    IL_009d:  ldftn      instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::OnHostDeactivated(class [mscorlib]System.EventArgs)
    IL_00a3:  newobj     instance void class [mscorlib]System.Action`1<class [mscorlib]System.EventArgs>::.ctor(object,
                                                                                                                native int)
    IL_00a8:  callvirt   instance class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::Subscribe(class [mscorlib]System.Action`1<!0>)
    IL_00ad:  pop
    IL_00ae:  ldarg.0
    IL_00af:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_00b4:  ldc.i4.0
    IL_00b5:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.InjectionMember
    IL_00ba:  call       class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::RegisterType<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost,class AspenTech.EquipmentAnalysis.PSVPlus.CxsHost>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                                                                                                                                            class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.InjectionMember[])
    IL_00bf:  pop
    IL_00c0:  ret
  } // end of method PsvCase::.ctor

  .method public newslot strict virtual final 
          instance void  Close() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::Close
    // Code size       166 (0xa6)
    .maxstack  2
    .locals init (valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0006:  ldc.i4.0
    IL_0007:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_000c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVMessageCollection>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                         class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0011:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVMessageCollection::CloseCase()
    .try
    {
      IL_0016:  ldarg.0
      IL_0017:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
      IL_001c:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::GetEnumerator()
      IL_0021:  stloc.0
      IL_0022:  br.s       IL_0030

      IL_0024:  ldloca.s   V_0
      IL_0026:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::get_Current()
      IL_002b:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::DisposeAllScenarios()
      IL_0030:  ldloca.s   V_0
      IL_0032:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::MoveNext()
      IL_0037:  brtrue.s   IL_0024

      IL_0039:  leave.s    IL_0049

    }  // end .try
    finally
    {
      IL_003b:  ldloca.s   V_0
      IL_003d:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>
      IL_0043:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0048:  endfinally
    }  // end handler
    IL_0049:  ldarg.0
    IL_004a:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_004f:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::Close()
    IL_0054:  ldarg.0
    IL_0055:  ldnull
    IL_0056:  stfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_005b:  ldarg.0
    IL_005c:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0061:  callvirt   instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer::get_Parent()
    IL_0066:  ldc.i4.0
    IL_0067:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_006c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0071:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.CloseCaseEvent>()
    IL_0076:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_007b:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::Publish(!0)
    IL_0080:  ldarg.0
    IL_0081:  ldfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_activeScreenChangedToken
    IL_0086:  brfalse.s  IL_00a5

    IL_0088:  ldarg.0
    IL_0089:  ldfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_parentAggregator
    IL_008e:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveScreenChangedEvent>()
    IL_0093:  ldarg.0
    IL_0094:  ldfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_activeScreenChangedToken
    IL_0099:  callvirt   instance void [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.EventBase::Unsubscribe(class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken)
    IL_009e:  ldarg.0
    IL_009f:  ldnull
    IL_00a0:  stfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_activeScreenChangedToken
    IL_00a5:  ret
  } // end of method PsvCase::Close

  .method public specialname instance string 
          get_Host() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_host
    IL_0006:  ret
  } // end of method PsvCase::get_Host

  .method public specialname instance void 
          set_Host(string 'value') cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_host
    IL_0007:  ret
  } // end of method PsvCase::set_Host

  .method private specialname instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry 
          get_m_ModelRegistry() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_0006:  call       class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelRegistry(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_000b:  ret
  } // end of method PsvCase::get_m_ModelRegistry

  .method public newslot specialname strict virtual final 
          instance string  get_CaseKey() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::get_CaseKey
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::m_caseKey
    IL_0006:  ret
  } // end of method PsvCase::get_CaseKey

  .method public newslot specialname strict virtual final 
          instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop 
          get_AdbTop() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::get_AdbTop
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_0006:  ret
  } // end of method PsvCase::get_AdbTop

  .method public newslot strict virtual final 
          instance void  Initialize(string caseKey,
                                    class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop adbTop,
                                    [opt] string caseFileName,
                                    [opt] bool testForMdbRecall) cil managed
  {
    .param [3] = nullref
    .param [4] = bool(true)
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::Initialize
    // Code size       278 (0x116)
    .maxstack  3
    .locals init (class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager V_0,
             bool V_1,
             string V_2,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase V_3,
             valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet V_4)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.2
    IL_0002:  stfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_0007:  call       void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::buildDictionaries()
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0012:  ldc.i4.0
    IL_0013:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0018:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_001d:  callvirt   instance class [mscorlib]System.Globalization.CultureInfo [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_SystemCulture()
    IL_0022:  call       void [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.Format::set_SystemCulture(class [mscorlib]System.Globalization.CultureInfo)
    IL_0027:  ldarg.0
    IL_0028:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_002d:  ldc.i4.0
    IL_002e:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0033:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0038:  stloc.0
    IL_0039:  ldarg.0
    IL_003a:  ldloc.0
    IL_003b:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_PSVHostType()
    IL_0040:  call       instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::set_Host(string)
    IL_0045:  ldarg.0
    IL_0046:  ldarg.1
    IL_0047:  stfld      string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::m_caseKey
    IL_004c:  ldc.i4.0
    IL_004d:  stloc.1
    IL_004e:  ldnull
    IL_004f:  stloc.2
    IL_0050:  ldarg.s    testForMdbRecall
    IL_0052:  brfalse.s  IL_008b

    IL_0054:  ldarg.0
    IL_0055:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_005a:  ldc.i4.0
    IL_005b:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0060:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                          class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0065:  stloc.3
    IL_0066:  ldarg.3
    IL_0067:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_006c:  brfalse.s  IL_0076

    IL_006e:  ldloc.3
    IL_006f:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::get_CaseFileName()
    IL_0074:  starg.s    caseFileName
    IL_0076:  ldloc.3
    IL_0077:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::get_CaseWorkingDirectory()
    IL_007c:  ldarg.3
    IL_007d:  call       string [mscorlib]System.IO.Path::Combine(string,
                                                                  string)
    IL_0082:  stloc.2
    IL_0083:  ldarg.0
    IL_0084:  ldloc.2
    IL_0085:  call       instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::NeedToRecallFromDatabase(string)
    IL_008a:  stloc.1
    IL_008b:  ldarg.0
    IL_008c:  ldarg.0
    IL_008d:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_0092:  ldc.i4.1
    IL_0093:  newobj     instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::.ctor(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop,
                                                                                                                                        bool)
    IL_0098:  stfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_009d:  ldloc.1
    IL_009e:  brfalse.s  IL_00ae

    IL_00a0:  ldarg.0
    IL_00a1:  ldarg.0
    IL_00a2:  ldloc.2
    IL_00a3:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetDatabasePath(string)
    IL_00a8:  ldarg.2
    IL_00a9:  call       instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::RecallFromDatabase(string,
                                                                                                       class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_00ae:  ldarg.0
    IL_00af:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_00b4:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_Configuration()
    IL_00b9:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessEnum`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration::get_SelectedUnitSet()
    IL_00be:  callvirt   instance valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.AbstractProcessVariable::get_SpecifierType()
    IL_00c3:  ldc.i4.1
    IL_00c4:  bne.un.s   IL_0115

    .try
    {
      IL_00c6:  ldtoken    [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet
      IL_00cb:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_00d0:  ldloc.0
      IL_00d1:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_PSVHostUnitSet()
      IL_00d6:  call       object [mscorlib]System.Enum::Parse(class [mscorlib]System.Type,
                                                               string)
      IL_00db:  unbox.any  [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet
      IL_00e0:  stloc.s    V_4
      IL_00e2:  leave.s    IL_00f3

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_00e4:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::SetProjectError(class [mscorlib]System.Exception)
      IL_00e9:  ldc.i4.0
      IL_00ea:  stloc.s    V_4
      IL_00ec:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::ClearProjectError()
      IL_00f1:  leave.s    IL_00f3

    }  // end handler
    IL_00f3:  ldarg.0
    IL_00f4:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_00f9:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_Configuration()
    IL_00fe:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessEnum`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration::get_SelectedUnitSet()
    IL_0103:  ldloc.s    V_4
    IL_0105:  newobj     instance void valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet>::.ctor(!0)
    IL_010a:  newobj     instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.UserSpecifier::.ctor()
    IL_010f:  callvirt   instance bool class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessVar`2<valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet>,valuetype [mscorlib]System.Nullable`1<int32>>::Specify(!0,
                                                                                                                                                                                                                                                                                                                                                class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier)
    IL_0114:  pop
    IL_0115:  ret
  } // end of method PsvCase::Initialize

  .method private instance string  GetDatabasePath(string caseFilePath) cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.1
    IL_0001:  callvirt   instance int32 [mscorlib]System.String::get_Length()
    IL_0006:  ldc.i4.4
    IL_0007:  bge.s      IL_0011

    IL_0009:  ldsfld     string [mscorlib]System.String::Empty
    IL_000e:  stloc.0
    IL_000f:  br.s       IL_001d

    IL_0011:  ldarg.1
    IL_0012:  ldstr      ".mdb"
    IL_0017:  call       string [mscorlib]System.IO.Path::ChangeExtension(string,
                                                                          string)
    IL_001c:  stloc.0
    IL_001d:  ldloc.0
    IL_001e:  ret
  } // end of method PsvCase::GetDatabasePath

  .method private instance bool  NeedToRecallFromDatabase(string caseFilePath) cil managed
  {
    // Code size       46 (0x2e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetDatabasePath(string)
    IL_0007:  call       bool [mscorlib]System.IO.File::Exists(string)
    IL_000c:  brfalse.s  IL_002c

    IL_000e:  ldarg.0
    IL_000f:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_0014:  call       class [mscorlib]System.Collections.Generic.IEnumerable`1<class [AspenDataShareCS]AspenTech.Adb.Acs.AcsTopRecord> [AspenDataShareCS]AspenTech.Adb.Acs.AdbTopEnums::AcsTopRecords(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_0019:  call       !!0 [System.Core]System.Linq.Enumerable::SingleOrDefault<class [AspenDataShareCS]AspenTech.Adb.Acs.AcsTopRecord>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_001e:  callvirt   instance class [AspenDataShareCS]AspenTech.Adb.Acs.AcsSafetyAnalysisCase [AspenDataShareCS]AspenTech.Adb.Acs.AcsTopRecord::get_SafetyAnalysisCase()
    IL_0023:  callvirt   instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbRecord [AspenDataShareCS]AspenTech.Adb.Acs.AcsBaseRecord::get_Record()
    IL_0028:  ldnull
    IL_0029:  ceq
    IL_002b:  ret

    IL_002c:  ldc.i4.0
    IL_002d:  ret
  } // end of method PsvCase::NeedToRecallFromDatabase

  .method private instance void  RecallFromDatabase(string dbPath,
                                                    class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop adbTop) cil managed
  {
    // Code size       41 (0x29)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldarg.0
    IL_0002:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_CaseKey()
    IL_0007:  newobj     instance void [AspenTech.EquipmentAnalysis.DataMigration]AspenTech.EquipmentAnalysis.DataMigration.DataTranscriber::.ctor(string,
                                                                                                                                                   string)
    IL_000c:  dup
    IL_000d:  ldarg.2
    IL_000e:  callvirt   instance void [AspenTech.EquipmentAnalysis.DataMigration]AspenTech.EquipmentAnalysis.DataMigration.DataTranscriber::RecallAndTranscribe(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_0013:  ldarg.0
    IL_0014:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_0019:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_ModelRegistry()
    IL_001e:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::ResetLegacyKeys()
    IL_0023:  callvirt   instance void [AspenTech.EquipmentAnalysis.DataMigration]AspenTech.EquipmentAnalysis.DataMigration.DataTranscriber::CloseAndCleanUp()
    IL_0028:  ret
  } // end of method PsvCase::RecallFromDatabase

  .method public newslot strict virtual final 
          instance void  Activate() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::Activate
    // Code size       131 (0x83)
    .maxstack  3
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_0006:  callvirt   instance bool [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::Activate()
    IL_000b:  pop
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0012:  ldc.i4.0
    IL_0013:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0018:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVMessageCollection>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                         class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_001d:  ldarg.0
    IL_001e:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_0023:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVMessageCollection::ActivateCase(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase)
    IL_0028:  ldarg.0
    IL_0029:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_002e:  ldc.i4.0
    IL_002f:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0034:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0039:  ldsfld     class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode> [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.TranslateUiStrings::SystemDesignCode
    IL_003e:  call       class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.DefaultValueDefiner [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_ActiveDefaultDefiner()
    IL_0043:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessEnum`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.DefaultValueDefiner::get_PressureProtectionRequirement_DesignCode()
    IL_0048:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessVar`2<valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode>,valuetype [mscorlib]System.Nullable`1<int32>>::get_Value()
    IL_004d:  callvirt   instance string class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode>::StringValue(valuetype [mscorlib]System.Nullable`1<!0>)
    IL_0052:  callvirt   instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::set_PSVDefaultDesignCodeString(string)
    IL_0057:  ldarg.0
    IL_0058:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_005d:  callvirt   instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer::get_Parent()
    IL_0062:  ldc.i4.0
    IL_0063:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0068:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_006d:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyCaseChangedEvent>()
    IL_0072:  ldarg.0
    IL_0073:  call       instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_AdbTop()
    IL_0078:  newobj     instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs::.ctor(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_007d:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs>::Publish(!0)
    IL_0082:  ret
  } // end of method PsvCase::Activate

  .method public newslot strict virtual final 
          instance bool  IsDirty() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::IsDirty
    // Code size       17 (0x11)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_0006:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_ModelRegistry()
    IL_000b:  callvirt   instance bool [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::get_IsDirty()
    IL_0010:  ret
  } // end of method PsvCase::IsDirty

  .method public newslot strict virtual final 
          instance void  ClearDirty() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::ClearDirty
    // Code size       18 (0x12)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_0006:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_ModelRegistry()
    IL_000b:  ldc.i4.0
    IL_000c:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::set_IsDirty(bool)
    IL_0011:  ret
  } // end of method PsvCase::ClearDirty

  .method public newslot strict virtual final 
          instance void  Load() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::Load
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method PsvCase::Load

  .method public newslot strict virtual final 
          instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          AddNewPRDSystem(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType systemType,
                          string CXSDatapath) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::AddNewPRDSystem
    // Code size       85 (0x55)
    .maxstack  5
    .locals init (class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement V_0,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_0006:  call       class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::CreateNew(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_000b:  stloc.0
    IL_000c:  ldc.i4.0
    IL_000d:  ldloc.0
    IL_000e:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::get_LegacyKey()
    IL_0013:  newobj     instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey::.ctor(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.eRecordType,
                                                                                                                                              int32)
    IL_0018:  stloc.1
    IL_0019:  ldarg.0
    IL_001a:  ldarg.1
    IL_001b:  ldloc.1
    IL_001c:  ldarg.2
    IL_001d:  ldloc.0
    IL_001e:  call       instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::UpdatePRDSystem(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType,
                                                                                                    class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,
                                                                                                    string,
                                                                                                    class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel)
    IL_0023:  ldarg.0
    IL_0024:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0029:  callvirt   instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer::get_Parent()
    IL_002e:  ldc.i4.0
    IL_002f:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0034:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0039:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEvent>()
    IL_003e:  ldloc.0
    IL_003f:  callvirt   instance object [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_DataModel()
    IL_0044:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0049:  newobj     instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEventArgs::.ctor(object)
    IL_004e:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEventArgs>::Publish(!0)
    IL_0053:  ldloc.1
    IL_0054:  ret
  } // end of method PsvCase::AddNewPRDSystem

  .method public newslot strict virtual final 
          instance void  UpdatePRDSystem(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType systemType,
                                         class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey prdSysKey,
                                         string CXSDatapath,
                                         class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel pressureProtectionRequirement) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::UpdatePRDSystem
    // Code size       282 (0x11a)
    .maxstack  5
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__31-0' V_0,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel V_1,
             string V_2,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary V_3,
             string V_4,
             string V_5)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__31-0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.2
    IL_0008:  stfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__31-0'::$VB$Local_prdSysKey
    IL_000d:  ldnull
    IL_000e:  stloc.1
    IL_000f:  ldloc.0
    IL_0010:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__31-0'::$VB$Local_prdSysKey
    IL_0015:  brfalse.s  IL_0046

    IL_0017:  ldarg.s    pressureProtectionRequirement
    IL_0019:  brtrue.s   IL_0039

    IL_001b:  ldarg.0
    IL_001c:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_m_ModelRegistry()
    IL_0021:  ldloc.0
    IL_0022:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__31-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement)
    IL_0028:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement,bool>::.ctor(object,
                                                                                                                                                                                             native int)
    IL_002d:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelsOfType<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>(class [mscorlib]System.Func`2<!!0,bool>)
    IL_0032:  call       !!0 [System.Core]System.Linq.Enumerable::SingleOrDefault<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0037:  starg.s    pressureProtectionRequirement
    IL_0039:  ldarg.0
    IL_003a:  ldloc.0
    IL_003b:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__31-0'::$VB$Local_prdSysKey
    IL_0040:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0045:  stloc.1
    IL_0046:  ldloc.1
    IL_0047:  brtrue     IL_0112

    IL_004c:  ldloc.0
    IL_004d:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__31-0'::$VB$Local_prdSysKey
    IL_0052:  ldnull
    IL_0053:  cgt.un
    IL_0055:  ldarg.s    pressureProtectionRequirement
    IL_0057:  ldnull
    IL_0058:  cgt.un
    IL_005a:  and
    IL_005b:  brfalse.s  IL_0091

    IL_005d:  ldarg.0
    IL_005e:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0063:  newobj     instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::.ctor(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer)
    IL_0068:  stloc.1
    IL_0069:  ldloc.1
    IL_006a:  ldarg.1
    IL_006b:  ldloc.0
    IL_006c:  ldflda     class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__31-0'::$VB$Local_prdSysKey
    IL_0071:  ldarg.3
    IL_0072:  ldarg.s    pressureProtectionRequirement
    IL_0074:  castclass  [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement
    IL_0079:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::Initialize(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType,
                                                                                                                                                           class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey&,
                                                                                                                                                           string,
                                                                                                                                                           class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement)
    IL_007e:  ldarg.0
    IL_007f:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
    IL_0084:  ldloc.1
    IL_0085:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::Add(!0)
    IL_008a:  ldloc.1
    IL_008b:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::RecallFixUp()
    IL_0090:  ret

    IL_0091:  ldstr      "<empty>"
    IL_0096:  stloc.2
    IL_0097:  ldarg.3
    IL_0098:  ldstr      ""
    IL_009d:  ldc.i4.0
    IL_009e:  call       int32 [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Operators::CompareString(string,
                                                                                                                      string,
                                                                                                                      bool)
    IL_00a3:  brfalse.s  IL_0101

    IL_00a5:  ldarg.0
    IL_00a6:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_00ab:  ldc.i4.0
    IL_00ac:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_00b1:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                    class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_00b6:  stloc.3
    IL_00b7:  ldloc.3
    IL_00b8:  call       bool [Microsoft.VisualBasic]Microsoft.VisualBasic.Information::IsNothing(object)
    IL_00bd:  brtrue.s   IL_0101

    IL_00bf:  ldloc.3
    IL_00c0:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
    IL_00c5:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ObjectName()
    IL_00ca:  stloc.s    V_4
    IL_00cc:  ldloc.s    V_4
    IL_00ce:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_00d3:  brtrue.s   IL_0101

    IL_00d5:  ldarg.3
    IL_00d6:  ldstr      "."
    IL_00db:  ldloc.s    V_4
    IL_00dd:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_00e2:  stloc.s    V_5
    IL_00e4:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_00e9:  ldloc.s    V_5
    IL_00eb:  ldstr      "value"
    IL_00f0:  ldnull
    IL_00f1:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::BatchGet(string,
                                                                                                                                    string,
                                                                                                                                    string)
    IL_00f6:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_00fb:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
    IL_0100:  stloc.2
    IL_0101:  ldarg.0
    IL_0102:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetNoDatabaseEntryMSG()
    IL_0107:  ldloc.2
    IL_0108:  ldc.i4.0
    IL_0109:  ldc.i4.s   16
    IL_010b:  call       valuetype [System.Windows.Forms]System.Windows.Forms.DialogResult [System.Windows.Forms]System.Windows.Forms.MessageBox::Show(string,
                                                                                                                                                       string,
                                                                                                                                                       valuetype [System.Windows.Forms]System.Windows.Forms.MessageBoxButtons,
                                                                                                                                                       valuetype [System.Windows.Forms]System.Windows.Forms.MessageBoxIcon)
    IL_0110:  pop
    IL_0111:  ret

    IL_0112:  ldloc.1
    IL_0113:  ldarg.3
    IL_0114:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::UpdateDataPath(string)
    IL_0119:  ret
  } // end of method PsvCase::UpdatePRDSystem

  .method public instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel 
          GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey prdSysKey) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__32-0' V_0)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__32-0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__32-0'::$VB$Local_prdSysKey
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
    IL_0013:  ldloc.0
    IL_0014:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__32-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel)
    IL_001a:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel,bool>::.ctor(object,
                                                                                                                                                                                                native int)
    IL_001f:  call       !!0 [System.Core]System.Linq.Enumerable::SingleOrDefault<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                                 class [mscorlib]System.Func`2<!!0,bool>)
    IL_0024:  ret
  } // end of method PsvCase::GetPRDSystemModel

  .method private newslot strict virtual final 
          instance object  IPsvCase_GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey prdSysKey) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::GetPRDSystemModel
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0007:  ret
  } // end of method PsvCase::IPsvCase_GetPRDSystemModel

  .method public instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel 
          GetPSVScenarioModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey scenarioKey) cil managed
  {
    // Code size       86 (0x56)
    .maxstack  3
    .locals init (class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel V_0,
             class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition V_1,
             class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__34-0' V_2,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel V_3)
    IL_0000:  ldarg.1
    IL_0001:  brfalse.s  IL_0052

    IL_0003:  ldarg.0
    IL_0004:  ldarg.1
    IL_0005:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
    IL_000a:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPrdConstraintsDefinition(int32)
    IL_000f:  stloc.1
    IL_0010:  ldloc.1
    IL_0011:  brfalse.s  IL_0052

    IL_0013:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__34-0'::.ctor()
    IL_0018:  stloc.2
    IL_0019:  ldloc.2
    IL_001a:  ldloc.1
    IL_001b:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition::get_ReliefScenario()
    IL_0020:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario::get_PressureProtectionRequirement()
    IL_0025:  stfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__34-0'::$VB$Local_ppr
    IL_002a:  ldarg.0
    IL_002b:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
    IL_0030:  ldloc.2
    IL_0031:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__34-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel)
    IL_0037:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel,bool>::.ctor(object,
                                                                                                                                                                                                native int)
    IL_003c:  call       !!0 [System.Core]System.Linq.Enumerable::SingleOrDefault<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                                 class [mscorlib]System.Func`2<!!0,bool>)
    IL_0041:  stloc.3
    IL_0042:  ldloc.3
    IL_0043:  brtrue.s   IL_0048

    IL_0045:  ldnull
    IL_0046:  br.s       IL_004f

    IL_0048:  ldloc.3
    IL_0049:  ldarg.1
    IL_004a:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::GetScenarioModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_004f:  stloc.0
    IL_0050:  br.s       IL_0054

    IL_0052:  ldnull
    IL_0053:  stloc.0
    IL_0054:  ldloc.0
    IL_0055:  ret
  } // end of method PsvCase::GetPSVScenarioModel

  .method private newslot strict virtual final 
          instance object  IPsvCase_GetPSVScenarioModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey scenarioKey) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::GetPSVScenarioModel
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPSVScenarioModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0007:  ret
  } // end of method PsvCase::IPsvCase_GetPSVScenarioModel

  .method family instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition 
          GetPrdConstraintsDefinition(int32 legacyKey) cil managed
  {
    // Code size       43 (0x2b)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__36-0' V_0)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__36-0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int32 AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__36-0'::$VB$Local_legacyKey
    IL_000d:  ldarg.0
    IL_000e:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_m_ModelRegistry()
    IL_0013:  ldnull
    IL_0014:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelsOfType<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition>(class [mscorlib]System.Func`2<!!0,bool>)
    IL_0019:  ldloc.0
    IL_001a:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__36-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition)
    IL_0020:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition,bool>::.ctor(object,
                                                                                                                                                                                        native int)
    IL_0025:  call       !!0 [System.Core]System.Linq.Enumerable::SingleOrDefault<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                         class [mscorlib]System.Func`2<!!0,bool>)
    IL_002a:  ret
  } // end of method PsvCase::GetPrdConstraintsDefinition

  .method public newslot strict virtual final 
          instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          AddNewScenario(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PSVKey,
                         string ScenarioName,
                         class [PSVSizingEngine]PSVSizingEngine.IPPPFluid fluid) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::AddNewScenario
    // Code size       28 (0x1c)
    .maxstack  4
    .locals init (class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0007:  stloc.0
    IL_0008:  ldloc.0
    IL_0009:  ldarg.3
    IL_000a:  ldarg.2
    IL_000b:  ldloc.0
    IL_000c:  callvirt   instance valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::get_SystemType()
    IL_0011:  callvirt   instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::CreateScenario(class [PSVSizingEngine]PSVSizingEngine.IPPPFluid,
                                                                                                                                                                                                                                                                          string,
                                                                                                                                                                                                                                                                          valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType)
    IL_0016:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel::get_DBKey()
    IL_001b:  ret
  } // end of method PsvCase::AddNewScenario

  .method public newslot strict virtual final 
          instance void  UpdateScenario(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PSVKey,
                                        class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey scenarioKey,
                                        class [PSVSizingEngine]PSVSizingEngine.IPPPFluid fluid) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::UpdateScenario
    // Code size       100 (0x64)
    .maxstack  5
    .locals init (class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel V_0,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel V_1,
             class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition V_2,
             string V_3)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0007:  stloc.0
    IL_0008:  ldloc.0
    IL_0009:  call       bool [Microsoft.VisualBasic]Microsoft.VisualBasic.Information::IsNothing(object)
    IL_000e:  brtrue.s   IL_0063

    IL_0010:  ldloc.0
    IL_0011:  ldarg.2
    IL_0012:  callvirt   instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::GetScenarioModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0017:  stloc.1
    IL_0018:  ldloc.1
    IL_0019:  brtrue.s   IL_005c

    IL_001b:  ldarg.2
    IL_001c:  brfalse.s  IL_0044

    IL_001e:  ldarg.0
    IL_001f:  ldarg.2
    IL_0020:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
    IL_0025:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPrdConstraintsDefinition(int32)
    IL_002a:  stloc.2
    IL_002b:  ldloc.2
    IL_002c:  brfalse.s  IL_0063

    IL_002e:  ldloc.0
    IL_002f:  ldarg.2
    IL_0030:  ldarg.3
    IL_0031:  ldloc.2
    IL_0032:  ldstr      ""
    IL_0037:  callvirt   instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::AddScenarioModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,
                                                                                                                                                                                                                                                                            class [PSVSizingEngine]PSVSizingEngine.IPPPFluid,
                                                                                                                                                                                                                                                                            class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition,
                                                                                                                                                                                                                                                                            string)
    IL_003c:  stloc.1
    IL_003d:  ldloc.1
    IL_003e:  callvirt   instance void class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition>::RecallFixUp()
    IL_0043:  ret

    IL_0044:  ldloc.0
    IL_0045:  callvirt   instance string [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::get_PRDSystemName()
    IL_004a:  stloc.3
    IL_004b:  ldarg.0
    IL_004c:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetNoDatabaseEntryMSG()
    IL_0051:  ldloc.3
    IL_0052:  ldc.i4.0
    IL_0053:  ldc.i4.s   16
    IL_0055:  call       valuetype [System.Windows.Forms]System.Windows.Forms.DialogResult [System.Windows.Forms]System.Windows.Forms.MessageBox::Show(string,
                                                                                                                                                       string,
                                                                                                                                                       valuetype [System.Windows.Forms]System.Windows.Forms.MessageBoxButtons,
                                                                                                                                                       valuetype [System.Windows.Forms]System.Windows.Forms.MessageBoxIcon)
    IL_005a:  pop
    IL_005b:  ret

    IL_005c:  ldloc.1
    IL_005d:  ldarg.3
    IL_005e:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel::set_PhysicalPropPkgFluid(class [PSVSizingEngine]PSVSizingEngine.IPPPFluid)
    IL_0063:  ret
  } // end of method PsvCase::UpdateScenario

  .method public newslot strict virtual final 
          instance void  DeletePRDSystem(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PRDSystemKey,
                                         int32 prdtype,
                                         string path) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::DeletePRDSystem
    // Code size       207 (0xcf)
    .maxstack  5
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__39-0' V_0,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel V_1,
             class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement V_2)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__39-0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__39-0'::$VB$Local_PRDSystemKey
    IL_000d:  ldarg.0
    IL_000e:  ldloc.0
    IL_000f:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__39-0'::$VB$Local_PRDSystemKey
    IL_0014:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0019:  stloc.1
    IL_001a:  ldloc.1
    IL_001b:  ldnull
    IL_001c:  ceq
    IL_001e:  ldarg.2
    IL_001f:  ldc.i4.m1
    IL_0020:  ceq
    IL_0022:  ldc.i4.0
    IL_0023:  ceq
    IL_0025:  and
    IL_0026:  ldarg.3
    IL_0027:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_002c:  ldc.i4.0
    IL_002d:  ceq
    IL_002f:  and
    IL_0030:  brfalse.s  IL_0075

    IL_0032:  ldloc.0
    IL_0033:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__39-0'::$VB$Local_PRDSystemKey
    IL_0038:  brfalse.s  IL_0075

    IL_003a:  ldarg.0
    IL_003b:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_m_ModelRegistry()
    IL_0040:  ldloc.0
    IL_0041:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__39-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement)
    IL_0047:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement,bool>::.ctor(object,
                                                                                                                                                                                             native int)
    IL_004c:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelsOfType<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>(class [mscorlib]System.Func`2<!!0,bool>)
    IL_0051:  call       !!0 [System.Core]System.Linq.Enumerable::SingleOrDefault<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0056:  stloc.2
    IL_0057:  ldloc.2
    IL_0058:  brfalse.s  IL_0075

    IL_005a:  ldarg.0
    IL_005b:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0060:  newobj     instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::.ctor(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer)
    IL_0065:  stloc.1
    IL_0066:  ldloc.1
    IL_0067:  ldarg.2
    IL_0068:  ldloc.0
    IL_0069:  ldflda     class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__39-0'::$VB$Local_PRDSystemKey
    IL_006e:  ldarg.3
    IL_006f:  ldloc.2
    IL_0070:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::Initialize(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType,
                                                                                                                                                           class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey&,
                                                                                                                                                           string,
                                                                                                                                                           class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement)
    IL_0075:  ldloc.1
    IL_0076:  brfalse.s  IL_00ce

    IL_0078:  ldarg.0
    IL_0079:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_007e:  callvirt   instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer::get_Parent()
    IL_0083:  ldc.i4.0
    IL_0084:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0089:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_008e:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEvent>()
    IL_0093:  ldloc.1
    IL_0094:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::get_Model()
    IL_0099:  callvirt   instance object [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_DataModel()
    IL_009e:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_00a3:  newobj     instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEventArgs::.ctor(object)
    IL_00a8:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEventArgs>::Publish(!0)
    IL_00ad:  ldloc.1
    IL_00ae:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::Delete()
    IL_00b3:  ldarg.0
    IL_00b4:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
    IL_00b9:  ldloc.1
    IL_00ba:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::Contains(!0)
    IL_00bf:  brfalse.s  IL_00ce

    IL_00c1:  ldarg.0
    IL_00c2:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
    IL_00c7:  ldloc.1
    IL_00c8:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::Remove(!0)
    IL_00cd:  pop
    IL_00ce:  ret
  } // end of method PsvCase::DeletePRDSystem

  .method public newslot strict virtual final 
          instance void  DeleteScenario(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey scenarioKey,
                                        [opt] class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PSVKey) cil managed
  {
    .param [2] = nullref
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::DeleteScenario
    // Code size       81 (0x51)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__40-0' V_0,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel V_1,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel V_2)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__40-0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldarg.1
    IL_0009:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
    IL_000e:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPrdConstraintsDefinition(int32)
    IL_0013:  stfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__40-0'::$VB$Local_prdConstraints
    IL_0018:  ldarg.2
    IL_0019:  brfalse.s  IL_0025

    IL_001b:  ldarg.0
    IL_001c:  ldarg.2
    IL_001d:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0022:  stloc.1
    IL_0023:  br.s       IL_003d

    IL_0025:  ldarg.0
    IL_0026:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
    IL_002b:  ldloc.0
    IL_002c:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__40-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel)
    IL_0032:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel,bool>::.ctor(object,
                                                                                                                                                                                                native int)
    IL_0037:  call       !!0 [System.Core]System.Linq.Enumerable::SingleOrDefault<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                                 class [mscorlib]System.Func`2<!!0,bool>)
    IL_003c:  stloc.1
    IL_003d:  ldloc.1
    IL_003e:  brfalse.s  IL_0050

    IL_0040:  ldloc.1
    IL_0041:  ldarg.1
    IL_0042:  callvirt   instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::GetScenarioModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0047:  stloc.2
    IL_0048:  ldloc.1
    IL_0049:  ldloca.s   V_2
    IL_004b:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::DeleteScenario(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel&)
    IL_0050:  ret
  } // end of method PsvCase::DeleteScenario

  .method public newslot strict virtual final 
          instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          AddNewStorageTank(string CXSDatapath,
                            class [PSVSizingEngine]PSVSizingEngine.IPPPFluid fluid) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::AddNewStorageTank
    // Code size       85 (0x55)
    .maxstack  5
    .locals init (class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank V_0,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_0006:  call       class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank::CreateNew(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_000b:  stloc.0
    IL_000c:  ldc.i4.1
    IL_000d:  ldloc.0
    IL_000e:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank::get_LegacyKey()
    IL_0013:  newobj     instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey::.ctor(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.eRecordType,
                                                                                                                                              int32)
    IL_0018:  stloc.1
    IL_0019:  ldarg.0
    IL_001a:  ldloc.1
    IL_001b:  ldarg.1
    IL_001c:  ldarg.2
    IL_001d:  ldloc.0
    IL_001e:  call       instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::UpdateStorageTank(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,
                                                                                                      string,
                                                                                                      class [PSVSizingEngine]PSVSizingEngine.IPPPFluid,
                                                                                                      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel)
    IL_0023:  ldarg.0
    IL_0024:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0029:  callvirt   instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer::get_Parent()
    IL_002e:  ldc.i4.0
    IL_002f:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0034:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0039:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEvent>()
    IL_003e:  ldloc.0
    IL_003f:  callvirt   instance object [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_DataModel()
    IL_0044:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0049:  newobj     instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEventArgs::.ctor(object)
    IL_004e:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEventArgs>::Publish(!0)
    IL_0053:  ldloc.1
    IL_0054:  ret
  } // end of method PsvCase::AddNewStorageTank

  .method public newslot strict virtual final 
          instance void  UpdateStorageTank(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey tankKey,
                                           string CXSDatapath,
                                           class [PSVSizingEngine]PSVSizingEngine.IPPPFluid fluid,
                                           class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel storageTank) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::UpdateStorageTank
    // Code size       169 (0xa9)
    .maxstack  6
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__42-0' V_0,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel V_1)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__42-0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__42-0'::$VB$Local_tankKey
    IL_000d:  ldnull
    IL_000e:  stloc.1
    IL_000f:  ldloc.0
    IL_0010:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__42-0'::$VB$Local_tankKey
    IL_0015:  brfalse.s  IL_004b

    IL_0017:  ldarg.s    storageTank
    IL_0019:  call       bool [Microsoft.VisualBasic]Microsoft.VisualBasic.Information::IsNothing(object)
    IL_001e:  brfalse.s  IL_003e

    IL_0020:  ldarg.0
    IL_0021:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_m_ModelRegistry()
    IL_0026:  ldloc.0
    IL_0027:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__42-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank)
    IL_002d:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank,bool>::.ctor(object,
                                                                                                                                                                           native int)
    IL_0032:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelsOfType<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank>(class [mscorlib]System.Func`2<!!0,bool>)
    IL_0037:  call       !!0 [System.Core]System.Linq.Enumerable::SingleOrDefault<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_003c:  starg.s    storageTank
    IL_003e:  ldarg.0
    IL_003f:  ldloc.0
    IL_0040:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__42-0'::$VB$Local_tankKey
    IL_0045:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetStorageTankModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_004a:  stloc.1
    IL_004b:  ldloc.1
    IL_004c:  brtrue.s   IL_00a1

    IL_004e:  ldloc.0
    IL_004f:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__42-0'::$VB$Local_tankKey
    IL_0054:  ldnull
    IL_0055:  cgt.un
    IL_0057:  ldarg.s    storageTank
    IL_0059:  call       bool [Microsoft.VisualBasic]Microsoft.VisualBasic.Information::IsNothing(object)
    IL_005e:  ldc.i4.0
    IL_005f:  ceq
    IL_0061:  and
    IL_0062:  brfalse.s  IL_00a8

    IL_0064:  ldarg.0
    IL_0065:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_006a:  newobj     instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel::.ctor(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer)
    IL_006f:  stloc.1
    IL_0070:  ldloc.1
    IL_0071:  ldloc.0
    IL_0072:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__42-0'::$VB$Local_tankKey
    IL_0077:  ldarg.2
    IL_0078:  ldnull
    IL_0079:  ldarg.3
    IL_007a:  ldarg.s    storageTank
    IL_007c:  castclass  [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank
    IL_0081:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel::Initialize(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,
                                                                                                                                                      string,
                                                                                                                                                      class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.IBaseModel,
                                                                                                                                                      class [PSVSizingEngine]PSVSizingEngine.IPPPFluid,
                                                                                                                                                      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank)
    IL_0086:  ldarg.0
    IL_0087:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myStorageTankModels
    IL_008c:  ldloc.1
    IL_008d:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>::Add(!0)
    IL_0092:  ldloc.1
    IL_0093:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel::RecallFixUp()
    IL_0098:  ldloc.1
    IL_0099:  ldnull
    IL_009a:  ldc.i4.1
    IL_009b:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel::AutoRunCalculations(string,
                                                                                                                                                               bool)
    IL_00a0:  ret

    IL_00a1:  ldloc.1
    IL_00a2:  ldarg.3
    IL_00a3:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel::set_PhysicalPropPkgFluid(class [PSVSizingEngine]PSVSizingEngine.IPPPFluid)
    IL_00a8:  ret
  } // end of method PsvCase::UpdateStorageTank

  .method public instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel 
          GetStorageTankModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey tankKey) cil managed
  {
    // Code size       40 (0x28)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__43-0' V_0,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel V_1,
             valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> V_2,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel V_3)
    IL_0000:  ldloc.0
    IL_0001:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__43-0'::.ctor(class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__43-0')
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  ldarg.1
    IL_0009:  stfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__43-0'::$VB$Local_tankKey
    IL_000e:  ldarg.0
    IL_000f:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myStorageTankModels
    IL_0014:  ldloc.0
    IL_0015:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__43-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel)
    IL_001b:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel,bool>::.ctor(object,
                                                                                                                                                                                           native int)
    IL_0020:  call       !!0 [System.Core]System.Linq.Enumerable::SingleOrDefault<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                            class [mscorlib]System.Func`2<!!0,bool>)
    IL_0025:  stloc.1
    IL_0026:  ldloc.1
    IL_0027:  ret
  } // end of method PsvCase::GetStorageTankModel

  .method private newslot strict virtual final 
          instance object  IPsvCase_GetStorageTankModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey tankKey) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::GetStorageTankModel
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetStorageTankModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0007:  ret
  } // end of method PsvCase::IPsvCase_GetStorageTankModel

  .method public newslot strict virtual final 
          instance object  GetAllTankModels() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::GetAllTankModels
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myStorageTankModels
    IL_0006:  ret
  } // end of method PsvCase::GetAllTankModels

  .method public newslot strict virtual final 
          instance void  DeleteStorageTank(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey tankKey) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::DeleteStorageTank
    // Code size       84 (0x54)
    .maxstack  2
    .locals init (class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetStorageTankModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0007:  stloc.0
    IL_0008:  ldloc.0
    IL_0009:  brfalse.s  IL_0053

    IL_000b:  ldarg.0
    IL_000c:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0011:  callvirt   instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer::get_Parent()
    IL_0016:  ldc.i4.0
    IL_0017:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_001c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0021:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEvent>()
    IL_0026:  ldloc.0
    IL_0027:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank>::get_Model()
    IL_002c:  callvirt   instance object [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_DataModel()
    IL_0031:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0036:  newobj     instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEventArgs::.ctor(object)
    IL_003b:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEventArgs>::Publish(!0)
    IL_0040:  ldarg.0
    IL_0041:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myStorageTankModels
    IL_0046:  ldloc.0
    IL_0047:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>::Remove(!0)
    IL_004c:  pop
    IL_004d:  ldloc.0
    IL_004e:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel::Delete()
    IL_0053:  ret
  } // end of method PsvCase::DeleteStorageTank

  .method public newslot strict virtual final 
          instance object  GetOrificeSelectionModel() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::GetOrificeSelectionModel
    // Code size       20 (0x14)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0006:  newobj     instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.OrificeSizeSettingModel::.ctor(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer)
    IL_000b:  dup
    IL_000c:  ldnull
    IL_000d:  ldnull
    IL_000e:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.OrificeSizeSettingModel::Initialize(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.IBaseModel,
                                                                                                                                                                    class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0013:  ret
  } // end of method PsvCase::GetOrificeSelectionModel

  .method public newslot strict virtual final 
          instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseUserControl 
          GetUserControl(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlID,
                         class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey key) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::GetUserControl
    // Code size       395 (0x18b)
    .maxstack  2
    .locals init (class [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.BaseUserControl V_0,
             valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs V_1,
             string V_2,
             string V_3,
             string V_4,
             string V_5,
             string V_6,
             string V_7,
             string V_8,
             string V_9)
    IL_0000:  ldarg.1
    IL_0001:  stloc.1
    IL_0002:  ldloc.1
    IL_0003:  ldc.i4.s   17
    IL_0005:  sub
    IL_0006:  switch     ( 
                          IL_0076,
                          IL_0166,
                          IL_00cb,
                          IL_0166,
                          IL_003c,
                          IL_00b4,
                          IL_0166,
                          IL_0166,
                          IL_011a,
                          IL_0106,
                          IL_0152)
    IL_0037:  br         IL_0166

    IL_003c:  ldarg.0
    IL_003d:  ldarg.2
    IL_003e:  call       instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::RecordExists(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0043:  brfalse.s  IL_005c

    IL_0045:  ldarg.0
    IL_0046:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_004b:  ldc.i4.0
    IL_004c:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0051:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.PRDSummary>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                   class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0056:  stloc.0
    IL_0057:  br         IL_0178

    IL_005c:  call       string [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.FormResource::get_title_PageNoDisplay()
    IL_0061:  stloc.2
    IL_0062:  ldarg.0
    IL_0063:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetNoDatabaseEntryMSG()
    IL_0068:  stloc.3
    IL_0069:  ldloc.2
    IL_006a:  ldloc.3
    IL_006b:  newobj     instance void [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.ErrorControl::.ctor(string,
                                                                                                                                                        string)
    IL_0070:  stloc.0
    IL_0071:  br         IL_0178

    IL_0076:  ldarg.0
    IL_0077:  ldarg.2
    IL_0078:  call       instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::RecordExists(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_007d:  brfalse.s  IL_0096

    IL_007f:  ldarg.0
    IL_0080:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0085:  ldc.i4.0
    IL_0086:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_008b:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.PSVScenarioControl>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                           class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0090:  stloc.0
    IL_0091:  br         IL_0178

    IL_0096:  call       string [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.FormResource::get_title_PageNoDisplay()
    IL_009b:  stloc.s    V_4
    IL_009d:  ldarg.0
    IL_009e:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetNoDatabaseEntryMSG()
    IL_00a3:  stloc.s    V_5
    IL_00a5:  ldloc.s    V_4
    IL_00a7:  ldloc.s    V_5
    IL_00a9:  newobj     instance void [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.ErrorControl::.ctor(string,
                                                                                                                                                        string)
    IL_00ae:  stloc.0
    IL_00af:  br         IL_0178

    IL_00b4:  ldarg.0
    IL_00b5:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_00ba:  ldc.i4.0
    IL_00bb:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_00c0:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.OrificeSizeSettings>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                            class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_00c5:  stloc.0
    IL_00c6:  br         IL_0178

    IL_00cb:  ldarg.0
    IL_00cc:  ldarg.2
    IL_00cd:  call       instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::RecordExists(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_00d2:  brfalse.s  IL_00eb

    IL_00d4:  ldarg.0
    IL_00d5:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_00da:  ldc.i4.0
    IL_00db:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_00e0:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.PSVTank>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_00e5:  stloc.0
    IL_00e6:  br         IL_0178

    IL_00eb:  call       string [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.FormResource::get_title_PageNoDisplay()
    IL_00f0:  stloc.s    V_6
    IL_00f2:  ldarg.0
    IL_00f3:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetNoDatabaseEntryMSG()
    IL_00f8:  stloc.s    V_7
    IL_00fa:  ldloc.s    V_6
    IL_00fc:  ldloc.s    V_7
    IL_00fe:  newobj     instance void [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.ErrorControl::.ctor(string,
                                                                                                                                                        string)
    IL_0103:  stloc.0
    IL_0104:  br.s       IL_0178

    IL_0106:  ldarg.0
    IL_0107:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_010c:  ldc.i4.0
    IL_010d:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0112:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.PSVTankManager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                       class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0117:  stloc.0
    IL_0118:  br.s       IL_0178

    IL_011a:  ldarg.0
    IL_011b:  ldarg.2
    IL_011c:  call       instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::RecordExists(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0121:  brfalse.s  IL_0137

    IL_0123:  ldarg.0
    IL_0124:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0129:  ldc.i4.0
    IL_012a:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_012f:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.ValveName>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                  class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0134:  stloc.0
    IL_0135:  br.s       IL_0178

    IL_0137:  call       string [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.FormResource::get_title_PageNoDisplay()
    IL_013c:  stloc.s    V_8
    IL_013e:  ldarg.0
    IL_013f:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetNoDatabaseEntryMSG()
    IL_0144:  stloc.s    V_9
    IL_0146:  ldloc.s    V_8
    IL_0148:  ldloc.s    V_9
    IL_014a:  newobj     instance void [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.ErrorControl::.ctor(string,
                                                                                                                                                        string)
    IL_014f:  stloc.0
    IL_0150:  br.s       IL_0178

    IL_0152:  ldarg.0
    IL_0153:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0158:  ldc.i4.0
    IL_0159:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_015e:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.PreferencesManager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                           class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0163:  stloc.0
    IL_0164:  br.s       IL_0178

    IL_0166:  ldarg.0
    IL_0167:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_016c:  ldc.i4.0
    IL_016d:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0172:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.BaseUserControl>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                        class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0177:  stloc.0
    IL_0178:  ldarg.2
    IL_0179:  brfalse.s  IL_0182

    IL_017b:  ldloc.0
    IL_017c:  ldarg.2
    IL_017d:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.BaseUserControl::set_ModelKey(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0182:  ldloc.0
    IL_0183:  ldarg.0
    IL_0184:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVControlLibrary]AspenTech.EquipmentAnalysis.PSVControlLibrary.BaseUserControl::set_PSVCase(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase)
    IL_0189:  ldloc.0
    IL_018a:  ret
  } // end of method PsvCase::GetUserControl

  .method public newslot strict virtual final 
          instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          DuplicateScenario(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey scenarioKey) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::DuplicateScenario
    // Code size       61 (0x3d)
    .maxstack  4
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__49-0' V_0)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__49-0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldarg.1
    IL_0009:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPSVScenarioModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_000e:  stfld      class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__49-0'::$VB$Local_oldScenario
    IL_0013:  ldarg.0
    IL_0014:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
    IL_0019:  ldloc.0
    IL_001a:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__49-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel)
    IL_0020:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel,bool>::.ctor(object,
                                                                                                                                                                                                native int)
    IL_0025:  call       !!0 [System.Core]System.Linq.Enumerable::Single<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                        class [mscorlib]System.Func`2<!!0,bool>)
    IL_002a:  ldloc.0
    IL_002b:  ldfld      class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__49-0'::$VB$Local_oldScenario
    IL_0030:  ldnull
    IL_0031:  ldnull
    IL_0032:  callvirt   instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::DuplicateScenario(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel,
                                                                                                                                                                                                                                                                             string,
                                                                                                                                                                                                                                                                             string)
    IL_0037:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel::get_DBKey()
    IL_003c:  ret
  } // end of method PsvCase::DuplicateScenario

  .method public newslot strict virtual final 
          instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          DuplicatePRDSystem(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType systemType,
                             string CXSDatapath,
                             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PRDSystemKey) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::DuplicatePRDSystem
    // Code size       37 (0x25)
    .maxstack  3
    .locals init (class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel V_0,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey V_1,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.3
    IL_0002:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0007:  stloc.0
    IL_0008:  ldarg.0
    IL_0009:  ldarg.1
    IL_000a:  ldarg.2
    IL_000b:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::AddNewPRDSystem(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType,
                                                                                                                                                                                                     string)
    IL_0010:  stloc.1
    IL_0011:  ldarg.0
    IL_0012:  ldloc.1
    IL_0013:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0018:  stloc.2
    IL_0019:  ldloc.2
    IL_001a:  brfalse.s  IL_0023

    IL_001c:  ldloc.2
    IL_001d:  ldloc.0
    IL_001e:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::CopyFrom(class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.IBaseModel)
    IL_0023:  ldloc.1
    IL_0024:  ret
  } // end of method PsvCase::DuplicatePRDSystem

  .method public newslot strict virtual final 
          instance void  EnterEnvironment([opt] class [mscorlib]System.Collections.Generic.IEnumerable`1<valuetype [mscorlib]System.ValueTuple`2<string,string>> psvsToBeDeleted) cil managed
  {
    .param [1] = nullref
    .custom instance void [mscorlib]System.Runtime.CompilerServices.TupleElementNamesAttribute::.ctor(string[]) = ( 01 00 02 00 00 00 04 70 61 74 68 04 6E 61 6D 65   // .......path.name
                                                                                                                    00 00 ) 
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::EnterEnvironment
    // Code size       625 (0x271)
    .maxstack  5
    .locals init (class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey> V_0,
             class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey> V_1,
             class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey[]> V_2,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands V_3,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<valuetype [mscorlib]System.ValueTuple`2<string,string>> V_4,
             valuetype [mscorlib]System.ValueTuple`2<string,string> V_5,
             valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> V_6,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel V_7,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel> V_8,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel V_9,
             valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey[]> V_10,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey[] V_11,
             valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey> V_12,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey V_13,
             valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> V_14)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0006:  ldc.i4.0
    IL_0007:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_000c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0011:  dup
    IL_0012:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_ApplicationNameWithVersion()
    IL_0017:  call       void [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.ExtractDefaultPrefsFile::Extract(string)
    IL_001c:  ldsfld     class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode> [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.TranslateUiStrings::SystemDesignCode
    IL_0021:  call       class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.DefaultValueDefiner [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_ActiveDefaultDefiner()
    IL_0026:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessEnum`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.DefaultValueDefiner::get_PressureProtectionRequirement_DesignCode()
    IL_002b:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessVar`2<valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode>,valuetype [mscorlib]System.Nullable`1<int32>>::get_Value()
    IL_0030:  callvirt   instance string class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode>::StringValue(valuetype [mscorlib]System.Nullable`1<!0>)
    IL_0035:  callvirt   instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::set_PSVDefaultDesignCodeString(string)
    IL_003a:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_003f:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::PurgeDataCache()
    IL_0044:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_0049:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::UpdateDataCache()
    IL_004e:  ldarg.1
    IL_004f:  brfalse.s  IL_00ac

    IL_0051:  ldarg.0
    IL_0052:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0057:  ldc.i4.0
    IL_0058:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_005d:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                    class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0062:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVCommands()
    IL_0067:  stloc.3
    .try
    {
      IL_0068:  ldarg.1
      IL_0069:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<valuetype [mscorlib]System.ValueTuple`2<string,string>>::GetEnumerator()
      IL_006e:  stloc.s    V_4
      IL_0070:  br.s       IL_0095

      IL_0072:  ldloc.s    V_4
      IL_0074:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<valuetype [mscorlib]System.ValueTuple`2<string,string>>::get_Current()
      IL_0079:  stloc.s    V_5
      IL_007b:  ldloc.3
      IL_007c:  ldloc.s    V_5
      IL_007e:  ldfld      !0 valuetype [mscorlib]System.ValueTuple`2<string,string>::Item1
      IL_0083:  ldloc.s    V_5
      IL_0085:  ldfld      !1 valuetype [mscorlib]System.ValueTuple`2<string,string>::Item2
      IL_008a:  ldarg.0
      IL_008b:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
      IL_0090:  callvirt   instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands::DeletePSVFromCaseAndWait(string,
                                                                                                                                                                          string,
                                                                                                                                                                          class [mscorlib]System.Collections.IList)
      IL_0095:  ldloc.s    V_4
      IL_0097:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_009c:  brtrue.s   IL_0072

      IL_009e:  leave.s    IL_00ac

    }  // end .try
    finally
    {
      IL_00a0:  ldloc.s    V_4
      IL_00a2:  brfalse.s  IL_00ab

      IL_00a4:  ldloc.s    V_4
      IL_00a6:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_00ab:  endfinally
    }  // end handler
    IL_00ac:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>::.ctor()
    IL_00b1:  stloc.0
    IL_00b2:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>::.ctor()
    IL_00b7:  stloc.1
    IL_00b8:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey[]>::.ctor()
    IL_00bd:  stloc.2
    .try
    {
      IL_00be:  ldarg.0
      IL_00bf:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
      IL_00c4:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::GetEnumerator()
      IL_00c9:  stloc.s    V_6
      IL_00cb:  br         IL_01c0

      IL_00d0:  ldloca.s   V_6
      IL_00d2:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::get_Current()
      IL_00d7:  stloc.s    V_7
      IL_00d9:  ldloc.s    V_7
      IL_00db:  callvirt   instance bool class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::DataIsConsistent()
      IL_00e0:  brtrue.s   IL_0117

      IL_00e2:  ldarg.0
      IL_00e3:  ldfld      bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myWarningIssued
      IL_00e8:  brtrue.s   IL_0105

      IL_00ea:  ldarg.0
      IL_00eb:  ldc.i4.1
      IL_00ec:  stfld      bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myWarningIssued
      IL_00f1:  ldarg.0
      IL_00f2:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetNoDatabaseEntryMSG()
      IL_00f7:  call       string [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.FormResource::get_Title_EAModule()
      IL_00fc:  ldc.i4.0
      IL_00fd:  ldc.i4.s   16
      IL_00ff:  call       valuetype [System.Windows.Forms]System.Windows.Forms.DialogResult [System.Windows.Forms]System.Windows.Forms.MessageBox::Show(string,
                                                                                                                                                         string,
                                                                                                                                                         valuetype [System.Windows.Forms]System.Windows.Forms.MessageBoxButtons,
                                                                                                                                                         valuetype [System.Windows.Forms]System.Windows.Forms.MessageBoxIcon)
      IL_0104:  pop
      IL_0105:  ldloc.1
      IL_0106:  ldloc.s    V_7
      IL_0108:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::get_DBKey()
      IL_010d:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>::Add(!0)
      IL_0112:  br         IL_01c0

      IL_0117:  ldloc.2
      IL_0118:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey[]>::Clear()
      .try
      {
        IL_011d:  ldloc.s    V_7
        IL_011f:  callvirt   instance class [mscorlib]System.Collections.Generic.IList`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel> [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::get_OverallScenarioModels()
        IL_0124:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel>::GetEnumerator()
        IL_0129:  stloc.s    V_8
        IL_012b:  br.s       IL_016e

        IL_012d:  ldloc.s    V_8
        IL_012f:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel>::get_Current()
        IL_0134:  stloc.s    V_9
        IL_0136:  ldloc.s    V_9
        IL_0138:  callvirt   instance bool [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel::DataIsConsistent()
        IL_013d:  brtrue.s   IL_0161

        IL_013f:  ldloc.2
        IL_0140:  ldc.i4.2
        IL_0141:  newarr     [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey
        IL_0146:  dup
        IL_0147:  ldc.i4.0
        IL_0148:  ldloc.s    V_9
        IL_014a:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel::get_DBKey()
        IL_014f:  stelem.ref
        IL_0150:  dup
        IL_0151:  ldc.i4.1
        IL_0152:  ldloc.s    V_7
        IL_0154:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::get_DBKey()
        IL_0159:  stelem.ref
        IL_015a:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey[]>::Add(!0)
        IL_015f:  br.s       IL_016e

        IL_0161:  ldloc.0
        IL_0162:  ldloc.s    V_9
        IL_0164:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel::get_DBKey()
        IL_0169:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>::Add(!0)
        IL_016e:  ldloc.s    V_8
        IL_0170:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
        IL_0175:  brtrue.s   IL_012d

        IL_0177:  leave.s    IL_0185

      }  // end .try
      finally
      {
        IL_0179:  ldloc.s    V_8
        IL_017b:  brfalse.s  IL_0184

        IL_017d:  ldloc.s    V_8
        IL_017f:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
        IL_0184:  endfinally
      }  // end handler
      IL_0185:  nop
      .try
      {
        IL_0186:  ldloc.2
        IL_0187:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey[]>::GetEnumerator()
        IL_018c:  stloc.s    V_10
        IL_018e:  br.s       IL_01a7

        IL_0190:  ldloca.s   V_10
        IL_0192:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey[]>::get_Current()
        IL_0197:  stloc.s    V_11
        IL_0199:  ldarg.0
        IL_019a:  ldloc.s    V_11
        IL_019c:  ldc.i4.1
        IL_019d:  ldelem.ref
        IL_019e:  ldloc.s    V_11
        IL_01a0:  ldc.i4.2
        IL_01a1:  ldelem.ref
        IL_01a2:  call       instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::DeleteScenario(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,
                                                                                                       class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
        IL_01a7:  ldloca.s   V_10
        IL_01a9:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey[]>::MoveNext()
        IL_01ae:  brtrue.s   IL_0190

        IL_01b0:  leave.s    IL_01c0

      }  // end .try
      finally
      {
        IL_01b2:  ldloca.s   V_10
        IL_01b4:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey[]>
        IL_01ba:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
        IL_01bf:  endfinally
      }  // end handler
      IL_01c0:  ldloca.s   V_6
      IL_01c2:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::MoveNext()
      IL_01c7:  brtrue     IL_00d0

      IL_01cc:  leave.s    IL_01dc

    }  // end .try
    finally
    {
      IL_01ce:  ldloca.s   V_6
      IL_01d0:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>
      IL_01d6:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_01db:  endfinally
    }  // end handler
    IL_01dc:  nop
    .try
    {
      IL_01dd:  ldloc.1
      IL_01de:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>::GetEnumerator()
      IL_01e3:  stloc.s    V_12
      IL_01e5:  br.s       IL_01fa

      IL_01e7:  ldloca.s   V_12
      IL_01e9:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>::get_Current()
      IL_01ee:  stloc.s    V_13
      IL_01f0:  ldarg.0
      IL_01f1:  ldloc.s    V_13
      IL_01f3:  ldc.i4.m1
      IL_01f4:  ldnull
      IL_01f5:  call       instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::DeletePRDSystem(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,
                                                                                                      int32,
                                                                                                      string)
      IL_01fa:  ldloca.s   V_12
      IL_01fc:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>::MoveNext()
      IL_0201:  brtrue.s   IL_01e7

      IL_0203:  leave.s    IL_0213

    }  // end .try
    finally
    {
      IL_0205:  ldloca.s   V_12
      IL_0207:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>
      IL_020d:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0212:  endfinally
    }  // end handler
    IL_0213:  nop
    .try
    {
      IL_0214:  ldarg.0
      IL_0215:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myStorageTankModels
      IL_021a:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>::GetEnumerator()
      IL_021f:  stloc.s    V_14
      IL_0221:  br.s       IL_022f

      IL_0223:  ldloca.s   V_14
      IL_0225:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>::get_Current()
      IL_022a:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel::ValidatePropertyPackage()
      IL_022f:  ldloca.s   V_14
      IL_0231:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>::MoveNext()
      IL_0236:  brtrue.s   IL_0223

      IL_0238:  leave.s    IL_0248

    }  // end .try
    finally
    {
      IL_023a:  ldloca.s   V_14
      IL_023c:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>
      IL_0242:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0247:  endfinally
    }  // end handler
    IL_0248:  ldarg.0
    IL_0249:  call       instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::Deactivate()
    IL_024e:  ldarg.0
    IL_024f:  ldarg.0
    IL_0250:  ldfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_parentAggregator
    IL_0255:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveScreenChangedEvent>()
    IL_025a:  ldarg.0
    IL_025b:  ldftn      instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::OnActiveScreenChanged(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ActiveScreenChangedEventArgs)
    IL_0261:  newobj     instance void class [mscorlib]System.Action`1<class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ActiveScreenChangedEventArgs>::.ctor(object,
                                                                                                                                                                                                              native int)
    IL_0266:  callvirt   instance class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ActiveScreenChangedEventArgs>::Subscribe(class [mscorlib]System.Action`1<!0>)
    IL_026b:  stfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_activeScreenChangedToken
    IL_0270:  ret
  } // end of method PsvCase::EnterEnvironment

  .method public newslot strict virtual final 
          instance void  Deactivate() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::Deactivate
    // Code size       38 (0x26)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_activeScreenChangedToken
    IL_0006:  brfalse.s  IL_0025

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_parentAggregator
    IL_000e:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveScreenChangedEvent>()
    IL_0013:  ldarg.0
    IL_0014:  ldfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_activeScreenChangedToken
    IL_0019:  callvirt   instance void [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.EventBase::Unsubscribe(class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken)
    IL_001e:  ldarg.0
    IL_001f:  ldnull
    IL_0020:  stfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.SubscriptionToken AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_activeScreenChangedToken
    IL_0025:  ret
  } // end of method PsvCase::Deactivate

  .method public newslot strict virtual final 
          instance void  ExitEnvironment() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::ExitEnvironment
    // Code size       95 (0x5f)
    .maxstack  2
    .locals init (valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> V_0)
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
      IL_0006:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::GetEnumerator()
      IL_000b:  stloc.0
      IL_000c:  br.s       IL_001a

      IL_000e:  ldloca.s   V_0
      IL_0010:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::get_Current()
      IL_0015:  callvirt   instance void class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::TellSimulatorForgetMessages()
      IL_001a:  ldloca.s   V_0
      IL_001c:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::MoveNext()
      IL_0021:  brtrue.s   IL_000e

      IL_0023:  leave.s    IL_0033

    }  // end .try
    finally
    {
      IL_0025:  ldloca.s   V_0
      IL_0027:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>
      IL_002d:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0032:  endfinally
    }  // end handler
    IL_0033:  ldarg.0
    IL_0034:  call       instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::Deactivate()
    IL_0039:  ldarg.0
    IL_003a:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_003f:  callvirt   instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer::get_Parent()
    IL_0044:  ldc.i4.0
    IL_0045:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_004a:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_004f:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.ExitSafetyEnvironmentEvent>()
    IL_0054:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0059:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::Publish(!0)
    IL_005e:  ret
  } // end of method PsvCase::ExitEnvironment

  .method public newslot strict virtual final 
          instance void  OnAllFlowsheetItemsAdded() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::OnAllFlowsheetItemsAdded
    // Code size       428 (0x1ac)
    .maxstack  2
    .locals init (class [System.Core]System.Collections.Generic.HashSet`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement> V_0,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement> V_1,
             class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement V_2,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey V_3,
             valuetype [System.Core]System.Collections.Generic.HashSet`1/Enumerator<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement> V_4,
             valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> V_5,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel V_6,
             class [System.Core]System.Collections.Generic.HashSet`1<valuetype [mscorlib]System.Guid> V_7,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel> V_8,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel V_9,
             int32 V_10,
             class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario V_11)
    IL_0000:  newobj     instance void class [System.Core]System.Collections.Generic.HashSet`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::.ctor()
    IL_0005:  stloc.0
    .try
    {
      IL_0006:  ldarg.0
      IL_0007:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
      IL_000c:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_ModelRegistry()
      IL_0011:  ldnull
      IL_0012:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelsOfType<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>(class [mscorlib]System.Func`2<!!0,bool>)
      IL_0017:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::GetEnumerator()
      IL_001c:  stloc.1
      IL_001d:  br.s       IL_0044

      IL_001f:  ldloc.1
      IL_0020:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::get_Current()
      IL_0025:  stloc.2
      IL_0026:  ldc.i4.0
      IL_0027:  ldloc.2
      IL_0028:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::get_LegacyKey()
      IL_002d:  newobj     instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey::.ctor(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.eRecordType,
                                                                                                                                                   int32)
      IL_0032:  stloc.3
      IL_0033:  ldarg.0
      IL_0034:  ldloc.3
      IL_0035:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
      IL_003a:  brtrue.s   IL_0044

      IL_003c:  ldloc.0
      IL_003d:  ldloc.2
      IL_003e:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::Add(!0)
      IL_0043:  pop
      IL_0044:  ldloc.1
      IL_0045:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_004a:  brtrue.s   IL_001f

      IL_004c:  leave.s    IL_0058

    }  // end .try
    finally
    {
      IL_004e:  ldloc.1
      IL_004f:  brfalse.s  IL_0057

      IL_0051:  ldloc.1
      IL_0052:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0057:  endfinally
    }  // end handler
    IL_0058:  nop
    .try
    {
      IL_0059:  ldloc.0
      IL_005a:  callvirt   instance valuetype [System.Core]System.Collections.Generic.HashSet`1/Enumerator<!0> class [System.Core]System.Collections.Generic.HashSet`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::GetEnumerator()
      IL_005f:  stloc.s    V_4
      IL_0061:  br.s       IL_006f

      IL_0063:  ldloca.s   V_4
      IL_0065:  call       instance !0 valuetype [System.Core]System.Collections.Generic.HashSet`1/Enumerator<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::get_Current()
      IL_006a:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.Referenceable::Delete()
      IL_006f:  ldloca.s   V_4
      IL_0071:  call       instance bool valuetype [System.Core]System.Collections.Generic.HashSet`1/Enumerator<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::MoveNext()
      IL_0076:  brtrue.s   IL_0063

      IL_0078:  leave.s    IL_0088

    }  // end .try
    finally
    {
      IL_007a:  ldloca.s   V_4
      IL_007c:  constrained. valuetype [System.Core]System.Collections.Generic.HashSet`1/Enumerator<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>
      IL_0082:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0087:  endfinally
    }  // end handler
    IL_0088:  nop
    .try
    {
      IL_0089:  ldarg.0
      IL_008a:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
      IL_008f:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::GetEnumerator()
      IL_0094:  stloc.s    V_5
      IL_0096:  br         IL_0164

      IL_009b:  ldloca.s   V_5
      IL_009d:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::get_Current()
      IL_00a2:  stloc.s    V_6
      IL_00a4:  ldloc.s    V_6
      IL_00a6:  callvirt   instance class [mscorlib]System.Collections.Generic.IList`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel> [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::get_OverallScenarioModels()
      IL_00ab:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.ICollection`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel>::get_Count()
      IL_00b0:  ldloc.s    V_6
      IL_00b2:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::get_Model()
      IL_00b7:  callvirt   instance class [mscorlib]System.Collections.Generic.IReadOnlyList`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::get_ReliefScenarios()
      IL_00bc:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.IReadOnlyCollection`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario>::get_Count()
      IL_00c1:  beq        IL_0164

      IL_00c6:  newobj     instance void class [System.Core]System.Collections.Generic.HashSet`1<valuetype [mscorlib]System.Guid>::.ctor()
      IL_00cb:  stloc.s    V_7
      .try
      {
        IL_00cd:  ldloc.s    V_6
        IL_00cf:  callvirt   instance class [mscorlib]System.Collections.Generic.IList`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel> [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::get_OverallScenarioModels()
        IL_00d4:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel>::GetEnumerator()
        IL_00d9:  stloc.s    V_8
        IL_00db:  br.s       IL_00ff

        IL_00dd:  ldloc.s    V_8
        IL_00df:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel>::get_Current()
        IL_00e4:  stloc.s    V_9
        IL_00e6:  ldloc.s    V_7
        IL_00e8:  ldloc.s    V_9
        IL_00ea:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition>::get_Model()
        IL_00ef:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition::get_ReliefScenario()
        IL_00f4:  callvirt   instance valuetype [mscorlib]System.Guid [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.BaseModel::get_Key()
        IL_00f9:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<valuetype [mscorlib]System.Guid>::Add(!0)
        IL_00fe:  pop
        IL_00ff:  ldloc.s    V_8
        IL_0101:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
        IL_0106:  brtrue.s   IL_00dd

        IL_0108:  leave.s    IL_0116

      }  // end .try
      finally
      {
        IL_010a:  ldloc.s    V_8
        IL_010c:  brfalse.s  IL_0115

        IL_010e:  ldloc.s    V_8
        IL_0110:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
        IL_0115:  endfinally
      }  // end handler
      IL_0116:  ldloc.s    V_6
      IL_0118:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::get_Model()
      IL_011d:  callvirt   instance class [mscorlib]System.Collections.Generic.IReadOnlyList`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::get_ReliefScenarios()
      IL_0122:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.IReadOnlyCollection`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario>::get_Count()
      IL_0127:  ldc.i4.1
      IL_0128:  sub.ovf
      IL_0129:  stloc.s    V_10
      IL_012b:  br.s       IL_015f

      IL_012d:  ldloc.s    V_6
      IL_012f:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::get_Model()
      IL_0134:  callvirt   instance class [mscorlib]System.Collections.Generic.IReadOnlyList`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::get_ReliefScenarios()
      IL_0139:  ldloc.s    V_10
      IL_013b:  call       !!0 [System.Core]System.Linq.Enumerable::ElementAt<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                           int32)
      IL_0140:  stloc.s    V_11
      IL_0142:  ldloc.s    V_7
      IL_0144:  ldloc.s    V_11
      IL_0146:  callvirt   instance valuetype [mscorlib]System.Guid [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.BaseModel::get_Key()
      IL_014b:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<valuetype [mscorlib]System.Guid>::Contains(!0)
      IL_0150:  brtrue.s   IL_0159

      IL_0152:  ldloc.s    V_11
      IL_0154:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.Referenceable::Delete()
      IL_0159:  ldloc.s    V_10
      IL_015b:  ldc.i4.m1
      IL_015c:  add.ovf
      IL_015d:  stloc.s    V_10
      IL_015f:  ldloc.s    V_10
      IL_0161:  ldc.i4.0
      IL_0162:  bge.s      IL_012d

      IL_0164:  ldloca.s   V_5
      IL_0166:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::MoveNext()
      IL_016b:  brtrue     IL_009b

      IL_0170:  leave.s    IL_0180

    }  // end .try
    finally
    {
      IL_0172:  ldloca.s   V_5
      IL_0174:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>
      IL_017a:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_017f:  endfinally
    }  // end handler
    IL_0180:  ldarg.0
    IL_0181:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0186:  callvirt   instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer::get_Parent()
    IL_018b:  ldc.i4.0
    IL_018c:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0191:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0196:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEvent>()
    IL_019b:  ldarg.0
    IL_019c:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_01a1:  newobj     instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs::.ctor(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_01a6:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs>::Publish(!0)
    IL_01ab:  ret
  } // end of method PsvCase::OnAllFlowsheetItemsAdded

  .method family instance void  UpdateStatusMessages() cil managed
  {
    // Code size       53 (0x35)
    .maxstack  1
    .locals init (valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> V_0)
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
      IL_0006:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::GetEnumerator()
      IL_000b:  stloc.0
      IL_000c:  br.s       IL_001b

      IL_000e:  ldloca.s   V_0
      IL_0010:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::get_Current()
      IL_0015:  callvirt   instance string [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::get_PRDSystemMessages()
      IL_001a:  pop
      IL_001b:  ldloca.s   V_0
      IL_001d:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::MoveNext()
      IL_0022:  brtrue.s   IL_000e

      IL_0024:  leave.s    IL_0034

    }  // end .try
    finally
    {
      IL_0026:  ldloca.s   V_0
      IL_0028:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>
      IL_002e:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0033:  endfinally
    }  // end handler
    IL_0034:  ret
  } // end of method PsvCase::UpdateStatusMessages

  .method public newslot strict virtual final 
          instance void  Calculate([opt] bool force) cil managed
  {
    .param [1] = bool(false)
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::Calculate
    // Code size       181 (0xb5)
    .maxstack  4
    .locals init (valuetype [mscorlib]System.Nullable`1<bool> V_0,
             valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> V_1,
             valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> V_2)
    IL_0000:  ldarg.1
    IL_0001:  brtrue.s   IL_0023

    IL_0003:  ldarg.0
    IL_0004:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_0009:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_Configuration()
    IL_000e:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessBool [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration::get_ShouldForceCalculate()
    IL_0013:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessVar`2<valuetype [mscorlib]System.Nullable`1<bool>,valuetype [mscorlib]System.Nullable`1<bool>>::get_Value()
    IL_0018:  stloc.0
    IL_0019:  ldloca.s   V_0
    IL_001b:  ldc.i4.1
    IL_001c:  call       instance !0 valuetype [mscorlib]System.Nullable`1<bool>::GetValueOrDefault(!0)
    IL_0021:  starg.s    force
    IL_0023:  nop
    .try
    {
      IL_0024:  ldarg.0
      IL_0025:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
      IL_002a:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::GetEnumerator()
      IL_002f:  stloc.1
      IL_0030:  br.s       IL_004f

      IL_0032:  ldloca.s   V_1
      IL_0034:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::get_Current()
      IL_0039:  dup
      IL_003a:  ldc.i4.0
      IL_003b:  ldc.i4.0
      IL_003c:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::RecallFixUpSplitScenarioModels(bool,
                                                                                                                                                                                 bool)
      IL_0041:  dup
      IL_0042:  ldc.i4.0
      IL_0043:  ldc.i4.0
      IL_0044:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::RecallFixUpSpareScenarioModels(bool,
                                                                                                                                                                                 bool)
      IL_0049:  ldarg.1
      IL_004a:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::RunCalculations(bool)
      IL_004f:  ldloca.s   V_1
      IL_0051:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::MoveNext()
      IL_0056:  brtrue.s   IL_0032

      IL_0058:  leave.s    IL_0068

    }  // end .try
    finally
    {
      IL_005a:  ldloca.s   V_1
      IL_005c:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>
      IL_0062:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0067:  endfinally
    }  // end handler
    IL_0068:  nop
    .try
    {
      IL_0069:  ldarg.0
      IL_006a:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myStorageTankModels
      IL_006f:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>::GetEnumerator()
      IL_0074:  stloc.2
      IL_0075:  br.s       IL_008b

      IL_0077:  ldloca.s   V_2
      IL_0079:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>::get_Current()
      IL_007e:  dup
      IL_007f:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel::UpdateFluidPath()
      IL_0084:  ldnull
      IL_0085:  ldc.i4.1
      IL_0086:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel::AutoRunCalculations(string,
                                                                                                                                                                 bool)
      IL_008b:  ldloca.s   V_2
      IL_008d:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>::MoveNext()
      IL_0092:  brtrue.s   IL_0077

      IL_0094:  leave.s    IL_00a4

    }  // end .try
    finally
    {
      IL_0096:  ldloca.s   V_2
      IL_0098:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel>
      IL_009e:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_00a3:  endfinally
    }  // end handler
    IL_00a4:  ldarg.0
    IL_00a5:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_00aa:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_Configuration()
    IL_00af:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration::ClearForceCalculateFlag()
    IL_00b4:  ret
  } // end of method PsvCase::Calculate

  .method public newslot strict virtual final 
          instance void  CalculateLineSizing() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::CalculateLineSizing
    // Code size       52 (0x34)
    .maxstack  1
    .locals init (valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> V_0)
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
      IL_0006:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::GetEnumerator()
      IL_000b:  stloc.0
      IL_000c:  br.s       IL_001a

      IL_000e:  ldloca.s   V_0
      IL_0010:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::get_Current()
      IL_0015:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::AutoRunLineSizing()
      IL_001a:  ldloca.s   V_0
      IL_001c:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::MoveNext()
      IL_0021:  brtrue.s   IL_000e

      IL_0023:  leave.s    IL_0033

    }  // end .try
    finally
    {
      IL_0025:  ldloca.s   V_0
      IL_0027:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>
      IL_002d:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0032:  endfinally
    }  // end handler
    IL_0033:  ret
  } // end of method PsvCase::CalculateLineSizing

  .method public newslot strict virtual final 
          instance void  ShowReport(class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey> keys,
                                    valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVReportTypeEnum 'type') cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::ShowReport
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method PsvCase::ShowReport

  .method public newslot strict virtual final 
          instance void  UpdateSelectedOrifices() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::UpdateSelectedOrifices
    // Code size       87 (0x57)
    .maxstack  2
    .locals init (valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> V_0)
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
      IL_0006:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::GetEnumerator()
      IL_000b:  stloc.0
      IL_000c:  br.s       IL_001a

      IL_000e:  ldloca.s   V_0
      IL_0010:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::get_Current()
      IL_0015:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::UpdateSelectedOrifices()
      IL_001a:  ldloca.s   V_0
      IL_001c:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::MoveNext()
      IL_0021:  brtrue.s   IL_000e

      IL_0023:  leave.s    IL_0033

    }  // end .try
    finally
    {
      IL_0025:  ldloca.s   V_0
      IL_0027:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>
      IL_002d:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0032:  endfinally
    }  // end handler
    IL_0033:  ldarg.0
    IL_0034:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0039:  call       bool [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::IsRegistered<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.OrificeSizeSettingModel>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer)
    IL_003e:  brfalse.s  IL_0056

    IL_0040:  ldarg.0
    IL_0041:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0046:  ldc.i4.0
    IL_0047:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_004c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.OrificeSizeSettingModel>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                            class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0051:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.OrificeSizeSettingModel::ResetDirty()
    IL_0056:  ret
  } // end of method PsvCase::UpdateSelectedOrifices

  .method public newslot strict virtual final 
          instance void  UpdateOverpressure() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::UpdateOverpressure
    // Code size       52 (0x34)
    .maxstack  1
    .locals init (valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> V_0)
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myPRDSystemModels
      IL_0006:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::GetEnumerator()
      IL_000b:  stloc.0
      IL_000c:  br.s       IL_001a

      IL_000e:  ldloca.s   V_0
      IL_0010:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::get_Current()
      IL_0015:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel::UpdateOverpressure()
      IL_001a:  ldloca.s   V_0
      IL_001c:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>::MoveNext()
      IL_0021:  brtrue.s   IL_000e

      IL_0023:  leave.s    IL_0033

    }  // end .try
    finally
    {
      IL_0025:  ldloca.s   V_0
      IL_0027:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel>
      IL_002d:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0032:  endfinally
    }  // end handler
    IL_0033:  ret
  } // end of method PsvCase::UpdateOverpressure

  .method public instance void  CalculateRuptureDisk() cil managed
  {
    // Code size       753 (0x2f1)
    .maxstack  8
    .locals init (object V_0,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData V_1,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_2,
             string V_3,
             object V_4)
    IL_0000:  newobj     instance void [mscorlib]System.Object::.ctor()
    IL_0005:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_000a:  stloc.0
    IL_000b:  ldloc.0
    IL_000c:  ldc.i4.2
    IL_000d:  newarr     [mscorlib]System.Object
    IL_0012:  dup
    IL_0013:  ldc.i4.0
    IL_0014:  ldc.i4.0
    IL_0015:  box        [mscorlib]System.Int32
    IL_001a:  stelem.ref
    IL_001b:  dup
    IL_001c:  ldc.i4.1
    IL_001d:  ldstr      "A9P4879R"
    IL_0022:  stelem.ref
    IL_0023:  ldnull
    IL_0024:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateIndexSet(object,
                                                                                                                         object[],
                                                                                                                         string[])
    IL_0029:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_002e:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief"
    IL_0033:  ldstr      "InsertChild"
    IL_0038:  ldc.i4.0
    IL_0039:  ldc.i4.1
    IL_003a:  newarr     [mscorlib]System.Object
    IL_003f:  dup
    IL_0040:  ldc.i4.0
    IL_0041:  ldloc.0
    IL_0042:  stelem.ref
    IL_0043:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::InvokeAction(string,
                                                                                                                                                                                                                        string,
                                                                                                                                                                                                                        bool,
                                                                                                                                                                                                                        object[])
    IL_0048:  pop
    .try
    {
      IL_0049:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::.ctor()
      IL_004e:  stloc.1
      IL_004f:  ldloc.1
      IL_0050:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.DISCHARGE_PR"
      IL_0055:  ldstr      "value"
      IL_005a:  ldnull
      IL_005b:  ldc.r8     1
      IL_0064:  box        [mscorlib]System.Double
      IL_0069:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_006e:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_0073:  ldloc.1
      IL_0074:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.SCENARIO"
      IL_0079:  ldstr      "value"
      IL_007e:  ldnull
      IL_007f:  ldstr      "FLOW-SPEC"
      IL_0084:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_0089:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_008e:  ldloc.1
      IL_008f:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.CAPACITY"
      IL_0094:  ldstr      "value"
      IL_0099:  ldnull
      IL_009a:  ldstr      "ACTUAL"
      IL_009f:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_00a4:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_00a9:  ldloc.1
      IL_00aa:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.STRM_BASIS"
      IL_00af:  ldstr      "value"
      IL_00b4:  ldnull
      IL_00b5:  ldstr      "MOLE"
      IL_00ba:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_00bf:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_00c4:  ldloc.1
      IL_00c5:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.BASIS_UFLOW"
      IL_00ca:  ldstr      "value"
      IL_00cf:  ldnull
      IL_00d0:  ldc.r8     123
      IL_00d9:  box        [mscorlib]System.Double
      IL_00de:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_00e3:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_00e8:  ldloc.1
      IL_00e9:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.STREAM"
      IL_00ee:  ldstr      "value"
      IL_00f3:  ldnull
      IL_00f4:  ldstr      "1"
      IL_00f9:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_00fe:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_0103:  ldloc.1
      IL_0104:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.STRM_COMP"
      IL_0109:  ldstr      "value"
      IL_010e:  ldnull
      IL_010f:  ldstr      "FROM-STREAM"
      IL_0114:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_0119:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_011e:  ldloc.1
      IL_011f:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.STRM_TFROM"
      IL_0124:  ldstr      "value"
      IL_0129:  ldnull
      IL_012a:  ldstr      "FROM-STREAM"
      IL_012f:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_0134:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_0139:  ldloc.1
      IL_013a:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.STRM_PFROM"
      IL_013f:  ldstr      "value"
      IL_0144:  ldnull
      IL_0145:  ldstr      "FROM-STREAM"
      IL_014a:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_014f:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_0154:  ldloc.1
      IL_0155:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.DEVICE"
      IL_015a:  ldstr      "value"
      IL_015f:  ldnull
      IL_0160:  ldstr      "PSD"
      IL_0165:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_016a:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_016f:  ldloc.1
      IL_0170:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.PSD_DIAM"
      IL_0175:  ldstr      "value"
      IL_017a:  ldnull
      IL_017b:  ldc.r8     1
      IL_0184:  box        [mscorlib]System.Double
      IL_0189:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_018e:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_0193:  ldloc.1
      IL_0194:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.PSD_CD"
      IL_0199:  ldstr      "value"
      IL_019e:  ldnull
      IL_019f:  ldc.r8     1
      IL_01a8:  box        [mscorlib]System.Double
      IL_01ad:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_01b2:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_01b7:  ldloc.1
      IL_01b8:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.PSD_SETPOINT"
      IL_01bd:  ldstr      "value"
      IL_01c2:  ldnull
      IL_01c3:  ldc.r8     2
      IL_01cc:  box        [mscorlib]System.Double
      IL_01d1:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_01d6:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_01db:  ldloc.1
      IL_01dc:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Input.PSD_LD"
      IL_01e1:  ldstr      "value"
      IL_01e6:  ldnull
      IL_01e7:  ldc.r8     15
      IL_01f0:  box        [mscorlib]System.Double
      IL_01f5:  newobj     instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest::.ctor(string,
                                                                                                       string,
                                                                                                       string,
                                                                                                       object)
      IL_01fa:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData::AddRequest(valuetype [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequest)
      IL_01ff:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyCase()
      IL_0204:  ldloc.1
      IL_0205:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchSet(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsBatchRequestData)
      IL_020a:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyCase()
      IL_020f:  ldstr      "Top.Solver.RunSynchronous"
      IL_0214:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::ResolveNode(string)
      IL_0219:  stloc.2
      IL_021a:  ldloc.2
      IL_021b:  ldstr      "value"
      IL_0220:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::GetAttribute(string)
      IL_0225:  call       string [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Conversions::ToString(object)
      IL_022a:  stloc.3
      IL_022b:  ldloc.3
      IL_022c:  ldstr      "false"
      IL_0231:  callvirt   instance bool [mscorlib]System.String::Equals(string)
      IL_0236:  brfalse.s  IL_0248

      IL_0238:  ldloc.2
      IL_0239:  ldstr      "value"
      IL_023e:  ldstr      "true"
      IL_0243:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::SetAttribute(string,
                                                                                                      object)
      IL_0248:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyCase()
      IL_024d:  ldstr      "Top.Solver"
      IL_0252:  ldstr      "Run"
      IL_0257:  ldc.i4.0
      IL_0258:  newarr     [mscorlib]System.Object
      IL_025d:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::InvokeAction(string,
                                                                                                        string,
                                                                                                        object[])
      IL_0262:  pop
      IL_0263:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyCase()
      IL_0268:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief.A9P4"
      + "879R.Output.MAX_MOLEFLOW"
      IL_026d:  ldstr      "value"
      IL_0272:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                    string)
      IL_0277:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
      IL_027c:  stloc.s    V_4
      IL_027e:  ldloc.s    V_4
      IL_0280:  brfalse.s  IL_028a

      IL_0282:  ldloc.s    V_4
      IL_0284:  call       float64 [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Conversions::ToDouble(object)
      IL_0289:  pop
      IL_028a:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
      IL_028f:  ldstr      "Top.appModel.Flowsheeting Options.Pres-Relief"
      IL_0294:  ldstr      "DeleteChild"
      IL_0299:  ldc.i4.0
      IL_029a:  ldc.i4.1
      IL_029b:  newarr     [mscorlib]System.Object
      IL_02a0:  dup
      IL_02a1:  ldc.i4.0
      IL_02a2:  ldloc.0
      IL_02a3:  stelem.ref
      IL_02a4:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::InvokeAction(string,
                                                                                                                                                                                                                          string,
                                                                                                                                                                                                                          bool,
                                                                                                                                                                                                                          object[])
      IL_02a9:  pop
      IL_02aa:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyCase()
      IL_02af:  ldstr      "Top.Solver"
      IL_02b4:  ldstr      "Run"
      IL_02b9:  ldc.i4.0
      IL_02ba:  newarr     [mscorlib]System.Object
      IL_02bf:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::InvokeAction(string,
                                                                                                        string,
                                                                                                        object[])
      IL_02c4:  pop
      IL_02c5:  ldloc.3
      IL_02c6:  ldstr      "false"
      IL_02cb:  callvirt   instance bool [mscorlib]System.String::Equals(string)
      IL_02d0:  brfalse.s  IL_02e2

      IL_02d2:  ldloc.2
      IL_02d3:  ldstr      "value"
      IL_02d8:  ldstr      "false"
      IL_02dd:  callvirt   instance void [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::SetAttribute(string,
                                                                                                      object)
      IL_02e2:  leave.s    IL_02f0

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_02e4:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::SetProjectError(class [mscorlib]System.Exception)
      IL_02e9:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::ClearProjectError()
      IL_02ee:  leave.s    IL_02f0

    }  // end handler
    IL_02f0:  ret
  } // end of method PsvCase::CalculateRuptureDisk

  .method public newslot strict virtual final 
          instance bool  RecordExists(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey key) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::RecordExists
    // Code size       151 (0x97)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0' V_0,
             bool V_1)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::$VB$Local_key
    IL_000d:  ldloc.0
    IL_000e:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::$VB$Local_key
    IL_0013:  callvirt   instance valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.eRecordType [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_RecordType()
    IL_0018:  ldc.i4.1
    IL_0019:  bne.un.s   IL_003a

    IL_001b:  ldarg.0
    IL_001c:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_m_ModelRegistry()
    IL_0021:  ldloc.0
    IL_0022:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank)
    IL_0028:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank,bool>::.ctor(object,
                                                                                                                                                                           native int)
    IL_002d:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelsOfType<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank>(class [mscorlib]System.Func`2<!!0,bool>)
    IL_0032:  call       bool [System.Core]System.Linq.Enumerable::Any<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0037:  stloc.1
    IL_0038:  br.s       IL_0095

    IL_003a:  ldloc.0
    IL_003b:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::$VB$Local_key
    IL_0040:  callvirt   instance valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.eRecordType [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_RecordType()
    IL_0045:  brtrue.s   IL_0066

    IL_0047:  ldarg.0
    IL_0048:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_m_ModelRegistry()
    IL_004d:  ldloc.0
    IL_004e:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::_Lambda$__1(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement)
    IL_0054:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement,bool>::.ctor(object,
                                                                                                                                                                                             native int)
    IL_0059:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelsOfType<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>(class [mscorlib]System.Func`2<!!0,bool>)
    IL_005e:  call       bool [System.Core]System.Linq.Enumerable::Any<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0063:  stloc.1
    IL_0064:  br.s       IL_0095

    IL_0066:  ldloc.0
    IL_0067:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::$VB$Local_key
    IL_006c:  callvirt   instance valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.eRecordType [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_RecordType()
    IL_0071:  ldc.i4.5
    IL_0072:  bne.un.s   IL_0093

    IL_0074:  ldarg.0
    IL_0075:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_m_ModelRegistry()
    IL_007a:  ldloc.0
    IL_007b:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__62-0'::_Lambda$__2(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition)
    IL_0081:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition,bool>::.ctor(object,
                                                                                                                                                                                        native int)
    IL_0086:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelsOfType<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition>(class [mscorlib]System.Func`2<!!0,bool>)
    IL_008b:  call       bool [System.Core]System.Linq.Enumerable::Any<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0090:  stloc.1
    IL_0091:  br.s       IL_0095

    IL_0093:  ldc.i4.0
    IL_0094:  stloc.1
    IL_0095:  ldloc.1
    IL_0096:  ret
  } // end of method PsvCase::RecordExists

  .method public instance string  GetNoDatabaseEntryMSG() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_Host()
    IL_0006:  ldstr      "ASPENPLUS"
    IL_000b:  call       bool [mscorlib]System.String::Equals(string,
                                                              string)
    IL_0010:  brfalse.s  IL_001a

    IL_0012:  call       string [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.FormResource::get_lbl_NoDatabaseEntry_AspenPlus()
    IL_0017:  stloc.0
    IL_0018:  br.s       IL_0020

    IL_001a:  call       string [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.FormResource::get_lbl_NoDatabaseEntry()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method PsvCase::GetNoDatabaseEntryMSG

  .method public newslot strict virtual final 
          instance void  ExportDefaultsToFile(string path) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::ExportDefaultsToFile
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::ExportDefaultsToFile(string)
    IL_000c:  ret
  } // end of method PsvCase::ExportDefaultsToFile

  .method public newslot strict virtual final 
          instance void  ImportDefaultsFromFile(string path,
                                                string& loadVersion,
                                                class [mscorlib]System.Collections.Generic.IEnumerable`1<string>& warningSections,
                                                class [mscorlib]System.Collections.Generic.IEnumerable`1<string>& warningMessages) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::ImportDefaultsFromFile
    // Code size       17 (0x11)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_0006:  ldarg.1
    IL_0007:  ldarg.2
    IL_0008:  ldarg.3
    IL_0009:  ldarg.s    warningMessages
    IL_000b:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::ImportDefaultsFromFile(string,
                                                                                                                                                         string&,
                                                                                                                                                         class [mscorlib]System.Collections.Generic.IEnumerable`1<string>&,
                                                                                                                                                         class [mscorlib]System.Collections.Generic.IEnumerable`1<string>&)
    IL_0010:  ret
  } // end of method PsvCase::ImportDefaultsFromFile

  .method public newslot strict virtual final 
          instance void  ImportPRDSystem(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase fromCase,
                                         class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey prdSysKey,
                                         [opt] class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey destKey,
                                         [opt] class [mscorlib]System.Collections.Generic.Dictionary`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey> destScenarioKeyMap) cil managed
  {
    .param [3] = nullref
    .param [4] = nullref
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::ImportPRDSystem
    // Code size       219 (0xdb)
    .maxstack  4
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__66-0' V_0,
             class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement V_1,
             class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement V_2,
             class [mscorlib]System.Collections.Generic.Dictionary`2<int32,int32> V_3)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__66-0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.2
    IL_0008:  stfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__66-0'::$VB$Local_prdSysKey
    IL_000d:  ldloc.0
    IL_000e:  ldfld      class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__66-0'::$VB$Local_prdSysKey
    IL_0013:  callvirt   instance valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.eRecordType [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_RecordType()
    IL_0018:  brtrue     IL_00da

    IL_001d:  ldarg.1
    IL_001e:  castclass  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase
    IL_0023:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_0028:  call       class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelRegistry(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_002d:  ldnull
    IL_002e:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry::GetModelsOfType<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>(class [mscorlib]System.Func`2<!!0,bool>)
    IL_0033:  ldloc.0
    IL_0034:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/'_Closure$__66-0'::_Lambda$__0(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement)
    IL_003a:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement,bool>::.ctor(object,
                                                                                                                                                                                             native int)
    IL_003f:  call       !!0 [System.Core]System.Linq.Enumerable::Single<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                     class [mscorlib]System.Func`2<!!0,bool>)
    IL_0044:  stloc.1
    IL_0045:  ldarg.0
    IL_0046:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_004b:  call       class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::CreateNew(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_0050:  stloc.2
    IL_0051:  ldloc.2
    IL_0052:  ldloc.1
    IL_0053:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.BaseModel::CopyFromOtherDatabase(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.BaseModel)
    IL_0058:  ldarg.3
    IL_0059:  brfalse.s  IL_0069

    IL_005b:  ldloc.2
    IL_005c:  ldarg.3
    IL_005d:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
    IL_0062:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::FixUpLegacyKey(int32)
    IL_0067:  br.s       IL_0075

    IL_0069:  ldloc.2
    IL_006a:  ldloc.1
    IL_006b:  callvirt   instance int32 [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::get_LegacyKey()
    IL_0070:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::FixUpLegacyKey(int32)
    IL_0075:  ldarg.s    destScenarioKeyMap
    IL_0077:  brfalse.s  IL_00d2

    IL_0079:  ldarg.s    destScenarioKeyMap
    IL_007b:  ldsfld     class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'$I66-1'
    IL_0080:  brfalse.s  IL_0089

    IL_0082:  ldsfld     class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'$I66-1'
    IL_0087:  br.s       IL_009f

    IL_0089:  ldsfld     class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__ AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::$I
    IL_008e:  ldftn      instance int32 AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'_Lambda$__66-1'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>)
    IL_0094:  newobj     instance void class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32>::.ctor(object,
                                                                                                                                                                                                                                                                                                                                                          native int)
    IL_0099:  dup
    IL_009a:  stsfld     class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'$I66-1'
    IL_009f:  ldsfld     class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'$I66-2'
    IL_00a4:  brfalse.s  IL_00ad

    IL_00a6:  ldsfld     class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'$I66-2'
    IL_00ab:  br.s       IL_00c3

    IL_00ad:  ldsfld     class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__ AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::$I
    IL_00b2:  ldftn      instance int32 AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'_Lambda$__66-2'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>)
    IL_00b8:  newobj     instance void class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32>::.ctor(object,
                                                                                                                                                                                                                                                                                                                                                          native int)
    IL_00bd:  dup
    IL_00be:  stsfld     class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'$I66-2'
    IL_00c3:  call       class [mscorlib]System.Collections.Generic.Dictionary`2<!!1,!!2> [System.Core]System.Linq.Enumerable::ToDictionary<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey>,int32,int32>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                                                                                                                                                                                                                                                                class [mscorlib]System.Func`2<!!0,!!1>,
                                                                                                                                                                                                                                                                                                                                                                                                                                class [mscorlib]System.Func`2<!!0,!!2>)
    IL_00c8:  stloc.3
    IL_00c9:  ldloc.2
    IL_00ca:  ldloc.1
    IL_00cb:  ldloc.3
    IL_00cc:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::RemapScenarioKeysForRecord(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement,
                                                                                                                                                                        class [mscorlib]System.Collections.Generic.Dictionary`2<int32,int32>)
    IL_00d1:  ret

    IL_00d2:  ldloc.2
    IL_00d3:  ldloc.1
    IL_00d4:  ldnull
    IL_00d5:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement::RemapScenarioKeysForRecord(class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement,
                                                                                                                                                                        class [mscorlib]System.Collections.Generic.Dictionary`2<int32,int32>)
    IL_00da:  ret
  } // end of method PsvCase::ImportPRDSystem

  .method public newslot strict virtual final 
          instance void  ImportCaseConfiguration(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase fromCase,
                                                 bool isMergeOperation) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::ImportCaseConfiguration
    // Code size       124 (0x7c)
    .maxstack  2
    .locals init (class [AspenDataShareCS]AspenTech.Adb.Acs.AcsSeDefaultValueDefiner V_0,
             class [AspenDataShareCS]AspenTech.Adb.Acs.AcsSeCaseConfiguration V_1)
    IL_0000:  ldarg.1
    IL_0001:  castclass  AspenTech.EquipmentAnalysis.PSVPlus.PsvCase
    IL_0006:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::_AdbTop
    IL_000b:  dup
    IL_000c:  call       class [mscorlib]System.Collections.Generic.IEnumerable`1<class [AspenDataShareCS]AspenTech.Adb.Acs.AcsSeDefaultValueDefiner> [AspenDataShareCS]AspenTech.Adb.Acs.AdbTopEnums::AcsSeDefaultValueDefiners(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_0011:  call       !!0 [System.Core]System.Linq.Enumerable::Single<class [AspenDataShareCS]AspenTech.Adb.Acs.AcsSeDefaultValueDefiner>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0016:  stloc.0
    IL_0017:  call       class [mscorlib]System.Collections.Generic.IEnumerable`1<class [AspenDataShareCS]AspenTech.Adb.Acs.AcsSeCaseConfiguration> [AspenDataShareCS]AspenTech.Adb.Acs.AdbTopEnums::AcsSeCaseConfigurations(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_001c:  call       !!0 [System.Core]System.Linq.Enumerable::Single<class [AspenDataShareCS]AspenTech.Adb.Acs.AcsSeCaseConfiguration>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0021:  stloc.1
    IL_0022:  ldarg.2
    IL_0023:  brtrue.s   IL_0047

    IL_0025:  ldarg.0
    IL_0026:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_002b:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_Configuration()
    IL_0030:  ldloc.1
    IL_0031:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.BaseModel::CopyFromRecord(class [AspenDataShareCS]AspenTech.Adb.Acs.AcsBase)
    IL_0036:  ldarg.0
    IL_0037:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_003c:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.DefaultValueDefiner [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_DefaultValueDefiner()
    IL_0041:  ldloc.0
    IL_0042:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.DefaultValueDefiner::CopyFromRecord(class [AspenDataShareCS]AspenTech.Adb.Acs.AcsSeDefaultValueDefiner)
    IL_0047:  ldarg.0
    IL_0048:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_004d:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_Configuration()
    IL_0052:  ldloc.1
    IL_0053:  callvirt   instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration::MergeConfigurationData(class [AspenDataShareCS]AspenTech.Adb.Acs.AcsSeCaseConfiguration)
    IL_0058:  ldarg.0
    IL_0059:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_005e:  call       bool [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::IsRegistered<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.OrificeSizeSettingModel>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer)
    IL_0063:  brfalse.s  IL_007b

    IL_0065:  ldarg.0
    IL_0066:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_006b:  ldc.i4.0
    IL_006c:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0071:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.OrificeSizeSettingModel>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                                            class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0076:  callvirt   instance void [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.OrificeSizeSettingModel::OnSettingsLoaded()
    IL_007b:  ret
  } // end of method PsvCase::ImportCaseConfiguration

  .method private instance void  OnDefaultDesignCodeChanged(class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       56 (0x38)
    .maxstack  3
    .locals init (class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_0006:  ldc.i4.0
    IL_0007:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_000c:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                               class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_0011:  stloc.0
    IL_0012:  call       class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.DefaultValueDefiner [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_ActiveDefaultDefiner()
    IL_0017:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessEnum`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.DefaultValueDefiner::get_PressureProtectionRequirement_DesignCode()
    IL_001c:  ldsfld     class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode> [AspenTech.EquipmentAnalysis.PSVControlResources]AspenTech.EquipmentAnalysis.PSVControlResources.TranslateUiStrings::SystemDesignCode
    IL_0021:  ldloc.0
    IL_0022:  callvirt   instance string [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_PSVDefaultDesignCodeString()
    IL_0027:  callvirt   instance valuetype [mscorlib]System.Nullable`1<!0> class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode>::Enum(string)
    IL_002c:  newobj     instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.UserSpecifier::.ctor()
    IL_0031:  callvirt   instance bool class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessVar`2<valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode>,valuetype [mscorlib]System.Nullable`1<int32>>::Specify(!0,
                                                                                                                                                                                                                                                                                                                                                 class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier)
    IL_0036:  pop
    IL_0037:  ret
  } // end of method PsvCase::OnDefaultDesignCodeChanged

  .method private instance void  OnActiveScreenChanged(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ActiveScreenChangedEventArgs e) cil managed
  {
    // Code size       414 (0x19e)
    .maxstack  5
    .locals init (class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase V_0,
             class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.BaseModel V_1,
             class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.BaseModel V_2,
             class [mscorlib]System.Collections.Generic.IEnumerable`1<object> V_3,
             object V_4,
             valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.eRecordType V_5,
             class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel V_6,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVScreen V_7)
    IL_0000:  ldarg.0
    IL_0001:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_m_ModelRegistry()
    IL_0006:  call       class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_ActiveConfiguration()
    IL_000b:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.BaseModel::get_ModelRegistry()
    IL_0010:  bne.un     IL_019d

    IL_0015:  ldarg.1
    IL_0016:  callvirt   instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ActiveScreenChangedEventArgs::get_Screen()
    IL_001b:  dup
    IL_001c:  brtrue.s   IL_0022

    IL_001e:  pop
    IL_001f:  ldnull
    IL_0020:  br.s       IL_0027

    IL_0022:  call       instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl::get_ScreenSubject()
    IL_0027:  isinst     [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase
    IL_002c:  stloc.0
    IL_002d:  ldnull
    IL_002e:  stloc.1
    IL_002f:  ldnull
    IL_0030:  stloc.2
    IL_0031:  ldnull
    IL_0032:  stloc.3
    IL_0033:  ldnull
    IL_0034:  stloc.s    V_4
    IL_0036:  ldloc.0
    IL_0037:  brtrue.s   IL_003c

    IL_0039:  ldnull
    IL_003a:  br.s       IL_0042

    IL_003c:  ldloc.0
    IL_003d:  call       instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase::get_ModelKey()
    IL_0042:  brfalse    IL_0165

    IL_0047:  ldloc.0
    IL_0048:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase::get_ModelKey()
    IL_004d:  callvirt   instance valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.eRecordType [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey::get_RecordType()
    IL_0052:  stloc.s    V_5
    IL_0054:  ldloc.s    V_5
    IL_0056:  brfalse.s  IL_0064

    IL_0058:  ldloc.s    V_5
    IL_005a:  ldc.i4.1
    IL_005b:  beq.s      IL_00c7

    IL_005d:  ldloc.s    V_5
    IL_005f:  ldc.i4.5
    IL_0060:  beq.s      IL_0081

    IL_0062:  br.s       IL_00e0

    IL_0064:  ldarg.0
    IL_0065:  ldloc.0
    IL_0066:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase::get_ModelKey()
    IL_006b:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPRDSystemModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0070:  dup
    IL_0071:  brtrue.s   IL_0077

    IL_0073:  pop
    IL_0074:  ldnull
    IL_0075:  br.s       IL_007c

    IL_0077:  call       instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::get_Model()
    IL_007c:  stloc.1
    IL_007d:  ldloc.1
    IL_007e:  stloc.2
    IL_007f:  br.s       IL_00e0

    IL_0081:  ldarg.0
    IL_0082:  ldloc.0
    IL_0083:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase::get_ModelKey()
    IL_0088:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetPSVScenarioModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_008d:  stloc.s    V_6
    IL_008f:  ldloc.s    V_6
    IL_0091:  brtrue.s   IL_0096

    IL_0093:  ldnull
    IL_0094:  br.s       IL_00a9

    IL_0096:  ldloc.s    V_6
    IL_0098:  call       instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition>::get_Model()
    IL_009d:  dup
    IL_009e:  brtrue.s   IL_00a4

    IL_00a0:  pop
    IL_00a1:  ldnull
    IL_00a2:  br.s       IL_00a9

    IL_00a4:  call       instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ReliefScenario [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PrdConstraintsDefinition::get_ReliefScenario()
    IL_00a9:  stloc.1
    IL_00aa:  ldloc.s    V_6
    IL_00ac:  brtrue.s   IL_00b1

    IL_00ae:  ldnull
    IL_00af:  br.s       IL_00c4

    IL_00b1:  ldloc.s    V_6
    IL_00b3:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PRDSystemModel [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.PSVScenarioModel::get_PRDSystem()
    IL_00b8:  dup
    IL_00b9:  brtrue.s   IL_00bf

    IL_00bb:  pop
    IL_00bc:  ldnull
    IL_00bd:  br.s       IL_00c4

    IL_00bf:  call       instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.PressureProtectionRequirement>::get_Model()
    IL_00c4:  stloc.2
    IL_00c5:  br.s       IL_00e0

    IL_00c7:  ldarg.0
    IL_00c8:  ldloc.0
    IL_00c9:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase::get_ModelKey()
    IL_00ce:  call       instance class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.TankModel AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::GetStorageTankModel(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_00d3:  dup
    IL_00d4:  brtrue.s   IL_00da

    IL_00d6:  pop
    IL_00d7:  ldnull
    IL_00d8:  br.s       IL_00df

    IL_00da:  call       instance !0 class [AspenTech.EquipmentAnalysis.PSVModelLibrary]AspenTech.EquipmentAnalysis.PSVModelLibrary.BaseModel`1<class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.StorageTank>::get_Model()
    IL_00df:  stloc.1
    IL_00e0:  ldc.i4.1
    IL_00e1:  newarr     [mscorlib]System.Object
    IL_00e6:  dup
    IL_00e7:  ldc.i4.0
    IL_00e8:  ldloc.1
    IL_00e9:  dup
    IL_00ea:  brtrue.s   IL_00f0

    IL_00ec:  pop
    IL_00ed:  ldnull
    IL_00ee:  br.s       IL_00f5

    IL_00f0:  callvirt   instance object [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_DataModel()
    IL_00f5:  stelem.ref
    IL_00f6:  stloc.3
    IL_00f7:  ldloc.2
    IL_00f8:  dup
    IL_00f9:  brtrue.s   IL_00ff

    IL_00fb:  pop
    IL_00fc:  ldnull
    IL_00fd:  br.s       IL_0104

    IL_00ff:  callvirt   instance object [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_DataModel()
    IL_0104:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0109:  stloc.s    V_4
    IL_010b:  ldloc.0
    IL_010c:  callvirt   instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase::get_ModelKey()
    IL_0111:  callvirt   instance valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.eRecordType [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey::get_RecordType()
    IL_0116:  brtrue.s   IL_0165

    IL_0118:  ldarg.1
    IL_0119:  callvirt   instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ActiveScreenChangedEventArgs::get_Screen()
    IL_011e:  callvirt   instance object [PresentationFramework]System.Windows.Controls.ContentControl::get_Content()
    IL_0123:  isinst     [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVScreen
    IL_0128:  stloc.s    V_7
    IL_012a:  ldloc.s    V_7
    IL_012c:  brfalse.s  IL_0165

    IL_012e:  ldloc.3
    IL_012f:  ldloc.s    V_7
    IL_0131:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel> [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVScreen::get_ActiveModels()
    IL_0136:  ldsfld     class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel,object> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'$I69-0'
    IL_013b:  brfalse.s  IL_0144

    IL_013d:  ldsfld     class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel,object> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'$I69-0'
    IL_0142:  br.s       IL_015a

    IL_0144:  ldsfld     class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__ AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::$I
    IL_0149:  ldftn      instance object AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'_Lambda$__69-0'(class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel)
    IL_014f:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel,object>::.ctor(object,
                                                                                                                                                                                            native int)
    IL_0154:  dup
    IL_0155:  stsfld     class [mscorlib]System.Func`2<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel,object> AspenTech.EquipmentAnalysis.PSVPlus.PsvCase/_Closure$__::'$I69-0'
    IL_015a:  call       class [mscorlib]System.Collections.Generic.IEnumerable`1<!!1> [System.Core]System.Linq.Enumerable::Select<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel,object>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                                                                                   class [mscorlib]System.Func`2<!!0,!!1>)
    IL_015f:  call       class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0> [System.Core]System.Linq.Enumerable::Concat<object>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                           class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0164:  stloc.3
    IL_0165:  ldarg.0
    IL_0166:  ldfld      class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myContainer
    IL_016b:  callvirt   instance class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainer::get_Parent()
    IL_0170:  ldc.i4.0
    IL_0171:  newarr     [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride
    IL_0176:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                                class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
    IL_017b:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEvent>()
    IL_0180:  ldloc.3
    IL_0181:  brtrue.s   IL_0186

    IL_0183:  ldnull
    IL_0184:  br.s       IL_018c

    IL_0186:  ldloc.3
    IL_0187:  call       class [mscorlib]System.Collections.Generic.List`1<!!0> [System.Core]System.Linq.Enumerable::ToList<object>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_018c:  ldloc.s    V_4
    IL_018e:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0193:  newobj     instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs::.ctor(class [mscorlib]System.Collections.Generic.IEnumerable`1<object>,
                                                                                                                                                                               object)
    IL_0198:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs>::Publish(!0)
    IL_019d:  ret
  } // end of method PsvCase::OnActiveScreenChanged

  .method private instance void  OnHostDeactivated(class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       18 (0x12)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::myEventAggregator
    IL_0006:  callvirt   instance !!0 [Microsoft.Practices.Composite]Microsoft.Practices.Composite.Events.IEventAggregator::GetEvent<class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Events.HostDeactivatedEvent>()
    IL_000b:  ldarg.1
    IL_000c:  callvirt   instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::Publish(!0)
    IL_0011:  ret
  } // end of method PsvCase::OnHostDeactivated

  .method public newslot specialname strict virtual final 
          instance valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet 
          get_SelectedUnitSet() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::get_SelectedUnitSet
    // Code size       31 (0x1f)
    .maxstack  2
    .locals init (valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet> V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_0006:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_Configuration()
    IL_000b:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessEnum`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration::get_SelectedUnitSet()
    IL_0010:  callvirt   instance !0 class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessVar`2<valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet>,valuetype [mscorlib]System.Nullable`1<int32>>::get_Value()
    IL_0015:  stloc.0
    IL_0016:  ldloca.s   V_0
    IL_0018:  ldc.i4.0
    IL_0019:  call       instance !0 valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet>::GetValueOrDefault(!0)
    IL_001e:  ret
  } // end of method PsvCase::get_SelectedUnitSet

  .method public newslot specialname strict virtual final 
          instance void  set_SelectedUnitSet(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet 'value') cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::set_SelectedUnitSet
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::SafetyAnalysisCase
    IL_0006:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.SafetyAnalysisCase::get_Configuration()
    IL_000b:  callvirt   instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessEnum`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet> [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.CaseConfiguration::get_SelectedUnitSet()
    IL_0010:  ldarg.1
    IL_0011:  newobj     instance void valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet>::.ctor(!0)
    IL_0016:  newobj     instance void [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.UserSpecifier::.ctor()
    IL_001b:  callvirt   instance bool class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ProcessVar`2<valuetype [mscorlib]System.Nullable`1<valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet>,valuetype [mscorlib]System.Nullable`1<int32>>::Specify(!0,
                                                                                                                                                                                                                                                                                                                                                class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier)
    IL_0020:  pop
    IL_0021:  ret
  } // end of method PsvCase::set_SelectedUnitSet

  .property instance callconv(8) string Host()
  {
    .get instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_Host()
    .set instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::set_Host(string)
  } // end of property PsvCase::Host
  .property instance callconv(8) class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry
          m_ModelRegistry()
  {
    .get instance class [AspenTech.EquipmentAnalysis.Models]AspenTech.EquipmentAnalysis.Models.ModelRegistry AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_m_ModelRegistry()
  } // end of property PsvCase::m_ModelRegistry
  .property instance callconv(8) string CaseKey()
  {
    .get instance string AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_CaseKey()
  } // end of property PsvCase::CaseKey
  .property instance callconv(8) class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop
          AdbTop()
  {
    .get instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_AdbTop()
  } // end of property PsvCase::AdbTop
  .property instance callconv(8) valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet
          SelectedUnitSet()
  {
    .get instance valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::get_SelectedUnitSet()
    .set instance void AspenTech.EquipmentAnalysis.PSVPlus.PsvCase::set_SelectedUnitSet(valuetype [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet)
  } // end of property PsvCase::SelectedUnitSet
} // end of class AspenTech.EquipmentAnalysis.PSVPlus.PsvCase

.class public auto ansi AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager
       extends [mscorlib]System.Object
       implements [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager
{
  .class auto ansi sealed nested assembly '_Closure$__7-0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop $VB$Local_adbTop
    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '_Closure$__7-0'::.ctor

    .method assembly specialname instance bool 
            _Lambda$__0(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> kvp) cil managed
    {
      // Code size       21 (0x15)
      .maxstack  8
      IL_0000:  ldarga.s   kvp
      IL_0002:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::get_Value()
      IL_0007:  callvirt   instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::get_AdbTop()
      IL_000c:  ldarg.0
      IL_000d:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager/'_Closure$__7-0'::$VB$Local_adbTop
      IL_0012:  ceq
      IL_0014:  ret
    } // end of method '_Closure$__7-0'::_Lambda$__0

  } // end of class '_Closure$__7-0'

  .field private class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> Cases
  .method public specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       18 (0x12)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  newobj     instance void class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::.ctor()
    IL_000c:  stfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0011:  ret
  } // end of method PSVCaseManager::.ctor

  .method public newslot specialname strict virtual final 
          instance int32  get_Count() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager::get_Count
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0006:  callvirt   instance int32 class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::get_Count()
    IL_000b:  ret
  } // end of method PSVCaseManager::get_Count

  .method public newslot strict virtual final 
          instance bool  AddCase(string pathName,
                                 class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase psvcase) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager::AddCase
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0006:  ldarg.1
    IL_0007:  ldarg.2
    IL_0008:  callvirt   instance bool class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::TryAdd(!0,
                                                                                                                                                                                                                                  !1)
    IL_000d:  ret
  } // end of method PSVCaseManager::AddCase

  .method public newslot strict virtual final 
          instance class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase 
          GetCase(string pathname) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager::GetCase
    // Code size       38 (0x26)
    .maxstack  2
    .locals init (class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0006:  callvirt   instance class [mscorlib]System.Collections.Generic.ICollection`1<!0> class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::get_Keys()
    IL_000b:  ldarg.1
    IL_000c:  callvirt   instance bool class [mscorlib]System.Collections.Generic.ICollection`1<string>::Contains(!0)
    IL_0011:  brfalse.s  IL_0022

    IL_0013:  ldarg.0
    IL_0014:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0019:  ldarg.1
    IL_001a:  callvirt   instance !1 class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::get_Item(!0)
    IL_001f:  stloc.0
    IL_0020:  br.s       IL_0024

    IL_0022:  ldnull
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ret
  } // end of method PSVCaseManager::GetCase

  .method public hidebysig newslot strict virtual final 
          instance bool  TryGetCase(string pathname,
                                    [out] class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase& foundCase) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager::TryGetCase
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0006:  ldarg.1
    IL_0007:  ldarg.2
    IL_0008:  callvirt   instance bool class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::TryGetValue(!0,
                                                                                                                                                                                                                                       !1&)
    IL_000d:  ret
  } // end of method PSVCaseManager::TryGetCase

  .method public hidebysig newslot strict virtual final 
          instance bool  TryGetCase(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop adbTop,
                                    [out] class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase& foundCase) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager::TryGetCase
    // Code size       52 (0x34)
    .maxstack  4
    .locals init (class AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager/'_Closure$__7-0' V_0,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> V_1)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager/'_Closure$__7-0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager/'_Closure$__7-0'::$VB$Local_adbTop
    IL_000d:  ldarg.2
    IL_000e:  ldarg.0
    IL_000f:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0014:  ldloc.0
    IL_0015:  ldftn      instance bool AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager/'_Closure$__7-0'::_Lambda$__0(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>)
    IL_001b:  newobj     instance void class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>,bool>::.ctor(object,
                                                                                                                                                                                                                                                              native int)
    IL_0020:  call       !!0 [System.Core]System.Linq.Enumerable::FirstOrDefault<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                                                                                              class [mscorlib]System.Func`2<!!0,bool>)
    IL_0025:  stloc.1
    IL_0026:  ldloca.s   V_1
    IL_0028:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::get_Value()
    IL_002d:  stind.ref
    IL_002e:  ldarg.2
    IL_002f:  ldind.ref
    IL_0030:  ldnull
    IL_0031:  cgt.un
    IL_0033:  ret
  } // end of method PSVCaseManager::TryGetCase

  .method public newslot strict virtual final 
          instance bool  RemoveCase(string pathName) cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager::RemoveCase
    // Code size       70 (0x46)
    .maxstack  3
    .locals init (bool V_0,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase V_1)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0006:  callvirt   instance class [mscorlib]System.Collections.Generic.ICollection`1<!0> class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::get_Keys()
    IL_000b:  ldarg.1
    IL_000c:  callvirt   instance bool class [mscorlib]System.Collections.Generic.ICollection`1<string>::Contains(!0)
    IL_0011:  brfalse.s  IL_0042

    IL_0013:  ldarg.0
    IL_0014:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0019:  ldarg.1
    IL_001a:  callvirt   instance !1 class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::get_Item(!0)
    IL_001f:  stloc.1
    IL_0020:  ldarg.0
    IL_0021:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0026:  ldarg.1
    IL_0027:  ldloca.s   V_1
    IL_0029:  callvirt   instance bool class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::TryRemove(!0,
                                                                                                                                                                                                                                     !1&)
    IL_002e:  dup
    IL_002f:  brfalse.s  IL_003f

    IL_0031:  ldloc.1
    IL_0032:  call       bool [Microsoft.VisualBasic]Microsoft.VisualBasic.Information::IsNothing(object)
    IL_0037:  brtrue.s   IL_003f

    IL_0039:  ldloc.1
    IL_003a:  callvirt   instance void [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::Close()
    IL_003f:  stloc.0
    IL_0040:  br.s       IL_0044

    IL_0042:  ldc.i4.0
    IL_0043:  stloc.0
    IL_0044:  ldloc.0
    IL_0045:  ret
  } // end of method PSVCaseManager::RemoveCase

  .method public instance bool  RenameCase(string oldPathName,
                                           string newPathName) cil managed
  {
    // Code size       93 (0x5d)
    .maxstack  3
    .locals init (bool V_0,
             class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase V_1,
             bool V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0006:  callvirt   instance class [mscorlib]System.Collections.Generic.ICollection`1<!0> class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::get_Keys()
    IL_000b:  ldarg.1
    IL_000c:  callvirt   instance bool class [mscorlib]System.Collections.Generic.ICollection`1<string>::Contains(!0)
    IL_0011:  ldc.i4.0
    IL_0012:  ceq
    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_001a:  callvirt   instance class [mscorlib]System.Collections.Generic.ICollection`1<!0> class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::get_Keys()
    IL_001f:  ldarg.2
    IL_0020:  callvirt   instance bool class [mscorlib]System.Collections.Generic.ICollection`1<string>::Contains(!0)
    IL_0025:  or
    IL_0026:  brfalse.s  IL_002c

    IL_0028:  ldc.i4.0
    IL_0029:  stloc.0
    IL_002a:  br.s       IL_005b

    IL_002c:  ldarg.0
    IL_002d:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0032:  ldarg.1
    IL_0033:  callvirt   instance !1 class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::get_Item(!0)
    IL_0038:  stloc.1
    IL_0039:  ldarg.0
    IL_003a:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_003f:  ldarg.1
    IL_0040:  ldloca.s   V_1
    IL_0042:  callvirt   instance bool class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::TryRemove(!0,
                                                                                                                                                                                                                                     !1&)
    IL_0047:  stloc.2
    IL_0048:  ldloc.2
    IL_0049:  brfalse.s  IL_0059

    IL_004b:  ldarg.0
    IL_004c:  ldfld      class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase> AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::Cases
    IL_0051:  ldarg.2
    IL_0052:  ldloc.1
    IL_0053:  callvirt   instance bool class [mscorlib]System.Collections.Concurrent.ConcurrentDictionary`2<string,class [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase>::TryAdd(!0,
                                                                                                                                                                                                                                  !1)
    IL_0058:  stloc.2
    IL_0059:  ldloc.2
    IL_005a:  stloc.0
    IL_005b:  ldloc.0
    IL_005c:  ret
  } // end of method PSVCaseManager::RenameCase

  .property instance callconv(8) int32 Count()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager::get_Count()
  } // end of property PSVCaseManager::Count
} // end of class AspenTech.EquipmentAnalysis.PSVPlus.PSVCaseManager


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file orig.ildasm.res
