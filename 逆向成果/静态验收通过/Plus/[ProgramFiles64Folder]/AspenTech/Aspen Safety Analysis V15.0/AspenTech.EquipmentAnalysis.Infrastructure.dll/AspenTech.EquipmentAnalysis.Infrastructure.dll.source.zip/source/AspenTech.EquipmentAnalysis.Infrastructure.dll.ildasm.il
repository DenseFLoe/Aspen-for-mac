﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest
  AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfoHelper
  AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo
  AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo
  AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper
  AspenTech.EquipmentAnalysis.Infrastructure.BindableBase
  AspenTech.EquipmentAnalysis.Infrastructure.ComboBoxItemWithTooltip
  AspenTech.EquipmentAnalysis.Infrastructure.Common
  AspenTech.EquipmentAnalysis.Infrastructure.HelpTopicID
  AspenTech.EquipmentAnalysis.Infrastructure.EAObjType
  AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType
  AspenTech.EquipmentAnalysis.Infrastructure.PsvType
  AspenTech.EquipmentAnalysis.Infrastructure.ApiSpringMaterial
  AspenTech.EquipmentAnalysis.Infrastructure.FlowType
  AspenTech.EquipmentAnalysis.Infrastructure.ReliefLoadCalculationType
  AspenTech.EquipmentAnalysis.Infrastructure.CalculationMessageType
  AspenTech.EquipmentAnalysis.Infrastructure.StorageTankCalcCode
  AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice
  AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType
  AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskType
  AspenTech.EquipmentAnalysis.Infrastructure.ReliefOrificeSource
  AspenTech.EquipmentAnalysis.Infrastructure.PressureDropCalculationType
  AspenTech.EquipmentAnalysis.Infrastructure.TeeFlowType
  AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation
  AspenTech.EquipmentAnalysis.Infrastructure.ApiValveMaterial
  AspenTech.EquipmentAnalysis.Infrastructure.Api526Ed
  AspenTech.EquipmentAnalysis.Infrastructure.EquipmentMaterial
  AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskSpecificationType
  AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode
  AspenTech.EquipmentAnalysis.Infrastructure.PipeMaterial
  AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation
  AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType
  AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod
  AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime
  AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod
  AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec
  AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource
  AspenTech.EquipmentAnalysis.Infrastructure.ProcessDataSource
  AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod
  AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType
  AspenTech.EquipmentAnalysis.Infrastructure.HeadType
  AspenTech.EquipmentAnalysis.Infrastructure.BuiltUpBackpressureSource
  AspenTech.EquipmentAnalysis.Infrastructure.CpCvSelectionEnum
  AspenTech.EquipmentAnalysis.Infrastructure.PSVReportTypeEnum
  AspenTech.EquipmentAnalysis.Infrastructure.PipeElementType
  AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceConfigurationType
  AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionCoefficientMethod
  AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionTemperatureType
  AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation
  AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel
  AspenTech.EquipmentAnalysis.Infrastructure.FittingName
  AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries
  AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1
  AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslatorOneWay`1
  AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel
  AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel
  AspenTech.EquipmentAnalysis.Infrastructure.INamedModel
  AspenTech.EquipmentAnalysis.Infrastructure.IMessageContainer`1
  AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier
  AspenTech.EquipmentAnalysis.Infrastructure.IProcessAction
  AspenTech.EquipmentAnalysis.Infrastructure.ICalculationRunner
  AspenTech.EquipmentAnalysis.Infrastructure.eDBConnectionSide
  AspenTech.EquipmentAnalysis.Infrastructure.IConnectedObjectList`1
  AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection
  AspenTech.EquipmentAnalysis.Infrastructure.IOwnedObjectList`1
  AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost
  AspenTech.EquipmentAnalysis.Infrastructure.IEquipmentAnalysisInContextGuidanceAgent
  AspenTech.EquipmentAnalysis.Infrastructure.InContextGuidanceExtensions
  AspenTech.EquipmentAnalysis.Infrastructure.INotifyInvalidValueEntered
  AspenTech.EquipmentAnalysis.Infrastructure.IPSVScreen
  AspenTech.EquipmentAnalysis.Infrastructure.IKeyedObject
  AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable
  AspenTech.EquipmentAnalysis.Infrastructure.IReferenceHolder
  AspenTech.EquipmentAnalysis.Infrastructure.IManagedReference
  AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType
  AspenTech.EquipmentAnalysis.Infrastructure.IReferenceUpdate
  AspenTech.EquipmentAnalysis.Infrastructure.ISerializableObject
  AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel
  AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1
  AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
  AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
  AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure
  AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1
  AspenTech.EquipmentAnalysis.Infrastructure.IFluidForHydraulics
  AspenTech.EquipmentAnalysis.Infrastructure.IImportWizard
  AspenTech.EquipmentAnalysis.Infrastructure.IModelRegistry
  AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable
  AspenTech.EquipmentAnalysis.Infrastructure.IProcessVar`1
  AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager
  AspenTech.EquipmentAnalysis.Infrastructure.IPSVDatabaseMgr
  AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager
  AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation
  AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.IPSVNavigator
  AspenTech.EquipmentAnalysis.Infrastructure.IPSVNode
  AspenTech.EquipmentAnalysis.Infrastructure.IBaseUserControl
  AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase
  AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs
  AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary
  AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings
  AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings
  AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings
  AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands
  AspenTech.EquipmentAnalysis.Infrastructure.ISubject
  AspenTech.EquipmentAnalysis.Infrastructure.IObserver
  AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver
  AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal
  AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal
  AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
  AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey
  AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKeyFactory
  AspenTech.EquipmentAnalysis.Infrastructure.eRecordType
  AspenTech.EquipmentAnalysis.Infrastructure.eUtilityType
  AspenTech.EquipmentAnalysis.Infrastructure.eEquipmentType
  AspenTech.EquipmentAnalysis.Infrastructure.eIterationCalcType
  AspenTech.EquipmentAnalysis.Infrastructure.PsvKey
  AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenFactoryKeys
  AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase
  AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioNodeEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveScreenChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyCaseChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ExitSafetyEnvironmentEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.CloseCaseEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.HostDeactivatedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVDesignCodeChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType
  AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseStatusChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.DefaultWarningSeetingChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PropertyEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventEx
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVShowHelpEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVHelpEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVUnitSetChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation
  AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOrificeSizesEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateTankManagerGridEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEvent
  AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs
  AspenTech.EquipmentAnalysis.Infrastructure.Events.DatabaseConnectedEvent
  '<PrivateImplementationDetails>'
  AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest/'<>c'
  AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0'
  AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation
  AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet
  AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass0_0'
  AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass2_0'
  AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass3_0'
  AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass9_0'
  AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1/'<>c__DisplayClass5_0'
  AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal/'<>c__DisplayClass9_0'
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern AspenTech.AspenCxs
{
  .publickeytoken = (5D 73 34 E0 D1 73 8A D6 )                         // ]s4..s..
  .ver 41:0:0:57
}
.assembly extern Microsoft.Practices.Unity
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 3:5:0:0
}
.assembly extern AspenTech.AspenCxs.CxsViewModel
{
  .ver 41:0:0:0
}
.assembly extern System
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern System.Core
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern PresentationCore
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern PresentationFramework
{
  .publickeytoken = (31 BF 38 56 AD 36 4E 35 )                         // 1.8V.6N5
  .ver 4:0:0:0
}
.assembly extern PSVSizingEngine
{
  .ver 41:0:0:0
}
.assembly extern AspenTech.EquipmentAnalysis.Resources
{
  .ver 41:0:0:0
}
.assembly extern AdbComInterfaces
{
  .ver 41:0:0:0
}
.assembly extern System.Data
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern AspenTech.Visualisation.CommonShell.Infrastructure.Wpf
{
  .publickeytoken = (B0 56 89 B3 9D EE FB CD )                         // .V......
  .ver 31:0:0:5
}
.assembly extern Microsoft.Practices.Composite.Presentation
{
  .publickeytoken = (8A F4 53 88 06 95 A9 B8 )                         // ..S.....
  .ver 2:0:1:0
}
.assembly AspenTech.EquipmentAnalysis.Infrastructure
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.ExtensionAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.

  // --- The following custom attribute is added automatically, do not uncomment -------
  //  .custom instance void [mscorlib]System.Diagnostics.DebuggableAttribute::.ctor(valuetype [mscorlib]System.Diagnostics.DebuggableAttribute/DebuggingModes) = ( 01 00 02 00 00 00 00 00 ) 

  .custom instance void [mscorlib]System.Reflection.AssemblyFileVersionAttribute::.ctor(string) = ( 01 00 09 34 31 2E 30 2E 30 2E 38 33 00 00 )       // ...41.0.0.83..
  .custom instance void [mscorlib]System.Reflection.AssemblyCompanyAttribute::.ctor(string) = ( 01 00 15 41 73 70 65 6E 54 65 63 68 20 43 6F 72   // ...AspenTech Cor
                                                                                                70 6F 72 61 74 69 6F 6E 00 00 )                   // poration..
  .custom instance void [mscorlib]System.Reflection.AssemblyProductAttribute::.ctor(string) = ( 01 00 21 41 73 70 65 6E 20 53 61 66 65 74 79 20   // ..!Aspen Safety 
                                                                                                41 6E 61 6C 79 73 69 73 20 45 6E 76 69 72 6F 6E   // Analysis Environ
                                                                                                6D 65 6E 74 00 00 )                               // ment..
  .custom instance void [mscorlib]System.Reflection.AssemblyCopyrightAttribute::.ctor(string) = ( 01 00 27 43 6F 70 79 72 69 67 68 74 20 C2 A9 20   // ..'Copyright .. 
                                                                                                  41 73 70 65 6E 54 65 63 68 20 43 6F 72 70 6F 72   // AspenTech Corpor
                                                                                                  61 74 69 6F 6E 20 32 30 32 34 00 00 )             // ation 2024..
  .custom instance void [mscorlib]System.Reflection.AssemblyTitleAttribute::.ctor(string) = ( 01 00 2A 41 73 70 65 6E 54 65 63 68 2E 45 71 75   // ..*AspenTech.Equ
                                                                                              69 70 6D 65 6E 74 41 6E 61 6C 79 73 69 73 2E 49   // ipmentAnalysis.I
                                                                                              6E 66 72 61 73 74 72 75 63 74 75 72 65 00 00 )    // nfrastructure..
  .custom instance void [mscorlib]System.Reflection.AssemblyDescriptionAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyConfigurationAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyTrademarkAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 39 61 36 38 61 65 36 31 2D 32 34 65 65   // ..$9a68ae61-24ee
                                                                                                  2D 34 35 35 63 2D 39 37 30 65 2D 36 38 37 66 64   // -455c-970e-687fd
                                                                                                  33 37 31 34 34 62 66 00 00 )                      // 37144bf..
  .custom instance void [mscorlib]System.Runtime.Versioning.TargetFrameworkAttribute::.ctor(string) = ( 01 00 1A 2E 4E 45 54 46 72 61 6D 65 77 6F 72 6B   // ....NETFramework
                                                                                                        2C 56 65 72 73 69 6F 6E 3D 76 34 2E 38 01 00 54   // ,Version=v4.8..T
                                                                                                        0E 14 46 72 61 6D 65 77 6F 72 6B 44 69 73 70 6C   // ..FrameworkDispl
                                                                                                        61 79 4E 61 6D 65 12 2E 4E 45 54 20 46 72 61 6D   // ayName..NET Fram
                                                                                                        65 77 6F 72 6B 20 34 2E 38 )                      // ework 4.8
  .hash algorithm 0x00008004
  .ver 41:0:0:0
}
.module AspenTech.EquipmentAnalysis.Infrastructure.dll
// MVID: {87b4666f-b883-4b88-a5c4-0ea178066f2f}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000001    //  ILONLY
// Image base: 0x000001F14A5A0000


// =============== CLASS MEMBERS DECLARATION ===================

.class public abstract auto ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest
       extends [mscorlib]System.Object
{
  .class auto ansi serializable sealed nested private beforefieldinit '<>c'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static initonly class AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest/'<>c' '<>9'
    .field public static class [mscorlib]System.Func`2<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode,string> '<>9__5_0'
    .method private hidebysig specialname rtspecialname static 
            void  .cctor() cil managed
    {
      // Code size       11 (0xb)
      .maxstack  8
      IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest/'<>c'::.ctor()
      IL_0005:  stsfld     class AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest/'<>c' AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest/'<>c'::'<>9'
      IL_000a:  ret
    } // end of method '<>c'::.cctor

    .method public hidebysig specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '<>c'::.ctor

    .method assembly hidebysig instance string 
            '<BuildNodeInfo>b__5_0'(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode x) cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.1
      IL_0001:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Id()
      IL_0006:  ret
    } // end of method '<>c'::'<BuildNodeInfo>b__5_0'

  } // end of class '<>c'

  .method public hidebysig static class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>> 
          GetSubflowsheets(string datapath,
                           class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase) cil managed
  {
    // Code size       180 (0xb4)
    .maxstack  4
    .locals init (class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>> V_0,
             string[] V_1,
             string[] V_2,
             int32 V_3,
             string V_4,
             string V_5,
             string V_6,
             class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool> V_7,
             string V_8,
             class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool> V_9)
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.1
    IL_0007:  ldarg.0
    IL_0008:  callvirt   instance string[] [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::GetChildPaths(string)
    IL_000d:  stloc.1
    IL_000e:  ldloc.1
    IL_000f:  brfalse    IL_00b2

    IL_0014:  ldloc.1
    IL_0015:  stloc.2
    IL_0016:  ldc.i4.0
    IL_0017:  stloc.3
    IL_0018:  br         IL_00a9

    IL_001d:  ldloc.2
    IL_001e:  ldloc.3
    IL_001f:  ldelem.ref
    IL_0020:  stloc.s    V_4
    IL_0022:  ldarg.1
    IL_0023:  ldloc.s    V_4
    IL_0025:  ldstr      "type"
    IL_002a:  ldnull
    IL_002b:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                  string,
                                                                                                  string)
    IL_0030:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
    IL_0035:  stloc.s    V_5
    IL_0037:  ldsfld     class [System.Core]System.Collections.Generic.HashSet`1<string> AspenTech.EquipmentAnalysis.Infrastructure.Common::PSVColFlowshtTypeList
    IL_003c:  ldloc.s    V_5
    IL_003e:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Contains(!0)
    IL_0043:  brfalse.s  IL_006e

    IL_0045:  ldloc.s    V_4
    IL_0047:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsPath::LeafId(string)
    IL_004c:  callvirt   instance string [mscorlib]System.String::Trim()
    IL_0051:  stloc.s    V_6
    IL_0053:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>::.ctor()
    IL_0058:  stloc.s    V_7
    IL_005a:  ldloc.s    V_7
    IL_005c:  ldloc.s    V_4
    IL_005e:  ldc.i4.1
    IL_005f:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>::Add(!0,
                                                                                                                 !1)
    IL_0064:  ldloc.0
    IL_0065:  ldloc.s    V_6
    IL_0067:  ldloc.s    V_7
    IL_0069:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>>::Add(!0,
                                                                                                                                                                                 !1)
    IL_006e:  ldsfld     class [System.Core]System.Collections.Generic.HashSet`1<string> AspenTech.EquipmentAnalysis.Infrastructure.Common::PSVFlowshtTypeList
    IL_0073:  ldloc.s    V_5
    IL_0075:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Contains(!0)
    IL_007a:  brfalse.s  IL_00a5

    IL_007c:  ldloc.s    V_4
    IL_007e:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsPath::LeafId(string)
    IL_0083:  callvirt   instance string [mscorlib]System.String::Trim()
    IL_0088:  stloc.s    V_8
    IL_008a:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>::.ctor()
    IL_008f:  stloc.s    V_9
    IL_0091:  ldloc.s    V_9
    IL_0093:  ldloc.s    V_4
    IL_0095:  ldc.i4.0
    IL_0096:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>::Add(!0,
                                                                                                                 !1)
    IL_009b:  ldloc.0
    IL_009c:  ldloc.s    V_8
    IL_009e:  ldloc.s    V_9
    IL_00a0:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>>::Add(!0,
                                                                                                                                                                                 !1)
    IL_00a5:  ldloc.3
    IL_00a6:  ldc.i4.1
    IL_00a7:  add
    IL_00a8:  stloc.3
    IL_00a9:  ldloc.3
    IL_00aa:  ldloc.2
    IL_00ab:  ldlen
    IL_00ac:  conv.i4
    IL_00ad:  blt        IL_001d

    IL_00b2:  ldloc.0
    IL_00b3:  ret
  } // end of method AspenCaseDataRequest::GetSubflowsheets

  .method public hidebysig static class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool> 
          GetFlowsheetStreams(string datapath,
                              class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase) cil managed
  {
    // Code size       293 (0x125)
    .maxstack  4
    .locals init (class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool> V_0,
             string[] V_1,
             int32 V_2,
             string V_3,
             bool V_4,
             string[] V_5,
             string V_6,
             string[] V_7,
             string V_8)
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.1
    IL_0007:  ldarg.0
    IL_0008:  callvirt   instance string[] [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::GetChildPaths(string)
    IL_000d:  stloc.1
    IL_000e:  ldc.i4.0
    IL_000f:  stloc.2
    IL_0010:  br         IL_011a

    IL_0015:  ldloc.1
    IL_0016:  ldloc.2
    IL_0017:  ldelem.ref
    IL_0018:  stloc.3
    IL_0019:  ldarg.1
    IL_001a:  ldloc.3
    IL_001b:  ldstr      "type"
    IL_0020:  ldnull
    IL_0021:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                  string,
                                                                                                  string)
    IL_0026:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
    IL_002b:  ldstr      "MaterialStreamObject"
    IL_0030:  call       bool [mscorlib]System.String::op_Inequality(string,
                                                                     string)
    IL_0035:  brtrue     IL_0116

    IL_003a:  ldc.i4.0
    IL_003b:  stloc.s    V_4
    IL_003d:  ldarg.1
    IL_003e:  ldstr      "{0}.{1}"
    IL_0043:  ldloc.3
    IL_0044:  ldstr      "Upstream Unit Operations"
    IL_0049:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_004e:  callvirt   instance string[] [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::GetChildPaths(string)
    IL_0053:  stloc.s    V_5
    IL_0055:  ldloc.s    V_5
    IL_0057:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_005c:  brtrue.s   IL_0061

    IL_005e:  ldc.i4.1
    IL_005f:  stloc.s    V_4
    IL_0061:  ldloc.s    V_5
    IL_0063:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0068:  ldc.i4.1
    IL_0069:  bne.un     IL_0108

    IL_006e:  ldarg.1
    IL_006f:  ldloc.s    V_5
    IL_0071:  ldc.i4.0
    IL_0072:  ldelem.ref
    IL_0073:  ldstr      "display_name"
    IL_0078:  ldnull
    IL_0079:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                  string,
                                                                                                  string)
    IL_007e:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
    IL_0083:  stloc.s    V_6
    IL_0085:  ldloc.s    V_6
    IL_0087:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_008c:  brtrue.s   IL_0108

    IL_008e:  ldloc.s    V_6
    IL_0090:  callvirt   instance string [mscorlib]System.String::ToLower()
    IL_0095:  ldstr      "feederblock"
    IL_009a:  callvirt   instance bool [mscorlib]System.String::StartsWith(string)
    IL_009f:  brfalse.s  IL_0108

    IL_00a1:  ldarg.1
    IL_00a2:  ldstr      "{0}.{1}"
    IL_00a7:  ldloc.3
    IL_00a8:  ldstr      "Downstream Unit Operations"
    IL_00ad:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_00b2:  callvirt   instance string[] [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::GetChildPaths(string)
    IL_00b7:  stloc.s    V_7
    IL_00b9:  ldloc.s    V_7
    IL_00bb:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_00c0:  ldc.i4.1
    IL_00c1:  ble.s      IL_00c8

    IL_00c3:  ldc.i4.1
    IL_00c4:  stloc.s    V_4
    IL_00c6:  br.s       IL_0108

    IL_00c8:  ldloc.s    V_7
    IL_00ca:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_00cf:  ldc.i4.1
    IL_00d0:  bne.un.s   IL_0108

    IL_00d2:  ldarg.1
    IL_00d3:  ldloc.s    V_7
    IL_00d5:  ldc.i4.0
    IL_00d6:  ldelem.ref
    IL_00d7:  ldstr      "display_name"
    IL_00dc:  ldnull
    IL_00dd:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                  string,
                                                                                                  string)
    IL_00e2:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
    IL_00e7:  stloc.s    V_8
    IL_00e9:  ldloc.s    V_8
    IL_00eb:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_00f0:  brtrue.s   IL_0108

    IL_00f2:  ldloc.s    V_8
    IL_00f4:  callvirt   instance string [mscorlib]System.String::ToLower()
    IL_00f9:  ldstr      "productblock"
    IL_00fe:  callvirt   instance bool [mscorlib]System.String::StartsWith(string)
    IL_0103:  brtrue.s   IL_0108

    IL_0105:  ldc.i4.1
    IL_0106:  stloc.s    V_4
    IL_0108:  ldloc.0
    IL_0109:  ldloc.3
    IL_010a:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsPath::LeafId(string)
    IL_010f:  ldloc.s    V_4
    IL_0111:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>::Add(!0,
                                                                                                                 !1)
    IL_0116:  ldloc.2
    IL_0117:  ldc.i4.1
    IL_0118:  add
    IL_0119:  stloc.2
    IL_011a:  ldloc.2
    IL_011b:  ldloc.1
    IL_011c:  ldlen
    IL_011d:  conv.i4
    IL_011e:  blt        IL_0015

    IL_0123:  ldloc.0
    IL_0124:  ret
  } // end of method AspenCaseDataRequest::GetFlowsheetStreams

  .method public hidebysig static class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool> 
          GetSubFlowsheetStreams(string spath,
                                 bool iscolumn,
                                 class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase) cil managed
  {
    // Code size       43 (0x2b)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldsfld     string [mscorlib]System.String::Empty
    IL_0005:  stloc.0
    IL_0006:  ldarg.1
    IL_0007:  brfalse.s  IL_0017

    IL_0009:  ldstr      "{0}.My SubFlowsheet.Streams"
    IL_000e:  ldarg.0
    IL_000f:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_0014:  stloc.0
    IL_0015:  br.s       IL_0023

    IL_0017:  ldstr      "{0}.Streams"
    IL_001c:  ldarg.0
    IL_001d:  call       string [mscorlib]System.String::Format(string,
                                                                object)
    IL_0022:  stloc.0
    IL_0023:  ldloc.0
    IL_0024:  ldarg.2
    IL_0025:  call       class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool> AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetFlowsheetStreams(string,
                                                                                                                                                                                   class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_002a:  ret
  } // end of method AspenCaseDataRequest::GetSubFlowsheetStreams

  .method private hidebysig static class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode 
          GetNodeByPath(string datapath,
                        class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase) cil managed
  {
    // Code size       47 (0x2f)
    .maxstack  2
    .locals init (class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_0)
    IL_0000:  ldarg.0
    IL_0001:  callvirt   instance string [mscorlib]System.String::ToLowerInvariant()
    IL_0006:  ldstr      "top."
    IL_000b:  callvirt   instance bool [mscorlib]System.String::StartsWith(string)
    IL_0010:  brfalse.s  IL_001b

    IL_0012:  ldarg.0
    IL_0013:  ldc.i4.4
    IL_0014:  callvirt   instance string [mscorlib]System.String::Substring(int32)
    IL_0019:  starg.s    datapath
    IL_001b:  ldarg.1
    IL_001c:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::get_TopNode()
    IL_0021:  stloc.0
    IL_0022:  ldloc.0
    IL_0023:  brfalse.s  IL_002d

    IL_0025:  ldloc.0
    IL_0026:  ldarg.0
    IL_0027:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::ResolveNode(string)
    IL_002c:  ret

    IL_002d:  ldnull
    IL_002e:  ret
  } // end of method AspenCaseDataRequest::GetNodeByPath

  .method private hidebysig static class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode> 
          GetChildren(string datapath,
                      class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase) cil managed
  {
    // Code size       25 (0x19)
    .maxstack  2
    .locals init (class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetNodeByPath(string,
                                                                                                                                                             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_0007:  stloc.0
    IL_0008:  ldloc.0
    IL_0009:  brfalse.s  IL_0017

    IL_000b:  ldloc.0
    IL_000c:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_0011:  call       class [mscorlib]System.Collections.Generic.List`1<!!0> [System.Core]System.Linq.Enumerable::ToList<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0016:  ret

    IL_0017:  ldnull
    IL_0018:  ret
  } // end of method AspenCaseDataRequest::GetChildren

  .method public hidebysig static class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo> 
          BuildNodeInfo(string datapath,
                        class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase) cil managed
  {
    // Code size       348 (0x15c)
    .maxstack  3
    .locals init (class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode> V_0,
             class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo> V_1,
             string[] V_2,
             int32 V_3,
             string V_4,
             valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo V_5,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode> V_6,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_7,
             valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo V_8)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode> AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetChildren(string,
                                                                                                                                                                                                              class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_0007:  stloc.0
    IL_0008:  ldloc.0
    IL_0009:  brtrue.s   IL_000d

    IL_000b:  ldnull
    IL_000c:  ret

    IL_000d:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::.ctor()
    IL_0012:  stloc.1
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Count()
    IL_0019:  brtrue.s   IL_001d

    IL_001b:  ldloc.1
    IL_001c:  ret

    IL_001d:  ldarg.1
    IL_001e:  ldarg.0
    IL_001f:  ldstr      "child_ids"
    IL_0024:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                  string)
    IL_0029:  call       string[] [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToStringArray(object)
    IL_002e:  stloc.2
    IL_002f:  ldloc.2
    IL_0030:  brfalse    IL_00b6

    IL_0035:  ldloc.2
    IL_0036:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_003b:  ldc.i4.0
    IL_003c:  ble.s      IL_00b6

    IL_003e:  ldloc.2
    IL_003f:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0044:  ldloc.0
    IL_0045:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Count()
    IL_004a:  beq.s      IL_00b6

    IL_004c:  ldc.i4.0
    IL_004d:  stloc.3
    IL_004e:  br.s       IL_00a8

    IL_0050:  ldarg.0
    IL_0051:  ldloc.2
    IL_0052:  ldloc.3
    IL_0053:  ldelem.ref
    IL_0054:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsPath::CombinePathAndId(string,
                                                                                                 string)
    IL_0059:  stloc.s    V_4
    IL_005b:  ldloca.s   V_5
    IL_005d:  initobj    AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo
    IL_0063:  ldloca.s   V_5
    IL_0065:  ldc.i4.1
    IL_0066:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::isleaf
    IL_006b:  ldloca.s   V_5
    IL_006d:  ldloc.s    V_4
    IL_006f:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::path
    IL_0074:  ldloca.s   V_5
    IL_0076:  ldloc.2
    IL_0077:  ldloc.3
    IL_0078:  ldelem.ref
    IL_0079:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::id
    IL_007e:  ldloca.s   V_5
    IL_0080:  ldarg.1
    IL_0081:  ldloc.s    V_4
    IL_0083:  call       string AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetChildDataType(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                                  string)
    IL_0088:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::'type'
    IL_008d:  ldloca.s   V_5
    IL_008f:  ldarg.1
    IL_0090:  ldloc.s    V_4
    IL_0092:  call       string AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetChildContainerType(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                                       string)
    IL_0097:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::containertype
    IL_009c:  ldloc.1
    IL_009d:  ldloc.s    V_5
    IL_009f:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::Add(!0)
    IL_00a4:  ldloc.3
    IL_00a5:  ldc.i4.1
    IL_00a6:  add
    IL_00a7:  stloc.3
    IL_00a8:  ldloc.3
    IL_00a9:  ldloc.2
    IL_00aa:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_00af:  blt.s      IL_0050

    IL_00b1:  br         IL_015a

    IL_00b6:  ldloc.0
    IL_00b7:  ldsfld     class [mscorlib]System.Func`2<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode,string> AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest/'<>c'::'<>9__5_0'
    IL_00bc:  dup
    IL_00bd:  brtrue.s   IL_00d6

    IL_00bf:  pop
    IL_00c0:  ldsfld     class AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest/'<>c' AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest/'<>c'::'<>9'
    IL_00c5:  ldftn      instance string AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest/'<>c'::'<BuildNodeInfo>b__5_0'(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode)
    IL_00cb:  newobj     instance void class [mscorlib]System.Func`2<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode,string>::.ctor(object,
                                                                                                                                         native int)
    IL_00d0:  dup
    IL_00d1:  stsfld     class [mscorlib]System.Func`2<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode,string> AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest/'<>c'::'<>9__5_0'
    IL_00d6:  call       class [System.Core]System.Linq.IOrderedEnumerable`1<!!0> [System.Core]System.Linq.Enumerable::OrderBy<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode,string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                            class [mscorlib]System.Func`2<!!0,!!1>)
    IL_00db:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.Generic.IEnumerable`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::GetEnumerator()
    IL_00e0:  stloc.s    V_6
    .try
    {
      IL_00e2:  br.s       IL_0143

      IL_00e4:  ldloc.s    V_6
      IL_00e6:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Current()
      IL_00eb:  stloc.s    V_7
      IL_00ed:  ldloca.s   V_8
      IL_00ef:  initobj    AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo
      IL_00f5:  ldloca.s   V_8
      IL_00f7:  ldloc.s    V_7
      IL_00f9:  callvirt   instance bool [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_IsLeaf()
      IL_00fe:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::isleaf
      IL_0103:  ldloca.s   V_8
      IL_0105:  ldloc.s    V_7
      IL_0107:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Path()
      IL_010c:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::path
      IL_0111:  ldloca.s   V_8
      IL_0113:  ldloc.s    V_7
      IL_0115:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_NodeType()
      IL_011a:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::'type'
      IL_011f:  ldloca.s   V_8
      IL_0121:  ldloc.s    V_7
      IL_0123:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Id()
      IL_0128:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::id
      IL_012d:  ldloca.s   V_8
      IL_012f:  ldloc.s    V_7
      IL_0131:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ContainerType()
      IL_0136:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::containertype
      IL_013b:  ldloc.1
      IL_013c:  ldloc.s    V_8
      IL_013e:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::Add(!0)
      IL_0143:  ldloc.s    V_6
      IL_0145:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_014a:  brtrue.s   IL_00e4

      IL_014c:  leave.s    IL_015a

    }  // end .try
    finally
    {
      IL_014e:  ldloc.s    V_6
      IL_0150:  brfalse.s  IL_0159

      IL_0152:  ldloc.s    V_6
      IL_0154:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0159:  endfinally
    }  // end handler
    IL_015a:  ldloc.1
    IL_015b:  ret
  } // end of method AspenCaseDataRequest::BuildNodeInfo

  .method public hidebysig static class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo> 
          RetrieveStreamConnectionInfo(string datapath,
                                       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase) cil managed
  {
    // Code size       360 (0x168)
    .maxstack  3
    .locals init (class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode> V_0,
             class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo> V_1,
             valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode> V_2,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_3,
             valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo V_4,
             valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo V_5,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_6,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_7,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_8,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_9)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode> AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetChildren(string,
                                                                                                                                                                                                              class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_0007:  stloc.0
    IL_0008:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo>::.ctor()
    IL_000d:  stloc.1
    IL_000e:  ldloc.0
    IL_000f:  brfalse    IL_0166

    IL_0014:  ldloc.0
    IL_0015:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<!0> class [mscorlib]System.Collections.Generic.List`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::GetEnumerator()
    IL_001a:  stloc.2
    .try
    {
      IL_001b:  br         IL_014a

      IL_0020:  ldloca.s   V_2
      IL_0022:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Current()
      IL_0027:  stloc.3
      IL_0028:  ldstr      "MaterialStreamObject"
      IL_002d:  ldloc.3
      IL_002e:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_NodeType()
      IL_0033:  ldc.i4.1
      IL_0034:  call       int32 [mscorlib]System.String::Compare(string,
                                                                  string,
                                                                  bool)
      IL_0039:  brtrue     IL_014a

      IL_003e:  ldloca.s   V_4
      IL_0040:  initobj    AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo
      IL_0046:  ldloca.s   V_4
      IL_0048:  ldloc.3
      IL_0049:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Path()
      IL_004e:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::path
      IL_0053:  ldloca.s   V_4
      IL_0055:  ldloc.3
      IL_0056:  callvirt   instance bool [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_IsLeaf()
      IL_005b:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::isleaf
      IL_0060:  ldloca.s   V_4
      IL_0062:  ldloc.3
      IL_0063:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_NodeType()
      IL_0068:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::'type'
      IL_006d:  ldloca.s   V_4
      IL_006f:  ldloc.3
      IL_0070:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Id()
      IL_0075:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::id
      IL_007a:  ldloca.s   V_4
      IL_007c:  ldloc.3
      IL_007d:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ContainerType()
      IL_0082:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::containertype
      IL_0087:  ldloc.3
      IL_0088:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Id()
      IL_008d:  pop
      IL_008e:  ldloc.3
      IL_008f:  ldstr      "Upstream Unit Operations"
      IL_0094:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::ResolveNode(string)
      IL_0099:  stloc.s    V_6
      IL_009b:  ldloc.s    V_6
      IL_009d:  brfalse.s  IL_00d6

      IL_009f:  ldloc.s    V_6
      IL_00a1:  callvirt   instance bool [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_HasChildren()
      IL_00a6:  brfalse.s  IL_00d6

      IL_00a8:  ldloc.s    V_6
      IL_00aa:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
      IL_00af:  call       !!0 [System.Core]System.Linq.Enumerable::FirstOrDefault<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
      IL_00b4:  stloc.s    V_8
      IL_00b6:  ldloca.s   V_5
      IL_00b8:  ldloc.s    V_8
      IL_00ba:  brtrue.s   IL_00bf

      IL_00bc:  ldnull
      IL_00bd:  br.s       IL_00c6

      IL_00bf:  ldloc.s    V_8
      IL_00c1:  call       instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Id()
      IL_00c6:  dup
      IL_00c7:  brtrue.s   IL_00cf

      IL_00c9:  pop
      IL_00ca:  ldsfld     string [mscorlib]System.String::Empty
      IL_00cf:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo::upstreamUo
      IL_00d4:  br.s       IL_00e2

      IL_00d6:  ldloca.s   V_5
      IL_00d8:  ldsfld     string [mscorlib]System.String::Empty
      IL_00dd:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo::upstreamUo
      IL_00e2:  ldloc.3
      IL_00e3:  ldstr      "Downstream Unit Operations"
      IL_00e8:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::ResolveNode(string)
      IL_00ed:  stloc.s    V_7
      IL_00ef:  ldloc.s    V_7
      IL_00f1:  brfalse.s  IL_012a

      IL_00f3:  ldloc.s    V_7
      IL_00f5:  callvirt   instance bool [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_HasChildren()
      IL_00fa:  brfalse.s  IL_012a

      IL_00fc:  ldloc.s    V_7
      IL_00fe:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
      IL_0103:  call       !!0 [System.Core]System.Linq.Enumerable::FirstOrDefault<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
      IL_0108:  stloc.s    V_9
      IL_010a:  ldloca.s   V_5
      IL_010c:  ldloc.s    V_9
      IL_010e:  brtrue.s   IL_0113

      IL_0110:  ldnull
      IL_0111:  br.s       IL_011a

      IL_0113:  ldloc.s    V_9
      IL_0115:  call       instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Id()
      IL_011a:  dup
      IL_011b:  brtrue.s   IL_0123

      IL_011d:  pop
      IL_011e:  ldsfld     string [mscorlib]System.String::Empty
      IL_0123:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo::downstreamUo
      IL_0128:  br.s       IL_0136

      IL_012a:  ldloca.s   V_5
      IL_012c:  ldsfld     string [mscorlib]System.String::Empty
      IL_0131:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo::downstreamUo
      IL_0136:  ldloc.1
      IL_0137:  ldloc.s    V_4
      IL_0139:  callvirt   instance bool class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo>::ContainsKey(!0)
      IL_013e:  brtrue.s   IL_014a

      IL_0140:  ldloc.1
      IL_0141:  ldloc.s    V_4
      IL_0143:  ldloc.s    V_5
      IL_0145:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo>::Add(!0,
                                                                                                                                                                                                                                                  !1)
      IL_014a:  ldloca.s   V_2
      IL_014c:  call       instance bool valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::MoveNext()
      IL_0151:  brtrue     IL_0020

      IL_0156:  leave.s    IL_0166

    }  // end .try
    finally
    {
      IL_0158:  ldloca.s   V_2
      IL_015a:  constrained. valuetype [mscorlib]System.Collections.Generic.List`1/Enumerator<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>
      IL_0160:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0165:  endfinally
    }  // end handler
    IL_0166:  ldloc.1
    IL_0167:  ret
  } // end of method AspenCaseDataRequest::RetrieveStreamConnectionInfo

  .method public hidebysig static class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode 
          GetPSVSizingNode(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase,
                           string path) cil managed
  {
    // Code size       25 (0x19)
    .maxstack  2
    .locals init (class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.0
    IL_0002:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetNodeByPath(string,
                                                                                                                                                             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_0007:  stloc.0
    IL_0008:  ldloc.0
    IL_0009:  brtrue.s   IL_000d

    IL_000b:  ldnull
    IL_000c:  ret

    IL_000d:  ldloc.0
    IL_000e:  ldstr      "PSV Sizing Calculation"
    IL_0013:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::ResolveNode(string)
    IL_0018:  ret
  } // end of method AspenCaseDataRequest::GetPSVSizingNode

  .method public hidebysig static class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode 
          GetEmergencyScenarioNode(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase,
                                   string path) cil managed
  {
    // Code size       25 (0x19)
    .maxstack  2
    .locals init (class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.0
    IL_0002:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetNodeByPath(string,
                                                                                                                                                             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_0007:  stloc.0
    IL_0008:  ldloc.0
    IL_0009:  brtrue.s   IL_000d

    IL_000b:  ldnull
    IL_000c:  ret

    IL_000d:  ldloc.0
    IL_000e:  ldstr      "Emergency Scenario"
    IL_0013:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::ResolveNode(string)
    IL_0018:  ret
  } // end of method AspenCaseDataRequest::GetEmergencyScenarioNode

  .method private hidebysig static string 
          GetChildDataType(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase,
                           string path) cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  3
    .locals init (object V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldstr      "type"
    IL_0007:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                  string)
    IL_000c:  stloc.0
    IL_000d:  ldloc.0
    IL_000e:  brfalse.s  IL_0017

    IL_0010:  ldloc.0
    IL_0011:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
    IL_0016:  ret

    IL_0017:  ldsfld     string [mscorlib]System.String::Empty
    IL_001c:  ret
  } // end of method AspenCaseDataRequest::GetChildDataType

  .method private hidebysig static string 
          GetChildContainerType(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase,
                                string path) cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  3
    .locals init (object V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldstr      "container_type"
    IL_0007:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                  string)
    IL_000c:  stloc.0
    IL_000d:  ldloc.0
    IL_000e:  brfalse.s  IL_0017

    IL_0010:  ldloc.0
    IL_0011:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToString(object)
    IL_0016:  ret

    IL_0017:  ldsfld     string [mscorlib]System.String::Empty
    IL_001c:  ret
  } // end of method AspenCaseDataRequest::GetChildContainerType

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest

.class public abstract auto ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfoHelper
       extends [mscorlib]System.Object
{
  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo 
          GetValveNodeInfo(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase,
                           string path) cil managed
  {
    // Code size       226 (0xe2)
    .maxstack  3
    .locals init (class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_0,
             valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo V_1,
             int32 V_2,
             string V_3)
    IL_0000:  ldnull
    IL_0001:  stloc.0
    IL_0002:  ldloca.s   V_1
    IL_0004:  initobj    AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo
    IL_000a:  ldarg.0
    IL_000b:  ldarg.1
    IL_000c:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetPSVSizingNode(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                                                                                string)
    IL_0011:  stloc.0
    IL_0012:  ldloc.0
    IL_0013:  brfalse    IL_00e0

    IL_0018:  ldloc.0
    IL_0019:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_DisplayValue()
    IL_001e:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_0023:  brtrue     IL_00e0

    IL_0028:  ldloca.s   V_1
    IL_002a:  ldloc.0
    IL_002b:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_DisplayValue()
    IL_0030:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::id
    IL_0035:  ldloca.s   V_1
    IL_0037:  ldloc.0
    IL_0038:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Path()
    IL_003d:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::path
    IL_0042:  ldloca.s   V_1
    IL_0044:  ldloc.0
    IL_0045:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_NodeType()
    IL_004a:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::'type'
    IL_004f:  ldloca.s   V_1
    IL_0051:  ldloc.0
    IL_0052:  callvirt   instance bool [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_IsLeaf()
    IL_0057:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::isleaf
    IL_005c:  ldloca.s   V_1
    IL_005e:  ldloc.0
    IL_005f:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ContainerType()
    IL_0064:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::containertype
    IL_0069:  ldloc.0
    IL_006a:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_006f:  callvirt   instance int32 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Count()
    IL_0074:  ldc.i4.0
    IL_0075:  ble.s      IL_00e0

    IL_0077:  ldc.i4.0
    IL_0078:  stloc.2
    IL_0079:  br.s       IL_00d2

    IL_007b:  ldloc.0
    IL_007c:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_0081:  ldloc.2
    IL_0082:  callvirt   instance !0 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Item(int32)
    IL_0087:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Id()
    IL_008c:  callvirt   instance string [mscorlib]System.String::Trim()
    IL_0091:  ldstr      "PRD Type"
    IL_0096:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_009b:  brfalse.s  IL_00ce

    IL_009d:  ldloc.0
    IL_009e:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_00a3:  ldloc.2
    IL_00a4:  callvirt   instance !0 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Item(int32)
    IL_00a9:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_DisplayValue()
    IL_00ae:  callvirt   instance string [mscorlib]System.String::Trim()
    IL_00b3:  stloc.3
    IL_00b4:  ldloca.s   V_1
    IL_00b6:  ldloc.3
    IL_00b7:  ldstr      "Rupture Disk"
    IL_00bc:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00c1:  brtrue.s   IL_00c6

    IL_00c3:  ldc.i4.0
    IL_00c4:  br.s       IL_00c7

    IL_00c6:  ldc.i4.1
    IL_00c7:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::prdType
    IL_00cc:  br.s       IL_00e0

    IL_00ce:  ldloc.2
    IL_00cf:  ldc.i4.1
    IL_00d0:  add
    IL_00d1:  stloc.2
    IL_00d2:  ldloc.2
    IL_00d3:  ldloc.0
    IL_00d4:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_00d9:  callvirt   instance int32 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Count()
    IL_00de:  blt.s      IL_007b

    IL_00e0:  ldloc.1
    IL_00e1:  ret
  } // end of method CxsNodeInfoHelper::GetValveNodeInfo

  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo 
          GetScenarioNodeInfo(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase,
                              string path,
                              int32 index) cil managed
  {
    // Code size       295 (0x127)
    .maxstack  4
    .locals init (class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_0,
             valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo V_1,
             string[] V_2,
             string V_3,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_4)
    IL_0000:  ldnull
    IL_0001:  stloc.0
    IL_0002:  ldloca.s   V_1
    IL_0004:  initobj    AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo
    IL_000a:  ldarg.0
    IL_000b:  ldarg.1
    IL_000c:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetEmergencyScenarioNode(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                                                                                        string)
    IL_0011:  stloc.0
    IL_0012:  ldloc.0
    IL_0013:  brfalse    IL_0125

    IL_0018:  ldloc.0
    IL_0019:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_001e:  callvirt   instance int32 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Count()
    IL_0023:  brfalse    IL_0125

    IL_0028:  ldarg.0
    IL_0029:  ldstr      "{0}.{1}"
    IL_002e:  ldarg.1
    IL_002f:  ldstr      "Emergency Scenario"
    IL_0034:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_0039:  ldstr      "child_ids"
    IL_003e:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                  string)
    IL_0043:  call       string[] [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToStringArray(object)
    IL_0048:  stloc.2
    IL_0049:  ldloc.2
    IL_004a:  brfalse.s  IL_00b5

    IL_004c:  ldloc.2
    IL_004d:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0052:  ldc.i4.0
    IL_0053:  ble.s      IL_00b5

    IL_0055:  ldloc.2
    IL_0056:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_005b:  ldloc.0
    IL_005c:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_0061:  callvirt   instance int32 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Count()
    IL_0066:  beq.s      IL_00b5

    IL_0068:  ldstr      "{0}.{1}"
    IL_006d:  ldarg.1
    IL_006e:  ldstr      "Emergency Scenario"
    IL_0073:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_0078:  ldloc.2
    IL_0079:  ldarg.2
    IL_007a:  ldelem.ref
    IL_007b:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsPath::CombinePathAndId(string,
                                                                                                 string)
    IL_0080:  stloc.3
    IL_0081:  ldloca.s   V_1
    IL_0083:  ldloc.2
    IL_0084:  ldarg.2
    IL_0085:  ldelem.ref
    IL_0086:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::id
    IL_008b:  ldloca.s   V_1
    IL_008d:  ldloc.3
    IL_008e:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::path
    IL_0093:  ldloca.s   V_1
    IL_0095:  ldstr      "Attachment"
    IL_009a:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::'type'
    IL_009f:  ldloca.s   V_1
    IL_00a1:  ldc.i4.1
    IL_00a2:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::isleaf
    IL_00a7:  ldloca.s   V_1
    IL_00a9:  ldstr      ""
    IL_00ae:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::containertype
    IL_00b3:  br.s       IL_0125

    IL_00b5:  ldarg.2
    IL_00b6:  ldloc.0
    IL_00b7:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_00bc:  callvirt   instance int32 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Count()
    IL_00c1:  bge.s      IL_0125

    IL_00c3:  ldloc.0
    IL_00c4:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_00c9:  ldarg.2
    IL_00ca:  callvirt   instance !0 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Item(int32)
    IL_00cf:  stloc.s    V_4
    IL_00d1:  ldloc.s    V_4
    IL_00d3:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_DisplayValue()
    IL_00d8:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
    IL_00dd:  brtrue.s   IL_0125

    IL_00df:  ldloca.s   V_1
    IL_00e1:  ldloc.s    V_4
    IL_00e3:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_DisplayValue()
    IL_00e8:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::id
    IL_00ed:  ldloca.s   V_1
    IL_00ef:  ldloc.s    V_4
    IL_00f1:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Path()
    IL_00f6:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::path
    IL_00fb:  ldloca.s   V_1
    IL_00fd:  ldloc.s    V_4
    IL_00ff:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_NodeType()
    IL_0104:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::'type'
    IL_0109:  ldloca.s   V_1
    IL_010b:  ldloc.s    V_4
    IL_010d:  callvirt   instance bool [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_IsLeaf()
    IL_0112:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::isleaf
    IL_0117:  ldloca.s   V_1
    IL_0119:  ldloc.s    V_4
    IL_011b:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ContainerType()
    IL_0120:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::containertype
    IL_0125:  ldloc.1
    IL_0126:  ret
  } // end of method CxsNodeInfoHelper::GetScenarioNodeInfo

  .method public hidebysig static class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo> 
          GetScenarioNodesInfo(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase,
                               string path) cil managed
  {
    // Code size       368 (0x170)
    .maxstack  4
    .locals init (class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_0,
             class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo> V_1,
             string[] V_2,
             int32 V_3,
             valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo V_4,
             string V_5,
             class [mscorlib]System.Collections.Generic.IEnumerator`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode> V_6,
             class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode V_7,
             valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo V_8,
             valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo V_9)
    IL_0000:  ldnull
    IL_0001:  stloc.0
    IL_0002:  ldarg.0
    IL_0003:  ldarg.1
    IL_0004:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetEmergencyScenarioNode(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase,
                                                                                                                                                                        string)
    IL_0009:  stloc.0
    IL_000a:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::.ctor()
    IL_000f:  stloc.1
    IL_0010:  ldloc.0
    IL_0011:  brfalse    IL_016e

    IL_0016:  ldloc.0
    IL_0017:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_001c:  callvirt   instance int32 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Count()
    IL_0021:  brfalse    IL_016e

    IL_0026:  ldarg.0
    IL_0027:  ldstr      "{0}.{1}"
    IL_002c:  ldarg.1
    IL_002d:  ldstr      "Emergency Scenario"
    IL_0032:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_0037:  ldstr      "child_ids"
    IL_003c:  callvirt   instance object [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase::BatchGet(string,
                                                                                                  string)
    IL_0041:  call       string[] [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsConverter::ValueToStringArray(object)
    IL_0046:  stloc.2
    IL_0047:  ldloc.2
    IL_0048:  brfalse    IL_00df

    IL_004d:  ldloc.2
    IL_004e:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0053:  ldc.i4.0
    IL_0054:  ble        IL_00df

    IL_0059:  ldloc.2
    IL_005a:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_005f:  ldloc.0
    IL_0060:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_0065:  callvirt   instance int32 class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Count()
    IL_006a:  beq.s      IL_00df

    IL_006c:  ldc.i4.0
    IL_006d:  stloc.3
    IL_006e:  br.s       IL_00d1

    IL_0070:  ldloca.s   V_4
    IL_0072:  initobj    AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo
    IL_0078:  ldstr      "{0}.{1}"
    IL_007d:  ldarg.1
    IL_007e:  ldstr      "Emergency Scenario"
    IL_0083:  call       string [mscorlib]System.String::Format(string,
                                                                object,
                                                                object)
    IL_0088:  ldloc.2
    IL_0089:  ldloc.3
    IL_008a:  ldelem.ref
    IL_008b:  call       string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsPath::CombinePathAndId(string,
                                                                                                 string)
    IL_0090:  stloc.s    V_5
    IL_0092:  ldloca.s   V_4
    IL_0094:  ldloc.2
    IL_0095:  ldloc.3
    IL_0096:  ldelem.ref
    IL_0097:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::id
    IL_009c:  ldloca.s   V_4
    IL_009e:  ldloc.s    V_5
    IL_00a0:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::path
    IL_00a5:  ldloca.s   V_4
    IL_00a7:  ldstr      "Attachment"
    IL_00ac:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::'type'
    IL_00b1:  ldloca.s   V_4
    IL_00b3:  ldc.i4.1
    IL_00b4:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::isleaf
    IL_00b9:  ldloca.s   V_4
    IL_00bb:  ldstr      ""
    IL_00c0:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::containertype
    IL_00c5:  ldloc.1
    IL_00c6:  ldloc.s    V_4
    IL_00c8:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::Add(!0)
    IL_00cd:  ldloc.3
    IL_00ce:  ldc.i4.1
    IL_00cf:  add
    IL_00d0:  stloc.3
    IL_00d1:  ldloc.3
    IL_00d2:  ldloc.2
    IL_00d3:  call       int32 [System.Core]System.Linq.Enumerable::Count<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_00d8:  blt.s      IL_0070

    IL_00da:  br         IL_016c

    IL_00df:  ldloc.0
    IL_00e0:  callvirt   instance class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNodeCollection [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ChildNodes()
    IL_00e5:  callvirt   instance class [mscorlib]System.Collections.Generic.IEnumerator`1<!0> class [mscorlib]System.Collections.ObjectModel.Collection`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::GetEnumerator()
    IL_00ea:  stloc.s    V_6
    .try
    {
      IL_00ec:  br.s       IL_0155

      IL_00ee:  ldloc.s    V_6
      IL_00f0:  callvirt   instance !0 class [mscorlib]System.Collections.Generic.IEnumerator`1<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode>::get_Current()
      IL_00f5:  stloc.s    V_7
      IL_00f7:  ldloc.s    V_7
      IL_00f9:  brfalse.s  IL_0155

      IL_00fb:  ldloca.s   V_9
      IL_00fd:  initobj    AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo
      IL_0103:  ldloca.s   V_9
      IL_0105:  ldloc.s    V_7
      IL_0107:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_DisplayValue()
      IL_010c:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::id
      IL_0111:  ldloca.s   V_9
      IL_0113:  ldloc.s    V_7
      IL_0115:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_Path()
      IL_011a:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::path
      IL_011f:  ldloca.s   V_9
      IL_0121:  ldloc.s    V_7
      IL_0123:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_NodeType()
      IL_0128:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::'type'
      IL_012d:  ldloca.s   V_9
      IL_012f:  ldloc.s    V_7
      IL_0131:  callvirt   instance bool [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_IsLeaf()
      IL_0136:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::isleaf
      IL_013b:  ldloca.s   V_9
      IL_013d:  ldloc.s    V_7
      IL_013f:  callvirt   instance string [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsNode::get_ContainerType()
      IL_0144:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo::containertype
      IL_0149:  ldloc.s    V_9
      IL_014b:  stloc.s    V_8
      IL_014d:  ldloc.1
      IL_014e:  ldloc.s    V_8
      IL_0150:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::Add(!0)
      IL_0155:  ldloc.s    V_6
      IL_0157:  callvirt   instance bool [mscorlib]System.Collections.IEnumerator::MoveNext()
      IL_015c:  brtrue.s   IL_00ee

      IL_015e:  leave.s    IL_016c

    }  // end .try
    finally
    {
      IL_0160:  ldloc.s    V_6
      IL_0162:  brfalse.s  IL_016b

      IL_0164:  ldloc.s    V_6
      IL_0166:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_016b:  endfinally
    }  // end handler
    IL_016c:  ldloc.1
    IL_016d:  ret

    IL_016e:  ldloc.1
    IL_016f:  ret
  } // end of method CxsNodeInfoHelper::GetScenarioNodesInfo

  .method public hidebysig static valuetype [mscorlib]System.ValueTuple`3<class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>,class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>> 
          CollectUoAndStream(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase,
                             string path) cil managed
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.CompilerServices.TupleElementNamesAttribute::.ctor(string[]) = ( 01 00 03 00 00 00 05 66 65 65 64 73 07 6F 75 74   // .......feeds.out
                                                                                                                    6C 65 74 73 11 73 74 61 6E 64 61 6C 6F 6E 65 53   // lets.standaloneS
                                                                                                                    74 72 65 61 6D 73 00 00 )                         // treams..
    // Code size       243 (0xf3)
    .maxstack  3
    .locals init (class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>> V_0,
             class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>> V_1,
             class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo> V_2,
             valuetype [mscorlib]System.Collections.Generic.Dictionary`2/Enumerator<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo> V_3,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo> V_4,
             bool V_5,
             bool V_6,
             valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo V_7,
             string V_8,
             string V_9)
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>::.ctor()
    IL_000b:  stloc.1
    IL_000c:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::.ctor()
    IL_0011:  stloc.2
    IL_0012:  ldarg.1
    IL_0013:  ldarg.0
    IL_0014:  call       class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo> AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::RetrieveStreamConnectionInfo(string,
                                                                                                                                                                                                                                                                                                                           class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_0019:  callvirt   instance valuetype [mscorlib]System.Collections.Generic.Dictionary`2/Enumerator<!0,!1> class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo>::GetEnumerator()
    IL_001e:  stloc.3
    .try
    {
      IL_001f:  br         IL_00ce

      IL_0024:  ldloca.s   V_3
      IL_0026:  call       instance valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<!0,!1> valuetype [mscorlib]System.Collections.Generic.Dictionary`2/Enumerator<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo>::get_Current()
      IL_002b:  stloc.s    V_4
      IL_002d:  ldc.i4.0
      IL_002e:  stloc.s    V_5
      IL_0030:  ldc.i4.0
      IL_0031:  stloc.s    V_6
      IL_0033:  ldloca.s   V_4
      IL_0035:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo>::get_Key()
      IL_003a:  stloc.s    V_7
      IL_003c:  ldloca.s   V_4
      IL_003e:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo>::get_Value()
      IL_0043:  dup
      IL_0044:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo::upstreamUo
      IL_0049:  stloc.s    V_8
      IL_004b:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo::downstreamUo
      IL_0050:  stloc.s    V_9
      IL_0052:  ldloc.s    V_8
      IL_0054:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
      IL_0059:  brtrue.s   IL_007a

      IL_005b:  ldloc.s    V_8
      IL_005d:  callvirt   instance string [mscorlib]System.String::ToLowerInvariant()
      IL_0062:  ldstr      "feeder"
      IL_0067:  callvirt   instance bool [mscorlib]System.String::StartsWith(string)
      IL_006c:  brtrue.s   IL_007a

      IL_006e:  ldloc.s    V_8
      IL_0070:  ldloc.s    V_7
      IL_0072:  ldloc.1
      IL_0073:  call       void AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfoHelper::AddTargetToCollection(string,
                                                                                                                    valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,
                                                                                                                    class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>)
      IL_0078:  br.s       IL_007d

      IL_007a:  ldc.i4.1
      IL_007b:  stloc.s    V_5
      IL_007d:  ldloc.s    V_9
      IL_007f:  callvirt   instance string [mscorlib]System.String::ToLowerInvariant()
      IL_0084:  ldstr      "product"
      IL_0089:  callvirt   instance bool [mscorlib]System.String::StartsWith(string)
      IL_008e:  brfalse.s  IL_0093

      IL_0090:  ldc.i4.1
      IL_0091:  stloc.s    V_6
      IL_0093:  ldloc.s    V_5
      IL_0095:  ldloc.s    V_6
      IL_0097:  and
      IL_0098:  brfalse.s  IL_00a4

      IL_009a:  ldloc.2
      IL_009b:  ldloc.s    V_7
      IL_009d:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::Add(!0)
      IL_00a2:  br.s       IL_00ce

      IL_00a4:  ldloc.s    V_5
      IL_00a6:  brfalse.s  IL_00ce

      IL_00a8:  ldloc.s    V_9
      IL_00aa:  call       bool [mscorlib]System.String::IsNullOrEmpty(string)
      IL_00af:  brtrue.s   IL_00ce

      IL_00b1:  ldloc.s    V_9
      IL_00b3:  callvirt   instance string [mscorlib]System.String::ToLowerInvariant()
      IL_00b8:  ldstr      "product"
      IL_00bd:  callvirt   instance bool [mscorlib]System.String::StartsWith(string)
      IL_00c2:  brtrue.s   IL_00ce

      IL_00c4:  ldloc.s    V_9
      IL_00c6:  ldloc.s    V_7
      IL_00c8:  ldloc.0
      IL_00c9:  call       void AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfoHelper::AddTargetToCollection(string,
                                                                                                                    valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,
                                                                                                                    class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>)
      IL_00ce:  ldloca.s   V_3
      IL_00d0:  call       instance bool valuetype [mscorlib]System.Collections.Generic.Dictionary`2/Enumerator<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo>::MoveNext()
      IL_00d5:  brtrue     IL_0024

      IL_00da:  leave.s    IL_00ea

    }  // end .try
    finally
    {
      IL_00dc:  ldloca.s   V_3
      IL_00de:  constrained. valuetype [mscorlib]System.Collections.Generic.Dictionary`2/Enumerator<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo,valuetype AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo>
      IL_00e4:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_00e9:  endfinally
    }  // end handler
    IL_00ea:  ldloc.0
    IL_00eb:  ldloc.1
    IL_00ec:  ldloc.2
    IL_00ed:  newobj     instance void valuetype [mscorlib]System.ValueTuple`3<class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>,class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>::.ctor(!0,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !1,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   !2)
    IL_00f2:  ret
  } // end of method CxsNodeInfoHelper::CollectUoAndStream

  .method public hidebysig static bool  HasStandAloneSubFlowsheet(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase currentcase) cil managed
  {
    // Code size       25 (0x19)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldc.i4.0
    IL_0001:  stloc.0
    IL_0002:  ldstr      "appModel.FlowSheetObjects.UnitOps"
    IL_0007:  ldarg.0
    IL_0008:  call       class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>> AspenTech.EquipmentAnalysis.Infrastructure.AspenCaseDataRequest::GetSubflowsheets(string,
                                                                                                                                                                                                                                                class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
    IL_000d:  callvirt   instance int32 class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.Dictionary`2<string,bool>>::get_Count()
    IL_0012:  ldc.i4.0
    IL_0013:  ble.s      IL_0017

    IL_0015:  ldc.i4.1
    IL_0016:  stloc.0
    IL_0017:  ldloc.0
    IL_0018:  ret
  } // end of method CxsNodeInfoHelper::HasStandAloneSubFlowsheet

  .method private hidebysig static void  AddTargetToCollection(string uoid,
                                                               valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo streamInfo,
                                                               class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>> collection) cil managed
  {
    // Code size       58 (0x3a)
    .maxstack  3
    .locals init (class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo> V_0)
    IL_0000:  ldarg.2
    IL_0001:  ldarg.0
    IL_0002:  ldloca.s   V_0
    IL_0004:  callvirt   instance bool class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>::TryGetValue(!0,
                                                                                                                                                                                                                                        !1&)
    IL_0009:  brfalse.s  IL_0024

    IL_000b:  ldloc.0
    IL_000c:  ldarg.1
    IL_000d:  callvirt   instance bool class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::Contains(!0)
    IL_0012:  brtrue.s   IL_001b

    IL_0014:  ldloc.0
    IL_0015:  ldarg.1
    IL_0016:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::Add(!0)
    IL_001b:  ldarg.2
    IL_001c:  ldarg.0
    IL_001d:  ldloc.0
    IL_001e:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>::set_Item(!0,
                                                                                                                                                                                                                                     !1)
    IL_0023:  ret

    IL_0024:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::.ctor()
    IL_0029:  dup
    IL_002a:  ldarg.1
    IL_002b:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>::Add(!0)
    IL_0030:  stloc.0
    IL_0031:  ldarg.2
    IL_0032:  ldarg.0
    IL_0033:  ldloc.0
    IL_0034:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class [mscorlib]System.Collections.Generic.List`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo>>::Add(!0,
                                                                                                                                                                                                                                !1)
    IL_0039:  ret
  } // end of method CxsNodeInfoHelper::AddTargetToCollection

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfoHelper

.class public sequential ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo
       extends [mscorlib]System.ValueType
{
  .field public string path
  .field public string 'type'
  .field public bool isleaf
  .field public string id
  .field public string containertype
  .field public valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType prdType
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.CxsNodeInfo

.class public sequential ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo
       extends [mscorlib]System.ValueType
{
  .field public string upstreamUo
  .field public string downstreamUo
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.StreamConnectionInfo

.class public abstract auto ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper
       extends [mscorlib]System.Object
{
  .field private static class [mscorlib]System.WeakReference uContainerReference
  .method private hidebysig specialname static 
          class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer 
          get_Container() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.WeakReference AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::uContainerReference
    IL_0005:  callvirt   instance bool [mscorlib]System.WeakReference::get_IsAlive()
    IL_000a:  brfalse.s  IL_001c

    IL_000c:  ldsfld     class [mscorlib]System.WeakReference AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::uContainerReference
    IL_0011:  callvirt   instance object [mscorlib]System.WeakReference::get_Target()
    IL_0016:  castclass  [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer
    IL_001b:  ret

    IL_001c:  ldnull
    IL_001d:  ret
  } // end of method CxsCaseHelper::get_Container

  .method public hidebysig specialname static 
          void  set_Container(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer 'value') cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  newobj     instance void [mscorlib]System.WeakReference::.ctor(object,
                                                                             bool)
    IL_0007:  stsfld     class [mscorlib]System.WeakReference AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::uContainerReference
    IL_000c:  ret
  } // end of method CxsCaseHelper::set_Container

  .method public hidebysig specialname static 
          class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase 
          get_MyCase() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  2
    .locals init (class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase V_0)
    .try
    {
      IL_0000:  call       class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_Container()
      IL_0005:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
      IL_000a:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                            class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
      IL_000f:  stloc.0
      IL_0010:  leave.s    IL_0017

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_0012:  pop
      IL_0013:  ldnull
      IL_0014:  stloc.0
      IL_0015:  leave.s    IL_0017

    }  // end handler
    IL_0017:  ldloc.0
    IL_0018:  ret
  } // end of method CxsCaseHelper::get_MyCase

  .method public hidebysig specialname static 
          class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider 
          get_MyDataProvider() cil managed
  {
    // Code size       36 (0x24)
    .maxstack  3
    .locals init (class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider V_0)
    .try
    {
      IL_0000:  call       class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_Container()
      IL_0005:  call       !!0[] [mscorlib]System.Array::Empty<class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride>()
      IL_000a:  call       !!0 [Microsoft.Practices.Unity]Microsoft.Practices.Unity.UnityContainerExtensions::Resolve<class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer,
                                                                                                                                                                                                              class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.ResolverOverride[])
      IL_000f:  dup
      IL_0010:  call       class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyCase()
      IL_0015:  callvirt   instance void [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::set_Case(class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase)
      IL_001a:  stloc.0
      IL_001b:  leave.s    IL_0022

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_001d:  pop
      IL_001e:  ldnull
      IL_001f:  stloc.0
      IL_0020:  leave.s    IL_0022

    }  // end handler
    IL_0022:  ldloc.0
    IL_0023:  ret
  } // end of method CxsCaseHelper::get_MyDataProvider

  .property callconv(8) class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer
          Container()
  {
    .get class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_Container()
    .set void AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::set_Container(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer)
  } // end of property CxsCaseHelper::Container
  .property callconv(8) class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase
          MyCase()
  {
    .get class [AspenTech.AspenCxs]AspenTech.AspenCxs.CxsCase AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyCase()
  } // end of property CxsCaseHelper::MyCase
  .property callconv(8) class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider
          MyDataProvider()
  {
    .get class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
  } // end of property CxsCaseHelper::MyDataProvider
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper

.class public abstract auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.BindableBase
       extends [mscorlib]System.Object
       implements [System]System.ComponentModel.INotifyPropertyChanged
{
  .class auto ansi sealed nested private beforefieldinit '<>c__DisplayClass6_0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class AspenTech.EquipmentAnalysis.Infrastructure.BindableBase '<>4__this'
    .field public string propertyName
    .method public hidebysig specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '<>c__DisplayClass6_0'::.ctor

    .method assembly hidebysig instance void 
            '<Make>b__0'() cil managed
    {
      // Code size       18 (0x12)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.BindableBase AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0'::'<>4__this'
      IL_0006:  ldarg.0
      IL_0007:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0'::propertyName
      IL_000c:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::OnPropertyChanged(string)
      IL_0011:  ret
    } // end of method '<>c__DisplayClass6_0'::'<Make>b__0'

  } // end of class '<>c__DisplayClass6_0'

  .field private initonly class [mscorlib]System.Collections.Generic.Dictionary`2<string,class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver> _propertyObserverContainer
  .field private class [System]System.ComponentModel.PropertyChangedEventHandler PropertyChanged
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig newslot specialname virtual final 
          instance void  add_PropertyChanged(class [System]System.ComponentModel.PropertyChangedEventHandler 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [System]System.ComponentModel.PropertyChangedEventHandler V_0,
             class [System]System.ComponentModel.PropertyChangedEventHandler V_1,
             class [System]System.ComponentModel.PropertyChangedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.ComponentModel.PropertyChangedEventHandler AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::PropertyChanged
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [System]System.ComponentModel.PropertyChangedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [System]System.ComponentModel.PropertyChangedEventHandler AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::PropertyChanged
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [System]System.ComponentModel.PropertyChangedEventHandler>(!!0&,
                                                                                                                                                      !!0,
                                                                                                                                                      !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method BindableBase::add_PropertyChanged

  .method public hidebysig newslot specialname virtual final 
          instance void  remove_PropertyChanged(class [System]System.ComponentModel.PropertyChangedEventHandler 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [System]System.ComponentModel.PropertyChangedEventHandler V_0,
             class [System]System.ComponentModel.PropertyChangedEventHandler V_1,
             class [System]System.ComponentModel.PropertyChangedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.ComponentModel.PropertyChangedEventHandler AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::PropertyChanged
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [System]System.ComponentModel.PropertyChangedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [System]System.ComponentModel.PropertyChangedEventHandler AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::PropertyChanged
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [System]System.ComponentModel.PropertyChangedEventHandler>(!!0&,
                                                                                                                                                      !!0,
                                                                                                                                                      !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method BindableBase::remove_PropertyChanged

  .method family hidebysig instance void 
          OnPropertyChanged([opt] string propertyName) cil managed
  {
    .param [1] = nullref
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CallerMemberNameAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       24 (0x18)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.ComponentModel.PropertyChangedEventHandler AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::PropertyChanged
    IL_0006:  dup
    IL_0007:  brtrue.s   IL_000b

    IL_0009:  pop
    IL_000a:  ret

    IL_000b:  ldarg.0
    IL_000c:  ldarg.1
    IL_000d:  newobj     instance void [System]System.ComponentModel.PropertyChangedEventArgs::.ctor(string)
    IL_0012:  callvirt   instance void [System]System.ComponentModel.PropertyChangedEventHandler::Invoke(object,
                                                                                                         class [System]System.ComponentModel.PropertyChangedEventArgs)
    IL_0017:  ret
  } // end of method BindableBase::OnPropertyChanged

  .method family hidebysig newslot virtual 
          instance bool  SetProperty<T>(!!T& 'storage',
                                        !!T 'value',
                                        [opt] string propertyName) cil managed
  {
    .param [3] = nullref
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CallerMemberNameAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       37 (0x25)
    .maxstack  8
    IL_0000:  call       class [mscorlib]System.Collections.Generic.EqualityComparer`1<!0> class [mscorlib]System.Collections.Generic.EqualityComparer`1<!!T>::get_Default()
    IL_0005:  ldarg.1
    IL_0006:  ldobj      !!T
    IL_000b:  ldarg.2
    IL_000c:  callvirt   instance bool class [mscorlib]System.Collections.Generic.EqualityComparer`1<!!T>::Equals(!0,
                                                                                                                  !0)
    IL_0011:  brfalse.s  IL_0015

    IL_0013:  ldc.i4.0
    IL_0014:  ret

    IL_0015:  ldarg.1
    IL_0016:  ldarg.2
    IL_0017:  stobj      !!T
    IL_001c:  ldarg.0
    IL_001d:  ldarg.3
    IL_001e:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::OnPropertyChanged(string)
    IL_0023:  ldc.i4.1
    IL_0024:  ret
  } // end of method BindableBase::SetProperty

  .method family hidebysig instance class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver 
          Make(string propertyName) cil managed
  {
    // Code size       91 (0x5b)
    .maxstack  4
    .locals init (class AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0' V_0)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.0
    IL_0008:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.BindableBase AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0'::'<>4__this'
    IL_000d:  ldloc.0
    IL_000e:  ldarg.1
    IL_000f:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0'::propertyName
    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver> AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::_propertyObserverContainer
    IL_001a:  ldloc.0
    IL_001b:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0'::propertyName
    IL_0020:  callvirt   instance bool class [mscorlib]System.Collections.Generic.Dictionary`2<string,class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver>::ContainsKey(!0)
    IL_0025:  brtrue.s   IL_0049

    IL_0027:  ldarg.0
    IL_0028:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver> AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::_propertyObserverContainer
    IL_002d:  ldloc.0
    IL_002e:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0'::propertyName
    IL_0033:  ldloc.0
    IL_0034:  ldftn      instance void AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0'::'<Make>b__0'()
    IL_003a:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_003f:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver::.ctor(class [mscorlib]System.Action)
    IL_0044:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver>::set_Item(!0,
                                                                                                                                                                                   !1)
    IL_0049:  ldarg.0
    IL_004a:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver> AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::_propertyObserverContainer
    IL_004f:  ldloc.0
    IL_0050:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.BindableBase/'<>c__DisplayClass6_0'::propertyName
    IL_0055:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<string,class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver>::get_Item(!0)
    IL_005a:  ret
  } // end of method BindableBase::Make

  .method family hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       18 (0x12)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<string,class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver>::.ctor()
    IL_0006:  stfld      class [mscorlib]System.Collections.Generic.Dictionary`2<string,class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver> AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::_propertyObserverContainer
    IL_000b:  ldarg.0
    IL_000c:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0011:  ret
  } // end of method BindableBase::.ctor

  .event [System]System.ComponentModel.PropertyChangedEventHandler PropertyChanged
  {
    .addon instance void AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::add_PropertyChanged(class [System]System.ComponentModel.PropertyChangedEventHandler)
    .removeon instance void AspenTech.EquipmentAnalysis.Infrastructure.BindableBase::remove_PropertyChanged(class [System]System.ComponentModel.PropertyChangedEventHandler)
  } // end of event BindableBase::PropertyChanged
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.BindableBase

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.ComboBoxItemWithTooltip
       extends [mscorlib]System.Object
{
  .field private initonly string '<Text>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly string '<Tooltip>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string text,
                               [opt] string tooltip) cil managed
  {
    .param [2] = ""
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.ComboBoxItemWithTooltip::'<Text>k__BackingField'
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.ComboBoxItemWithTooltip::'<Tooltip>k__BackingField'
    IL_0014:  ret
  } // end of method ComboBoxItemWithTooltip::.ctor

  .method public hidebysig specialname instance string 
          get_Text() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.ComboBoxItemWithTooltip::'<Text>k__BackingField'
    IL_0006:  ret
  } // end of method ComboBoxItemWithTooltip::get_Text

  .method public hidebysig specialname instance string 
          get_Tooltip() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.ComboBoxItemWithTooltip::'<Tooltip>k__BackingField'
    IL_0006:  ret
  } // end of method ComboBoxItemWithTooltip::get_Tooltip

  .property instance callconv(8) string Text()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ComboBoxItemWithTooltip::get_Text()
  } // end of property ComboBoxItemWithTooltip::Text
  .property instance callconv(8) string Tooltip()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ComboBoxItemWithTooltip::get_Tooltip()
  } // end of property ComboBoxItemWithTooltip::Tooltip
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ComboBoxItemWithTooltip

.class public abstract auto ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Common
       extends [mscorlib]System.Object
{
  .class auto ansi sealed nested public TreeViewOperation
         extends [mscorlib]System.Enum
  {
    .field public specialname rtspecialname int32 value__
    .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation Locate = int32(0x00000000)
    .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation Add = int32(0x00000001)
    .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation Delete = int32(0x00000002)
    .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation Reload = int32(0x00000003)
  } // end of class TreeViewOperation

  .class auto ansi sealed nested public eUnitSet
         extends [mscorlib]System.Enum
  {
    .field public specialname rtspecialname int32 value__
    .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet SI = int32(0x00000000)
    .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet EN = int32(0x00000001)
  } // end of class eUnitSet

  .field public static literal string hysysUOPath = "appModel.FlowSheetObjects.UnitOps"
  .field public static literal string hysysStreamPath = "appModel.FlowSheetObjects.Streams"
  .field public static literal string hysysPSVPath = "PSV Sizing Calculation"
  .field public static literal string hysysPSVScenarioPath = "Emergency Scenario"
  .field public static literal string hysysInlet = "Upstream Unit Operations"
  .field public static literal string hysysOutlet = "Downstream Unit Operations"
  .field public static literal string hysysLPTankPath = ""
  .field public static literal string hysysSubFSUOPath = "{0}.UnitOps"
  .field public static literal string hysysSubFSStreamPath = "{0}.Streams"
  .field public static literal string psvTUONodeType = "TopLevelUOs"
  .field public static literal string psvTUAStmNodeType = "TopUnattachedStreams"
  .field public static literal string psvTankRootNodeType = "TopPSVTankRoot"
  .field public static literal string psvUAStmNodeType = "UnattachedStreams"
  .field public static literal string psvSubFSNodeType = "Subflowsheet"
  .field public static literal string psvColSubFSUAStmNodeType = "ColSubflowsheetUnattachedStreams"
  .field public static literal string psvSubFSUAStmNodeType = "SubflowsheetUnattachedStreams"
  .field public static literal string psvUONodeType = "UO"
  .field public static literal string psvOutletNodeType = "Outlet"
  .field public static literal string SafetyDevice = "PRD"
  .field public static literal string emergencyScenario = "EmScenario"
  .field public static literal string Tank = "Tank"
  .field public static literal string psvWorkbookType = "ScenarioWB"
  .field public static literal string psvStreamType = "Stream"
  .field public static literal string psvReportType = "Report"
  .field public static literal string psvFlarenetType = "Flarenet"
  .field public static literal string psvColSubFSNodeType = "ColSubflowsheet"
  .field public static literal string hysysColSubFSUOPath = "{0}.My SubFlowsheet.UnitOps"
  .field public static literal string hysysColSubFSStreamPath = "{0}.My SubFlowsheet.Streams"
  .field public static literal string psvUnitOpsContainerNodeType = "UnitOpsContainer"
  .field public static literal string unitTemp = "Temperature"
  .field public static literal string unitAbsPress = "AbsolutePressure"
  .field public static literal string capacity = "Capacity"
  .field public static literal string unitGPress = "GaugePressure"
  .field public static literal string unitSArea = "SmallArea"
  .field public static literal string unitLength = "Length"
  .field public static literal string unitSLength = "SmallLength"
  .field public static literal string unitMFlow = "MassFlow"
  .field public static literal string unitVelocity = "Velocity"
  .field public static literal string unitForce = "Force"
  .field public static literal string unitRhov2 = "RhoV2"
  .field public static literal string unitMEnthalpy = "MassEnthalpy"
  .field public static literal string unitEnergy = "Energy"
  .field public static literal string unitFEnergy = "FireEnergy"
  .field public static literal string unitVol = "Volume"
  .field public static literal string unitCp = "CoeffCp"
  .field public static literal string unitDensity = "Density"
  .field public static literal string unitDP = "DeltaPressure"
  .field public static literal string unitVis = "Viscosity"
  .field public static literal string unitECoeff = "ExpansionCoeff"
  .field public static literal string unitTCond = "ThermalCond"
  .field public static literal string unitFlux = "MassFlux"
  .field public static literal string unitArea = "Area"
  .field public static literal string unitPerc = "Percentage"
  .field public static literal string unitTP2 = "TankPressure2"
  .field public static literal string unitTP1 = "TankPressure1"
  .field public static literal string unitSLength2 = "SmallLength2"
  .field public static literal string unitTTemp = "TankTemperature"
  .field public static literal string unitStdGasFlow = "StdGasFlow"
  .field public static literal string unitStdVolFlow = "StdVolFlow"
  .field public static literal string unitTLength = "TankLength"
  .field public static literal string unitIntegrand = "Integrand"
  .field public static literal string unitFireHeatFlow = "FireHeatFlow"
  .field public static literal string unitFireEntropy = "FireEntropy"
  .field public static literal string unitExposedVolume = "ExposedVolume"
  .field public static literal string unitDeltaTemp = "DeltaTemperature"
  .field public static literal string unitNoiseLevel = "NoiseLevel"
  .field public static literal string unitSurfaceTension = "SurfaceTension"
  .field public static literal float64 doubleDiffTolerance = float64(1.0000000000000000e-08)
  .field public static literal float64 doubleMinNonZero = float64(9.9999999999999994e-37)
  .field public static literal float64 doubleMaxValue = float64(1.0000000000000000e+36)
  .field public static literal string hysysMaterialStream = "MaterialStreamObject"
  .field public static initonly class [System.Core]System.Collections.Generic.HashSet`1<string> PSVFlowshtTypeList
  .field public static initonly class [System.Core]System.Collections.Generic.HashSet`1<string> PSVColFlowshtTypeList
  .field public static initonly class [System.Core]System.Collections.Generic.HashSet`1<string> PSVNAUnitOpTypeList
  .field private static initonly class [mscorlib]System.Collections.Generic.List`1<string> _codes
  .field private static valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet _uset
  .method public hidebysig static bool  IsSameValue(float64 a,
                                                    float64 b) cil managed
  {
    // Code size       81 (0x51)
    .maxstack  2
    IL_0000:  ldarg.0
    IL_0001:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0006:  brfalse.s  IL_0012

    IL_0008:  ldarg.1
    IL_0009:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000e:  brfalse.s  IL_0012

    IL_0010:  ldc.i4.1
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldc.r8     -32767
    IL_001c:  bne.un.s   IL_0028

    IL_001e:  ldarg.1
    IL_001f:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0024:  brfalse.s  IL_0028

    IL_0026:  ldc.i4.1
    IL_0027:  ret

    IL_0028:  ldarg.0
    IL_0029:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_002e:  brtrue.s   IL_0038

    IL_0030:  ldarg.1
    IL_0031:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0036:  brfalse.s  IL_003a

    IL_0038:  ldc.i4.0
    IL_0039:  ret

    IL_003a:  ldarg.0
    IL_003b:  ldarg.1
    IL_003c:  sub
    IL_003d:  call       float64 [mscorlib]System.Math::Abs(float64)
    IL_0042:  ldc.r8     1e-08
    IL_004b:  bge.un.s   IL_004f

    IL_004d:  ldc.i4.1
    IL_004e:  ret

    IL_004f:  ldc.i4.0
    IL_0050:  ret
  } // end of method Common::IsSameValue

  .method public hidebysig specialname static 
          class [mscorlib]System.Collections.Generic.List`1<string> 
          get_DesignCode() cil managed
  {
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.Collections.Generic.List`1<string> AspenTech.EquipmentAnalysis.Infrastructure.Common::_codes
    IL_0005:  ret
  } // end of method Common::get_DesignCode

  .method public hidebysig specialname static 
          valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet 
          get_PSVUnitSet() cil managed
  {
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  ldsfld     valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet AspenTech.EquipmentAnalysis.Infrastructure.Common::_uset
    IL_0005:  ret
  } // end of method Common::get_PSVUnitSet

  .method public hidebysig specialname static 
          void  set_PSVUnitSet(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet 'value') cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  stsfld     valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet AspenTech.EquipmentAnalysis.Infrastructure.Common::_uset
    IL_0006:  ret
  } // end of method Common::set_PSVUnitSet

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       390 (0x186)
    .maxstack  3
    IL_0000:  newobj     instance void class [System.Core]System.Collections.Generic.HashSet`1<string>::.ctor()
    IL_0005:  dup
    IL_0006:  ldstr      "FlowShtObject"
    IL_000b:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_0010:  pop
    IL_0011:  dup
    IL_0012:  ldstr      "TemplateOpObject"
    IL_0017:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_001c:  pop
    IL_001d:  stsfld     class [System.Core]System.Collections.Generic.HashSet`1<string> AspenTech.EquipmentAnalysis.Infrastructure.Common::PSVFlowshtTypeList
    IL_0022:  newobj     instance void class [System.Core]System.Collections.Generic.HashSet`1<string>::.ctor()
    IL_0027:  dup
    IL_0028:  ldstr      "ColumnOpObject"
    IL_002d:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_0032:  pop
    IL_0033:  dup
    IL_0034:  ldstr      "DistillationObject"
    IL_0039:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_003e:  pop
    IL_003f:  dup
    IL_0040:  ldstr      "FractOpObject"
    IL_0045:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_004a:  pop
    IL_004b:  dup
    IL_004c:  ldstr      "AbsorberObject"
    IL_0051:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_0056:  pop
    IL_0057:  dup
    IL_0058:  ldstr      "ReboiledAbsorberObject"
    IL_005d:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_0062:  pop
    IL_0063:  dup
    IL_0064:  ldstr      "RefluxedAbsorberObject"
    IL_0069:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_006e:  pop
    IL_006f:  dup
    IL_0070:  ldstr      "LiqLiqExtractorObject"
    IL_0075:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_007a:  pop
    IL_007b:  dup
    IL_007c:  ldstr      "RateBasedColObject"
    IL_0081:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_0086:  pop
    IL_0087:  dup
    IL_0088:  ldstr      "ShDistOpObject"
    IL_008d:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_0092:  pop
    IL_0093:  dup
    IL_0094:  ldstr      "ThreePhaseObject"
    IL_0099:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_009e:  pop
    IL_009f:  dup
    IL_00a0:  ldstr      "DynamicTemplateOpObject"
    IL_00a5:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_00aa:  pop
    IL_00ab:  dup
    IL_00ac:  ldstr      "HysysEOTemplateOpObject"
    IL_00b1:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_00b6:  pop
    IL_00b7:  dup
    IL_00b8:  ldstr      "SRUOpObject"
    IL_00bd:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_00c2:  pop
    IL_00c3:  stsfld     class [System.Core]System.Collections.Generic.HashSet`1<string> AspenTech.EquipmentAnalysis.Infrastructure.Common::PSVColFlowshtTypeList
    IL_00c8:  newobj     instance void class [System.Core]System.Collections.Generic.HashSet`1<string>::.ctor()
    IL_00cd:  dup
    IL_00ce:  ldstr      "FeederBlockObject"
    IL_00d3:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_00d8:  pop
    IL_00d9:  dup
    IL_00da:  ldstr      "PetrolFeederObject"
    IL_00df:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_00e4:  pop
    IL_00e5:  dup
    IL_00e6:  ldstr      "FBControlOpObject"
    IL_00eb:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_00f0:  pop
    IL_00f1:  dup
    IL_00f2:  ldstr      "SpreadsheetOpObject"
    IL_00f7:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_00fc:  pop
    IL_00fd:  dup
    IL_00fe:  ldstr      "AdjustObject"
    IL_0103:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_0108:  pop
    IL_0109:  dup
    IL_010a:  ldstr      "BalanceOpObject"
    IL_010f:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_0114:  pop
    IL_0115:  dup
    IL_0116:  ldstr      "RecycleObject"
    IL_011b:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_0120:  pop
    IL_0121:  dup
    IL_0122:  ldstr      "SetOpObject"
    IL_0127:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_012c:  pop
    IL_012d:  dup
    IL_012e:  ldstr      "DigitalOpObject"
    IL_0133:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_0138:  pop
    IL_0139:  stsfld     class [System.Core]System.Collections.Generic.HashSet`1<string> AspenTech.EquipmentAnalysis.Infrastructure.Common::PSVNAUnitOpTypeList
    IL_013e:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<string>::.ctor()
    IL_0143:  dup
    IL_0144:  ldstr      ""
    IL_0149:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_014e:  dup
    IL_014f:  ldstr      "ASME VIII"
    IL_0154:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0159:  dup
    IL_015a:  ldstr      "PD 5500"
    IL_015f:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_0164:  dup
    IL_0165:  ldstr      "ASME I"
    IL_016a:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_016f:  dup
    IL_0170:  ldstr      "Other"
    IL_0175:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<string>::Add(!0)
    IL_017a:  stsfld     class [mscorlib]System.Collections.Generic.List`1<string> AspenTech.EquipmentAnalysis.Infrastructure.Common::_codes
    IL_017f:  ldc.i4.0
    IL_0180:  stsfld     valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet AspenTech.EquipmentAnalysis.Infrastructure.Common::_uset
    IL_0185:  ret
  } // end of method Common::.cctor

  .property callconv(8) class [mscorlib]System.Collections.Generic.List`1<string>
          DesignCode()
  {
    .get class [mscorlib]System.Collections.Generic.List`1<string> AspenTech.EquipmentAnalysis.Infrastructure.Common::get_DesignCode()
  } // end of property Common::DesignCode
  .property callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet
          PSVUnitSet()
  {
    .get valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet AspenTech.EquipmentAnalysis.Infrastructure.Common::get_PSVUnitSet()
    .set void AspenTech.EquipmentAnalysis.Infrastructure.Common::set_PSVUnitSet(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet)
  } // end of property Common::PSVUnitSet
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Common

.class public abstract auto ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.HelpTopicID
       extends [mscorlib]System.Object
{
  .field public static literal int32 SafetyEnvironmentGeneral = int32(0x00002648)
  .field public static literal int32 PSVPRDLineSizingTab = int32(0x0000264A)
  .field public static literal int32 PSVPRDScenarioSetup = int32(0x0000264B)
  .field public static literal int32 PSVPRDFluidPropertiesTab = int32(0x0000264C)
  .field public static literal int32 PSVValveSettings = int32(0x0000264D)
  .field public static literal int32 PSVOrificeSizeSettings = int32(0x0000264E)
  .field public static literal int32 PSVLineSizingSettings = int32(0x0000264F)
  .field public static literal int32 PSVReliefPressDialog = int32(0x00002650)
  .field public static literal int32 PSVTotalPressDialog = int32(0x00002651)
  .field public static literal int32 PSVTankDesignTab = int32(0x00002654)
  .field public static literal int32 PSVTankEmergVentTab = int32(0x00002655)
  .field public static literal int32 PSVTankManager = int32(0x00002656)
  .field public static literal int32 PSVTankNormalVentTab = int32(0x00002657)
  .field public static literal int32 PSVEquipmentTab = int32(0x0000265C)
  .field public static literal int32 PSVScenariosTab = int32(0x0000265D)
  .field public static literal int32 PSVPRDDataTab = int32(0x0000265E)
  .field public static literal int32 PSVRatingTab = int32(0x0000265F)
  .field public static literal int32 PSVPRDDataTabRenamePRDDialogBox = int32(0x00002660)
  .field public static literal int32 PSVRuptureDiskEquipmentTab = int32(0x00002662)
  .field public static literal int32 PSVRuptureDiskScenariosTab = int32(0x00002663)
  .field public static literal int32 PSVRuptureDiskScenarioSetup = int32(0x00002664)
  .field public static literal int32 PSVRuptureDiskFluidPropertiesTab = int32(0x00002665)
  .field public static literal int32 PSVRuptureDiskPRDDataTab = int32(0x00002666)
  .field public static literal int32 PSVRuptureDiskPRDDataTabRenamePRDDialogBox = int32(0x00002667)
  .field public static literal int32 PSVRuptureDiskRatingTab = int32(0x00002668)
  .field public static literal int32 PSVRuptureLineSizingTab = int32(0x00002669)
  .field public static literal int32 PSVRuptureLineSizingTabConstraintSettingDialogBox = int32(0x0000266A)
  .field public static literal int32 PSVFireEmergencyScenario = int32(0x0000266B)
  .field public static literal int32 RuptureDiskFireScenario = int32(0x0000266C)
  .field public static literal int32 PSVValveLineSizingTabConstraintSettingDialogBox = int32(0x0000266D)
  .field public static literal int32 PSVPreferencesManagerDialogBox = int32(0x0000266E)
  .field public static literal int32 PSVCalculationSettings = int32(0x0000266F)
  .field public static literal int32 PSVEditPipesAndFittings = int32(0x00002670)
  .field public static literal int32 PSVLineSizingMethodChange = int32(0x00002671)
  .field public static literal int32 PSVPreferencesGeneralSetup = int32(0x00002672)
  .field public static literal int32 PSVPreferencesScenarios = int32(0x00002673)
  .field public static literal int32 PSVPreferencesLineSizing = int32(0x00002674)
  .field public static literal int32 PSVPreferencesRigorousLineSizing = int32(0x00002675)
  .field public static literal int32 PSVPreferencesStorageTank = int32(0x00002676)
  .field public static literal int32 PSVMessageList = int32(0x00002677)
  .field public static literal int32 PSVLegacyLineSizing = int32(0x00002678)
  .field public static literal int32 PSVLineSizingDesign = int32(0x00002679)
  .field public static literal int32 PSVLineSizingRating = int32(0x0000267A)
  .field public static literal int32 PSVFireStepFlashDialog = int32(0x0000267B)
  .field public static literal int32 ReliefCompositionTab = int32(0x0000267C)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.HelpTopicID

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.EAObjType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EAObjType ObjMgr = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EAObjType Valve = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EAObjType EmergScenario = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EAObjType Tank = int32(0x00000003)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.EAObjType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType User = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType Calculation = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType Default = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType Unspecified = int32(0x00000003)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.PsvType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PsvType Conventional = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PsvType BalancedBellows = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PsvType PilotOperated = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PsvType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.ApiSpringMaterial
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiSpringMaterial LowTemperatureAlloySteel = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiSpringMaterial CarbonSteel = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiSpringMaterial ChromeAlloySteel = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiSpringMaterial HighTemperatureAlloySteel = int32(0x00000003)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ApiSpringMaterial

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.FlowType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FlowType Critical = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FlowType Subcritical = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.FlowType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.ReliefLoadCalculationType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefLoadCalculationType Trivial = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefLoadCalculationType ControlValveFailure = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefLoadCalculationType FanFailure = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefLoadCalculationType TubeRupture = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefLoadCalculationType Fire = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefLoadCalculationType RefluxFailure = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefLoadCalculationType ThermalExpansion = int32(0x00000006)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ReliefLoadCalculationType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.CalculationMessageType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CalculationMessageType Error = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CalculationMessageType Warning = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CalculationMessageType Suggestion = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CalculationMessageType Information = int32(0x00000003)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.CalculationMessageType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.StorageTankCalcCode
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankCalcCode Api_650 = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankCalcCode Api_620 = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.StorageTankCalcCode

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice OpenVent = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice BlanketingSystem = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice PressureVacuumValve = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice PressureAndVacuumRelief = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice ManholeCover = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice ManwayEmergencyVent = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice PilotOperated = int32(0x00000006)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice GaugeHatch = int32(0x00000007)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType Psv = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType RuptureDisk = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskType SolidMetal = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskType Scored = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskType FlatComposite = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskType DomedComposite = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskType ReverseActing = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskType Graphite = int32(0x00000005)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.ReliefOrificeSource
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefOrificeSource ApiStandard = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefOrificeSource BuiltIn = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefOrificeSource User = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ReliefOrificeSource

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.PressureDropCalculationType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PressureDropCalculationType LOverD = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PressureDropCalculationType K = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PressureDropCalculationType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.TeeFlowType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.TeeFlowType ConvergingFlow = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.TeeFlowType DeadLeg = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.TeeFlowType DivergingFlow = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.TeeFlowType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation D = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation E = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation F = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation G = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation H = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation J = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation K = int32(0x00000006)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation L = int32(0x00000007)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation M = int32(0x00000008)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation N = int32(0x00000009)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation P = int32(0x0000000A)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation Q = int32(0x0000000B)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation R = int32(0x0000000C)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation T = int32(0x0000000D)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ApiDesignation

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.ApiValveMaterial
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiValveMaterial CarbonSteel = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiValveMaterial ChromeMoly = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiValveMaterial AusteniticStainless = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiValveMaterial NickelCopper = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ApiValveMaterial Alloy20 = int32(0x00000004)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ApiValveMaterial

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.Api526Ed
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Api526Ed e5 = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Api526Ed e7 = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Api526Ed

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.EquipmentMaterial
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EquipmentMaterial Aluminum = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EquipmentMaterial NickelAlloy = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EquipmentMaterial MonelAlloy = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EquipmentMaterial InconelAlloy = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EquipmentMaterial Stainless316 = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EquipmentMaterial HastelloyC276 = int32(0x00000005)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.EquipmentMaterial

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskSpecificationType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskSpecificationType Pressure = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskSpecificationType Percent = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.RuptureDiskSpecificationType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode Other = int32(0xFFFFFFFF)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode ASME_VIII = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode PD_5500 = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode ASME_I = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.SystemDesignCode

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.PipeMaterial
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PipeMaterial MildSteel = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PipeMaterial Smooth = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PipeMaterial

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation Atmosphere = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation Flare = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation HPFlare = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation LPFlare = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation ColdFlare = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation AcidGasFlare = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation WetBurnPit = int32(0x00000006)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation CryoBurnPit = int32(0x00000007)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation Process = int32(0x00000008)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation Sewer = int32(0x00000009)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.DischargeLocation

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Abnormal_Flow_through_Valve = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Abnormal_Heat_or_Vapor_Input = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Accidental_Mixing = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Accumulation_of_Non_Condensables = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Blocked_In_Fired_Heater = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Blocked_Outlet = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Chemical_Reaction = int32(0x00000006)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Cold_Side_of_Exchanger_Blocked = int32(0x00000007)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Control_Valve_Failure = int32(0x00000008)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Coolant_Failure = int32(0x00000009)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Cooling_Water_Failure = int32(0x0000000A)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Exch_Tube_Rupture = int32(0x0000000B)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Failure_of_Automatic_Controls = int32(0x0000000C)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Fan_Failure = int32(0x0000000D)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Fire = int32(0x0000000E)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType General_Power_Failure = int32(0x0000000F)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Inadvertent_Loss_of_Segregation = int32(0x00000010)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Local_Power_Failure = int32(0x00000011)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Loss_of_Absorbent = int32(0x00000012)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Loss_of_Heat = int32(0x00000013)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Overfilling = int32(0x00000014)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Pressure_Surge_or_Internal_Explosion = int32(0x00000015)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Reflux_Failure = int32(0x00000016)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Reflux_Failure_in_Side_Stream = int32(0x00000017)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType Thermal_Expansion = int32(0x00000018)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType User_Defined = int32(0x00000019)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod Vapor = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod Liquid = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod Steam = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod Mixed_1 = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod Mixed_2 = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod Mixed_3 = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod Mixed_Direct = int32(0x00000006)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod KrMethod = int32(0x00000007)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod NonCertifiedLiquid = int32(0x00000008)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime Vapor = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime Liquid = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime TwoPhase = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime Supercritical = int32(0x00000003)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod Omega = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod Homogeneous = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod SinglePhase = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod Rigorous = int32(0x00000003)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec RatedArea = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec Required = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec Manual = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource Empty = int32(0xFFFFFFFF)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource Reference = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource Specified = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource VaporFraction = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource Unwetted = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource Wetted = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource Rigorous = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource Calculated = int32(0x00000006)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.ProcessDataSource
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ProcessDataSource Reference = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ProcessDataSource Calculated = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ProcessDataSource Specified = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ProcessDataSource

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod FIREWetted = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod FIREUnwetted = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod TwoPhaseRigorous = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod SinglePhaseRigorous = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod NFPA30 = int32(0x00000004)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType PctVap = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType HeatFlow = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType FinalTemp = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.HeadType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType Ellipsoidal = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType Hemispherical = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType Flat = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType Same = int32(0x00000003)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.HeadType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.BuiltUpBackpressureSource
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.BuiltUpBackpressureSource PctOfSet = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.BuiltUpBackpressureSource Fixed = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.BuiltUpBackpressureSource

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.CpCvSelectionEnum
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CpCvSelectionEnum Ideal = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CpCvSelectionEnum SemiIdeal = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.CpCvSelectionEnum

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.PSVReportTypeEnum
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVReportTypeEnum Calculation = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVReportTypeEnum ReliefLoad = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVReportTypeEnum LineSizing = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVReportTypeEnum EquivLength = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVReportTypeEnum Tank = int32(0x00000004)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PSVReportTypeEnum

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.PipeElementType
       extends [mscorlib]System.Enum
{
  .custom instance void [mscorlib]System.FlagsAttribute::.ctor() = ( 01 00 00 00 ) 
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PipeElementType All = int32(0xFFFFFFFF)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PipeElementType None = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PipeElementType Segment = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PipeElementType Fitting = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PipeElementType Swage = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PipeElementType Tee = int32(0x00000008)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PipeElementType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceConfigurationType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceConfigurationType None = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceConfigurationType Cache = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceConfigurationType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionCoefficientMethod
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionCoefficientMethod Specified = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionCoefficientMethod Equation = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionCoefficientMethod

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionTemperatureType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionTemperatureType Operating = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionTemperatureType Relief = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionTemperatureType Manual = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.CubicalExpansionTemperatureType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation Elsewhere = int32(0xFFFFFFFF)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation FlowCalc = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation OrificeCalc = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation OrificeSelection = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation LineSizing = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation SummaryForm = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation Anywhere = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation TankCalc = int32(0x00000006)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation LineSizingConstraints = int32(0x00000007)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation RDFlowResistance = int32(0x00000008)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel Uninitialized = int32(0xFFFFFFFF)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel Ok = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel Warning = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel Error = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.FittingName
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Elbow45Std = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Elbow45Long = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Elbow90Std = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Elbow90Long = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd1 = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd15 = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd2 = int32(0x00000006)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd3 = int32(0x00000007)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd4 = int32(0x00000008)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd6 = int32(0x00000009)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd8 = int32(0x0000000A)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd10 = int32(0x0000000B)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd12 = int32(0x0000000C)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd14 = int32(0x0000000D)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd16 = int32(0x0000000E)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Bend90rd20 = int32(0x0000000F)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Elbow45Mitre = int32(0x00000010)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Elbow90Mitre = int32(0x00000011)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName Fitting180DegreeCloseReturn = int32(0x00000012)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName TeeBranchBlanked = int32(0x00000013)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName TeeAsElbow = int32(0x00000014)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName CouplingUnion = int32(0x00000015)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName GateValveOpen = int32(0x00000016)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName GateValveThreeQuarter = int32(0x00000017)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName GateValveHalf = int32(0x00000018)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName GateValveOneQuarter = int32(0x00000019)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName GateValveCraneOpen = int32(0x0000001A)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName DiaphramValveOpen = int32(0x0000001B)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName DiaphramValveThreeQuarter = int32(0x0000001C)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName DiaphramValveHalf = int32(0x0000001D)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName DiaphramValveOneQuarter = int32(0x0000001E)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName GlobeValveOpen = int32(0x0000001F)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName GlobeValveHalf = int32(0x00000020)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName GlobeValveCraneOpen = int32(0x00000021)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName AngleValveOpen = int32(0x00000022)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName AngleValve45degOpen = int32(0x00000023)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName AngleValve90degOpen = int32(0x00000024)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName BlowoffValveOpen = int32(0x00000025)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName PlugCockAngle5 = int32(0x00000026)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName PlugCockAngle10 = int32(0x00000027)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName PlugCockAngle20 = int32(0x00000028)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName PlugCockAngle40 = int32(0x00000029)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName PlugCockAngle60 = int32(0x0000002A)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName PlugCockOpen = int32(0x0000002B)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName ButterflyValveAngle5 = int32(0x0000002C)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName ButterflyValveAngle10 = int32(0x0000002D)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName ButterflyValveAngle20 = int32(0x0000002E)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName ButterflyValveAngle40 = int32(0x0000002F)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName ButterflyValveAngle60 = int32(0x00000030)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName ButterflyValve28inOpen = int32(0x00000031)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName ButterflyValve1014inOpen = int32(0x00000032)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName ButterflyValve1624inOpen = int32(0x00000033)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName BallValveOpen = int32(0x00000034)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName CheckValveSwing = int32(0x00000035)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName CheckValveDisk = int32(0x00000036)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName CheckValveBall = int32(0x00000037)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName CheckValveLift = int32(0x00000038)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName CheckValve45degLift = int32(0x00000039)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName FootValve = int32(0x0000003A)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName FootValvePoppetdisk = int32(0x0000003B)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName FootValveHingeddisk = int32(0x0000003C)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName EntranceSharpEdged = int32(0x0000003D)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName EntranceRoundedrd002 = int32(0x0000003E)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName EntranceRoundedrd004 = int32(0x0000003F)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName EntranceRoundedrd006 = int32(0x00000040)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName EntranceRoundedrd010 = int32(0x00000041)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName EntranceWellRounded = int32(0x00000042)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName EntranceInwardProjecting = int32(0x00000043)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName WaterMeterDisk = int32(0x00000044)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName WaterMeterPiston = int32(0x00000045)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName WaterMeterRotary = int32(0x00000046)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.FittingName WaterMeterTurbine = int32(0x00000047)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.FittingName

.class public abstract auto ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries
       extends [mscorlib]System.Object
{
  .class auto ansi sealed nested private beforefieldinit '<>c__DisplayClass0_0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public string scenarioName
    .method public hidebysig specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '<>c__DisplayClass0_0'::.ctor

    .method assembly hidebysig instance bool 
            '<LookUpEmergScenarioEnum>b__0'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> pair) cil managed
    {
      // Code size       19 (0x13)
      .maxstack  8
      IL_0000:  ldarga.s   pair
      IL_0002:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::get_Value()
      IL_0007:  ldarg.0
      IL_0008:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass0_0'::scenarioName
      IL_000d:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                     string)
      IL_0012:  ret
    } // end of method '<>c__DisplayClass0_0'::'<LookUpEmergScenarioEnum>b__0'

  } // end of class '<>c__DisplayClass0_0'

  .class auto ansi sealed nested private beforefieldinit '<>c__DisplayClass2_0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public string phaseName
    .method public hidebysig specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '<>c__DisplayClass2_0'::.ctor

    .method assembly hidebysig instance bool 
            '<LookUpSizingMethod>b__0'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> pair) cil managed
    {
      // Code size       19 (0x13)
      .maxstack  8
      IL_0000:  ldarga.s   pair
      IL_0002:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::get_Value()
      IL_0007:  ldarg.0
      IL_0008:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass2_0'::phaseName
      IL_000d:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                     string)
      IL_0012:  ret
    } // end of method '<>c__DisplayClass2_0'::'<LookUpSizingMethod>b__0'

  } // end of class '<>c__DisplayClass2_0'

  .class auto ansi sealed nested private beforefieldinit '<>c__DisplayClass3_0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public string phaseName
    .method public hidebysig specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '<>c__DisplayClass3_0'::.ctor

    .method assembly hidebysig instance bool 
            '<LookUpReliefPhase>b__0'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string> pair) cil managed
    {
      // Code size       19 (0x13)
      .maxstack  8
      IL_0000:  ldarga.s   pair
      IL_0002:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>::get_Value()
      IL_0007:  ldarg.0
      IL_0008:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass3_0'::phaseName
      IL_000d:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                     string)
      IL_0012:  ret
    } // end of method '<>c__DisplayClass3_0'::'<LookUpReliefPhase>b__0'

  } // end of class '<>c__DisplayClass3_0'

  .class auto ansi sealed nested private beforefieldinit '<>c__DisplayClass9_0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public string lineSizingMethod
    .method public hidebysig specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '<>c__DisplayClass9_0'::.ctor

    .method assembly hidebysig instance bool 
            '<LookUpLineSizingMethod>b__0'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string> pair) cil managed
    {
      // Code size       19 (0x13)
      .maxstack  8
      IL_0000:  ldarga.s   pair
      IL_0002:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>::get_Value()
      IL_0007:  ldarg.0
      IL_0008:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass9_0'::lineSizingMethod
      IL_000d:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                     string)
      IL_0012:  ret
    } // end of method '<>c__DisplayClass9_0'::'<LookUpLineSizingMethod>b__0'

  } // end of class '<>c__DisplayClass9_0'

  .field private static class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> EmergScenarios
  .field private static class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> SizingMethods
  .field private static class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string> ReliefPhases
  .field private static class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string> FireCalcMethod
  .field private static class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string> SemiDynFlashTypes
  .field private static class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string> FireHeadTypes
  .field private static class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string> LineSizingMethods
  .field private static class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec,string> LineSizingFlows
  .field private static object _dictionariesLock
  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType 
          LookUpEmergScenarioEnum(string scenarioName) cil managed
  {
    // Code size       44 (0x2c)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass0_0' V_0,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> V_1)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass0_0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.0
    IL_0008:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass0_0'::scenarioName
    IL_000d:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_0012:  ldloc.0
    IL_0013:  ldftn      instance bool AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass0_0'::'<LookUpEmergScenarioEnum>b__0'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>)
    IL_0019:  newobj     instance void class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>,bool>::.ctor(object,
                                                                                                                                                                                                                               native int)
    IL_001e:  call       !!0 [System.Core]System.Linq.Enumerable::FirstOrDefault<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                                                               class [mscorlib]System.Func`2<!!0,bool>)
    IL_0023:  stloc.1
    IL_0024:  ldloca.s   V_1
    IL_0026:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::get_Key()
    IL_002b:  ret
  } // end of method PSVDictionaries::LookUpEmergScenarioEnum

  .method public hidebysig static string 
          LookUpEmergScenario(valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType scenarioType) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_0005:  ldarg.0
    IL_0006:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::get_Item(!0)
    IL_000b:  ret
  } // end of method PSVDictionaries::LookUpEmergScenario

  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod 
          LookUpSizingMethod(string phaseName) cil managed
  {
    // Code size       64 (0x40)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass2_0' V_0,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> V_1)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass2_0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.0
    IL_0008:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass2_0'::phaseName
    IL_000d:  ldloc.0
    IL_000e:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass2_0'::phaseName
    IL_0013:  ldstr      "Mixed - Direct"
    IL_0018:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_001d:  brfalse.s  IL_0021

    IL_001f:  ldc.i4.6
    IL_0020:  ret

    IL_0021:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_0026:  ldloc.0
    IL_0027:  ldftn      instance bool AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass2_0'::'<LookUpSizingMethod>b__0'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>)
    IL_002d:  newobj     instance void class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>,bool>::.ctor(object,
                                                                                                                                                                                                                                 native int)
    IL_0032:  call       !!0 [System.Core]System.Linq.Enumerable::FirstOrDefault<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                                                                 class [mscorlib]System.Func`2<!!0,bool>)
    IL_0037:  stloc.1
    IL_0038:  ldloca.s   V_1
    IL_003a:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::get_Key()
    IL_003f:  ret
  } // end of method PSVDictionaries::LookUpSizingMethod

  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime 
          LookUpReliefPhase(string phaseName) cil managed
  {
    // Code size       44 (0x2c)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass3_0' V_0,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string> V_1)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass3_0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.0
    IL_0008:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass3_0'::phaseName
    IL_000d:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::ReliefPhases
    IL_0012:  ldloc.0
    IL_0013:  ldftn      instance bool AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass3_0'::'<LookUpReliefPhase>b__0'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>)
    IL_0019:  newobj     instance void class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>,bool>::.ctor(object,
                                                                                                                                                                                                                              native int)
    IL_001e:  call       !!0 [System.Core]System.Linq.Enumerable::FirstOrDefault<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                                                              class [mscorlib]System.Func`2<!!0,bool>)
    IL_0023:  stloc.1
    IL_0024:  ldloca.s   V_1
    IL_0026:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>::get_Key()
    IL_002b:  ret
  } // end of method PSVDictionaries::LookUpReliefPhase

  .method public hidebysig static string 
          LookUpSizingMethod(valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod sizingMethod) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_0005:  ldarg.0
    IL_0006:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::get_Item(!0)
    IL_000b:  ret
  } // end of method PSVDictionaries::LookUpSizingMethod

  .method public hidebysig static string 
          LookUpReliefPhase(valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime phaseRegime) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::ReliefPhases
    IL_0005:  ldarg.0
    IL_0006:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>::get_Item(!0)
    IL_000b:  ret
  } // end of method PSVDictionaries::LookUpReliefPhase

  .method public hidebysig static string 
          LookUpFireCalcMethod(valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod firecalcmethod) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireCalcMethod
    IL_0005:  ldarg.0
    IL_0006:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string>::get_Item(!0)
    IL_000b:  ret
  } // end of method PSVDictionaries::LookUpFireCalcMethod

  .method public hidebysig static string 
          LookUpSemiDynFlashType(valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType semidynflashtype) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SemiDynFlashTypes
    IL_0005:  ldarg.0
    IL_0006:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string>::get_Item(!0)
    IL_000b:  ret
  } // end of method PSVDictionaries::LookUpSemiDynFlashType

  .method public hidebysig static string 
          LookUpFireHeadTypeEnum(valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType fireheadtype) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireHeadTypes
    IL_0005:  ldarg.0
    IL_0006:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string>::get_Item(!0)
    IL_000b:  ret
  } // end of method PSVDictionaries::LookUpFireHeadTypeEnum

  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod 
          LookUpLineSizingMethod(string lineSizingMethod) cil managed
  {
    // Code size       44 (0x2c)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass9_0' V_0,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string> V_1)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass9_0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.0
    IL_0008:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass9_0'::lineSizingMethod
    IL_000d:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::LineSizingMethods
    IL_0012:  ldloc.0
    IL_0013:  ldftn      instance bool AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries/'<>c__DisplayClass9_0'::'<LookUpLineSizingMethod>b__0'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>)
    IL_0019:  newobj     instance void class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>,bool>::.ctor(object,
                                                                                                                                                                                                                              native int)
    IL_001e:  call       !!0 [System.Core]System.Linq.Enumerable::FirstOrDefault<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                                                                                              class [mscorlib]System.Func`2<!!0,bool>)
    IL_0023:  stloc.1
    IL_0024:  ldloca.s   V_1
    IL_0026:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>::get_Key()
    IL_002b:  ret
  } // end of method PSVDictionaries::LookUpLineSizingMethod

  .method public hidebysig static string 
          LookUpLineSizingMethod(valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod lineSizingMethod) cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::LineSizingMethods
    IL_0005:  ldarg.0
    IL_0006:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>::get_Item(!0)
    IL_000b:  ret
  } // end of method PSVDictionaries::LookUpLineSizingMethod

  .method public hidebysig static string 
          LookupLineSizingFlow(valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec> lineSizingFlow) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarga.s   lineSizingFlow
    IL_0002:  call       instance bool valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec>::get_HasValue()
    IL_0007:  brfalse.s  IL_001b

    IL_0009:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::LineSizingFlows
    IL_000e:  ldarga.s   lineSizingFlow
    IL_0010:  call       instance !0 valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec>::get_Value()
    IL_0015:  callvirt   instance !1 class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec,string>::get_Item(!0)
    IL_001a:  ret

    IL_001b:  ldsfld     string [mscorlib]System.String::Empty
    IL_0020:  ret
  } // end of method PSVDictionaries::LookupLineSizingFlow

  .method public hidebysig static void  buildDictionaries() cil managed
  {
    // Code size       78 (0x4e)
    .maxstack  2
    .locals init (object V_0,
             bool V_1)
    IL_0000:  ldsfld     object AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::_dictionariesLock
    IL_0005:  stloc.0
    IL_0006:  ldc.i4.0
    IL_0007:  stloc.1
    .try
    {
      IL_0008:  ldloc.0
      IL_0009:  ldloca.s   V_1
      IL_000b:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_0010:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
      IL_0015:  brfalse.s  IL_0019

      IL_0017:  leave.s    IL_004d

      IL_0019:  call       void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::buildEmergScenarios()
      IL_001e:  call       void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::buildSizingMethods()
      IL_0023:  call       void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::buildReliefPhases()
      IL_0028:  call       void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::buildFireCalcMethods()
      IL_002d:  call       void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::buildSemiDynFlashTypes()
      IL_0032:  call       void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::buildHeadTypes()
      IL_0037:  call       void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::buildLineSizingMethods()
      IL_003c:  call       void AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::buildLineSizingFlows()
      IL_0041:  leave.s    IL_004d

    }  // end .try
    finally
    {
      IL_0043:  ldloc.1
      IL_0044:  brfalse.s  IL_004c

      IL_0046:  ldloc.0
      IL_0047:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_004c:  endfinally
    }  // end handler
    IL_004d:  ret
  } // end of method PSVDictionaries::buildDictionaries

  .method private hidebysig static void  buildEmergScenarios() cil managed
  {
    // Code size       444 (0x1bc)
    .maxstack  3
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::.ctor()
    IL_0005:  stsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_000a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_000f:  ldc.i4.0
    IL_0010:  ldstr      "Abnormal Flow through Valve"
    IL_0015:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_001a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_001f:  ldc.i4.1
    IL_0020:  ldstr      "Abnormal Heat or Vapor Input"
    IL_0025:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_002a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_002f:  ldc.i4.2
    IL_0030:  ldstr      "Accidental Mixing"
    IL_0035:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_003a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_003f:  ldc.i4.3
    IL_0040:  ldstr      "Accumulation of Non-Condensables"
    IL_0045:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_004a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_004f:  ldc.i4.4
    IL_0050:  ldstr      "Blocked-In Fired Heater"
    IL_0055:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_005a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_005f:  ldc.i4.5
    IL_0060:  ldstr      "Blocked Outlet"
    IL_0065:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_006a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_006f:  ldc.i4.6
    IL_0070:  ldstr      "Chemical Reaction"
    IL_0075:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_007a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_007f:  ldc.i4.7
    IL_0080:  ldstr      "Cold Side of Exchanger Blocked-In"
    IL_0085:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_008a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_008f:  ldc.i4.8
    IL_0090:  ldstr      "Control Valve Failure"
    IL_0095:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_009a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_009f:  ldc.i4.s   9
    IL_00a1:  ldstr      "Coolant Failure (Other than CW)"
    IL_00a6:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_00ab:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_00b0:  ldc.i4.s   10
    IL_00b2:  ldstr      "Cooling Water Failure"
    IL_00b7:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_00bc:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_00c1:  ldc.i4.s   11
    IL_00c3:  ldstr      "Exch. Tube Rupture"
    IL_00c8:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_00cd:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_00d2:  ldc.i4.s   12
    IL_00d4:  ldstr      "Failure of Automatic Controls"
    IL_00d9:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_00de:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_00e3:  ldc.i4.s   13
    IL_00e5:  ldstr      "Fan Failure"
    IL_00ea:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_00ef:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_00f4:  ldc.i4.s   14
    IL_00f6:  ldstr      "Fire"
    IL_00fb:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_0100:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_0105:  ldc.i4.s   15
    IL_0107:  ldstr      "General Power Failure"
    IL_010c:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_0111:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_0116:  ldc.i4.s   16
    IL_0118:  ldstr      "Inadvertent Loss of Segregation"
    IL_011d:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_0122:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_0127:  ldc.i4.s   17
    IL_0129:  ldstr      "Local Power Failure"
    IL_012e:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_0133:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_0138:  ldc.i4.s   18
    IL_013a:  ldstr      "Loss of Absorbent"
    IL_013f:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_0144:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_0149:  ldc.i4.s   19
    IL_014b:  ldstr      "Loss of Heat"
    IL_0150:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_0155:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_015a:  ldc.i4.s   20
    IL_015c:  ldstr      "Overfilling"
    IL_0161:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_0166:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_016b:  ldc.i4.s   21
    IL_016d:  ldstr      "Pressure Surge or Internal Explosion"
    IL_0172:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_0177:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_017c:  ldc.i4.s   22
    IL_017e:  ldstr      "Reflux Failure"
    IL_0183:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_0188:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_018d:  ldc.i4.s   23
    IL_018f:  ldstr      "Reflux Failure (Side Stream)"
    IL_0194:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_0199:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_019e:  ldc.i4.s   24
    IL_01a0:  ldstr      "Thermal Expansion"
    IL_01a5:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_01aa:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::EmergScenarios
    IL_01af:  ldc.i4.s   25
    IL_01b1:  ldstr      "User Defined"
    IL_01b6:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType,string>::Add(!0,
                                                                                                                                                                                   !1)
    IL_01bb:  ret
  } // end of method PSVDictionaries::buildEmergScenarios

  .method private hidebysig static void  buildSizingMethods() cil managed
  {
    // Code size       139 (0x8b)
    .maxstack  3
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::.ctor()
    IL_0005:  stsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_000a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_000f:  ldc.i4.0
    IL_0010:  ldstr      "Vapor"
    IL_0015:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::Add(!0,
                                                                                                                                                                                     !1)
    IL_001a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_001f:  ldc.i4.2
    IL_0020:  ldstr      "Steam"
    IL_0025:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::Add(!0,
                                                                                                                                                                                     !1)
    IL_002a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_002f:  ldc.i4.1
    IL_0030:  ldstr      "Liquid"
    IL_0035:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::Add(!0,
                                                                                                                                                                                     !1)
    IL_003a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_003f:  ldc.i4.3
    IL_0040:  ldstr      "Mixed (A)"
    IL_0045:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::Add(!0,
                                                                                                                                                                                     !1)
    IL_004a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_004f:  ldc.i4.4
    IL_0050:  ldstr      "Mixed (B)"
    IL_0055:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::Add(!0,
                                                                                                                                                                                     !1)
    IL_005a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_005f:  ldc.i4.5
    IL_0060:  ldstr      "Mixed (C)"
    IL_0065:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::Add(!0,
                                                                                                                                                                                     !1)
    IL_006a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_006f:  ldc.i4.6
    IL_0070:  ldstr      "Direct"
    IL_0075:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::Add(!0,
                                                                                                                                                                                     !1)
    IL_007a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SizingMethods
    IL_007f:  ldc.i4.7
    IL_0080:  ldstr      "Flow Resistance (L/D)"
    IL_0085:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod,string>::Add(!0,
                                                                                                                                                                                     !1)
    IL_008a:  ret
  } // end of method PSVDictionaries::buildSizingMethods

  .method private hidebysig static void  buildReliefPhases() cil managed
  {
    // Code size       75 (0x4b)
    .maxstack  3
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>::.ctor()
    IL_0005:  stsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::ReliefPhases
    IL_000a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::ReliefPhases
    IL_000f:  ldc.i4.0
    IL_0010:  ldstr      "Vapor"
    IL_0015:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_001a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::ReliefPhases
    IL_001f:  ldc.i4.1
    IL_0020:  ldstr      "Liquid"
    IL_0025:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_002a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::ReliefPhases
    IL_002f:  ldc.i4.2
    IL_0030:  ldstr      "TwoPhase"
    IL_0035:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_003a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::ReliefPhases
    IL_003f:  ldc.i4.3
    IL_0040:  ldstr      "Supercritical"
    IL_0045:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_004a:  ret
  } // end of method PSVDictionaries::buildReliefPhases

  .method private hidebysig static void  buildFireCalcMethods() cil managed
  {
    // Code size       75 (0x4b)
    .maxstack  3
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string>::.ctor()
    IL_0005:  stsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireCalcMethod
    IL_000a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireCalcMethod
    IL_000f:  ldc.i4.1
    IL_0010:  ldstr      "Unwetted (API)"
    IL_0015:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string>::Add(!0,
                                                                                                                                                                                !1)
    IL_001a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireCalcMethod
    IL_001f:  ldc.i4.0
    IL_0020:  ldstr      "Wetted (API)"
    IL_0025:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string>::Add(!0,
                                                                                                                                                                                !1)
    IL_002a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireCalcMethod
    IL_002f:  ldc.i4.2
    IL_0030:  ldstr      "Semi-Dynamic Flash"
    IL_0035:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string>::Add(!0,
                                                                                                                                                                                !1)
    IL_003a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireCalcMethod
    IL_003f:  ldc.i4.3
    IL_0040:  ldstr      "Supercritical"
    IL_0045:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.FireCalcMethod,string>::Add(!0,
                                                                                                                                                                                !1)
    IL_004a:  ret
  } // end of method PSVDictionaries::buildFireCalcMethods

  .method private hidebysig static void  buildSemiDynFlashTypes() cil managed
  {
    // Code size       59 (0x3b)
    .maxstack  8
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string>::.ctor()
    IL_0005:  stsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SemiDynFlashTypes
    IL_000a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SemiDynFlashTypes
    IL_000f:  ldc.i4.2
    IL_0010:  ldstr      "Temperature"
    IL_0015:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_001a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SemiDynFlashTypes
    IL_001f:  ldc.i4.1
    IL_0020:  ldstr      "Heat Flow"
    IL_0025:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_002a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::SemiDynFlashTypes
    IL_002f:  ldc.i4.0
    IL_0030:  ldstr      "% Vaporized"
    IL_0035:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_003a:  ret
  } // end of method PSVDictionaries::buildSemiDynFlashTypes

  .method private hidebysig static void  buildHeadTypes() cil managed
  {
    // Code size       59 (0x3b)
    .maxstack  8
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string>::.ctor()
    IL_0005:  stsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireHeadTypes
    IL_000a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireHeadTypes
    IL_000f:  ldc.i4.0
    IL_0010:  ldstr      "2:1 Ellipsoidal"
    IL_0015:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string>::Add(!0,
                                                                                                                                                                          !1)
    IL_001a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireHeadTypes
    IL_001f:  ldc.i4.1
    IL_0020:  ldstr      "Hemispherical"
    IL_0025:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string>::Add(!0,
                                                                                                                                                                          !1)
    IL_002a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::FireHeadTypes
    IL_002f:  ldc.i4.2
    IL_0030:  ldstr      "Flat"
    IL_0035:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType,string>::Add(!0,
                                                                                                                                                                          !1)
    IL_003a:  ret
  } // end of method PSVDictionaries::buildHeadTypes

  .method private hidebysig static void  buildLineSizingMethods() cil managed
  {
    // Code size       75 (0x4b)
    .maxstack  3
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>::.ctor()
    IL_0005:  stsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::LineSizingMethods
    IL_000a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::LineSizingMethods
    IL_000f:  ldc.i4.0
    IL_0010:  ldstr      "Omega"
    IL_0015:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_001a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::LineSizingMethods
    IL_001f:  ldc.i4.2
    IL_0020:  ldstr      "1Phase"
    IL_0025:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_002a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::LineSizingMethods
    IL_002f:  ldc.i4.1
    IL_0030:  ldstr      "Homogeneous"
    IL_0035:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_003a:  ldsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::LineSizingMethods
    IL_003f:  ldc.i4.3
    IL_0040:  ldstr      "Rigorous"
    IL_0045:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineSizingMethod,string>::Add(!0,
                                                                                                                                                                                  !1)
    IL_004a:  ret
  } // end of method PSVDictionaries::buildLineSizingMethods

  .method private hidebysig static void  buildLineSizingFlows() cil managed
  {
    // Code size       47 (0x2f)
    .maxstack  8
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec,string>::.ctor()
    IL_0005:  dup
    IL_0006:  ldc.i4.0
    IL_0007:  ldstr      "Rated (area)"
    IL_000c:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec,string>::Add(!0,
                                                                                                                                                                                    !1)
    IL_0011:  dup
    IL_0012:  ldc.i4.1
    IL_0013:  ldstr      "Required"
    IL_0018:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec,string>::Add(!0,
                                                                                                                                                                                    !1)
    IL_001d:  dup
    IL_001e:  ldc.i4.2
    IL_001f:  ldstr      "Manual"
    IL_0024:  callvirt   instance void class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec,string>::Add(!0,
                                                                                                                                                                                    !1)
    IL_0029:  stsfld     class [mscorlib]System.Collections.Generic.Dictionary`2<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec,string> AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::LineSizingFlows
    IL_002e:  ret
  } // end of method PSVDictionaries::buildLineSizingFlows

  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.ProcessDataSource 
          StringToDataSourceEnum(string str) cil managed
  {
    // Code size       49 (0x31)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "Calculated"
    IL_0006:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_000b:  brtrue.s   IL_0029

    IL_000d:  ldarg.0
    IL_000e:  ldstr      "Reference"
    IL_0013:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0018:  brtrue.s   IL_002b

    IL_001a:  ldarg.0
    IL_001b:  ldstr      "Specified"
    IL_0020:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0025:  brtrue.s   IL_002d

    IL_0027:  br.s       IL_002f

    IL_0029:  ldc.i4.1
    IL_002a:  ret

    IL_002b:  ldc.i4.0
    IL_002c:  ret

    IL_002d:  ldc.i4.2
    IL_002e:  ret

    IL_002f:  ldc.i4.0
    IL_0030:  ret
  } // end of method PSVDictionaries::StringToDataSourceEnum

  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefTemperatureSource 
          StringToReliefTempSourceEnum(string str) cil managed
  {
    // Code size       259 (0x103)
    .maxstack  2
    .locals init (uint32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       uint32 '<PrivateImplementationDetails>'::ComputeStringHash(string)
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  ldc.i4     0x67aee7a0
    IL_000d:  bgt.un.s   IL_0047

    IL_000f:  ldloc.0
    IL_0010:  ldc.i4     0x4507e731
    IL_0015:  bgt.un.s   IL_0032

    IL_0017:  ldloc.0
    IL_0018:  ldc.i4     0x4386ab91
    IL_001d:  beq        IL_00c4

    IL_0022:  ldloc.0
    IL_0023:  ldc.i4     0x4507e731
    IL_0028:  beq        IL_00d3

    IL_002d:  br         IL_0101

    IL_0032:  ldloc.0
    IL_0033:  ldc.i4     0x61583c23
    IL_0038:  beq.s      IL_0097

    IL_003a:  ldloc.0
    IL_003b:  ldc.i4     0x67aee7a0
    IL_0040:  beq.s      IL_00b5

    IL_0042:  br         IL_0101

    IL_0047:  ldloc.0
    IL_0048:  ldc.i4     0xadc8c33a
    IL_004d:  bgt.un.s   IL_0064

    IL_004f:  ldloc.0
    IL_0050:  ldc.i4     0x8ed67c77
    IL_0055:  beq.s      IL_00a6

    IL_0057:  ldloc.0
    IL_0058:  ldc.i4     0xadc8c33a
    IL_005d:  beq.s      IL_0079

    IL_005f:  br         IL_0101

    IL_0064:  ldloc.0
    IL_0065:  ldc.i4     0xb5e81221
    IL_006a:  beq.s      IL_0088

    IL_006c:  ldloc.0
    IL_006d:  ldc.i4     0xd1571f8e
    IL_0072:  beq.s      IL_00e2

    IL_0074:  br         IL_0101

    IL_0079:  ldarg.0
    IL_007a:  ldstr      "Reference"
    IL_007f:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0084:  brtrue.s   IL_00f1

    IL_0086:  br.s       IL_0101

    IL_0088:  ldarg.0
    IL_0089:  ldstr      "Specified"
    IL_008e:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0093:  brtrue.s   IL_00f3

    IL_0095:  br.s       IL_0101

    IL_0097:  ldarg.0
    IL_0098:  ldstr      "VaporFraction"
    IL_009d:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00a2:  brtrue.s   IL_00f5

    IL_00a4:  br.s       IL_0101

    IL_00a6:  ldarg.0
    IL_00a7:  ldstr      "Unwetted"
    IL_00ac:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00b1:  brtrue.s   IL_00f7

    IL_00b3:  br.s       IL_0101

    IL_00b5:  ldarg.0
    IL_00b6:  ldstr      "Wetted"
    IL_00bb:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00c0:  brtrue.s   IL_00f9

    IL_00c2:  br.s       IL_0101

    IL_00c4:  ldarg.0
    IL_00c5:  ldstr      "Rigorous"
    IL_00ca:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00cf:  brtrue.s   IL_00fb

    IL_00d1:  br.s       IL_0101

    IL_00d3:  ldarg.0
    IL_00d4:  ldstr      "Calculated"
    IL_00d9:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00de:  brtrue.s   IL_00fd

    IL_00e0:  br.s       IL_0101

    IL_00e2:  ldarg.0
    IL_00e3:  ldstr      "Empty"
    IL_00e8:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_00ed:  brtrue.s   IL_00ff

    IL_00ef:  br.s       IL_0101

    IL_00f1:  ldc.i4.0
    IL_00f2:  ret

    IL_00f3:  ldc.i4.1
    IL_00f4:  ret

    IL_00f5:  ldc.i4.2
    IL_00f6:  ret

    IL_00f7:  ldc.i4.3
    IL_00f8:  ret

    IL_00f9:  ldc.i4.4
    IL_00fa:  ret

    IL_00fb:  ldc.i4.5
    IL_00fc:  ret

    IL_00fd:  ldc.i4.6
    IL_00fe:  ret

    IL_00ff:  ldc.i4.m1
    IL_0100:  ret

    IL_0101:  ldc.i4.0
    IL_0102:  ret
  } // end of method PSVDictionaries::StringToReliefTempSourceEnum

  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime 
          GetPhaseFromVaporFraction(float64 vf) cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.r8     0.99990000000000001
    IL_000a:  ble.un.s   IL_000e

    IL_000c:  ldc.i4.0
    IL_000d:  ret

    IL_000e:  ldarg.0
    IL_000f:  ldc.r8     0.0001
    IL_0018:  bge.un.s   IL_001c

    IL_001a:  ldc.i4.1
    IL_001b:  ret

    IL_001c:  ldc.i4.2
    IL_001d:  ret
  } // end of method PSVDictionaries::GetPhaseFromVaporFraction

  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime 
          StringToReliefPhaseEnum(string str) cil managed
  {
    // Code size       64 (0x40)
    .maxstack  2
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "Vapor"
    IL_0006:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_000b:  brtrue.s   IL_0036

    IL_000d:  ldarg.0
    IL_000e:  ldstr      "Supercritical"
    IL_0013:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0018:  brtrue.s   IL_0038

    IL_001a:  ldarg.0
    IL_001b:  ldstr      "Liquid"
    IL_0020:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0025:  brtrue.s   IL_003a

    IL_0027:  ldarg.0
    IL_0028:  ldstr      "TwoPhase"
    IL_002d:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0032:  brtrue.s   IL_003c

    IL_0034:  br.s       IL_003e

    IL_0036:  ldc.i4.0
    IL_0037:  ret

    IL_0038:  ldc.i4.3
    IL_0039:  ret

    IL_003a:  ldc.i4.1
    IL_003b:  ret

    IL_003c:  ldc.i4.2
    IL_003d:  ret

    IL_003e:  ldc.i4.0
    IL_003f:  ret
  } // end of method PSVDictionaries::StringToReliefPhaseEnum

  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.SemiDynFlashType 
          StringToSemiDynFlashTypeEnum(string str) cil managed
  {
    // Code size       49 (0x31)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "Temperature"
    IL_0006:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_000b:  brtrue.s   IL_0029

    IL_000d:  ldarg.0
    IL_000e:  ldstr      "% Vaporized"
    IL_0013:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0018:  brtrue.s   IL_002b

    IL_001a:  ldarg.0
    IL_001b:  ldstr      "Heat Flow"
    IL_0020:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0025:  brtrue.s   IL_002d

    IL_0027:  br.s       IL_002f

    IL_0029:  ldc.i4.2
    IL_002a:  ret

    IL_002b:  ldc.i4.0
    IL_002c:  ret

    IL_002d:  ldc.i4.1
    IL_002e:  ret

    IL_002f:  ldc.i4.2
    IL_0030:  ret
  } // end of method PSVDictionaries::StringToSemiDynFlashTypeEnum

  .method public hidebysig static valuetype AspenTech.EquipmentAnalysis.Infrastructure.HeadType 
          StringToFireHeadTypeEnum(string str) cil managed
  {
    // Code size       49 (0x31)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "2:1 Ellipsoidal"
    IL_0006:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_000b:  brtrue.s   IL_0029

    IL_000d:  ldarg.0
    IL_000e:  ldstr      "Hemispherical"
    IL_0013:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0018:  brtrue.s   IL_002b

    IL_001a:  ldarg.0
    IL_001b:  ldstr      "Flat"
    IL_0020:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0025:  brtrue.s   IL_002d

    IL_0027:  br.s       IL_002f

    IL_0029:  ldc.i4.0
    IL_002a:  ret

    IL_002b:  ldc.i4.1
    IL_002c:  ret

    IL_002d:  ldc.i4.2
    IL_002e:  ret

    IL_002f:  ldc.i4.0
    IL_0030:  ret
  } // end of method PSVDictionaries::StringToFireHeadTypeEnum

  .method public hidebysig static valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec> 
          StringToLineRatingFlowSpec(string str) cil managed
  {
    // Code size       106 (0x6a)
    .maxstack  2
    .locals init (valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec> V_0)
    IL_0000:  ldarg.0
    IL_0001:  brfalse.s  IL_0044

    IL_0003:  ldarg.0
    IL_0004:  brfalse.s  IL_000e

    IL_0006:  ldarg.0
    IL_0007:  call       instance int32 [mscorlib]System.String::get_Length()
    IL_000c:  brfalse.s  IL_0044

    IL_000e:  ldarg.0
    IL_000f:  ldstr      "Rated (area)"
    IL_0014:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0019:  brtrue.s   IL_004e

    IL_001b:  ldarg.0
    IL_001c:  ldstr      "Required"
    IL_0021:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0026:  brtrue.s   IL_0055

    IL_0028:  ldarg.0
    IL_0029:  ldstr      "Design"
    IL_002e:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0033:  brtrue.s   IL_0055

    IL_0035:  ldarg.0
    IL_0036:  ldstr      "Manual"
    IL_003b:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0040:  brtrue.s   IL_005c

    IL_0042:  br.s       IL_0063

    IL_0044:  ldloca.s   V_0
    IL_0046:  initobj    valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec>
    IL_004c:  ldloc.0
    IL_004d:  ret

    IL_004e:  ldc.i4.0
    IL_004f:  newobj     instance void valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec>::.ctor(!0)
    IL_0054:  ret

    IL_0055:  ldc.i4.1
    IL_0056:  newobj     instance void valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec>::.ctor(!0)
    IL_005b:  ret

    IL_005c:  ldc.i4.2
    IL_005d:  newobj     instance void valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec>::.ctor(!0)
    IL_0062:  ret

    IL_0063:  ldc.i4.0
    IL_0064:  newobj     instance void valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.LineRatingFlowSpec>::.ctor(!0)
    IL_0069:  ret
  } // end of method PSVDictionaries::StringToLineRatingFlowSpec

  .method private hidebysig specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       11 (0xb)
    .maxstack  8
    IL_0000:  newobj     instance void [mscorlib]System.Object::.ctor()
    IL_0005:  stsfld     object AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries::_dictionariesLock
    IL_000a:  ret
  } // end of method PSVDictionaries::.cctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PSVDictionaries

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<valuetype .ctor ([mscorlib]System.ValueType) T>
       extends [mscorlib]System.Object
{
  .class auto ansi sealed nested private beforefieldinit '<>c__DisplayClass5_0'<valuetype .ctor ([mscorlib]System.ValueType) T>
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public string s
    .method public hidebysig specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '<>c__DisplayClass5_0'::.ctor

    .method assembly hidebysig instance bool 
            '<Enum>b__0'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<!T,string> p) cil managed
    {
      // Code size       19 (0x13)
      .maxstack  8
      IL_0000:  ldarga.s   p
      IL_0002:  call       instance !1 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<!T,string>::get_Value()
      IL_0007:  ldarg.0
      IL_0008:  ldfld      string class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1/'<>c__DisplayClass5_0'<!T>::s
      IL_000d:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                     string)
      IL_0012:  ret
    } // end of method '<>c__DisplayClass5_0'::'<Enum>b__0'

  } // end of class '<>c__DisplayClass5_0'

  .field private initonly class [mscorlib]System.Collections.Generic.Dictionary`2<!T,string> _enumStringPairs
  .field private initonly class [System.Core]System.Collections.Generic.HashSet`1<string> _expectedMissingItems
  .field private initonly string _emptyText
  .field private initonly bool _isLimited
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class [mscorlib]System.Collections.Generic.Dictionary`2<!T,string> pairs,
                               string emptyText,
                               [opt] bool isLimited,
                               [opt] class [mscorlib]System.Collections.Generic.IEnumerable`1<string> expectedMissingItems) cil managed
  {
    .param [3] = bool(true)
    .param [4] = nullref
    // Code size       45 (0x2d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class [mscorlib]System.Collections.Generic.Dictionary`2<!0,string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_enumStringPairs
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      string class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_emptyText
    IL_0014:  ldarg.0
    IL_0015:  ldarg.3
    IL_0016:  stfld      bool class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_isLimited
    IL_001b:  ldarg.s    expectedMissingItems
    IL_001d:  brfalse.s  IL_002c

    IL_001f:  ldarg.0
    IL_0020:  ldarg.s    expectedMissingItems
    IL_0022:  newobj     instance void class [System.Core]System.Collections.Generic.HashSet`1<string>::.ctor(class [mscorlib]System.Collections.Generic.IEnumerable`1<!0>)
    IL_0027:  stfld      class [System.Core]System.Collections.Generic.HashSet`1<string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_expectedMissingItems
    IL_002c:  ret
  } // end of method EnumTranslator`1::.ctor

  .method public hidebysig instance valuetype [mscorlib]System.Nullable`1<!T> 
          Enum(string s) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1/'<>c__DisplayClass5_0'<!T> V_0,
             valuetype [mscorlib]System.Nullable`1<!T> V_1,
             valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<!T,string> V_2)
    IL_0000:  newobj     instance void class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1/'<>c__DisplayClass5_0'<!T>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1/'<>c__DisplayClass5_0'<!T>::s
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<!0,string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_enumStringPairs
    IL_0013:  brfalse.s  IL_0028

    IL_0015:  ldarg.0
    IL_0016:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<!0,string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_enumStringPairs
    IL_001b:  ldloc.0
    IL_001c:  ldfld      string class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1/'<>c__DisplayClass5_0'<!T>::s
    IL_0021:  callvirt   instance bool class [mscorlib]System.Collections.Generic.Dictionary`2<!T,string>::ContainsValue(!1)
    IL_0026:  brtrue.s   IL_0054

    IL_0028:  ldarg.0
    IL_0029:  ldfld      bool class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_isLimited
    IL_002e:  brfalse.s  IL_004a

    IL_0030:  ldarg.0
    IL_0031:  ldfld      class [System.Core]System.Collections.Generic.HashSet`1<string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_expectedMissingItems
    IL_0036:  brfalse.s  IL_004a

    IL_0038:  ldarg.0
    IL_0039:  ldfld      class [System.Core]System.Collections.Generic.HashSet`1<string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_expectedMissingItems
    IL_003e:  ldloc.0
    IL_003f:  ldfld      string class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1/'<>c__DisplayClass5_0'<!T>::s
    IL_0044:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Contains(!0)
    IL_0049:  pop
    IL_004a:  ldloca.s   V_1
    IL_004c:  initobj    valuetype [mscorlib]System.Nullable`1<!T>
    IL_0052:  ldloc.1
    IL_0053:  ret

    IL_0054:  ldarg.0
    IL_0055:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<!0,string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_enumStringPairs
    IL_005a:  ldloc.0
    IL_005b:  ldftn      instance bool class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1/'<>c__DisplayClass5_0'<!T>::'<Enum>b__0'(valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<!0,string>)
    IL_0061:  newobj     instance void class [mscorlib]System.Func`2<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<!T,string>,bool>::.ctor(object,
                                                                                                                                                           native int)
    IL_0066:  call       !!0 [System.Core]System.Linq.Enumerable::SingleOrDefault<valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<!T,string>>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>,
                                                                                                                                                            class [mscorlib]System.Func`2<!!0,bool>)
    IL_006b:  stloc.2
    IL_006c:  ldloca.s   V_2
    IL_006e:  call       instance !0 valuetype [mscorlib]System.Collections.Generic.KeyValuePair`2<!T,string>::get_Key()
    IL_0073:  newobj     instance void valuetype [mscorlib]System.Nullable`1<!T>::.ctor(!0)
    IL_0078:  ret
  } // end of method EnumTranslator`1::Enum

  .method public hidebysig instance string 
          StringValue(valuetype [mscorlib]System.Nullable`1<!T> e) cil managed
  {
    // Code size       47 (0x2f)
    .maxstack  3
    .locals init (string V_0)
    IL_0000:  ldarga.s   e
    IL_0002:  call       instance bool valuetype [mscorlib]System.Nullable`1<!T>::get_HasValue()
    IL_0007:  brtrue.s   IL_0010

    IL_0009:  ldarg.0
    IL_000a:  ldfld      string class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_emptyText
    IL_000f:  ret

    IL_0010:  ldarg.0
    IL_0011:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<!0,string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_enumStringPairs
    IL_0016:  ldarga.s   e
    IL_0018:  call       instance !0 valuetype [mscorlib]System.Nullable`1<!T>::get_Value()
    IL_001d:  ldloca.s   V_0
    IL_001f:  callvirt   instance bool class [mscorlib]System.Collections.Generic.Dictionary`2<!T,string>::TryGetValue(!0,
                                                                                                                       !1&)
    IL_0024:  brtrue.s   IL_002d

    IL_0026:  ldarg.0
    IL_0027:  ldfld      string class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_emptyText
    IL_002c:  ret

    IL_002d:  ldloc.0
    IL_002e:  ret
  } // end of method EnumTranslator`1::StringValue

  .method public hidebysig specialname instance class [mscorlib]System.Collections.Generic.List`1<string> 
          get_StringValues() cil managed
  {
    // Code size       17 (0x11)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<!0,string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_enumStringPairs
    IL_0006:  callvirt   instance class [mscorlib]System.Collections.Generic.Dictionary`2/ValueCollection<!0,!1> class [mscorlib]System.Collections.Generic.Dictionary`2<!T,string>::get_Values()
    IL_000b:  call       class [mscorlib]System.Collections.Generic.List`1<!!0> [System.Core]System.Linq.Enumerable::ToList<string>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0010:  ret
  } // end of method EnumTranslator`1::get_StringValues

  .method public hidebysig specialname instance class [mscorlib]System.Collections.Generic.List`1<!T> 
          get_EnumValues() cil managed
  {
    // Code size       17 (0x11)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<!0,string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1<!T>::_enumStringPairs
    IL_0006:  callvirt   instance class [mscorlib]System.Collections.Generic.Dictionary`2/KeyCollection<!0,!1> class [mscorlib]System.Collections.Generic.Dictionary`2<!T,string>::get_Keys()
    IL_000b:  call       class [mscorlib]System.Collections.Generic.List`1<!!0> [System.Core]System.Linq.Enumerable::ToList<!T>(class [mscorlib]System.Collections.Generic.IEnumerable`1<!!0>)
    IL_0010:  ret
  } // end of method EnumTranslator`1::get_EnumValues

  .property instance callconv(8) class [mscorlib]System.Collections.Generic.List`1<string>
          StringValues()
  {
    .get instance class [mscorlib]System.Collections.Generic.List`1<string> AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1::get_StringValues()
  } // end of property EnumTranslator`1::StringValues
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.List`1<!T>
          EnumValues()
  {
    .get instance class [mscorlib]System.Collections.Generic.List`1<!T> AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1::get_EnumValues()
  } // end of property EnumTranslator`1::EnumValues
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslator`1

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslatorOneWay`1<valuetype .ctor ([mscorlib]System.ValueType) T>
       extends [mscorlib]System.Object
{
  .field private initonly class [mscorlib]System.Collections.Generic.Dictionary`2<!T,string> _enumStringPairs
  .field private initonly string _emptyText
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class [mscorlib]System.Collections.Generic.Dictionary`2<!T,string> pairs,
                               string emptyText) cil managed
  {
    // Code size       36 (0x24)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  dup
    IL_0009:  brtrue.s   IL_0017

    IL_000b:  pop
    IL_000c:  ldstr      "pairs"
    IL_0011:  newobj     instance void [mscorlib]System.ArgumentNullException::.ctor(string)
    IL_0016:  throw

    IL_0017:  stfld      class [mscorlib]System.Collections.Generic.Dictionary`2<!0,string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslatorOneWay`1<!T>::_enumStringPairs
    IL_001c:  ldarg.0
    IL_001d:  ldarg.2
    IL_001e:  stfld      string class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslatorOneWay`1<!T>::_emptyText
    IL_0023:  ret
  } // end of method EnumTranslatorOneWay`1::.ctor

  .method public hidebysig instance string 
          StringValue(valuetype [mscorlib]System.Nullable`1<!T> e) cil managed
  {
    // Code size       47 (0x2f)
    .maxstack  3
    .locals init (string V_0)
    IL_0000:  ldarga.s   e
    IL_0002:  call       instance bool valuetype [mscorlib]System.Nullable`1<!T>::get_HasValue()
    IL_0007:  brtrue.s   IL_0010

    IL_0009:  ldarg.0
    IL_000a:  ldfld      string class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslatorOneWay`1<!T>::_emptyText
    IL_000f:  ret

    IL_0010:  ldarg.0
    IL_0011:  ldfld      class [mscorlib]System.Collections.Generic.Dictionary`2<!0,string> class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslatorOneWay`1<!T>::_enumStringPairs
    IL_0016:  ldarga.s   e
    IL_0018:  call       instance !0 valuetype [mscorlib]System.Nullable`1<!T>::get_Value()
    IL_001d:  ldloca.s   V_0
    IL_001f:  callvirt   instance bool class [mscorlib]System.Collections.Generic.Dictionary`2<!T,string>::TryGetValue(!0,
                                                                                                                       !1&)
    IL_0024:  brtrue.s   IL_002d

    IL_0026:  ldarg.0
    IL_0027:  ldfld      string class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslatorOneWay`1<!T>::_emptyText
    IL_002c:  ret

    IL_002d:  ldloc.0
    IL_002e:  ret
  } // end of method EnumTranslatorOneWay`1::StringValue

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.EnumTranslatorOneWay`1

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel
       implements AspenTech.EquipmentAnalysis.Infrastructure.IReferenceHolder,
                  AspenTech.EquipmentAnalysis.Infrastructure.IKeyedObject,
                  AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable,
                  [System]System.ComponentModel.INotifyPropertyChanged
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          get_PsvDbKey() cil managed
  {
  } // end of method IBaseModel::get_PsvDbKey

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype [mscorlib]System.Guid 
          get_ModelKey() cil managed
  {
  } // end of method IBaseModel::get_ModelKey

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IModelRegistry 
          get_ModelRegistry() cil managed
  {
  } // end of method IBaseModel::get_ModelRegistry

  .method public hidebysig newslot specialname abstract virtual 
          instance object  get_DataModel() cil managed
  {
  } // end of method IBaseModel::get_DataModel

  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey
          PsvDbKey()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_PsvDbKey()
  } // end of property IBaseModel::PsvDbKey
  .property instance callconv(8) valuetype [mscorlib]System.Guid
          ModelKey()
  {
    .get instance valuetype [mscorlib]System.Guid AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_ModelKey()
  } // end of property IBaseModel::ModelKey
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IModelRegistry
          ModelRegistry()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IModelRegistry AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_ModelRegistry()
  } // end of property IBaseModel::ModelRegistry
  .property instance callconv(8) object DataModel()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel::get_DataModel()
  } // end of property IBaseModel::DataModel
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel
{
  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_CXSDataPath() cil managed
  {
  } // end of method IPSVCXSModel::get_CXSDataPath

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_CXSDataPath(string 'value') cil managed
  {
  } // end of method IPSVCXSModel::set_CXSDataPath

  .property instance callconv(8) string CXSDataPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel::get_CXSDataPath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel::set_CXSDataPath(string)
  } // end of property IPSVCXSModel::CXSDataPath
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.INamedModel
       implements [System]System.ComponentModel.INotifyPropertyChanged
{
  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_FullName() cil managed
  {
  } // end of method INamedModel::get_FullName

  .property instance callconv(8) string FullName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.INamedModel::get_FullName()
  } // end of property INamedModel::FullName
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.INamedModel

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IMessageContainer`1<TMessageType>
{
  .method public hidebysig newslot abstract virtual 
          instance !TMessageType  AddNewMessage(valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel level,
                                                valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation location,
                                                string message,
                                                class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel refObject) cil managed
  {
  } // end of method IMessageContainer`1::AddNewMessage

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveMessage(!TMessageType message) cil managed
  {
  } // end of method IMessageContainer`1::RemoveMessage

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveMatchingMessages([opt] valuetype [mscorlib]System.Nullable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel> level,
                                                [opt] string message,
                                                [opt] valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation location,
                                                [opt] class [mscorlib]System.Collections.Generic.IEnumerable`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLocation> exceptLocation,
                                                [opt] class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel refObject) cil managed
  {
    .param [1] = nullref
    .param [2] = nullref
    .param [3] = int32(0x00000005)
    .param [4] = nullref
    .param [5] = nullref
  } // end of method IMessageContainer`1::RemoveMatchingMessages

  .method public hidebysig newslot abstract virtual 
          instance void  ClearMessages() cil managed
  {
  } // end of method IMessageContainer`1::ClearMessages

  .method public hidebysig newslot specialname abstract virtual 
          instance class [mscorlib]System.Collections.Generic.IReadOnlyList`1<!TMessageType> 
          get_Messages() cil managed
  {
  } // end of method IMessageContainer`1::get_Messages

  .property instance callconv(8) class [mscorlib]System.Collections.Generic.IReadOnlyList`1<!TMessageType>
          Messages()
  {
    .get instance class [mscorlib]System.Collections.Generic.IReadOnlyList`1<!TMessageType> AspenTech.EquipmentAnalysis.Infrastructure.IMessageContainer`1::get_Messages()
  } // end of property IMessageContainer`1::Messages
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IMessageContainer`1

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier
{
  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType 
          get_SpecifierType() cil managed
  {
  } // end of method IVariableSpecifier::get_SpecifierType

  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType
          SpecifierType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier::get_SpecifierType()
  } // end of property IVariableSpecifier::SpecifierType
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IProcessAction
       implements AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier
{
  .method public hidebysig newslot abstract virtual 
          instance void  InputChanged(class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable variable) cil managed
  {
  } // end of method IProcessAction::InputChanged

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IProcessAction

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ICalculationRunner
       implements AspenTech.EquipmentAnalysis.Infrastructure.IProcessAction,
                  AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class [mscorlib]System.Collections.Generic.IReadOnlyList`1<class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable> 
          get_Inputs() cil managed
  {
  } // end of method ICalculationRunner::get_Inputs

  .method public hidebysig newslot specialname abstract virtual 
          instance class [mscorlib]System.Collections.Generic.IReadOnlyList`1<class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable> 
          get_Outputs() cil managed
  {
  } // end of method ICalculationRunner::get_Outputs

  .method public hidebysig newslot abstract virtual 
          instance bool  Disconnect(class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable processVar) cil managed
  {
  } // end of method ICalculationRunner::Disconnect

  .method public hidebysig newslot abstract virtual 
          instance bool  InputsComplete() cil managed
  {
  } // end of method ICalculationRunner::InputsComplete

  .method public hidebysig newslot abstract virtual 
          instance bool  CanSetOutputs() cil managed
  {
  } // end of method ICalculationRunner::CanSetOutputs

  .method public hidebysig newslot abstract virtual 
          instance void  ClearOutputs() cil managed
  {
  } // end of method ICalculationRunner::ClearOutputs

  .method public hidebysig newslot abstract virtual 
          instance void  Execute() cil managed
  {
  } // end of method ICalculationRunner::Execute

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_CurrentVersion() cil managed
  {
  } // end of method ICalculationRunner::get_CurrentVersion

  .property instance callconv(8) class [mscorlib]System.Collections.Generic.IReadOnlyList`1<class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable>
          Inputs()
  {
    .get instance class [mscorlib]System.Collections.Generic.IReadOnlyList`1<class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable> AspenTech.EquipmentAnalysis.Infrastructure.ICalculationRunner::get_Inputs()
  } // end of property ICalculationRunner::Inputs
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.IReadOnlyList`1<class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable>
          Outputs()
  {
    .get instance class [mscorlib]System.Collections.Generic.IReadOnlyList`1<class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable> AspenTech.EquipmentAnalysis.Infrastructure.ICalculationRunner::get_Outputs()
  } // end of property ICalculationRunner::Outputs
  .property instance callconv(8) int32 CurrentVersion()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.ICalculationRunner::get_CurrentVersion()
  } // end of property ICalculationRunner::CurrentVersion
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ICalculationRunner

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.eDBConnectionSide
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eDBConnectionSide Neither = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eDBConnectionSide LHS = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eDBConnectionSide RHS = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eDBConnectionSide Both = int32(0x00000003)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.eDBConnectionSide

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IConnectedObjectList`1<T>
       implements class [mscorlib]System.Collections.Generic.IList`1<class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel>,
                  class [mscorlib]System.Collections.Generic.ICollection`1<class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel>,
                  class [mscorlib]System.Collections.Generic.IEnumerable`1<class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel>,
                  [mscorlib]System.Collections.IEnumerable
{
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IConnectedObjectList`1

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel 
          get_LHS() cil managed
  {
  } // end of method IStoredConnection::get_LHS

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel 
          get_RHS() cil managed
  {
  } // end of method IStoredConnection::get_RHS

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ConnectionName() cil managed
  {
  } // end of method IStoredConnection::get_ConnectionName

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ConnectionComment() cil managed
  {
  } // end of method IStoredConnection::get_ConnectionComment

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_ConnectionComment(string 'value') cil managed
  {
  } // end of method IStoredConnection::set_ConnectionComment

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_CascadeDelete_LtoR() cil managed
  {
  } // end of method IStoredConnection::get_CascadeDelete_LtoR

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_CascadeDelete_LtoR(bool 'value') cil managed
  {
  } // end of method IStoredConnection::set_CascadeDelete_LtoR

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_CascadeDelete_RtoL() cil managed
  {
  } // end of method IStoredConnection::get_CascadeDelete_RtoL

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_CascadeDelete_RtoL(bool 'value') cil managed
  {
  } // end of method IStoredConnection::set_CascadeDelete_RtoL

  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel
          LHS()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection::get_LHS()
  } // end of property IStoredConnection::LHS
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel
          RHS()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection::get_RHS()
  } // end of property IStoredConnection::RHS
  .property instance callconv(8) string ConnectionName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection::get_ConnectionName()
  } // end of property IStoredConnection::ConnectionName
  .property instance callconv(8) string ConnectionComment()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection::get_ConnectionComment()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection::set_ConnectionComment(string)
  } // end of property IStoredConnection::ConnectionComment
  .property instance callconv(8) bool CascadeDelete_LtoR()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection::get_CascadeDelete_LtoR()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection::set_CascadeDelete_LtoR(bool)
  } // end of property IStoredConnection::CascadeDelete_LtoR
  .property instance callconv(8) bool CascadeDelete_RtoL()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection::get_CascadeDelete_RtoL()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection::set_CascadeDelete_RtoL(bool)
  } // end of property IStoredConnection::CascadeDelete_RtoL
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IStoredConnection

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IOwnedObjectList`1<IBaseModel>
       implements class [mscorlib]System.Collections.Generic.IList`1<!IBaseModel>,
                  class [mscorlib]System.Collections.Generic.ICollection`1<!IBaseModel>,
                  class [mscorlib]System.Collections.Generic.IEnumerable`1<!IBaseModel>,
                  [mscorlib]System.Collections.IEnumerable
{
  .method public hidebysig newslot specialname abstract virtual 
          instance !IBaseModel  get_Owner() cil managed
  {
  } // end of method IOwnedObjectList`1::get_Owner

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType 
          get_MemberType() cil managed
  {
  } // end of method IOwnedObjectList`1::get_MemberType

  .property instance callconv(8) !IBaseModel
          Owner()
  {
    .get instance !IBaseModel AspenTech.EquipmentAnalysis.Infrastructure.IOwnedObjectList`1::get_Owner()
  } // end of property IOwnedObjectList`1::Owner
  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType
          MemberType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.IOwnedObjectList`1::get_MemberType()
  } // end of property IOwnedObjectList`1::MemberType
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IOwnedObjectList`1

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost
{
  .method public hidebysig newslot abstract virtual 
          instance void  Initialize(string objectId,
                                    class AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary messageProvider) cil managed
  {
  } // end of method ISafetyHost::Initialize

  .method public hidebysig newslot abstract virtual 
          instance void  ClearStatus() cil managed
  {
  } // end of method ISafetyHost::ClearStatus

  .method public hidebysig newslot abstract virtual 
          instance void  AddStatus(valuetype AspenTech.EquipmentAnalysis.Infrastructure.MessageLevel level,
                                   int32 count,
                                   string message) cil managed
  {
  } // end of method ISafetyHost::AddStatus

  .method public hidebysig newslot abstract virtual 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetStreamTemperature() cil managed
  {
  } // end of method ISafetyHost::GetStreamTemperature

  .method public hidebysig newslot abstract virtual 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetStreamPressure() cil managed
  {
  } // end of method ISafetyHost::GetStreamPressure

  .method public hidebysig newslot abstract virtual 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetStreamMassFlow(string scenarioId) cil managed
  {
  } // end of method ISafetyHost::GetStreamMassFlow

  .method public hidebysig newslot abstract virtual 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetRefStreamPressure(string scenarioId) cil managed
  {
  } // end of method ISafetyHost::GetRefStreamPressure

  .method public hidebysig newslot abstract virtual 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetRefStreamTemperature(string scenarioId) cil managed
  {
  } // end of method ISafetyHost::GetRefStreamTemperature

  .method public hidebysig newslot abstract virtual 
          instance valuetype [mscorlib]System.Nullable`1<float64> 
          GetTankStreamTemperature(string tankId,
                                   string streamId) cil managed
  {
  } // end of method ISafetyHost::GetTankStreamTemperature

  .method public hidebysig newslot abstract virtual 
          instance valuetype [mscorlib]System.Nullable`1<bool> 
          GetDirtyState(string objectId) cil managed
  {
  } // end of method ISafetyHost::GetDirtyState

  .method public hidebysig newslot abstract virtual 
          instance void  SetDirtyState(string objectId,
                                       bool 'value') cil managed
  {
  } // end of method ISafetyHost::SetDirtyState

  .method public hidebysig newslot abstract virtual 
          instance valuetype [mscorlib]System.Nullable`1<bool> 
          GetTankDirtyState(string tankId) cil managed
  {
  } // end of method ISafetyHost::GetTankDirtyState

  .method public hidebysig newslot abstract virtual 
          instance void  SetTankDirtyState(string tankId,
                                           bool 'value') cil managed
  {
  } // end of method ISafetyHost::SetTankDirtyState

  .method public hidebysig newslot abstract virtual 
          instance bool  DuplicateScenario(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey key,
                                           [opt] string scenarioId) cil managed
  {
    .param [2] = nullref
  } // end of method ISafetyHost::DuplicateScenario

  .method public hidebysig newslot abstract virtual 
          instance bool  PasteScenario(string newScenarioName,
                                       [opt] string newScenarioId) cil managed
  {
    .param [2] = nullref
  } // end of method ISafetyHost::PasteScenario

  .method public hidebysig newslot abstract virtual 
          instance void  SetValveData(string systemId,
                                      float64 calcOrifice,
                                      float64 selectedOrifice,
                                      string orificeDesignation,
                                      bool isSizingCase,
                                      float64 inletFlangeSize,
                                      float64 outletFlangeSize) cil managed
  {
  } // end of method ISafetyHost::SetValveData

  .method public hidebysig newslot abstract virtual 
          instance string  GetRefStreamName(string scenarioId) cil managed
  {
  } // end of method ISafetyHost::GetRefStreamName

  .method public hidebysig newslot abstract virtual 
          instance string  GetTankStreamName(string tankId) cil managed
  {
  } // end of method ISafetyHost::GetTankStreamName

  .method public hidebysig newslot abstract virtual 
          instance bool  GetTankUsesPropertyPackage(string tankId) cil managed
  {
  } // end of method ISafetyHost::GetTankUsesPropertyPackage

  .method public hidebysig newslot abstract virtual 
          instance void  SetTankUsesPropertyPackage(string tankId,
                                                    bool 'value') cil managed
  {
  } // end of method ISafetyHost::SetTankUsesPropertyPackage

  .method public hidebysig newslot abstract virtual 
          instance string  GetTankUpdatedId(string tankId,
                                            string newTankName) cil managed
  {
  } // end of method ISafetyHost::GetTankUpdatedId

  .method public hidebysig newslot abstract virtual 
          instance void  InvokeOnUi(object 'instance',
                                    class [mscorlib]System.Delegate 'method',
                                    object[] args) cil managed
  {
    .param [3]
    .custom instance void [mscorlib]System.ParamArrayAttribute::.ctor() = ( 01 00 00 00 ) 
  } // end of method ISafetyHost::InvokeOnUi

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ISafetyHost

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IEquipmentAnalysisInContextGuidanceAgent
{
  .method public hidebysig newslot abstract virtual 
          instance void  SetHelpId(class [PresentationCore]System.Windows.UIElement element,
                                   int32 helpId) cil managed
  {
  } // end of method IEquipmentAnalysisInContextGuidanceAgent::SetHelpId

  .method public hidebysig newslot abstract virtual 
          instance class [PresentationCore]System.Windows.UIElement 
          CreateInContextGuidanceButtonForTabControl(class [PresentationFramework]System.Windows.Controls.TabControl target) cil managed
  {
  } // end of method IEquipmentAnalysisInContextGuidanceAgent::CreateInContextGuidanceButtonForTabControl

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IEquipmentAnalysisInContextGuidanceAgent

.class public abstract auto ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.InContextGuidanceExtensions
       extends [mscorlib]System.Object
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.ExtensionAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig static void  SetHelpId(class [PresentationCore]System.Windows.UIElement element,
                                                  int32 helpId,
                                                  class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer unityContainer) cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.ExtensionAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       47 (0x2f)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.Infrastructure.IEquipmentAnalysisInContextGuidanceAgent V_0)
    IL_0000:  ldarg.0
    IL_0001:  brtrue.s   IL_000e

    IL_0003:  ldstr      "element"
    IL_0008:  newobj     instance void [mscorlib]System.ArgumentNullException::.ctor(string)
    IL_000d:  throw

    IL_000e:  ldarg.2
    IL_000f:  brtrue.s   IL_001c

    IL_0011:  ldstr      "unityContainer"
    IL_0016:  newobj     instance void [mscorlib]System.ArgumentNullException::.ctor(string)
    IL_001b:  throw

    IL_001c:  ldarg.2
    IL_001d:  call       !!0 [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvUnityContainerExtensions::TryResolve<class AspenTech.EquipmentAnalysis.Infrastructure.IEquipmentAnalysisInContextGuidanceAgent>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer)
    IL_0022:  stloc.0
    IL_0023:  ldloc.0
    IL_0024:  brfalse.s  IL_002e

    IL_0026:  ldloc.0
    IL_0027:  ldarg.0
    IL_0028:  ldarg.1
    IL_0029:  callvirt   instance void AspenTech.EquipmentAnalysis.Infrastructure.IEquipmentAnalysisInContextGuidanceAgent::SetHelpId(class [PresentationCore]System.Windows.UIElement,
                                                                                                                                      int32)
    IL_002e:  ret
  } // end of method InContextGuidanceExtensions::SetHelpId

  .method public hidebysig static class [PresentationCore]System.Windows.UIElement 
          CreateInContextGuidanceButtonForTabControl(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer unityContainer,
                                                     class [PresentationFramework]System.Windows.Controls.TabControl target) cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.ExtensionAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  brtrue.s   IL_000e

    IL_0003:  ldstr      "unityContainer"
    IL_0008:  newobj     instance void [mscorlib]System.ArgumentNullException::.ctor(string)
    IL_000d:  throw

    IL_000e:  ldarg.0
    IL_000f:  call       !!0 [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvUnityContainerExtensions::TryResolve<class AspenTech.EquipmentAnalysis.Infrastructure.IEquipmentAnalysisInContextGuidanceAgent>(class [Microsoft.Practices.Unity]Microsoft.Practices.Unity.IUnityContainer)
    IL_0014:  dup
    IL_0015:  brtrue.s   IL_001a

    IL_0017:  pop
    IL_0018:  ldnull
    IL_0019:  ret

    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance class [PresentationCore]System.Windows.UIElement AspenTech.EquipmentAnalysis.Infrastructure.IEquipmentAnalysisInContextGuidanceAgent::CreateInContextGuidanceButtonForTabControl(class [PresentationFramework]System.Windows.Controls.TabControl)
    IL_0020:  ret
  } // end of method InContextGuidanceExtensions::CreateInContextGuidanceButtonForTabControl

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.InContextGuidanceExtensions

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.INotifyInvalidValueEntered
{
  .method public hidebysig newslot specialname abstract virtual 
          instance void  add_InvalidValueEntered(class [mscorlib]System.EventHandler`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs> 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  } // end of method INotifyInvalidValueEntered::add_InvalidValueEntered

  .method public hidebysig newslot specialname abstract virtual 
          instance void  remove_InvalidValueEntered(class [mscorlib]System.EventHandler`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs> 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  } // end of method INotifyInvalidValueEntered::remove_InvalidValueEntered

  .event class [mscorlib]System.EventHandler`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs> InvalidValueEntered
  {
    .addon instance void AspenTech.EquipmentAnalysis.Infrastructure.INotifyInvalidValueEntered::add_InvalidValueEntered(class [mscorlib]System.EventHandler`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs>)
    .removeon instance void AspenTech.EquipmentAnalysis.Infrastructure.INotifyInvalidValueEntered::remove_InvalidValueEntered(class [mscorlib]System.EventHandler`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs>)
  } // end of event INotifyInvalidValueEntered::InvalidValueEntered
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.INotifyInvalidValueEntered

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IPSVScreen
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel> 
          get_ActiveModels() cil managed
  {
  } // end of method IPSVScreen::get_ActiveModels

  .property instance callconv(8) class [mscorlib]System.Collections.Generic.IEnumerable`1<class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel>
          ActiveModels()
  {
    .get instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel> AspenTech.EquipmentAnalysis.Infrastructure.IPSVScreen::get_ActiveModels()
  } // end of property IPSVScreen::ActiveModels
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IPSVScreen

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IKeyedObject
{
  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype [mscorlib]System.Guid 
          get_Key() cil managed
  {
  } // end of method IKeyedObject::get_Key

  .property instance callconv(8) valuetype [mscorlib]System.Guid
          Key()
  {
    .get instance valuetype [mscorlib]System.Guid AspenTech.EquipmentAnalysis.Infrastructure.IKeyedObject::get_Key()
  } // end of property IKeyedObject::Key
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IKeyedObject

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable
       implements AspenTech.EquipmentAnalysis.Infrastructure.IKeyedObject
{
  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsBeingDeleted() cil managed
  {
  } // end of method IReferenceable::get_IsBeingDeleted

  .method public hidebysig newslot abstract virtual 
          instance void  Delete() cil managed
  {
  } // end of method IReferenceable::Delete

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceHolder 
          GetParent() cil managed
  {
  } // end of method IReferenceable::GetParent

  .method public hidebysig newslot abstract virtual 
          instance void  ParentAssigned() cil managed
  {
  } // end of method IReferenceable::ParentAssigned

  .property instance callconv(8) bool IsBeingDeleted()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable::get_IsBeingDeleted()
  } // end of property IReferenceable::IsBeingDeleted
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IReferenceHolder
       implements AspenTech.EquipmentAnalysis.Infrastructure.IKeyedObject
{
  .method public hidebysig newslot abstract virtual 
          instance void  ReferenceChanged(class AspenTech.EquipmentAnalysis.Infrastructure.IManagedReference reference,
                                          class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceUpdate update) cil managed
  {
  } // end of method IReferenceHolder::ReferenceChanged

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceHolder

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IManagedReference
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceHolder 
          get_Source() cil managed
  {
  } // end of method IManagedReference::get_Source

  .method public hidebysig newslot abstract virtual 
          instance void  RemoveDeletedTarget(class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable target) cil managed
  {
  } // end of method IManagedReference::RemoveDeletedTarget

  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceHolder
          Source()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceHolder AspenTech.EquipmentAnalysis.Infrastructure.IManagedReference::get_Source()
  } // end of property IManagedReference::Source
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IManagedReference

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType Assign = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType Append = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType Insert = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType Remove = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType RemoveDeleted = int32(0x00000004)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IReferenceUpdate
{
  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType 
          get_UpdateType() cil managed
  {
  } // end of method IReferenceUpdate::get_UpdateType

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable 
          get_Old() cil managed
  {
  } // end of method IReferenceUpdate::get_Old

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable 
          get_New() cil managed
  {
  } // end of method IReferenceUpdate::get_New

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype [mscorlib]System.Nullable`1<int32> 
          get_Index() cil managed
  {
  } // end of method IReferenceUpdate::get_Index

  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType
          UpdateType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReferenceUpdateType AspenTech.EquipmentAnalysis.Infrastructure.IReferenceUpdate::get_UpdateType()
  } // end of property IReferenceUpdate::UpdateType
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable
          Old()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable AspenTech.EquipmentAnalysis.Infrastructure.IReferenceUpdate::get_Old()
  } // end of property IReferenceUpdate::Old
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable
          New()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceable AspenTech.EquipmentAnalysis.Infrastructure.IReferenceUpdate::get_New()
  } // end of property IReferenceUpdate::New
  .property instance callconv(8) valuetype [mscorlib]System.Nullable`1<int32>
          Index()
  {
    .get instance valuetype [mscorlib]System.Nullable`1<int32> AspenTech.EquipmentAnalysis.Infrastructure.IReferenceUpdate::get_Index()
  } // end of property IReferenceUpdate::Index
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IReferenceUpdate

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ISerializableObject
{
  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsBeingRecalled() cil managed
  {
  } // end of method ISerializableObject::get_IsBeingRecalled

  .property instance callconv(8) bool IsBeingRecalled()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.ISerializableObject::get_IsBeingRecalled()
  } // end of property ISerializableObject::IsBeingRecalled
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ISerializableObject

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar 
          get_TankItem() cil managed
  {
  } // end of method IStorageTankViewModel::get_TankItem

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar 
          get_Service() cil managed
  {
  } // end of method IStorageTankViewModel::get_Service

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar 
          get_FluidName() cil managed
  {
  } // end of method IStorageTankViewModel::get_FluidName

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankCalcCode> 
          get_CalcCode() cil managed
  {
  } // end of method IStorageTankViewModel::get_CalcCode

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_BarometricPressure() cil managed
  {
  } // end of method IStorageTankViewModel::get_BarometricPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_InFlow() cil managed
  {
  } // end of method IStorageTankViewModel::get_InFlow

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_OutFlow() cil managed
  {
  } // end of method IStorageTankViewModel::get_OutFlow

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.VesselTypeEnum> 
          get_TankType() cil managed
  {
  } // end of method IStorageTankViewModel::get_TankType

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_Diameter() cil managed
  {
  } // end of method IStorageTankViewModel::get_Diameter

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_Height() cil managed
  {
  } // end of method IStorageTankViewModel::get_Height

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar 
          get_NormalDeviceItem() cil managed
  {
  } // end of method IStorageTankViewModel::get_NormalDeviceItem

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_ThermalInBreath() cil managed
  {
  } // end of method IStorageTankViewModel::get_ThermalInBreath

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_ThermalOutBreath() cil managed
  {
  } // end of method IStorageTankViewModel::get_ThermalOutBreath

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_InBreathing() cil managed
  {
  } // end of method IStorageTankViewModel::get_InBreathing

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_OutBreathing() cil managed
  {
  } // end of method IStorageTankViewModel::get_OutBreathing

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_TotalInBreathing() cil managed
  {
  } // end of method IStorageTankViewModel::get_TotalInBreathing

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_TotalOutBreathing() cil managed
  {
  } // end of method IStorageTankViewModel::get_TotalOutBreathing

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure 
          get_DesignPressure() cil managed
  {
  } // end of method IStorageTankViewModel::get_DesignPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_DesignVacuum() cil managed
  {
  } // end of method IStorageTankViewModel::get_DesignVacuum

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar 
          get_F() cil managed
  {
  } // end of method IStorageTankViewModel::get_F

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.ProcessDataSource> 
          get_FDataSource() cil managed
  {
  } // end of method IStorageTankViewModel::get_FDataSource

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_InsulationThermalConductivity() cil managed
  {
  } // end of method IStorageTankViewModel::get_InsulationThermalConductivity

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_InsulationThickness() cil managed
  {
  } // end of method IStorageTankViewModel::get_InsulationThickness

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_Elevation() cil managed
  {
  } // end of method IStorageTankViewModel::get_Elevation

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_FlameHeight() cil managed
  {
  } // end of method IStorageTankViewModel::get_FlameHeight

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_CalculatedHeatInput() cil managed
  {
  } // end of method IStorageTankViewModel::get_CalculatedHeatInput

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_FluidLatentHeat() cil managed
  {
  } // end of method IStorageTankViewModel::get_FluidLatentHeat

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_CalculatedRelievingFlow() cil managed
  {
  } // end of method IStorageTankViewModel::get_CalculatedRelievingFlow

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice> 
          get_NormalDeviceType() cil managed
  {
  } // end of method IStorageTankViewModel::get_NormalDeviceType

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure 
          get_NormalDeviceSetPressure() cil managed
  {
  } // end of method IStorageTankViewModel::get_NormalDeviceSetPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_NormalDeviceSetVacuumPressure() cil managed
  {
  } // end of method IStorageTankViewModel::get_NormalDeviceSetVacuumPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<valuetype [mscorlib]System.Nullable`1<bool>> 
          get_NormalVenting() cil managed
  {
  } // end of method IStorageTankViewModel::get_NormalVenting

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<valuetype [mscorlib]System.Nullable`1<bool>> 
          get_EmergencyVenting() cil managed
  {
  } // end of method IStorageTankViewModel::get_EmergencyVenting

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar 
          get_EmergencyDeviceItem() cil managed
  {
  } // end of method IStorageTankViewModel::get_EmergencyDeviceItem

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice> 
          get_EmergencyDeviceType() cil managed
  {
  } // end of method IStorageTankViewModel::get_EmergencyDeviceType

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure 
          get_EmergencyDeviceSetPressure() cil managed
  {
  } // end of method IStorageTankViewModel::get_EmergencyDeviceSetPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_EmergencyDeviceGasTemperature() cil managed
  {
  } // end of method IStorageTankViewModel::get_EmergencyDeviceGasTemperature

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_EmergencyDeviceGasMolecularWeight() cil managed
  {
  } // end of method IStorageTankViewModel::get_EmergencyDeviceGasMolecularWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_InitialTemperature() cil managed
  {
  } // end of method IStorageTankViewModel::get_InitialTemperature

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_FinalTemperature() cil managed
  {
  } // end of method IStorageTankViewModel::get_FinalTemperature

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_VaporSpaceMolecularWeight() cil managed
  {
  } // end of method IStorageTankViewModel::get_VaporSpaceMolecularWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure 
          get_OperatingPressure() cil managed
  {
  } // end of method IStorageTankViewModel::get_OperatingPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_CalculatedArea() cil managed
  {
  } // end of method IStorageTankViewModel::get_CalculatedArea

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_NormalInArea() cil managed
  {
  } // end of method IStorageTankViewModel::get_NormalInArea

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_NormalOutArea() cil managed
  {
  } // end of method IStorageTankViewModel::get_NormalOutArea

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_NormalInSize() cil managed
  {
  } // end of method IStorageTankViewModel::get_NormalInSize

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_NormalOutSize() cil managed
  {
  } // end of method IStorageTankViewModel::get_NormalOutSize

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_EmergencyOutArea() cil managed
  {
  } // end of method IStorageTankViewModel::get_EmergencyOutArea

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_EmergencyOutSize() cil managed
  {
  } // end of method IStorageTankViewModel::get_EmergencyOutSize

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar 
          get_Notes() cil managed
  {
  } // end of method IStorageTankViewModel::get_Notes

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.LatitudeEnum> 
          get_Latitude() cil managed
  {
  } // end of method IStorageTankViewModel::get_Latitude

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar 
          get_InsulationRatio() cil managed
  {
  } // end of method IStorageTankViewModel::get_InsulationRatio

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.RelVapPressEnum> 
          get_RelativeVaporPressure() cil managed
  {
  } // end of method IStorageTankViewModel::get_RelativeVaporPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_EvaporationRate() cil managed
  {
  } // end of method IStorageTankViewModel::get_EvaporationRate

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_InsulationThermalConductivityToFire() cil managed
  {
  } // end of method IStorageTankViewModel::get_InsulationThermalConductivityToFire

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.TankNormalAPIEditionEnum> 
          get_NormalMethod() cil managed
  {
  } // end of method IStorageTankViewModel::get_NormalMethod

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<valuetype [mscorlib]System.Nullable`1<bool>> 
          get_IsVolatileLiquid() cil managed
  {
  } // end of method IStorageTankViewModel::get_IsVolatileLiquid

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity 
          get_MaxOperatingTemperature() cil managed
  {
  } // end of method IStorageTankViewModel::get_MaxOperatingTemperature

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar 
          get_Capacity() cil managed
  {
  } // end of method IStorageTankViewModel::get_Capacity

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar 
          get_AreaFractionNotContained() cil managed
  {
  } // end of method IStorageTankViewModel::get_AreaFractionNotContained

  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
          TankItem()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_TankItem()
  } // end of property IStorageTankViewModel::TankItem
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
          Service()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_Service()
  } // end of property IStorageTankViewModel::Service
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
          FluidName()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_FluidName()
  } // end of property IStorageTankViewModel::FluidName
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankCalcCode>
          CalcCode()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankCalcCode> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_CalcCode()
  } // end of property IStorageTankViewModel::CalcCode
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          BarometricPressure()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_BarometricPressure()
  } // end of property IStorageTankViewModel::BarometricPressure
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          InFlow()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_InFlow()
  } // end of property IStorageTankViewModel::InFlow
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          OutFlow()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_OutFlow()
  } // end of property IStorageTankViewModel::OutFlow
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.VesselTypeEnum>
          TankType()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.VesselTypeEnum> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_TankType()
  } // end of property IStorageTankViewModel::TankType
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          Diameter()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_Diameter()
  } // end of property IStorageTankViewModel::Diameter
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          Height()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_Height()
  } // end of property IStorageTankViewModel::Height
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
          NormalDeviceItem()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_NormalDeviceItem()
  } // end of property IStorageTankViewModel::NormalDeviceItem
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          ThermalInBreath()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_ThermalInBreath()
  } // end of property IStorageTankViewModel::ThermalInBreath
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          ThermalOutBreath()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_ThermalOutBreath()
  } // end of property IStorageTankViewModel::ThermalOutBreath
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          InBreathing()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_InBreathing()
  } // end of property IStorageTankViewModel::InBreathing
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          OutBreathing()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_OutBreathing()
  } // end of property IStorageTankViewModel::OutBreathing
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          TotalInBreathing()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_TotalInBreathing()
  } // end of property IStorageTankViewModel::TotalInBreathing
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          TotalOutBreathing()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_TotalOutBreathing()
  } // end of property IStorageTankViewModel::TotalOutBreathing
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure
          DesignPressure()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_DesignPressure()
  } // end of property IStorageTankViewModel::DesignPressure
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          DesignVacuum()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_DesignVacuum()
  } // end of property IStorageTankViewModel::DesignVacuum
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
          F()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_F()
  } // end of property IStorageTankViewModel::F
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.ProcessDataSource>
          FDataSource()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.ProcessDataSource> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_FDataSource()
  } // end of property IStorageTankViewModel::FDataSource
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          InsulationThermalConductivity()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_InsulationThermalConductivity()
  } // end of property IStorageTankViewModel::InsulationThermalConductivity
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          InsulationThickness()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_InsulationThickness()
  } // end of property IStorageTankViewModel::InsulationThickness
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          Elevation()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_Elevation()
  } // end of property IStorageTankViewModel::Elevation
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          FlameHeight()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_FlameHeight()
  } // end of property IStorageTankViewModel::FlameHeight
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          CalculatedHeatInput()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_CalculatedHeatInput()
  } // end of property IStorageTankViewModel::CalculatedHeatInput
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          FluidLatentHeat()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_FluidLatentHeat()
  } // end of property IStorageTankViewModel::FluidLatentHeat
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          CalculatedRelievingFlow()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_CalculatedRelievingFlow()
  } // end of property IStorageTankViewModel::CalculatedRelievingFlow
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice>
          NormalDeviceType()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_NormalDeviceType()
  } // end of property IStorageTankViewModel::NormalDeviceType
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure
          NormalDeviceSetPressure()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_NormalDeviceSetPressure()
  } // end of property IStorageTankViewModel::NormalDeviceSetPressure
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          NormalDeviceSetVacuumPressure()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_NormalDeviceSetVacuumPressure()
  } // end of property IStorageTankViewModel::NormalDeviceSetVacuumPressure
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<valuetype [mscorlib]System.Nullable`1<bool>>
          NormalVenting()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<valuetype [mscorlib]System.Nullable`1<bool>> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_NormalVenting()
  } // end of property IStorageTankViewModel::NormalVenting
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<valuetype [mscorlib]System.Nullable`1<bool>>
          EmergencyVenting()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<valuetype [mscorlib]System.Nullable`1<bool>> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_EmergencyVenting()
  } // end of property IStorageTankViewModel::EmergencyVenting
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
          EmergencyDeviceItem()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_EmergencyDeviceItem()
  } // end of property IStorageTankViewModel::EmergencyDeviceItem
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice>
          EmergencyDeviceType()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype AspenTech.EquipmentAnalysis.Infrastructure.StorageTankVentDevice> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_EmergencyDeviceType()
  } // end of property IStorageTankViewModel::EmergencyDeviceType
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure
          EmergencyDeviceSetPressure()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_EmergencyDeviceSetPressure()
  } // end of property IStorageTankViewModel::EmergencyDeviceSetPressure
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          EmergencyDeviceGasTemperature()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_EmergencyDeviceGasTemperature()
  } // end of property IStorageTankViewModel::EmergencyDeviceGasTemperature
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          EmergencyDeviceGasMolecularWeight()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_EmergencyDeviceGasMolecularWeight()
  } // end of property IStorageTankViewModel::EmergencyDeviceGasMolecularWeight
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          InitialTemperature()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_InitialTemperature()
  } // end of property IStorageTankViewModel::InitialTemperature
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          FinalTemperature()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_FinalTemperature()
  } // end of property IStorageTankViewModel::FinalTemperature
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          VaporSpaceMolecularWeight()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_VaporSpaceMolecularWeight()
  } // end of property IStorageTankViewModel::VaporSpaceMolecularWeight
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure
          OperatingPressure()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_OperatingPressure()
  } // end of property IStorageTankViewModel::OperatingPressure
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          CalculatedArea()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_CalculatedArea()
  } // end of property IStorageTankViewModel::CalculatedArea
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          NormalInArea()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_NormalInArea()
  } // end of property IStorageTankViewModel::NormalInArea
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          NormalOutArea()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_NormalOutArea()
  } // end of property IStorageTankViewModel::NormalOutArea
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          NormalInSize()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_NormalInSize()
  } // end of property IStorageTankViewModel::NormalInSize
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          NormalOutSize()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_NormalOutSize()
  } // end of property IStorageTankViewModel::NormalOutSize
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          EmergencyOutArea()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_EmergencyOutArea()
  } // end of property IStorageTankViewModel::EmergencyOutArea
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          EmergencyOutSize()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_EmergencyOutSize()
  } // end of property IStorageTankViewModel::EmergencyOutSize
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
          Notes()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_Notes()
  } // end of property IStorageTankViewModel::Notes
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.LatitudeEnum>
          Latitude()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.LatitudeEnum> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_Latitude()
  } // end of property IStorageTankViewModel::Latitude
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
          InsulationRatio()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_InsulationRatio()
  } // end of property IStorageTankViewModel::InsulationRatio
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.RelVapPressEnum>
          RelativeVaporPressure()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.RelVapPressEnum> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_RelativeVaporPressure()
  } // end of property IStorageTankViewModel::RelativeVaporPressure
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          EvaporationRate()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_EvaporationRate()
  } // end of property IStorageTankViewModel::EvaporationRate
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          InsulationThermalConductivityToFire()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_InsulationThermalConductivityToFire()
  } // end of property IStorageTankViewModel::InsulationThermalConductivityToFire
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.TankNormalAPIEditionEnum>
          NormalMethod()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype [PSVSizingEngine]PSVSizingEngine.TankNormalAPIEditionEnum> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_NormalMethod()
  } // end of property IStorageTankViewModel::NormalMethod
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<valuetype [mscorlib]System.Nullable`1<bool>>
          IsVolatileLiquid()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<valuetype [mscorlib]System.Nullable`1<bool>> AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_IsVolatileLiquid()
  } // end of property IStorageTankViewModel::IsVolatileLiquid
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
          MaxOperatingTemperature()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_MaxOperatingTemperature()
  } // end of property IStorageTankViewModel::MaxOperatingTemperature
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
          Capacity()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_Capacity()
  } // end of property IStorageTankViewModel::Capacity
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
          AreaFractionNotContained()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel::get_AreaFractionNotContained()
  } // end of property IStorageTankViewModel::AreaFractionNotContained
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IStorageTankViewModel

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<T>
       implements [System]System.ComponentModel.INotifyPropertyChanged
{
  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType 
          get_VarSpecifierType() cil managed
  {
  } // end of method IProcessVarViewModel`1::get_VarSpecifierType

  .method public hidebysig newslot specialname abstract virtual 
          instance !T  get_DisplayValue() cil managed
  {
  } // end of method IProcessVarViewModel`1::get_DisplayValue

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_DisplayValue(!T 'value') cil managed
  {
  } // end of method IProcessVarViewModel`1::set_DisplayValue

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() cil managed
  {
  } // end of method IProcessVarViewModel`1::get_IsValid

  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType
          VarSpecifierType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.SpecifierType AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1::get_VarSpecifierType()
  } // end of property IProcessVarViewModel`1::VarSpecifierType
  .property instance callconv(8) !T DisplayValue()
  {
    .get instance !T AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1::get_DisplayValue()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1::set_DisplayValue(!T)
  } // end of property IProcessVarViewModel`1::DisplayValue
  .property instance callconv(8) bool IsValid()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1::get_IsValid()
  } // end of property IProcessVarViewModel`1::IsValid
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar
       implements class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<string>,
                  [System]System.ComponentModel.INotifyPropertyChanged
{
  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ClipboardValue() cil managed
  {
  } // end of method ITextBoxProcessVar::get_ClipboardValue

  .property instance callconv(8) string ClipboardValue()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar::get_ClipboardValue()
  } // end of property ITextBoxProcessVar::ClipboardValue
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity
       implements AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar,
                  class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<string>,
                  [System]System.ComponentModel.INotifyPropertyChanged
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.IUnitOfMeasure 
          get_DisplayUnit() cil managed
  {
  } // end of method ITextBoxQuantity::get_DisplayUnit

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_DisplayUnit(class [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.IUnitOfMeasure 'value') cil managed
  {
  } // end of method ITextBoxQuantity::set_DisplayUnit

  .method public hidebysig newslot specialname abstract virtual 
          instance class [System]System.Collections.ObjectModel.ObservableCollection`1<class [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.IUnitOfMeasure> 
          get_AvailableUnits() cil managed
  {
  } // end of method ITextBoxQuantity::get_AvailableUnits

  .property instance callconv(8) class [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.IUnitOfMeasure
          DisplayUnit()
  {
    .get instance class [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.IUnitOfMeasure AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity::get_DisplayUnit()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity::set_DisplayUnit(class [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.IUnitOfMeasure)
  } // end of property ITextBoxQuantity::DisplayUnit
  .property instance callconv(8) class [System]System.Collections.ObjectModel.ObservableCollection`1<class [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.IUnitOfMeasure>
          AvailableUnits()
  {
    .get instance class [System]System.Collections.ObjectModel.ObservableCollection`1<class [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.IUnitOfMeasure> AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity::get_AvailableUnits()
  } // end of property ITextBoxQuantity::AvailableUnits
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure
       implements AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxQuantity,
                  AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxProcessVar,
                  class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<string>,
                  [System]System.ComponentModel.INotifyPropertyChanged
{
  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.PressureReference 
          get_PressureReference() cil managed
  {
  } // end of method ITextBoxPressure::get_PressureReference

  .property instance callconv(8) valuetype [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.PressureReference
          PressureReference()
  {
    .get instance valuetype [AspenTech.EquipmentAnalysis.Resources]AspenTech.EquipmentAnalysis.Resources.PressureReference AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure::get_PressureReference()
  } // end of property ITextBoxPressure::PressureReference
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ITextBoxPressure

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1<valuetype .ctor ([mscorlib]System.IConvertible, [mscorlib]System.ValueType) T>
       implements class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVarViewModel`1<valuetype [mscorlib]System.Nullable`1<!T>>,
                  [System]System.ComponentModel.INotifyPropertyChanged
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class [System]System.Collections.ObjectModel.ObservableCollection`1<valuetype [mscorlib]System.Nullable`1<!T>> 
          get_AvailableValues() cil managed
  {
  } // end of method IProcessEnumViewModel`1::get_AvailableValues

  .property instance callconv(8) class [System]System.Collections.ObjectModel.ObservableCollection`1<valuetype [mscorlib]System.Nullable`1<!T>>
          AvailableValues()
  {
    .get instance class [System]System.Collections.ObjectModel.ObservableCollection`1<valuetype [mscorlib]System.Nullable`1<!T>> AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1::get_AvailableValues()
  } // end of property IProcessEnumViewModel`1::AvailableValues
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IProcessEnumViewModel`1

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IFluidForHydraulics
{
  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_StreamName() cil managed
  {
  } // end of method IFluidForHydraulics::get_StreamName

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_PackageName() cil managed
  {
  } // end of method IFluidForHydraulics::get_PackageName

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_HasCustomPropertySlate() cil managed
  {
  } // end of method IFluidForHydraulics::get_HasCustomPropertySlate

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ComponentListXml() cil managed
  {
  } // end of method IFluidForHydraulics::get_ComponentListXml

  .property instance callconv(8) string StreamName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IFluidForHydraulics::get_StreamName()
  } // end of property IFluidForHydraulics::StreamName
  .property instance callconv(8) string PackageName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IFluidForHydraulics::get_PackageName()
  } // end of property IFluidForHydraulics::PackageName
  .property instance callconv(8) bool HasCustomPropertySlate()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IFluidForHydraulics::get_HasCustomPropertySlate()
  } // end of property IFluidForHydraulics::HasCustomPropertySlate
  .property instance callconv(8) string ComponentListXml()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IFluidForHydraulics::get_ComponentListXml()
  } // end of property IFluidForHydraulics::ComponentListXml
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IFluidForHydraulics

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IImportWizard
{
  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_DBPath() cil managed
  {
  } // end of method IImportWizard::get_DBPath

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_DBPath(string 'value') cil managed
  {
  } // end of method IImportWizard::set_DBPath

  .method public hidebysig newslot abstract virtual 
          instance void  Initialize() cil managed
  {
  } // end of method IImportWizard::Initialize

  .method public hidebysig newslot abstract virtual 
          instance bool  Exit() cil managed
  {
  } // end of method IImportWizard::Exit

  .property instance callconv(8) string DBPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IImportWizard::get_DBPath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IImportWizard::set_DBPath(string)
  } // end of property IImportWizard::DBPath
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IImportWizard

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IModelRegistry
       implements AspenTech.EquipmentAnalysis.Infrastructure.IReferenceHolder,
                  AspenTech.EquipmentAnalysis.Infrastructure.IKeyedObject
{
  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() cil managed
  {
  } // end of method IModelRegistry::get_Count

  .method public hidebysig newslot specialname abstract virtual 
          instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop 
          get_AdbTop() cil managed
  {
  } // end of method IModelRegistry::get_AdbTop

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsDirty() cil managed
  {
  } // end of method IModelRegistry::get_IsDirty

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_IsDirty(bool 'value') cil managed
  {
  } // end of method IModelRegistry::set_IsDirty

  .property instance callconv(8) int32 Count()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.IModelRegistry::get_Count()
  } // end of property IModelRegistry::Count
  .property instance callconv(8) class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop
          AdbTop()
  {
    .get instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.Infrastructure.IModelRegistry::get_AdbTop()
  } // end of property IModelRegistry::AdbTop
  .property instance callconv(8) bool IsDirty()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IModelRegistry::get_IsDirty()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IModelRegistry::set_IsDirty(bool)
  } // end of property IModelRegistry::IsDirty
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IModelRegistry

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable
       implements [System]System.ComponentModel.INotifyPropertyChanged,
                  AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel 
          get_Model() cil managed
  {
  } // end of method IProcessVariable::get_Model

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsValid() cil managed
  {
  } // end of method IProcessVariable::get_IsValid

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsEmpty() cil managed
  {
  } // end of method IProcessVariable::get_IsEmpty

  .method public hidebysig newslot abstract virtual 
          instance void  Reset(class AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier specifier) cil managed
  {
  } // end of method IProcessVariable::Reset

  .method public hidebysig newslot abstract virtual 
          instance void  Clear(class AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier specifier) cil managed
  {
  } // end of method IProcessVariable::Clear

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier 
          get_Source() cil managed
  {
  } // end of method IProcessVariable::get_Source

  .method public hidebysig newslot specialname abstract virtual 
          instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class AspenTech.EquipmentAnalysis.Infrastructure.IProcessAction> 
          get_AffectedProcessActions() cil managed
  {
  } // end of method IProcessVariable::get_AffectedProcessActions

  .method public hidebysig newslot abstract virtual 
          instance void  AddAffectedProcessAction(class AspenTech.EquipmentAnalysis.Infrastructure.IProcessAction processAction) cil managed
  {
  } // end of method IProcessVariable::AddAffectedProcessAction

  .method public hidebysig newslot abstract virtual 
          instance bool  RemoveAffectedProcessAction(class AspenTech.EquipmentAnalysis.Infrastructure.IProcessAction processAction) cil managed
  {
  } // end of method IProcessVariable::RemoveAffectedProcessAction

  .method public hidebysig newslot abstract virtual 
          instance bool  TrySpecifyFrom(class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable processVariable) cil managed
  {
  } // end of method IProcessVariable::TrySpecifyFrom

  .method public hidebysig newslot abstract virtual 
          instance object  GetValue() cil managed
  {
  } // end of method IProcessVariable::GetValue

  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel
          Model()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable::get_Model()
  } // end of property IProcessVariable::Model
  .property instance callconv(8) bool IsValid()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable::get_IsValid()
  } // end of property IProcessVariable::IsValid
  .property instance callconv(8) bool IsEmpty()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable::get_IsEmpty()
  } // end of property IProcessVariable::IsEmpty
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier
          Source()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable::get_Source()
  } // end of property IProcessVariable::Source
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.IEnumerable`1<class AspenTech.EquipmentAnalysis.Infrastructure.IProcessAction>
          AffectedProcessActions()
  {
    .get instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class AspenTech.EquipmentAnalysis.Infrastructure.IProcessAction> AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable::get_AffectedProcessActions()
  } // end of property IProcessVariable::AffectedProcessActions
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IProcessVar`1<T>
       implements AspenTech.EquipmentAnalysis.Infrastructure.IProcessVariable,
                  [System]System.ComponentModel.INotifyPropertyChanged,
                  AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier
{
  .method public hidebysig newslot specialname abstract virtual 
          instance !T  get_Value() cil managed
  {
  } // end of method IProcessVar`1::get_Value

  .method public hidebysig newslot abstract virtual 
          instance bool  Specify(!T 'value',
                                 class AspenTech.EquipmentAnalysis.Infrastructure.IVariableSpecifier specifier) cil managed
  {
  } // end of method IProcessVar`1::Specify

  .method public hidebysig newslot abstract virtual 
          instance bool  WouldBeValid(!T 'value') cil managed
  {
  } // end of method IProcessVar`1::WouldBeValid

  .method public hidebysig newslot abstract virtual 
          instance bool  WouldBeEmpty(!T 'value') cil managed
  {
  } // end of method IProcessVar`1::WouldBeEmpty

  .property instance callconv(8) !T Value()
  {
    .get instance !T AspenTech.EquipmentAnalysis.Infrastructure.IProcessVar`1::get_Value()
  } // end of property IProcessVar`1::Value
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IProcessVar`1

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager
{
  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_Count() cil managed
  {
  } // end of method IPSVCaseManager::get_Count

  .method public hidebysig newslot abstract virtual 
          instance bool  AddCase(string pathName,
                                 class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase psvcase) cil managed
  {
  } // end of method IPSVCaseManager::AddCase

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase 
          GetCase(string pathName) cil managed
  {
  } // end of method IPSVCaseManager::GetCase

  .method public hidebysig newslot abstract virtual 
          instance bool  RemoveCase(string pathName) cil managed
  {
  } // end of method IPSVCaseManager::RemoveCase

  .method public hidebysig newslot abstract virtual 
          instance bool  TryGetCase(string pathName,
                                    [out] class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase& psvcase) cil managed
  {
  } // end of method IPSVCaseManager::TryGetCase

  .method public hidebysig newslot abstract virtual 
          instance bool  TryGetCase(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop adbTop,
                                    [out] class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase& psvcase) cil managed
  {
  } // end of method IPSVCaseManager::TryGetCase

  .property instance callconv(8) int32 Count()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager::get_Count()
  } // end of property IPSVCaseManager::Count
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IPSVCaseManager

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IPSVDatabaseMgr
{
  .method public hidebysig newslot abstract virtual 
          instance void  Initialize(string DBName,
                                    string caseKey) cil managed
  {
  } // end of method IPSVDatabaseMgr::Initialize

  .method public hidebysig newslot abstract virtual 
          instance bool  OwnsKeyFactory() cil managed
  {
  } // end of method IPSVDatabaseMgr::OwnsKeyFactory

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey[] 
          GetAllKeys() cil managed
  {
  } // end of method IPSVDatabaseMgr::GetAllKeys

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey[] 
          GetAllKeysOfType(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType recordType) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetAllKeysOfType

  .method public hidebysig newslot abstract virtual 
          instance void  FlushCache([opt] bool isSaving) cil managed
  {
    .param [1] = bool(false)
  } // end of method IPSVDatabaseMgr::FlushCache

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsDirty() cil managed
  {
  } // end of method IPSVDatabaseMgr::get_IsDirty

  .method public hidebysig newslot abstract virtual 
          instance !!T  GetValue<T>(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey key,
                                    string propName) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetValue

  .method public hidebysig newslot abstract virtual 
          instance bool  SetValue<T>(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey key,
                                     string propName,
                                     !!T 'value') cil managed
  {
  } // end of method IPSVDatabaseMgr::SetValue

  .method public hidebysig newslot abstract virtual 
          instance !!T  GetDefaultValue<T>(string propName) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetDefaultValue

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreatePRDSystem() cil managed
  {
  } // end of method IPSVDatabaseMgr::CreatePRDSystem

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreatePRD(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey PRDSystemKey,
                    valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType PRDType) cil managed
  {
  } // end of method IPSVDatabaseMgr::CreatePRD

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreateReliefLoad(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey PRDSystemKey) cil managed
  {
  } // end of method IPSVDatabaseMgr::CreateReliefLoad

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreateEquipment(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey PRDSystemKey,
                          valuetype AspenTech.EquipmentAnalysis.Infrastructure.eEquipmentType EquipType) cil managed
  {
  } // end of method IPSVDatabaseMgr::CreateEquipment

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreateOrificeCalc(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey PRDKey,
                            class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey ReliefLoadKey) cil managed
  {
  } // end of method IPSVDatabaseMgr::CreateOrificeCalc

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreateOrificeRatingCalc(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey PRDKey,
                                  class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey OrigOrificeCalcKey) cil managed
  {
  } // end of method IPSVDatabaseMgr::CreateOrificeRatingCalc

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreateLineSizing(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey OrificeCalcKey) cil managed
  {
  } // end of method IPSVDatabaseMgr::CreateLineSizing

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreateConnection(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey LHS,
                           class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey RHS,
                           string ConnectionName,
                           [opt] string ConnectionComment,
                           [opt] valuetype AspenTech.EquipmentAnalysis.Infrastructure.eDBConnectionSide cascadeDeleteToSide) cil managed
  {
    .param [4] = nullref
    .param [5] = int32(0x00000000)
  } // end of method IPSVDatabaseMgr::CreateConnection

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreateIterationResult(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey OwnerKey,
                                valuetype AspenTech.EquipmentAnalysis.Infrastructure.eIterationCalcType IterCalcType) cil managed
  {
  } // end of method IPSVDatabaseMgr::CreateIterationResult

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreateScenario(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey PSVkey,
                         valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod smEnum,
                         valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime rpEnum) cil managed
  {
  } // end of method IPSVDatabaseMgr::CreateScenario

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreateScenario(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey PSVkey,
                         valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType ScenarioType,
                         valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod 'method',
                         valuetype AspenTech.EquipmentAnalysis.Infrastructure.FluidPhaseRegime rpEnum) cil managed
  {
  } // end of method IPSVDatabaseMgr::CreateScenario

  .method public hidebysig newslot abstract virtual 
          instance void  DeleteRecord(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey deadKey) cil managed
  {
  } // end of method IPSVDatabaseMgr::DeleteRecord

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          GetParentKey(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey key,
                       valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType parentType) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetParentKey

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey[] 
          GetChildrenKeys(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey key,
                          valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType childType) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetChildrenKeys

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey> 
          GetConnectedRecords(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey Key,
                              [opt] string ConnectionName,
                              [opt] string ConnectionComment,
                              [opt] valuetype AspenTech.EquipmentAnalysis.Infrastructure.eDBConnectionSide LookOnSide) cil managed
  {
    .param [2] = nullref
    .param [3] = nullref
    .param [4] = int32(0x00000003)
  } // end of method IPSVDatabaseMgr::GetConnectedRecords

  .method public hidebysig newslot abstract virtual 
          instance void  DeleteReliefCompositions(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey orificeCalcKey) cil managed
  {
  } // end of method IPSVDatabaseMgr::DeleteReliefCompositions

  .method public hidebysig newslot abstract virtual 
          instance float64[]  GetReliefCompositions(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey key) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetReliefCompositions

  .method public hidebysig newslot abstract virtual 
          instance void  SetReliefCompositions(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey orificeCalcKey,
                                               float64[] compositions) cil managed
  {
  } // end of method IPSVDatabaseMgr::SetReliefCompositions

  .method public hidebysig newslot abstract virtual 
          instance bool  RecordExists(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey key) cil managed
  {
  } // end of method IPSVDatabaseMgr::RecordExists

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          GetRecordDBKey(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType recordType,
                         int32 key) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetRecordDBKey

  .method public hidebysig newslot abstract virtual 
          instance void  DatabaseCleanUp() cil managed
  {
  } // end of method IPSVDatabaseMgr::DatabaseCleanUp

  .method public hidebysig newslot abstract virtual 
          instance void  ChangReliefDeviceType(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey PRDKey,
                                               valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType PRDType) cil managed
  {
  } // end of method IPSVDatabaseMgr::ChangReliefDeviceType

  .method public hidebysig newslot abstract virtual 
          instance bool  PushReportingData(class [System.Data]System.Data.DataSet reportingData) cil managed
  {
  } // end of method IPSVDatabaseMgr::PushReportingData

  .method public hidebysig newslot abstract virtual 
          instance int32  GetMajorVersionLoaded() cil managed
  {
  } // end of method IPSVDatabaseMgr::GetMajorVersionLoaded

  .method public hidebysig newslot abstract virtual 
          instance int32  GetMinorVersionLoaded() cil managed
  {
  } // end of method IPSVDatabaseMgr::GetMinorVersionLoaded

  .method public hidebysig newslot abstract virtual 
          instance void  SetAStringToCustomizationVars(int32 PSVkey,
                                                       string propName,
                                                       string 'value') cil managed
  {
  } // end of method IPSVDatabaseMgr::SetAStringToCustomizationVars

  .method public hidebysig newslot abstract virtual 
          instance void  SetADoubleToCustomizationVars(int32 PSVkey,
                                                       string propName,
                                                       float64 'value') cil managed
  {
  } // end of method IPSVDatabaseMgr::SetADoubleToCustomizationVars

  .method public hidebysig newslot abstract virtual 
          instance void  SetABoolToCustomizationVars(int32 PSVkey,
                                                     string propName,
                                                     bool 'value') cil managed
  {
  } // end of method IPSVDatabaseMgr::SetABoolToCustomizationVars

  .method public hidebysig newslot abstract virtual 
          instance void  SetAnObjectToCustomizationVars(int32 PSVkey,
                                                        string propName,
                                                        object 'value') cil managed
  {
  } // end of method IPSVDatabaseMgr::SetAnObjectToCustomizationVars

  .method public hidebysig newslot abstract virtual 
          instance bool  SetAValueToCustomizationVars<T>(int32 PSVkey,
                                                         string propName,
                                                         !!T 'value') cil managed
  {
  } // end of method IPSVDatabaseMgr::SetAValueToCustomizationVars

  .method public hidebysig newslot abstract virtual 
          instance bool  NewScenarioNameIsUnique(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey rowNum,
                                                 string newName) cil managed
  {
  } // end of method IPSVDatabaseMgr::NewScenarioNameIsUnique

  .method public hidebysig newslot abstract virtual 
          instance bool  NewTankNameIsUnique(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey tankKey,
                                             string newName) cil managed
  {
  } // end of method IPSVDatabaseMgr::NewTankNameIsUnique

  .method public hidebysig newslot abstract virtual 
          instance bool  NewPRDSuffixIsUnique(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey prdKey,
                                              string newSuffix) cil managed
  {
  } // end of method IPSVDatabaseMgr::NewPRDSuffixIsUnique

  .method public hidebysig newslot abstract virtual 
          instance string  GetAStringFromCustomizationVars(int32 PSVkey,
                                                           string propName) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetAStringFromCustomizationVars

  .method public hidebysig newslot abstract virtual 
          instance float64  GetADoubleFromCustomizationVars(int32 PSVkey,
                                                            string propName) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetADoubleFromCustomizationVars

  .method public hidebysig newslot abstract virtual 
          instance bool  GetABoolFromCustomizationVars(int32 PSVkey,
                                                       string propName) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetABoolFromCustomizationVars

  .method public hidebysig newslot abstract virtual 
          instance object  GetAnObjectFromCustomizationVars(int32 PSVkey,
                                                            string propName) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetAnObjectFromCustomizationVars

  .method public hidebysig newslot abstract virtual 
          instance !!T  GetAValueFromCustomizationVars<T>(int32 PSVkey,
                                                          string propName) cil managed
  {
  } // end of method IPSVDatabaseMgr::GetAValueFromCustomizationVars

  .method public hidebysig newslot abstract virtual 
          instance void  DuplicateScenario(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey srcScenKey,
                                           class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey tarScenKey) cil managed
  {
  } // end of method IPSVDatabaseMgr::DuplicateScenario

  .method public hidebysig newslot abstract virtual 
          instance void  ChangeSizingMethod(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey key,
                                            valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod newMethod) cil managed
  {
  } // end of method IPSVDatabaseMgr::ChangeSizingMethod

  .method public hidebysig newslot abstract virtual 
          instance void  ChangeEmergScenario(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey key,
                                             valuetype AspenTech.EquipmentAnalysis.Infrastructure.EmergScenarioType newScenario) cil managed
  {
  } // end of method IPSVDatabaseMgr::ChangeEmergScenario

  .property instance callconv(8) bool IsDirty()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IPSVDatabaseMgr::get_IsDirty()
  } // end of property IPSVDatabaseMgr::IsDirty
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IPSVDatabaseMgr

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.NavigatorTreeNodeCollection 
          get_UnitOperationsTreeView() cil managed
  {
  } // end of method IPSVMessager::get_UnitOperationsTreeView

  .method public hidebysig newslot specialname abstract virtual 
          instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.NavigatorTreeNode 
          get_UnattachedStreamsRootNode() cil managed
  {
  } // end of method IPSVMessager::get_UnattachedStreamsRootNode

  .method public hidebysig newslot abstract virtual 
          instance class [mscorlib]System.Collections.Generic.IEnumerable`1<class AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation> 
          GetOutMaterialStreamByBlockName(string name) cil managed
  {
  } // end of method IPSVMessager::GetOutMaterialStreamByBlockName

  .method public hidebysig newslot abstract virtual 
          instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.NavigatorTreeNode 
          GetUOTreeNodeByFullPath(string path) cil managed
  {
  } // end of method IPSVMessager::GetUOTreeNodeByFullPath

  .method public hidebysig newslot abstract virtual 
          instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.NavigatorTreeNode 
          GetStreamTreeNodeByFullPath(string path) cil managed
  {
  } // end of method IPSVMessager::GetStreamTreeNodeByFullPath

  .method public hidebysig newslot abstract virtual 
          instance void  AddPSVFromTreeView(string streamPath,
                                            string psvName) cil managed
  {
  } // end of method IPSVMessager::AddPSVFromTreeView

  .method public hidebysig newslot abstract virtual 
          instance void  DeletePSVFromTreeView(string streamPath,
                                               string psvName) cil managed
  {
  } // end of method IPSVMessager::DeletePSVFromTreeView

  .method public hidebysig newslot abstract virtual 
          instance void  RenamePSVFromTreeView(string streamPath,
                                               string oldPsvName,
                                               string newPsvName) cil managed
  {
  } // end of method IPSVMessager::RenamePSVFromTreeView

  .method public hidebysig newslot abstract virtual 
          instance string  GetBlockByOutMaterialStreamPath(string path) cil managed
  {
  } // end of method IPSVMessager::GetBlockByOutMaterialStreamPath

  .method public hidebysig newslot abstract virtual 
          instance void  Initialize() cil managed
  {
  } // end of method IPSVMessager::Initialize

  .method public hidebysig newslot abstract virtual 
          instance valuetype [PresentationFramework]System.Windows.MessageBoxResult 
          ShowMessageBox(class [PresentationFramework]System.Windows.Window owner,
                         string messageBoxText,
                         string caption,
                         valuetype [PresentationFramework]System.Windows.MessageBoxButton button,
                         valuetype [PresentationFramework]System.Windows.MessageBoxImage icon,
                         valuetype [PresentationFramework]System.Windows.MessageBoxResult defaultResult,
                         valuetype [PresentationFramework]System.Windows.MessageBoxOptions options) cil managed
  {
  } // end of method IPSVMessager::ShowMessageBox

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateTreeView(class AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs args) cil managed
  {
  } // end of method IPSVMessager::UpdateTreeView

  .method public hidebysig newslot specialname abstract virtual 
          instance void  add_UpdateTreeViewEvent(class [mscorlib]System.EventHandler`1<class AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs> 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  } // end of method IPSVMessager::add_UpdateTreeViewEvent

  .method public hidebysig newslot specialname abstract virtual 
          instance void  remove_UpdateTreeViewEvent(class [mscorlib]System.EventHandler`1<class AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs> 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  } // end of method IPSVMessager::remove_UpdateTreeViewEvent

  .method public hidebysig newslot abstract virtual 
          instance void  LeavePSVEnvironment() cil managed
  {
  } // end of method IPSVMessager::LeavePSVEnvironment

  .method public hidebysig newslot specialname abstract virtual 
          instance void  add_LeavePSVEnvironmentEvent(class [mscorlib]System.EventHandler 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  } // end of method IPSVMessager::add_LeavePSVEnvironmentEvent

  .method public hidebysig newslot specialname abstract virtual 
          instance void  remove_LeavePSVEnvironmentEvent(class [mscorlib]System.EventHandler 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  } // end of method IPSVMessager::remove_LeavePSVEnvironmentEvent

  .method public hidebysig newslot abstract virtual 
          instance string  ShowSelectReferenceStreamDialog(string hierName) cil managed
  {
  } // end of method IPSVMessager::ShowSelectReferenceStreamDialog

  .method public hidebysig newslot abstract virtual 
          instance void  PSVHelpExecuted(class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVHelpEventArgs args) cil managed
  {
  } // end of method IPSVMessager::PSVHelpExecuted

  .method public hidebysig newslot abstract virtual 
          instance void  InitializePSVPlusIfNot() cil managed
  {
  } // end of method IPSVMessager::InitializePSVPlusIfNot

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_PSVHostUnitSet() cil managed
  {
  } // end of method IPSVMessager::get_PSVHostUnitSet

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_PSVHostUnitSet(string 'value') cil managed
  {
  } // end of method IPSVMessager::set_PSVHostUnitSet

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsAddingPSV() cil managed
  {
  } // end of method IPSVMessager::get_IsAddingPSV

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_IsAddingPSV(bool 'value') cil managed
  {
  } // end of method IPSVMessager::set_IsAddingPSV

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsAddingPSVEnabled() cil managed
  {
  } // end of method IPSVMessager::get_IsAddingPSVEnabled

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsAddingRuptureDisk() cil managed
  {
  } // end of method IPSVMessager::get_IsAddingRuptureDisk

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_IsAddingRuptureDisk(bool 'value') cil managed
  {
  } // end of method IPSVMessager::set_IsAddingRuptureDisk

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_IsAddingRuptureDiskEnabled() cil managed
  {
  } // end of method IPSVMessager::get_IsAddingRuptureDiskEnabled

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_PSVHostType() cil managed
  {
  } // end of method IPSVMessager::get_PSVHostType

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_CaseFilePath() cil managed
  {
  } // end of method IPSVMessager::get_CaseFilePath

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ApplicationName() cil managed
  {
  } // end of method IPSVMessager::get_ApplicationName

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ApplicationNameWithVersion() cil managed
  {
  } // end of method IPSVMessager::get_ApplicationNameWithVersion

  .method public hidebysig newslot abstract virtual 
          instance object  GetIHNodeValue(string path,
                                          string attribute) cil managed
  {
  } // end of method IPSVMessager::GetIHNodeValue

  .method public hidebysig newslot abstract virtual 
          instance void  SetIHNodeValue(string path,
                                        object 'value') cil managed
  {
  } // end of method IPSVMessager::SetIHNodeValue

  .method public hidebysig newslot abstract virtual 
          instance void  NewIHNodeChild(string path) cil managed
  {
  } // end of method IPSVMessager::NewIHNodeChild

  .method public hidebysig newslot abstract virtual 
          instance void  PSVRefreshUI() cil managed
  {
  } // end of method IPSVMessager::PSVRefreshUI

  .method public hidebysig newslot abstract virtual 
          instance void  PSVAddRibbonToHost() cil managed
  {
  } // end of method IPSVMessager::PSVAddRibbonToHost

  .method public hidebysig newslot abstract virtual 
          instance void  PSVRibbonButtonCallBack(string btnName) cil managed
  {
  } // end of method IPSVMessager::PSVRibbonButtonCallBack

  .method public hidebysig newslot specialname abstract virtual 
          instance void  add_HostDataChangedEvent(class [mscorlib]System.EventHandler 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  } // end of method IPSVMessager::add_HostDataChangedEvent

  .method public hidebysig newslot specialname abstract virtual 
          instance void  remove_HostDataChangedEvent(class [mscorlib]System.EventHandler 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  } // end of method IPSVMessager::remove_HostDataChangedEvent

  .method public hidebysig newslot abstract virtual 
          instance void  PSVPreferenceManager() cil managed
  {
  } // end of method IPSVMessager::PSVPreferenceManager

  .method public hidebysig newslot specialname abstract virtual 
          instance bool  get_CanHostExecuteKrMethodSizing() cil managed
  {
  } // end of method IPSVMessager::get_CanHostExecuteKrMethodSizing

  .method public hidebysig newslot abstract virtual 
          instance string  GetViewableName(string path) cil managed
  {
  } // end of method IPSVMessager::GetViewableName

  .method public hidebysig newslot abstract virtual 
          instance bool  SetViewableName(string path,
                                         string name) cil managed
  {
  } // end of method IPSVMessager::SetViewableName

  .method public hidebysig newslot abstract virtual 
          instance bool  SetScenarioName(string path,
                                         string name) cil managed
  {
  } // end of method IPSVMessager::SetScenarioName

  .method public hidebysig newslot abstract virtual 
          instance string  GetScenarioStreamName(string path) cil managed
  {
  } // end of method IPSVMessager::GetScenarioStreamName

  .method public hidebysig newslot abstract virtual 
          instance bool  SetTankName(string path,
                                     string name) cil managed
  {
  } // end of method IPSVMessager::SetTankName

  .method public hidebysig newslot abstract virtual 
          instance string  GetTankName(string path) cil managed
  {
  } // end of method IPSVMessager::GetTankName

  .method public hidebysig newslot abstract virtual 
          instance string  GetTankStreamName(string path) cil managed
  {
  } // end of method IPSVMessager::GetTankStreamName

  .method public hidebysig newslot abstract virtual 
          instance string  GetTankStreamTemperaturePath(string path,
                                                        string refStreamName) cil managed
  {
  } // end of method IPSVMessager::GetTankStreamTemperaturePath

  .method public hidebysig newslot abstract virtual 
          instance valuetype [mscorlib]System.Nullable`1<bool> 
          GetTankDirtyState(string path,
                            string refStreamName) cil managed
  {
  } // end of method IPSVMessager::GetTankDirtyState

  .method public hidebysig newslot abstract virtual 
          instance void  SetTankDirtyState(string path,
                                           string refStreamName,
                                           bool 'value') cil managed
  {
  } // end of method IPSVMessager::SetTankDirtyState

  .method public hidebysig newslot abstract virtual 
          instance object  CreateHostSpecificFluid(string path) cil managed
  {
  } // end of method IPSVMessager::CreateHostSpecificFluid

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_PSVDefaultDesignCodeString() cil managed
  {
  } // end of method IPSVMessager::get_PSVDefaultDesignCodeString

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_PSVDefaultDesignCodeString(string 'value') cil managed
  {
  } // end of method IPSVMessager::set_PSVDefaultDesignCodeString

  .method public hidebysig newslot abstract virtual 
          instance object  GetFlagValue(bool flag) cil managed
  {
  } // end of method IPSVMessager::GetFlagValue

  .method public hidebysig newslot abstract virtual 
          instance bool  GetScenarioIsDirty(string path) cil managed
  {
  } // end of method IPSVMessager::GetScenarioIsDirty

  .method public hidebysig newslot abstract virtual 
          instance void  SetScenarioIsDirty(string path,
                                            bool isDirty) cil managed
  {
  } // end of method IPSVMessager::SetScenarioIsDirty

  .method public hidebysig newslot specialname abstract virtual 
          instance class [mscorlib]System.Globalization.CultureInfo 
          get_SystemCulture() cil managed
  {
  } // end of method IPSVMessager::get_SystemCulture

  .method public hidebysig newslot abstract virtual 
          instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop 
          GetAdbTopForActiveDocument() cil managed
  {
  } // end of method IPSVMessager::GetAdbTopForActiveDocument

  .method public hidebysig newslot abstract virtual 
          instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop 
          GetAdbTopForImportExport() cil managed
  {
  } // end of method IPSVMessager::GetAdbTopForImportExport

  .method public hidebysig newslot abstract virtual 
          instance void  SetSystemDeviceType(string path,
                                             valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType deviceType) cil managed
  {
  } // end of method IPSVMessager::SetSystemDeviceType

  .event class [mscorlib]System.EventHandler`1<class AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs> UpdateTreeViewEvent
  {
    .addon instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::add_UpdateTreeViewEvent(class [mscorlib]System.EventHandler`1<class AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs>)
    .removeon instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::remove_UpdateTreeViewEvent(class [mscorlib]System.EventHandler`1<class AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs>)
  } // end of event IPSVMessager::UpdateTreeViewEvent
  .event [mscorlib]System.EventHandler LeavePSVEnvironmentEvent
  {
    .addon instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::add_LeavePSVEnvironmentEvent(class [mscorlib]System.EventHandler)
    .removeon instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::remove_LeavePSVEnvironmentEvent(class [mscorlib]System.EventHandler)
  } // end of event IPSVMessager::LeavePSVEnvironmentEvent
  .event [mscorlib]System.EventHandler HostDataChangedEvent
  {
    .addon instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::add_HostDataChangedEvent(class [mscorlib]System.EventHandler)
    .removeon instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::remove_HostDataChangedEvent(class [mscorlib]System.EventHandler)
  } // end of event IPSVMessager::HostDataChangedEvent
  .property instance callconv(8) class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.NavigatorTreeNodeCollection
          UnitOperationsTreeView()
  {
    .get instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.NavigatorTreeNodeCollection AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_UnitOperationsTreeView()
  } // end of property IPSVMessager::UnitOperationsTreeView
  .property instance callconv(8) class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.NavigatorTreeNode
          UnattachedStreamsRootNode()
  {
    .get instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.NavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_UnattachedStreamsRootNode()
  } // end of property IPSVMessager::UnattachedStreamsRootNode
  .property instance callconv(8) string PSVHostUnitSet()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_PSVHostUnitSet()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::set_PSVHostUnitSet(string)
  } // end of property IPSVMessager::PSVHostUnitSet
  .property instance callconv(8) bool IsAddingPSV()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_IsAddingPSV()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::set_IsAddingPSV(bool)
  } // end of property IPSVMessager::IsAddingPSV
  .property instance callconv(8) bool IsAddingPSVEnabled()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_IsAddingPSVEnabled()
  } // end of property IPSVMessager::IsAddingPSVEnabled
  .property instance callconv(8) bool IsAddingRuptureDisk()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_IsAddingRuptureDisk()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::set_IsAddingRuptureDisk(bool)
  } // end of property IPSVMessager::IsAddingRuptureDisk
  .property instance callconv(8) bool IsAddingRuptureDiskEnabled()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_IsAddingRuptureDiskEnabled()
  } // end of property IPSVMessager::IsAddingRuptureDiskEnabled
  .property instance callconv(8) string PSVHostType()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_PSVHostType()
  } // end of property IPSVMessager::PSVHostType
  .property instance callconv(8) string CaseFilePath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_CaseFilePath()
  } // end of property IPSVMessager::CaseFilePath
  .property instance callconv(8) string ApplicationName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_ApplicationName()
  } // end of property IPSVMessager::ApplicationName
  .property instance callconv(8) string ApplicationNameWithVersion()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_ApplicationNameWithVersion()
  } // end of property IPSVMessager::ApplicationNameWithVersion
  .property instance callconv(8) bool CanHostExecuteKrMethodSizing()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_CanHostExecuteKrMethodSizing()
  } // end of property IPSVMessager::CanHostExecuteKrMethodSizing
  .property instance callconv(8) string PSVDefaultDesignCodeString()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_PSVDefaultDesignCodeString()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::set_PSVDefaultDesignCodeString(string)
  } // end of property IPSVMessager::PSVDefaultDesignCodeString
  .property instance callconv(8) class [mscorlib]System.Globalization.CultureInfo
          SystemCulture()
  {
    .get instance class [mscorlib]System.Globalization.CultureInfo AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager::get_SystemCulture()
  } // end of property IPSVMessager::SystemCulture
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IPSVMessager

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation
       extends [mscorlib]System.Object
{
  .field private string '<Name>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<SourceBlock>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<DestBlock>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<Type>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private bool '<IsUnAttached>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private bool '<IsInHierarchy>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<DataPath>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<ParentUnitOperationName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance string 
          get_Name() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<Name>k__BackingField'
    IL_0006:  ret
  } // end of method StreamInformation::get_Name

  .method public hidebysig specialname instance void 
          set_Name(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<Name>k__BackingField'
    IL_0007:  ret
  } // end of method StreamInformation::set_Name

  .method public hidebysig specialname instance string 
          get_SourceBlock() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<SourceBlock>k__BackingField'
    IL_0006:  ret
  } // end of method StreamInformation::get_SourceBlock

  .method public hidebysig specialname instance void 
          set_SourceBlock(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<SourceBlock>k__BackingField'
    IL_0007:  ret
  } // end of method StreamInformation::set_SourceBlock

  .method public hidebysig specialname instance string 
          get_DestBlock() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<DestBlock>k__BackingField'
    IL_0006:  ret
  } // end of method StreamInformation::get_DestBlock

  .method public hidebysig specialname instance void 
          set_DestBlock(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<DestBlock>k__BackingField'
    IL_0007:  ret
  } // end of method StreamInformation::set_DestBlock

  .method public hidebysig specialname instance string 
          get_Type() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<Type>k__BackingField'
    IL_0006:  ret
  } // end of method StreamInformation::get_Type

  .method public hidebysig specialname instance void 
          set_Type(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<Type>k__BackingField'
    IL_0007:  ret
  } // end of method StreamInformation::set_Type

  .method public hidebysig specialname instance bool 
          get_IsUnAttached() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<IsUnAttached>k__BackingField'
    IL_0006:  ret
  } // end of method StreamInformation::get_IsUnAttached

  .method public hidebysig specialname instance void 
          set_IsUnAttached(bool 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<IsUnAttached>k__BackingField'
    IL_0007:  ret
  } // end of method StreamInformation::set_IsUnAttached

  .method public hidebysig specialname instance bool 
          get_IsInHierarchy() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<IsInHierarchy>k__BackingField'
    IL_0006:  ret
  } // end of method StreamInformation::get_IsInHierarchy

  .method public hidebysig specialname instance void 
          set_IsInHierarchy(bool 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<IsInHierarchy>k__BackingField'
    IL_0007:  ret
  } // end of method StreamInformation::set_IsInHierarchy

  .method public hidebysig specialname instance string 
          get_DataPath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<DataPath>k__BackingField'
    IL_0006:  ret
  } // end of method StreamInformation::get_DataPath

  .method public hidebysig specialname instance void 
          set_DataPath(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<DataPath>k__BackingField'
    IL_0007:  ret
  } // end of method StreamInformation::set_DataPath

  .method public hidebysig specialname instance string 
          get_ParentUnitOperationName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<ParentUnitOperationName>k__BackingField'
    IL_0006:  ret
  } // end of method StreamInformation::get_ParentUnitOperationName

  .method public hidebysig specialname instance void 
          set_ParentUnitOperationName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::'<ParentUnitOperationName>k__BackingField'
    IL_0007:  ret
  } // end of method StreamInformation::set_ParentUnitOperationName

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ret
  } // end of method StreamInformation::.ctor

  .property instance callconv(8) string Name()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::get_Name()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::set_Name(string)
  } // end of property StreamInformation::Name
  .property instance callconv(8) string SourceBlock()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::get_SourceBlock()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::set_SourceBlock(string)
  } // end of property StreamInformation::SourceBlock
  .property instance callconv(8) string DestBlock()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::get_DestBlock()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::set_DestBlock(string)
  } // end of property StreamInformation::DestBlock
  .property instance callconv(8) string Type()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::get_Type()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::set_Type(string)
  } // end of property StreamInformation::Type
  .property instance callconv(8) bool IsUnAttached()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::get_IsUnAttached()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::set_IsUnAttached(bool)
  } // end of property StreamInformation::IsUnAttached
  .property instance callconv(8) bool IsInHierarchy()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::get_IsInHierarchy()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::set_IsInHierarchy(bool)
  } // end of property StreamInformation::IsInHierarchy
  .property instance callconv(8) string DataPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::get_DataPath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::set_DataPath(string)
  } // end of property StreamInformation::DataPath
  .property instance callconv(8) string ParentUnitOperationName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::get_ParentUnitOperationName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation::set_ParentUnitOperationName(string)
  } // end of property StreamInformation::ParentUnitOperationName
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.StreamInformation

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private bool '<IsFromRestoring>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private bool '<IfAnyMoveHierarchyOperation>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance bool 
          get_IsFromRestoring() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs::'<IsFromRestoring>k__BackingField'
    IL_0006:  ret
  } // end of method UpdateTreeViewEventArgs::get_IsFromRestoring

  .method public hidebysig specialname instance void 
          set_IsFromRestoring(bool 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs::'<IsFromRestoring>k__BackingField'
    IL_0007:  ret
  } // end of method UpdateTreeViewEventArgs::set_IsFromRestoring

  .method public hidebysig specialname instance bool 
          get_IfAnyMoveHierarchyOperation() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs::'<IfAnyMoveHierarchyOperation>k__BackingField'
    IL_0006:  ret
  } // end of method UpdateTreeViewEventArgs::get_IfAnyMoveHierarchyOperation

  .method public hidebysig specialname instance void 
          set_IfAnyMoveHierarchyOperation(bool 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs::'<IfAnyMoveHierarchyOperation>k__BackingField'
    IL_0007:  ret
  } // end of method UpdateTreeViewEventArgs::set_IfAnyMoveHierarchyOperation

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method UpdateTreeViewEventArgs::.ctor

  .property instance callconv(8) bool IsFromRestoring()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs::get_IsFromRestoring()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs::set_IsFromRestoring(bool)
  } // end of property UpdateTreeViewEventArgs::IsFromRestoring
  .property instance callconv(8) bool IfAnyMoveHierarchyOperation()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs::get_IfAnyMoveHierarchyOperation()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs::set_IfAnyMoveHierarchyOperation(bool)
  } // end of property UpdateTreeViewEventArgs::IfAnyMoveHierarchyOperation
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.UpdateTreeViewEventArgs

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IPSVNavigator
{
  .method public hidebysig newslot abstract virtual 
          instance void  GenerateTopLevelNodes() cil managed
  {
  } // end of method IPSVNavigator::GenerateTopLevelNodes

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IPSVNavigator

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IPSVNode
{
  .method public hidebysig newslot abstract virtual 
          instance void  RefreshChildren() cil managed
  {
  } // end of method IPSVNode::RefreshChildren

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IPSVNode

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IBaseUserControl
{
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IBaseUserControl

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase
{
  .method public hidebysig newslot abstract virtual 
          instance void  Initialize(string caseKey,
                                    class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop adbTop,
                                    [opt] string caseFileName,
                                    [opt] bool testForMdbRecall) cil managed
  {
    .param [3] = nullref
    .param [4] = bool(true)
  } // end of method IPsvCase::Initialize

  .method public hidebysig newslot abstract virtual 
          instance bool  IsDirty() cil managed
  {
  } // end of method IPsvCase::IsDirty

  .method public hidebysig newslot abstract virtual 
          instance void  ClearDirty() cil managed
  {
  } // end of method IPsvCase::ClearDirty

  .method public hidebysig newslot abstract virtual 
          instance void  Load() cil managed
  {
  } // end of method IPsvCase::Load

  .method public hidebysig newslot abstract virtual 
          instance void  Close() cil managed
  {
  } // end of method IPsvCase::Close

  .method public hidebysig newslot abstract virtual 
          instance void  EnterEnvironment([opt] class [mscorlib]System.Collections.Generic.IEnumerable`1<valuetype [mscorlib]System.ValueTuple`2<string,string>> psvsToBeDeleted) cil managed
  {
    .param [1] = nullref
    .custom instance void [mscorlib]System.Runtime.CompilerServices.TupleElementNamesAttribute::.ctor(string[]) = ( 01 00 02 00 00 00 04 70 61 74 68 04 6E 61 6D 65   // .......path.name
                                                                                                                    00 00 ) 
  } // end of method IPsvCase::EnterEnvironment

  .method public hidebysig newslot abstract virtual 
          instance void  ExitEnvironment() cil managed
  {
  } // end of method IPsvCase::ExitEnvironment

  .method public hidebysig newslot abstract virtual 
          instance void  Calculate([opt] bool force) cil managed
  {
    .param [1] = bool(false)
  } // end of method IPsvCase::Calculate

  .method public hidebysig newslot abstract virtual 
          instance void  CalculateLineSizing() cil managed
  {
  } // end of method IPsvCase::CalculateLineSizing

  .method public hidebysig newslot abstract virtual 
          instance void  Activate() cil managed
  {
  } // end of method IPsvCase::Activate

  .method public hidebysig newslot abstract virtual 
          instance void  Deactivate() cil managed
  {
  } // end of method IPsvCase::Deactivate

  .method public hidebysig newslot abstract virtual 
          instance void  OnAllFlowsheetItemsAdded() cil managed
  {
  } // end of method IPsvCase::OnAllFlowsheetItemsAdded

  .method public hidebysig newslot abstract virtual 
          instance void  ExportDefaultsToFile(string path) cil managed
  {
  } // end of method IPsvCase::ExportDefaultsToFile

  .method public hidebysig newslot abstract virtual 
          instance void  ImportDefaultsFromFile(string path,
                                                string& loadVersion,
                                                [out] class [mscorlib]System.Collections.Generic.IEnumerable`1<string>& warningSections,
                                                [out] class [mscorlib]System.Collections.Generic.IEnumerable`1<string>& warningMessages) cil managed
  {
  } // end of method IPsvCase::ImportDefaultsFromFile

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.IBaseUserControl 
          GetUserControl(valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlID,
                         class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey rowNum) cil managed
  {
  } // end of method IPsvCase::GetUserControl

  .method public hidebysig newslot abstract virtual 
          instance bool  RecordExists(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey key) cil managed
  {
  } // end of method IPsvCase::RecordExists

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          AddNewPRDSystem(valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType systemType,
                          string CXSDatapath) cil managed
  {
  } // end of method IPsvCase::AddNewPRDSystem

  .method public hidebysig newslot abstract virtual 
          instance void  UpdatePRDSystem(valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType systemType,
                                         class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PRDSysKey,
                                         string CXSDatapath,
                                         class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel pressureProtectionRequirement) cil managed
  {
  } // end of method IPsvCase::UpdatePRDSystem

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          AddNewScenario(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PSVkey,
                         string ScenarioName,
                         class [PSVSizingEngine]PSVSizingEngine.IPPPFluid fluid) cil managed
  {
  } // end of method IPsvCase::AddNewScenario

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateScenario(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PSVKey,
                                        class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey row,
                                        class [PSVSizingEngine]PSVSizingEngine.IPPPFluid fluid) cil managed
  {
  } // end of method IPsvCase::UpdateScenario

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          AddNewStorageTank(string CXSDatapath,
                            class [PSVSizingEngine]PSVSizingEngine.IPPPFluid fluid) cil managed
  {
  } // end of method IPsvCase::AddNewStorageTank

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateStorageTank(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey tankKey,
                                           string CXSDatapath,
                                           class [PSVSizingEngine]PSVSizingEngine.IPPPFluid fluid,
                                           class AspenTech.EquipmentAnalysis.Infrastructure.IBaseModel dataModel) cil managed
  {
  } // end of method IPsvCase::UpdateStorageTank

  .method public hidebysig newslot abstract virtual 
          instance void  DeletePRDSystem(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PRDSystemKey,
                                         int32 prdtype,
                                         string path) cil managed
  {
  } // end of method IPsvCase::DeletePRDSystem

  .method public hidebysig newslot abstract virtual 
          instance void  DeleteScenario(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey rowNum,
                                        [opt] class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PSVKey) cil managed
  {
    .param [2] = nullref
  } // end of method IPsvCase::DeleteScenario

  .method public hidebysig newslot abstract virtual 
          instance void  DeleteStorageTank(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey tankKey) cil managed
  {
  } // end of method IPsvCase::DeleteStorageTank

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          DuplicatePRDSystem(valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType systemType,
                             string CXSDatapath,
                             class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey PRDSystemKey) cil managed
  {
  } // end of method IPsvCase::DuplicatePRDSystem

  .method public hidebysig newslot abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          DuplicateScenario(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey rowNum) cil managed
  {
  } // end of method IPsvCase::DuplicateScenario

  .method public hidebysig newslot abstract virtual 
          instance object  GetPRDSystemModel(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey prdSysKey) cil managed
  {
  } // end of method IPsvCase::GetPRDSystemModel

  .method public hidebysig newslot abstract virtual 
          instance object  GetPSVScenarioModel(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey scenarioRow) cil managed
  {
  } // end of method IPsvCase::GetPSVScenarioModel

  .method public hidebysig newslot abstract virtual 
          instance object  GetAllTankModels() cil managed
  {
  } // end of method IPsvCase::GetAllTankModels

  .method public hidebysig newslot abstract virtual 
          instance object  GetStorageTankModel(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey tankKey) cil managed
  {
  } // end of method IPsvCase::GetStorageTankModel

  .method public hidebysig newslot abstract virtual 
          instance object  GetOrificeSelectionModel() cil managed
  {
  } // end of method IPsvCase::GetOrificeSelectionModel

  .method public hidebysig newslot abstract virtual 
          instance void  ShowReport(class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey> keys,
                                    valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVReportTypeEnum 'type') cil managed
  {
  } // end of method IPsvCase::ShowReport

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateSelectedOrifices() cil managed
  {
  } // end of method IPsvCase::UpdateSelectedOrifices

  .method public hidebysig newslot abstract virtual 
          instance void  UpdateOverpressure() cil managed
  {
  } // end of method IPsvCase::UpdateOverpressure

  .method public hidebysig newslot specialname abstract virtual 
          instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop 
          get_AdbTop() cil managed
  {
  } // end of method IPsvCase::get_AdbTop

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_CaseKey() cil managed
  {
  } // end of method IPsvCase::get_CaseKey

  .method public hidebysig newslot abstract virtual 
          instance void  ImportPRDSystem(class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase fromCase,
                                         class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey prdSysKey,
                                         [opt] class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey destKey,
                                         [opt] class [mscorlib]System.Collections.Generic.Dictionary`2<class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey> scenarioKeyMap) cil managed
  {
    .param [3] = nullref
    .param [4] = nullref
  } // end of method IPsvCase::ImportPRDSystem

  .method public hidebysig newslot abstract virtual 
          instance void  ImportCaseConfiguration(class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase fromCase,
                                                 bool isMergeOperation) cil managed
  {
  } // end of method IPsvCase::ImportCaseConfiguration

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet 
          get_SelectedUnitSet() cil managed
  {
  } // end of method IPsvCase::get_SelectedUnitSet

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_SelectedUnitSet(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet 'value') cil managed
  {
  } // end of method IPsvCase::set_SelectedUnitSet

  .property instance callconv(8) class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop
          AdbTop()
  {
    .get instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::get_AdbTop()
  } // end of property IPsvCase::AdbTop
  .property instance callconv(8) string CaseKey()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::get_CaseKey()
  } // end of property IPsvCase::CaseKey
  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet
          SelectedUnitSet()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::get_SelectedUnitSet()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase::set_SelectedUnitSet(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/eUnitSet)
  } // end of property IPsvCase::SelectedUnitSet
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlInitial = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrl2PhaseLines = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrl2PhaseLineSizing = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlDbBrowse = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlFire = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlLiqRelief = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlMain = int32(0x00000006)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlMixed_1Relief = int32(0x00000007)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlMixed_2Relief = int32(0x00000008)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlMixed_3Relief = int32(0x00000009)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlMixed_4Relief = int32(0x0000000A)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlThermalExpansion = int32(0x0000000B)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlTubeRuptureLiquid = int32(0x0000000C)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlTubeRuptureMixed = int32(0x0000000D)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlTubeRuptureVapor = int32(0x0000000E)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlValveFailure = int32(0x0000000F)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlValveFailure_L = int32(0x00000010)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlVapRelief = int32(0x00000011)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlSteamRelief = int32(0x00000012)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlTankVent = int32(0x00000013)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlComplexPiping = int32(0x00000014)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlPSVSummaryForm = int32(0x00000015)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlPSVOrificeSizeSettings = int32(0x00000016)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlPSVLineSizingSettings = int32(0x00000017)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlPSVValveSettings = int32(0x00000018)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlPSVValveName = int32(0x00000019)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlTankManager = int32(0x0000001A)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs ctrlPreferenceManager = int32(0x0000001B)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PSVctrlIDs

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary
{
  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings 
          get_PSVNavigationStrings() cil managed
  {
  } // end of method ISimMsgDictionary::get_PSVNavigationStrings

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings 
          get_PSVPropertyStrings() cil managed
  {
  } // end of method ISimMsgDictionary::get_PSVPropertyStrings

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings 
          get_UnitStrings() cil managed
  {
  } // end of method ISimMsgDictionary::get_UnitStrings

  .method public hidebysig newslot specialname abstract virtual 
          instance class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands 
          get_PSVCommands() cil managed
  {
  } // end of method ISimMsgDictionary::get_PSVCommands

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_EmptyValue() cil managed
  {
  } // end of method ISimMsgDictionary::get_EmptyValue

  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings
          PSVNavigationStrings()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVNavigationStrings()
  } // end of property ISimMsgDictionary::PSVNavigationStrings
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings
          PSVPropertyStrings()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVPropertyStrings()
  } // end of property ISimMsgDictionary::PSVPropertyStrings
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings
          UnitStrings()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_UnitStrings()
  } // end of property ISimMsgDictionary::UnitStrings
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands
          PSVCommands()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_PSVCommands()
  } // end of property ISimMsgDictionary::PSVCommands
  .property instance callconv(8) float64 EmptyValue()
  {
    .get instance float64 AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary::get_EmptyValue()
  } // end of property ISimMsgDictionary::EmptyValue
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ISimMsgDictionary

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings
{
  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Action_SendMessage() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_Action_SendMessage

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_TopNode() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_TopNode

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Attribute_CaseKey() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_Attribute_CaseKey

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_PSVKey() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_PSVKey

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_PSVProtectedUO() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_PSVProtectedUO

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_PSVAssociatedStream() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_PSVAssociatedStream

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_PSVAttachedScenario() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_PSVAttachedScenario

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_PSVStreamTemperature() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_PSVStreamTemperature

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioKey() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioKey

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioFluid() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioFluid

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioOverrideStream() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioOverrideStream

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioRefStream() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioRefStream

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioOverrideStreamID() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioOverrideStreamID

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioRefStreamMassFlow() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioRefStreamMassFlow

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioIsDirty() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioIsDirty

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioRefStreamTemperature() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioRefStreamTemperature

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioCalcOrificeSize() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioCalcOrificeSize

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioSelOrificeSize() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioSelOrificeSize

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioOrificeDesignation() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioOrificeDesignation

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioInletPipeID() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioInletPipeID

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioOutletPipeID() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioOutletPipeID

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ScenarioIsSizingCase() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ScenarioIsSizingCase

  .method public hidebysig newslot abstract virtual 
          instance string  ExtractPsvNodeKey(string psvNodeKey) cil managed
  {
  } // end of method ISimPSVNavigationStrings::ExtractPsvNodeKey

  .method public hidebysig newslot abstract virtual 
          instance string  GetScenarioNodeKey(string psvNodeKey,
                                              string scenarioName) cil managed
  {
  } // end of method ISimPSVNavigationStrings::GetScenarioNodeKey

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_TankKey() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_TankKey

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_TankFluid() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_TankFluid

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_TankUseRefStream() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_TankUseRefStream

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_TankRefStream() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_TankRefStream

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_TankIsDirty() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_TankIsDirty

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_TankDirectory() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_TankDirectory

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_ObjectName() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_ObjectName

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_StreamPress() cil managed
  {
  } // end of method ISimPSVNavigationStrings::get_StreamPress

  .property instance callconv(8) string Action_SendMessage()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_Action_SendMessage()
  } // end of property ISimPSVNavigationStrings::Action_SendMessage
  .property instance callconv(8) string TopNode()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_TopNode()
  } // end of property ISimPSVNavigationStrings::TopNode
  .property instance callconv(8) string Attribute_CaseKey()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_Attribute_CaseKey()
  } // end of property ISimPSVNavigationStrings::Attribute_CaseKey
  .property instance callconv(8) string PSVKey()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_PSVKey()
  } // end of property ISimPSVNavigationStrings::PSVKey
  .property instance callconv(8) string PSVProtectedUO()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_PSVProtectedUO()
  } // end of property ISimPSVNavigationStrings::PSVProtectedUO
  .property instance callconv(8) string PSVAssociatedStream()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_PSVAssociatedStream()
  } // end of property ISimPSVNavigationStrings::PSVAssociatedStream
  .property instance callconv(8) string PSVAttachedScenario()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_PSVAttachedScenario()
  } // end of property ISimPSVNavigationStrings::PSVAttachedScenario
  .property instance callconv(8) string PSVStreamTemperature()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_PSVStreamTemperature()
  } // end of property ISimPSVNavigationStrings::PSVStreamTemperature
  .property instance callconv(8) string ScenarioKey()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioKey()
  } // end of property ISimPSVNavigationStrings::ScenarioKey
  .property instance callconv(8) string ScenarioFluid()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioFluid()
  } // end of property ISimPSVNavigationStrings::ScenarioFluid
  .property instance callconv(8) string ScenarioOverrideStream()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioOverrideStream()
  } // end of property ISimPSVNavigationStrings::ScenarioOverrideStream
  .property instance callconv(8) string ScenarioRefStream()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioRefStream()
  } // end of property ISimPSVNavigationStrings::ScenarioRefStream
  .property instance callconv(8) string ScenarioOverrideStreamID()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioOverrideStreamID()
  } // end of property ISimPSVNavigationStrings::ScenarioOverrideStreamID
  .property instance callconv(8) string ScenarioRefStreamMassFlow()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioRefStreamMassFlow()
  } // end of property ISimPSVNavigationStrings::ScenarioRefStreamMassFlow
  .property instance callconv(8) string ScenarioIsDirty()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioIsDirty()
  } // end of property ISimPSVNavigationStrings::ScenarioIsDirty
  .property instance callconv(8) string ScenarioRefStreamTemperature()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioRefStreamTemperature()
  } // end of property ISimPSVNavigationStrings::ScenarioRefStreamTemperature
  .property instance callconv(8) string ScenarioCalcOrificeSize()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioCalcOrificeSize()
  } // end of property ISimPSVNavigationStrings::ScenarioCalcOrificeSize
  .property instance callconv(8) string ScenarioSelOrificeSize()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioSelOrificeSize()
  } // end of property ISimPSVNavigationStrings::ScenarioSelOrificeSize
  .property instance callconv(8) string ScenarioOrificeDesignation()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioOrificeDesignation()
  } // end of property ISimPSVNavigationStrings::ScenarioOrificeDesignation
  .property instance callconv(8) string ScenarioInletPipeID()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioInletPipeID()
  } // end of property ISimPSVNavigationStrings::ScenarioInletPipeID
  .property instance callconv(8) string ScenarioOutletPipeID()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioOutletPipeID()
  } // end of property ISimPSVNavigationStrings::ScenarioOutletPipeID
  .property instance callconv(8) string ScenarioIsSizingCase()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ScenarioIsSizingCase()
  } // end of property ISimPSVNavigationStrings::ScenarioIsSizingCase
  .property instance callconv(8) string TankKey()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_TankKey()
  } // end of property ISimPSVNavigationStrings::TankKey
  .property instance callconv(8) string TankFluid()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_TankFluid()
  } // end of property ISimPSVNavigationStrings::TankFluid
  .property instance callconv(8) string TankUseRefStream()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_TankUseRefStream()
  } // end of property ISimPSVNavigationStrings::TankUseRefStream
  .property instance callconv(8) string TankRefStream()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_TankRefStream()
  } // end of property ISimPSVNavigationStrings::TankRefStream
  .property instance callconv(8) string TankIsDirty()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_TankIsDirty()
  } // end of property ISimPSVNavigationStrings::TankIsDirty
  .property instance callconv(8) string TankDirectory()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_TankDirectory()
  } // end of property ISimPSVNavigationStrings::TankDirectory
  .property instance callconv(8) string ObjectName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_ObjectName()
  } // end of property ISimPSVNavigationStrings::ObjectName
  .property instance callconv(8) string StreamPress()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings::get_StreamPress()
  } // end of property ISimPSVNavigationStrings::StreamPress
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVNavigationStrings

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings
{
  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Length_m() cil managed
  {
  } // end of method ISimUnitStrings::get_Length_m

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Length_in() cil managed
  {
  } // end of method ISimUnitStrings::get_Length_in

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Area_cm2() cil managed
  {
  } // end of method ISimUnitStrings::get_Area_cm2

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Temperature_C() cil managed
  {
  } // end of method ISimUnitStrings::get_Temperature_C

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Pressure_kPa() cil managed
  {
  } // end of method ISimUnitStrings::get_Pressure_kPa

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_MassDensity_kg_m3() cil managed
  {
  } // end of method ISimUnitStrings::get_MassDensity_kg_m3

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_MassEnthalpy_kJ_kg() cil managed
  {
  } // end of method ISimUnitStrings::get_MassEnthalpy_kJ_kg

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_MassHeatCapacity_kJ_kg_C() cil managed
  {
  } // end of method ISimUnitStrings::get_MassHeatCapacity_kJ_kg_C

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_MolarEnthalpy_kJ_kgmol() cil managed
  {
  } // end of method ISimUnitStrings::get_MolarEnthalpy_kJ_kgmol

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Viscosity_cP() cil managed
  {
  } // end of method ISimUnitStrings::get_Viscosity_cP

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_MassFlow_kg_h() cil managed
  {
  } // end of method ISimUnitStrings::get_MassFlow_kg_h

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_MassEntropy_kJ_kg_C() cil managed
  {
  } // end of method ISimUnitStrings::get_MassEntropy_kJ_kg_C

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_SurfaceTension_dyn_cm() cil managed
  {
  } // end of method ISimUnitStrings::get_SurfaceTension_dyn_cm

  .property instance callconv(8) string Length_m()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Length_m()
  } // end of property ISimUnitStrings::Length_m
  .property instance callconv(8) string Length_in()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Length_in()
  } // end of property ISimUnitStrings::Length_in
  .property instance callconv(8) string Area_cm2()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Area_cm2()
  } // end of property ISimUnitStrings::Area_cm2
  .property instance callconv(8) string Temperature_C()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Temperature_C()
  } // end of property ISimUnitStrings::Temperature_C
  .property instance callconv(8) string Pressure_kPa()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Pressure_kPa()
  } // end of property ISimUnitStrings::Pressure_kPa
  .property instance callconv(8) string MassDensity_kg_m3()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_MassDensity_kg_m3()
  } // end of property ISimUnitStrings::MassDensity_kg_m3
  .property instance callconv(8) string MassEnthalpy_kJ_kg()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_MassEnthalpy_kJ_kg()
  } // end of property ISimUnitStrings::MassEnthalpy_kJ_kg
  .property instance callconv(8) string MassHeatCapacity_kJ_kg_C()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_MassHeatCapacity_kJ_kg_C()
  } // end of property ISimUnitStrings::MassHeatCapacity_kJ_kg_C
  .property instance callconv(8) string MolarEnthalpy_kJ_kgmol()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_MolarEnthalpy_kJ_kgmol()
  } // end of property ISimUnitStrings::MolarEnthalpy_kJ_kgmol
  .property instance callconv(8) string Viscosity_cP()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_Viscosity_cP()
  } // end of property ISimUnitStrings::Viscosity_cP
  .property instance callconv(8) string MassFlow_kg_h()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_MassFlow_kg_h()
  } // end of property ISimUnitStrings::MassFlow_kg_h
  .property instance callconv(8) string MassEntropy_kJ_kg_C()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_MassEntropy_kJ_kg_C()
  } // end of property ISimUnitStrings::MassEntropy_kJ_kg_C
  .property instance callconv(8) string SurfaceTension_dyn_cm()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings::get_SurfaceTension_dyn_cm()
  } // end of property ISimUnitStrings::SurfaceTension_dyn_cm
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ISimUnitStrings

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings
{
  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Fluid_T() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Fluid_T

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Fluid_P() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Fluid_P

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Fluid_SaturationP() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Fluid_SaturationP

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Fluid_VaporFraction() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Fluid_VaporFraction

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Fluid_HeatOfVaporization() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Fluid_HeatOfVaporization

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Ideal_CpCvRatio() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Ideal_CpCvRatio

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_SemiIdeal_CpCvRatio() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_SemiIdeal_CpCvRatio

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Rigorous_CpCvRatio() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Rigorous_CpCvRatio

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Critical_P() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Critical_P

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Critical_T() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Critical_T

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Liquid_CriticalPressure() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Liquid_CriticalPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Liquid_PseudoCriticalPressure() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Liquid_PseudoCriticalPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Liquid_MassDensity() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Liquid_MassDensity

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Liquid_MassEnthalpy() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Liquid_MassEnthalpy

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Liquid_MassEntropy() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Liquid_MassEntropy

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Liquid_MassHeatCapacity() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Liquid_MassHeatCapacity

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Liquid_MolecularWeight() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Liquid_MolecularWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Liquid_Viscosity() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Liquid_Viscosity

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Liquid_MassFlow() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Liquid_MassFlow

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Liquid_SurfaceTension() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Liquid_SurfaceTension

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_CriticalPressure() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_CriticalPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_PseudoCriticalPressure() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_PseudoCriticalPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_MassFraction() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_MassFraction

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_MassDensity() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_MassDensity

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_MassEnthalpy() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_MassEnthalpy

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_MassEntropy() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_MassEntropy

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_MassHeatCapacity() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_MassHeatCapacity

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_MolecularWeight() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_MolecularWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_Viscosity() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_Viscosity

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_ZFactor() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_ZFactor

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Vapor_MassFlow() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Vapor_MassFlow

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Overall_CriticalPressure() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Overall_CriticalPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Overall_PseudoCriticalPressure() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Overall_PseudoCriticalPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Overall_Density() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Overall_Density

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Overall_MassFlow() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Overall_MassFlow

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Overall_MolecularWeight() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Overall_MolecularWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Overall_Mass_Heat_Capacity() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Overall_Mass_Heat_Capacity

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Overall_Mass_Enthalpy() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Overall_Mass_Enthalpy

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Overall_Mass_Entropy() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Overall_Mass_Entropy

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_NumComponents() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_NumComponents

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Fluid_ComponentName() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Fluid_ComponentName

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Fluid_Composition() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Fluid_Composition

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Fluid_StoredComposition() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Fluid_StoredComposition

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_StreamName() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_StreamName

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Component_MolecularWeight() cil managed
  {
  } // end of method ISimPSVPropertyStrings::get_Component_MolecularWeight

  .property instance callconv(8) string Fluid_T()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Fluid_T()
  } // end of property ISimPSVPropertyStrings::Fluid_T
  .property instance callconv(8) string Fluid_P()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Fluid_P()
  } // end of property ISimPSVPropertyStrings::Fluid_P
  .property instance callconv(8) string Fluid_SaturationP()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Fluid_SaturationP()
  } // end of property ISimPSVPropertyStrings::Fluid_SaturationP
  .property instance callconv(8) string Fluid_VaporFraction()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Fluid_VaporFraction()
  } // end of property ISimPSVPropertyStrings::Fluid_VaporFraction
  .property instance callconv(8) string Fluid_HeatOfVaporization()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Fluid_HeatOfVaporization()
  } // end of property ISimPSVPropertyStrings::Fluid_HeatOfVaporization
  .property instance callconv(8) string Ideal_CpCvRatio()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Ideal_CpCvRatio()
  } // end of property ISimPSVPropertyStrings::Ideal_CpCvRatio
  .property instance callconv(8) string SemiIdeal_CpCvRatio()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_SemiIdeal_CpCvRatio()
  } // end of property ISimPSVPropertyStrings::SemiIdeal_CpCvRatio
  .property instance callconv(8) string Rigorous_CpCvRatio()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Rigorous_CpCvRatio()
  } // end of property ISimPSVPropertyStrings::Rigorous_CpCvRatio
  .property instance callconv(8) string Critical_P()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Critical_P()
  } // end of property ISimPSVPropertyStrings::Critical_P
  .property instance callconv(8) string Critical_T()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Critical_T()
  } // end of property ISimPSVPropertyStrings::Critical_T
  .property instance callconv(8) string Liquid_CriticalPressure()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Liquid_CriticalPressure()
  } // end of property ISimPSVPropertyStrings::Liquid_CriticalPressure
  .property instance callconv(8) string Liquid_PseudoCriticalPressure()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Liquid_PseudoCriticalPressure()
  } // end of property ISimPSVPropertyStrings::Liquid_PseudoCriticalPressure
  .property instance callconv(8) string Liquid_MassDensity()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Liquid_MassDensity()
  } // end of property ISimPSVPropertyStrings::Liquid_MassDensity
  .property instance callconv(8) string Liquid_MassEnthalpy()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Liquid_MassEnthalpy()
  } // end of property ISimPSVPropertyStrings::Liquid_MassEnthalpy
  .property instance callconv(8) string Liquid_MassEntropy()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Liquid_MassEntropy()
  } // end of property ISimPSVPropertyStrings::Liquid_MassEntropy
  .property instance callconv(8) string Liquid_MassHeatCapacity()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Liquid_MassHeatCapacity()
  } // end of property ISimPSVPropertyStrings::Liquid_MassHeatCapacity
  .property instance callconv(8) string Liquid_MolecularWeight()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Liquid_MolecularWeight()
  } // end of property ISimPSVPropertyStrings::Liquid_MolecularWeight
  .property instance callconv(8) string Liquid_Viscosity()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Liquid_Viscosity()
  } // end of property ISimPSVPropertyStrings::Liquid_Viscosity
  .property instance callconv(8) string Liquid_MassFlow()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Liquid_MassFlow()
  } // end of property ISimPSVPropertyStrings::Liquid_MassFlow
  .property instance callconv(8) string Liquid_SurfaceTension()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Liquid_SurfaceTension()
  } // end of property ISimPSVPropertyStrings::Liquid_SurfaceTension
  .property instance callconv(8) string Vapor_CriticalPressure()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_CriticalPressure()
  } // end of property ISimPSVPropertyStrings::Vapor_CriticalPressure
  .property instance callconv(8) string Vapor_PseudoCriticalPressure()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_PseudoCriticalPressure()
  } // end of property ISimPSVPropertyStrings::Vapor_PseudoCriticalPressure
  .property instance callconv(8) string Vapor_MassFraction()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_MassFraction()
  } // end of property ISimPSVPropertyStrings::Vapor_MassFraction
  .property instance callconv(8) string Vapor_MassDensity()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_MassDensity()
  } // end of property ISimPSVPropertyStrings::Vapor_MassDensity
  .property instance callconv(8) string Vapor_MassEnthalpy()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_MassEnthalpy()
  } // end of property ISimPSVPropertyStrings::Vapor_MassEnthalpy
  .property instance callconv(8) string Vapor_MassEntropy()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_MassEntropy()
  } // end of property ISimPSVPropertyStrings::Vapor_MassEntropy
  .property instance callconv(8) string Vapor_MassHeatCapacity()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_MassHeatCapacity()
  } // end of property ISimPSVPropertyStrings::Vapor_MassHeatCapacity
  .property instance callconv(8) string Vapor_MolecularWeight()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_MolecularWeight()
  } // end of property ISimPSVPropertyStrings::Vapor_MolecularWeight
  .property instance callconv(8) string Vapor_Viscosity()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_Viscosity()
  } // end of property ISimPSVPropertyStrings::Vapor_Viscosity
  .property instance callconv(8) string Vapor_ZFactor()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_ZFactor()
  } // end of property ISimPSVPropertyStrings::Vapor_ZFactor
  .property instance callconv(8) string Vapor_MassFlow()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Vapor_MassFlow()
  } // end of property ISimPSVPropertyStrings::Vapor_MassFlow
  .property instance callconv(8) string Overall_CriticalPressure()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Overall_CriticalPressure()
  } // end of property ISimPSVPropertyStrings::Overall_CriticalPressure
  .property instance callconv(8) string Overall_PseudoCriticalPressure()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Overall_PseudoCriticalPressure()
  } // end of property ISimPSVPropertyStrings::Overall_PseudoCriticalPressure
  .property instance callconv(8) string Overall_Density()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Overall_Density()
  } // end of property ISimPSVPropertyStrings::Overall_Density
  .property instance callconv(8) string Overall_MassFlow()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Overall_MassFlow()
  } // end of property ISimPSVPropertyStrings::Overall_MassFlow
  .property instance callconv(8) string Overall_MolecularWeight()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Overall_MolecularWeight()
  } // end of property ISimPSVPropertyStrings::Overall_MolecularWeight
  .property instance callconv(8) string Overall_Mass_Heat_Capacity()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Overall_Mass_Heat_Capacity()
  } // end of property ISimPSVPropertyStrings::Overall_Mass_Heat_Capacity
  .property instance callconv(8) string Overall_Mass_Enthalpy()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Overall_Mass_Enthalpy()
  } // end of property ISimPSVPropertyStrings::Overall_Mass_Enthalpy
  .property instance callconv(8) string Overall_Mass_Entropy()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Overall_Mass_Entropy()
  } // end of property ISimPSVPropertyStrings::Overall_Mass_Entropy
  .property instance callconv(8) string NumComponents()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_NumComponents()
  } // end of property ISimPSVPropertyStrings::NumComponents
  .property instance callconv(8) string Fluid_ComponentName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Fluid_ComponentName()
  } // end of property ISimPSVPropertyStrings::Fluid_ComponentName
  .property instance callconv(8) string Fluid_Composition()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Fluid_Composition()
  } // end of property ISimPSVPropertyStrings::Fluid_Composition
  .property instance callconv(8) string Fluid_StoredComposition()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Fluid_StoredComposition()
  } // end of property ISimPSVPropertyStrings::Fluid_StoredComposition
  .property instance callconv(8) string StreamName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_StreamName()
  } // end of property ISimPSVPropertyStrings::StreamName
  .property instance callconv(8) string Component_MolecularWeight()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings::get_Component_MolecularWeight()
  } // end of property ISimPSVPropertyStrings::Component_MolecularWeight
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVPropertyStrings

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands
{
  .method public hidebysig newslot abstract virtual 
          instance string  Flash_ConstH(float64 P) cil managed
  {
  } // end of method ISimPSVCommands::Flash_ConstH

  .method public hidebysig newslot abstract virtual 
          instance string  Flash_ConstS(float64 P) cil managed
  {
  } // end of method ISimPSVCommands::Flash_ConstS

  .method public hidebysig newslot abstract virtual 
          instance string  Flash_PVf(float64 P,
                                     float64 Vf) cil managed
  {
  } // end of method ISimPSVCommands::Flash_PVf

  .method public hidebysig newslot abstract virtual 
          instance string  Flash_PH(float64 P,
                                    float64 H) cil managed
  {
  } // end of method ISimPSVCommands::Flash_PH

  .method public hidebysig newslot abstract virtual 
          instance string  Flash_PS(float64 P,
                                    float64 S) cil managed
  {
  } // end of method ISimPSVCommands::Flash_PS

  .method public hidebysig newslot abstract virtual 
          instance string  Flash_TP(float64 T,
                                    float64 P) cil managed
  {
  } // end of method ISimPSVCommands::Flash_TP

  .method public hidebysig newslot abstract virtual 
          instance string  Flash_TP_Fire(float64 T,
                                         float64 P) cil managed
  {
  } // end of method ISimPSVCommands::Flash_TP_Fire

  .method public hidebysig newslot abstract virtual 
          instance string  Flash_TVf(float64 T,
                                     float64 Vf) cil managed
  {
  } // end of method ISimPSVCommands::Flash_TVf

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Create_PSV() cil managed
  {
  } // end of method ISimPSVCommands::get_Create_PSV

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Delete_PSV() cil managed
  {
  } // end of method ISimPSVCommands::get_Delete_PSV

  .method public hidebysig newslot abstract virtual 
          instance string  PSVCreate_Scenario(string name) cil managed
  {
  } // end of method ISimPSVCommands::PSVCreate_Scenario

  .method public hidebysig newslot abstract virtual 
          instance string  PSVDelete_Scenario(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey Key) cil managed
  {
  } // end of method ISimPSVCommands::PSVDelete_Scenario

  .method public hidebysig newslot abstract virtual 
          instance string  PSVDuplicate_Scenario(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey Key) cil managed
  {
  } // end of method ISimPSVCommands::PSVDuplicate_Scenario

  .method public hidebysig newslot abstract virtual 
          instance string  PSVAddStatus(string level,
                                        int32 count,
                                        string message) cil managed
  {
  } // end of method ISimPSVCommands::PSVAddStatus

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_PSVClearStatus() cil managed
  {
  } // end of method ISimPSVCommands::get_PSVClearStatus

  .method public hidebysig newslot specialname abstract virtual 
          instance string  get_Create_Tank() cil managed
  {
  } // end of method ISimPSVCommands::get_Create_Tank

  .method public hidebysig newslot abstract virtual 
          instance string  Delete_Tank(int32 Key) cil managed
  {
  } // end of method ISimPSVCommands::Delete_Tank

  .method public hidebysig newslot abstract virtual 
          instance void  WaitForScenarioConstruction(object prdModel) cil managed
  {
  } // end of method ISimPSVCommands::WaitForScenarioConstruction

  .method public hidebysig newslot abstract virtual 
          instance void  DeletePSVFromCaseAndWait(string cxsPath,
                                                  string psvName,
                                                  class [mscorlib]System.Collections.IList modelContainer) cil managed
  {
  } // end of method ISimPSVCommands::DeletePSVFromCaseAndWait

  .property instance callconv(8) string Create_PSV()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands::get_Create_PSV()
  } // end of property ISimPSVCommands::Create_PSV
  .property instance callconv(8) string Delete_PSV()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands::get_Delete_PSV()
  } // end of property ISimPSVCommands::Delete_PSV
  .property instance callconv(8) string PSVClearStatus()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands::get_PSVClearStatus()
  } // end of property ISimPSVCommands::PSVClearStatus
  .property instance callconv(8) string Create_Tank()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands::get_Create_Tank()
  } // end of property ISimPSVCommands::Create_Tank
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ISimPSVCommands

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.ISubject
{
  .method public hidebysig newslot abstract virtual 
          instance void  Notify(string propertyName) cil managed
  {
  } // end of method ISubject::Notify

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.ISubject

.class interface public abstract auto ansi AspenTech.EquipmentAnalysis.Infrastructure.IObserver
{
  .method public hidebysig newslot abstract virtual 
          instance void  Update(string propertyName) cil managed
  {
  } // end of method IObserver::Update

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.IObserver

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver
       extends [mscorlib]System.Object
{
  .field private initonly class [System.Core]System.Collections.Generic.HashSet`1<string> _observedPropertiesExpressions
  .field private initonly class [mscorlib]System.Action _action
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class [mscorlib]System.Action action) cil managed
  {
    // Code size       25 (0x19)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  newobj     instance void class [System.Core]System.Collections.Generic.HashSet`1<string>::.ctor()
    IL_0006:  stfld      class [System.Core]System.Collections.Generic.HashSet`1<string> AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver::_observedPropertiesExpressions
    IL_000b:  ldarg.0
    IL_000c:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0011:  ldarg.0
    IL_0012:  ldarg.1
    IL_0013:  stfld      class [mscorlib]System.Action AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver::_action
    IL_0018:  ret
  } // end of method PropertyObserver::.ctor

  .method public hidebysig instance class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver 
          ObservesProperty<T>(class [System.Core]System.Linq.Expressions.Expression`1<class [mscorlib]System.Func`1<!!T>> propertyExpression) cil managed
  {
    // Code size       79 (0x4f)
    .maxstack  2
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System.Core]System.Collections.Generic.HashSet`1<string> AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver::_observedPropertiesExpressions
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_000c:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Contains(!0)
    IL_0011:  brfalse.s  IL_002e

    IL_0013:  ldarg.1
    IL_0014:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_0019:  ldstr      " is already being observed."
    IL_001e:  call       string [mscorlib]System.String::Concat(string,
                                                                string)
    IL_0023:  ldstr      "propertyExpression"
    IL_0028:  newobj     instance void [mscorlib]System.ArgumentException::.ctor(string,
                                                                                 string)
    IL_002d:  throw

    IL_002e:  ldarg.0
    IL_002f:  ldfld      class [System.Core]System.Collections.Generic.HashSet`1<string> AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver::_observedPropertiesExpressions
    IL_0034:  ldarg.1
    IL_0035:  callvirt   instance string [mscorlib]System.Object::ToString()
    IL_003a:  callvirt   instance bool class [System.Core]System.Collections.Generic.HashSet`1<string>::Add(!0)
    IL_003f:  pop
    IL_0040:  ldarg.1
    IL_0041:  ldarg.0
    IL_0042:  ldfld      class [mscorlib]System.Action AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver::_action
    IL_0047:  call       class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal::Observes<!!0>(class [System.Core]System.Linq.Expressions.Expression`1<class [mscorlib]System.Func`1<!!0>>,
                                                                                                                                                                                      class [mscorlib]System.Action)
    IL_004c:  pop
    IL_004d:  ldarg.0
    IL_004e:  ret
  } // end of method PropertyObserver::ObservesProperty

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserver

.class private auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal
       extends [mscorlib]System.Object
{
  .field private initonly class [mscorlib]System.Action _action
  .method private hidebysig specialname rtspecialname 
          instance void  .ctor(class [System.Core]System.Linq.Expressions.Expression propertyExpression,
                               class [mscorlib]System.Action action) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.2
    IL_0008:  stfld      class [mscorlib]System.Action AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal::_action
    IL_000d:  ldarg.0
    IL_000e:  ldarg.1
    IL_000f:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal::SubscribeListeners(class [System.Core]System.Linq.Expressions.Expression)
    IL_0014:  ret
  } // end of method PropertyObserverInternal::.ctor

  .method private hidebysig instance void 
          SubscribeListeners(class [System.Core]System.Linq.Expressions.Expression propertyExpression) cil managed
  {
    // Code size       207 (0xcf)
    .maxstack  3
    .locals init (class [System]System.Collections.Generic.Stack`1<string> V_0,
             class [System.Core]System.Linq.Expressions.ConstantExpression V_1,
             class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal V_2,
             class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal V_3,
             class [System]System.ComponentModel.INotifyPropertyChanged V_4,
             class [System.Core]System.Linq.Expressions.MemberExpression V_5,
             valuetype [System]System.Collections.Generic.Stack`1/Enumerator<string> V_6,
             class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal V_7)
    IL_0000:  newobj     instance void class [System]System.Collections.Generic.Stack`1<string>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.1
    IL_0007:  isinst     [System.Core]System.Linq.Expressions.MemberExpression
    IL_000c:  stloc.s    V_5
    IL_000e:  ldloc.s    V_5
    IL_0010:  brfalse.s  IL_002f

    IL_0012:  ldloc.s    V_5
    IL_0014:  callvirt   instance class [System.Core]System.Linq.Expressions.Expression [System.Core]System.Linq.Expressions.MemberExpression::get_Expression()
    IL_0019:  starg.s    propertyExpression
    IL_001b:  ldloc.0
    IL_001c:  ldloc.s    V_5
    IL_001e:  callvirt   instance class [mscorlib]System.Reflection.MemberInfo [System.Core]System.Linq.Expressions.MemberExpression::get_Member()
    IL_0023:  callvirt   instance string [mscorlib]System.Reflection.MemberInfo::get_Name()
    IL_0028:  callvirt   instance void class [System]System.Collections.Generic.Stack`1<string>::Push(!0)
    IL_002d:  br.s       IL_0006

    IL_002f:  ldarg.1
    IL_0030:  isinst     [System.Core]System.Linq.Expressions.ConstantExpression
    IL_0035:  stloc.1
    IL_0036:  ldloc.1
    IL_0037:  brtrue.s   IL_0044

    IL_0039:  ldstr      "Operation not supported for the given expression t"
    + "ype. Only MemberExpression and ConstanteExpression are currently suppor"
    + "ted."
    IL_003e:  newobj     instance void [mscorlib]System.NotSupportedException::.ctor(string)
    IL_0043:  throw

    IL_0044:  ldloc.0
    IL_0045:  callvirt   instance !0 class [System]System.Collections.Generic.Stack`1<string>::Pop()
    IL_004a:  ldarg.0
    IL_004b:  ldfld      class [mscorlib]System.Action AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal::_action
    IL_0050:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::.ctor(string,
                                                                                                                      class [mscorlib]System.Action)
    IL_0055:  stloc.2
    IL_0056:  ldloc.2
    IL_0057:  stloc.3
    IL_0058:  ldloc.0
    IL_0059:  callvirt   instance valuetype [System]System.Collections.Generic.Stack`1/Enumerator<!0> class [System]System.Collections.Generic.Stack`1<string>::GetEnumerator()
    IL_005e:  stloc.s    V_6
    .try
    {
      IL_0060:  br.s       IL_0081

      IL_0062:  ldloca.s   V_6
      IL_0064:  call       instance !0 valuetype [System]System.Collections.Generic.Stack`1/Enumerator<string>::get_Current()
      IL_0069:  ldarg.0
      IL_006a:  ldfld      class [mscorlib]System.Action AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal::_action
      IL_006f:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::.ctor(string,
                                                                                                                        class [mscorlib]System.Action)
      IL_0074:  stloc.s    V_7
      IL_0076:  ldloc.3
      IL_0077:  ldloc.s    V_7
      IL_0079:  callvirt   instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::set_Next(class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal)
      IL_007e:  ldloc.s    V_7
      IL_0080:  stloc.3
      IL_0081:  ldloca.s   V_6
      IL_0083:  call       instance bool valuetype [System]System.Collections.Generic.Stack`1/Enumerator<string>::MoveNext()
      IL_0088:  brtrue.s   IL_0062

      IL_008a:  leave.s    IL_009a

    }  // end .try
    finally
    {
      IL_008c:  ldloca.s   V_6
      IL_008e:  constrained. valuetype [System]System.Collections.Generic.Stack`1/Enumerator<string>
      IL_0094:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
      IL_0099:  endfinally
    }  // end handler
    IL_009a:  ldloc.1
    IL_009b:  callvirt   instance object [System.Core]System.Linq.Expressions.ConstantExpression::get_Value()
    IL_00a0:  isinst     [System]System.ComponentModel.INotifyPropertyChanged
    IL_00a5:  stloc.s    V_4
    IL_00a7:  ldloc.s    V_4
    IL_00a9:  brtrue.s   IL_00c6

    IL_00ab:  ldstr      "Trying to subscribe PropertyChanged listener in ob"
    + "ject that owns '"
    IL_00b0:  ldloc.2
    IL_00b1:  callvirt   instance string AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_PropertyName()
    IL_00b6:  ldstr      "' property, but the object does not implements INo"
    + "tifyPropertyChanged."
    IL_00bb:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_00c0:  newobj     instance void [mscorlib]System.InvalidOperationException::.ctor(string)
    IL_00c5:  throw

    IL_00c6:  ldloc.2
    IL_00c7:  ldloc.s    V_4
    IL_00c9:  callvirt   instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::SubscribeListenerFor(class [System]System.ComponentModel.INotifyPropertyChanged)
    IL_00ce:  ret
  } // end of method PropertyObserverInternal::SubscribeListeners

  .method assembly hidebysig static class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal 
          Observes<T>(class [System.Core]System.Linq.Expressions.Expression`1<class [mscorlib]System.Func`1<!!T>> propertyExpression,
                      class [mscorlib]System.Action action) cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  callvirt   instance class [System.Core]System.Linq.Expressions.Expression [System.Core]System.Linq.Expressions.LambdaExpression::get_Body()
    IL_0006:  ldarg.1
    IL_0007:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal::.ctor(class [System.Core]System.Linq.Expressions.Expression,
                                                                                                                  class [mscorlib]System.Action)
    IL_000c:  ret
  } // end of method PropertyObserverInternal::Observes

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverInternal

.class private auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal
       extends [mscorlib]System.Object
{
  .class auto ansi sealed nested private beforefieldinit '<>c__DisplayClass9_0'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public class [mscorlib]System.Action action
    .field public class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal '<>4__this'
    .method public hidebysig specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      // Code size       7 (0x7)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0006:  ret
    } // end of method '<>c__DisplayClass9_0'::.ctor

    .method assembly hidebysig instance void 
            '<.ctor>b__0'() cil managed
    {
      // Code size       59 (0x3b)
      .maxstack  8
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [mscorlib]System.Action AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal/'<>c__DisplayClass9_0'::action
      IL_0006:  dup
      IL_0007:  brtrue.s   IL_000c

      IL_0009:  pop
      IL_000a:  br.s       IL_0011

      IL_000c:  callvirt   instance void [mscorlib]System.Action::Invoke()
      IL_0011:  ldarg.0
      IL_0012:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal/'<>c__DisplayClass9_0'::'<>4__this'
      IL_0017:  call       instance class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_Next()
      IL_001c:  brtrue.s   IL_001f

      IL_001e:  ret

      IL_001f:  ldarg.0
      IL_0020:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal/'<>c__DisplayClass9_0'::'<>4__this'
      IL_0025:  call       instance class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_Next()
      IL_002a:  callvirt   instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::UnsubscribeListener()
      IL_002f:  ldarg.0
      IL_0030:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal/'<>c__DisplayClass9_0'::'<>4__this'
      IL_0035:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::GenerateNextNode()
      IL_003a:  ret
    } // end of method '<>c__DisplayClass9_0'::'<.ctor>b__0'

  } // end of class '<>c__DisplayClass9_0'

  .field private initonly class [mscorlib]System.Action _action
  .field private class [System]System.ComponentModel.INotifyPropertyChanged _inpcObject
  .field private initonly string '<PropertyName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal '<Next>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance string 
          get_PropertyName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::'<PropertyName>k__BackingField'
    IL_0006:  ret
  } // end of method PropertyObserverNodeInternal::get_PropertyName

  .method public hidebysig specialname instance class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal 
          get_Next() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::'<Next>k__BackingField'
    IL_0006:  ret
  } // end of method PropertyObserverNodeInternal::get_Next

  .method public hidebysig specialname instance void 
          set_Next(class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::'<Next>k__BackingField'
    IL_0007:  ret
  } // end of method PropertyObserverNodeInternal::set_Next

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string propertyName,
                               class [mscorlib]System.Action action) cil managed
  {
    // Code size       52 (0x34)
    .maxstack  3
    .locals init (class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal/'<>c__DisplayClass9_0' V_0)
    IL_0000:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal/'<>c__DisplayClass9_0'::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldloc.0
    IL_0007:  ldarg.2
    IL_0008:  stfld      class [mscorlib]System.Action AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal/'<>c__DisplayClass9_0'::action
    IL_000d:  ldarg.0
    IL_000e:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0013:  ldloc.0
    IL_0014:  ldarg.0
    IL_0015:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal/'<>c__DisplayClass9_0'::'<>4__this'
    IL_001a:  ldarg.0
    IL_001b:  ldarg.1
    IL_001c:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::'<PropertyName>k__BackingField'
    IL_0021:  ldarg.0
    IL_0022:  ldloc.0
    IL_0023:  ldftn      instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal/'<>c__DisplayClass9_0'::'<.ctor>b__0'()
    IL_0029:  newobj     instance void [mscorlib]System.Action::.ctor(object,
                                                                      native int)
    IL_002e:  stfld      class [mscorlib]System.Action AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::_action
    IL_0033:  ret
  } // end of method PropertyObserverNodeInternal::.ctor

  .method public hidebysig instance void 
          SubscribeListenerFor(class [System]System.ComponentModel.INotifyPropertyChanged inpcObject) cil managed
  {
    // Code size       45 (0x2d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [System]System.ComponentModel.INotifyPropertyChanged AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::_inpcObject
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class [System]System.ComponentModel.INotifyPropertyChanged AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::_inpcObject
    IL_000d:  ldarg.0
    IL_000e:  ldftn      instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::OnPropertyChanged(object,
                                                                                                                                  class [System]System.ComponentModel.PropertyChangedEventArgs)
    IL_0014:  newobj     instance void [System]System.ComponentModel.PropertyChangedEventHandler::.ctor(object,
                                                                                                        native int)
    IL_0019:  callvirt   instance void [System]System.ComponentModel.INotifyPropertyChanged::add_PropertyChanged(class [System]System.ComponentModel.PropertyChangedEventHandler)
    IL_001e:  ldarg.0
    IL_001f:  call       instance class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_Next()
    IL_0024:  brfalse.s  IL_002c

    IL_0026:  ldarg.0
    IL_0027:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::GenerateNextNode()
    IL_002c:  ret
  } // end of method PropertyObserverNodeInternal::SubscribeListenerFor

  .method private hidebysig instance void 
          GenerateNextNode() cil managed
  {
    // Code size       113 (0x71)
    .maxstack  3
    .locals init (class [mscorlib]System.Type V_0,
             object V_1,
             class [System]System.ComponentModel.INotifyPropertyChanged V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.ComponentModel.INotifyPropertyChanged AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::_inpcObject
    IL_0006:  callvirt   instance class [mscorlib]System.Type [mscorlib]System.Object::GetType()
    IL_000b:  stloc.0
    IL_000c:  ldloc.0
    IL_000d:  ldarg.0
    IL_000e:  call       instance string AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_PropertyName()
    IL_0013:  call       class [mscorlib]System.Reflection.PropertyInfo [mscorlib]System.Reflection.RuntimeReflectionExtensions::GetRuntimeProperty(class [mscorlib]System.Type,
                                                                                                                                                    string)
    IL_0018:  dup
    IL_0019:  brtrue.s   IL_002a

    IL_001b:  pop
    IL_001c:  ldloc.0
    IL_001d:  ldarg.0
    IL_001e:  call       instance string AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_PropertyName()
    IL_0023:  ldc.i4.s   36
    IL_0025:  callvirt   instance class [mscorlib]System.Reflection.PropertyInfo [mscorlib]System.Type::GetProperty(string,
                                                                                                                    valuetype [mscorlib]System.Reflection.BindingFlags)
    IL_002a:  ldarg.0
    IL_002b:  ldfld      class [System]System.ComponentModel.INotifyPropertyChanged AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::_inpcObject
    IL_0030:  callvirt   instance object [mscorlib]System.Reflection.PropertyInfo::GetValue(object)
    IL_0035:  stloc.1
    IL_0036:  ldloc.1
    IL_0037:  brtrue.s   IL_003a

    IL_0039:  ret

    IL_003a:  ldloc.1
    IL_003b:  isinst     [System]System.ComponentModel.INotifyPropertyChanged
    IL_0040:  stloc.2
    IL_0041:  ldloc.2
    IL_0042:  brtrue.s   IL_0064

    IL_0044:  ldstr      "Trying to subscribe PropertyChanged listener in ob"
    + "ject that owns '"
    IL_0049:  ldarg.0
    IL_004a:  call       instance class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_Next()
    IL_004f:  callvirt   instance string AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_PropertyName()
    IL_0054:  ldstr      "' property, but the object does not implements INo"
    + "tifyPropertyChanged."
    IL_0059:  call       string [mscorlib]System.String::Concat(string,
                                                                string,
                                                                string)
    IL_005e:  newobj     instance void [mscorlib]System.InvalidOperationException::.ctor(string)
    IL_0063:  throw

    IL_0064:  ldarg.0
    IL_0065:  call       instance class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_Next()
    IL_006a:  ldloc.2
    IL_006b:  callvirt   instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::SubscribeListenerFor(class [System]System.ComponentModel.INotifyPropertyChanged)
    IL_0070:  ret
  } // end of method PropertyObserverNodeInternal::GenerateNextNode

  .method private hidebysig instance void 
          UnsubscribeListener() cil managed
  {
    // Code size       48 (0x30)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [System]System.ComponentModel.INotifyPropertyChanged AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::_inpcObject
    IL_0006:  brfalse.s  IL_001f

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [System]System.ComponentModel.INotifyPropertyChanged AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::_inpcObject
    IL_000e:  ldarg.0
    IL_000f:  ldftn      instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::OnPropertyChanged(object,
                                                                                                                                  class [System]System.ComponentModel.PropertyChangedEventArgs)
    IL_0015:  newobj     instance void [System]System.ComponentModel.PropertyChangedEventHandler::.ctor(object,
                                                                                                        native int)
    IL_001a:  callvirt   instance void [System]System.ComponentModel.INotifyPropertyChanged::remove_PropertyChanged(class [System]System.ComponentModel.PropertyChangedEventHandler)
    IL_001f:  ldarg.0
    IL_0020:  call       instance class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_Next()
    IL_0025:  dup
    IL_0026:  brtrue.s   IL_002a

    IL_0028:  pop
    IL_0029:  ret

    IL_002a:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::UnsubscribeListener()
    IL_002f:  ret
  } // end of method PropertyObserverNodeInternal::UnsubscribeListener

  .method private hidebysig instance void 
          OnPropertyChanged(object sender,
                            class [System]System.ComponentModel.PropertyChangedEventArgs e) cil managed
  {
    // Code size       53 (0x35)
    .maxstack  8
    IL_0000:  ldarg.2
    IL_0001:  brtrue.s   IL_0006

    IL_0003:  ldnull
    IL_0004:  br.s       IL_000c

    IL_0006:  ldarg.2
    IL_0007:  callvirt   instance string [System]System.ComponentModel.PropertyChangedEventArgs::get_PropertyName()
    IL_000c:  ldarg.0
    IL_000d:  call       instance string AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_PropertyName()
    IL_0012:  call       bool [mscorlib]System.String::op_Equality(string,
                                                                   string)
    IL_0017:  brtrue.s   IL_0024

    IL_0019:  ldarg.2
    IL_001a:  brfalse.s  IL_0024

    IL_001c:  ldarg.2
    IL_001d:  callvirt   instance string [System]System.ComponentModel.PropertyChangedEventArgs::get_PropertyName()
    IL_0022:  brtrue.s   IL_0034

    IL_0024:  ldarg.0
    IL_0025:  ldfld      class [mscorlib]System.Action AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::_action
    IL_002a:  dup
    IL_002b:  brtrue.s   IL_002f

    IL_002d:  pop
    IL_002e:  ret

    IL_002f:  callvirt   instance void [mscorlib]System.Action::Invoke()
    IL_0034:  ret
  } // end of method PropertyObserverNodeInternal::OnPropertyChanged

  .property instance callconv(8) string PropertyName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_PropertyName()
  } // end of property PropertyObserverNodeInternal::PropertyName
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal
          Next()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::get_Next()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal::set_Next(class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal)
  } // end of property PropertyObserverNodeInternal::Next
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PropertyObserverNodeInternal

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
       extends AspenTech.EquipmentAnalysis.Infrastructure.PsvKey
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType recordType,
                               int32 'value') cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldarg.2
    IL_0003:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::.ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType,
                                                                                                int32)
    IL_0008:  ret
  } // end of method PsvModelKey::.ctor

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::.ctor()
    IL_0006:  ret
  } // end of method PsvModelKey::.ctor

  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType 
          get_RecordType() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_recordType
    IL_0006:  ret
  } // end of method PsvModelKey::get_RecordType

  .method public hidebysig specialname instance void 
          set_RecordType(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType 'value') cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_recordType
    IL_0007:  ret
  } // end of method PsvModelKey::set_RecordType

  .method public hidebysig specialname instance int32 
          get_Value() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_value
    IL_0006:  ret
  } // end of method PsvModelKey::get_Value

  .method public hidebysig specialname instance void 
          set_Value(int32 'value') cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_value
    IL_0007:  ret
  } // end of method PsvModelKey::set_Value

  .method public hidebysig specialname static 
          class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 
          op_Implicit(class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey dbKey) cil managed
  {
    // Code size       29 (0x1d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldnull
    IL_0002:  call       bool AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::op_Equality(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,
                                                                                             class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0007:  brfalse.s  IL_000b

    IL_0009:  ldnull
    IL_000a:  ret

    IL_000b:  ldarg.0
    IL_000c:  callvirt   instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_RecordType()
    IL_0011:  ldarg.0
    IL_0012:  callvirt   instance int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
    IL_0017:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey::.ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType,
                                                                                                     int32)
    IL_001c:  ret
  } // end of method PsvModelKey::op_Implicit

  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType
          RecordType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey::get_RecordType()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey::set_RecordType(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType)
  } // end of property PsvModelKey::RecordType
  .property instance callconv(8) int32 Value()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey::get_Value()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey::set_Value(int32)
  } // end of property PsvModelKey::Value
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey
       extends AspenTech.EquipmentAnalysis.Infrastructure.PsvKey
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType recordType,
                               int32 'value') cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldarg.2
    IL_0003:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::.ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType,
                                                                                                int32)
    IL_0008:  ret
  } // end of method PSVDBKey::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKeyFactory
       extends [mscorlib]System.Object
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class AspenTech.EquipmentAnalysis.Infrastructure.IPSVDatabaseMgr owner) cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ret
  } // end of method PSVDBKeyFactory::.ctor

  .method public hidebysig instance class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey 
          CreateKey(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType recordType,
                    int32 newKey) cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey::.ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType,
                                                                                                  int32)
    IL_0007:  ret
  } // end of method PSVDBKeyFactory::CreateKey

  .method public hidebysig instance class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey> 
          CreateKeys(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType recordType,
                     int32[] newKeys) cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey> V_0,
             int32[] V_1,
             int32 V_2,
             int32 V_3)
    IL_0000:  newobj     instance void class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey>::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.2
    IL_0007:  stloc.1
    IL_0008:  ldc.i4.0
    IL_0009:  stloc.2
    IL_000a:  br.s       IL_0021

    IL_000c:  ldloc.1
    IL_000d:  ldloc.2
    IL_000e:  ldelem.i4
    IL_000f:  stloc.3
    IL_0010:  ldloc.0
    IL_0011:  ldarg.1
    IL_0012:  ldloc.3
    IL_0013:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey::.ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType,
                                                                                                  int32)
    IL_0018:  callvirt   instance void class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKey>::Add(!0)
    IL_001d:  ldloc.2
    IL_001e:  ldc.i4.1
    IL_001f:  add
    IL_0020:  stloc.2
    IL_0021:  ldloc.2
    IL_0022:  ldloc.1
    IL_0023:  ldlen
    IL_0024:  conv.i4
    IL_0025:  blt.s      IL_000c

    IL_0027:  ldloc.0
    IL_0028:  ret
  } // end of method PSVDBKeyFactory::CreateKeys

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PSVDBKeyFactory

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.eRecordType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType PRDSystem = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType Utility = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType PRD = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType Equipment = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType ReliefLoad = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType OrificeCalc = int32(0x00000005)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType LineSizing = int32(0x00000006)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType IterationResult = int32(0x00000007)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType SimulationSettings = int32(0x00000008)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType ConnectedObject = int32(0x00000009)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.eRecordType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.eUtilityType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eUtilityType TankVent = int32(0x00000000)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.eUtilityType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.eEquipmentType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eEquipmentType Vessel_FireCalc = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eEquipmentType EquipmentBase = int32(0x00000001)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.eEquipmentType

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.eIterationCalcType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.eIterationCalcType RLCFire = int32(0x00000000)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.eIterationCalcType

.class public abstract auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.PsvKey
       extends [mscorlib]System.Object
{
  .field family valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType _recordType
  .field family int32 _value
  .method assembly hidebysig specialname rtspecialname 
          instance void  .ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType recordType,
                               int32 newKey) cil managed
  {
    // Code size       28 (0x1c)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.m1
    IL_0002:  stfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_value
    IL_0007:  ldarg.0
    IL_0008:  call       instance void [mscorlib]System.Object::.ctor()
    IL_000d:  ldarg.0
    IL_000e:  ldarg.1
    IL_000f:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_recordType
    IL_0014:  ldarg.0
    IL_0015:  ldarg.2
    IL_0016:  stfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_value
    IL_001b:  ret
  } // end of method PsvKey::.ctor

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.m1
    IL_0002:  stfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_value
    IL_0007:  ldarg.0
    IL_0008:  call       instance void [mscorlib]System.Object::.ctor()
    IL_000d:  ret
  } // end of method PsvKey::.ctor

  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType 
          get_RecordType() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_recordType
    IL_0006:  ret
  } // end of method PsvKey::get_RecordType

  .method public hidebysig specialname instance int32 
          get_Value() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_value
    IL_0006:  ret
  } // end of method PsvKey::get_Value

  .method public hidebysig virtual instance bool 
          Equals(object obj) cil managed
  {
    // Code size       52 (0x34)
    .maxstack  2
    .locals init (class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey V_0)
    IL_0000:  ldarg.1
    IL_0001:  isinst     AspenTech.EquipmentAnalysis.Infrastructure.PsvKey
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  ldnull
    IL_0009:  call       bool AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::op_Equality(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,
                                                                                             class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_000e:  brfalse.s  IL_0012

    IL_0010:  ldc.i4.0
    IL_0011:  ret

    IL_0012:  ldloc.0
    IL_0013:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_recordType
    IL_0018:  ldarg.0
    IL_0019:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_recordType
    IL_001e:  beq.s      IL_0022

    IL_0020:  ldc.i4.0
    IL_0021:  ret

    IL_0022:  ldloc.0
    IL_0023:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_value
    IL_0028:  ldarg.0
    IL_0029:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_value
    IL_002e:  beq.s      IL_0032

    IL_0030:  ldc.i4.0
    IL_0031:  ret

    IL_0032:  ldc.i4.1
    IL_0033:  ret
  } // end of method PsvKey::Equals

  .method public hidebysig specialname static 
          bool  op_Equality(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey lhs,
                            class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey rhs) cil managed
  {
    // Code size       16 (0x10)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  brtrue.s   IL_0008

    IL_0003:  ldarg.0
    IL_0004:  ldarg.1
    IL_0005:  ceq
    IL_0007:  ret

    IL_0008:  ldarg.0
    IL_0009:  ldarg.1
    IL_000a:  callvirt   instance bool [mscorlib]System.Object::Equals(object)
    IL_000f:  ret
  } // end of method PsvKey::op_Equality

  .method public hidebysig specialname static 
          bool  op_Inequality(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey lhs,
                              class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey rhs) cil managed
  {
    // Code size       11 (0xb)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       bool AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::op_Equality(class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey,
                                                                                             class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey)
    IL_0007:  ldc.i4.0
    IL_0008:  ceq
    IL_000a:  ret
  } // end of method PsvKey::op_Inequality

  .method public hidebysig virtual instance int32 
          GetHashCode() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldflda     valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_recordType
    IL_0006:  constrained. AspenTech.EquipmentAnalysis.Infrastructure.eRecordType
    IL_000c:  callvirt   instance int32 [mscorlib]System.Object::GetHashCode()
    IL_0011:  ldarg.0
    IL_0012:  ldflda     int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_value
    IL_0017:  call       instance int32 [mscorlib]System.Int32::GetHashCode()
    IL_001c:  xor
    IL_001d:  ret
  } // end of method PsvKey::GetHashCode

  .method public hidebysig instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 
          AsPsvModelKey() cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  isinst     AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
    IL_0006:  brfalse.s  IL_000f

    IL_0008:  ldarg.0
    IL_0009:  isinst     AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
    IL_000e:  ret

    IL_000f:  ldarg.0
    IL_0010:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_recordType
    IL_0015:  ldarg.0
    IL_0016:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::_value
    IL_001b:  newobj     instance void AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey::.ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType,
                                                                                                     int32)
    IL_0020:  ret
  } // end of method PsvKey::AsPsvModelKey

  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType
          RecordType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.eRecordType AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_RecordType()
  } // end of property PsvKey::RecordType
  .property instance callconv(8) int32 Value()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.PsvKey::get_Value()
  } // end of property PsvKey::Value
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PsvKey

.class public abstract auto ansi sealed beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenFactoryKeys
       extends [mscorlib]System.Object
{
  .field public static literal string MainScreenKey = "Main"
  .field public static literal string PsvMessageScreenKey = "PsvMessageScreen"
  .field public static literal string ValveScreenKey = "Valve"
  .field public static literal string DBScreenKey = "Database"
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenFactoryKeys

.class public abstract auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase
       extends [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject
{
  .field private class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey '<ModelKey>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 
          get_ModelKey() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase::'<ModelKey>k__BackingField'
    IL_0006:  ret
  } // end of method PSVScreenSubjectBase::get_ModelKey

  .method public hidebysig specialname instance void 
          set_ModelKey(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase::'<ModelKey>k__BackingField'
    IL_0007:  ret
  } // end of method PSVScreenSubjectBase::set_ModelKey

  .method family hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject::.ctor()
    IL_0006:  ret
  } // end of method PSVScreenSubjectBase::.ctor

  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
          ModelKey()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase::get_ModelKey()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase::set_ModelKey(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey)
  } // end of property PSVScreenSubjectBase::ModelKey
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.PSVScreenSubjectBase

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method AddValveNodeEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode '<AttachedTarget>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<NodeDataPath>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<ReferenceStream>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<ReferenceUo>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private int32 '<PSVKey>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode 
          get_AttachedTarget() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::'<AttachedTarget>k__BackingField'
    IL_0006:  ret
  } // end of method AddValveNodeEventArgs::get_AttachedTarget

  .method public hidebysig specialname instance void 
          set_AttachedTarget(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::'<AttachedTarget>k__BackingField'
    IL_0007:  ret
  } // end of method AddValveNodeEventArgs::set_AttachedTarget

  .method public hidebysig specialname instance string 
          get_NodeDataPath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::'<NodeDataPath>k__BackingField'
    IL_0006:  ret
  } // end of method AddValveNodeEventArgs::get_NodeDataPath

  .method public hidebysig specialname instance void 
          set_NodeDataPath(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::'<NodeDataPath>k__BackingField'
    IL_0007:  ret
  } // end of method AddValveNodeEventArgs::set_NodeDataPath

  .method public hidebysig specialname instance string 
          get_ReferenceStream() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::'<ReferenceStream>k__BackingField'
    IL_0006:  ret
  } // end of method AddValveNodeEventArgs::get_ReferenceStream

  .method public hidebysig specialname instance void 
          set_ReferenceStream(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::'<ReferenceStream>k__BackingField'
    IL_0007:  ret
  } // end of method AddValveNodeEventArgs::set_ReferenceStream

  .method public hidebysig specialname instance string 
          get_ReferenceUo() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::'<ReferenceUo>k__BackingField'
    IL_0006:  ret
  } // end of method AddValveNodeEventArgs::get_ReferenceUo

  .method public hidebysig specialname instance void 
          set_ReferenceUo(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::'<ReferenceUo>k__BackingField'
    IL_0007:  ret
  } // end of method AddValveNodeEventArgs::set_ReferenceUo

  .method public hidebysig specialname instance int32 
          get_PSVKey() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::'<PSVKey>k__BackingField'
    IL_0006:  ret
  } // end of method AddValveNodeEventArgs::get_PSVKey

  .method public hidebysig specialname instance void 
          set_PSVKey(int32 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::'<PSVKey>k__BackingField'
    IL_0007:  ret
  } // end of method AddValveNodeEventArgs::set_PSVKey

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method AddValveNodeEventArgs::.ctor

  .property instance callconv(8) class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode
          AttachedTarget()
  {
    .get instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::get_AttachedTarget()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::set_AttachedTarget(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode)
  } // end of property AddValveNodeEventArgs::AttachedTarget
  .property instance callconv(8) string NodeDataPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::get_NodeDataPath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::set_NodeDataPath(string)
  } // end of property AddValveNodeEventArgs::NodeDataPath
  .property instance callconv(8) string ReferenceStream()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::get_ReferenceStream()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::set_ReferenceStream(string)
  } // end of property AddValveNodeEventArgs::ReferenceStream
  .property instance callconv(8) string ReferenceUo()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::get_ReferenceUo()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::set_ReferenceUo(string)
  } // end of property AddValveNodeEventArgs::ReferenceUo
  .property instance callconv(8) int32 PSVKey()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::get_PSVKey()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs::set_PSVKey(int32)
  } // end of property AddValveNodeEventArgs::PSVKey
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.AddValveNodeEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode '<AttachedTarget>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<NodeDataPath>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private int32 '<PSVkey>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private int32 '<RowNumber>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class [PSVSizingEngine]PSVSizingEngine.IPPPFluid '<FluidPackage>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod '<SizingMethod>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode 
          get_AttachedTarget() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<AttachedTarget>k__BackingField'
    IL_0006:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::get_AttachedTarget

  .method public hidebysig specialname instance void 
          set_AttachedTarget(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<AttachedTarget>k__BackingField'
    IL_0007:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::set_AttachedTarget

  .method public hidebysig specialname instance string 
          get_NodeDataPath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<NodeDataPath>k__BackingField'
    IL_0006:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::get_NodeDataPath

  .method public hidebysig specialname instance void 
          set_NodeDataPath(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<NodeDataPath>k__BackingField'
    IL_0007:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::set_NodeDataPath

  .method public hidebysig specialname instance int32 
          get_PSVkey() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<PSVkey>k__BackingField'
    IL_0006:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::get_PSVkey

  .method public hidebysig specialname instance void 
          set_PSVkey(int32 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<PSVkey>k__BackingField'
    IL_0007:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::set_PSVkey

  .method public hidebysig specialname instance int32 
          get_RowNumber() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<RowNumber>k__BackingField'
    IL_0006:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::get_RowNumber

  .method public hidebysig specialname instance void 
          set_RowNumber(int32 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<RowNumber>k__BackingField'
    IL_0007:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::set_RowNumber

  .method public hidebysig specialname instance class [PSVSizingEngine]PSVSizingEngine.IPPPFluid 
          get_FluidPackage() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [PSVSizingEngine]PSVSizingEngine.IPPPFluid AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<FluidPackage>k__BackingField'
    IL_0006:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::get_FluidPackage

  .method public hidebysig specialname instance void 
          set_FluidPackage(class [PSVSizingEngine]PSVSizingEngine.IPPPFluid 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [PSVSizingEngine]PSVSizingEngine.IPPPFluid AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<FluidPackage>k__BackingField'
    IL_0007:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::set_FluidPackage

  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod 
          get_SizingMethod() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<SizingMethod>k__BackingField'
    IL_0006:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::get_SizingMethod

  .method public hidebysig specialname instance void 
          set_SizingMethod(valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::'<SizingMethod>k__BackingField'
    IL_0007:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::set_SizingMethod

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method AddEmergencyScenarioNodeEventArgs::.ctor

  .property instance callconv(8) class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode
          AttachedTarget()
  {
    .get instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::get_AttachedTarget()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::set_AttachedTarget(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode)
  } // end of property AddEmergencyScenarioNodeEventArgs::AttachedTarget
  .property instance callconv(8) string NodeDataPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::get_NodeDataPath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::set_NodeDataPath(string)
  } // end of property AddEmergencyScenarioNodeEventArgs::NodeDataPath
  .property instance callconv(8) int32 PSVkey()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::get_PSVkey()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::set_PSVkey(int32)
  } // end of property AddEmergencyScenarioNodeEventArgs::PSVkey
  .property instance callconv(8) int32 RowNumber()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::get_RowNumber()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::set_RowNumber(int32)
  } // end of property AddEmergencyScenarioNodeEventArgs::RowNumber
  .property instance callconv(8) class [PSVSizingEngine]PSVSizingEngine.IPPPFluid
          FluidPackage()
  {
    .get instance class [PSVSizingEngine]PSVSizingEngine.IPPPFluid AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::get_FluidPackage()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::set_FluidPackage(class [PSVSizingEngine]PSVSizingEngine.IPPPFluid)
  } // end of property AddEmergencyScenarioNodeEventArgs::FluidPackage
  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod
          SizingMethod()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::get_SizingMethod()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs::set_SizingMethod(valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod)
  } // end of property AddEmergencyScenarioNodeEventArgs::SizingMethod
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method AddEmergencyScenarioNodeEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.AddEmergencyScenarioNodeEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private string '<ScenarioName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<ValveName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey '<Key>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<PSVNodeKey>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance string 
          get_ScenarioName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::'<ScenarioName>k__BackingField'
    IL_0006:  ret
  } // end of method ViewEmergencyScenarioNodeEventArgs::get_ScenarioName

  .method public hidebysig specialname instance void 
          set_ScenarioName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::'<ScenarioName>k__BackingField'
    IL_0007:  ret
  } // end of method ViewEmergencyScenarioNodeEventArgs::set_ScenarioName

  .method public hidebysig specialname instance string 
          get_ValveName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::'<ValveName>k__BackingField'
    IL_0006:  ret
  } // end of method ViewEmergencyScenarioNodeEventArgs::get_ValveName

  .method public hidebysig specialname instance void 
          set_ValveName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::'<ValveName>k__BackingField'
    IL_0007:  ret
  } // end of method ViewEmergencyScenarioNodeEventArgs::set_ValveName

  .method public hidebysig specialname instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 
          get_Key() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::'<Key>k__BackingField'
    IL_0006:  ret
  } // end of method ViewEmergencyScenarioNodeEventArgs::get_Key

  .method public hidebysig specialname instance void 
          set_Key(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::'<Key>k__BackingField'
    IL_0007:  ret
  } // end of method ViewEmergencyScenarioNodeEventArgs::set_Key

  .method public hidebysig specialname instance string 
          get_PSVNodeKey() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::'<PSVNodeKey>k__BackingField'
    IL_0006:  ret
  } // end of method ViewEmergencyScenarioNodeEventArgs::get_PSVNodeKey

  .method public hidebysig specialname instance void 
          set_PSVNodeKey(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::'<PSVNodeKey>k__BackingField'
    IL_0007:  ret
  } // end of method ViewEmergencyScenarioNodeEventArgs::set_PSVNodeKey

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method ViewEmergencyScenarioNodeEventArgs::.ctor

  .property instance callconv(8) string ScenarioName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::get_ScenarioName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::set_ScenarioName(string)
  } // end of property ViewEmergencyScenarioNodeEventArgs::ScenarioName
  .property instance callconv(8) string ValveName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::get_ValveName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::set_ValveName(string)
  } // end of property ViewEmergencyScenarioNodeEventArgs::ValveName
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
          Key()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::get_Key()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::set_Key(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey)
  } // end of property ViewEmergencyScenarioNodeEventArgs::Key
  .property instance callconv(8) string PSVNodeKey()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::get_PSVNodeKey()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs::set_PSVNodeKey(string)
  } // end of property ViewEmergencyScenarioNodeEventArgs::PSVNodeKey
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method ViewEmergencyScenarioNodeEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewEmergencyScenarioNodeEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode '<Node>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode 
          get_Node() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEventArgs::'<Node>k__BackingField'
    IL_0006:  ret
  } // end of method DeleteValveNodeEventArgs::get_Node

  .method public hidebysig specialname instance void 
          set_Node(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEventArgs::'<Node>k__BackingField'
    IL_0007:  ret
  } // end of method DeleteValveNodeEventArgs::set_Node

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method DeleteValveNodeEventArgs::.ctor

  .property instance callconv(8) class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode
          Node()
  {
    .get instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEventArgs::get_Node()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEventArgs::set_Node(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode)
  } // end of property DeleteValveNodeEventArgs::Node
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method DeleteValveNodeEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteValveNodeEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private string '<PSVName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<NodeKey>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<OriginalSource>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance string 
          get_PSVName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::'<PSVName>k__BackingField'
    IL_0006:  ret
  } // end of method PasteNodeEventArgs::get_PSVName

  .method public hidebysig specialname instance void 
          set_PSVName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::'<PSVName>k__BackingField'
    IL_0007:  ret
  } // end of method PasteNodeEventArgs::set_PSVName

  .method public hidebysig specialname instance string 
          get_NodeKey() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::'<NodeKey>k__BackingField'
    IL_0006:  ret
  } // end of method PasteNodeEventArgs::get_NodeKey

  .method public hidebysig specialname instance void 
          set_NodeKey(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::'<NodeKey>k__BackingField'
    IL_0007:  ret
  } // end of method PasteNodeEventArgs::set_NodeKey

  .method public hidebysig specialname instance string 
          get_OriginalSource() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::'<OriginalSource>k__BackingField'
    IL_0006:  ret
  } // end of method PasteNodeEventArgs::get_OriginalSource

  .method public hidebysig specialname instance void 
          set_OriginalSource(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::'<OriginalSource>k__BackingField'
    IL_0007:  ret
  } // end of method PasteNodeEventArgs::set_OriginalSource

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method PasteNodeEventArgs::.ctor

  .property instance callconv(8) string PSVName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::get_PSVName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::set_PSVName(string)
  } // end of property PasteNodeEventArgs::PSVName
  .property instance callconv(8) string NodeKey()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::get_NodeKey()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::set_NodeKey(string)
  } // end of property PasteNodeEventArgs::NodeKey
  .property instance callconv(8) string OriginalSource()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::get_OriginalSource()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs::set_OriginalSource(string)
  } // end of property PasteNodeEventArgs::OriginalSource
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method PasteNodeEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PasteNodeEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode '<Node>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode 
          get_Node() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioEventArgs::'<Node>k__BackingField'
    IL_0006:  ret
  } // end of method DeleteScenarioEventArgs::get_Node

  .method public hidebysig specialname instance void 
          set_Node(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioEventArgs::'<Node>k__BackingField'
    IL_0007:  ret
  } // end of method DeleteScenarioEventArgs::set_Node

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method DeleteScenarioEventArgs::.ctor

  .property instance callconv(8) class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode
          Node()
  {
    .get instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioEventArgs::get_Node()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioEventArgs::set_Node(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.SimpleNavigatorTreeNode)
  } // end of property DeleteScenarioEventArgs::Node
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioNodeEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method DeleteScenarioNodeEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.DeleteScenarioNodeEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl '<Screen>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl 
          get_Screen() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEventArgs::'<Screen>k__BackingField'
    IL_0006:  ret
  } // end of method SafetyScreenCreatedEventArgs::get_Screen

  .method public hidebysig specialname instance void 
          set_Screen(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEventArgs::'<Screen>k__BackingField'
    IL_0007:  ret
  } // end of method SafetyScreenCreatedEventArgs::set_Screen

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl screen) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEventArgs::set_Screen(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl)
    IL_000d:  ret
  } // end of method SafetyScreenCreatedEventArgs::.ctor

  .property instance callconv(8) class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl
          Screen()
  {
    .get instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEventArgs::get_Screen()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEventArgs::set_Screen(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenContentControl)
  } // end of property SafetyScreenCreatedEventArgs::Screen
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method SafetyScreenCreatedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SafetyScreenCreatedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly class [mscorlib]System.Collections.Generic.IEnumerable`1<object> '<ObjectRecords>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly object '<OwnerSystemRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance class [mscorlib]System.Collections.Generic.IEnumerable`1<object> 
          get_ObjectRecords() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.IEnumerable`1<object> AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs::'<ObjectRecords>k__BackingField'
    IL_0006:  ret
  } // end of method ActiveSafetyObjectChangedEventArgs::get_ObjectRecords

  .method public hidebysig specialname instance object 
          get_OwnerSystemRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs::'<OwnerSystemRecord>k__BackingField'
    IL_0006:  ret
  } // end of method ActiveSafetyObjectChangedEventArgs::get_OwnerSystemRecord

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class [mscorlib]System.Collections.Generic.IEnumerable`1<object> objectRecords,
                               object ownerSystemRecord) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class [mscorlib]System.Collections.Generic.IEnumerable`1<object> AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs::'<ObjectRecords>k__BackingField'
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs::'<OwnerSystemRecord>k__BackingField'
    IL_0014:  ret
  } // end of method ActiveSafetyObjectChangedEventArgs::.ctor

  .property instance callconv(8) class [mscorlib]System.Collections.Generic.IEnumerable`1<object>
          ObjectRecords()
  {
    .get instance class [mscorlib]System.Collections.Generic.IEnumerable`1<object> AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs::get_ObjectRecords()
  } // end of property ActiveSafetyObjectChangedEventArgs::ObjectRecords
  .property instance callconv(8) object OwnerSystemRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs::get_OwnerSystemRecord()
  } // end of property ActiveSafetyObjectChangedEventArgs::OwnerSystemRecord
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method ActiveSafetyObjectChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyObjectChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveScreenChangedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ActiveScreenChangedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ActiveScreenChangedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method ActiveScreenChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveScreenChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop '<AdbTop>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop 
          get_AdbTop() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs::'<AdbTop>k__BackingField'
    IL_0006:  ret
  } // end of method EnterSafetyEnvironmentEventArgs::get_AdbTop

  .method public hidebysig specialname instance void 
          set_AdbTop(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs::'<AdbTop>k__BackingField'
    IL_0007:  ret
  } // end of method EnterSafetyEnvironmentEventArgs::set_AdbTop

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop adbTop) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs::set_AdbTop(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
    IL_000d:  ret
  } // end of method EnterSafetyEnvironmentEventArgs::.ctor

  .property instance callconv(8) class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop
          AdbTop()
  {
    .get instance class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs::get_AdbTop()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs::set_AdbTop(class [AdbComInterfaces]AspenTech.Adb.Interfaces.IAdbTop)
  } // end of property EnterSafetyEnvironmentEventArgs::AdbTop
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method EnterSafetyEnvironmentEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyCaseChangedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.EnterSafetyEnvironmentEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method ActiveSafetyCaseChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ActiveSafetyCaseChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ExitSafetyEnvironmentEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::.ctor()
    IL_0006:  ret
  } // end of method ExitSafetyEnvironmentEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ExitSafetyEnvironmentEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.CloseCaseEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::.ctor()
    IL_0006:  ret
  } // end of method CloseCaseEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.CloseCaseEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.HostDeactivatedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class [mscorlib]System.EventArgs>::.ctor()
    IL_0006:  ret
  } // end of method HostDeactivatedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.HostDeactivatedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVDesignCodeChangedEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.3
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method PSVDesignCodeChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVDesignCodeChangedEvent

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType TypeError = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType RangeError = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType OtherError = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType '<ErrorType>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class [mscorlib]System.Type '<ValueType>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private object '<InvalidValue>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<PropertyName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType 
          get_ErrorType() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::'<ErrorType>k__BackingField'
    IL_0006:  ret
  } // end of method InvalidValueEnteredEventArgs::get_ErrorType

  .method private hidebysig specialname instance void 
          set_ErrorType(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::'<ErrorType>k__BackingField'
    IL_0007:  ret
  } // end of method InvalidValueEnteredEventArgs::set_ErrorType

  .method public hidebysig specialname instance class [mscorlib]System.Type 
          get_ValueType() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Type AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::'<ValueType>k__BackingField'
    IL_0006:  ret
  } // end of method InvalidValueEnteredEventArgs::get_ValueType

  .method private hidebysig specialname instance void 
          set_ValueType(class [mscorlib]System.Type 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [mscorlib]System.Type AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::'<ValueType>k__BackingField'
    IL_0007:  ret
  } // end of method InvalidValueEnteredEventArgs::set_ValueType

  .method public hidebysig specialname instance object 
          get_InvalidValue() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::'<InvalidValue>k__BackingField'
    IL_0006:  ret
  } // end of method InvalidValueEnteredEventArgs::get_InvalidValue

  .method private hidebysig specialname instance void 
          set_InvalidValue(object 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::'<InvalidValue>k__BackingField'
    IL_0007:  ret
  } // end of method InvalidValueEnteredEventArgs::set_InvalidValue

  .method public hidebysig specialname instance string 
          get_PropertyName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::'<PropertyName>k__BackingField'
    IL_0006:  ret
  } // end of method InvalidValueEnteredEventArgs::get_PropertyName

  .method private hidebysig specialname instance void 
          set_PropertyName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::'<PropertyName>k__BackingField'
    IL_0007:  ret
  } // end of method InvalidValueEnteredEventArgs::set_PropertyName

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType errorType,
                               [opt] class [mscorlib]System.Type valueType,
                               [opt] object invalidValue,
                               [opt] string propertyName) cil managed
  {
    .param [2] = nullref
    .param [3] = nullref
    .param [4] = nullref
    // Code size       36 (0x24)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::set_ErrorType(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType)
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::set_ValueType(class [mscorlib]System.Type)
    IL_0014:  ldarg.0
    IL_0015:  ldarg.3
    IL_0016:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::set_InvalidValue(object)
    IL_001b:  ldarg.0
    IL_001c:  ldarg.s    propertyName
    IL_001e:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::set_PropertyName(string)
    IL_0023:  ret
  } // end of method InvalidValueEnteredEventArgs::.ctor

  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType
          ErrorType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::get_ErrorType()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::set_ErrorType(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueErrorType)
  } // end of property InvalidValueEnteredEventArgs::ErrorType
  .property instance callconv(8) class [mscorlib]System.Type
          ValueType()
  {
    .get instance class [mscorlib]System.Type AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::get_ValueType()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::set_ValueType(class [mscorlib]System.Type)
  } // end of property InvalidValueEnteredEventArgs::ValueType
  .property instance callconv(8) object InvalidValue()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::get_InvalidValue()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::set_InvalidValue(object)
  } // end of property InvalidValueEnteredEventArgs::InvalidValue
  .property instance callconv(8) string PropertyName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::get_PropertyName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs::set_PropertyName(string)
  } // end of property InvalidValueEnteredEventArgs::PropertyName
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.InvalidValueEnteredEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method LineSizingSettingsChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private object '<Para1>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_Para1() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEventArgs::'<Para1>k__BackingField'
    IL_0006:  ret
  } // end of method LineSizingSettingsChangedEventArgs::get_Para1

  .method public hidebysig specialname instance void 
          set_Para1(object 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEventArgs::'<Para1>k__BackingField'
    IL_0007:  ret
  } // end of method LineSizingSettingsChangedEventArgs::set_Para1

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method LineSizingSettingsChangedEventArgs::.ctor

  .property instance callconv(8) object Para1()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEventArgs::get_Para1()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEventArgs::set_Para1(object)
  } // end of property LineSizingSettingsChangedEventArgs::Para1
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.LineSizingSettingsChangedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseStatusChangedEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::.ctor()
    IL_0006:  ret
  } // end of method SizingCaseStatusChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseStatusChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.DefaultWarningSeetingChangedEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::.ctor()
    IL_0006:  ret
  } // end of method DefaultWarningSeetingChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.DefaultWarningSeetingChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method PRDTypeChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType '<OldPRDType>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType '<NewPRDType>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType oldPRDType,
                               valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType newPRDType) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs::'<OldPRDType>k__BackingField'
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs::'<NewPRDType>k__BackingField'
    IL_0014:  ret
  } // end of method PRDTypeChangedEventArgs::.ctor

  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType 
          get_OldPRDType() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs::'<OldPRDType>k__BackingField'
    IL_0006:  ret
  } // end of method PRDTypeChangedEventArgs::get_OldPRDType

  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType 
          get_NewPRDType() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs::'<NewPRDType>k__BackingField'
    IL_0006:  ret
  } // end of method PRDTypeChangedEventArgs::get_NewPRDType

  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType
          OldPRDType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs::get_OldPRDType()
  } // end of property PRDTypeChangedEventArgs::OldPRDType
  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType
          NewPRDType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs::get_NewPRDType()
  } // end of property PRDTypeChangedEventArgs::NewPRDType
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.4
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method NavigateToFormTabEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private string '<PSVPath>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<ToTabName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<PRDName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey '<Key>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance string 
          get_PSVPath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::'<PSVPath>k__BackingField'
    IL_0006:  ret
  } // end of method NavigateToFormTabEventArgs::get_PSVPath

  .method public hidebysig specialname instance void 
          set_PSVPath(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::'<PSVPath>k__BackingField'
    IL_0007:  ret
  } // end of method NavigateToFormTabEventArgs::set_PSVPath

  .method public hidebysig specialname instance string 
          get_ToTabName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::'<ToTabName>k__BackingField'
    IL_0006:  ret
  } // end of method NavigateToFormTabEventArgs::get_ToTabName

  .method public hidebysig specialname instance void 
          set_ToTabName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::'<ToTabName>k__BackingField'
    IL_0007:  ret
  } // end of method NavigateToFormTabEventArgs::set_ToTabName

  .method public hidebysig specialname instance string 
          get_PRDName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::'<PRDName>k__BackingField'
    IL_0006:  ret
  } // end of method NavigateToFormTabEventArgs::get_PRDName

  .method public hidebysig specialname instance void 
          set_PRDName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::'<PRDName>k__BackingField'
    IL_0007:  ret
  } // end of method NavigateToFormTabEventArgs::set_PRDName

  .method public hidebysig specialname instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 
          get_Key() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::'<Key>k__BackingField'
    IL_0006:  ret
  } // end of method NavigateToFormTabEventArgs::get_Key

  .method public hidebysig specialname instance void 
          set_Key(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::'<Key>k__BackingField'
    IL_0007:  ret
  } // end of method NavigateToFormTabEventArgs::set_Key

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method NavigateToFormTabEventArgs::.ctor

  .property instance callconv(8) string PSVPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::get_PSVPath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::set_PSVPath(string)
  } // end of property NavigateToFormTabEventArgs::PSVPath
  .property instance callconv(8) string ToTabName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::get_ToTabName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::set_ToTabName(string)
  } // end of property NavigateToFormTabEventArgs::ToTabName
  .property instance callconv(8) string PRDName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::get_PRDName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::set_PRDName(string)
  } // end of property NavigateToFormTabEventArgs::PRDName
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
          Key()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::get_Key()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs::set_Key(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey)
  } // end of property NavigateToFormTabEventArgs::Key
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.NavigateToFormTabEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PropertyEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private string '<PropertyName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string name) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  call       instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.PropertyEventArgs::set_PropertyName(string)
    IL_000d:  ret
  } // end of method PropertyEventArgs::.ctor

  .method public hidebysig specialname instance string 
          get_PropertyName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PropertyEventArgs::'<PropertyName>k__BackingField'
    IL_0006:  ret
  } // end of method PropertyEventArgs::get_PropertyName

  .method public hidebysig specialname instance void 
          set_PropertyName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PropertyEventArgs::'<PropertyName>k__BackingField'
    IL_0007:  ret
  } // end of method PropertyEventArgs::set_PropertyName

  .property instance callconv(8) string PropertyName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.PropertyEventArgs::get_PropertyName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.PropertyEventArgs::set_PropertyName(string)
  } // end of property PropertyEventArgs::PropertyName
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PropertyEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventEx
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx>::.ctor()
    IL_0006:  ret
  } // end of method PRDTypeChangedEventEx::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventEx

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx
       extends [mscorlib]System.EventArgs
{
  .field private initonly string '<PRDPath>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType '<NewPRDType>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string fullPRDPath,
                               valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType newPRDType) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx::'<PRDPath>k__BackingField'
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx::'<NewPRDType>k__BackingField'
    IL_0014:  ret
  } // end of method PRDTypeChangedEventArgsEx::.ctor

  .method public hidebysig specialname instance string 
          get_PRDPath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx::'<PRDPath>k__BackingField'
    IL_0006:  ret
  } // end of method PRDTypeChangedEventArgsEx::get_PRDPath

  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType 
          get_NewPRDType() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx::'<NewPRDType>k__BackingField'
    IL_0006:  ret
  } // end of method PRDTypeChangedEventArgsEx::get_NewPRDType

  .property instance callconv(8) string PRDPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx::get_PRDPath()
  } // end of property PRDTypeChangedEventArgsEx::PRDPath
  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType
          NewPRDType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx::get_NewPRDType()
  } // end of property PRDTypeChangedEventArgsEx::NewPRDType
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PRDTypeChangedEventArgsEx

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method PSVOwnerStreamChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private string '<NewCxsPath>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey '<PSVKey>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<OldCxsPath>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance string 
          get_NewCxsPath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::'<NewCxsPath>k__BackingField'
    IL_0006:  ret
  } // end of method PSVOwnerStreamChangedEventArgs::get_NewCxsPath

  .method public hidebysig specialname instance void 
          set_NewCxsPath(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::'<NewCxsPath>k__BackingField'
    IL_0007:  ret
  } // end of method PSVOwnerStreamChangedEventArgs::set_NewCxsPath

  .method public hidebysig specialname instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 
          get_PSVKey() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::'<PSVKey>k__BackingField'
    IL_0006:  ret
  } // end of method PSVOwnerStreamChangedEventArgs::get_PSVKey

  .method public hidebysig specialname instance void 
          set_PSVKey(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::'<PSVKey>k__BackingField'
    IL_0007:  ret
  } // end of method PSVOwnerStreamChangedEventArgs::set_PSVKey

  .method public hidebysig specialname instance string 
          get_OldCxsPath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::'<OldCxsPath>k__BackingField'
    IL_0006:  ret
  } // end of method PSVOwnerStreamChangedEventArgs::get_OldCxsPath

  .method public hidebysig specialname instance void 
          set_OldCxsPath(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::'<OldCxsPath>k__BackingField'
    IL_0007:  ret
  } // end of method PSVOwnerStreamChangedEventArgs::set_OldCxsPath

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method PSVOwnerStreamChangedEventArgs::.ctor

  .property instance callconv(8) string NewCxsPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::get_NewCxsPath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::set_NewCxsPath(string)
  } // end of property PSVOwnerStreamChangedEventArgs::NewCxsPath
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
          PSVKey()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::get_PSVKey()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::set_PSVKey(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey)
  } // end of property PSVOwnerStreamChangedEventArgs::PSVKey
  .property instance callconv(8) string OldCxsPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::get_OldCxsPath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs::set_OldCxsPath(string)
  } // end of property PSVOwnerStreamChangedEventArgs::OldCxsPath
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVOwnerStreamChangedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVShowHelpEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVHelpEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVHelpEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method PSVShowHelpEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVShowHelpEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVHelpEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private int32 '<TopicID>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance int32 
          get_TopicID() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVHelpEventArgs::'<TopicID>k__BackingField'
    IL_0006:  ret
  } // end of method PSVHelpEventArgs::get_TopicID

  .method public hidebysig specialname instance void 
          set_TopicID(int32 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVHelpEventArgs::'<TopicID>k__BackingField'
    IL_0007:  ret
  } // end of method PSVHelpEventArgs::set_TopicID

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method PSVHelpEventArgs::.ctor

  .property instance callconv(8) int32 TopicID()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVHelpEventArgs::get_TopicID()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVHelpEventArgs::set_TopicID(int32)
  } // end of property PSVHelpEventArgs::TopicID
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVHelpEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVUnitSetChangedEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.3
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method PSVUnitSetChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.PSVUnitSetChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method RenameEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private string '<OldName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<NewName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<ObjectType>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<Path>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey '<Key>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private bool '<Handled>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private int32 '<HashCode>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey> '<Scenarios>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance string 
          get_OldName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<OldName>k__BackingField'
    IL_0006:  ret
  } // end of method RenameEventArgs::get_OldName

  .method public hidebysig specialname instance void 
          set_OldName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<OldName>k__BackingField'
    IL_0007:  ret
  } // end of method RenameEventArgs::set_OldName

  .method public hidebysig specialname instance string 
          get_NewName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<NewName>k__BackingField'
    IL_0006:  ret
  } // end of method RenameEventArgs::get_NewName

  .method public hidebysig specialname instance void 
          set_NewName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<NewName>k__BackingField'
    IL_0007:  ret
  } // end of method RenameEventArgs::set_NewName

  .method public hidebysig specialname instance string 
          get_ObjectType() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<ObjectType>k__BackingField'
    IL_0006:  ret
  } // end of method RenameEventArgs::get_ObjectType

  .method public hidebysig specialname instance void 
          set_ObjectType(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<ObjectType>k__BackingField'
    IL_0007:  ret
  } // end of method RenameEventArgs::set_ObjectType

  .method public hidebysig specialname instance string 
          get_Path() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<Path>k__BackingField'
    IL_0006:  ret
  } // end of method RenameEventArgs::get_Path

  .method public hidebysig specialname instance void 
          set_Path(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<Path>k__BackingField'
    IL_0007:  ret
  } // end of method RenameEventArgs::set_Path

  .method public hidebysig specialname instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 
          get_Key() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<Key>k__BackingField'
    IL_0006:  ret
  } // end of method RenameEventArgs::get_Key

  .method public hidebysig specialname instance void 
          set_Key(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<Key>k__BackingField'
    IL_0007:  ret
  } // end of method RenameEventArgs::set_Key

  .method public hidebysig specialname instance bool 
          get_Handled() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<Handled>k__BackingField'
    IL_0006:  ret
  } // end of method RenameEventArgs::get_Handled

  .method public hidebysig specialname instance void 
          set_Handled(bool 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<Handled>k__BackingField'
    IL_0007:  ret
  } // end of method RenameEventArgs::set_Handled

  .method public hidebysig specialname instance int32 
          get_HashCode() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<HashCode>k__BackingField'
    IL_0006:  ret
  } // end of method RenameEventArgs::get_HashCode

  .method public hidebysig specialname instance void 
          set_HashCode(int32 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<HashCode>k__BackingField'
    IL_0007:  ret
  } // end of method RenameEventArgs::set_HashCode

  .method public hidebysig specialname instance class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey> 
          get_Scenarios() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey> AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<Scenarios>k__BackingField'
    IL_0006:  ret
  } // end of method RenameEventArgs::get_Scenarios

  .method public hidebysig specialname instance void 
          set_Scenarios(class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey> 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey> AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::'<Scenarios>k__BackingField'
    IL_0007:  ret
  } // end of method RenameEventArgs::set_Scenarios

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method RenameEventArgs::.ctor

  .property instance callconv(8) string OldName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::get_OldName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::set_OldName(string)
  } // end of property RenameEventArgs::OldName
  .property instance callconv(8) string NewName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::get_NewName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::set_NewName(string)
  } // end of property RenameEventArgs::NewName
  .property instance callconv(8) string ObjectType()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::get_ObjectType()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::set_ObjectType(string)
  } // end of property RenameEventArgs::ObjectType
  .property instance callconv(8) string Path()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::get_Path()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::set_Path(string)
  } // end of property RenameEventArgs::Path
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
          Key()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::get_Key()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::set_Key(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey)
  } // end of property RenameEventArgs::Key
  .property instance callconv(8) bool Handled()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::get_Handled()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::set_Handled(bool)
  } // end of property RenameEventArgs::Handled
  .property instance callconv(8) int32 HashCode()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::get_HashCode()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::set_HashCode(int32)
  } // end of property RenameEventArgs::HashCode
  .property instance callconv(8) class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey>
          Scenarios()
  {
    .get instance class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey> AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::get_Scenarios()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs::set_Scenarios(class [mscorlib]System.Collections.Generic.List`1<class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey>)
  } // end of property RenameEventArgs::Scenarios
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.RenameEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method SizingMethodChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private bool '<IsKrMethod>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private object '<ScenarioViewModel>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<RDName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance bool 
          get_IsKrMethod() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::'<IsKrMethod>k__BackingField'
    IL_0006:  ret
  } // end of method SizingMethodChangedEventArgs::get_IsKrMethod

  .method public hidebysig specialname instance void 
          set_IsKrMethod(bool 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::'<IsKrMethod>k__BackingField'
    IL_0007:  ret
  } // end of method SizingMethodChangedEventArgs::set_IsKrMethod

  .method public hidebysig specialname instance object 
          get_ScenarioViewModel() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::'<ScenarioViewModel>k__BackingField'
    IL_0006:  ret
  } // end of method SizingMethodChangedEventArgs::get_ScenarioViewModel

  .method public hidebysig specialname instance void 
          set_ScenarioViewModel(object 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::'<ScenarioViewModel>k__BackingField'
    IL_0007:  ret
  } // end of method SizingMethodChangedEventArgs::set_ScenarioViewModel

  .method public hidebysig specialname instance string 
          get_RDName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::'<RDName>k__BackingField'
    IL_0006:  ret
  } // end of method SizingMethodChangedEventArgs::get_RDName

  .method public hidebysig specialname instance void 
          set_RDName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::'<RDName>k__BackingField'
    IL_0007:  ret
  } // end of method SizingMethodChangedEventArgs::set_RDName

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method SizingMethodChangedEventArgs::.ctor

  .property instance callconv(8) bool IsKrMethod()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::get_IsKrMethod()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::set_IsKrMethod(bool)
  } // end of property SizingMethodChangedEventArgs::IsKrMethod
  .property instance callconv(8) object ScenarioViewModel()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::get_ScenarioViewModel()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::set_ScenarioViewModel(object)
  } // end of property SizingMethodChangedEventArgs::ScenarioViewModel
  .property instance callconv(8) string RDName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::get_RDName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs::set_RDName(string)
  } // end of property SizingMethodChangedEventArgs::RDName
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingMethodChangedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method SizingCaseChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private object '<ScenarioViewModel>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<RDName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_ScenarioViewModel() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs::'<ScenarioViewModel>k__BackingField'
    IL_0006:  ret
  } // end of method SizingCaseChangedEventArgs::get_ScenarioViewModel

  .method public hidebysig specialname instance void 
          set_ScenarioViewModel(object 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs::'<ScenarioViewModel>k__BackingField'
    IL_0007:  ret
  } // end of method SizingCaseChangedEventArgs::set_ScenarioViewModel

  .method public hidebysig specialname instance string 
          get_RDName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs::'<RDName>k__BackingField'
    IL_0006:  ret
  } // end of method SizingCaseChangedEventArgs::get_RDName

  .method public hidebysig specialname instance void 
          set_RDName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs::'<RDName>k__BackingField'
    IL_0007:  ret
  } // end of method SizingCaseChangedEventArgs::set_RDName

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method SizingCaseChangedEventArgs::.ctor

  .property instance callconv(8) object ScenarioViewModel()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs::get_ScenarioViewModel()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs::set_ScenarioViewModel(object)
  } // end of property SizingCaseChangedEventArgs::ScenarioViewModel
  .property instance callconv(8) string RDName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs::get_RDName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs::set_RDName(string)
  } // end of property SizingCaseChangedEventArgs::RDName
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SizingCaseChangedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<ReliefScenarioRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly object '<OwnerSystemRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_ReliefScenarioRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs::'<ReliefScenarioRecord>k__BackingField'
    IL_0006:  ret
  } // end of method ScenarioCalculationCompletedEventArgs::get_ReliefScenarioRecord

  .method public hidebysig specialname instance object 
          get_OwnerSystemRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs::'<OwnerSystemRecord>k__BackingField'
    IL_0006:  ret
  } // end of method ScenarioCalculationCompletedEventArgs::get_OwnerSystemRecord

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object reliefScenarioRecord,
                               object ownerSystemRecord) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs::'<ReliefScenarioRecord>k__BackingField'
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs::'<OwnerSystemRecord>k__BackingField'
    IL_0014:  ret
  } // end of method ScenarioCalculationCompletedEventArgs::.ctor

  .property instance callconv(8) object ReliefScenarioRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs::get_ReliefScenarioRecord()
  } // end of property ScenarioCalculationCompletedEventArgs::ReliefScenarioRecord
  .property instance callconv(8) object OwnerSystemRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs::get_OwnerSystemRecord()
  } // end of property ScenarioCalculationCompletedEventArgs::OwnerSystemRecord
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method ScenarioCalculationCompletedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationCompletedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<ReliefScenarioRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly object '<OwnerSystemRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_ReliefScenarioRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs::'<ReliefScenarioRecord>k__BackingField'
    IL_0006:  ret
  } // end of method ScenarioCalculationMethodChangedEventArgs::get_ReliefScenarioRecord

  .method public hidebysig specialname instance object 
          get_OwnerSystemRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs::'<OwnerSystemRecord>k__BackingField'
    IL_0006:  ret
  } // end of method ScenarioCalculationMethodChangedEventArgs::get_OwnerSystemRecord

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object reliefScenarioRecord,
                               object ownerSystemRecord) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs::'<ReliefScenarioRecord>k__BackingField'
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs::'<OwnerSystemRecord>k__BackingField'
    IL_0014:  ret
  } // end of method ScenarioCalculationMethodChangedEventArgs::.ctor

  .property instance callconv(8) object ReliefScenarioRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs::get_ReliefScenarioRecord()
  } // end of property ScenarioCalculationMethodChangedEventArgs::ReliefScenarioRecord
  .property instance callconv(8) object OwnerSystemRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs::get_OwnerSystemRecord()
  } // end of property ScenarioCalculationMethodChangedEventArgs::OwnerSystemRecord
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method ScenarioCalculationMethodChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioCalculationMethodChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<ReliefScenarioRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly object '<ReliefDeviceRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly object '<OwnerSystemRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_ReliefScenarioRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs::'<ReliefScenarioRecord>k__BackingField'
    IL_0006:  ret
  } // end of method ScenarioLineSizingMethodChangedEventArgs::get_ReliefScenarioRecord

  .method public hidebysig specialname instance object 
          get_ReliefDeviceRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs::'<ReliefDeviceRecord>k__BackingField'
    IL_0006:  ret
  } // end of method ScenarioLineSizingMethodChangedEventArgs::get_ReliefDeviceRecord

  .method public hidebysig specialname instance object 
          get_OwnerSystemRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs::'<OwnerSystemRecord>k__BackingField'
    IL_0006:  ret
  } // end of method ScenarioLineSizingMethodChangedEventArgs::get_OwnerSystemRecord

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object reliefScenarioRecord,
                               object reliefDeviceRecord,
                               object ownerSystemRecord) cil managed
  {
    // Code size       28 (0x1c)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs::'<ReliefScenarioRecord>k__BackingField'
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs::'<ReliefDeviceRecord>k__BackingField'
    IL_0014:  ldarg.0
    IL_0015:  ldarg.3
    IL_0016:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs::'<OwnerSystemRecord>k__BackingField'
    IL_001b:  ret
  } // end of method ScenarioLineSizingMethodChangedEventArgs::.ctor

  .property instance callconv(8) object ReliefScenarioRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs::get_ReliefScenarioRecord()
  } // end of property ScenarioLineSizingMethodChangedEventArgs::ReliefScenarioRecord
  .property instance callconv(8) object ReliefDeviceRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs::get_ReliefDeviceRecord()
  } // end of property ScenarioLineSizingMethodChangedEventArgs::ReliefDeviceRecord
  .property instance callconv(8) object OwnerSystemRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs::get_OwnerSystemRecord()
  } // end of property ScenarioLineSizingMethodChangedEventArgs::OwnerSystemRecord
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method ScenarioLineSizingMethodChangedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ScenarioLineSizingMethodChangedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<TankRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_TankRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEventArgs::'<TankRecord>k__BackingField'
    IL_0006:  ret
  } // end of method TankCalculationCompletedEventArgs::get_TankRecord

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object tankRecord) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEventArgs::'<TankRecord>k__BackingField'
    IL_000d:  ret
  } // end of method TankCalculationCompletedEventArgs::.ctor

  .property instance callconv(8) object TankRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEventArgs::get_TankRecord()
  } // end of property TankCalculationCompletedEventArgs::TankRecord
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method TankCalculationCompletedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCalculationCompletedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<NewSystemRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_NewSystemRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEventArgs::'<NewSystemRecord>k__BackingField'
    IL_0006:  ret
  } // end of method SystemCreatedEventArgs::get_NewSystemRecord

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object newSystemRecord) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEventArgs::'<NewSystemRecord>k__BackingField'
    IL_000d:  ret
  } // end of method SystemCreatedEventArgs::.ctor

  .property instance callconv(8) object NewSystemRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEventArgs::get_NewSystemRecord()
  } // end of property SystemCreatedEventArgs::NewSystemRecord
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method SystemCreatedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemCreatedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<UpdatedSystemRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_UpdatedSystemRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEventArgs::'<UpdatedSystemRecord>k__BackingField'
    IL_0006:  ret
  } // end of method SystemUpdatedEventArgs::get_UpdatedSystemRecord

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object updatedSystemRecord) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEventArgs::'<UpdatedSystemRecord>k__BackingField'
    IL_000d:  ret
  } // end of method SystemUpdatedEventArgs::.ctor

  .property instance callconv(8) object UpdatedSystemRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEventArgs::get_UpdatedSystemRecord()
  } // end of property SystemUpdatedEventArgs::UpdatedSystemRecord
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method SystemUpdatedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemUpdatedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<DeletedSystemRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_DeletedSystemRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEventArgs::'<DeletedSystemRecord>k__BackingField'
    IL_0006:  ret
  } // end of method SystemDeletedEventArgs::get_DeletedSystemRecord

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object deletedSystemRecord) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEventArgs::'<DeletedSystemRecord>k__BackingField'
    IL_000d:  ret
  } // end of method SystemDeletedEventArgs::.ctor

  .property instance callconv(8) object DeletedSystemRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEventArgs::get_DeletedSystemRecord()
  } // end of property SystemDeletedEventArgs::DeletedSystemRecord
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method SystemDeletedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemDeletedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<SystemRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly string '<OldSystemName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_SystemRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs::'<SystemRecord>k__BackingField'
    IL_0006:  ret
  } // end of method SystemRenamedEventArgs::get_SystemRecord

  .method public hidebysig specialname instance string 
          get_OldSystemName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs::'<OldSystemName>k__BackingField'
    IL_0006:  ret
  } // end of method SystemRenamedEventArgs::get_OldSystemName

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object systemRecord,
                               string oldSystemName) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs::'<SystemRecord>k__BackingField'
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs::'<OldSystemName>k__BackingField'
    IL_0014:  ret
  } // end of method SystemRenamedEventArgs::.ctor

  .property instance callconv(8) object SystemRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs::get_SystemRecord()
  } // end of property SystemRenamedEventArgs::SystemRecord
  .property instance callconv(8) string OldSystemName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs::get_OldSystemName()
  } // end of property SystemRenamedEventArgs::OldSystemName
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method SystemRenamedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.SystemRenamedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<NewTankRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_NewTankRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEventArgs::'<NewTankRecord>k__BackingField'
    IL_0006:  ret
  } // end of method TankCreatedEventArgs::get_NewTankRecord

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object newTankRecord) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEventArgs::'<NewTankRecord>k__BackingField'
    IL_000d:  ret
  } // end of method TankCreatedEventArgs::.ctor

  .property instance callconv(8) object NewTankRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEventArgs::get_NewTankRecord()
  } // end of property TankCreatedEventArgs::NewTankRecord
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method TankCreatedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankCreatedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<DeletedTankRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_DeletedTankRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEventArgs::'<DeletedTankRecord>k__BackingField'
    IL_0006:  ret
  } // end of method TankDeletedEventArgs::get_DeletedTankRecord

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object deletedTankRecord) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEventArgs::'<DeletedTankRecord>k__BackingField'
    IL_000d:  ret
  } // end of method TankDeletedEventArgs::.ctor

  .property instance callconv(8) object DeletedTankRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEventArgs::get_DeletedTankRecord()
  } // end of property TankDeletedEventArgs::DeletedTankRecord
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method TankDeletedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankDeletedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private initonly object '<TankRecord>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private initonly string '<OldTankName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance object 
          get_TankRecord() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs::'<TankRecord>k__BackingField'
    IL_0006:  ret
  } // end of method TankRenamedEventArgs::get_TankRecord

  .method public hidebysig specialname instance string 
          get_OldTankName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs::'<OldTankName>k__BackingField'
    IL_0006:  ret
  } // end of method TankRenamedEventArgs::get_OldTankName

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object tankRecord,
                               string oldTankName) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs::'<TankRecord>k__BackingField'
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs::'<OldTankName>k__BackingField'
    IL_0014:  ret
  } // end of method TankRenamedEventArgs::.ctor

  .property instance callconv(8) object TankRecord()
  {
    .get instance object AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs::get_TankRecord()
  } // end of property TankRenamedEventArgs::TankRecord
  .property instance callconv(8) string OldTankName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs::get_OldTankName()
  } // end of property TankRenamedEventArgs::OldTankName
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEvent
       extends class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [Microsoft.Practices.Composite.Presentation]Microsoft.Practices.Composite.Presentation.Events.CompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEventArgs>::.ctor()
    IL_0006:  ret
  } // end of method TankRenamedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.TankRenamedEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method UpdatePSVSummaryEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private string '<ScenarioName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod '<SizingMethod>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<PSVName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private int32 '<RowNumber>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<OriginalSource>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation _operation
  .method public hidebysig specialname instance string 
          get_ScenarioName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::'<ScenarioName>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVSummaryEventArgs::get_ScenarioName

  .method public hidebysig specialname instance void 
          set_ScenarioName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::'<ScenarioName>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVSummaryEventArgs::set_ScenarioName

  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod 
          get_SizingMethod() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::'<SizingMethod>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVSummaryEventArgs::get_SizingMethod

  .method public hidebysig specialname instance void 
          set_SizingMethod(valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::'<SizingMethod>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVSummaryEventArgs::set_SizingMethod

  .method public hidebysig specialname instance string 
          get_PSVName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::'<PSVName>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVSummaryEventArgs::get_PSVName

  .method public hidebysig specialname instance void 
          set_PSVName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::'<PSVName>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVSummaryEventArgs::set_PSVName

  .method public hidebysig specialname instance int32 
          get_RowNumber() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::'<RowNumber>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVSummaryEventArgs::get_RowNumber

  .method public hidebysig specialname instance void 
          set_RowNumber(int32 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::'<RowNumber>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVSummaryEventArgs::set_RowNumber

  .method public hidebysig specialname instance string 
          get_OriginalSource() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::'<OriginalSource>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVSummaryEventArgs::get_OriginalSource

  .method public hidebysig specialname instance void 
          set_OriginalSource(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::'<OriginalSource>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVSummaryEventArgs::set_OriginalSource

  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation 
          get_UpdateAction() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::_operation
    IL_0006:  ret
  } // end of method UpdatePSVSummaryEventArgs::get_UpdateAction

  .method public hidebysig specialname instance void 
          set_UpdateAction(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation 'value') cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::_operation
    IL_0007:  ret
  } // end of method UpdatePSVSummaryEventArgs::set_UpdateAction

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method UpdatePSVSummaryEventArgs::.ctor

  .property instance callconv(8) string ScenarioName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::get_ScenarioName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::set_ScenarioName(string)
  } // end of property UpdatePSVSummaryEventArgs::ScenarioName
  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod
          SizingMethod()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::get_SizingMethod()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::set_SizingMethod(valuetype AspenTech.EquipmentAnalysis.Infrastructure.OrificeSizingMethod)
  } // end of property UpdatePSVSummaryEventArgs::SizingMethod
  .property instance callconv(8) string PSVName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::get_PSVName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::set_PSVName(string)
  } // end of property UpdatePSVSummaryEventArgs::PSVName
  .property instance callconv(8) int32 RowNumber()
  {
    .get instance int32 AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::get_RowNumber()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::set_RowNumber(int32)
  } // end of property UpdatePSVSummaryEventArgs::RowNumber
  .property instance callconv(8) string OriginalSource()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::get_OriginalSource()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::set_OriginalSource(string)
  } // end of property UpdatePSVSummaryEventArgs::OriginalSource
  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation
          UpdateAction()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::get_UpdateAction()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs::set_UpdateAction(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation)
  } // end of property UpdatePSVSummaryEventArgs::UpdateAction
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVSummaryEventArgs

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation Create = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation Duplicate = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation Delete = int32(0x00000002)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOperation

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOrificeSizesEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method UpdateOrificeSizesEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateOrificeSizesEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.5
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method UpdatePSVTreeNavigatorViewEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption '<UpdateOption>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<DataPath>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey '<Key>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<CreatedObjectName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType '<PRDType>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private valuetype [mscorlib]System.Nullable`1<bool> '<IsCopyPaste>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption 
          get_UpdateOption() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<UpdateOption>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::get_UpdateOption

  .method public hidebysig specialname instance void 
          set_UpdateOption(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<UpdateOption>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::set_UpdateOption

  .method public hidebysig specialname instance string 
          get_DataPath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<DataPath>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::get_DataPath

  .method public hidebysig specialname instance void 
          set_DataPath(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<DataPath>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::set_DataPath

  .method public hidebysig specialname instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 
          get_Key() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<Key>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::get_Key

  .method public hidebysig specialname instance void 
          set_Key(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<Key>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::set_Key

  .method public hidebysig specialname instance string 
          get_CreatedObjectName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<CreatedObjectName>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::get_CreatedObjectName

  .method public hidebysig specialname instance void 
          set_CreatedObjectName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<CreatedObjectName>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::set_CreatedObjectName

  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType 
          get_PRDType() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<PRDType>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::get_PRDType

  .method public hidebysig specialname instance void 
          set_PRDType(valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<PRDType>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::set_PRDType

  .method public hidebysig specialname instance valuetype [mscorlib]System.Nullable`1<bool> 
          get_IsCopyPaste() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype [mscorlib]System.Nullable`1<bool> AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<IsCopyPaste>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::get_IsCopyPaste

  .method public hidebysig specialname instance void 
          set_IsCopyPaste(valuetype [mscorlib]System.Nullable`1<bool> 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      valuetype [mscorlib]System.Nullable`1<bool> AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::'<IsCopyPaste>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::set_IsCopyPaste

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method UpdatePSVTreeNavigatorViewEventArgs::.ctor

  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption
          UpdateOption()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::get_UpdateOption()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::set_UpdateOption(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption)
  } // end of property UpdatePSVTreeNavigatorViewEventArgs::UpdateOption
  .property instance callconv(8) string DataPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::get_DataPath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::set_DataPath(string)
  } // end of property UpdatePSVTreeNavigatorViewEventArgs::DataPath
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
          Key()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::get_Key()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::set_Key(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey)
  } // end of property UpdatePSVTreeNavigatorViewEventArgs::Key
  .property instance callconv(8) string CreatedObjectName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::get_CreatedObjectName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::set_CreatedObjectName(string)
  } // end of property UpdatePSVTreeNavigatorViewEventArgs::CreatedObjectName
  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType
          PRDType()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::get_PRDType()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::set_PRDType(valuetype AspenTech.EquipmentAnalysis.Infrastructure.ReliefDeviceType)
  } // end of property UpdatePSVTreeNavigatorViewEventArgs::PRDType
  .property instance callconv(8) valuetype [mscorlib]System.Nullable`1<bool>
          IsCopyPaste()
  {
    .get instance valuetype [mscorlib]System.Nullable`1<bool> AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::get_IsCopyPaste()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs::set_IsCopyPaste(valuetype [mscorlib]System.Nullable`1<bool>)
  } // end of property UpdatePSVTreeNavigatorViewEventArgs::IsCopyPaste
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewEventArgs

.class public auto ansi sealed AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption AddPSV = int32(0x00000000)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption AddScenario = int32(0x00000001)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption AddTank = int32(0x00000002)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption DeletePSV = int32(0x00000003)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption DeleteScenario = int32(0x00000004)
  .field public static literal valuetype AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption DeleteTank = int32(0x00000005)
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeNavigatorViewOption

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method ViewStorageTankEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey '<TankKey>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<TankName>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<NodePath>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 
          get_TankKey() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::'<TankKey>k__BackingField'
    IL_0006:  ret
  } // end of method ViewStorageTankEventArgs::get_TankKey

  .method public hidebysig specialname instance void 
          set_TankKey(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::'<TankKey>k__BackingField'
    IL_0007:  ret
  } // end of method ViewStorageTankEventArgs::set_TankKey

  .method public hidebysig specialname instance string 
          get_TankName() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::'<TankName>k__BackingField'
    IL_0006:  ret
  } // end of method ViewStorageTankEventArgs::get_TankName

  .method public hidebysig specialname instance void 
          set_TankName(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::'<TankName>k__BackingField'
    IL_0007:  ret
  } // end of method ViewStorageTankEventArgs::set_TankName

  .method public hidebysig specialname instance string 
          get_NodePath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::'<NodePath>k__BackingField'
    IL_0006:  ret
  } // end of method ViewStorageTankEventArgs::get_NodePath

  .method public hidebysig specialname instance void 
          set_NodePath(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::'<NodePath>k__BackingField'
    IL_0007:  ret
  } // end of method ViewStorageTankEventArgs::set_NodePath

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method ViewStorageTankEventArgs::.ctor

  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
          TankKey()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::get_TankKey()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::set_TankKey(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey)
  } // end of property ViewStorageTankEventArgs::TankKey
  .property instance callconv(8) string TankName()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::get_TankName()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::set_TankName(string)
  } // end of property ViewStorageTankEventArgs::TankName
  .property instance callconv(8) string NodePath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::get_NodePath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs::set_NodePath(string)
  } // end of property ViewStorageTankEventArgs::NodePath
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.ViewStorageTankEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateTankManagerGridEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method UpdateTankManagerGridEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdateTankManagerGridEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method OpenCaseEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private string '<Host>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private valuetype [mscorlib]System.Nullable`1<bool> '<UpdateTreeView>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase '<PSVCase>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance string 
          get_Host() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::'<Host>k__BackingField'
    IL_0006:  ret
  } // end of method OpenCaseEventArgs::get_Host

  .method public hidebysig specialname instance void 
          set_Host(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::'<Host>k__BackingField'
    IL_0007:  ret
  } // end of method OpenCaseEventArgs::set_Host

  .method public hidebysig specialname instance valuetype [mscorlib]System.Nullable`1<bool> 
          get_UpdateTreeView() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype [mscorlib]System.Nullable`1<bool> AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::'<UpdateTreeView>k__BackingField'
    IL_0006:  ret
  } // end of method OpenCaseEventArgs::get_UpdateTreeView

  .method public hidebysig specialname instance void 
          set_UpdateTreeView(valuetype [mscorlib]System.Nullable`1<bool> 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      valuetype [mscorlib]System.Nullable`1<bool> AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::'<UpdateTreeView>k__BackingField'
    IL_0007:  ret
  } // end of method OpenCaseEventArgs::set_UpdateTreeView

  .method public hidebysig specialname instance class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase 
          get_PSVCase() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::'<PSVCase>k__BackingField'
    IL_0006:  ret
  } // end of method OpenCaseEventArgs::get_PSVCase

  .method public hidebysig specialname instance void 
          set_PSVCase(class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::'<PSVCase>k__BackingField'
    IL_0007:  ret
  } // end of method OpenCaseEventArgs::set_PSVCase

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_0006:  ret
  } // end of method OpenCaseEventArgs::.ctor

  .property instance callconv(8) string Host()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::get_Host()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::set_Host(string)
  } // end of property OpenCaseEventArgs::Host
  .property instance callconv(8) valuetype [mscorlib]System.Nullable`1<bool>
          UpdateTreeView()
  {
    .get instance valuetype [mscorlib]System.Nullable`1<bool> AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::get_UpdateTreeView()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::set_UpdateTreeView(valuetype [mscorlib]System.Nullable`1<bool>)
  } // end of property OpenCaseEventArgs::UpdateTreeView
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase
          PSVCase()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::get_PSVCase()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs::set_PSVCase(class AspenTech.EquipmentAnalysis.Infrastructure.IPsvCase)
  } // end of property OpenCaseEventArgs::PSVCase
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.OpenCaseEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method UpdatePSVTreeViewEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEvent

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs
       extends [mscorlib]System.EventArgs
{
  .field private valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation _defaultOp
  .field private string '<NodeVisualPath>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private bool '<ShowScreen>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private string '<NodeType>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject '<ScreenSubject>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .field private class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey '<ModelKey>k__BackingField'
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public hidebysig specialname instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation 
          get_Operation() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::_defaultOp
    IL_0006:  ret
  } // end of method UpdatePSVTreeViewEventArgs::get_Operation

  .method public hidebysig specialname instance void 
          set_Operation(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation 'value') cil managed
  {
    // Code size       17 (0x11)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::_defaultOp
    IL_0006:  ldarg.1
    IL_0007:  beq.s      IL_0010

    IL_0009:  ldarg.0
    IL_000a:  ldarg.1
    IL_000b:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::_defaultOp
    IL_0010:  ret
  } // end of method UpdatePSVTreeViewEventArgs::set_Operation

  .method public hidebysig specialname instance string 
          get_NodeVisualPath() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::'<NodeVisualPath>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeViewEventArgs::get_NodeVisualPath

  .method public hidebysig specialname instance void 
          set_NodeVisualPath(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::'<NodeVisualPath>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeViewEventArgs::set_NodeVisualPath

  .method public hidebysig specialname instance bool 
          get_ShowScreen() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::'<ShowScreen>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeViewEventArgs::get_ShowScreen

  .method public hidebysig specialname instance void 
          set_ShowScreen(bool 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::'<ShowScreen>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeViewEventArgs::set_ShowScreen

  .method public hidebysig specialname instance string 
          get_NodeType() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::'<NodeType>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeViewEventArgs::get_NodeType

  .method public hidebysig specialname instance void 
          set_NodeType(string 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::'<NodeType>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeViewEventArgs::set_NodeType

  .method public hidebysig specialname instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject 
          get_ScreenSubject() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::'<ScreenSubject>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeViewEventArgs::get_ScreenSubject

  .method public hidebysig specialname instance void 
          set_ScreenSubject(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::'<ScreenSubject>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeViewEventArgs::set_ScreenSubject

  .method public hidebysig specialname instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 
          get_ModelKey() cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::'<ModelKey>k__BackingField'
    IL_0006:  ret
  } // end of method UpdatePSVTreeViewEventArgs::get_ModelKey

  .method public hidebysig specialname instance void 
          set_ModelKey(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey 'value') cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::'<ModelKey>k__BackingField'
    IL_0007:  ret
  } // end of method UpdatePSVTreeViewEventArgs::set_ModelKey

  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.3
    IL_0002:  stfld      valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::_defaultOp
    IL_0007:  ldarg.0
    IL_0008:  call       instance void [mscorlib]System.EventArgs::.ctor()
    IL_000d:  ret
  } // end of method UpdatePSVTreeViewEventArgs::.ctor

  .property instance callconv(8) valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation
          Operation()
  {
    .get instance valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::get_Operation()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::set_Operation(valuetype AspenTech.EquipmentAnalysis.Infrastructure.Common/TreeViewOperation)
  } // end of property UpdatePSVTreeViewEventArgs::Operation
  .property instance callconv(8) string NodeVisualPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::get_NodeVisualPath()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::set_NodeVisualPath(string)
  } // end of property UpdatePSVTreeViewEventArgs::NodeVisualPath
  .property instance callconv(8) bool ShowScreen()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::get_ShowScreen()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::set_ShowScreen(bool)
  } // end of property UpdatePSVTreeViewEventArgs::ShowScreen
  .property instance callconv(8) string NodeType()
  {
    .get instance string AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::get_NodeType()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::set_NodeType(string)
  } // end of property UpdatePSVTreeViewEventArgs::NodeType
  .property instance callconv(8) class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject
          ScreenSubject()
  {
    .get instance class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::get_ScreenSubject()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::set_ScreenSubject(class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.ScreenSubject)
  } // end of property UpdatePSVTreeViewEventArgs::ScreenSubject
  .property instance callconv(8) class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey
          ModelKey()
  {
    .get instance class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::get_ModelKey()
    .set instance void AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs::set_ModelKey(class AspenTech.EquipmentAnalysis.Infrastructure.PsvModelKey)
  } // end of property UpdatePSVTreeViewEventArgs::ModelKey
} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.UpdatePSVTreeViewEventArgs

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Infrastructure.Events.DatabaseConnectedEvent
       extends class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldc.i4.2
    IL_0008:  call       instance void class [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.RoutedCompositePresentationEvent`1<class [mscorlib]System.EventArgs>::set_RoutingStrategy(valuetype [AspenTech.Visualisation.CommonShell.Infrastructure.Wpf]AspenTech.Visualisation.CommonShell.CompositeEventRoutingStrategy)
    IL_000d:  ret
  } // end of method DatabaseConnectedEvent::.ctor

} // end of class AspenTech.EquipmentAnalysis.Infrastructure.Events.DatabaseConnectedEvent

.class private auto ansi sealed '<PrivateImplementationDetails>'
       extends [mscorlib]System.Object
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .method assembly hidebysig static uint32 
          ComputeStringHash(string s) cil managed
  {
    // Code size       44 (0x2c)
    .maxstack  2
    .locals init (uint32 V_0,
             int32 V_1)
    IL_0000:  ldarg.0
    IL_0001:  brfalse.s  IL_002a

    IL_0003:  ldc.i4     0x811c9dc5
    IL_0008:  stloc.0
    IL_0009:  ldc.i4.0
    IL_000a:  stloc.1
    IL_000b:  br.s       IL_0021

    IL_000d:  ldarg.0
    IL_000e:  ldloc.1
    IL_000f:  callvirt   instance char [mscorlib]System.String::get_Chars(int32)
    IL_0014:  ldloc.0
    IL_0015:  xor
    IL_0016:  ldc.i4     0x1000193
    IL_001b:  mul
    IL_001c:  stloc.0
    IL_001d:  ldloc.1
    IL_001e:  ldc.i4.1
    IL_001f:  add
    IL_0020:  stloc.1
    IL_0021:  ldloc.1
    IL_0022:  ldarg.0
    IL_0023:  callvirt   instance int32 [mscorlib]System.String::get_Length()
    IL_0028:  blt.s      IL_000d

    IL_002a:  ldloc.0
    IL_002b:  ret
  } // end of method '<PrivateImplementationDetails>'::ComputeStringHash

} // end of class '<PrivateImplementationDetails>'


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file orig.ildasm.res
