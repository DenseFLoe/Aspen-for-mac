﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties
  Aspentech.HYSYS.FlashType_enum
  Aspentech.HYSYS.PSVEmergScenario
  Aspentech.HYSYS.PSVEmergScenario2
  Aspentech.HYSYS.PSVFluid
  Aspentech.HYSYS.PSVFluidPhase_enum
  Aspentech.HYSYS.PSVStorageTank
  Aspentech.HYSYS.PhaseType_enum
  Aspentech.HYSYS._IRoot
  Aspentech.HYSYS._IViewable
  Aspentech.HYSYS._PSVFluid1
  AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties/'<>o__7'
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern AspenTech.EquipmentAnalysis.Infrastructure
{
  .ver 41:0:0:0
}
.assembly extern PSVSizingEngine
{
  .ver 41:0:0:0
}
.assembly extern AspenTech.AspenCxs.CxsViewModel
{
  .ver 41:0:0:0
}
.assembly extern System.Core
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern Microsoft.CSharp
{
  .publickeytoken = (B0 3F 5F 7F 11 D5 0A 3A )                         // .?_....:
  .ver 4:0:0:0
}
.assembly AspenTech.EquipmentAnalysis.Properties.AspenHysys
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.

  // --- The following custom attribute is added automatically, do not uncomment -------
  //  .custom instance void [mscorlib]System.Diagnostics.DebuggableAttribute::.ctor(valuetype [mscorlib]System.Diagnostics.DebuggableAttribute/DebuggingModes) = ( 01 00 02 00 00 00 00 00 ) 

  .custom instance void [mscorlib]System.Reflection.AssemblyFileVersionAttribute::.ctor(string) = ( 01 00 09 34 31 2E 30 2E 30 2E 38 33 00 00 )       // ...41.0.0.83..
  .custom instance void [mscorlib]System.Reflection.AssemblyCompanyAttribute::.ctor(string) = ( 01 00 15 41 73 70 65 6E 54 65 63 68 20 43 6F 72   // ...AspenTech Cor
                                                                                                70 6F 72 61 74 69 6F 6E 00 00 )                   // poration..
  .custom instance void [mscorlib]System.Reflection.AssemblyProductAttribute::.ctor(string) = ( 01 00 21 41 73 70 65 6E 20 53 61 66 65 74 79 20   // ..!Aspen Safety 
                                                                                                41 6E 61 6C 79 73 69 73 20 45 6E 76 69 72 6F 6E   // Analysis Environ
                                                                                                6D 65 6E 74 00 00 )                               // ment..
  .custom instance void [mscorlib]System.Reflection.AssemblyCopyrightAttribute::.ctor(string) = ( 01 00 27 43 6F 70 79 72 69 67 68 74 20 C2 A9 20   // ..'Copyright .. 
                                                                                                  41 73 70 65 6E 54 65 63 68 20 43 6F 72 70 6F 72   // AspenTech Corpor
                                                                                                  61 74 69 6F 6E 20 32 30 32 34 00 00 )             // ation 2024..
  .custom instance void [mscorlib]System.Reflection.AssemblyTitleAttribute::.ctor(string) = ( 01 00 31 41 73 70 65 6E 54 65 63 68 2E 45 71 75   // ..1AspenTech.Equ
                                                                                              69 70 6D 65 6E 74 41 6E 61 6C 79 73 69 73 2E 50   // ipmentAnalysis.P
                                                                                              72 6F 70 65 72 74 69 65 73 2E 41 73 70 65 6E 48   // roperties.AspenH
                                                                                              79 73 79 73 00 00 )                               // ysys..
  .custom instance void [mscorlib]System.Reflection.AssemblyDescriptionAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyConfigurationAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.AssemblyTrademarkAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 63 37 36 66 64 31 36 35 2D 35 38 37 62   // ..$c76fd165-587b
                                                                                                  2D 34 65 35 38 2D 39 61 63 31 2D 63 36 64 64 39   // -4e58-9ac1-c6dd9
                                                                                                  62 66 39 38 37 38 34 00 00 )                      // bf98784..
  .custom instance void [mscorlib]System.Runtime.Versioning.TargetFrameworkAttribute::.ctor(string) = ( 01 00 1A 2E 4E 45 54 46 72 61 6D 65 77 6F 72 6B   // ....NETFramework
                                                                                                        2C 56 65 72 73 69 6F 6E 3D 76 34 2E 38 01 00 54   // ,Version=v4.8..T
                                                                                                        0E 14 46 72 61 6D 65 77 6F 72 6B 44 69 73 70 6C   // ..FrameworkDispl
                                                                                                        61 79 4E 61 6D 65 12 2E 4E 45 54 20 46 72 61 6D   // ayName..NET Fram
                                                                                                        65 77 6F 72 6B 20 34 2E 38 )                      // ework 4.8
  .hash algorithm 0x00008004
  .ver 41:0:0:0
}
.module AspenTech.EquipmentAnalysis.Properties.AspenHysys.dll
// MVID: {70e7ee2f-07bf-4250-a09c-2b53728a07fe}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000001    //  ILONLY
// Image base: 0x000001908EDC0000


// =============== CLASS MEMBERS DECLARATION ===================

.class public auto ansi beforefieldinit AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties
       extends [mscorlib]System.Object
       implements [PSVSizingEngine]PSVSizingEngine.IPPPFluid,
                  [mscorlib]System.IDisposable,
                  [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel
{
  .class abstract auto ansi sealed nested private beforefieldinit '<>o__7'
         extends [mscorlib]System.Object
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>> '<>p__0'
    .field public static class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>> '<>p__1'
  } // end of class '<>o__7'

  .field private class Aspentech.HYSYS.PSVEmergScenario2 _refScenario
  .field private class Aspentech.HYSYS.PSVStorageTank _refTank
  .field private class Aspentech.HYSYS.PSVFluid _refFluid
  .field private string _path
  .field private bool _lastFlashSucceeded
  .field private bool _hasFireFractions
  .field private bool disposedValue
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string path) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  call       instance void AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_Initialize(string)
    IL_000d:  ret
  } // end of method HysysProperties::.ctor

  .method private hidebysig instance void 
          _Initialize(string path) cil managed
  {
    // Code size       274 (0x112)
    .maxstack  5
    .locals init (string V_0,
             class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult V_1,
             class Aspentech.HYSYS.PSVEmergScenario2 V_2,
             class Aspentech.HYSYS.PSVStorageTank V_3)
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  stfld      string AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_path
    IL_0007:  ldarg.1
    IL_0008:  stloc.0
    IL_0009:  ldloc.0
    IL_000a:  ldstr      "Fluid"
    IL_000f:  callvirt   instance bool [mscorlib]System.String::EndsWith(string)
    IL_0014:  brfalse.s  IL_0026

    IL_0016:  ldarg.1
    IL_0017:  ldc.i4.0
    IL_0018:  ldarg.1
    IL_0019:  callvirt   instance int32 [mscorlib]System.String::get_Length()
    IL_001e:  ldc.i4.6
    IL_001f:  sub
    IL_0020:  callvirt   instance string [mscorlib]System.String::Substring(int32,
                                                                            int32)
    IL_0025:  stloc.0
    IL_0026:  call       class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.CxsCaseHelper::get_MyDataProvider()
    IL_002b:  ldloc.0
    IL_002c:  ldstr      "GetDispatch"
    IL_0031:  ldc.i4.0
    IL_0032:  ldnull
    IL_0033:  callvirt   instance class [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxsDataProvider::InvokeAction(string,
                                                                                                                                                                                                                        string,
                                                                                                                                                                                                                        bool,
                                                                                                                                                                                                                        object[])
    IL_0038:  stloc.1
    IL_0039:  ldloc.1
    IL_003a:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult::get_Result()
    IL_003f:  isinst     Aspentech.HYSYS.PSVEmergScenario2
    IL_0044:  stloc.2
    IL_0045:  ldloc.2
    IL_0046:  brfalse.s  IL_00a0

    IL_0048:  ldarg.0
    IL_0049:  ldloc.2
    IL_004a:  stfld      class Aspentech.HYSYS.PSVEmergScenario2 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refScenario
    IL_004f:  ldarg.0
    IL_0050:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>> AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties/'<>o__7'::'<>p__0'
    IL_0055:  brtrue.s   IL_007b

    IL_0057:  ldc.i4.0
    IL_0058:  ldtoken    Aspentech.HYSYS.PSVFluid
    IL_005d:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_0062:  ldtoken    AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties
    IL_0067:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_006c:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_0071:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_0076:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>> AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties/'<>o__7'::'<>p__0'
    IL_007b:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>> AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties/'<>o__7'::'<>p__0'
    IL_0080:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>>::Target
    IL_0085:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>> AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties/'<>o__7'::'<>p__0'
    IL_008a:  ldarg.0
    IL_008b:  ldfld      class Aspentech.HYSYS.PSVEmergScenario2 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refScenario
    IL_0090:  callvirt   instance object Aspentech.HYSYS.PSVEmergScenario2::get_WorkingFluid()
    IL_0095:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>::Invoke(!0,
                                                                                                                                                                              !1)
    IL_009a:  stfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_009f:  ret

    IL_00a0:  ldloc.1
    IL_00a1:  callvirt   instance object [AspenTech.AspenCxs.CxsViewModel]AspenTech.AspenCxs.CxsViewModel.CxvActionResult::get_Result()
    IL_00a6:  isinst     Aspentech.HYSYS.PSVStorageTank
    IL_00ab:  stloc.3
    IL_00ac:  ldloc.3
    IL_00ad:  brfalse.s  IL_0107

    IL_00af:  ldarg.0
    IL_00b0:  ldloc.3
    IL_00b1:  stfld      class Aspentech.HYSYS.PSVStorageTank AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refTank
    IL_00b6:  ldarg.0
    IL_00b7:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>> AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties/'<>o__7'::'<>p__1'
    IL_00bc:  brtrue.s   IL_00e2

    IL_00be:  ldc.i4.0
    IL_00bf:  ldtoken    Aspentech.HYSYS.PSVFluid
    IL_00c4:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_00c9:  ldtoken    AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties
    IL_00ce:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_00d3:  call       class [System.Core]System.Runtime.CompilerServices.CallSiteBinder [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.Binder::Convert(valuetype [Microsoft.CSharp]Microsoft.CSharp.RuntimeBinder.CSharpBinderFlags,
                                                                                                                                                            class [mscorlib]System.Type,
                                                                                                                                                            class [mscorlib]System.Type)
    IL_00d8:  call       class [System.Core]System.Runtime.CompilerServices.CallSite`1<!0> class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>>::Create(class [System.Core]System.Runtime.CompilerServices.CallSiteBinder)
    IL_00dd:  stsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>> AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties/'<>o__7'::'<>p__1'
    IL_00e2:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>> AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties/'<>o__7'::'<>p__1'
    IL_00e7:  ldfld      !0 class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>>::Target
    IL_00ec:  ldsfld     class [System.Core]System.Runtime.CompilerServices.CallSite`1<class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>> AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties/'<>o__7'::'<>p__1'
    IL_00f1:  ldarg.0
    IL_00f2:  ldfld      class Aspentech.HYSYS.PSVStorageTank AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refTank
    IL_00f7:  callvirt   instance object Aspentech.HYSYS.PSVStorageTank::get_WorkingFluid()
    IL_00fc:  callvirt   instance !2 class [mscorlib]System.Func`3<class [System.Core]System.Runtime.CompilerServices.CallSite,object,class Aspentech.HYSYS.PSVFluid>::Invoke(!0,
                                                                                                                                                                              !1)
    IL_0101:  stfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0106:  ret

    IL_0107:  ldstr      "Internal error: Dispatch object from path could no"
    + "t be converted to a PSVEmergScenario or PSVStorageTank."
    IL_010c:  newobj     instance void [mscorlib]System.InvalidOperationException::.ctor(string)
    IL_0111:  throw
  } // end of method HysysProperties::_Initialize

  .method public hidebysig newslot virtual final 
          instance bool  IsFluidReady() cil managed
  {
    // Code size       2 (0x2)
    .maxstack  8
    IL_0000:  ldc.i4.1
    IL_0001:  ret
  } // end of method HysysProperties::IsFluidReady

  .method public hidebysig newslot virtual final 
          instance void  BatchRetrieveProperties() cil managed
  {
    // Code size       1 (0x1)
    .maxstack  8
    IL_0000:  ret
  } // end of method HysysProperties::BatchRetrieveProperties

  .method public hidebysig newslot virtual final 
          instance float64  Pressure() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_Pressure()
    IL_001d:  ret
  } // end of method HysysProperties::Pressure

  .method public hidebysig newslot virtual final 
          instance float64  Temperature() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_Temperature()
    IL_001d:  ret
  } // end of method HysysProperties::Temperature

  .method public hidebysig newslot virtual final 
          instance float64  VaporFraction() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_VaporFraction()
    IL_001d:  ret
  } // end of method HysysProperties::VaporFraction

  .method public hidebysig newslot virtual final 
          instance float64  SaturationPressure() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_SaturationPressure()
    IL_000b:  ret
  } // end of method HysysProperties::SaturationPressure

  .method public hidebysig newslot virtual final 
          instance int32  NumberOfComponents() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  callvirt   instance int32 Aspentech.HYSYS.PSVFluid::get_NumComponents()
    IL_000b:  ret
  } // end of method HysysProperties::NumberOfComponents

  .method public hidebysig newslot virtual final 
          instance float64  get_ComponentMolecularWeight(int32 Pos) cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_ComponentMolecularWeight(int32)
    IL_000c:  ret
  } // end of method HysysProperties::get_ComponentMolecularWeight

  .method public hidebysig newslot virtual final 
          instance string  get_ComponentName(int32 Pos) cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance string Aspentech.HYSYS.PSVFluid::get_ComponentName(int32)
    IL_000c:  ret
  } // end of method HysysProperties::get_ComponentName

  .method public hidebysig newslot virtual final 
          instance float64  CriticalPressure(int32 Pos) cil managed
  {
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  newobj     instance void [mscorlib]System.NotImplementedException::.ctor()
    IL_0005:  throw
  } // end of method HysysProperties::CriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  CriticalTemperature(int32 Pos) cil managed
  {
    // Code size       6 (0x6)
    .maxstack  8
    IL_0000:  newobj     instance void [mscorlib]System.NotImplementedException::.ctor()
    IL_0005:  throw
  } // end of method HysysProperties::CriticalTemperature

  .method public hidebysig newslot virtual final 
          instance float64  get_Composition(int32 Pos) cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_Composition(int32)
    IL_000c:  ret
  } // end of method HysysProperties::get_Composition

  .method public hidebysig newslot virtual final 
          instance float64  get_StoredComposition(int32 Pos) cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_StoredComposition(int32)
    IL_000c:  ret
  } // end of method HysysProperties::get_StoredComposition

  .method public hidebysig newslot specialname virtual final 
          instance float64[]  get_VaporComposition() cil managed
  {
    // Code size       65 (0x41)
    .maxstack  4
    .locals init (int32 V_0,
             float64[] V_1,
             int32 V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_000a

    IL_0008:  ldnull
    IL_0009:  ret

    IL_000a:  ldarg.0
    IL_000b:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0010:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::StoreVaporFractions()
    IL_0015:  pop
    IL_0016:  ldarg.0
    IL_0017:  call       instance int32 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::NumberOfComponents()
    IL_001c:  stloc.0
    IL_001d:  ldloc.0
    IL_001e:  newarr     [mscorlib]System.Double
    IL_0023:  stloc.1
    IL_0024:  ldc.i4.0
    IL_0025:  stloc.2
    IL_0026:  br.s       IL_003b

    IL_0028:  ldloc.1
    IL_0029:  ldloc.2
    IL_002a:  ldarg.0
    IL_002b:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0030:  ldloc.2
    IL_0031:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_VaporComposition(int32)
    IL_0036:  stelem.r8
    IL_0037:  ldloc.2
    IL_0038:  ldc.i4.1
    IL_0039:  add
    IL_003a:  stloc.2
    IL_003b:  ldloc.2
    IL_003c:  ldloc.0
    IL_003d:  blt.s      IL_0028

    IL_003f:  ldloc.1
    IL_0040:  ret
  } // end of method HysysProperties::get_VaporComposition

  .method public hidebysig newslot virtual final 
          instance float64  HeatOfVaporization() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_HeatOfVaporization()
    IL_001d:  ret
  } // end of method HysysProperties::HeatOfVaporization

  .method public hidebysig newslot virtual final 
          instance float64  OverallDensity() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.3
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassDensity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::OverallDensity

  .method public hidebysig newslot virtual final 
          instance float64  OverallMassEnthalpy() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.3
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassEnthalpy(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::OverallMassEnthalpy

  .method public hidebysig newslot virtual final 
          instance float64  OverallMassEntropy() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.3
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassEntropy(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::OverallMassEntropy

  .method public hidebysig newslot virtual final 
          instance float64  OverallMassHeatCapacity() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.3
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassHeatCapacity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::OverallMassHeatCapacity

  .method public hidebysig newslot virtual final 
          instance float64  OverallMolecularWeight() cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldc.i4.3
    IL_0007:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMolecularWeight(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_000c:  ret
  } // end of method HysysProperties::OverallMolecularWeight

  .method public hidebysig newslot virtual final 
          instance float64  OverallPseudoCriticalPressure() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PseudoCriticalPressure()
    IL_000b:  ret
  } // end of method HysysProperties::OverallPseudoCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  OverallTrueCriticalPressure() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_TrueCriticalPressure()
    IL_000b:  ret
  } // end of method HysysProperties::OverallTrueCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  OverallCriticalPressure() cil managed
  {
    // Code size       10 (0xa)
    .maxstack  3
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldloca.s   V_0
    IL_0003:  ldc.i4.0
    IL_0004:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::OverallCriticalPressure(bool&,
                                                                                                                                     bool)
    IL_0009:  ret
  } // end of method HysysProperties::OverallCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  OverallCriticalPressure([out] bool& usedRigorousMethod,
                                                    [opt] bool forceRigorous) cil managed
  {
    .param [2] = bool(false)
    // Code size       84 (0x54)
    .maxstack  2
    .locals init (float64 V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::OverallTrueCriticalPressure()
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0020

    IL_000f:  ldloc.0
    IL_0010:  ldc.r8     0.0
    IL_0019:  ble.un.s   IL_0020

    IL_001b:  ldarg.1
    IL_001c:  ldc.i4.1
    IL_001d:  stind.i1
    IL_001e:  br.s       IL_0052

    IL_0020:  ldarg.2
    IL_0021:  brfalse.s  IL_0032

    IL_0023:  ldarg.1
    IL_0024:  ldc.i4.1
    IL_0025:  stind.i1
    IL_0026:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_002f:  stloc.0
    IL_0030:  br.s       IL_0052

    IL_0032:  ldarg.1
    IL_0033:  ldc.i4.0
    IL_0034:  stind.i1
    IL_0035:  ldarg.0
    IL_0036:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::OverallPseudoCriticalPressure()
    IL_003b:  stloc.0
    IL_003c:  ldloc.0
    IL_003d:  ldc.r8     0.0
    IL_0046:  bgt.un.s   IL_0052

    IL_0048:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0051:  stloc.0
    IL_0052:  ldloc.0
    IL_0053:  ret
  } // end of method HysysProperties::OverallCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  LiquidMassDensity() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.4
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassDensity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::LiquidMassDensity

  .method public hidebysig newslot virtual final 
          instance float64  LiquidMassEnthalpy() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.4
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassEnthalpy(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::LiquidMassEnthalpy

  .method public hidebysig newslot virtual final 
          instance float64  LiquidMassEntropy() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.4
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassEntropy(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::LiquidMassEntropy

  .method public hidebysig newslot virtual final 
          instance float64  LiquidMassHeatCapacity() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.4
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassHeatCapacity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::LiquidMassHeatCapacity

  .method public hidebysig newslot virtual final 
          instance float64  LiquidMolecularWeight() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.4
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMolecularWeight(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::LiquidMolecularWeight

  .method public hidebysig newslot virtual final 
          instance float64  LiquidSurfaceTension() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_LiquidSurfaceTension()
    IL_001d:  ret
  } // end of method HysysProperties::LiquidSurfaceTension

  .method public hidebysig newslot virtual final 
          instance float64  LiquidViscosity() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.4
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseViscosity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::LiquidViscosity

  .method public hidebysig newslot virtual final 
          instance float64  LiquidPseudoCriticalPressure() cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldc.i4.4
    IL_0007:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhasePseudoCriticalPressure(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_000c:  ret
  } // end of method HysysProperties::LiquidPseudoCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  LiquidTrueCriticalPressure() cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldc.i4.4
    IL_0007:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseTrueCriticalPressure(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_000c:  ret
  } // end of method HysysProperties::LiquidTrueCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  LiquidCriticalPressure() cil managed
  {
    // Code size       10 (0xa)
    .maxstack  3
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldloca.s   V_0
    IL_0003:  ldc.i4.0
    IL_0004:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::LiquidCriticalPressure(bool&,
                                                                                                                                    bool)
    IL_0009:  ret
  } // end of method HysysProperties::LiquidCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  LiquidCriticalPressure([out] bool& usedRigorousMethod,
                                                   [opt] bool forceRigorous) cil managed
  {
    .param [2] = bool(false)
    // Code size       84 (0x54)
    .maxstack  2
    .locals init (float64 V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::LiquidTrueCriticalPressure()
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0020

    IL_000f:  ldloc.0
    IL_0010:  ldc.r8     0.0
    IL_0019:  ble.un.s   IL_0020

    IL_001b:  ldarg.1
    IL_001c:  ldc.i4.1
    IL_001d:  stind.i1
    IL_001e:  br.s       IL_0052

    IL_0020:  ldarg.2
    IL_0021:  brfalse.s  IL_0032

    IL_0023:  ldarg.1
    IL_0024:  ldc.i4.1
    IL_0025:  stind.i1
    IL_0026:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_002f:  stloc.0
    IL_0030:  br.s       IL_0052

    IL_0032:  ldarg.1
    IL_0033:  ldc.i4.0
    IL_0034:  stind.i1
    IL_0035:  ldarg.0
    IL_0036:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::LiquidPseudoCriticalPressure()
    IL_003b:  stloc.0
    IL_003c:  ldloc.0
    IL_003d:  ldc.r8     0.0
    IL_0046:  bgt.un.s   IL_0052

    IL_0048:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0051:  stloc.0
    IL_0052:  ldloc.0
    IL_0053:  ret
  } // end of method HysysProperties::LiquidCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  Cp_Cv_Ideal() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_IdealCpCv()
    IL_001d:  ret
  } // end of method HysysProperties::Cp_Cv_Ideal

  .method public hidebysig newslot virtual final 
          instance float64  Cp_Cv_SemiIdeal() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_SemiIdealCpCv()
    IL_001d:  ret
  } // end of method HysysProperties::Cp_Cv_SemiIdeal

  .method public hidebysig newslot virtual final 
          instance float64  Cp_Cv_Rigorous() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_RealCpCv()
    IL_001d:  ret
  } // end of method HysysProperties::Cp_Cv_Rigorous

  .method public hidebysig newslot virtual final 
          instance float64  VaporMassDensity() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.0
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassDensity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::VaporMassDensity

  .method public hidebysig newslot virtual final 
          instance float64  VaporMassEnthalpy() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.0
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassEnthalpy(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::VaporMassEnthalpy

  .method public hidebysig newslot virtual final 
          instance float64  VaporMassEntropy() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.0
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassEntropy(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::VaporMassEntropy

  .method public hidebysig newslot virtual final 
          instance float64  VaporMassFraction() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.0
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassFraction(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::VaporMassFraction

  .method public hidebysig newslot virtual final 
          instance float64  VaporMassHeatCapacity() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.0
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassHeatCapacity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::VaporMassHeatCapacity

  .method public hidebysig newslot virtual final 
          instance float64  VaporMolecularWeight() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.0
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMolecularWeight(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::VaporMolecularWeight

  .method public hidebysig newslot virtual final 
          instance float64  VaporViscosity() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  ldc.i4.0
    IL_0019:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseViscosity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_001e:  ret
  } // end of method HysysProperties::VaporViscosity

  .method public hidebysig newslot virtual final 
          instance float64  VaporZFactor() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_0012

    IL_0008:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0011:  ret

    IL_0012:  ldarg.0
    IL_0013:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0018:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_VaporZFactor()
    IL_001d:  ret
  } // end of method HysysProperties::VaporZFactor

  .method public hidebysig newslot virtual final 
          instance float64  VaporPseudoCriticalPressure() cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldc.i4.0
    IL_0007:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhasePseudoCriticalPressure(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_000c:  ret
  } // end of method HysysProperties::VaporPseudoCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  VaporTrueCriticalPressure() cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldc.i4.0
    IL_0007:  callvirt   instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseTrueCriticalPressure(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_000c:  ret
  } // end of method HysysProperties::VaporTrueCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  VaporCriticalPressure() cil managed
  {
    // Code size       10 (0xa)
    .maxstack  3
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldloca.s   V_0
    IL_0003:  ldc.i4.0
    IL_0004:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::VaporCriticalPressure(bool&,
                                                                                                                                   bool)
    IL_0009:  ret
  } // end of method HysysProperties::VaporCriticalPressure

  .method public hidebysig newslot virtual final 
          instance float64  VaporCriticalPressure([out] bool& usedRigorousMethod,
                                                  [opt] bool forceRigorous) cil managed
  {
    .param [2] = bool(false)
    // Code size       84 (0x54)
    .maxstack  2
    .locals init (float64 V_0)
    IL_0000:  ldarg.0
    IL_0001:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::VaporTrueCriticalPressure()
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0020

    IL_000f:  ldloc.0
    IL_0010:  ldc.r8     0.0
    IL_0019:  ble.un.s   IL_0020

    IL_001b:  ldarg.1
    IL_001c:  ldc.i4.1
    IL_001d:  stind.i1
    IL_001e:  br.s       IL_0052

    IL_0020:  ldarg.2
    IL_0021:  brfalse.s  IL_0032

    IL_0023:  ldarg.1
    IL_0024:  ldc.i4.1
    IL_0025:  stind.i1
    IL_0026:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_002f:  stloc.0
    IL_0030:  br.s       IL_0052

    IL_0032:  ldarg.1
    IL_0033:  ldc.i4.0
    IL_0034:  stind.i1
    IL_0035:  ldarg.0
    IL_0036:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::VaporPseudoCriticalPressure()
    IL_003b:  stloc.0
    IL_003c:  ldloc.0
    IL_003d:  ldc.r8     0.0
    IL_0046:  bgt.un.s   IL_0052

    IL_0048:  ldc.r8     (00 00 00 00 00 00 F8 FF)
    IL_0051:  stloc.0
    IL_0052:  ldloc.0
    IL_0053:  ret
  } // end of method HysysProperties::VaporCriticalPressure

  .method public hidebysig newslot virtual final 
          instance bool  IsenthalpicFlash(float64 pout) cil managed
  {
    // Code size       61 (0x3d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_000a

    IL_0008:  ldc.i4.0
    IL_0009:  ret

    IL_000a:  ldarg.0
    IL_000b:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::Pressure()
    IL_0010:  ldarg.1
    IL_0011:  bne.un.s   IL_0015

    IL_0013:  ldc.i4.1
    IL_0014:  ret

    IL_0015:  ldarg.0
    IL_0016:  ldc.i4.0
    IL_0017:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_001c:  ldarg.1
    IL_001d:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0022:  brfalse.s  IL_0026

    IL_0024:  ldc.i4.0
    IL_0025:  ret

    IL_0026:  ldarg.0
    IL_0027:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_002c:  ldarg.1
    IL_002d:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::IsenthalpicFlash(float64)
    IL_0032:  dup
    IL_0033:  brfalse.s  IL_003c

    IL_0035:  ldarg.0
    IL_0036:  ldc.i4.1
    IL_0037:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_003c:  ret
  } // end of method HysysProperties::IsenthalpicFlash

  .method public hidebysig newslot virtual final 
          instance bool  IsentropicFlash(float64 pout) cil managed
  {
    // Code size       61 (0x3d)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0006:  brtrue.s   IL_000a

    IL_0008:  ldc.i4.0
    IL_0009:  ret

    IL_000a:  ldarg.0
    IL_000b:  call       instance float64 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::Pressure()
    IL_0010:  ldarg.1
    IL_0011:  bne.un.s   IL_0015

    IL_0013:  ldc.i4.1
    IL_0014:  ret

    IL_0015:  ldarg.0
    IL_0016:  ldc.i4.0
    IL_0017:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_001c:  ldarg.1
    IL_001d:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0022:  brfalse.s  IL_0026

    IL_0024:  ldc.i4.0
    IL_0025:  ret

    IL_0026:  ldarg.0
    IL_0027:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_002c:  ldarg.1
    IL_002d:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::IsentropicFlash(float64)
    IL_0032:  dup
    IL_0033:  brfalse.s  IL_003c

    IL_0035:  ldarg.0
    IL_0036:  ldc.i4.1
    IL_0037:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_003c:  ret
  } // end of method HysysProperties::IsentropicFlash

  .method public hidebysig newslot virtual final 
          instance bool  IsentropicFlashFire(float64 pout) cil managed
  {
    // Code size       8 (0x8)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  call       instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::IsentropicFlash(float64)
    IL_0007:  ret
  } // end of method HysysProperties::IsentropicFlashFire

  .method public hidebysig newslot virtual final 
          instance bool  PHFlash(float64 pout,
                                 float64 h) cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.2
    IL_0020:  ldarg.1
    IL_0021:  ldarg.2
    IL_0022:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluid(valuetype Aspentech.HYSYS.FlashType_enum,
                                                                            float64,
                                                                            float64)
    IL_0027:  dup
    IL_0028:  brfalse.s  IL_0031

    IL_002a:  ldarg.0
    IL_002b:  ldc.i4.1
    IL_002c:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0031:  ret
  } // end of method HysysProperties::PHFlash

  .method public hidebysig newslot virtual final 
          instance bool  PHFlashLiquid(float64 P,
                                       float64 H) cil managed
  {
    // Code size       51 (0x33)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.3
    IL_0020:  ldc.i4.2
    IL_0021:  ldarg.1
    IL_0022:  ldarg.2
    IL_0023:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluidPhase(valuetype Aspentech.HYSYS.PhaseType_enum,
                                                                                 valuetype Aspentech.HYSYS.FlashType_enum,
                                                                                 float64,
                                                                                 float64)
    IL_0028:  dup
    IL_0029:  brfalse.s  IL_0032

    IL_002b:  ldarg.0
    IL_002c:  ldc.i4.1
    IL_002d:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0032:  ret
  } // end of method HysysProperties::PHFlashLiquid

  .method public hidebysig newslot virtual final 
          instance bool  PHFlashOverall(float64 P,
                                        float64 H) cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldarg.2
    IL_0003:  call       instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::PHFlash(float64,
                                                                                                                  float64)
    IL_0008:  ret
  } // end of method HysysProperties::PHFlashOverall

  .method public hidebysig instance bool 
          PHFlashVapor(float64 P,
                       float64 H) cil managed
  {
    // Code size       51 (0x33)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.0
    IL_0020:  ldc.i4.2
    IL_0021:  ldarg.1
    IL_0022:  ldarg.2
    IL_0023:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluidPhase(valuetype Aspentech.HYSYS.PhaseType_enum,
                                                                                 valuetype Aspentech.HYSYS.FlashType_enum,
                                                                                 float64,
                                                                                 float64)
    IL_0028:  dup
    IL_0029:  brfalse.s  IL_0032

    IL_002b:  ldarg.0
    IL_002c:  ldc.i4.1
    IL_002d:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0032:  ret
  } // end of method HysysProperties::PHFlashVapor

  .method public hidebysig newslot virtual final 
          instance bool  PSFlash(float64 pout,
                                 float64 s) cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.3
    IL_0020:  ldarg.1
    IL_0021:  ldarg.2
    IL_0022:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluid(valuetype Aspentech.HYSYS.FlashType_enum,
                                                                            float64,
                                                                            float64)
    IL_0027:  dup
    IL_0028:  brfalse.s  IL_0031

    IL_002a:  ldarg.0
    IL_002b:  ldc.i4.1
    IL_002c:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0031:  ret
  } // end of method HysysProperties::PSFlash

  .method public hidebysig newslot virtual final 
          instance bool  PSFlashOverall(float64 P,
                                        float64 S) cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldarg.2
    IL_0003:  call       instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::PSFlash(float64,
                                                                                                                  float64)
    IL_0008:  ret
  } // end of method HysysProperties::PSFlashOverall

  .method public hidebysig newslot virtual final 
          instance bool  PVFlash(float64 P,
                                 float64 Vf) cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.4
    IL_0020:  ldarg.1
    IL_0021:  ldarg.2
    IL_0022:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluid(valuetype Aspentech.HYSYS.FlashType_enum,
                                                                            float64,
                                                                            float64)
    IL_0027:  dup
    IL_0028:  brfalse.s  IL_0031

    IL_002a:  ldarg.0
    IL_002b:  ldc.i4.1
    IL_002c:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0031:  ret
  } // end of method HysysProperties::PVFlash

  .method public hidebysig newslot virtual final 
          instance bool  PVFlashFire(float64 P,
                                     float64 VF) cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_000d:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::ApplyFireFractions()
    IL_0012:  brtrue.s   IL_0016

    IL_0014:  ldc.i4.0
    IL_0015:  ret

    IL_0016:  ldarg.0
    IL_0017:  ldarg.1
    IL_0018:  ldarg.2
    IL_0019:  call       instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::PVFlash(float64,
                                                                                                                  float64)
    IL_001e:  ret
  } // end of method HysysProperties::PVFlashFire

  .method public hidebysig newslot virtual final 
          instance bool  PVFlashLiquid(float64 P,
                                       float64 VF) cil managed
  {
    // Code size       51 (0x33)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.3
    IL_0020:  ldc.i4.4
    IL_0021:  ldarg.1
    IL_0022:  ldarg.2
    IL_0023:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluidPhase(valuetype Aspentech.HYSYS.PhaseType_enum,
                                                                                 valuetype Aspentech.HYSYS.FlashType_enum,
                                                                                 float64,
                                                                                 float64)
    IL_0028:  dup
    IL_0029:  brfalse.s  IL_0032

    IL_002b:  ldarg.0
    IL_002c:  ldc.i4.1
    IL_002d:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0032:  ret
  } // end of method HysysProperties::PVFlashLiquid

  .method public hidebysig newslot virtual final 
          instance bool  PVFlashOverall(float64 P,
                                        float64 VF) cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldarg.2
    IL_0003:  call       instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::PVFlash(float64,
                                                                                                                  float64)
    IL_0008:  ret
  } // end of method HysysProperties::PVFlashOverall

  .method public hidebysig newslot virtual final 
          instance bool  PVFlashVapor(float64 P,
                                      float64 VF) cil managed
  {
    // Code size       51 (0x33)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.0
    IL_0020:  ldc.i4.4
    IL_0021:  ldarg.1
    IL_0022:  ldarg.2
    IL_0023:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluidPhase(valuetype Aspentech.HYSYS.PhaseType_enum,
                                                                                 valuetype Aspentech.HYSYS.FlashType_enum,
                                                                                 float64,
                                                                                 float64)
    IL_0028:  dup
    IL_0029:  brfalse.s  IL_0032

    IL_002b:  ldarg.0
    IL_002c:  ldc.i4.1
    IL_002d:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0032:  ret
  } // end of method HysysProperties::PVFlashVapor

  .method public hidebysig newslot virtual final 
          instance bool  TPFlash(float64 t,
                                 float64 p) cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.1
    IL_0020:  ldarg.1
    IL_0021:  ldarg.2
    IL_0022:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluid(valuetype Aspentech.HYSYS.FlashType_enum,
                                                                            float64,
                                                                            float64)
    IL_0027:  dup
    IL_0028:  brfalse.s  IL_0031

    IL_002a:  ldarg.0
    IL_002b:  ldc.i4.1
    IL_002c:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0031:  ret
  } // end of method HysysProperties::TPFlash

  .method public hidebysig newslot virtual final 
          instance bool  TPFlashFire(float64 t,
                                     float64 p) cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_000d:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::ApplyFireFractions()
    IL_0012:  brtrue.s   IL_0016

    IL_0014:  ldc.i4.0
    IL_0015:  ret

    IL_0016:  ldarg.0
    IL_0017:  ldarg.1
    IL_0018:  ldarg.2
    IL_0019:  call       instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::TPFlash(float64,
                                                                                                                  float64)
    IL_001e:  ret
  } // end of method HysysProperties::TPFlashFire

  .method public hidebysig newslot virtual final 
          instance bool  TPFlashLiquid(float64 T,
                                       float64 P) cil managed
  {
    // Code size       51 (0x33)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.3
    IL_0020:  ldc.i4.1
    IL_0021:  ldarg.1
    IL_0022:  ldarg.2
    IL_0023:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluidPhase(valuetype Aspentech.HYSYS.PhaseType_enum,
                                                                                 valuetype Aspentech.HYSYS.FlashType_enum,
                                                                                 float64,
                                                                                 float64)
    IL_0028:  dup
    IL_0029:  brfalse.s  IL_0032

    IL_002b:  ldarg.0
    IL_002c:  ldc.i4.1
    IL_002d:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0032:  ret
  } // end of method HysysProperties::TPFlashLiquid

  .method public hidebysig newslot virtual final 
          instance bool  TPFlashOverall(float64 T,
                                        float64 P) cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldarg.2
    IL_0003:  call       instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::TPFlash(float64,
                                                                                                                  float64)
    IL_0008:  ret
  } // end of method HysysProperties::TPFlashOverall

  .method public hidebysig newslot virtual final 
          instance bool  TPFlashVapor(float64 T,
                                      float64 P) cil managed
  {
    // Code size       51 (0x33)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.0
    IL_0020:  ldc.i4.1
    IL_0021:  ldarg.1
    IL_0022:  ldarg.2
    IL_0023:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluidPhase(valuetype Aspentech.HYSYS.PhaseType_enum,
                                                                                 valuetype Aspentech.HYSYS.FlashType_enum,
                                                                                 float64,
                                                                                 float64)
    IL_0028:  dup
    IL_0029:  brfalse.s  IL_0032

    IL_002b:  ldarg.0
    IL_002c:  ldc.i4.1
    IL_002d:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0032:  ret
  } // end of method HysysProperties::TPFlashVapor

  .method public hidebysig newslot virtual final 
          instance bool  TVFlash(float64 t,
                                 float64 Vf) cil managed
  {
    // Code size       50 (0x32)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.0
    IL_0002:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0007:  ldarg.1
    IL_0008:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_000d:  brtrue.s   IL_0017

    IL_000f:  ldarg.2
    IL_0010:  call       bool [mscorlib]System.Double::IsNaN(float64)
    IL_0015:  brfalse.s  IL_0019

    IL_0017:  ldc.i4.0
    IL_0018:  ret

    IL_0019:  ldarg.0
    IL_001a:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_001f:  ldc.i4.7
    IL_0020:  ldarg.1
    IL_0021:  ldarg.2
    IL_0022:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::FlashFluid(valuetype Aspentech.HYSYS.FlashType_enum,
                                                                            float64,
                                                                            float64)
    IL_0027:  dup
    IL_0028:  brfalse.s  IL_0031

    IL_002a:  ldarg.0
    IL_002b:  ldc.i4.1
    IL_002c:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_lastFlashSucceeded
    IL_0031:  ret
  } // end of method HysysProperties::TVFlash

  .method public hidebysig newslot virtual final 
          instance bool  TVFlashOverall(float64 T,
                                        float64 VF) cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.1
    IL_0002:  ldarg.2
    IL_0003:  call       instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::TVFlash(float64,
                                                                                                                  float64)
    IL_0008:  ret
  } // end of method HysysProperties::TVFlashOverall

  .method public hidebysig newslot virtual final 
          instance void  ReinitializeFluid() cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_ReleaseAll()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      string AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_path
    IL_000d:  call       instance void AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_Initialize(string)
    IL_0012:  ldarg.0
    IL_0013:  call       instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::ResetFluid()
    IL_0018:  pop
    IL_0019:  ret
  } // end of method HysysProperties::ReinitializeFluid

  .method public hidebysig newslot virtual final 
          instance bool  ResetFluid() cil managed
  {
    // Code size       22 (0x16)
    .maxstack  1
    .locals init (bool V_0)
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
      IL_0006:  callvirt   instance void Aspentech.HYSYS.PSVFluid::ResetFluid()
      IL_000b:  ldc.i4.1
      IL_000c:  stloc.0
      IL_000d:  leave.s    IL_0014

    }  // end .try
    catch [mscorlib]System.Object 
    {
      IL_000f:  pop
      IL_0010:  ldc.i4.0
      IL_0011:  stloc.0
      IL_0012:  leave.s    IL_0014

    }  // end handler
    IL_0014:  ldloc.0
    IL_0015:  ret
  } // end of method HysysProperties::ResetFluid

  .method public hidebysig newslot virtual final 
          instance bool  SetLiquidVaporRatio(float64 VF,
                                             float64 T,
                                             float64 P) cil managed
  {
    // Code size       25 (0x19)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  call       instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::TPFlash(float64,
                                                                                                                  float64)
    IL_0008:  brtrue.s   IL_000c

    IL_000a:  ldc.i4.0
    IL_000b:  ret

    IL_000c:  ldarg.0
    IL_000d:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0012:  ldarg.1
    IL_0013:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::SetLiquidVaporRatio(float64)
    IL_0018:  ret
  } // end of method HysysProperties::SetLiquidVaporRatio

  .method public hidebysig newslot virtual final 
          instance bool  SetLiquidVaporRatio(float64 VF) cil managed
  {
    // Code size       13 (0xd)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::SetLiquidVaporRatio(float64)
    IL_000c:  ret
  } // end of method HysysProperties::SetLiquidVaporRatio

  .method public hidebysig newslot virtual final 
          instance bool  StoreFireFractions([opt] valuetype [PSVSizingEngine]PSVSizingEngine.FluidPhaseSelection selectedPhase) cil managed
  {
    .param [1] = int32(0x00000000)
    // Code size       23 (0x17)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  ldarg.1
    IL_0007:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::StoreFireFractions(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
    IL_000c:  dup
    IL_000d:  brfalse.s  IL_0016

    IL_000f:  ldarg.0
    IL_0010:  ldc.i4.1
    IL_0011:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_hasFireFractions
    IL_0016:  ret
  } // end of method HysysProperties::StoreFireFractions

  .method public hidebysig newslot virtual final 
          instance bool  StoreOverallFractions() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::StoreOverallFractions()
    IL_000b:  ret
  } // end of method HysysProperties::StoreOverallFractions

  .method public hidebysig newslot virtual final 
          instance bool  RevertOverallFractions() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  callvirt   instance bool Aspentech.HYSYS.PSVFluid::ApplyOverallFractions()
    IL_000b:  ret
  } // end of method HysysProperties::RevertOverallFractions

  .method public hidebysig newslot virtual final 
          instance bool  ClearFireFractions() cil managed
  {
    // Code size       20 (0x14)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  callvirt   instance void Aspentech.HYSYS.PSVFluid::ClearFireFractions()
    IL_000b:  ldarg.0
    IL_000c:  ldc.i4.0
    IL_000d:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_hasFireFractions
    IL_0012:  ldc.i4.1
    IL_0013:  ret
  } // end of method HysysProperties::ClearFireFractions

  .method public hidebysig newslot specialname virtual final 
          instance bool  get_HasFireFractions() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_hasFireFractions
    IL_0006:  ret
  } // end of method HysysProperties::get_HasFireFractions

  .method private hidebysig newslot specialname virtual final 
          instance string  AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel.get_CXSDataPath() cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel::get_CXSDataPath
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      string AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_path
    IL_0006:  ret
  } // end of method HysysProperties::AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel.get_CXSDataPath

  .method private hidebysig newslot specialname virtual final 
          instance void  AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel.set_CXSDataPath(string 'value') cil managed
  {
    .override [AspenTech.EquipmentAnalysis.Infrastructure]AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel::set_CXSDataPath
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_ReleaseAll()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  call       instance void AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_Initialize(string)
    IL_000d:  ret
  } // end of method HysysProperties::AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel.set_CXSDataPath

  .method private hidebysig instance void 
          _ReleaseAll() cil managed
  {
    // Code size       89 (0x59)
    .maxstack  2
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0006:  brfalse.s  IL_0014

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_000e:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
    IL_0013:  pop
    IL_0014:  ldarg.0
    IL_0015:  ldfld      class Aspentech.HYSYS.PSVEmergScenario2 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refScenario
    IL_001a:  brfalse.s  IL_0028

    IL_001c:  ldarg.0
    IL_001d:  ldfld      class Aspentech.HYSYS.PSVEmergScenario2 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refScenario
    IL_0022:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
    IL_0027:  pop
    IL_0028:  ldarg.0
    IL_0029:  ldfld      class Aspentech.HYSYS.PSVStorageTank AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refTank
    IL_002e:  brfalse.s  IL_003c

    IL_0030:  ldarg.0
    IL_0031:  ldfld      class Aspentech.HYSYS.PSVStorageTank AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refTank
    IL_0036:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
    IL_003b:  pop
    IL_003c:  ldarg.0
    IL_003d:  ldnull
    IL_003e:  stfld      class Aspentech.HYSYS.PSVFluid AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refFluid
    IL_0043:  ldarg.0
    IL_0044:  ldnull
    IL_0045:  stfld      class Aspentech.HYSYS.PSVEmergScenario2 AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refScenario
    IL_004a:  ldarg.0
    IL_004b:  ldnull
    IL_004c:  stfld      class Aspentech.HYSYS.PSVStorageTank AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_refTank
    IL_0051:  ldarg.0
    IL_0052:  ldc.i4.1
    IL_0053:  stfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::disposedValue
    IL_0058:  ret
  } // end of method HysysProperties::_ReleaseAll

  .method family hidebysig newslot virtual 
          instance void  Dispose(bool disposing) cil managed
  {
    // Code size       17 (0x11)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::disposedValue
    IL_0006:  brtrue.s   IL_0010

    IL_0008:  ldarg.1
    IL_0009:  pop
    IL_000a:  ldarg.0
    IL_000b:  call       instance void AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::_ReleaseAll()
    IL_0010:  ret
  } // end of method HysysProperties::Dispose

  .method family hidebysig virtual instance void 
          Finalize() cil managed
  {
    .override [mscorlib]System.Object::Finalize
    // Code size       17 (0x11)
    .maxstack  2
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldc.i4.0
      IL_0002:  callvirt   instance void AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::Dispose(bool)
      IL_0007:  leave.s    IL_0010

    }  // end .try
    finally
    {
      IL_0009:  ldarg.0
      IL_000a:  call       instance void [mscorlib]System.Object::Finalize()
      IL_000f:  endfinally
    }  // end handler
    IL_0010:  ret
  } // end of method HysysProperties::Finalize

  .method public hidebysig newslot virtual final 
          instance void  Dispose() cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldc.i4.1
    IL_0002:  callvirt   instance void AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::Dispose(bool)
    IL_0007:  ldarg.0
    IL_0008:  call       void [mscorlib]System.GC::SuppressFinalize(object)
    IL_000d:  ret
  } // end of method HysysProperties::Dispose

  .property instance callconv(8) float64[]
          VaporComposition()
  {
    .get instance float64[] AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::get_VaporComposition()
  } // end of property HysysProperties::VaporComposition
  .property instance callconv(8) bool HasFireFractions()
  {
    .get instance bool AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::get_HasFireFractions()
  } // end of property HysysProperties::HasFireFractions
  .property instance callconv(8) string AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel.CXSDataPath()
  {
    .get instance string AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel.get_CXSDataPath()
    .set instance void AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties::AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel.set_CXSDataPath(string)
  } // end of property HysysProperties::AspenTech.EquipmentAnalysis.Infrastructure.IPSVCXSModel.CXSDataPath
} // end of class AspenTech.EquipmentAnalysis.Properties.AspenHysys.HysysProperties

.class public auto ansi sealed Aspentech.HYSYS.FlashType_enum
       extends [mscorlib]System.Enum
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor(string,
                                                                                                string) = ( 01 00 24 44 46 43 31 43 35 38 42 2D 41 45 39 46   // ..$DFC1C58B-AE9F
                                                                                                            2D 31 31 43 46 2D 38 45 42 32 2D 30 30 32 30 41   // -11CF-8EB2-0020A
                                                                                                            46 31 31 39 42 39 30 1E 41 73 70 65 6E 74 65 63   // F119B90.Aspentec
                                                                                                            68 2E 48 59 53 59 53 2E 46 6C 61 73 68 54 79 70   // h.HYSYS.FlashTyp
                                                                                                            65 5F 65 6E 75 6D 00 00 )                         // e_enum..
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Aspentech.HYSYS.FlashType_enum ftTPFlash = int32(0x00000001)
  .field public static literal valuetype Aspentech.HYSYS.FlashType_enum ftPHFlash = int32(0x00000002)
  .field public static literal valuetype Aspentech.HYSYS.FlashType_enum ftPSFlash = int32(0x00000003)
  .field public static literal valuetype Aspentech.HYSYS.FlashType_enum ftPVFlash = int32(0x00000004)
  .field public static literal valuetype Aspentech.HYSYS.FlashType_enum ftTHFlash = int32(0x00000005)
  .field public static literal valuetype Aspentech.HYSYS.FlashType_enum ftTVFlash = int32(0x00000007)
} // end of class Aspentech.HYSYS.FlashType_enum

.class interface public abstract auto ansi import Aspentech.HYSYS.PSVEmergScenario
       implements Aspentech.HYSYS._IViewable
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 32 33 33 33 43 43 38 46 2D 32 38 37 34   // ..$2333CC8F-2874
                                                                                                  2D 34 32 39 36 2D 42 35 44 35 2D 32 35 39 46 44   // -4296-B5D5-259FD
                                                                                                  31 39 41 44 42 44 33 00 00 )                      // 19ADBD3..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 6E 61 6D 65 00 00 )                      // ...name..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_3() runtime managed
  {
  } // end of method PSVEmergScenario::_VtblGap1_3

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method PSVEmergScenario::get_name

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_name([in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method PSVEmergScenario::set_name

  .property callconv(8) string name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance string Aspentech.HYSYS.PSVEmergScenario::get_name()
    .set instance void Aspentech.HYSYS.PSVEmergScenario::set_name(string)
  } // end of property PSVEmergScenario::name
} // end of class Aspentech.HYSYS.PSVEmergScenario

.class interface public abstract auto ansi import Aspentech.HYSYS.PSVEmergScenario2
       implements Aspentech.HYSYS.PSVEmergScenario
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 44 37 31 43 30 35 36 2D 42 38 34 45   // ..$FD71C056-B84E
                                                                                                  2D 34 31 36 30 2D 39 33 36 42 2D 33 41 34 46 42   // -4160-936B-3A4FB
                                                                                                  44 44 39 45 42 42 42 00 00 )                      // DD9EBBB..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 6E 61 6D 65 00 00 )                      // ...name..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_3() runtime managed
  {
  } // end of method PSVEmergScenario2::_VtblGap1_3

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method PSVEmergScenario2::get_name

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_name([in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method PSVEmergScenario2::set_name

  .method public specialname rtspecialname 
          instance void  _VtblGap2_13() runtime managed
  {
  } // end of method PSVEmergScenario2::_VtblGap2_13

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_WorkingFluid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 05 60 00 00 )                         // .....`..
  } // end of method PSVEmergScenario2::get_WorkingFluid

  .property callconv(8) string name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance string Aspentech.HYSYS.PSVEmergScenario2::get_name()
    .set instance void Aspentech.HYSYS.PSVEmergScenario2::set_name(string)
  } // end of property PSVEmergScenario2::name
  .property callconv(8) object WorkingFluid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 05 60 00 00 )                         // .....`..
    .get instance object Aspentech.HYSYS.PSVEmergScenario2::get_WorkingFluid()
  } // end of property PSVEmergScenario2::WorkingFluid
} // end of class Aspentech.HYSYS.PSVEmergScenario2

.class interface public abstract auto ansi import Aspentech.HYSYS.PSVFluid
       implements Aspentech.HYSYS._PSVFluid1
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 35 42 45 41 43 46 36 34 2D 45 38 34 35   // ..$5BEACF64-E845
                                                                                                  2D 34 45 32 34 2D 41 38 42 36 2D 41 46 42 44 33   // -4E24-A8B6-AFBD3
                                                                                                  32 30 36 42 45 33 30 00 00 )                      // 206BE30..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 6E 61 6D 65 00 00 )                      // ...name..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_3() runtime managed
  {
  } // end of method PSVFluid::_VtblGap1_3

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method PSVFluid::get_name

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_name([in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method PSVFluid::set_name

  .method public specialname rtspecialname 
          instance void  _VtblGap2_8() runtime managed
  {
  } // end of method PSVFluid::_VtblGap2_8

  .method public hidebysig newslot abstract virtual 
          instance bool  FlashFluid([in] valuetype Aspentech.HYSYS.FlashType_enum flashTypeValue,
                                    [in] float64 data1,
                                    [in] float64 data2) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::FlashFluid

  .method public hidebysig newslot abstract virtual 
          instance bool  FlashFluidPhase([in] valuetype Aspentech.HYSYS.PhaseType_enum Phase,
                                         [in] valuetype Aspentech.HYSYS.FlashType_enum flashTypeValue,
                                         [in] float64 data1,
                                         [in] float64 data2) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::FlashFluidPhase

  .method public hidebysig newslot abstract virtual 
          instance bool  IsentropicFlash([in] float64 Pressure) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::IsentropicFlash

  .method public hidebysig newslot abstract virtual 
          instance bool  IsenthalpicFlash([in] float64 Pressure) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::IsenthalpicFlash

  .method public hidebysig newslot abstract virtual 
          instance bool  StoreVaporFractions() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::StoreVaporFractions

  .method public hidebysig newslot abstract virtual 
          instance bool  StoreFireFractions([in] valuetype Aspentech.HYSYS.PSVFluidPhase_enum Phase) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::StoreFireFractions

  .method public hidebysig newslot abstract virtual 
          instance bool  ApplyFireFractions() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::ApplyFireFractions

  .method public hidebysig newslot abstract virtual 
          instance bool  StoreOverallFractions() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::StoreOverallFractions

  .method public hidebysig newslot abstract virtual 
          instance bool  ApplyOverallFractions() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::ApplyOverallFractions

  .method public hidebysig newslot abstract virtual 
          instance bool  SetLiquidVaporRatio([in] float64 Ratio) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::SetLiquidVaporRatio

  .method public hidebysig newslot abstract virtual 
          instance void  ResetFluid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::ResetFluid

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Pressure() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_Pressure

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Temperature() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_Temperature

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_PhaseMassFraction([in] valuetype Aspentech.HYSYS.PSVFluidPhase_enum Phase) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_PhaseMassFraction

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_PhaseMassDensity([in] valuetype Aspentech.HYSYS.PSVFluidPhase_enum Phase) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_PhaseMassDensity

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_PhaseMassEnthalpy([in] valuetype Aspentech.HYSYS.PSVFluidPhase_enum Phase) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_PhaseMassEnthalpy

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_PhaseMassEntropy([in] valuetype Aspentech.HYSYS.PSVFluidPhase_enum Phase) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_PhaseMassEntropy

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_PhaseMassHeatCapacity([in] valuetype Aspentech.HYSYS.PSVFluidPhase_enum Phase) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_PhaseMassHeatCapacity

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_PhaseMolecularWeight([in] valuetype Aspentech.HYSYS.PSVFluidPhase_enum Phase) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_PhaseMolecularWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_PhaseViscosity([in] valuetype Aspentech.HYSYS.PSVFluidPhase_enum Phase) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_PhaseViscosity

  .method public specialname rtspecialname 
          instance void  _VtblGap3_2() runtime managed
  {
  } // end of method PSVFluid::_VtblGap3_2

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_LiquidSurfaceTension() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_LiquidSurfaceTension

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_VaporFraction() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_VaporFraction

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_VaporZFactor() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_VaporZFactor

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_IdealCpCv() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_IdealCpCv

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_SemiIdealCpCv() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1A 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_SemiIdealCpCv

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_RealCpCv() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1B 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_RealCpCv

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_SaturationPressure() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1C 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_SaturationPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_HeatOfVaporization() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1D 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_HeatOfVaporization

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_TrueCriticalPressure() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1E 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_TrueCriticalPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_PseudoCriticalPressure() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1F 00 04 60 00 00 )                         // .....`..
  } // end of method PSVFluid::get_PseudoCriticalPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_PhaseTrueCriticalPressure([in] valuetype Aspentech.HYSYS.PSVFluidPhase_enum Phase) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 04 60 00 00 )                         // .. ..`..
  } // end of method PSVFluid::get_PhaseTrueCriticalPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_PhasePseudoCriticalPressure([in] valuetype Aspentech.HYSYS.PSVFluidPhase_enum Phase) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 04 60 00 00 )                         // ..!..`..
  } // end of method PSVFluid::get_PhasePseudoCriticalPressure

  .method public hidebysig newslot specialname abstract virtual 
          instance int32  get_NumComponents() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 22 00 04 60 00 00 )                         // .."..`..
  } // end of method PSVFluid::get_NumComponents

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_ComponentName([in] int32 pos) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 23 00 04 60 00 00 )                         // ..#..`..
  } // end of method PSVFluid::get_ComponentName

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_ComponentMolecularWeight([in] int32 pos) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 04 60 00 00 )                         // ..$..`..
  } // end of method PSVFluid::get_ComponentMolecularWeight

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_Composition([in] int32 pos) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 25 00 04 60 00 00 )                         // ..%..`..
  } // end of method PSVFluid::get_Composition

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_StoredComposition([in] int32 pos) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 26 00 04 60 00 00 )                         // ..&..`..
  } // end of method PSVFluid::get_StoredComposition

  .method public hidebysig newslot specialname abstract virtual 
          instance float64  get_VaporComposition([in] int32 pos) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 27 00 04 60 00 00 )                         // ..'..`..
  } // end of method PSVFluid::get_VaporComposition

  .method public hidebysig newslot abstract virtual 
          instance void  ClearFireFractions() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 05 60 00 00 )                         // .....`..
  } // end of method PSVFluid::ClearFireFractions

  .property callconv(8) string name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance string Aspentech.HYSYS.PSVFluid::get_name()
    .set instance void Aspentech.HYSYS.PSVFluid::set_name(string)
  } // end of property PSVFluid::name
  .property callconv(8) float64 Pressure()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_Pressure()
  } // end of property PSVFluid::Pressure
  .property callconv(8) float64 Temperature()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_Temperature()
  } // end of property PSVFluid::Temperature
  .property callconv(8) float64 PhaseMassFraction(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassFraction(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  } // end of property PSVFluid::PhaseMassFraction
  .property callconv(8) float64 PhaseMassDensity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassDensity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  } // end of property PSVFluid::PhaseMassDensity
  .property callconv(8) float64 PhaseMassEnthalpy(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassEnthalpy(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  } // end of property PSVFluid::PhaseMassEnthalpy
  .property callconv(8) float64 PhaseMassEntropy(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassEntropy(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  } // end of property PSVFluid::PhaseMassEntropy
  .property callconv(8) float64 PhaseMassHeatCapacity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 11 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMassHeatCapacity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  } // end of property PSVFluid::PhaseMassHeatCapacity
  .property callconv(8) float64 PhaseMolecularWeight(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 12 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseMolecularWeight(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  } // end of property PSVFluid::PhaseMolecularWeight
  .property callconv(8) float64 PhaseViscosity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 13 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseViscosity(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  } // end of property PSVFluid::PhaseViscosity
  .property callconv(8) float64 LiquidSurfaceTension()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 16 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_LiquidSurfaceTension()
  } // end of property PSVFluid::LiquidSurfaceTension
  .property callconv(8) float64 VaporFraction()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 17 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_VaporFraction()
  } // end of property PSVFluid::VaporFraction
  .property callconv(8) float64 VaporZFactor()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 18 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_VaporZFactor()
  } // end of property PSVFluid::VaporZFactor
  .property callconv(8) float64 IdealCpCv()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 19 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_IdealCpCv()
  } // end of property PSVFluid::IdealCpCv
  .property callconv(8) float64 SemiIdealCpCv()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1A 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_SemiIdealCpCv()
  } // end of property PSVFluid::SemiIdealCpCv
  .property callconv(8) float64 RealCpCv()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1B 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_RealCpCv()
  } // end of property PSVFluid::RealCpCv
  .property callconv(8) float64 SaturationPressure()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1C 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_SaturationPressure()
  } // end of property PSVFluid::SaturationPressure
  .property callconv(8) float64 HeatOfVaporization()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1D 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_HeatOfVaporization()
  } // end of property PSVFluid::HeatOfVaporization
  .property callconv(8) float64 TrueCriticalPressure()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1E 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_TrueCriticalPressure()
  } // end of property PSVFluid::TrueCriticalPressure
  .property callconv(8) float64 PseudoCriticalPressure()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 1F 00 04 60 00 00 )                         // .....`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_PseudoCriticalPressure()
  } // end of property PSVFluid::PseudoCriticalPressure
  .property callconv(8) float64 PhaseTrueCriticalPressure(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 20 00 04 60 00 00 )                         // .. ..`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_PhaseTrueCriticalPressure(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  } // end of property PSVFluid::PhaseTrueCriticalPressure
  .property callconv(8) float64 PhasePseudoCriticalPressure(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 21 00 04 60 00 00 )                         // ..!..`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_PhasePseudoCriticalPressure(valuetype Aspentech.HYSYS.PSVFluidPhase_enum)
  } // end of property PSVFluid::PhasePseudoCriticalPressure
  .property callconv(8) int32 NumComponents()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 22 00 04 60 00 00 )                         // .."..`..
    .get instance int32 Aspentech.HYSYS.PSVFluid::get_NumComponents()
  } // end of property PSVFluid::NumComponents
  .property callconv(8) string ComponentName(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 23 00 04 60 00 00 )                         // ..#..`..
    .get instance string Aspentech.HYSYS.PSVFluid::get_ComponentName(int32)
  } // end of property PSVFluid::ComponentName
  .property callconv(8) float64 ComponentMolecularWeight(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 24 00 04 60 00 00 )                         // ..$..`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_ComponentMolecularWeight(int32)
  } // end of property PSVFluid::ComponentMolecularWeight
  .property callconv(8) float64 Composition(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 25 00 04 60 00 00 )                         // ..%..`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_Composition(int32)
  } // end of property PSVFluid::Composition
  .property callconv(8) float64 StoredComposition(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 26 00 04 60 00 00 )                         // ..&..`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_StoredComposition(int32)
  } // end of property PSVFluid::StoredComposition
  .property callconv(8) float64 VaporComposition(int32)
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 27 00 04 60 00 00 )                         // ..'..`..
    .get instance float64 Aspentech.HYSYS.PSVFluid::get_VaporComposition(int32)
  } // end of property PSVFluid::VaporComposition
} // end of class Aspentech.HYSYS.PSVFluid

.class public auto ansi sealed Aspentech.HYSYS.PSVFluidPhase_enum
       extends [mscorlib]System.Enum
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor(string,
                                                                                                string) = ( 01 00 24 44 46 43 31 43 35 38 42 2D 41 45 39 46   // ..$DFC1C58B-AE9F
                                                                                                            2D 31 31 43 46 2D 38 45 42 32 2D 30 30 32 30 41   // -11CF-8EB2-0020A
                                                                                                            46 31 31 39 42 39 30 22 41 73 70 65 6E 74 65 63   // F119B90"Aspentec
                                                                                                            68 2E 48 59 53 59 53 2E 50 53 56 46 6C 75 69 64   // h.HYSYS.PSVFluid
                                                                                                            50 68 61 73 65 5F 65 6E 75 6D 00 00 )             // Phase_enum..
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Aspentech.HYSYS.PSVFluidPhase_enum fpVapour = int32(0x00000000)
  .field public static literal valuetype Aspentech.HYSYS.PSVFluidPhase_enum fpLiq1 = int32(0x00000001)
  .field public static literal valuetype Aspentech.HYSYS.PSVFluidPhase_enum fpLiq2 = int32(0x00000002)
  .field public static literal valuetype Aspentech.HYSYS.PSVFluidPhase_enum fpFeed = int32(0x00000003)
  .field public static literal valuetype Aspentech.HYSYS.PSVFluidPhase_enum fpMixedLiquid = int32(0x00000004)
  .field public static literal valuetype Aspentech.HYSYS.PSVFluidPhase_enum fpSolid = int32(0x00000005)
} // end of class Aspentech.HYSYS.PSVFluidPhase_enum

.class interface public abstract auto ansi import Aspentech.HYSYS.PSVStorageTank
       implements Aspentech.HYSYS._IViewable
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 43 30 46 38 34 46 44 43 2D 39 33 37 42   // ..$C0F84FDC-937B
                                                                                                  2D 34 31 37 42 2D 42 33 36 35 2D 32 35 32 38 41   // -417B-B365-2528A
                                                                                                  41 37 34 46 38 41 34 00 00 )                      // A74F8A4..
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 6E 61 6D 65 00 00 )                      // ...name..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_3() runtime managed
  {
  } // end of method PSVStorageTank::_VtblGap1_3

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method PSVStorageTank::get_name

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_name([in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method PSVStorageTank::set_name

  .method public specialname rtspecialname 
          instance void  _VtblGap2_13() runtime managed
  {
  } // end of method PSVStorageTank::_VtblGap2_13

  .method public hidebysig newslot specialname abstract virtual 
          instance object 
          marshal( iunknown ) 
          get_WorkingFluid() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
  } // end of method PSVStorageTank::get_WorkingFluid

  .property callconv(8) string name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance string Aspentech.HYSYS.PSVStorageTank::get_name()
    .set instance void Aspentech.HYSYS.PSVStorageTank::set_name(string)
  } // end of property PSVStorageTank::name
  .property callconv(8) object WorkingFluid()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 04 60 00 00 )                         // .....`..
    .get instance object Aspentech.HYSYS.PSVStorageTank::get_WorkingFluid()
  } // end of property PSVStorageTank::WorkingFluid
} // end of class Aspentech.HYSYS.PSVStorageTank

.class public auto ansi sealed Aspentech.HYSYS.PhaseType_enum
       extends [mscorlib]System.Enum
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor(string,
                                                                                                string) = ( 01 00 24 44 46 43 31 43 35 38 42 2D 41 45 39 46   // ..$DFC1C58B-AE9F
                                                                                                            2D 31 31 43 46 2D 38 45 42 32 2D 30 30 32 30 41   // -11CF-8EB2-0020A
                                                                                                            46 31 31 39 42 39 30 1E 41 73 70 65 6E 74 65 63   // F119B90.Aspentec
                                                                                                            68 2E 48 59 53 59 53 2E 50 68 61 73 65 54 79 70   // h.HYSYS.PhaseTyp
                                                                                                            65 5F 65 6E 75 6D 00 00 )                         // e_enum..
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Aspentech.HYSYS.PhaseType_enum ptVapourPhase = int32(0x00000000)
  .field public static literal valuetype Aspentech.HYSYS.PhaseType_enum ptLiquidPhase = int32(0x00000001)
  .field public static literal valuetype Aspentech.HYSYS.PhaseType_enum ptLiquid2Phase = int32(0x00000002)
  .field public static literal valuetype Aspentech.HYSYS.PhaseType_enum ptCombinedLiquidPhase = int32(0x00000003)
  .field public static literal valuetype Aspentech.HYSYS.PhaseType_enum ptSolidPhase = int32(0x00000004)
  .field public static literal valuetype Aspentech.HYSYS.PhaseType_enum ptCombinedPhase = int32(0x00000005)
  .field public static literal valuetype Aspentech.HYSYS.PhaseType_enum ptPolymerPhase = int32(0x00000006)
  .field public static literal valuetype Aspentech.HYSYS.PhaseType_enum ptUnknownPhase = int32(0x00000007)
} // end of class Aspentech.HYSYS.PhaseType_enum

.class interface public abstract auto ansi import Aspentech.HYSYS._IRoot
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 44 46 43 31 43 35 37 31 2D 41 45 39 46   // ..$DFC1C571-AE9F
                                                                                                  2D 31 31 43 46 2D 38 45 42 32 2D 30 30 32 30 41   // -11CF-8EB2-0020A
                                                                                                  46 31 31 39 42 39 30 00 00 )                      // F119B90..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
} // end of class Aspentech.HYSYS._IRoot

.class interface public abstract auto ansi import Aspentech.HYSYS._IViewable
       implements Aspentech.HYSYS._IRoot
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 6E 61 6D 65 00 00 )                      // ...name..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 44 46 43 31 43 35 37 32 2D 41 45 39 46   // ..$DFC1C572-AE9F
                                                                                                  2D 31 31 43 46 2D 38 45 42 32 2D 30 30 32 30 41   // -11CF-8EB2-0020A
                                                                                                  46 31 31 39 42 39 30 00 00 )                      // F119B90..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_3() runtime managed
  {
  } // end of method _IViewable::_VtblGap1_3

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method _IViewable::get_name

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_name([in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method _IViewable::set_name

  .property callconv(8) string name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance string Aspentech.HYSYS._IViewable::get_name()
    .set instance void Aspentech.HYSYS._IViewable::set_name(string)
  } // end of property _IViewable::name
} // end of class Aspentech.HYSYS._IViewable

.class interface public abstract auto ansi import Aspentech.HYSYS._PSVFluid1
       implements Aspentech.HYSYS._IViewable
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Reflection.DefaultMemberAttribute::.ctor(string) = ( 01 00 04 6E 61 6D 65 00 00 )                      // ...name..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 44 35 38 33 35 30 30 32 2D 44 36 30 46   // ..$D5835002-D60F
                                                                                                  2D 34 39 43 36 2D 41 32 41 32 2D 35 36 31 37 31   // -49C6-A2A2-56171
                                                                                                  43 39 41 43 35 32 46 00 00 )                      // C9AC52F..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeIdentifierAttribute::.ctor() = ( 01 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  _VtblGap1_3() runtime managed
  {
  } // end of method _PSVFluid1::_VtblGap1_3

  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_name() runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method _PSVFluid1::get_name

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_name([in] string  marshal( bstr) retval) runtime managed internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
  } // end of method _PSVFluid1::set_name

  .property callconv(8) string name()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance string Aspentech.HYSYS._PSVFluid1::get_name()
    .set instance void Aspentech.HYSYS._PSVFluid1::set_name(string)
  } // end of property _PSVFluid1::name
} // end of class Aspentech.HYSYS._PSVFluid1


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file orig.ildasm.res
