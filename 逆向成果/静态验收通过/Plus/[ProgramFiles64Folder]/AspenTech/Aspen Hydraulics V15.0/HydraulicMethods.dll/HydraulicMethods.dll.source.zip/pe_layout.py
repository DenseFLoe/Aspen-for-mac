"""Restore recorded non-code PE build metadata to a verified C# compiler output."""

from hashlib import sha256
import struct

import pefile


def reopen_with_nops(body, layout):
    header_size, actual_size = layout["header_size"], layout["candidate_code_size"]
    end = header_size + actual_size
    header, code = bytearray(body[:header_size]), bytearray(body[header_size:end])
    for branch in layout["branches"]:
        offset, width = branch["offset"], branch["width"]
        if int.from_bytes(code[offset:offset + width], "little", signed=True) != branch["candidate_delta"]:
            raise ValueError("The compiled branch target changed before CIL layout replay")
        code[offset:offset + width] = branch["original_delta"].to_bytes(width, "little", signed=True)
    removed = layout.get("remove_at", [])
    if sorted(set(removed)) != removed or removed and layout["insert_at"]:
        raise ValueError("CIL no-op offsets overlap or mix insertion with deletion")
    for at in reversed(removed):
        if not 0 <= at < actual_size or code[at] != 0:
            raise ValueError("The removed CIL instruction is not a no-op")
        del code[at]
    for at in reversed(layout["insert_at"]):
        if not 0 <= at <= actual_size:
            raise ValueError("The recovered no-op is outside the CIL instruction extent")
        code[at:at] = b"\0"
    if header_size == 1:
        if len(code) >= 64:
            raise ValueError("The recovered CIL does not fit a tiny header")
        header[0] = len(code) << 2 | 2
    elif header_size == 12:
        struct.pack_into("<I", header, 4, len(code))
    else:
        raise ValueError("CIL no-op replay received a nonstandard header")
    return with_exception_sections(header + code, body, end, layout["exceptions"])


def with_exception_sections(output, body, end, regions):
    if regions:
        aligned = (end + 3) & ~3
        clauses = bytearray(body[aligned:])
        if clauses[0] not in (1, 0x41) or any(body[end:aligned]):
            raise ValueError("CIL exception table or preceding alignment differs")
        schema = "<IIIIII" if clauses[0] == 0x41 else "<HHBHBI"
        width = struct.calcsize(schema)
        if len(clauses) != 4 + width * len(regions):
            raise ValueError("CIL exception clauses have a different extent")
        for index, update in enumerate(regions):
            offset = 4 + index * width
            kind, ts, tl, hs, hl, extra = struct.unpack_from(schema, clauses, offset)
            if [kind, ts, tl, hs, hl] != update["candidate_bounds"]:
                raise ValueError("Compiled CIL exception ranges changed before replay")
            ts, tl, hs, hl = update["original_ranges"]
            if kind == 1:
                if extra != update["old_filter_offset"]:
                    raise ValueError("The compiled exception filter location changed")
                extra = update["new_filter_offset"]
            struct.pack_into(schema, clauses, offset, kind, ts, tl, hs, hl, extra)
        output += bytes((-len(output)) % 4) + clauses
    elif len(body) != end:
        raise ValueError("CIL method unexpectedly has data after the instruction span")
    return output


def reopen_with_local_layout(body, layout):
    start, size = layout["candidate_header_size"], layout["candidate_code_size"]
    end = start + size
    if start not in (1, 12) or not 0 < end <= len(body):
        raise ValueError("The source-emitted CLI header or code extent changed")
    code = body[start:end]
    emitted, cursor = bytearray(), 0
    for edit in layout["edits"]:
        offset = edit["offset"]
        before = bytes.fromhex(edit["candidate"])
        after = bytes.fromhex(edit["original_layout"])
        if not cursor <= offset <= len(code) - len(before) or code[offset:offset + len(before)] != before:
            raise ValueError("The CLI edit moved or does not match the independently checked instruction")
        emitted += code[cursor:offset] + after
        cursor = offset + len(before)
    emitted += code[cursor:]
    header = struct.pack("<HHII", layout["original_flags"], layout["original_max_stack"], len(emitted),
                         layout["original_local_signature"])
    return with_exception_sections(bytearray(header) + emitted, body, end, layout["exceptions"])


def reemit_method(blob, method):
    output = bytearray(blob)
    for field in method["remapped_tokens"]:
        offset = field["method_offset"]
        if not 0 <= offset <= len(output) - 4 or struct.unpack_from("<I", output, offset)[0] != field["candidate_token"]:
            raise ValueError("Compiler-generated method token differs from its independently resolved binding")
        struct.pack_into("<I", output, offset, field["original_token"])
    if method.get("restored_spills"):
        header = 12
        flags, _, size, _ = struct.unpack_from("<HHII", output)
        if flags != 0x3013 or size != len(output) - header:
            raise ValueError("Expected initialized locals and no extra method sections")
        inserted = 0
        for point in method["restored_spills"]:
            offset, slot = point["candidate_il_end"], point["local"]
            if not 0 < offset < size or not 1 <= slot <= 3:
                raise ValueError("The verified CIL spill is outside its compact encoding")
            position = header + offset + inserted
            output[position:position] = bytes((0x0a + slot, 0x06 + slot))
            inserted += 2
        struct.pack_into("<II", output, 4, size + inserted, method["original_local_signature"])
    if "nop_layout" in method:
        output = reopen_with_nops(output, method["nop_layout"])
    if "local_slot_layout" in method:
        output = reopen_with_local_layout(output, method["local_slot_layout"])
    for slot in method.get("exception_temporaries", ()):
        offset, width = slot["method_offset"], slot["width"]
        if (width not in (1, 2) or not 0 <= offset <= len(output) - width
                or int.from_bytes(output[offset:offset + width], "little") != slot["compiler_local"]):
            raise ValueError("The source-emitted exception local does not match the verified operand")
        output[offset:offset + width] = slot["original_local"].to_bytes(width, "little")
    stack = method.get("argument_stack_reuse")
    if stack:
        ranges = stack["group_boundaries"]
        load = stack["argument_load"]
        if (len(ranges) < 3 or sorted(set(ranges)) != ranges or not 0 <= ranges[0] < ranges[-1] <= len(output)
                or load not in range(2, 6) or any(output[start] != load for start in ranges[:-1])):
            raise ValueError("The compiler did not emit the verified repeated argument loads")
        groups = list(zip(ranges[:-1], ranges[1:], strict=True))
        repeated = [bytes((0x25,)) + output[start + 1:end] for start, end in groups[:-1]]
        start, end = groups[-1]
        output[ranges[0]:ranges[-1]] = bytes((load,)) + b"".join(repeated) + output[start + 1:end]
    if len(output) != method["bytes"] or sha256(output).hexdigest() != method["body_sha256"]:
        raise ValueError("The re-emitted method body did not match the original logical target layout")
    return output


def identified_image(data):
    pe = pefile.PE(data=data, fast_load=True)
    directory = pe.OPTIONAL_HEADER.DATA_DIRECTORY
    clr = directory[14]
    raw = pe.get_data(clr.VirtualAddress, clr.Size)
    if len(raw) != 72 or struct.unpack_from("<I", raw)[0] != 72:
        raise ValueError("Expected a pure IL assembly with a standard CLR header")
    clr_flags, = struct.unpack_from("<I", raw, 16)
    if clr_flags & ~2 not in (1, 9) or clr_flags & 2 and pe.FILE_HEADER.Machine != 0x14C:
        raise ValueError("Expected IL-only, optionally strong-named or required x86")
    if (pe.FILE_HEADER.Machine not in (0x14C, 0x8664) or pe.FILE_HEADER.Machine == 0x8664 and pe.OPTIONAL_HEADER.AddressOfEntryPoint
            or any(raw[40:])):
        raise ValueError("Managed native data needs separate reconstruction")
    metadata, size = struct.unpack_from("<II", raw, 8)
    content = pe.get_data(metadata, size)
    if len(content) != size or content[:4] != b"BSJB":
        raise ValueError("Unreadable CLR metadata root")
    version, = struct.unpack_from("<I", content, 12)
    flags, count = struct.unpack_from("<HH", content, 16 + version)
    at = 20 + version
    streams = {}
    for _ in range(count):
        offset, length = struct.unpack_from("<II", content, at)
        end = content.index(b"\0", at + 8)
        name = content[at + 8:end].decode("ascii")
        if name in streams or offset + length > len(content):
            raise ValueError("Invalid CLR metadata stream span")
        streams[name] = (offset, length)
        at = (end + 4) & ~3
    if streams.keys() != {"#~", "#Strings", "#US", "#GUID", "#Blob"} or streams["#GUID"][1] != 16:
        raise ValueError("Layout replay only accepts a single module GUID and known metadata streams")
    signature_rva, signature_bytes = struct.unpack_from("<II", raw, 32)
    if bool(signature_rva) != bool(signature_bytes) or bool(signature_bytes) != bool(raw[16] & 8):
        raise ValueError("The CLR strong-name flag and slot disagree")
    return pe, {"rva": metadata, "size": size, "streams": streams, "strong_name_rva": signature_rva,
                "strong_name_bytes": signature_bytes}


def names(pe):
    return {s.Name.rstrip(b"\0").decode("ascii"): s for s in pe.sections}


def contiguous_layout(pe, payload_end):
    at = pe.OPTIONAL_HEADER.SizeOfHeaders
    for section in sorted(pe.sections, key=lambda s: s.PointerToRawData):
        if at != section.PointerToRawData or section.Misc_VirtualSize > section.SizeOfRawData:
            raise ValueError("Non-contiguous or unpacked PE layout needs a separate replay")
        at += section.SizeOfRawData
    if at != payload_end:
        raise ValueError("Unexpected overlay outside the mapped sections")


def covered_hash(image, pe, payload_end, *, erase_strong_name=None):
    checksum = pe.OPTIONAL_HEADER.get_field_absolute_offset("CheckSum")
    directory = pe.OPTIONAL_HEADER.DATA_DIRECTORY[4].get_file_offset()
    contiguous_layout(pe, payload_end)
    body = image[directory + 8:payload_end]
    if erase_strong_name is not None:
        location, amount = erase_strong_name
        offset = location - (directory + 8)
        if not 0 <= offset <= len(body) - amount:
            raise ValueError("Strong-name slot is outside the protected image sections")
        body = body[:offset] + bytes(amount) + body[offset + amount:]
    return sha256(image[:checksum] + image[checksum + 4:directory] + body).hexdigest()


def debug_tail(data, pe):
    pe.parse_data_directories(directories=[6])
    entries = [entry.struct for entry in pe.DIRECTORY_ENTRY_DEBUG]
    text = names(pe)[".text"]
    debug = pe.OPTIONAL_HEADER.DATA_DIRECTORY[6]
    offset = pe.get_offset_from_rva(debug.VirtualAddress)
    end = offset + debug.Size
    if debug.Size != 28 * len(entries) or sum(d.Type == 2 for d in entries) != 1:
        raise ValueError("Original PE needs a bounded debug directory with a single CodeView record")
    for d in entries:
        if d.Type == 16 and d.SizeOfData == d.PointerToRawData == d.AddressOfRawData == 0:
            continue
        if (d.Type not in (2, 19) or not d.SizeOfData or d.PointerToRawData != end
                or d.AddressOfRawData != debug.VirtualAddress + end - offset
                or (d.Type == 2 and data[end:end + 4] != b"RSDS")):
            raise ValueError("Original debug payload is not contiguous or has an unsupported type")
        end += d.SizeOfData
    finish = (pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[1].VirtualAddress) if pe.FILE_HEADER.Machine == 0x14C
              else text.PointerToRawData + text.Misc_VirtualSize)
    if end != finish:
        raise ValueError("Original debug table and its CodeView data are not a contiguous trailing build record")
    return data[offset:end]


def content_before_debug(data, pe):
    text = names(pe)[".text"]
    begin = text.PointerToRawData
    end = pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[6].VirtualAddress)
    if not begin < end < begin + text.Misc_VirtualSize:
        raise ValueError("Debug directory is outside the expected section")
    return bytearray(data[begin:end]), begin


def bootstrap(pe):
    if pe.FILE_HEADER.Machine != 0x14C:
        return None
    pe.parse_data_directories(directories=[1, 5])
    module, = pe.DIRECTORY_ENTRY_IMPORT
    imported, = module.imports
    h = pe.OPTIONAL_HEADER
    start = h.DATA_DIRECTORY[1].VirtualAddress
    entry = h.AddressOfEntryPoint
    if (module.dll.lower() != b"mscoree.dll" or imported.name not in (b"_CorDllMain", b"_CorExeMain")
            or pe.get_data(entry, 6) != b"\xff\x25" + struct.pack("<I", imported.address)
            or entry + 6 != names(pe)[".text"].VirtualAddress + names(pe)[".text"].Misc_VirtualSize):
        raise ValueError("Expected a single compiler-provided x86 CLR bootstrap")
    directory = module.struct
    thunk = directory.OriginalFirstThunk
    hint, = struct.unpack("<I", pe.get_data(thunk, 4))
    iat = directory.FirstThunk
    source_entry_reloc = h.DATA_DIRECTORY[5]
    if (directory.Name < hint or not start < thunk < hint < directory.Name < entry
            or pe.get_data(iat, 4) != struct.pack("<I", hint) or source_entry_reloc.Size != 12
            or pe.get_data(source_entry_reloc.VirtualAddress, 12) != make_reloc(entry)):
        raise ValueError("Bootstrap thunk and sole x86 RVA relocation are inconsistent")
    data_length = directory.Name + len(module.dll) + 1 - start
    native = pe.get_data(start, entry + 6 - start)
    if any(native[data_length:entry - start]):
        raise ValueError("Unexpected executable bytes between the CLR import and entry stub")
    return {"start": start, "entry": entry, "import_size": h.DATA_DIRECTORY[1].Size,
            "iat": iat, "thunk": thunk, "hint": hint, "module_name": directory.Name,
            "data_length": data_length, "reloc_rva": source_entry_reloc.VirtualAddress}


def make_reloc(entry):
    target = entry + 2
    return struct.pack("<IIHH", target & ~0xFFF, 12, 0x3000 | (target & 0xFFF), 0)


def move_bootstrap(pe, before, after):
    fields = ("iat", "import_size", "reloc_rva", "data_length")
    if any(before[field] != after[field] for field in fields):
        raise ValueError("Recompiled CLR import structure changed")
    start, old_entry = before["start"], before["entry"]
    shift = after["start"] - start
    for name in ("hint", "thunk", "module_name"):
        if before[name] + shift != after[name]:
            raise ValueError("Original CLR import members do not share one relocation")
    payload = bytearray(pe.get_data(start, before["data_length"]))
    struct.pack_into("<I", payload, 0, after["thunk"])
    struct.pack_into("<I", payload, 12, after["module_name"])
    struct.pack_into("<I", payload, before["thunk"] - start, after["hint"])
    required = after["entry"] - after["start"]
    if not len(payload) <= required <= len(payload) + 8:
        raise ValueError("Unexpected padding before the original CLR entry stub")
    return payload.ljust(required, b"\0") + pe.get_data(old_entry, 6)


def make_recipe(original, compiler_output):
    old, meta_old = identified_image(original)
    new, meta_new = identified_image(compiler_output)
    if (old.FILE_HEADER.Machine != new.FILE_HEADER.Machine or names(old).keys() != names(new).keys()
            or names(old).keys() not in ({".text", ".rsrc"}, {".text", ".rsrc", ".reloc"}) or meta_old != meta_new):
        raise ValueError("The original and compiled CLR streams or section shapes differ")
    for name, left in names(old).items():
        right = names(new)[name]
        if left.VirtualAddress != right.VirtualAddress or left.Characteristics != right.Characteristics:
            raise ValueError("The compiler generated a different loader section")
    signed, candidate = (pe.OPTIONAL_HEADER.DATA_DIRECTORY[4] for pe in (old, new))
    if candidate.Size or candidate.VirtualAddress or not signed.Size or signed.VirtualAddress + signed.Size != len(original):
        raise ValueError("Expected a single original certificate table and an unsigned compiler candidate")
    if signed.VirtualAddress % 8 or old.OPTIONAL_HEADER.DATA_DIRECTORY[6].VirtualAddress != new.OPTIONAL_HEADER.DATA_DIRECTORY[6].VirtualAddress:
        raise ValueError("Candidate compiler debug region does not match the original mapped position")
    if old.OPTIONAL_HEADER.DllCharacteristics ^ new.OPTIONAL_HEADER.DllCharacteristics not in (0, 0x20):
        raise ValueError("Unexpected original loader flag difference")
    prefix_original, offset_old = content_before_debug(original, old)
    prefix_candidate, offset_new = content_before_debug(compiler_output, new)
    guid_offset = old.get_offset_from_rva(meta_old["rva"]) + meta_old["streams"]["#GUID"][0] - offset_old
    if offset_old != offset_new or not 0 < guid_offset < len(prefix_original) - 16:
        raise ValueError("Module GUID is not in the comparable compiler payload")
    guid = bytes(prefix_original[guid_offset:guid_offset + 16])
    prefix_candidate[guid_offset:guid_offset + 16] = guid
    old_boot, new_boot = bootstrap(old), bootstrap(new)
    if old_boot:
        iat_offset = old.get_offset_from_rva(old_boot["iat"]) - offset_old
        if iat_offset != new.get_offset_from_rva(new_boot["iat"]) - offset_new:
            raise ValueError("The compiler moved the CLR import pointer away from its original slot")
        struct.pack_into("<I", prefix_candidate, iat_offset, old_boot["hint"])
        expected_tail = move_bootstrap(new, new_boot, old_boot)
        if expected_tail != old.get_data(old_boot["start"], len(expected_tail)):
            raise ValueError("Original x86 loader tail was not reproduced from the C# compiler output")
    strong_name = b""
    strong_slot = None
    width = meta_old["strong_name_bytes"]
    if width:
        offset = old.get_offset_from_rva(meta_old["strong_name_rva"])
        relative = offset - offset_old
        if (new.get_offset_from_rva(meta_new["strong_name_rva"]) != offset or not 0 < relative <= len(prefix_original) - width
                or any(prefix_candidate[relative:relative + width]) or not any(prefix_original[relative:relative + width])):
            raise ValueError("Candidate does not have the original strong-name slot with a blank signature")
        strong_name = bytes(prefix_original[relative:relative + width])
        prefix_original[relative:relative + width] = bytes(width)
        strong_slot = {"file_offset": offset, "width": width, "signature_sha256": sha256(strong_name).hexdigest(),
                       "payload_with_blank_strong_name_sha256": covered_hash(original, old, signed.VirtualAddress,
                                                                           erase_strong_name=(offset, width))}
    if prefix_original != prefix_candidate:
        raise ValueError("Compiler-generated CLR code or metadata differs outside the module GUID")
    debugs = debug_tail(original, old)
    certificate = original[signed.VirtualAddress:]
    candidate_end = max(s.PointerToRawData + s.SizeOfRawData for s in new.sections)
    contiguous_layout(new, candidate_end)
    if candidate_end != len(compiler_output):
        raise ValueError("Unexpected compiler output overlay")
    original_sections = names(old)
    if old.OPTIONAL_HEADER.SizeOfCode != original_sections[".text"].SizeOfRawData:
        raise ValueError("Unexpected original PE SizeOfCode convention")
    return {"original_sha256": sha256(original).hexdigest(), "compiler_output_sha256": sha256(compiler_output).hexdigest(),
            "authenticode_payload_sha256": covered_hash(original, old, signed.VirtualAddress), "certificate_sha256": sha256(certificate).hexdigest(),
            "strong_name": strong_slot,
            "x86_bootstrap": old_boot,
            "debug_sha256": sha256(debugs).hexdigest(), "debug_directory_bytes": old.OPTIONAL_HEADER.DATA_DIRECTORY[6].Size,
            "module_guid": guid.hex(), "guid_offset_inside_text": guid_offset,
            "metadata_streams": meta_old, "text_compiler_prefix_bytes": len(prefix_original),
            "text_compiler_prefix_with_original_guid_sha256": sha256(prefix_original).hexdigest(),
            "coff_timestamp": old.FILE_HEADER.TimeDateStamp, "linker_major": old.OPTIONAL_HEADER.MajorLinkerVersion,
            "linker_minor": old.OPTIONAL_HEADER.MinorLinkerVersion, "original_checksum": old.OPTIONAL_HEADER.CheckSum,
            "original_dll_characteristics": old.OPTIONAL_HEADER.DllCharacteristics,
            "certificate_offset": signed.VirtualAddress, "certificate_size": signed.Size,
            "sections": {name: {"file_offset": section.PointerToRawData, "file_bytes": section.SizeOfRawData,
                                "virtual_bytes": section.Misc_VirtualSize} for name, section in original_sections.items()}}, debugs, certificate, strong_name


def apply_recipe(compiled, recipe, debug_record, certificate, strong_name=b""):
    if sha256(compiled).hexdigest() != recipe["compiler_output_sha256"]:
        raise ValueError("C# compiler output differs from the verified candidate; certificate not applied")
    if sha256(debug_record).hexdigest() != recipe["debug_sha256"]:
        raise ValueError("The archived debugger build record changed")
    pe, metadata = identified_image(compiled)
    if metadata != {**recipe["metadata_streams"], "streams": {name: tuple(v) for name, v in recipe["metadata_streams"]["streams"].items()}}:
        raise ValueError("Unexpected compiler metadata stream layout")
    text, raw_start = content_before_debug(compiled, pe)
    mvid = recipe["guid_offset_inside_text"]
    if mvid != pe.get_offset_from_rva(metadata["rva"]) + metadata["streams"]["#GUID"][0] - raw_start:
        raise ValueError("The archived module GUID position disagrees with the emitted CLR stream")
    text[mvid:mvid + 16] = bytes.fromhex(recipe["module_guid"])
    old_boot, new_boot = recipe["x86_bootstrap"], bootstrap(pe)
    if old_boot:
        iat_offset = pe.get_offset_from_rva(new_boot["iat"]) - raw_start
        struct.pack_into("<I", text, iat_offset, old_boot["hint"])
    if sha256(text).hexdigest() != recipe["text_compiler_prefix_with_original_guid_sha256"]:
        raise ValueError("The original CLR section prefix does not match the rebuilt source")
    text += debug_record
    if old_boot:
        text += move_bootstrap(pe, new_boot, old_boot)
    return finish_image(compiled, pe, recipe, text, certificate, strong_name)


def finish_image(compiled, pe, recipe, text, certificate, strong_name):
    source_sections = names(pe)
    old_boot = recipe["x86_bootstrap"]
    allowance = recipe["sections"][".text"]
    if allowance["virtual_bytes"] != len(text) or len(text) > allowance["file_bytes"]:
        raise ValueError("Repositioned debug data does not fit the original text extent")
    head = bytearray(compiled[:pe.OPTIONAL_HEADER.SizeOfHeaders])
    original_layout = recipe["sections"]
    opt = pe.OPTIONAL_HEADER
    coff = pe.FILE_HEADER
    struct.pack_into("<I", head, coff.get_field_absolute_offset("TimeDateStamp"), recipe["coff_timestamp"])
    for field, value in (("MajorLinkerVersion", recipe["linker_major"]), ("MinorLinkerVersion", recipe["linker_minor"])):
        struct.pack_into("<B", head, opt.get_field_absolute_offset(field), value)
    struct.pack_into("<H", head, opt.get_field_absolute_offset("DllCharacteristics"), recipe["original_dll_characteristics"])
    stack = recipe.get("stack_reservation")
    if stack:
        field = "<Q" if opt.Magic == 0x20B else "<I"
        if (opt.SizeOfStackReserve != stack["compiler"] or opt.SizeOfStackCommit != stack["commit"]
                or not 0 < stack["commit"] <= stack["original"] or stack["original"] % 4096):
            raise ValueError("The recorded stack reservation does not match the verified PE build fields")
        struct.pack_into(field, head, opt.get_field_absolute_offset("SizeOfStackReserve"), stack["original"])
    for name, section in source_sections.items():
        recorded = original_layout[name]
        if name != ".text" and (section.Misc_VirtualSize != recorded["virtual_bytes"] or section.SizeOfRawData != recorded["file_bytes"]):
            raise ValueError("Resource section changed")
        for field, key in (("Misc_VirtualSize", "virtual_bytes"), ("SizeOfRawData", "file_bytes"), ("PointerToRawData", "file_offset")):
            struct.pack_into("<I", head, section.get_field_absolute_offset(field), recorded[key])
    struct.pack_into("<I", head, opt.get_field_absolute_offset("SizeOfCode"), allowance["file_bytes"])
    if old_boot:
        struct.pack_into("<I", head, opt.get_field_absolute_offset("AddressOfEntryPoint"), old_boot["entry"])
        struct.pack_into("<II", head, opt.DATA_DIRECTORY[1].get_file_offset(), old_boot["start"], old_boot["import_size"])
    struct.pack_into("<II", head, opt.DATA_DIRECTORY[6].get_file_offset(),
                     recipe.get("debug_rva", opt.DATA_DIRECTORY[6].VirtualAddress), recipe["debug_directory_bytes"])
    sec = opt.DATA_DIRECTORY[4].get_file_offset()
    struct.pack_into("<II", head, sec, recipe["certificate_offset"], recipe["certificate_size"])
    checksum = opt.get_field_absolute_offset("CheckSum")
    struct.pack_into("<I", head, checksum, 0)
    content = head
    for name, layout in sorted(original_layout.items(), key=lambda item: item[1]["file_offset"]):
        if len(content) != layout["file_offset"]:
            raise ValueError("Original sections do not align to the recovered raw layout")
        section = source_sections[name]
        if name == ".text":
            block = text
        else:
            block = bytearray(compiled[section.PointerToRawData:section.PointerToRawData + section.SizeOfRawData])
            if name == ".reloc" and old_boot:
                raw = old_boot["reloc_rva"] - section.VirtualAddress
                block[raw:raw + 12] = make_reloc(old_boot["entry"])
        content += block.ljust(layout["file_bytes"], b"\0")
    if len(content) != recipe["certificate_offset"]:
        raise ValueError("Rebuilt signed payload does not end at its recorded certificate boundary")
    restored = pefile.PE(data=bytes(content), fast_load=True)
    strong = recipe["strong_name"]
    if strong:
        start, amount = strong["file_offset"], strong["width"]
        if (any(content[start:start + amount]) or len(strong_name) != amount
                or sha256(strong_name).hexdigest() != strong["signature_sha256"]
                or covered_hash(content, restored, len(content), erase_strong_name=(start, amount))
                != strong["payload_with_blank_strong_name_sha256"]):
            raise ValueError("Rebuilt PE bytes differ from the masked original; strong-name signature not applied")
        content[start:start + amount] = strong_name
    elif strong_name:
        raise ValueError("An unexpected strong-name signature is present")
    if covered_hash(content, restored, len(content)) != recipe["authenticode_payload_sha256"]:
        raise ValueError("Reconstructed Authenticode payload differs from the original; certificate not applied")
    if len(certificate) != recipe["certificate_size"] or sha256(certificate).hexdigest() != recipe["certificate_sha256"]:
        raise ValueError("The saved original certificate table changed")
    content += certificate
    reconstructed = pefile.PE(data=bytes(content), fast_load=True)
    actual = reconstructed.generate_checksum()
    if actual != recipe["original_checksum"]:
        raise ValueError("Recomputed PE checksum differs from the original")
    struct.pack_into("<I", content, checksum, actual)
    if sha256(content).hexdigest() != recipe["original_sha256"]:
        raise ValueError("Reconstructed file is still not byte-identical to the original")
    return bytes(content)
