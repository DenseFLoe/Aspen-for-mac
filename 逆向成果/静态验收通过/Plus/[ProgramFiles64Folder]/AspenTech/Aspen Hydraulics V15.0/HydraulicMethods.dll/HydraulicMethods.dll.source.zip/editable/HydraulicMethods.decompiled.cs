using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using AHResources;
using AspenTech.Hydraulics.Data;
using AspenTech.Hydraulics.HTFSMethodLib;
using AspenTech.Hydraulics.HydraulicMethodLib;
using AspenTech.Hydraulics.PropertyUtilities;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("Aspen Hydraulics")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2024")]
[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("..\\..\\..\\packages\\AspenTech.StrongName.SNK.1.0.0\\content\\AspenTech.snk")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyFileVersion("41.0.0.99")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace AspenTech.Hydraulics.HydraulicMethodLib
{
	public class Limits
	{
		public const double small = 0.0001;
	}
	public class PipeFlow
	{
		public static double ChurchillFFF(double Re, double relRoughness)
		{
			double y = 16.0;
			double num = 12.0;
			try
			{
				double num2 = Math.Pow(7.0 / Re, 0.9) + 0.27 * relRoughness;
				double num3 = Math.Pow(37530.0 / Re, y);
				double num4 = Math.Pow(2.457 * Math.Log(1.0 / num2), y);
				double x = Math.Pow(8.0 / Re, num) + Math.Pow(num4 + num3, -1.5);
				return 2.0 * Math.Pow(x, 1.0 / num);
			}
			catch (Exception innerException)
			{
				throw new Exception(Resources.ChurchillFFFFailed, innerException);
			}
		}

		public static double aDPDZcorrection(double velocity1, double velocity2, double density, double pressure)
		{
			double num = velocity1 * velocity2 * density / pressure;
			if (num >= 1.0 || num < 0.0)
			{
				return RealValue.FEMPTY;
			}
			return 1.0 - num;
		}

		public static void GetSupVelocities(IFlowStream stream, double diameter, ref double vsg, ref double vsl, ref double vm)
		{
			IPhase phaseByType = stream.GetPhaseByType(PhaseType.Vapour);
			IPhase combinedLiquidPhase = stream.CombinedLiquidPhase;
			double num = stream.MassFlowrate.Value / HTFSUtility.FlowArea(diameter);
			vsg = num * phaseByType.MassFraction.Value / phaseByType.Density.Value;
			vsl = num * combinedLiquidPhase.MassFraction.Value / combinedLiquidPhase.Density.Value;
			vm = vsg + vsl;
		}

		public static double BeggsAndBrillVoidFraction(IPhase liquid, double angleInRads, double laml, double frn, double vsl)
		{
			double fEMPTY = RealValue.FEMPTY;
			int num = 0;
			double num2 = 0.01;
			double num3 = 0.4;
			double num4 = 316.0;
			double y = 0.302;
			double num5 = 0.0009252;
			double y2 = -2.4684;
			double num6 = 0.1;
			double y3 = -1.4516;
			double num7 = 0.5;
			double y4 = -6.738;
			double num8 = 0.685;
			double num9 = 0.924;
			double num10 = 1E-06;
			double[] array = new double[4];
			array[1] = 0.0;
			double[] array2 = new double[4];
			array2[1] = 0.0;
			double[] array3 = new double[4];
			array3[1] = 0.0;
			double[] array4 = new double[4];
			array4[1] = 0.0;
			double[] array5 = new double[4];
			array5[1] = 0.0;
			double[] array6 = new double[4];
			array6[1] = 0.0;
			double[] array7 = new double[4];
			array7[1] = 0.0;
			array[0] = 0.98;
			array[2] = 0.845;
			array[3] = 1.065;
			array2[0] = 0.4846;
			array2[2] = 0.5351;
			array2[3] = 0.5824;
			array3[0] = 0.0868;
			array3[2] = 0.0173;
			array3[3] = 0.0609;
			array4[0] = 0.011;
			array4[2] = 2.96;
			array4[3] = 4.7;
			array5[0] = -3.768;
			array5[2] = 0.305;
			array5[3] = -0.3692;
			array6[0] = 3.539;
			array6[2] = -0.4473;
			array6[3] = 0.1244;
			array7[0] = -1.614;
			array7[2] = 0.0978;
			array7[3] = -0.5056;
			double num11 = num4 * Math.Pow(laml, y);
			double num12 = num5 * Math.Pow(laml, y2);
			double num13 = num6 * Math.Pow(laml, y3);
			double num14 = num7 * Math.Pow(laml, y4);
			if ((laml < num2 && frn < num11) || (laml >= num2 && frn < num12))
			{
				num = 1;
			}
			else if (laml >= num2 && frn >= num12 && frn <= num13)
			{
				num = 2;
			}
			else if ((laml >= num2 && laml < num3 && frn > num13 && frn <= num11) || (laml >= num3 && frn > num13 && frn <= num14))
			{
				num = 3;
			}
			else if ((laml < num3 && frn >= num11) || (laml >= num3 && frn > num14))
			{
				num = 4;
			}
			if (num == 0)
			{
				throw new Exception(Resources.BeggsBrillNoFlowRegime);
			}
			double num15 = 1.0;
			double num16 = 1.0;
			double num17 = 1.0;
			double num18 = 1.0;
			if (num == 2)
			{
				if (Math.Abs(num13 - num12) < num10)
				{
					throw new Exception(Resources.TransitionFlowLimitsTooClose);
				}
				num16 = (num13 - frn) / (num13 - num12);
				num17 = array[0] * Math.Pow(laml, array2[0]) / Math.Pow(frn, array3[0]);
				num18 = array[2] * Math.Pow(laml, array2[2]) / Math.Pow(frn, array3[2]);
			}
			else
			{
				num15 = array[num - 1] * Math.Pow(laml, array2[num - 1]) / Math.Pow(frn, array3[num - 1]);
			}
			double d = vsl * Math.Pow(liquid.Density.Value / (9.80665 * liquid.SurfaceTension.Value), 0.25);
			double num19 = Math.Sin(angleInRads);
			int num20 = 0;
			if (num19 >= 0.0)
			{
				if (num >= 1 && num <= 3)
				{
					num20 = num;
				}
			}
			else
			{
				num20 = 4;
			}
			double num21 = Math.Sin(1.8 * angleInRads);
			double num22 = num21 - Math.Pow(num21, 3.0) / 3.0;
			double num23 = 0.0;
			double num24 = 0.0;
			double num25 = 0.0;
			double num26 = num15;
			if (num20 == 1 || num20 == 3 || num20 == 4)
			{
				num23 = (1.0 - laml) * (Math.Log(array4[num20 - 1]) + array5[num20 - 1] * Math.Log(laml) + array6[num20 - 1] * Math.Log(d) + array7[num20 - 1] * Math.Log(frn));
				num26 = num15 * (1.0 + num23 * num22);
			}
			else if (num20 == 2)
			{
				num24 = (1.0 - laml) * (Math.Log(array4[0]) + array5[0] * Math.Log(laml) + array6[0] * Math.Log(d) + array7[0] * Math.Log(frn));
				num25 = (1.0 - laml) * (Math.Log(array4[2]) + array5[2] * Math.Log(laml) + array6[2] * Math.Log(d) + array7[2] * Math.Log(frn));
				num26 = num16 * num17 * (1.0 + num24 * num22) + (1.0 - num16) * num18 * (1.0 + num25 * num22);
			}
			if (num20 == 4)
			{
				num26 = num8 * num26;
			}
			else
			{
				num26 = num9 * num26;
			}
			fEMPTY = 1.0 - num26;
			if (fEMPTY <= 0.0 || fEMPTY >= 1.0)
			{
				throw new Exception(Resources.BeggsBrillInvalidHoldup);
			}
			return fEMPTY;
		}

		public static double BeggsAndBrillFrictionFactor(double Re, double laml, double vf, double relRoughness)
		{
			double num = -0.0523;
			double num2 = 3.182;
			double num3 = -0.8725;
			double num4 = 0.01853;
			double num5 = 1.0 - vf;
			if (num5 <= 0.0)
			{
				throw new Exception(Resources.BeggsBrillPgNegativeHoldup);
			}
			double num6 = laml / (num5 * num5);
			double num7 = 0.0;
			if (num6 >= 1.0 && num6 <= 1.2)
			{
				num7 = Math.Log(2.2 * num6 - 1.2);
			}
			else
			{
				double num8 = Math.Log(num6);
				num7 = num8 / (num + num2 * num8 + num3 * num8 * num8 + num4 * Math.Pow(num8, 4.0));
			}
			return Math.Exp(num7) * ChurchillFFF(Re, relRoughness);
		}
	}
}
namespace AspenTech.Hydraulics.HydraulicMethodHandler
{
	public interface IPipeFlow
	{
		RealProperty Diameter { get; set; }

		RealProperty InclinationRads { get; set; }

		RealProperty Roughness { get; set; }

		RealProperty VoidFraction { get; }

		RealProperty PressureGradient { get; }

		BooleanProperty IsChoked { get; set; }

		IFlowStream FlowStream { get; set; }

		IPhysicalPropertyPackage PPPOfFluid { get; set; }

		VoidFractionMethodEnum VoidFractionMethod { get; set; }

		PressureGradientMethodEnum PressureGradientMethod { get; set; }

		double CalculateVoidFraction(IFlowStream Stream, double diam, double inclinationRads, double Roughness, VoidFractionMethodEnum method);

		double CalculateDP_DLInPipe(IFlowStream Stream, double diam, double inclinationRads, double Roughness, VoidFractionMethodEnum method, PressureGradientMethodEnum pgcor, ref bool isChoked);
	}
	public class HydraulicMethodhandler : IPipeFlow
	{
		private RealProperty mDiam;

		private RealProperty mAngle;

		private RealProperty mRoughness;

		private RealProperty mVF;

		private RealProperty mPG;

		private BooleanProperty mChoked;

		private VoidFractionMethodEnum mVFMethod;

		private PressureGradientMethodEnum mPGMethod;

		private IFlowStream mStream;

		private IPhysicalPropertyPackage mIPPP;

		private bool mVFUpdated;

		private bool mPGUpdated;

		public IPhysicalPropertyPackage PPPOfFluid
		{
			get
			{
				try
				{
					return mIPPP;
				}
				catch (Exception ex)
				{
					throw ex;
				}
			}
			set
			{
				mIPPP = value;
				initialiseBooleanVariable();
			}
		}

		public IFlowStream FlowStream
		{
			get
			{
				try
				{
					return mStream;
				}
				catch (Exception ex)
				{
					throw ex;
				}
			}
			set
			{
				mStream = value;
				initialiseBooleanVariable();
			}
		}

		public RealProperty Diameter
		{
			get
			{
				return mDiam;
			}
			set
			{
				mDiam = value;
				initialiseBooleanVariable();
			}
		}

		public RealProperty InclinationRads
		{
			get
			{
				return mAngle;
			}
			set
			{
				mAngle = value;
				initialiseBooleanVariable();
			}
		}

		public RealProperty Roughness
		{
			get
			{
				return mRoughness;
			}
			set
			{
				mRoughness = value;
				initialiseBooleanVariable();
			}
		}

		public RealProperty VoidFraction
		{
			get
			{
				if (!mVFUpdated)
				{
					mVF.Value = RealValue.FEMPTY;
				}
				return mVF;
			}
		}

		public RealProperty PressureGradient
		{
			get
			{
				if (!mPGUpdated)
				{
					mPG.Value = RealValue.FEMPTY;
				}
				return mPG;
			}
		}

		public BooleanProperty IsChoked
		{
			get
			{
				return mChoked;
			}
			set
			{
				mChoked = value;
			}
		}

		public VoidFractionMethodEnum VoidFractionMethod
		{
			get
			{
				return mVFMethod;
			}
			set
			{
				mVFMethod = value;
			}
		}

		public PressureGradientMethodEnum PressureGradientMethod
		{
			get
			{
				return mPGMethod;
			}
			set
			{
				mPGMethod = value;
			}
		}

		public HydraulicMethodhandler()
		{
			initHydraulicMethodhandler();
		}

		public double CalculateVoidFraction(IFlowStream Stream, double diameter, double inclinationRads, double Roughness, VoidFractionMethodEnum vfcor)
		{
			try
			{
				IPhase phaseByType = Stream.GetPhaseByType(PhaseType.Overall);
				IPhase combinedLiquidPhase = Stream.CombinedLiquidPhase;
				IPhase phaseByType2 = Stream.GetPhaseByType(PhaseType.Vapour);
				double num = Roughness / diameter;
				double slipRatio = 1.0;
				double vsg = 0.0;
				double vsl = 0.0;
				double vm = 0.0;
				switch (vfcor)
				{
				case VoidFractionMethodEnum.Homogeneous:
					mVF.Value = TwoPhaseFlow.VoidFractionInPipe(combinedLiquidPhase.Density.Value, phaseByType2.Density.Value, phaseByType2.MassFraction.Value, slipRatio);
					break;
				case VoidFractionMethodEnum.HTFS:
				{
					double angle = 180.0 * inclinationRads / Math.PI;
					double area = HTFSUtility.FlowArea(diameter);
					double value = HTFSUtility.CalculateMassFlux(Stream.MassFlowrate.Value, area);
					slipRatio = TwoPhaseFlow.SlipRatioInPipe(combinedLiquidPhase.Density.Value, phaseByType2.Density.Value, combinedLiquidPhase.Viscosity.Value, phaseByType2.Viscosity.Value, phaseByType2.MassFraction.Value, Math.Abs(value), angle);
					mVF.Value = TwoPhaseFlow.VoidFractionInPipe(combinedLiquidPhase.Density.Value, phaseByType2.Density.Value, phaseByType2.MassFraction.Value, slipRatio);
					break;
				}
				case VoidFractionMethodEnum.BeggsAndBrill:
				{
					PipeFlow.GetSupVelocities(Stream, diameter, ref vsg, ref vsl, ref vm);
					double laml = vsl / vm;
					double frn = vm * vm / (9.80665 * diameter);
					mVF.Value = PipeFlow.BeggsAndBrillVoidFraction(combinedLiquidPhase, inclinationRads, laml, frn, vsl);
					break;
				}
				default:
					return RealValue.FEMPTY;
				}
				mVFUpdated = true;
				return mVF.Value;
			}
			catch (Exception innerException)
			{
				throw new Exception(string.Format(Resources.MethodFailed, "CalculateVoidFraction"), innerException);
			}
		}

		public double CalculateDP_DLInPipe(IFlowStream Stream, double diameter, double inclinationRads, double Roughness, VoidFractionMethodEnum vfcor, PressureGradientMethodEnum pgcor, ref bool isChoked)
		{
			isChoked = false;
			IPhase phaseByType = Stream.GetPhaseByType(PhaseType.Overall);
			IPhase combinedLiquidPhase = Stream.CombinedLiquidPhase;
			IPhase phaseByType2 = Stream.GetPhaseByType(PhaseType.Vapour);
			double num = Roughness / diameter;
			double area = HTFSUtility.FlowArea(diameter);
			double num2 = HTFSUtility.CalculateMassFlux(Stream.MassFlowrate.Value, area);
			double fEMPTY = RealValue.FEMPTY;
			double fEMPTY2 = RealValue.FEMPTY;
			double fEMPTY3 = RealValue.FEMPTY;
			if (mVFUpdated)
			{
				fEMPTY3 = mVF.Value;
			}
			else
			{
				fEMPTY3 = CalculateVoidFraction(Stream, diameter, inclinationRads, num, vfcor);
			}
			try
			{
				double num3 = 1.0;
				switch (Stream.NumberOfPhases)
				{
				case 1:
				{
					phaseByType = Stream.GetPhaseByID(1);
					double num9 = num2 / phaseByType.Density.Value;
					double re = num2 * diameter / phaseByType.Viscosity.Value;
					fEMPTY = -2.0 * phaseByType.Density.Value * num9 * num9 * PipeFlow.ChurchillFFF(re, num) / diameter;
					fEMPTY2 = -9.80665 * Math.Sin(inclinationRads) * phaseByType.Density.Value;
					num3 = PipeFlow.aDPDZcorrection(num9, num9, phaseByType.Density.Value, phaseByType.Pressure.Value);
					break;
				}
				case 2:
				{
					phaseByType = Stream.GetPhaseByType(PhaseType.Overall);
					phaseByType2 = Stream.GetPhaseByType(PhaseType.Vapour);
					combinedLiquidPhase = Stream.CombinedLiquidPhase;
					double vsg = 0.0;
					double vsl = 0.0;
					double vm = 0.0;
					PipeFlow.GetSupVelocities(Stream, diameter, ref vsg, ref vsl, ref vm);
					double num4 = vsl / vm;
					double num5 = num4 * combinedLiquidPhase.Viscosity.Value + (1.0 - num4) * phaseByType2.Viscosity.Value;
					double num6 = num4 * combinedLiquidPhase.Density.Value + (1.0 - num4) * phaseByType2.Density.Value;
					switch (pgcor)
					{
					case PressureGradientMethodEnum.Homogeneous:
					{
						double num8 = num6 * vm * diameter / num5;
						if (num8 <= 0.0)
						{
							throw new Exception(Resources.HomogeneousPGInvalidRe);
						}
						fEMPTY = -2.0 * PipeFlow.ChurchillFFF(num8, num) * num6 * vm * vm / diameter;
						fEMPTY2 = -9.80665 * Math.Sin(inclinationRads) * num6;
						break;
					}
					case PressureGradientMethodEnum.HTFS:
						fEMPTY = TwoPhaseFlow.FrictionalPressureGradientInPipe(Stream, num2, diameter, num);
						fEMPTY2 = -9.80665 * Math.Sin(inclinationRads) * num6;
						break;
					case PressureGradientMethodEnum.BeggsAndBrill:
					{
						double num7 = num6 * vm * diameter / num5;
						if (num7 <= 0.0)
						{
							throw new Exception(Resources.BeggsBrillPGInvalidRe);
						}
						fEMPTY = -2.0 * PipeFlow.BeggsAndBrillFrictionFactor(num7, num4, fEMPTY3, num) * num6 * vm * vm / diameter;
						fEMPTY2 = -9.80665 * Math.Sin(inclinationRads) * (phaseByType2.Density.Value * fEMPTY3 + combinedLiquidPhase.Density.Value * (1.0 - fEMPTY3));
						break;
					}
					default:
						return RealValue.FEMPTY;
					}
					num3 = PipeFlow.aDPDZcorrection(vm, vsg, phaseByType.Density.Value, phaseByType.Pressure.Value);
					break;
				}
				default:
					return RealValue.FEMPTY;
				}
				if (num3 == RealValue.FEMPTY)
				{
					isChoked = true;
					return RealValue.FEMPTY;
				}
				mPGUpdated = true;
				mPG.Value = (fEMPTY + fEMPTY2) / num3;
				return mPG.Value;
			}
			catch (Exception innerException)
			{
				throw new Exception(string.Format(Resources.MethodFailed, "CalculateDP_DLInPipe"), innerException);
			}
		}

		private void initHydraulicMethodhandler()
		{
			mDiam = new RealProperty();
			mDiam.Description = Resources.PipeDiam;
			mDiam.DefaultValue = 0.0;
			mDiam.LBound = 0.0;
			mDiam.UBound = 10.0;
			mDiam.Value = 0.0;
			mAngle = new RealProperty();
			mAngle.Description = Resources.PipeAngle;
			mAngle.DefaultValue = 0.0;
			mAngle.LBound = -Math.PI / 2.0;
			mAngle.UBound = Math.PI / 2.0;
			mAngle.Value = 0.0;
			mRoughness = new RealProperty();
			mRoughness.Description = Resources.PipeRoughness;
			mRoughness.DefaultValue = 0.0;
			mRoughness.LBound = 0.0;
			mRoughness.UBound = 0.05;
			mRoughness.Value = 0.0;
			mVF = new RealProperty();
			mVF.Description = Resources.VoidFrac;
			mVF.DefaultValue = 1.0;
			mVF.LBound = 0.0;
			mVF.UBound = 1.0;
			mVF.Value = RealValue.FEMPTY;
			mPG = new RealProperty();
			mPG.Description = Resources.PressureGrad;
			mPG.DefaultValue = 0.0;
			mPG.Value = 0.0;
			mChoked = new BooleanProperty();
			mChoked.Description = Resources.FlowChoked;
			mChoked.DefaultValue = false;
			mChoked.Value = false;
			initialiseBooleanVariable();
		}

		private void initialiseBooleanVariable()
		{
			mVFUpdated = false;
			mPGUpdated = false;
		}
	}
	public enum VoidFractionMethodEnum
	{
		Default = -1,
		Homogeneous,
		HTFS,
		DunsAndRos,
		HagedornAndBrown,
		BeggsAndBrill,
		Eaton
	}
	public enum PressureGradientMethodEnum
	{
		Default = -1,
		Homogeneous,
		HTFS,
		DunsAndRos,
		HagedornAndBrown,
		BeggsAndBrill,
		Orkiszewski
	}
}
