// IL code: AspenTech.Interop.thcontainers
.class private auto ansi '<Module>'
{
} // end of class <Module>

.class public auto ansi import beforefieldinit AspenTech.Interop.ThContainers.COTHCompoundClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThContainers.IBasicCompound,
	           AspenTech.Interop.ThContainers.COTHCompound,
	           AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties,
	           AspenTech.Interop.ThContainers.ICompoundPR,
	           AspenTech.Interop.ThContainers.ICompoundCOSTALD,
	           AspenTech.Interop.ThContainers.ICompoundCavett,
	           AspenTech.Interop.ThContainers.ICompoundViscosity,
	           AspenTech.Interop.ThContainers.ICompoundChaoSeader,
	           AspenTech.Interop.ThContainers.ICompoundChienNull,
	           AspenTech.Interop.ThContainers.ICompoundVirial,
	           AspenTech.Interop.ThContainers.ICompoundPRSV,
	           AspenTech.Interop.ThContainers.ICompoundSRK,
	           AspenTech.Interop.ThContainers.ICompoundWilson,
	           AspenTech.Interop.ThContainers.ICompoundID,
	           AspenTech.Interop.ThContainers.ICompoundFamily,
	           AspenTech.Interop.ThContainers.ICompoundUNIFAC1,
	           AspenTech.Interop.ThContainers.ICompoundUNIQUAC1,
	           AspenTech.Interop.ThContainers.ICompoundSolidProperties,
	           AspenTech.Interop.ThContainers.ICompoundIDPut,
	           AspenTech.Interop.ThContainers.ICompoundFamilyPut,
	           AspenTech.Interop.ThContainers.ICompoundUNIFAC1Put,
	           AspenTech.Interop.ThContainers.ICompoundInitFromHypDB,
	           AspenTech.Interop.ThContainers.ICompoundProp,
	           AspenTech.Interop.ThContainers.ICompoundPropPut,
	           AspenTech.Interop.ThContainers.ICompoundCopy,
	           AspenTech.Interop.ThContainers.XMLParserClient,
	           AspenTech.Interop.ThContainers.IXMLStore,
	           AspenTech.Interop.ThContainers.IUserProperty,
	           AspenTech.Interop.ThContainers.ICompEqnXYShape
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 34 43 41 33 42 38 33 34 2d 34 43 42 33
		2d 31 31 44 32 2d 42 38 44 34 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot virtual 
		instance float64 get_MW (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_MW(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_MW

	.method public hidebysig specialname newslot virtual 
		instance float64 get_TC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_TC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_TC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_PC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_VC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_VC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_VC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_ACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_ACEN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_ACEN

	.method public hidebysig specialname newslot virtual 
		instance float64 get_NBP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_NBP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_NBP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SLDN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0d 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_SLDN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SLDN

	.method public hidebysig specialname newslot virtual 
		instance float64 get_DM (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0f 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_DM(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_DM

	.method public hidebysig specialname newslot virtual 
		instance float64 get_RG (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 11 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_RG(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_RG

	.method public hidebysig specialname newslot virtual 
		instance float64 get_MP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 13 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_MP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_MP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_HFUS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 15 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_HFUS(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_HFUS

	.method public hidebysig specialname newslot virtual 
		instance float64 get_RI (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 17 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_RI(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_RI

	.method public hidebysig specialname newslot virtual 
		instance float64 get_FP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 19 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_FP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_FP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_FLML (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1b 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_FLML(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_FLML

	.method public hidebysig specialname newslot virtual 
		instance float64 get_FLMU (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1d 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_FLMU(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_FLMU

	.method public hidebysig specialname newslot virtual 
		instance float64 get_AIT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1f 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_AIT(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_AIT

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SVEL (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 21 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_SVEL(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SVEL

	.method public hidebysig specialname newslot virtual 
		instance float64 get_LDN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 23 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_LDN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_LDN

	.method public hidebysig specialname newslot virtual 
		instance float64 get_VDN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 25 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_VDN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_VDN

	.method public hidebysig specialname newslot virtual 
		instance float64 get_VP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 27 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_VP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_VP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 29 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_SP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_HVP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2b 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_HVP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_HVP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_LCP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2d 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_LCP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_LCP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_VCP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2f 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_VCP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_VCP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SVR (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 31 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_SVR(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SVR

	.method public hidebysig specialname newslot virtual 
		instance float64 get_LVS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 33 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_LVS(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_LVS

	.method public hidebysig specialname newslot virtual 
		instance float64 get_VVS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 35 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_VVS(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_VVS

	.method public hidebysig specialname newslot virtual 
		instance float64 get_LTC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 37 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_LTC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_LTC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_VTC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 39 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_VTC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_VTC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_ST (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3b 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_ST(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_ST

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3d 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_IT(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_IT

	.method public hidebysig specialname newslot virtual 
		instance float64 get_LIQH (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3f 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_LIQH(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_LIQH

	.method public hidebysig specialname newslot virtual 
		instance float64 get_VAPH (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 41 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_VAPH(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_VAPH

	.method public hidebysig specialname newslot virtual 
		instance float64 get_LIQS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 43 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_LIQS(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_LIQS

	.method public hidebysig specialname newslot virtual 
		instance float64 get_VAPS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 45 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_VAPS(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_VAPS

	.method public hidebysig specialname newslot virtual 
		instance int32 get_HyprotechID () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 47 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThContainers.IBasicCompound::get_HyprotechID()
	} // end of method COTHCompoundClass::get_HyprotechID

	.method public hidebysig specialname newslot virtual 
		instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum get_Family () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 48 00 00 00 00 00
		)
	} // end of method COTHCompoundClass::get_Family

	.method public hidebysig specialname newslot virtual 
		instance string marshal(bstr) get_SubFamily () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 49 00 00 00 00 00
		)
		.override method instance string AspenTech.Interop.ThContainers.IBasicCompound::get_SubFamily()
	} // end of method COTHCompoundClass::get_SubFamily

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IGH (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4b 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_IGH(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_IGH

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IGS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4c 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_IGS(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_IGS

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IGCP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4d 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_IGCP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_IGCP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_CavettParameter (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4e 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_CavettParameter(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_CavettParameter

	.method public hidebysig specialname newslot virtual 
		instance float64 get_COSTALDACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4f 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_COSTALDACEN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_COSTALDACEN

	.method public hidebysig specialname newslot virtual 
		instance float64 get_COSTALDVCHAR (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 50 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_COSTALDVCHAR(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_COSTALDVCHAR

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SRKACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 51 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_SRKACEN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SRKACEN

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IGHF25 (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 52 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_IGHF25(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_IGHF25

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IGSF25 (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 53 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicCompound::get_IGSF25(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_IGSF25

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IGG (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGG(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_IGG

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties.get_IGH (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGH(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties.get_IGH

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties.get_IGS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGS(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties.get_IGS

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties.get_IGCP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGCP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties.get_IGCP

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties.get_IGHF25 (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGHF25(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties.get_IGHF25

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties.get_IGSF25 (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGSF25(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties.get_IGSF25

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IGHC25 (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGHC25(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_IGHC25

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRTC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPR::get_PRTC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRTC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRPC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPR::get_PRPC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRPC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRVC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPR::get_PRVC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRVC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPR::get_PRACEN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRACEN

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRMC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPR::get_PRMC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRMC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRPVOLT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPR::get_PRPVOLT(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRPVOLT

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThContainers.ICompoundCOSTALD.get_COSTALDACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundCOSTALD::get_COSTALDACEN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundCOSTALD.get_COSTALDACEN

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThContainers.ICompoundCOSTALD.get_COSTALDVCHAR (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundCOSTALD::get_COSTALDVCHAR(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundCOSTALD.get_COSTALDVCHAR

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThContainers.ICompoundCavett.get_CavettParameter (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundCavett::get_CavettParameter(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundCavett.get_CavettParameter

	.method public hidebysig specialname newslot virtual 
		instance float64 get_ChaoSeaderACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundChaoSeader::get_ChaoSeaderACEN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_ChaoSeaderACEN

	.method public hidebysig specialname newslot virtual 
		instance float64 get_ChaoSeaderMVOL (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundChaoSeader::get_ChaoSeaderMVOL(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_ChaoSeaderMVOL

	.method public hidebysig specialname newslot virtual 
		instance float64 get_ChaoSeaderPVOLT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundChaoSeader::get_ChaoSeaderPVOLT(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_ChaoSeaderPVOLT

	.method public hidebysig specialname newslot virtual 
		instance float64 get_ChaoSeaderSOLP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundChaoSeader::get_ChaoSeaderSOLP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_ChaoSeaderSOLP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_ChienNullMVOL (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundChienNull::get_ChienNullMVOL(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_ChienNullMVOL

	.method public hidebysig specialname newslot virtual 
		instance float64 get_ChienNullPVOLT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundChienNull::get_ChienNullPVOLT(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_ChienNullPVOLT

	.method public hidebysig specialname newslot virtual 
		instance float64 get_ChienNullSOLP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundChienNull::get_ChienNullSOLP(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_ChienNullSOLP

	.method public hidebysig specialname newslot virtual 
		instance float64 get_VirialSOLV (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundVirial::get_VirialSOLV(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_VirialSOLV

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRSVTC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVTC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRSVTC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRSVPC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVPC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRSVPC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRSVVC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVVC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRSVVC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRSVACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVACEN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRSVACEN

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRSVKAPPA (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVKAPPA(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRSVKAPPA

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PRSVPVOLT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVPVOLT(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_PRSVPVOLT

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SRKTC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKTC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SRKTC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SRKPC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKPC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SRKPC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SRKVC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKVC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SRKVC

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThContainers.ICompoundSRK.get_SRKACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKACEN(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundSRK.get_SRKACEN

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SRKMC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKMC(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SRKMC

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SRKPVOLT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKPVOLT(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SRKPVOLT

	.method public hidebysig specialname newslot virtual 
		instance float64 get_WilsonKVAL (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundWilson::get_WilsonKVAL(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_WilsonKVAL

	.method public hidebysig specialname newslot virtual 
		instance float64 get_WilsonMVOL (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundWilson::get_WilsonMVOL(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_WilsonMVOL

	.method public hidebysig specialname newslot virtual 
		instance string marshal(bstr) get_Name () runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThContainers.ICompoundID::get_Name()
	} // end of method COTHCompoundClass::get_Name

	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfSynonymNames () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_NumberOfSynonymNames()
	} // end of method COTHCompoundClass::get_NumberOfSynonymNames

	.method public hidebysig specialname newslot virtual 
		instance string marshal(bstr) get_SynonymName (
			[in] int32 nIdx
		) runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThContainers.ICompoundID::get_SynonymName(int32)
	} // end of method COTHCompoundClass::get_SynonymName

	.method public hidebysig specialname newslot virtual 
		instance int32 get_PPAttribute () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_PPAttribute()
	} // end of method COTHCompoundClass::get_PPAttribute

	.method public hidebysig specialname newslot virtual 
		instance string marshal(bstr) get_CASN () runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThContainers.ICompoundID::get_CASN()
	} // end of method COTHCompoundClass::get_CASN

	.method public hidebysig specialname newslot virtual 
		instance string marshal(bstr) get_IUPACName () runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThContainers.ICompoundID::get_IUPACName()
	} // end of method COTHCompoundClass::get_IUPACName

	.method private final hidebysig specialname newslot virtual 
		instance int32 AspenTech.Interop.ThContainers.ICompoundID.get_HyprotechID () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_HyprotechID()
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundID.get_HyprotechID

	.method public hidebysig specialname newslot virtual 
		instance int32 get_PPDSID () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_PPDSID()
	} // end of method COTHCompoundClass::get_PPDSID

	.method public hidebysig specialname newslot virtual 
		instance int32 get_DDBID () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_DDBID()
	} // end of method COTHCompoundClass::get_DDBID

	.method public hidebysig specialname newslot virtual 
		instance int32 get_DIPPRID () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_DIPPRID()
	} // end of method COTHCompoundClass::get_DIPPRID

	.method public hidebysig specialname newslot virtual 
		instance int32 get_CMAID () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_CMAID()
	} // end of method COTHCompoundClass::get_CMAID

	.method public hidebysig specialname newslot virtual 
		instance string marshal(bstr) get_ChemicalFormula () runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThContainers.ICompoundID::get_ChemicalFormula()
	} // end of method COTHCompoundClass::get_ChemicalFormula

	.method public hidebysig specialname newslot virtual 
		instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum get_ICompoundFamily_Family () runtime managed internalcall 
	{
	} // end of method COTHCompoundClass::get_ICompoundFamily_Family

	.method private final hidebysig specialname newslot virtual 
		instance string marshal(bstr) AspenTech.Interop.ThContainers.ICompoundFamily.get_SubFamily () runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThContainers.ICompoundFamily::get_SubFamily()
	} // end of method COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundFamily.get_SubFamily

	.method public hidebysig specialname newslot virtual 
		instance bool get_NonCondensable () runtime managed internalcall 
	{
		.override method instance bool AspenTech.Interop.ThContainers.ICompoundFamily::get_NonCondensable()
	} // end of method COTHCompoundClass::get_NonCondensable

	.method public hidebysig specialname newslot virtual 
		instance int32 get_UNIFAC1NumberOfGroups () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThContainers.ICompoundUNIFAC1::get_UNIFAC1NumberOfGroups()
	} // end of method COTHCompoundClass::get_UNIFAC1NumberOfGroups

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_UNIFAC1Groups (
			[out] object& marshal(idispatch) ppGroupTypeNo
		) runtime managed internalcall 
	{
		.override method instance object AspenTech.Interop.ThContainers.ICompoundUNIFAC1::get_UNIFAC1Groups(object&)
	} // end of method COTHCompoundClass::get_UNIFAC1Groups

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SolidAverageDiameter (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidAverageDiameter(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SolidAverageDiameter

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SolidSphericity (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidSphericity(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SolidSphericity

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SolidSurfaceArea (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidSurfaceArea(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SolidSurfaceArea

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SolidCarbon (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidCarbon(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SolidCarbon

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SolidHydrogen (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidHydrogen(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SolidHydrogen

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SolidNitrogen (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidNitrogen(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SolidNitrogen

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SolidOxygen (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidOxygen(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SolidOxygen

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SolidSulphur (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidSulphur(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SolidSulphur

	.method public hidebysig specialname newslot virtual 
		instance float64 get_SolidChlorine (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidChlorine(float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&)
	} // end of method COTHCompoundClass::get_SolidChlorine

	.method public hidebysig specialname newslot virtual 
		instance void set_Name (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_Name(string)
	} // end of method COTHCompoundClass::set_Name

	.method public hidebysig specialname newslot virtual 
		instance void set_NumberOfSynonymNames (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_NumberOfSynonymNames(int32)
	} // end of method COTHCompoundClass::set_NumberOfSynonymNames

	.method public hidebysig specialname newslot virtual 
		instance void set_SynonymName (
			[in] int32 nIdx,
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_SynonymName(int32, string)
	} // end of method COTHCompoundClass::set_SynonymName

	.method public hidebysig specialname newslot virtual 
		instance void set_PPAttribute (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_PPAttribute(int32)
	} // end of method COTHCompoundClass::set_PPAttribute

	.method public hidebysig specialname newslot virtual 
		instance void set_CASN (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_CASN(string)
	} // end of method COTHCompoundClass::set_CASN

	.method public hidebysig specialname newslot virtual 
		instance void set_IUPACName (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_IUPACName(string)
	} // end of method COTHCompoundClass::set_IUPACName

	.method public hidebysig specialname newslot virtual 
		instance void set_HyprotechID (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_HyprotechID(int32)
	} // end of method COTHCompoundClass::set_HyprotechID

	.method public hidebysig specialname newslot virtual 
		instance void set_PPDSID (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_PPDSID(int32)
	} // end of method COTHCompoundClass::set_PPDSID

	.method public hidebysig specialname newslot virtual 
		instance void set_DDBID (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_DDBID(int32)
	} // end of method COTHCompoundClass::set_DDBID

	.method public hidebysig specialname newslot virtual 
		instance void set_DIPPRID (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_DIPPRID(int32)
	} // end of method COTHCompoundClass::set_DIPPRID

	.method public hidebysig specialname newslot virtual 
		instance void set_CMAID (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_CMAID(int32)
	} // end of method COTHCompoundClass::set_CMAID

	.method public hidebysig specialname newslot virtual 
		instance void set_ChemicalFormula (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_ChemicalFormula(string)
	} // end of method COTHCompoundClass::set_ChemicalFormula

	.method public hidebysig specialname newslot virtual 
		instance void set_Family (
			[in] valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundFamilyPut::set_Family(valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum)
	} // end of method COTHCompoundClass::set_Family

	.method public hidebysig specialname newslot virtual 
		instance void set_SubFamily (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundFamilyPut::set_SubFamily(string)
	} // end of method COTHCompoundClass::set_SubFamily

	.method public hidebysig specialname newslot virtual 
		instance void set_NonCondensable (
			[in] bool 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundFamilyPut::set_NonCondensable(bool)
	} // end of method COTHCompoundClass::set_NonCondensable

	.method public hidebysig specialname newslot virtual 
		instance void set_UNIFAC1NumberOfGroups (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundUNIFAC1Put::set_UNIFAC1NumberOfGroups(int32)
	} // end of method COTHCompoundClass::set_UNIFAC1NumberOfGroups

	.method public hidebysig specialname newslot virtual 
		instance void set_UNIFAC1Groups (
			[in] int32 nNumGroup,
			[in] object marshal(idispatch) ppGroupTypeNo,
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundUNIFAC1Put::set_UNIFAC1Groups(int32, object, object)
	} // end of method COTHCompoundClass::set_UNIFAC1Groups

	.method public hidebysig specialname newslot virtual 
		instance void set_HYPUNIFACNoGr (
			[in] int32 nNumGroup,
			[in] class AspenTech.Interop.ThContainers.IIntegerArrayDisp marshal(interface) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundUNIFAC1Put::set_HYPUNIFACNoGr(int32, class AspenTech.Interop.ThContainers.IIntegerArrayDisp)
	} // end of method COTHCompoundClass::set_HYPUNIFACNoGr

	.method public hidebysig specialname newslot virtual 
		instance void set_HYPUNIFACSubGr (
			[in] int32 nNumGroup,
			[in] class AspenTech.Interop.ThContainers.IIntegerArrayDisp marshal(interface) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundUNIFAC1Put::set_HYPUNIFACSubGr(int32, class AspenTech.Interop.ThContainers.IIntegerArrayDisp)
	} // end of method COTHCompoundClass::set_HYPUNIFACSubGr

	.method public hidebysig newslot virtual 
		instance void get_MWTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_MWTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_MWTPRange

	.method public hidebysig newslot virtual 
		instance void get_TCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_TCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_TCTPRange

	.method public hidebysig newslot virtual 
		instance void get_PCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_PCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PCTPRange

	.method public hidebysig newslot virtual 
		instance void get_VCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_VCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_VCTPRange

	.method public hidebysig newslot virtual 
		instance void get_ACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_ACENTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_ACENTPRange

	.method public hidebysig newslot virtual 
		instance void get_NBPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_NBPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_NBPTPRange

	.method public hidebysig newslot virtual 
		instance void get_SLDNTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_SLDNTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SLDNTPRange

	.method public hidebysig newslot virtual 
		instance void get_DMTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_DMTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_DMTPRange

	.method public hidebysig newslot virtual 
		instance void get_RGTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_RGTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_RGTPRange

	.method public hidebysig newslot virtual 
		instance void get_MPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_MPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_MPTPRange

	.method public hidebysig newslot virtual 
		instance void get_HFUSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 16 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_HFUSTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_HFUSTPRange

	.method public hidebysig newslot virtual 
		instance void get_RITPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 18 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_RITPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_RITPRange

	.method public hidebysig newslot virtual 
		instance void get_FPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1a 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_FPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_FPTPRange

	.method public hidebysig newslot virtual 
		instance void get_FLMLTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1c 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_FLMLTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_FLMLTPRange

	.method public hidebysig newslot virtual 
		instance void get_FLMUTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1e 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_FLMUTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_FLMUTPRange

	.method public hidebysig newslot virtual 
		instance void get_AITTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 20 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_AITTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_AITTPRange

	.method public hidebysig newslot virtual 
		instance void get_SVELTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 22 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_SVELTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SVELTPRange

	.method public hidebysig newslot virtual 
		instance void get_LDNTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 24 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_LDNTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_LDNTPRange

	.method public hidebysig newslot virtual 
		instance void get_VDNTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 26 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_VDNTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_VDNTPRange

	.method public hidebysig newslot virtual 
		instance void get_VPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 28 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_VPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_VPTPRange

	.method public hidebysig newslot virtual 
		instance void get_SPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2a 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_SPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SPTPRange

	.method public hidebysig newslot virtual 
		instance void get_HVPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2c 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_HVPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_HVPTPRange

	.method public hidebysig newslot virtual 
		instance void get_LCPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2e 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_LCPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_LCPTPRange

	.method public hidebysig newslot virtual 
		instance void get_VCPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 30 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_VCPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_VCPTPRange

	.method public hidebysig newslot virtual 
		instance void get_SVRTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 32 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_SVRTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SVRTPRange

	.method public hidebysig newslot virtual 
		instance void get_LVSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 34 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_LVSTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_LVSTPRange

	.method public hidebysig newslot virtual 
		instance void get_VVSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 36 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_VVSTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_VVSTPRange

	.method public hidebysig newslot virtual 
		instance void get_LTCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 38 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_LTCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_LTCTPRange

	.method public hidebysig newslot virtual 
		instance void get_VTCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3a 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_VTCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_VTCTPRange

	.method public hidebysig newslot virtual 
		instance void get_STTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3c 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_STTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_STTPRange

	.method public hidebysig newslot virtual 
		instance void get_ITTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3e 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_ITTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_ITTPRange

	.method public hidebysig newslot virtual 
		instance void get_LIQHTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 40 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_LIQHTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_LIQHTPRange

	.method public hidebysig newslot virtual 
		instance void get_VAPHTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 42 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_VAPHTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_VAPHTPRange

	.method public hidebysig newslot virtual 
		instance void get_LIQSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 44 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_LIQSTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_LIQSTPRange

	.method public hidebysig newslot virtual 
		instance void get_VAPSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 46 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::get_VAPSTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_VAPSTPRange

	.method public hidebysig newslot virtual 
		instance void GetNonCondensable (
			[out] uint8& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4a 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicCompound::GetNonCondensable(uint8&)
	} // end of method COTHCompoundClass::GetNonCondensable

	.method public hidebysig newslot virtual 
		instance void get_IGGTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGGTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_IGGTPRange

	.method public hidebysig newslot virtual 
		instance void get_IGHTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGHTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_IGHTPRange

	.method public hidebysig newslot virtual 
		instance void get_IGSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGSTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_IGSTPRange

	.method public hidebysig newslot virtual 
		instance void get_IGCPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGCPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_IGCPTPRange

	.method public hidebysig newslot virtual 
		instance void get_IGHF25TPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGHF25TPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_IGHF25TPRange

	.method public hidebysig newslot virtual 
		instance void get_IGSF25TPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGSF25TPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_IGSF25TPRange

	.method public hidebysig newslot virtual 
		instance void get_IGHC25TPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties::get_IGHC25TPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_IGHC25TPRange

	.method public hidebysig newslot virtual 
		instance void get_PRTCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPR::get_PRTCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRTCTPRange

	.method public hidebysig newslot virtual 
		instance void get_PRPCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPR::get_PRPCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRPCTPRange

	.method public hidebysig newslot virtual 
		instance void get_PRVCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPR::get_PRVCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRVCTPRange

	.method public hidebysig newslot virtual 
		instance void get_PRACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPR::get_PRACENTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRACENTPRange

	.method public hidebysig newslot virtual 
		instance void get_PRMCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPR::get_PRMCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRMCTPRange

	.method public hidebysig newslot virtual 
		instance void get_PRPVOLTTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPR::get_PRPVOLTTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRPVOLTTPRange

	.method public hidebysig newslot virtual 
		instance void get_COSTALDACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCOSTALD::get_COSTALDACENTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_COSTALDACENTPRange

	.method public hidebysig newslot virtual 
		instance void get_COSTALDVCHARTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCOSTALD::get_COSTALDVCHARTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_COSTALDVCHARTPRange

	.method public hidebysig newslot virtual 
		instance void get_CavettParameterTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCavett::get_CavettParameterTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_CavettParameterTPRange

	.method public hidebysig newslot virtual 
		instance void get_ViscosityThetas (
			[out] float64& THETAA,
			[out] float64& THETAB
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundViscosity::get_ViscosityThetas(float64&, float64&)
	} // end of method COTHCompoundClass::get_ViscosityThetas

	.method public hidebysig newslot virtual 
		instance void get_ChaoSeaderACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundChaoSeader::get_ChaoSeaderACENTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_ChaoSeaderACENTPRange

	.method public hidebysig newslot virtual 
		instance void get_ChaoSeaderMVOLTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundChaoSeader::get_ChaoSeaderMVOLTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_ChaoSeaderMVOLTPRange

	.method public hidebysig newslot virtual 
		instance void get_ChaoSeaderPVOLTTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundChaoSeader::get_ChaoSeaderPVOLTTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_ChaoSeaderPVOLTTPRange

	.method public hidebysig newslot virtual 
		instance void get_ChaoSeaderSOLPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundChaoSeader::get_ChaoSeaderSOLPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_ChaoSeaderSOLPTPRange

	.method public hidebysig newslot virtual 
		instance void get_ChienNullMVOLTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundChienNull::get_ChienNullMVOLTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_ChienNullMVOLTPRange

	.method public hidebysig newslot virtual 
		instance void get_ChienNullPVOLTTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundChienNull::get_ChienNullPVOLTTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_ChienNullPVOLTTPRange

	.method public hidebysig newslot virtual 
		instance void get_ChienNullSOLPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundChienNull::get_ChienNullSOLPTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_ChienNullSOLPTPRange

	.method public hidebysig newslot virtual 
		instance void get_VirialSOLVTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundVirial::get_VirialSOLVTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_VirialSOLVTPRange

	.method public hidebysig newslot virtual 
		instance void get_PRSVTCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVTCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRSVTCTPRange

	.method public hidebysig newslot virtual 
		instance void get_PRSVPCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVPCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRSVPCTPRange

	.method public hidebysig newslot virtual 
		instance void get_PRSVVCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVVCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRSVVCTPRange

	.method public hidebysig newslot virtual 
		instance void get_PRSVACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVACENTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRSVACENTPRange

	.method public hidebysig newslot virtual 
		instance void get_PRSVKAPPATPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVKAPPATPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRSVKAPPATPRange

	.method public hidebysig newslot virtual 
		instance void get_PRSVPVOLTTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPRSV::get_PRSVPVOLTTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_PRSVPVOLTTPRange

	.method public hidebysig newslot virtual 
		instance void get_SRKTCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKTCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SRKTCTPRange

	.method public hidebysig newslot virtual 
		instance void get_SRKPCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKPCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SRKPCTPRange

	.method public hidebysig newslot virtual 
		instance void get_SRKVCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKVCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SRKVCTPRange

	.method public hidebysig newslot virtual 
		instance void get_SRKACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKACENTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SRKACENTPRange

	.method public hidebysig newslot virtual 
		instance void get_SRKMCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKMCTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SRKMCTPRange

	.method public hidebysig newslot virtual 
		instance void get_SRKPVOLTTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSRK::get_SRKPVOLTTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SRKPVOLTTPRange

	.method public hidebysig newslot virtual 
		instance void get_WilsonKVALTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundWilson::get_WilsonKVALTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_WilsonKVALTPRange

	.method public hidebysig newslot virtual 
		instance void get_WilsonMVOLTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundWilson::get_WilsonMVOLTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_WilsonMVOLTPRange

	.method public hidebysig newslot virtual 
		instance void IsWater () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundID::IsWater()
	} // end of method COTHCompoundClass::IsWater

	.method public hidebysig newslot virtual 
		instance void IsDEG () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundID::IsDEG()
	} // end of method COTHCompoundClass::IsDEG

	.method public hidebysig newslot virtual 
		instance void IsTEG () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundID::IsTEG()
	} // end of method COTHCompoundClass::IsTEG

	.method public hidebysig newslot virtual 
		instance void IsEG () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundID::IsEG()
	} // end of method COTHCompoundClass::IsEG

	.method public hidebysig newslot virtual 
		instance void IsMethanol () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundID::IsMethanol()
	} // end of method COTHCompoundClass::IsMethanol

	.method public hidebysig newslot virtual 
		instance void get_UNIQUAC1Parameters (
			[out] float64& pdR,
			[out] float64& pdQ
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundUNIQUAC1::get_UNIQUAC1Parameters(float64&, float64&)
	} // end of method COTHCompoundClass::get_UNIQUAC1Parameters

	.method public hidebysig newslot virtual 
		instance void get_SolidAverageDiameterTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidAverageDiameterTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SolidAverageDiameterTPRange

	.method public hidebysig newslot virtual 
		instance void get_SolidSphericityTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidSphericityTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SolidSphericityTPRange

	.method public hidebysig newslot virtual 
		instance void get_SolidSurfaceAreaTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidSurfaceAreaTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SolidSurfaceAreaTPRange

	.method public hidebysig newslot virtual 
		instance void get_SolidCarbonTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidCarbonTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SolidCarbonTPRange

	.method public hidebysig newslot virtual 
		instance void get_SolidHydrogenTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidHydrogenTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SolidHydrogenTPRange

	.method public hidebysig newslot virtual 
		instance void get_SolidNitrogenTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidNitrogenTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SolidNitrogenTPRange

	.method public hidebysig newslot virtual 
		instance void get_SolidOxygenTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidOxygenTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SolidOxygenTPRange

	.method public hidebysig newslot virtual 
		instance void get_SolidSulphurTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidSulphurTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SolidSulphurTPRange

	.method public hidebysig newslot virtual 
		instance void get_SolidChlorineTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundSolidProperties::get_SolidChlorineTPRange(float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::get_SolidChlorineTPRange

	.method public hidebysig newslot virtual 
		instance void Init (
			[in] string marshal(bstr) strPath,
			[in] int32 nCompIdx
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundInitFromHypDB::Init(string, int32)
	} // end of method COTHCompoundClass::Init

	.method public hidebysig newslot virtual 
		instance void GetNumbOfProperty (
			[in] uint8 bFixed,
			[out] int32& nProps
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundProp::GetNumbOfProperty(uint8, int32&)
	} // end of method COTHCompoundClass::GetNumbOfProperty

	.method public hidebysig newslot virtual 
		instance void GetPropertyName (
			[in] uint8 bFixed,
			[in] int32 iProp,
			[out] string& marshal(bstr) Name,
			[out] valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum& 'type'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundProp::GetPropertyName(uint8, int32, string&, valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum&)
	} // end of method COTHCompoundClass::GetPropertyName

	.method public hidebysig newslot virtual 
		instance void GetPropertyValue (
			[in] string marshal(bstr) Name,
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies,
			[out] float64& pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundProp::GetPropertyValue(string, float64, float64, valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum, int32&, float64&)
	} // end of method COTHCompoundClass::GetPropertyValue

	.method public hidebysig newslot virtual 
		instance void GetPropertyType (
			[in] string marshal(bstr) Name,
			[out] valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum& 'type'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundProp::GetPropertyType(string, valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum&)
	} // end of method COTHCompoundClass::GetPropertyType

	.method public hidebysig newslot virtual 
		instance void GetEquationProperty (
			[in] string marshal(bstr) Name,
			[out] valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum& shape,
			[out] string& marshal(bstr) form,
			[out] float64& tmin,
			[out] float64& tmax,
			[out] float64& pmin,
			[out] float64& pmax,
			[out] int32& nParameters,
			[out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) pCoeff
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundProp::GetEquationProperty(string, valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum&, string&, float64&, float64&, float64&, float64&, int32&, class AspenTech.Interop.ThContainers.IRealArrayDisp&)
	} // end of method COTHCompoundClass::GetEquationProperty

	.method public hidebysig newslot virtual 
		instance void GetCOMProperty (
			[in] string marshal(bstr) Name,
			[out] string& marshal(bstr) ClassID,
			[out] class AspenTech.Interop.ThContainers.IPCProperty& marshal(interface) prop
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundProp::GetCOMProperty(string, string&, class AspenTech.Interop.ThContainers.IPCProperty&)
	} // end of method COTHCompoundClass::GetCOMProperty

	.method public hidebysig newslot virtual 
		instance void GetNumbOfCommonProperty (
			[out] int32& nProps
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundProp::GetNumbOfCommonProperty(int32&)
	} // end of method COTHCompoundClass::GetNumbOfCommonProperty

	.method public hidebysig newslot virtual 
		instance void GetCommonPropertyName (
			[in] int32 iProp,
			[out] string& marshal(bstr) Name,
			[out] valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum& 'type'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundProp::GetCommonPropertyName(int32, string&, valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum&)
	} // end of method COTHCompoundClass::GetCommonPropertyName

	.method public hidebysig newslot virtual 
		instance void SetPointProperty (
			[in] string marshal(bstr) Name,
			[in] uint8 'fixed',
			[in] float64 dVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPropPut::SetPointProperty(string, uint8, float64)
	} // end of method COTHCompoundClass::SetPointProperty

	.method public hidebysig newslot virtual 
		instance void SetEquationProperty (
			[in] string marshal(bstr) Name,
			[in] uint8 'fixed',
			[in] valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum shape,
			[in] float64 tmin,
			[in] float64 tmax,
			[in] float64 pmin,
			[in] float64 pmax,
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) pCoeff
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPropPut::SetEquationProperty(string, uint8, valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum, float64, float64, float64, float64, class AspenTech.Interop.ThContainers.IRealArrayDisp)
	} // end of method COTHCompoundClass::SetEquationProperty

	.method public hidebysig newslot virtual 
		instance void SetCOMProperty (
			[in] string marshal(bstr) Name,
			[in] uint8 'fixed',
			[in] string marshal(bstr) ClassName,
			[in] class AspenTech.Interop.ThContainers.IPCProperty marshal(interface) prop
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPropPut::SetCOMProperty(string, uint8, string, class AspenTech.Interop.ThContainers.IPCProperty)
	} // end of method COTHCompoundClass::SetCOMProperty

	.method public hidebysig newslot virtual 
		instance void ErasePropFromMap (
			[in] string marshal(bstr) Name,
			[in] uint8 'fixed'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPropPut::ErasePropFromMap(string, uint8)
	} // end of method COTHCompoundClass::ErasePropFromMap

	.method public hidebysig newslot virtual 
		instance void FindProperty (
			[in] string marshal(bstr) Name,
			[out] uint8& find,
			[out] uint8& 'fixed'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPropPut::FindProperty(string, uint8&, uint8&)
	} // end of method COTHCompoundClass::FindProperty

	.method public hidebysig newslot virtual 
		instance void GetEquationInfo (
			[in] valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum shape,
			[out] string& marshal(bstr) form,
			[out] int32& nParameters
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPropPut::GetEquationInfo(valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum, string&, int32&)
	} // end of method COTHCompoundClass::GetEquationInfo

	.method public hidebysig newslot virtual 
		instance void SetVoidProperty (
			[in] string marshal(bstr) Name,
			[in] uint8 'fixed'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPropPut::SetVoidProperty(string, uint8)
	} // end of method COTHCompoundClass::SetVoidProperty

	.method public hidebysig newslot virtual 
		instance void GetPropertyLoader (
			[in] string marshal(bstr) propname,
			[out] string& marshal(bstr) loader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPropPut::GetPropertyLoader(string, string&)
	} // end of method COTHCompoundClass::GetPropertyLoader

	.method public hidebysig newslot virtual 
		instance void SetPropertyLoader (
			[in] string marshal(bstr) propname,
			[in] string marshal(bstr) loader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundPropPut::SetPropertyLoader(string, string)
	} // end of method COTHCompoundClass::SetPropertyLoader

	.method public hidebysig newslot virtual 
		instance void CopyToThis (
			[in] int32 NewID,
			[in] object marshal(idispatch) OrigComp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCopy::CopyToThis(int32, object)
	} // end of method COTHCompoundClass::CopyToThis

	.method public hidebysig newslot virtual 
		instance void CharacterData (
			[in] string marshal(bstr) userData
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::CharacterData(string)
	} // end of method COTHCompoundClass::CharacterData

	.method public hidebysig newslot virtual 
		instance void StartElement (
			[in] string marshal(bstr) Name,
			[in] class AspenTech.Interop.ThContainers.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::StartElement(string, class AspenTech.Interop.ThContainers.TaggedAttributes)
	} // end of method COTHCompoundClass::StartElement

	.method public hidebysig newslot virtual 
		instance void EndElement (
			[in] string marshal(bstr) Name
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::EndElement(string)
	} // end of method COTHCompoundClass::EndElement

	.method public hidebysig newslot virtual 
		instance void Comment (
			[in] string marshal(bstr) bstrComment
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::Comment(string)
	} // end of method COTHCompoundClass::Comment

	.method public hidebysig newslot virtual 
		instance void ProcessElement (
			[in] string marshal(bstr) Name,
			[in] class AspenTech.Interop.ThContainers.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::ProcessElement(string, class AspenTech.Interop.ThContainers.TaggedAttributes)
	} // end of method COTHCompoundClass::ProcessElement

	.method public hidebysig newslot virtual 
		instance void Error (
			[in] string marshal(bstr) Error
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::Error(string)
	} // end of method COTHCompoundClass::Error

	.method public hidebysig newslot virtual 
		instance void StartDocument () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::StartDocument()
	} // end of method COTHCompoundClass::StartDocument

	.method public hidebysig newslot virtual 
		instance void EndDocument () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::EndDocument()
	} // end of method COTHCompoundClass::EndDocument

	.method public hidebysig newslot virtual 
		instance string marshal(bstr) StoreAsXML () runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThContainers.IXMLStore::StoreAsXML()
	} // end of method COTHCompoundClass::StoreAsXML

	.method public hidebysig newslot virtual 
		instance void SetUserProperty (
			[in] string marshal(bstr) strName,
			[in] string marshal(bstr) ClassID,
			[in] object marshal(idispatch) pProp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IUserProperty::SetUserProperty(string, string, object)
	} // end of method COTHCompoundClass::SetUserProperty

	.method public hidebysig newslot virtual 
		instance void GetUserProperty (
			[in] string marshal(bstr) strName,
			[out] object& marshal(idispatch) pProp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IUserProperty::GetUserProperty(string, object&)
	} // end of method COTHCompoundClass::GetUserProperty

	.method public hidebysig newslot virtual 
		instance void GetUserPropertyClassID (
			[in] string marshal(bstr) strName,
			[out] string& marshal(bstr) ClassID
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IUserProperty::GetUserPropertyClassID(string, string&)
	} // end of method COTHCompoundClass::GetUserPropertyClassID

	.method public hidebysig newslot virtual 
		instance void DeleteUserProperty (
			[in] string marshal(bstr) strName
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IUserProperty::DeleteUserProperty(string)
	} // end of method COTHCompoundClass::DeleteUserProperty

	.method public hidebysig newslot virtual 
		instance void GetNumbOfUserProperty (
			[out] int32& nProp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IUserProperty::GetNumbOfUserProperty(int32&)
	} // end of method COTHCompoundClass::GetNumbOfUserProperty

	.method public hidebysig newslot virtual 
		instance void GetUserPropertyI (
			[in] int32 iProp,
			[out] string& marshal(bstr) Name,
			[out] string& marshal(bstr) ClassID,
			[out] object& marshal(idispatch) pProp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IUserProperty::GetUserPropertyI(int32, string&, string&, object&)
	} // end of method COTHCompoundClass::GetUserPropertyI

	.method public hidebysig newslot virtual 
		instance void GetEquationPropertyXYShape (
			[in] string marshal(bstr) Name,
			[out] valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum& xshape,
			[out] valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum& yshape,
			[out] float64& xnorm,
			[out] float64& ynorm,
			[out] float64& xpow,
			[out] float64& ypow,
			[out] float64& a,
			[out] float64& b
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompEqnXYShape::GetEquationPropertyXYShape(string, valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum&, valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum&, float64&, float64&, float64&, float64&, float64&, float64&)
	} // end of method COTHCompoundClass::GetEquationPropertyXYShape

	.method public hidebysig newslot virtual 
		instance void SetEquationPropertyXYShape (
			[in] string marshal(bstr) Name,
			[in] valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum xshape,
			[in] valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum yshape,
			[in] float64 xnorm,
			[in] float64 ynorm,
			[in] float64 xpow,
			[in] float64 ypow,
			[in] float64 a,
			[in] float64 b
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompEqnXYShape::SetEquationPropertyXYShape(string, valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum, valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum, float64, float64, float64, float64, float64, float64)
	} // end of method COTHCompoundClass::SetEquationPropertyXYShape

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHCompoundClass::.ctor

	// Properties
	.property instance int32 AspenTech.Interop.ThContainers.IBasicCompound.HyprotechID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 47 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.COTHCompoundClass::get_HyprotechID()
	}
	.property instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum Family()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 48 00 00 00 00 00
		)
		.get instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum AspenTech.Interop.ThContainers.COTHCompoundClass::get_Family()
	}
	.property instance string AspenTech.Interop.ThContainers.IBasicCompound.SubFamily()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 49 00 00 00 00 00
		)
		.get instance string AspenTech.Interop.ThContainers.COTHCompoundClass::get_SubFamily()
	}
	.property instance string AspenTech.Interop.ThContainers.ICompoundID.Name()
	{
		.get instance string AspenTech.Interop.ThContainers.COTHCompoundClass::get_Name()
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundID.NumberOfSynonymNames()
	{
		.get instance int32 AspenTech.Interop.ThContainers.COTHCompoundClass::get_NumberOfSynonymNames()
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundID.PPAttribute()
	{
		.get instance int32 AspenTech.Interop.ThContainers.COTHCompoundClass::get_PPAttribute()
	}
	.property instance string AspenTech.Interop.ThContainers.ICompoundID.CASN()
	{
		.get instance string AspenTech.Interop.ThContainers.COTHCompoundClass::get_CASN()
	}
	.property instance string AspenTech.Interop.ThContainers.ICompoundID.IUPACName()
	{
		.get instance string AspenTech.Interop.ThContainers.COTHCompoundClass::get_IUPACName()
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundID.HyprotechID()
	{
		.get instance int32 AspenTech.Interop.ThContainers.COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundID.get_HyprotechID()
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundID.PPDSID()
	{
		.get instance int32 AspenTech.Interop.ThContainers.COTHCompoundClass::get_PPDSID()
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundID.DDBID()
	{
		.get instance int32 AspenTech.Interop.ThContainers.COTHCompoundClass::get_DDBID()
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundID.DIPPRID()
	{
		.get instance int32 AspenTech.Interop.ThContainers.COTHCompoundClass::get_DIPPRID()
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundID.CMAID()
	{
		.get instance int32 AspenTech.Interop.ThContainers.COTHCompoundClass::get_CMAID()
	}
	.property instance string AspenTech.Interop.ThContainers.ICompoundID.ChemicalFormula()
	{
		.get instance string AspenTech.Interop.ThContainers.COTHCompoundClass::get_ChemicalFormula()
	}
	.property instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum ICompoundFamily_Family()
	{
		.get instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum AspenTech.Interop.ThContainers.COTHCompoundClass::get_ICompoundFamily_Family()
	}
	.property instance string AspenTech.Interop.ThContainers.ICompoundFamily.SubFamily()
	{
		.get instance string AspenTech.Interop.ThContainers.COTHCompoundClass::AspenTech.Interop.ThContainers.ICompoundFamily.get_SubFamily()
	}
	.property instance bool AspenTech.Interop.ThContainers.ICompoundFamily.NonCondensable()
	{
		.get instance bool AspenTech.Interop.ThContainers.COTHCompoundClass::get_NonCondensable()
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundUNIFAC1.UNIFAC1NumberOfGroups()
	{
		.get instance int32 AspenTech.Interop.ThContainers.COTHCompoundClass::get_UNIFAC1NumberOfGroups()
	}
	.property instance string AspenTech.Interop.ThContainers.ICompoundIDPut.Name()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_Name(string)
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundIDPut.NumberOfSynonymNames()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_NumberOfSynonymNames(int32)
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundIDPut.PPAttribute()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_PPAttribute(int32)
	}
	.property instance string AspenTech.Interop.ThContainers.ICompoundIDPut.CASN()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_CASN(string)
	}
	.property instance string AspenTech.Interop.ThContainers.ICompoundIDPut.IUPACName()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_IUPACName(string)
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundIDPut.HyprotechID()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_HyprotechID(int32)
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundIDPut.PPDSID()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_PPDSID(int32)
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundIDPut.DDBID()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_DDBID(int32)
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundIDPut.DIPPRID()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_DIPPRID(int32)
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundIDPut.CMAID()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_CMAID(int32)
	}
	.property instance string AspenTech.Interop.ThContainers.ICompoundIDPut.ChemicalFormula()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_ChemicalFormula(string)
	}
	.property instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum AspenTech.Interop.ThContainers.ICompoundFamilyPut.Family()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_Family(valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum)
	}
	.property instance string AspenTech.Interop.ThContainers.ICompoundFamilyPut.SubFamily()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_SubFamily(string)
	}
	.property instance bool AspenTech.Interop.ThContainers.ICompoundFamilyPut.NonCondensable()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_NonCondensable(bool)
	}
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundUNIFAC1Put.UNIFAC1NumberOfGroups()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundClass::set_UNIFAC1NumberOfGroups(int32)
	}

} // end of class AspenTech.Interop.ThContainers.COTHCompoundClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.COTHCompound
	implements AspenTech.Interop.ThContainers.IBasicCompound
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 34 43 41 33 42 38 33 33 2d 34 43 42 33
		2d 31 31 44 32 2d 42 38 44 34 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 30 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 43 6f 6e 74 61 69 6e 65 72
		73 2e 43 4f 54 48 43 6f 6d 70 6f 75 6e 64 43 6c
		61 73 73 00 00
	)
} // end of class AspenTech.Interop.ThContainers.COTHCompound

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IBasicCompound
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 34 43 41 33 42 38 33 33 2d 34 43 42 33
		2d 31 31 44 32 2d 42 38 44 34 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_MW (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_MW

	.method public hidebysig newslot abstract virtual 
		instance void get_MWTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_MWTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_TC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_TC

	.method public hidebysig newslot abstract virtual 
		instance void get_TCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_TCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_PC

	.method public hidebysig newslot abstract virtual 
		instance void get_PCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_PCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_VC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VC

	.method public hidebysig newslot abstract virtual 
		instance void get_VCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_ACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_ACEN

	.method public hidebysig newslot abstract virtual 
		instance void get_ACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_ACENTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_NBP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_NBP

	.method public hidebysig newslot abstract virtual 
		instance void get_NBPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_NBPTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SLDN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0d 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_SLDN

	.method public hidebysig newslot abstract virtual 
		instance void get_SLDNTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_SLDNTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_DM (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0f 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_DM

	.method public hidebysig newslot abstract virtual 
		instance void get_DMTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_DMTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_RG (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 11 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_RG

	.method public hidebysig newslot abstract virtual 
		instance void get_RGTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_RGTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_MP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 13 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_MP

	.method public hidebysig newslot abstract virtual 
		instance void get_MPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_MPTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_HFUS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 15 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_HFUS

	.method public hidebysig newslot abstract virtual 
		instance void get_HFUSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 16 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_HFUSTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_RI (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 17 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_RI

	.method public hidebysig newslot abstract virtual 
		instance void get_RITPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 18 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_RITPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_FP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 19 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_FP

	.method public hidebysig newslot abstract virtual 
		instance void get_FPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1a 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_FPTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_FLML (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1b 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_FLML

	.method public hidebysig newslot abstract virtual 
		instance void get_FLMLTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1c 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_FLMLTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_FLMU (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1d 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_FLMU

	.method public hidebysig newslot abstract virtual 
		instance void get_FLMUTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1e 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_FLMUTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_AIT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1f 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_AIT

	.method public hidebysig newslot abstract virtual 
		instance void get_AITTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 20 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_AITTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SVEL (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 21 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_SVEL

	.method public hidebysig newslot abstract virtual 
		instance void get_SVELTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 22 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_SVELTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_LDN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 23 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LDN

	.method public hidebysig newslot abstract virtual 
		instance void get_LDNTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 24 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LDNTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_VDN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 25 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VDN

	.method public hidebysig newslot abstract virtual 
		instance void get_VDNTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 26 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VDNTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_VP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 27 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VP

	.method public hidebysig newslot abstract virtual 
		instance void get_VPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 28 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VPTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 29 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_SP

	.method public hidebysig newslot abstract virtual 
		instance void get_SPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2a 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_SPTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_HVP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2b 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_HVP

	.method public hidebysig newslot abstract virtual 
		instance void get_HVPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2c 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_HVPTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_LCP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2d 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LCP

	.method public hidebysig newslot abstract virtual 
		instance void get_LCPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2e 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LCPTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_VCP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2f 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VCP

	.method public hidebysig newslot abstract virtual 
		instance void get_VCPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 30 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VCPTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SVR (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 31 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_SVR

	.method public hidebysig newslot abstract virtual 
		instance void get_SVRTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 32 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_SVRTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_LVS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 33 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LVS

	.method public hidebysig newslot abstract virtual 
		instance void get_LVSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 34 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LVSTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_VVS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 35 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VVS

	.method public hidebysig newslot abstract virtual 
		instance void get_VVSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 36 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VVSTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_LTC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 37 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LTC

	.method public hidebysig newslot abstract virtual 
		instance void get_LTCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 38 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LTCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_VTC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 39 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VTC

	.method public hidebysig newslot abstract virtual 
		instance void get_VTCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3a 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VTCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_ST (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3b 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_ST

	.method public hidebysig newslot abstract virtual 
		instance void get_STTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3c 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_STTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3d 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_IT

	.method public hidebysig newslot abstract virtual 
		instance void get_ITTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3e 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_ITTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_LIQH (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 3f 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LIQH

	.method public hidebysig newslot abstract virtual 
		instance void get_LIQHTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 40 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LIQHTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_VAPH (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 41 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VAPH

	.method public hidebysig newslot abstract virtual 
		instance void get_VAPHTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 42 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VAPHTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_LIQS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 43 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LIQS

	.method public hidebysig newslot abstract virtual 
		instance void get_LIQSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 44 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_LIQSTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_VAPS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 45 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VAPS

	.method public hidebysig newslot abstract virtual 
		instance void get_VAPSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 46 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_VAPSTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_HyprotechID () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 47 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_HyprotechID

	.method public hidebysig specialname newslot abstract virtual 
		instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum get_Family () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 48 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_Family

	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_SubFamily () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 49 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_SubFamily

	.method public hidebysig newslot abstract virtual 
		instance void GetNonCondensable (
			[out] uint8& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4a 00 00 00 00 00
		)
	} // end of method IBasicCompound::GetNonCondensable

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGH (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4b 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_IGH

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4c 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_IGS

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGCP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4d 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_IGCP

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_CavettParameter (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4e 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_CavettParameter

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_COSTALDACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 4f 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_COSTALDACEN

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_COSTALDVCHAR (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 50 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_COSTALDVCHAR

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SRKACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 51 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_SRKACEN

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGHF25 (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 52 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_IGHF25

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGSF25 (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 53 00 00 00 00 00
		)
	} // end of method IBasicCompound::get_IGSF25

	// Properties
	.property instance int32 HyprotechID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 47 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.IBasicCompound::get_HyprotechID()
	}
	.property instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum Family()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 48 00 00 00 00 00
		)
		.get instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum AspenTech.Interop.ThContainers.IBasicCompound::get_Family()
	}
	.property instance string SubFamily()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 49 00 00 00 00 00
		)
		.get instance string AspenTech.Interop.ThContainers.IBasicCompound::get_SubFamily()
	}

} // end of class AspenTech.Interop.ThContainers.IBasicCompound

.class public auto ansi sealed AspenTech.Interop.ThContainers.tagExtrapolationEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eNoExtrapolation = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eNothingDefinedYet = int32(1)

} // end of class AspenTech.Interop.ThContainers.tagExtrapolationEnum

.class public auto ansi sealed AspenTech.Interop.ThContainers.tagCompoundFamilyEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eHydrocarbon = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eSolid = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eMiscellaneous = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eAmine = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eAlcohol = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eKetone = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eAldehyde = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eEster = int32(7)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eCarboxylicAcid = int32(8)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eHalogen = int32(9)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eNitrile = int32(10)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum ePhenol = int32(11)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum eEther = int32(12)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum ePolymer = int32(13)

} // end of class AspenTech.Interop.ThContainers.tagCompoundFamilyEnum

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 43 31 45 30 31 45 30 2d 34 44 43 39
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGG (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGG

	.method public hidebysig newslot abstract virtual 
		instance void get_IGGTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGGTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGH (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGH

	.method public hidebysig newslot abstract virtual 
		instance void get_IGHTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGHTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGS (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGS

	.method public hidebysig newslot abstract virtual 
		instance void get_IGSTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGSTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGCP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGCP

	.method public hidebysig newslot abstract virtual 
		instance void get_IGCPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGCPTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGHF25 (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGHF25

	.method public hidebysig newslot abstract virtual 
		instance void get_IGHF25TPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGHF25TPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGSF25 (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGSF25

	.method public hidebysig newslot abstract virtual 
		instance void get_IGSF25TPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGSF25TPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IGHC25 (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0d 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGHC25

	.method public hidebysig newslot abstract virtual 
		instance void get_IGHC25TPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 00 00 00 00
		)
	} // end of method ICompoundReferenceStateProperties::get_IGHC25TPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundReferenceStateProperties

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundPR
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 43 31 45 30 31 45 31 2d 34 44 43 39
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRTC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRTC

	.method public hidebysig newslot abstract virtual 
		instance void get_PRTCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRTCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRPC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRPC

	.method public hidebysig newslot abstract virtual 
		instance void get_PRPCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRPCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRVC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRVC

	.method public hidebysig newslot abstract virtual 
		instance void get_PRVCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRVCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRACEN

	.method public hidebysig newslot abstract virtual 
		instance void get_PRACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRACENTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRMC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRMC

	.method public hidebysig newslot abstract virtual 
		instance void get_PRMCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRMCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRPVOLT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRPVOLT

	.method public hidebysig newslot abstract virtual 
		instance void get_PRPVOLTTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method ICompoundPR::get_PRPVOLTTPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundPR

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundCOSTALD
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 43 31 45 30 31 45 32 2d 34 44 43 39
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_COSTALDACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundCOSTALD::get_COSTALDACEN

	.method public hidebysig newslot abstract virtual 
		instance void get_COSTALDACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundCOSTALD::get_COSTALDACENTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_COSTALDVCHAR (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundCOSTALD::get_COSTALDVCHAR

	.method public hidebysig newslot abstract virtual 
		instance void get_COSTALDVCHARTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundCOSTALD::get_COSTALDVCHARTPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundCOSTALD

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundCavett
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 45 44 41 46 34 34 33 30 2d 35 34 42 43
		2d 31 31 44 32 2d 42 38 44 36 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_CavettParameter (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundCavett::get_CavettParameter

	.method public hidebysig newslot abstract virtual 
		instance void get_CavettParameterTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundCavett::get_CavettParameterTPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundCavett

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundViscosity
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 45 44 41 46 34 34 33 31 2d 35 34 42 43
		2d 31 31 44 32 2d 42 38 44 36 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void get_ViscosityThetas (
			[out] float64& THETAA,
			[out] float64& THETAB
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundViscosity::get_ViscosityThetas

} // end of class AspenTech.Interop.ThContainers.ICompoundViscosity

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundChaoSeader
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 43 31 45 30 31 45 33 2d 34 44 43 39
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_ChaoSeaderACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundChaoSeader::get_ChaoSeaderACEN

	.method public hidebysig newslot abstract virtual 
		instance void get_ChaoSeaderACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundChaoSeader::get_ChaoSeaderACENTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_ChaoSeaderMVOL (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundChaoSeader::get_ChaoSeaderMVOL

	.method public hidebysig newslot abstract virtual 
		instance void get_ChaoSeaderMVOLTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundChaoSeader::get_ChaoSeaderMVOLTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_ChaoSeaderPVOLT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundChaoSeader::get_ChaoSeaderPVOLT

	.method public hidebysig newslot abstract virtual 
		instance void get_ChaoSeaderPVOLTTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundChaoSeader::get_ChaoSeaderPVOLTTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_ChaoSeaderSOLP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundChaoSeader::get_ChaoSeaderSOLP

	.method public hidebysig newslot abstract virtual 
		instance void get_ChaoSeaderSOLPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundChaoSeader::get_ChaoSeaderSOLPTPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundChaoSeader

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundChienNull
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 38 30 46 33 38 38 45 30 2d 45 36 44 38
		2d 31 31 44 32 2d 41 35 42 34 2d 30 30 41 30 43
		39 44 46 34 45 45 32 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_ChienNullMVOL (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundChienNull::get_ChienNullMVOL

	.method public hidebysig newslot abstract virtual 
		instance void get_ChienNullMVOLTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundChienNull::get_ChienNullMVOLTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_ChienNullPVOLT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundChienNull::get_ChienNullPVOLT

	.method public hidebysig newslot abstract virtual 
		instance void get_ChienNullPVOLTTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundChienNull::get_ChienNullPVOLTTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_ChienNullSOLP (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundChienNull::get_ChienNullSOLP

	.method public hidebysig newslot abstract virtual 
		instance void get_ChienNullSOLPTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundChienNull::get_ChienNullSOLPTPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundChienNull

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundVirial
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 39 31 32 46 31 34 35 30 2d 44 33 32 33
		2d 31 31 44 32 2d 41 35 42 32 2d 30 30 41 30 43
		39 44 46 34 45 45 32 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_VirialSOLV (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundVirial::get_VirialSOLV

	.method public hidebysig newslot abstract virtual 
		instance void get_VirialSOLVTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundVirial::get_VirialSOLVTPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundVirial

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundPRSV
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 43 31 45 30 31 45 34 2d 34 44 43 39
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRSVTC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVTC

	.method public hidebysig newslot abstract virtual 
		instance void get_PRSVTCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVTCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRSVPC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVPC

	.method public hidebysig newslot abstract virtual 
		instance void get_PRSVPCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVPCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRSVVC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVVC

	.method public hidebysig newslot abstract virtual 
		instance void get_PRSVVCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVVCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRSVACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVACEN

	.method public hidebysig newslot abstract virtual 
		instance void get_PRSVACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVACENTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRSVKAPPA (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVKAPPA

	.method public hidebysig newslot abstract virtual 
		instance void get_PRSVKAPPATPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVKAPPATPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PRSVPVOLT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVPVOLT

	.method public hidebysig newslot abstract virtual 
		instance void get_PRSVPVOLTTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method ICompoundPRSV::get_PRSVPVOLTTPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundPRSV

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundSRK
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 38 33 30 36 32 42 41 30 2d 35 31 38 32
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SRKTC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKTC

	.method public hidebysig newslot abstract virtual 
		instance void get_SRKTCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKTCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SRKPC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKPC

	.method public hidebysig newslot abstract virtual 
		instance void get_SRKPCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKPCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SRKVC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKVC

	.method public hidebysig newslot abstract virtual 
		instance void get_SRKVCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKVCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SRKACEN (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKACEN

	.method public hidebysig newslot abstract virtual 
		instance void get_SRKACENTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKACENTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SRKMC (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKMC

	.method public hidebysig newslot abstract virtual 
		instance void get_SRKMCTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKMCTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SRKPVOLT (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKPVOLT

	.method public hidebysig newslot abstract virtual 
		instance void get_SRKPVOLTTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method ICompoundSRK::get_SRKPVOLTTPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundSRK

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundWilson
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 43 31 45 30 31 45 35 2d 34 44 43 39
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_WilsonKVAL (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundWilson::get_WilsonKVAL

	.method public hidebysig newslot abstract virtual 
		instance void get_WilsonKVALTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundWilson::get_WilsonKVALTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_WilsonMVOL (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundWilson::get_WilsonMVOL

	.method public hidebysig newslot abstract virtual 
		instance void get_WilsonMVOLTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundWilson::get_WilsonMVOLTPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundWilson

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundID
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 37 46 32 44 39 38 30 2d 35 31 38 32
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_Name () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundID::get_Name

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfSynonymNames () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundID::get_NumberOfSynonymNames

	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_SynonymName (
			[in] int32 nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundID::get_SynonymName

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_PPAttribute () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundID::get_PPAttribute

	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_CASN () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundID::get_CASN

	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_IUPACName () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundID::get_IUPACName

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_HyprotechID () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundID::get_HyprotechID

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_PPDSID () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundID::get_PPDSID

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_DDBID () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ICompoundID::get_DDBID

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_DIPPRID () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ICompoundID::get_DIPPRID

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_CMAID () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ICompoundID::get_CMAID

	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_ChemicalFormula () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method ICompoundID::get_ChemicalFormula

	.method public hidebysig newslot abstract virtual 
		instance void IsWater () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0d 00 00 00 00 00
		)
	} // end of method ICompoundID::IsWater

	.method public hidebysig newslot abstract virtual 
		instance void IsDEG () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 00 00 00 00
		)
	} // end of method ICompoundID::IsDEG

	.method public hidebysig newslot abstract virtual 
		instance void IsTEG () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0f 00 00 00 00 00
		)
	} // end of method ICompoundID::IsTEG

	.method public hidebysig newslot abstract virtual 
		instance void IsEG () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 00 00 00 00
		)
	} // end of method ICompoundID::IsEG

	.method public hidebysig newslot abstract virtual 
		instance void IsMethanol () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 11 00 00 00 00 00
		)
	} // end of method ICompoundID::IsMethanol

	// Properties
	.property instance string Name()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance string AspenTech.Interop.ThContainers.ICompoundID::get_Name()
	}
	.property instance int32 NumberOfSynonymNames()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_NumberOfSynonymNames()
	}
	.property instance int32 PPAttribute()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_PPAttribute()
	}
	.property instance string CASN()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.get instance string AspenTech.Interop.ThContainers.ICompoundID::get_CASN()
	}
	.property instance string IUPACName()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
		.get instance string AspenTech.Interop.ThContainers.ICompoundID::get_IUPACName()
	}
	.property instance int32 HyprotechID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_HyprotechID()
	}
	.property instance int32 PPDSID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_PPDSID()
	}
	.property instance int32 DDBID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_DDBID()
	}
	.property instance int32 DIPPRID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_DIPPRID()
	}
	.property instance int32 CMAID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.ICompoundID::get_CMAID()
	}
	.property instance string ChemicalFormula()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
		.get instance string AspenTech.Interop.ThContainers.ICompoundID::get_ChemicalFormula()
	}

} // end of class AspenTech.Interop.ThContainers.ICompoundID

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundFamily
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 37 46 32 44 39 38 31 2d 35 31 38 32
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum get_Family () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundFamily::get_Family

	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_SubFamily () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundFamily::get_SubFamily

	.method public hidebysig specialname newslot abstract virtual 
		instance bool get_NonCondensable () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundFamily::get_NonCondensable

	// Properties
	.property instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum Family()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum AspenTech.Interop.ThContainers.ICompoundFamily::get_Family()
	}
	.property instance string SubFamily()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance string AspenTech.Interop.ThContainers.ICompoundFamily::get_SubFamily()
	}
	.property instance bool NonCondensable()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.get instance bool AspenTech.Interop.ThContainers.ICompoundFamily::get_NonCondensable()
	}

} // end of class AspenTech.Interop.ThContainers.ICompoundFamily

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundUNIFAC1
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 37 46 32 44 39 38 32 2d 35 31 38 32
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_UNIFAC1NumberOfGroups () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundUNIFAC1::get_UNIFAC1NumberOfGroups

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_UNIFAC1Groups (
			[out] object& marshal(idispatch) ppGroupTypeNo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundUNIFAC1::get_UNIFAC1Groups

	// Properties
	.property instance int32 UNIFAC1NumberOfGroups()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.ICompoundUNIFAC1::get_UNIFAC1NumberOfGroups()
	}

} // end of class AspenTech.Interop.ThContainers.ICompoundUNIFAC1

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundUNIQUAC1
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 39 44 43 39 37 38 30 2d 35 33 33 45
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void get_UNIQUAC1Parameters (
			[out] float64& pdR,
			[out] float64& pdQ
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundUNIQUAC1::get_UNIQUAC1Parameters

} // end of class AspenTech.Interop.ThContainers.ICompoundUNIQUAC1

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundSolidProperties
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 37 46 32 44 39 38 33 2d 35 31 38 32
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SolidAverageDiameter (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidAverageDiameter

	.method public hidebysig newslot abstract virtual 
		instance void get_SolidAverageDiameterTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidAverageDiameterTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SolidSphericity (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidSphericity

	.method public hidebysig newslot abstract virtual 
		instance void get_SolidSphericityTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidSphericityTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SolidSurfaceArea (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidSurfaceArea

	.method public hidebysig newslot abstract virtual 
		instance void get_SolidSurfaceAreaTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidSurfaceAreaTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SolidCarbon (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidCarbon

	.method public hidebysig newslot abstract virtual 
		instance void get_SolidCarbonTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidCarbonTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SolidHydrogen (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidHydrogen

	.method public hidebysig newslot abstract virtual 
		instance void get_SolidHydrogenTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidHydrogenTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SolidNitrogen (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidNitrogen

	.method public hidebysig newslot abstract virtual 
		instance void get_SolidNitrogenTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidNitrogenTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SolidOxygen (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0d 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidOxygen

	.method public hidebysig newslot abstract virtual 
		instance void get_SolidOxygenTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidOxygenTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SolidSulphur (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0f 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidSulphur

	.method public hidebysig newslot abstract virtual 
		instance void get_SolidSulphurTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidSulphurTPRange

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_SolidChlorine (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 11 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidChlorine

	.method public hidebysig newslot abstract virtual 
		instance void get_SolidChlorineTPRange (
			[out] float64& pdTMin,
			[out] float64& pdTMax,
			[out] float64& pdPMin,
			[out] float64& pdPMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 00 00 00 00
		)
	} // end of method ICompoundSolidProperties::get_SolidChlorineTPRange

} // end of class AspenTech.Interop.ThContainers.ICompoundSolidProperties

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundIDPut
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 30 34 34 33 36 42 43 2d 36 43 37 41
		2d 31 31 44 33 2d 42 46 31 37 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Name (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_Name

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfSynonymNames (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_NumberOfSynonymNames

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_SynonymName (
			[in] int32 nIdx,
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_SynonymName

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_PPAttribute (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_PPAttribute

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_CASN (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_CASN

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IUPACName (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_IUPACName

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_HyprotechID (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_HyprotechID

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_PPDSID (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_PPDSID

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_DDBID (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_DDBID

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_DIPPRID (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_DIPPRID

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_CMAID (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_CMAID

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_ChemicalFormula (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method ICompoundIDPut::set_ChemicalFormula

	// Properties
	.property instance string Name()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_Name(string)
	}
	.property instance int32 NumberOfSynonymNames()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_NumberOfSynonymNames(int32)
	}
	.property instance int32 PPAttribute()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_PPAttribute(int32)
	}
	.property instance string CASN()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_CASN(string)
	}
	.property instance string IUPACName()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_IUPACName(string)
	}
	.property instance int32 HyprotechID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_HyprotechID(int32)
	}
	.property instance int32 PPDSID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_PPDSID(int32)
	}
	.property instance int32 DDBID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_DDBID(int32)
	}
	.property instance int32 DIPPRID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_DIPPRID(int32)
	}
	.property instance int32 CMAID()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_CMAID(int32)
	}
	.property instance string ChemicalFormula()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundIDPut::set_ChemicalFormula(string)
	}

} // end of class AspenTech.Interop.ThContainers.ICompoundIDPut

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundFamilyPut
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 30 34 34 33 36 42 44 2d 36 43 37 41
		2d 31 31 44 33 2d 42 46 31 37 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Family (
			[in] valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundFamilyPut::set_Family

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_SubFamily (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundFamilyPut::set_SubFamily

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NonCondensable (
			[in] bool 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundFamilyPut::set_NonCondensable

	// Properties
	.property instance valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum Family()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundFamilyPut::set_Family(valuetype AspenTech.Interop.ThContainers.tagCompoundFamilyEnum)
	}
	.property instance string SubFamily()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundFamilyPut::set_SubFamily(string)
	}
	.property instance bool NonCondensable()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundFamilyPut::set_NonCondensable(bool)
	}

} // end of class AspenTech.Interop.ThContainers.ICompoundFamilyPut

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundUNIFAC1Put
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 30 34 34 33 36 42 45 2d 36 43 37 41
		2d 31 31 44 33 2d 42 46 31 37 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance void set_UNIFAC1NumberOfGroups (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundUNIFAC1Put::set_UNIFAC1NumberOfGroups

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_UNIFAC1Groups (
			[in] int32 nNumGroup,
			[in] object marshal(idispatch) ppGroupTypeNo,
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundUNIFAC1Put::set_UNIFAC1Groups

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_HYPUNIFACNoGr (
			[in] int32 nNumGroup,
			[in] class AspenTech.Interop.ThContainers.IIntegerArrayDisp marshal(interface) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundUNIFAC1Put::set_HYPUNIFACNoGr

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_HYPUNIFACSubGr (
			[in] int32 nNumGroup,
			[in] class AspenTech.Interop.ThContainers.IIntegerArrayDisp marshal(interface) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundUNIFAC1Put::set_HYPUNIFACSubGr

	// Properties
	.property instance int32 UNIFAC1NumberOfGroups()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundUNIFAC1Put::set_UNIFAC1NumberOfGroups(int32)
	}

} // end of class AspenTech.Interop.ThContainers.ICompoundUNIFAC1Put

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IIntegerArrayDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 34 42 43 32 42 37 31 2d 35 44 36 46
		2d 31 31 44 32 2d 42 38 44 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_Size () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IIntegerArrayDisp::get_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IIntegerArrayDisp::set_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IIntegerArrayDisp::get_IthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthValue (
			[in] int32 i,
			[in] int32 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IIntegerArrayDisp::set_IthValue

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IIntegerArrayDisp::Reset

	// Properties
	.property instance int32 Size()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.IIntegerArrayDisp::get_Size()
		.set instance void AspenTech.Interop.ThContainers.IIntegerArrayDisp::set_Size(int32)
	}

} // end of class AspenTech.Interop.ThContainers.IIntegerArrayDisp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundInitFromHypDB
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 42 37 37 37 42 45 39 30 2d 34 44 42 38
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void Init (
			[in] string marshal(bstr) strPath,
			[in] int32 nCompIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundInitFromHypDB::Init

} // end of class AspenTech.Interop.ThContainers.ICompoundInitFromHypDB

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundProp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 34 42 39 41 38 32 34 32 2d 35 33 46 45
		2d 31 31 44 33 2d 42 46 31 35 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetNumbOfProperty (
			[in] uint8 bFixed,
			[out] int32& nProps
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundProp::GetNumbOfProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetPropertyName (
			[in] uint8 bFixed,
			[in] int32 iProp,
			[out] string& marshal(bstr) Name,
			[out] valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum& 'type'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundProp::GetPropertyName

	.method public hidebysig newslot abstract virtual 
		instance void GetPropertyValue (
			[in] string marshal(bstr) Name,
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies,
			[out] float64& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundProp::GetPropertyValue

	.method public hidebysig newslot abstract virtual 
		instance void GetPropertyType (
			[in] string marshal(bstr) Name,
			[out] valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum& 'type'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundProp::GetPropertyType

	.method public hidebysig newslot abstract virtual 
		instance void GetEquationProperty (
			[in] string marshal(bstr) Name,
			[out] valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum& shape,
			[out] string& marshal(bstr) form,
			[out] float64& tmin,
			[out] float64& tmax,
			[out] float64& pmin,
			[out] float64& pmax,
			[out] int32& nParameters,
			[out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) pCoeff
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundProp::GetEquationProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetCOMProperty (
			[in] string marshal(bstr) Name,
			[out] string& marshal(bstr) ClassID,
			[out] class AspenTech.Interop.ThContainers.IPCProperty& marshal(interface) prop
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundProp::GetCOMProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetNumbOfCommonProperty (
			[out] int32& nProps
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundProp::GetNumbOfCommonProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetCommonPropertyName (
			[in] int32 iProp,
			[out] string& marshal(bstr) Name,
			[out] valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum& 'type'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundProp::GetCommonPropertyName

} // end of class AspenTech.Interop.ThContainers.ICompoundProp

.class public auto ansi sealed AspenTech.Interop.ThContainers.tagPropTypeEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum VoidProp = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum PointProp = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum EquationProp = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum COMProp = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum PointPropBSTR = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum PointPropLong = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum MultiPointPropBSTR = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum MultiPointPropLong = int32(7)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum MultiPointPropReal = int32(8)

} // end of class AspenTech.Interop.ThContainers.tagPropTypeEnum

.class public auto ansi sealed AspenTech.Interop.ThContainers.tagEquationShapeEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveHYPDB1 = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveHYPDB2 = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveHYPDB3 = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveHYPDB4 = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveHYPDB5 = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveHYPDB6 = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveHYPDB7 = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveHYPDB8 = int32(7)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveDIPPR107 = int32(8)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveHYPDB9 = int32(9)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveHYPDB10 = int32(10)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveDIPPR101 = int32(11)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveDIPPR102 = int32(12)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveDIPPR103 = int32(13)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveDIPPR104 = int32(14)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveDIPPR106 = int32(15)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveDIPPR114 = int32(16)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveDIPPR115 = int32(17)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveDIPPR116 = int32(18)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePOLY2 = int32(19)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePOLY3 = int32(20)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveANTO1 = int32(21)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveANTO2 = int32(22)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveQUOT1 = int32(23)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveEXPO1 = int32(24)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveEXPO2 = int32(25)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveWTSN1 = int32(26)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveKFAC2 = int32(27)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveKFAC4 = int32(28)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePPDS1 = int32(29)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePPDS8 = int32(30)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePPDS9 = int32(31)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePPDS10 = int32(32)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePPDS12 = int32(33)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePPDS14 = int32(34)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePPDS15 = int32(35)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePPDS16 = int32(36)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurvePPDS17 = int32(37)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum PropCurveVoid = int32(1000)

} // end of class AspenTech.Interop.ThContainers.tagEquationShapeEnum

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IRealArrayDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 34 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_Size () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::get_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::set_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::get_IthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthValue (
			[in] int32 i,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::set_IthValue

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::Reset

	.method public hidebysig newslot abstract virtual 
		instance void Copy (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) pArray
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::Copy

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_Values (
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method IRealArrayDisp::get_Values

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Values (
			[in] int32 nSize,
			[in] float64& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method IRealArrayDisp::set_Values

	// Properties
	.property instance int32 Size()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.IRealArrayDisp::get_Size()
		.set instance void AspenTech.Interop.ThContainers.IRealArrayDisp::set_Size(int32)
	}

} // end of class AspenTech.Interop.ThContainers.IRealArrayDisp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IPCProperty
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 46 36 35 43 46 39 30 2d 32 38 33 32
		2d 31 31 44 34 2d 42 46 34 46 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetProperty (
			[in] float64 dTemp,
			[in] float64 dPres,
			[in] valuetype AspenTech.Interop.ThContainers.tagExtrapolationEnum eExtrapolationMethod,
			[out] int32& pDependencies,
			[out] float64& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IPCProperty::GetProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetClassID (
			[out] string& marshal(bstr) ClassID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IPCProperty::GetClassID

	.method public hidebysig newslot abstract virtual 
		instance void GetClassName (
			[out] string& marshal(bstr) ClassName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IPCProperty::GetClassName

	.method public hidebysig newslot abstract virtual 
		instance void Store (
			[out] string& marshal(bstr) data
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IPCProperty::Store

	.method public hidebysig newslot abstract virtual 
		instance void Recall (
			[in] string marshal(bstr) data
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IPCProperty::Recall

	.method public hidebysig newslot abstract virtual 
		instance void Copy (
			[in] class AspenTech.Interop.ThContainers.IPCProperty marshal(interface) prop
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IPCProperty::Copy

	.method public hidebysig newslot abstract virtual 
		instance void GetMethod (
			[out] string& marshal(bstr) 'method'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method IPCProperty::GetMethod

} // end of class AspenTech.Interop.ThContainers.IPCProperty

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundPropPut
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 34 45 45 46 42 38 42 30 2d 32 41 38 37
		2d 31 31 44 34 2d 42 46 34 46 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void SetPointProperty (
			[in] string marshal(bstr) Name,
			[in] uint8 'fixed',
			[in] float64 dVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundPropPut::SetPointProperty

	.method public hidebysig newslot abstract virtual 
		instance void SetEquationProperty (
			[in] string marshal(bstr) Name,
			[in] uint8 'fixed',
			[in] valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum shape,
			[in] float64 tmin,
			[in] float64 tmax,
			[in] float64 pmin,
			[in] float64 pmax,
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) pCoeff
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundPropPut::SetEquationProperty

	.method public hidebysig newslot abstract virtual 
		instance void SetCOMProperty (
			[in] string marshal(bstr) Name,
			[in] uint8 'fixed',
			[in] string marshal(bstr) ClassName,
			[in] class AspenTech.Interop.ThContainers.IPCProperty marshal(interface) prop
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundPropPut::SetCOMProperty

	.method public hidebysig newslot abstract virtual 
		instance void ErasePropFromMap (
			[in] string marshal(bstr) Name,
			[in] uint8 'fixed'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundPropPut::ErasePropFromMap

	.method public hidebysig newslot abstract virtual 
		instance void FindProperty (
			[in] string marshal(bstr) Name,
			[out] uint8& find,
			[out] uint8& 'fixed'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundPropPut::FindProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetEquationInfo (
			[in] valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum shape,
			[out] string& marshal(bstr) form,
			[out] int32& nParameters
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundPropPut::GetEquationInfo

	.method public hidebysig newslot abstract virtual 
		instance void SetVoidProperty (
			[in] string marshal(bstr) Name,
			[in] uint8 'fixed'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundPropPut::SetVoidProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetPropertyLoader (
			[in] string marshal(bstr) propname,
			[out] string& marshal(bstr) loader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundPropPut::GetPropertyLoader

	.method public hidebysig newslot abstract virtual 
		instance void SetPropertyLoader (
			[in] string marshal(bstr) propname,
			[in] string marshal(bstr) loader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ICompoundPropPut::SetPropertyLoader

} // end of class AspenTech.Interop.ThContainers.ICompoundPropPut

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundCopy
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 34 42 39 41 38 32 34 31 2d 35 33 46 45
		2d 31 31 44 33 2d 42 46 31 35 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void CopyToThis (
			[in] int32 NewID,
			[in] object marshal(idispatch) OrigComp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundCopy::CopyToThis

} // end of class AspenTech.Interop.ThContainers.ICompoundCopy

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.XMLParserClient
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 35 46 37 38 39 39 34 2d 36 36 45 38
		2d 31 31 44 33 2d 38 45 42 33 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void CharacterData (
			[in] string marshal(bstr) userData
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method XMLParserClient::CharacterData

	.method public hidebysig newslot abstract virtual 
		instance void StartElement (
			[in] string marshal(bstr) Name,
			[in] class AspenTech.Interop.ThContainers.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method XMLParserClient::StartElement

	.method public hidebysig newslot abstract virtual 
		instance void EndElement (
			[in] string marshal(bstr) Name
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method XMLParserClient::EndElement

	.method public hidebysig newslot abstract virtual 
		instance void Comment (
			[in] string marshal(bstr) bstrComment
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
	} // end of method XMLParserClient::Comment

	.method public hidebysig newslot abstract virtual 
		instance void ProcessElement (
			[in] string marshal(bstr) Name,
			[in] class AspenTech.Interop.ThContainers.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method XMLParserClient::ProcessElement

	.method public hidebysig newslot abstract virtual 
		instance void Error (
			[in] string marshal(bstr) Error
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 02 60 00 00
		)
	} // end of method XMLParserClient::Error

	.method public hidebysig newslot abstract virtual 
		instance void StartDocument () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method XMLParserClient::StartDocument

	.method public hidebysig newslot abstract virtual 
		instance void EndDocument () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
	} // end of method XMLParserClient::EndDocument

} // end of class AspenTech.Interop.ThContainers.XMLParserClient

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.TaggedAttributes
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 37 37 45 44 42 42 30 2d 34 46 35 42
		2d 31 31 44 33 2d 38 45 41 45 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void Add (
			[in] string marshal(bstr) tag,
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method TaggedAttributes::Add

	.method public hidebysig newslot abstract virtual 
		instance void AddMultiple (
			[in] object marshal(struct) tags,
			[in] object marshal(struct) Values
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method TaggedAttributes::AddMultiple

	.method public hidebysig newslot abstract virtual 
		instance void find (
			[in] string marshal(bstr) tag,
			[out] string& marshal(bstr) retValue
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method TaggedAttributes::find

	.method public hidebysig newslot abstract virtual 
		instance void GetByIndex (
			[in] int32 index,
			[out] string& marshal(bstr) retTag,
			[out] string& marshal(bstr) retValue
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
	} // end of method TaggedAttributes::GetByIndex

	.method public hidebysig newslot abstract virtual 
		instance void GetMultiple (
			[out] object& marshal(struct) retTags,
			[out] object& marshal(struct) retValues
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method TaggedAttributes::GetMultiple

	.method public hidebysig newslot abstract virtual 
		instance void Size (
			[out] int32& Size
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 02 60 00 00
		)
	} // end of method TaggedAttributes::Size

} // end of class AspenTech.Interop.ThContainers.TaggedAttributes

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IXMLStore
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 46 36 46 43 46 44 34 30 2d 46 39 31 42
		2d 31 31 44 33 2d 42 46 34 36 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) StoreAsXML () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IXMLStore::StoreAsXML

} // end of class AspenTech.Interop.ThContainers.IXMLStore

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IUserProperty
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 42 42 39 42 33 33 37 30 2d 30 31 44 41
		2d 31 31 44 34 2d 42 46 34 42 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void SetUserProperty (
			[in] string marshal(bstr) strName,
			[in] string marshal(bstr) ClassID,
			[in] object marshal(idispatch) pProp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IUserProperty::SetUserProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetUserProperty (
			[in] string marshal(bstr) strName,
			[out] object& marshal(idispatch) pProp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IUserProperty::GetUserProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetUserPropertyClassID (
			[in] string marshal(bstr) strName,
			[out] string& marshal(bstr) ClassID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IUserProperty::GetUserPropertyClassID

	.method public hidebysig newslot abstract virtual 
		instance void DeleteUserProperty (
			[in] string marshal(bstr) strName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IUserProperty::DeleteUserProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetNumbOfUserProperty (
			[out] int32& nProp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IUserProperty::GetNumbOfUserProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetUserPropertyI (
			[in] int32 iProp,
			[out] string& marshal(bstr) Name,
			[out] string& marshal(bstr) ClassID,
			[out] object& marshal(idispatch) pProp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IUserProperty::GetUserPropertyI

} // end of class AspenTech.Interop.ThContainers.IUserProperty

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompEqnXYShape
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 33 41 42 32 31 45 33 30 2d 43 31 41 33
		2d 31 31 44 35 2d 42 46 41 35 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetEquationPropertyXYShape (
			[in] string marshal(bstr) Name,
			[out] valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum& xshape,
			[out] valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum& yshape,
			[out] float64& xnorm,
			[out] float64& ynorm,
			[out] float64& xpow,
			[out] float64& ypow,
			[out] float64& a,
			[out] float64& b
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompEqnXYShape::GetEquationPropertyXYShape

	.method public hidebysig newslot abstract virtual 
		instance void SetEquationPropertyXYShape (
			[in] string marshal(bstr) Name,
			[in] valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum xshape,
			[in] valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum yshape,
			[in] float64 xnorm,
			[in] float64 ynorm,
			[in] float64 xpow,
			[in] float64 ypow,
			[in] float64 a,
			[in] float64 b
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompEqnXYShape::SetEquationPropertyXYShape

} // end of class AspenTech.Interop.ThContainers.ICompEqnXYShape

.class public auto ansi sealed AspenTech.Interop.ThContainers.tagXYShapeEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMx = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMxr = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COM1mxr = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMlogx = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMlogxr = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMlog1mxr = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMlnx = int32(7)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMlnxr = int32(8)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMln1mxr = int32(9)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMexpx = int32(10)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMexpxr = int32(11)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMexp1mxr = int32(12)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMsinx = int32(13)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMcosx = int32(14)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMtanx = int32(15)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMsinxr = int32(16)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMcosxr = int32(17)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMtanxr = int32(18)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMsin1mxr = int32(19)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMcos1mxr = int32(20)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMtan1mxr = int32(21)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COM1mx = int32(22)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMxm1 = int32(23)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMxrm1 = int32(24)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMcuberoot1mxr = int32(25)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMxppdsm1 = int32(26)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMlnxxo = int32(27)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMxscale = int32(28)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMxxo = int32(29)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMrootxodx = int32(30)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMscalexy = int32(31)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMydx = int32(32)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMrootxdy = int32(33)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMxdp = int32(34)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMxp = int32(35)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum COMlnxp = int32(36)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagXYShapeEnum eNoShapeDefined = int32(1000)

} // end of class AspenTech.Interop.ThContainers.tagXYShapeEnum

.class public auto ansi import beforefieldinit AspenTech.Interop.ThContainers.COTHCompoundCollectionClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThContainers.ICompoundCollection,
	           AspenTech.Interop.ThContainers.COTHCompoundCollection,
	           AspenTech.Interop.ThContainers.ICompoundCollectionSetup,
	           AspenTech.Interop.ThContainers.ICompoundManipulation,
	           AspenTech.Interop.ThContainers.ICompCollnIPInfo,
	           AspenTech.Interop.ThContainers.XMLParserClient,
	           AspenTech.Interop.ThContainers.IXMLStore,
	           AspenTech.Interop.ThContainers.ILoadCompoundProp,
	           AspenTech.Interop.ThContainers.ISubCompList,
	           AspenTech.Interop.ThContainers.IQueryLoader,
	           AspenTech.Interop.ThContainers.IPureEstimatorHandler,
	           AspenTech.Interop.ThContainers.ISubCompList1
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 37 45 44 33 31 38 45 33 2d 35 31 42 36
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_Compound (
			[in] int32 nIndex
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance object AspenTech.Interop.ThContainers.ICompoundCollection::get_Compound(int32)
	} // end of method COTHCompoundCollectionClass::get_Compound

	.method public hidebysig specialname newslot virtual 
		instance void set_Compound (
			[in] int32 nIndex,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollection::set_Compound(int32, object)
	} // end of method COTHCompoundCollectionClass::set_Compound

	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfCompounds () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThContainers.ICompoundCollection::get_NumberOfCompounds()
	} // end of method COTHCompoundCollectionClass::get_NumberOfCompounds

	.method public hidebysig specialname newslot virtual 
		instance void set_NumberOfCompounds (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollection::set_NumberOfCompounds(int32)
	} // end of method COTHCompoundCollectionClass::set_NumberOfCompounds

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_InteractionParameters (
			[in] string marshal(bstr) strModel
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.override method instance object AspenTech.Interop.ThContainers.ICompoundCollection::get_InteractionParameters(string)
	} // end of method COTHCompoundCollectionClass::get_InteractionParameters

	.method public hidebysig specialname newslot virtual 
		instance void set_InteractionParameters (
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollectionSetup::set_InteractionParameters(object)
	} // end of method COTHCompoundCollectionClass::set_InteractionParameters

	.method public hidebysig newslot virtual 
		instance void AddCompound (
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollection::AddCompound(object)
	} // end of method COTHCompoundCollectionClass::AddCompound

	.method public hidebysig newslot virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollection::Reset()
	} // end of method COTHCompoundCollectionClass::Reset

	.method public hidebysig newslot virtual 
		instance void GetBasicCompound (
			[in] int32 nIndex,
			[out] class AspenTech.Interop.ThContainers.COTHCompound& marshal(interface) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollection::GetBasicCompound(int32, class AspenTech.Interop.ThContainers.COTHCompound&)
	} // end of method COTHCompoundCollectionClass::GetBasicCompound

	.method public hidebysig newslot virtual 
		instance void GetOffsetH (
			[out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) OffsetH
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollection::GetOffsetH(class AspenTech.Interop.ThContainers.IRealArrayDisp&)
	} // end of method COTHCompoundCollectionClass::GetOffsetH

	.method public hidebysig newslot virtual 
		instance void PutOffsetH (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) OffsetH
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollection::PutOffsetH(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	} // end of method COTHCompoundCollectionClass::PutOffsetH

	.method public hidebysig newslot virtual 
		instance void GetOffsetS (
			[out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) OffsetS
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollection::GetOffsetS(class AspenTech.Interop.ThContainers.IRealArrayDisp&)
	} // end of method COTHCompoundCollectionClass::GetOffsetS

	.method public hidebysig newslot virtual 
		instance void PutOffsetS (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) OffsetS
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollection::PutOffsetS(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	} // end of method COTHCompoundCollectionClass::PutOffsetS

	.method public hidebysig newslot virtual 
		instance void AddCompoundFromLoader (
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] string marshal(bstr) loader,
			[in] uint8 useloader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.ICompoundCollection::AddCompoundFromLoader(string, string, string, uint8)
	} // end of method COTHCompoundCollectionClass::AddCompoundFromLoader

	.method public hidebysig newslot virtual 
		instance void MoveCompound (
			[in] int32 compToMove,
			[in] int32 moveBeforeComp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundManipulation::MoveCompound(int32, int32)
	} // end of method COTHCompoundCollectionClass::MoveCompound

	.method public hidebysig newslot virtual 
		instance void RemoveLastCompound () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundManipulation::RemoveLastCompound()
	} // end of method COTHCompoundCollectionClass::RemoveLastCompound

	.method public hidebysig newslot virtual 
		instance void AddLastCompoundLoadIPs (
			[in] object marshal(idispatch) pVal,
			[in] string marshal(bstr) databasedir
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompoundManipulation::AddLastCompoundLoadIPs(object, string)
	} // end of method COTHCompoundCollectionClass::AddLastCompoundLoadIPs

	.method public hidebysig newslot virtual 
		instance void CompCollnIPInfo (
			[out] int32& numbIPs,
			[out] object& marshal(struct) modelnames,
			[out] object& marshal(struct) modelpanes
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ICompCollnIPInfo::CompCollnIPInfo(int32&, object&, object&)
	} // end of method COTHCompoundCollectionClass::CompCollnIPInfo

	.method public hidebysig newslot virtual 
		instance void CharacterData (
			[in] string marshal(bstr) userData
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::CharacterData(string)
	} // end of method COTHCompoundCollectionClass::CharacterData

	.method public hidebysig newslot virtual 
		instance void StartElement (
			[in] string marshal(bstr) Name,
			[in] class AspenTech.Interop.ThContainers.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::StartElement(string, class AspenTech.Interop.ThContainers.TaggedAttributes)
	} // end of method COTHCompoundCollectionClass::StartElement

	.method public hidebysig newslot virtual 
		instance void EndElement (
			[in] string marshal(bstr) Name
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::EndElement(string)
	} // end of method COTHCompoundCollectionClass::EndElement

	.method public hidebysig newslot virtual 
		instance void Comment (
			[in] string marshal(bstr) bstrComment
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::Comment(string)
	} // end of method COTHCompoundCollectionClass::Comment

	.method public hidebysig newslot virtual 
		instance void ProcessElement (
			[in] string marshal(bstr) Name,
			[in] class AspenTech.Interop.ThContainers.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::ProcessElement(string, class AspenTech.Interop.ThContainers.TaggedAttributes)
	} // end of method COTHCompoundCollectionClass::ProcessElement

	.method public hidebysig newslot virtual 
		instance void Error (
			[in] string marshal(bstr) Error
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::Error(string)
	} // end of method COTHCompoundCollectionClass::Error

	.method public hidebysig newslot virtual 
		instance void StartDocument () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::StartDocument()
	} // end of method COTHCompoundCollectionClass::StartDocument

	.method public hidebysig newslot virtual 
		instance void EndDocument () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.XMLParserClient::EndDocument()
	} // end of method COTHCompoundCollectionClass::EndDocument

	.method public hidebysig newslot virtual 
		instance string marshal(bstr) StoreAsXML () runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThContainers.IXMLStore::StoreAsXML()
	} // end of method COTHCompoundCollectionClass::StoreAsXML

	.method public hidebysig newslot virtual 
		instance void LoadAllCompounds (
			[in] string marshal(bstr) loader,
			[in] string marshal(bstr) searchkey,
			[in] uint8 useloader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::LoadAllCompounds(string, string, uint8)
	} // end of method COTHCompoundCollectionClass::LoadAllCompounds

	.method public hidebysig newslot virtual 
		instance void LoadOneCompound (
			[in] int32 iComp,
			[in] string marshal(bstr) loader,
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] uint8 useloader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::LoadOneCompound(int32, string, string, string, uint8)
	} // end of method COTHCompoundCollectionClass::LoadOneCompound

	.method public hidebysig newslot virtual 
		instance void LoadOneProperty (
			[in] int32 iComp,
			[in] string marshal(bstr) propname,
			[in] string marshal(bstr) loader,
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] uint8 useloader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::LoadOneProperty(int32, string, string, string, string, uint8)
	} // end of method COTHCompoundCollectionClass::LoadOneProperty

	.method public hidebysig newslot virtual 
		instance void SetDefaultLoader (
			[in] string marshal(bstr) Name,
			[in] string marshal(bstr) ClassName,
			[in] string marshal(bstr) path,
			[in] object marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::SetDefaultLoader(string, string, string, object)
	} // end of method COTHCompoundCollectionClass::SetDefaultLoader

	.method public hidebysig newslot virtual 
		instance void AddLoader (
			[in] string marshal(bstr) Name,
			[in] string marshal(bstr) ClassName,
			[in] string marshal(bstr) path,
			[in] object marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::AddLoader(string, string, string, object)
	} // end of method COTHCompoundCollectionClass::AddLoader

	.method public hidebysig newslot virtual 
		instance void RemoveLoader (
			[in] string marshal(bstr) Name
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::RemoveLoader(string)
	} // end of method COTHCompoundCollectionClass::RemoveLoader

	.method public hidebysig newslot virtual 
		instance void GetLoader (
			[in] string marshal(bstr) Name,
			[out] object& marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::GetLoader(string, object&)
	} // end of method COTHCompoundCollectionClass::GetLoader

	.method public hidebysig newslot virtual 
		instance void GetDefaultLoader (
			[out] string& marshal(bstr) Name,
			[out] object& marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::GetDefaultLoader(string&, object&)
	} // end of method COTHCompoundCollectionClass::GetDefaultLoader

	.method public hidebysig newslot virtual 
		instance void GetNumOfLoaders (
			[out] int32& nloader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::GetNumOfLoaders(int32&)
	} // end of method COTHCompoundCollectionClass::GetNumOfLoaders

	.method public hidebysig newslot virtual 
		instance void GetLoaderI (
			[in] int32 iloader,
			[out] string& marshal(bstr) Name,
			[out] object& marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::GetLoaderI(int32, string&, object&)
	} // end of method COTHCompoundCollectionClass::GetLoaderI

	.method public hidebysig newslot virtual 
		instance void SetAsDefaultLoader (
			[in] string marshal(bstr) Name
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ILoadCompoundProp::SetAsDefaultLoader(string)
	} // end of method COTHCompoundCollectionClass::SetAsDefaultLoader

	.method public hidebysig newslot virtual 
		instance void SetUpSubCompList (
			[in] class AspenTech.Interop.ThContainers.COTHCompoundCollection marshal(interface) pMasterCompList,
			[in] int32 nComp,
			[in] class AspenTech.Interop.ThContainers.IIntegerArrayDisp marshal(interface) pMapping
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ISubCompList::SetUpSubCompList(class AspenTech.Interop.ThContainers.COTHCompoundCollection, int32, class AspenTech.Interop.ThContainers.IIntegerArrayDisp)
	} // end of method COTHCompoundCollectionClass::SetUpSubCompList

	.method public hidebysig newslot virtual 
		instance void GetSubCompList (
			[out] int32& nComp,
			[out] class AspenTech.Interop.ThContainers.IIntegerArrayDisp& marshal(interface) pMapping
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ISubCompList::GetSubCompList(int32&, class AspenTech.Interop.ThContainers.IIntegerArrayDisp&)
	} // end of method COTHCompoundCollectionClass::GetSubCompList

	.method public hidebysig newslot virtual 
		instance void GetHypIDs (
			[in] string marshal(bstr) strPath,
			[in] int32 nComp,
			[in] string marshal(bstr) identifierName,
			[in] object& marshal(struct) identifiers,
			[in] [out] object& marshal(struct) hyprotechIDs
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IQueryLoader::GetHypIDs(string, int32, string, object&, object&)
	} // end of method COTHCompoundCollectionClass::GetHypIDs

	.method public hidebysig newslot virtual 
		instance void GetNumbEstimators (
			[in] [out] int32& nEstimators,
			[in] [out] object& marshal(struct) Names
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::GetNumbEstimators(int32&, object&)
	} // end of method COTHCompoundCollectionClass::GetNumbEstimators

	.method public hidebysig newslot virtual 
		instance void GetEstimatorInfo (
			[in] int32 iEstimator,
			[in] [out] string& marshal(bstr) Name,
			[in] [out] string& marshal(bstr) Version,
			[in] [out] uint8& NeedPath,
			[in] [out] string& marshal(bstr) Note,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::GetEstimatorInfo(int32, string&, string&, uint8&, string&, int32&)
	} // end of method COTHCompoundCollectionClass::GetEstimatorInfo

	.method public hidebysig newslot virtual 
		instance void GetEstSupportedProps (
			[in] int32 iEstimator,
			[in] [out] int32& nProp,
			[in] [out] object& marshal(struct) Props,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::GetEstSupportedProps(int32, int32&, object&, int32&)
	} // end of method COTHCompoundCollectionClass::GetEstSupportedProps

	.method public hidebysig newslot virtual 
		instance void EstCanDo (
			[in] int32 iEstimator,
			[in] string marshal(bstr) prop,
			[in] [out] int32& nMethods,
			[in] [out] object& marshal(struct) Methods,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::EstCanDo(int32, string, int32&, object&, int32&)
	} // end of method COTHCompoundCollectionClass::EstCanDo

	.method public hidebysig newslot virtual 
		instance void EstUnknownProps (
			[in] int32 iEstimator,
			[in] int32 iComp,
			[in] int32 nSpecProps,
			[in] object marshal(struct) SpecProps,
			[in] object marshal(struct) SpecMethods,
			[in] object marshal(idispatch) errorLog,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::EstUnknownProps(int32, int32, int32, object, object, object, int32&)
	} // end of method COTHCompoundCollectionClass::EstUnknownProps

	.method public hidebysig newslot virtual 
		instance void EstProp (
			[in] int32 iEstimator,
			[in] int32 iComp,
			[in] string marshal(bstr) prop,
			[in] string marshal(bstr) 'method',
			[in] uint8 Replace,
			[in] object marshal(idispatch) errorLog,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::EstProp(int32, int32, string, string, uint8, object, int32&)
	} // end of method COTHCompoundCollectionClass::EstProp

	.method public hidebysig newslot virtual 
		instance void IsEstReady (
			[in] int32 iEstimator,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::IsEstReady(int32, int32&)
	} // end of method COTHCompoundCollectionClass::IsEstReady

	.method public hidebysig newslot virtual 
		instance void FindEstimator (
			[in] string marshal(bstr) Name,
			[in] [out] int32& iEstimator,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::FindEstimator(string, int32&, int32&)
	} // end of method COTHCompoundCollectionClass::FindEstimator

	.method public hidebysig newslot virtual 
		instance void GetEstimator (
			[in] int32 iEstimator,
			[in] [out] object& marshal(idispatch) pEstimator,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::GetEstimator(int32, object&, int32&)
	} // end of method COTHCompoundCollectionClass::GetEstimator

	.method public hidebysig newslot virtual 
		instance void AddEstimator (
			[in] string marshal(bstr) Name,
			[in] string marshal(bstr) ClassName,
			[in] string marshal(bstr) path,
			[in] object marshal(idispatch) pEstimator
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::AddEstimator(string, string, string, object)
	} // end of method COTHCompoundCollectionClass::AddEstimator

	.method public hidebysig newslot virtual 
		instance void SetAsDefault (
			[in] int32 iEstimator,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::SetAsDefault(int32, int32&)
	} // end of method COTHCompoundCollectionClass::SetAsDefault

	.method public hidebysig newslot virtual 
		instance void RemoveEstimator (
			[in] int32 iEstimator,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IPureEstimatorHandler::RemoveEstimator(int32, int32&)
	} // end of method COTHCompoundCollectionClass::RemoveEstimator

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThContainers.ISubCompList1.SetUpSubCompList (
			[in] class AspenTech.Interop.ThContainers.COTHCompoundCollection marshal(interface) pMasterCompList,
			[in] int32 nComp,
			[in] class AspenTech.Interop.ThContainers.IIntegerArrayDisp marshal(interface) pMapping
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ISubCompList1::SetUpSubCompList(class AspenTech.Interop.ThContainers.COTHCompoundCollection, int32, class AspenTech.Interop.ThContainers.IIntegerArrayDisp)
	} // end of method COTHCompoundCollectionClass::AspenTech.Interop.ThContainers.ISubCompList1.SetUpSubCompList

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThContainers.ISubCompList1.GetSubCompList (
			[out] int32& nComp,
			[out] class AspenTech.Interop.ThContainers.IIntegerArrayDisp& marshal(interface) pMapping
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ISubCompList1::GetSubCompList(int32&, class AspenTech.Interop.ThContainers.IIntegerArrayDisp&)
	} // end of method COTHCompoundCollectionClass::AspenTech.Interop.ThContainers.ISubCompList1.GetSubCompList

	.method public hidebysig newslot virtual 
		instance void GetSubCompList1 (
			[out] int32& nComp,
			[in] class AspenTech.Interop.ThContainers.IIntegerArrayDisp marshal(interface) pMapping,
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.ISubCompList1::GetSubCompList1(int32&, class AspenTech.Interop.ThContainers.IIntegerArrayDisp, int32)
	} // end of method COTHCompoundCollectionClass::GetSubCompList1

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHCompoundCollectionClass::.ctor

	// Properties
	.property instance int32 AspenTech.Interop.ThContainers.ICompoundCollection.NumberOfCompounds()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.COTHCompoundCollectionClass::get_NumberOfCompounds()
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundCollectionClass::set_NumberOfCompounds(int32)
	}
	.property instance object AspenTech.Interop.ThContainers.ICompoundCollectionSetup.InteractionParameters()
	{
		.set instance void AspenTech.Interop.ThContainers.COTHCompoundCollectionClass::set_InteractionParameters(object)
	}

} // end of class AspenTech.Interop.ThContainers.COTHCompoundCollectionClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.COTHCompoundCollection
	implements AspenTech.Interop.ThContainers.ICompoundCollection
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 39 37 32 32 41 36 44 31 2d 35 31 38 35
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 3a 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 43 6f 6e 74 61 69 6e 65 72
		73 2e 43 4f 54 48 43 6f 6d 70 6f 75 6e 64 43 6f
		6c 6c 65 63 74 69 6f 6e 43 6c 61 73 73 00 00
	)
} // end of class AspenTech.Interop.ThContainers.COTHCompoundCollection

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundCollection
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 39 37 32 32 41 36 44 31 2d 35 31 38 35
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_Compound (
			[in] int32 nIndex
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundCollection::get_Compound

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Compound (
			[in] int32 nIndex,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundCollection::set_Compound

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfCompounds () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundCollection::get_NumberOfCompounds

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfCompounds (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundCollection::set_NumberOfCompounds

	.method public hidebysig newslot abstract virtual 
		instance void AddCompound (
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundCollection::AddCompound

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_InteractionParameters (
			[in] string marshal(bstr) strModel
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICompoundCollection::get_InteractionParameters

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICompoundCollection::Reset

	.method public hidebysig newslot abstract virtual 
		instance void GetBasicCompound (
			[in] int32 nIndex,
			[out] class AspenTech.Interop.ThContainers.COTHCompound& marshal(interface) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICompoundCollection::GetBasicCompound

	.method public hidebysig newslot abstract virtual 
		instance void GetOffsetH (
			[out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) OffsetH
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICompoundCollection::GetOffsetH

	.method public hidebysig newslot abstract virtual 
		instance void PutOffsetH (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) OffsetH
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICompoundCollection::PutOffsetH

	.method public hidebysig newslot abstract virtual 
		instance void GetOffsetS (
			[out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) OffsetS
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ICompoundCollection::GetOffsetS

	.method public hidebysig newslot abstract virtual 
		instance void PutOffsetS (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) OffsetS
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ICompoundCollection::PutOffsetS

	.method public hidebysig newslot abstract virtual 
		instance void AddCompoundFromLoader (
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] string marshal(bstr) loader,
			[in] uint8 useloader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ICompoundCollection::AddCompoundFromLoader

	// Properties
	.property instance int32 NumberOfCompounds()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.ICompoundCollection::get_NumberOfCompounds()
		.set instance void AspenTech.Interop.ThContainers.ICompoundCollection::set_NumberOfCompounds(int32)
	}

} // end of class AspenTech.Interop.ThContainers.ICompoundCollection

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundCollectionSetup
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 00 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 38 39 34 45 30 44 46 30 2d 36 32 44 39
		2d 31 31 44 32 2d 42 38 45 30 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance void set_InteractionParameters (
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
	} // end of method ICompoundCollectionSetup::set_InteractionParameters

	// Properties
	.property instance object InteractionParameters()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
		.set instance void AspenTech.Interop.ThContainers.ICompoundCollectionSetup::set_InteractionParameters(object)
	}

} // end of class AspenTech.Interop.ThContainers.ICompoundCollectionSetup

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompoundManipulation
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 33 34 42 30 32 39 39 31 2d 36 43 37 30
		2d 31 31 44 33 2d 41 35 44 33 2d 30 30 41 30 43
		39 44 46 34 32 32 42 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void MoveCompound (
			[in] int32 compToMove,
			[in] int32 moveBeforeComp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompoundManipulation::MoveCompound

	.method public hidebysig newslot abstract virtual 
		instance void RemoveLastCompound () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICompoundManipulation::RemoveLastCompound

	.method public hidebysig newslot abstract virtual 
		instance void AddLastCompoundLoadIPs (
			[in] object marshal(idispatch) pVal,
			[in] string marshal(bstr) databasedir
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICompoundManipulation::AddLastCompoundLoadIPs

} // end of class AspenTech.Interop.ThContainers.ICompoundManipulation

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICompCollnIPInfo
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 46 38 31 44 45 41 39 31 2d 45 41 33 41
		2d 31 31 44 33 2d 41 36 31 39 2d 30 30 41 30 43
		39 44 46 34 32 32 42 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void CompCollnIPInfo (
			[out] int32& numbIPs,
			[out] object& marshal(struct) modelnames,
			[out] object& marshal(struct) modelpanes
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICompCollnIPInfo::CompCollnIPInfo

} // end of class AspenTech.Interop.ThContainers.ICompCollnIPInfo

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ILoadCompoundProp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 37 38 38 30 45 38 30 2d 34 37 41 46
		2d 31 31 44 34 2d 42 46 35 31 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void LoadAllCompounds (
			[in] string marshal(bstr) loader,
			[in] string marshal(bstr) searchkey,
			[in] uint8 useloader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::LoadAllCompounds

	.method public hidebysig newslot abstract virtual 
		instance void LoadOneCompound (
			[in] int32 iComp,
			[in] string marshal(bstr) loader,
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] uint8 useloader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::LoadOneCompound

	.method public hidebysig newslot abstract virtual 
		instance void LoadOneProperty (
			[in] int32 iComp,
			[in] string marshal(bstr) propname,
			[in] string marshal(bstr) loader,
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] uint8 useloader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::LoadOneProperty

	.method public hidebysig newslot abstract virtual 
		instance void SetDefaultLoader (
			[in] string marshal(bstr) Name,
			[in] string marshal(bstr) ClassName,
			[in] string marshal(bstr) path,
			[in] object marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::SetDefaultLoader

	.method public hidebysig newslot abstract virtual 
		instance void AddLoader (
			[in] string marshal(bstr) Name,
			[in] string marshal(bstr) ClassName,
			[in] string marshal(bstr) path,
			[in] object marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::AddLoader

	.method public hidebysig newslot abstract virtual 
		instance void RemoveLoader (
			[in] string marshal(bstr) Name
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::RemoveLoader

	.method public hidebysig newslot abstract virtual 
		instance void GetLoader (
			[in] string marshal(bstr) Name,
			[out] object& marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::GetLoader

	.method public hidebysig newslot abstract virtual 
		instance void GetDefaultLoader (
			[out] string& marshal(bstr) Name,
			[out] object& marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::GetDefaultLoader

	.method public hidebysig newslot abstract virtual 
		instance void GetNumOfLoaders (
			[out] int32& nloader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::GetNumOfLoaders

	.method public hidebysig newslot abstract virtual 
		instance void GetLoaderI (
			[in] int32 iloader,
			[out] string& marshal(bstr) Name,
			[out] object& marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::GetLoaderI

	.method public hidebysig newslot abstract virtual 
		instance void SetAsDefaultLoader (
			[in] string marshal(bstr) Name
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ILoadCompoundProp::SetAsDefaultLoader

} // end of class AspenTech.Interop.ThContainers.ILoadCompoundProp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ISubCompList
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 45 32 38 45 30 32 32 30 2d 46 31 37 31
		2d 31 31 44 34 2d 42 46 38 46 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void SetUpSubCompList (
			[in] class AspenTech.Interop.ThContainers.COTHCompoundCollection marshal(interface) pMasterCompList,
			[in] int32 nComp,
			[in] class AspenTech.Interop.ThContainers.IIntegerArrayDisp marshal(interface) pMapping
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ISubCompList::SetUpSubCompList

	.method public hidebysig newslot abstract virtual 
		instance void GetSubCompList (
			[out] int32& nComp,
			[out] class AspenTech.Interop.ThContainers.IIntegerArrayDisp& marshal(interface) pMapping
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ISubCompList::GetSubCompList

} // end of class AspenTech.Interop.ThContainers.ISubCompList

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IQueryLoader
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 43 46 36 39 39 35 42 38 2d 38 41 42 39
		2d 34 35 31 33 2d 38 41 34 30 2d 36 32 44 44 34
		36 43 44 38 44 33 31 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetHypIDs (
			[in] string marshal(bstr) strPath,
			[in] int32 nComp,
			[in] string marshal(bstr) identifierName,
			[in] object& marshal(struct) identifiers,
			[in] [out] object& marshal(struct) hyprotechIDs
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IQueryLoader::GetHypIDs

} // end of class AspenTech.Interop.ThContainers.IQueryLoader

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IPureEstimatorHandler
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 34 46 46 46 35 35 41 30 2d 33 31 32 45
		2d 31 31 44 36 2d 42 38 37 45 2d 30 30 30 33 34
		37 41 37 34 36 36 30 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetNumbEstimators (
			[in] [out] int32& nEstimators,
			[in] [out] object& marshal(struct) Names
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::GetNumbEstimators

	.method public hidebysig newslot abstract virtual 
		instance void GetEstimatorInfo (
			[in] int32 iEstimator,
			[in] [out] string& marshal(bstr) Name,
			[in] [out] string& marshal(bstr) Version,
			[in] [out] uint8& NeedPath,
			[in] [out] string& marshal(bstr) Note,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::GetEstimatorInfo

	.method public hidebysig newslot abstract virtual 
		instance void GetEstSupportedProps (
			[in] int32 iEstimator,
			[in] [out] int32& nProp,
			[in] [out] object& marshal(struct) Props,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::GetEstSupportedProps

	.method public hidebysig newslot abstract virtual 
		instance void EstCanDo (
			[in] int32 iEstimator,
			[in] string marshal(bstr) prop,
			[in] [out] int32& nMethods,
			[in] [out] object& marshal(struct) Methods,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::EstCanDo

	.method public hidebysig newslot abstract virtual 
		instance void EstUnknownProps (
			[in] int32 iEstimator,
			[in] int32 iComp,
			[in] int32 nSpecProps,
			[in] object marshal(struct) SpecProps,
			[in] object marshal(struct) SpecMethods,
			[in] object marshal(idispatch) errorLog,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::EstUnknownProps

	.method public hidebysig newslot abstract virtual 
		instance void EstProp (
			[in] int32 iEstimator,
			[in] int32 iComp,
			[in] string marshal(bstr) prop,
			[in] string marshal(bstr) 'method',
			[in] uint8 Replace,
			[in] object marshal(idispatch) errorLog,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::EstProp

	.method public hidebysig newslot abstract virtual 
		instance void IsEstReady (
			[in] int32 iEstimator,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::IsEstReady

	.method public hidebysig newslot abstract virtual 
		instance void FindEstimator (
			[in] string marshal(bstr) Name,
			[in] [out] int32& iEstimator,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::FindEstimator

	.method public hidebysig newslot abstract virtual 
		instance void GetEstimator (
			[in] int32 iEstimator,
			[in] [out] object& marshal(idispatch) pEstimator,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::GetEstimator

	.method public hidebysig newslot abstract virtual 
		instance void AddEstimator (
			[in] string marshal(bstr) Name,
			[in] string marshal(bstr) ClassName,
			[in] string marshal(bstr) path,
			[in] object marshal(idispatch) pEstimator
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::AddEstimator

	.method public hidebysig newslot abstract virtual 
		instance void SetAsDefault (
			[in] int32 iEstimator,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::SetAsDefault

	.method public hidebysig newslot abstract virtual 
		instance void RemoveEstimator (
			[in] int32 iEstimator,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method IPureEstimatorHandler::RemoveEstimator

} // end of class AspenTech.Interop.ThContainers.IPureEstimatorHandler

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ISubCompList1
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 30 36 42 41 42 33 31 30 2d 43 31 43 32
		2d 31 31 44 36 2d 42 38 39 36 2d 30 30 30 33 34
		37 41 37 34 36 36 30 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void SetUpSubCompList (
			[in] class AspenTech.Interop.ThContainers.COTHCompoundCollection marshal(interface) pMasterCompList,
			[in] int32 nComp,
			[in] class AspenTech.Interop.ThContainers.IIntegerArrayDisp marshal(interface) pMapping
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ISubCompList1::SetUpSubCompList

	.method public hidebysig newslot abstract virtual 
		instance void GetSubCompList (
			[out] int32& nComp,
			[out] class AspenTech.Interop.ThContainers.IIntegerArrayDisp& marshal(interface) pMapping
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ISubCompList1::GetSubCompList

	.method public hidebysig newslot abstract virtual 
		instance void GetSubCompList1 (
			[out] int32& nComp,
			[in] class AspenTech.Interop.ThContainers.IIntegerArrayDisp marshal(interface) pMapping,
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ISubCompList1::GetSubCompList1

} // end of class AspenTech.Interop.ThContainers.ISubCompList1

.class public auto ansi import beforefieldinit AspenTech.Interop.ThContainers.COTHPhaseClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThContainers.IBasicPhase,
	           AspenTech.Interop.ThContainers.COTHPhase,
	           AspenTech.Interop.ThContainers.IEnumeratedPropertyContainer,
	           AspenTech.Interop.ThContainers.IRegisterableObject,
	           AspenTech.Interop.ThContainers.IUserPhaseType,
	           AspenTech.Interop.ThContainers.IDerivativeProp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 35 42 37 46 42 39 32 2d 35 32 33 36
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot virtual 
		instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum get_PhaseType () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
		.override method instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum AspenTech.Interop.ThContainers.IBasicPhase::get_PhaseType()
	} // end of method COTHPhaseClass::get_PhaseType

	.method public hidebysig specialname newslot virtual 
		instance void set_PhaseType (
			[in] valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_PhaseType(valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum)
	} // end of method COTHPhaseClass::set_PhaseType

	.method public hidebysig specialname newslot virtual 
		instance valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum get_PhaseStatus () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
		.override method instance valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum AspenTech.Interop.ThContainers.IBasicPhase::get_PhaseStatus()
	} // end of method COTHPhaseClass::get_PhaseStatus

	.method public hidebysig specialname newslot virtual 
		instance void set_PhaseStatus (
			[in] valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_PhaseStatus(valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum)
	} // end of method COTHPhaseClass::set_PhaseStatus

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PhaseFraction () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_PhaseFraction()
	} // end of method COTHPhaseClass::get_PhaseFraction

	.method public hidebysig specialname newslot virtual 
		instance void set_PhaseFraction (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_PhaseFraction(float64)
	} // end of method COTHPhaseClass::set_PhaseFraction

	.method public hidebysig specialname newslot virtual 
		instance float64 get_PhaseMassFraction () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_PhaseMassFraction()
	} // end of method COTHPhaseClass::get_PhaseMassFraction

	.method public hidebysig specialname newslot virtual 
		instance void set_PhaseMassFraction (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_PhaseMassFraction(float64)
	} // end of method COTHPhaseClass::set_PhaseMassFraction

	.method public hidebysig specialname newslot virtual 
		instance float64 get_Pressure () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Pressure()
	} // end of method COTHPhaseClass::get_Pressure

	.method public hidebysig specialname newslot virtual 
		instance void set_Pressure (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Pressure(float64)
	} // end of method COTHPhaseClass::set_Pressure

	.method public hidebysig specialname newslot virtual 
		instance float64 get_Temperature () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Temperature()
	} // end of method COTHPhaseClass::get_Temperature

	.method public hidebysig specialname newslot virtual 
		instance void set_Temperature (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Temperature(float64)
	} // end of method COTHPhaseClass::set_Temperature

	.method public hidebysig specialname newslot virtual 
		instance float64 get_Homotopy () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Homotopy()
	} // end of method COTHPhaseClass::get_Homotopy

	.method public hidebysig specialname newslot virtual 
		instance void set_Homotopy (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Homotopy(float64)
	} // end of method COTHPhaseClass::set_Homotopy

	.method public hidebysig specialname newslot virtual 
		instance float64 get_Enthalpy () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Enthalpy()
	} // end of method COTHPhaseClass::get_Enthalpy

	.method public hidebysig specialname newslot virtual 
		instance void set_Enthalpy (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Enthalpy(float64)
	} // end of method COTHPhaseClass::set_Enthalpy

	.method public hidebysig specialname newslot virtual 
		instance float64 get_Entropy () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Entropy()
	} // end of method COTHPhaseClass::get_Entropy

	.method public hidebysig specialname newslot virtual 
		instance void set_Entropy (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Entropy(float64)
	} // end of method COTHPhaseClass::set_Entropy

	.method public hidebysig specialname newslot virtual 
		instance float64 get_Cp () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Cp()
	} // end of method COTHPhaseClass::get_Cp

	.method public hidebysig specialname newslot virtual 
		instance void set_Cp (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Cp(float64)
	} // end of method COTHPhaseClass::set_Cp

	.method public hidebysig specialname newslot virtual 
		instance float64 get_MolarVolume () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_MolarVolume()
	} // end of method COTHPhaseClass::get_MolarVolume

	.method public hidebysig specialname newslot virtual 
		instance void set_MolarVolume (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_MolarVolume(float64)
	} // end of method COTHPhaseClass::set_MolarVolume

	.method public hidebysig specialname newslot virtual 
		instance float64 get_MolecularWeight () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 16 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_MolecularWeight()
	} // end of method COTHPhaseClass::get_MolecularWeight

	.method public hidebysig specialname newslot virtual 
		instance void set_MolecularWeight (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 16 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_MolecularWeight(float64)
	} // end of method COTHPhaseClass::set_MolecularWeight

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_MolarComposition () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 18 00 02 60 00 00
		)
		.override method instance object AspenTech.Interop.ThContainers.IBasicPhase::get_MolarComposition()
	} // end of method COTHPhaseClass::get_MolarComposition

	.method public hidebysig specialname newslot virtual 
		instance void set_MolarComposition (
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 18 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_MolarComposition(object)
	} // end of method COTHPhaseClass::set_MolarComposition

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_MassComposition () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1a 00 02 60 00 00
		)
		.override method instance object AspenTech.Interop.ThContainers.IBasicPhase::get_MassComposition()
	} // end of method COTHPhaseClass::get_MassComposition

	.method public hidebysig specialname newslot virtual 
		instance void set_MassComposition (
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1a 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_MassComposition(object)
	} // end of method COTHPhaseClass::set_MassComposition

	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfCompounds () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1d 00 02 60 00 00
		)
		.override method instance int32 AspenTech.Interop.ThContainers.IBasicPhase::get_NumberOfCompounds()
	} // end of method COTHPhaseClass::get_NumberOfCompounds

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_Compounds () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1e 00 02 60 00 00
		)
		.override method instance object AspenTech.Interop.ThContainers.IBasicPhase::get_Compounds()
	} // end of method COTHPhaseClass::get_Compounds

	.method public hidebysig specialname newslot virtual 
		instance class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) get_MolarCompositionDisp () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 23 00 02 60 00 00
		)
		.override method instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.IBasicPhase::get_MolarCompositionDisp()
	} // end of method COTHPhaseClass::get_MolarCompositionDisp

	.method public hidebysig specialname newslot virtual 
		instance void set_MolarCompositionDisp (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 23 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_MolarCompositionDisp(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	} // end of method COTHPhaseClass::set_MolarCompositionDisp

	.method public hidebysig specialname newslot virtual 
		instance class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) get_LnFugacity () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 25 00 02 60 00 00
		)
		.override method instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.IBasicPhase::get_LnFugacity()
	} // end of method COTHPhaseClass::get_LnFugacity

	.method public hidebysig specialname newslot virtual 
		instance void set_LnFugacity (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 25 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_LnFugacity(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	} // end of method COTHPhaseClass::set_LnFugacity

	.method public hidebysig specialname newslot virtual 
		instance class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) get_LnFugacityCoeff () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 27 00 02 60 00 00
		)
		.override method instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.IBasicPhase::get_LnFugacityCoeff()
	} // end of method COTHPhaseClass::get_LnFugacityCoeff

	.method public hidebysig specialname newslot virtual 
		instance void set_LnFugacityCoeff (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 27 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_LnFugacityCoeff(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	} // end of method COTHPhaseClass::set_LnFugacityCoeff

	.method public hidebysig specialname newslot virtual 
		instance uint8 get_IsPseudoRoot () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 29 00 02 60 00 00
		)
		.override method instance uint8 AspenTech.Interop.ThContainers.IBasicPhase::get_IsPseudoRoot()
	} // end of method COTHPhaseClass::get_IsPseudoRoot

	.method public hidebysig specialname newslot virtual 
		instance void set_IsPseudoRoot (
			[in] uint8 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 29 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::set_IsPseudoRoot(uint8)
	} // end of method COTHPhaseClass::set_IsPseudoRoot

	.method public hidebysig specialname newslot virtual 
		instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum get_UserPhaseType () runtime managed internalcall 
	{
		.override method instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum AspenTech.Interop.ThContainers.IUserPhaseType::get_UserPhaseType()
	} // end of method COTHPhaseClass::get_UserPhaseType

	.method public hidebysig specialname newslot virtual 
		instance void set_UserPhaseType (
			[in] valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IUserPhaseType::set_UserPhaseType(valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum)
	} // end of method COTHPhaseClass::set_UserPhaseType

	.method public hidebysig newslot virtual 
		instance void Finalize (
			[in] object marshal(idispatch) pCompList
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1c 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::Finalize(object)
	} // end of method COTHPhaseClass::Finalize

	.method public hidebysig newslot virtual 
		instance void ResetProperties (
			[in] int32 dwSettings
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1f 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::ResetProperties(int32)
	} // end of method COTHPhaseClass::ResetProperties

	.method public hidebysig newslot virtual 
		instance bool IsActivePhase () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 20 00 02 60 00 00
		)
		.override method instance bool AspenTech.Interop.ThContainers.IBasicPhase::IsActivePhase()
	} // end of method COTHPhaseClass::IsActivePhase

	.method public hidebysig newslot virtual 
		instance void CopyProperties (
			[in] object marshal(idispatch) pPhase
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 21 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::CopyProperties(object)
	} // end of method COTHPhaseClass::CopyProperties

	.method public hidebysig newslot virtual 
		instance void GetCompounds (
			[out] class AspenTech.Interop.ThContainers.COTHCompoundCollection& marshal(interface) ppCompList
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 22 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::GetCompounds(class AspenTech.Interop.ThContainers.COTHCompoundCollection&)
	} // end of method COTHPhaseClass::GetCompounds

	.method public hidebysig newslot virtual 
		instance void GetLnFugacity (
			[out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) ppFugacity
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2b 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::GetLnFugacity(class AspenTech.Interop.ThContainers.IRealArrayDisp&)
	} // end of method COTHPhaseClass::GetLnFugacity

	.method public hidebysig newslot virtual 
		instance void GetLnFugacityCoeff (
			[out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) ppFugacityCoeff
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2c 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IBasicPhase::GetLnFugacityCoeff(class AspenTech.Interop.ThContainers.IRealArrayDisp&)
	} // end of method COTHPhaseClass::GetLnFugacityCoeff

	.method public hidebysig newslot virtual 
		instance int32 GetNumberOfProperties () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThContainers.IEnumeratedPropertyContainer::GetNumberOfProperties()
	} // end of method COTHPhaseClass::GetNumberOfProperties

	.method public hidebysig newslot virtual 
		instance object marshal(idispatch) GetPropertyIDs (
			[in] int32 nMax
		) runtime managed internalcall 
	{
		.override method instance object AspenTech.Interop.ThContainers.IEnumeratedPropertyContainer::GetPropertyIDs(int32)
	} // end of method COTHPhaseClass::GetPropertyIDs

	.method public hidebysig newslot virtual 
		instance bool SupportsProperty (
			[in] int32 nPropID
		) runtime managed internalcall 
	{
		.override method instance bool AspenTech.Interop.ThContainers.IEnumeratedPropertyContainer::SupportsProperty(int32)
	} // end of method COTHPhaseClass::SupportsProperty

	.method public hidebysig newslot virtual 
		instance void AddProperty (
			[in] int32 nPropID,
			[in] object marshal(struct) varPropVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IEnumeratedPropertyContainer::AddProperty(int32, object)
	} // end of method COTHPhaseClass::AddProperty

	.method public hidebysig newslot virtual 
		instance void RemoveProperty (
			[in] int32 nPropID
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IEnumeratedPropertyContainer::RemoveProperty(int32)
	} // end of method COTHPhaseClass::RemoveProperty

	.method public hidebysig newslot virtual 
		instance void PutPropertyValue (
			[in] int32 nPropID,
			[in] object marshal(struct) varPropVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IEnumeratedPropertyContainer::PutPropertyValue(int32, object)
	} // end of method COTHPhaseClass::PutPropertyValue

	.method public hidebysig newslot virtual 
		instance object marshal(struct) GetPropertyValue (
			[in] int32 nPropID
		) runtime managed internalcall 
	{
		.override method instance object AspenTech.Interop.ThContainers.IEnumeratedPropertyContainer::GetPropertyValue(int32)
	} // end of method COTHPhaseClass::GetPropertyValue

	.method public hidebysig newslot virtual 
		instance void RegisterProperties (
			[in] object marshal(idispatch) pEnumeratedPropertyRegistry
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IRegisterableObject::RegisterProperties(object)
	} // end of method COTHPhaseClass::RegisterProperties

	.method public hidebysig newslot virtual 
		instance void ClearDerivativesProps () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::ClearDerivativesProps()
	} // end of method COTHPhaseClass::ClearDerivativesProps

	.method public hidebysig newslot virtual 
		instance void AddDerivativeProp (
			[in] int32 nPropID,
			[in] int32 nDerivativeID,
			[in] valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum ePropResultType,
			[in] valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum eDevResultType,
			[in] [out] int32& nIdx
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::AddDerivativeProp(int32, int32, valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum, valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum, int32&)
	} // end of method COTHPhaseClass::AddDerivativeProp

	.method public hidebysig newslot virtual 
		instance void GetDerivativePropIndex (
			[in] int32 nPropID,
			[in] int32 nDerivativeID,
			[in] [out] int32& nIdx
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetDerivativePropIndex(int32, int32, int32&)
	} // end of method COTHPhaseClass::GetDerivativePropIndex

	.method public hidebysig newslot virtual 
		instance void RemoveDerivativeProp (
			[in] int32 nIdx,
			[in] int32 nPropID,
			[in] int32 nDerivativeID
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::RemoveDerivativeProp(int32, int32, int32)
	} // end of method COTHPhaseClass::RemoveDerivativeProp

	.method public hidebysig newslot virtual 
		instance void GetNumDerivativeProps (
			[in] [out] int32& nNumDerivativeProps
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetNumDerivativeProps(int32&)
	} // end of method COTHPhaseClass::GetNumDerivativeProps

	.method public hidebysig newslot virtual 
		instance void GetDerivativePropIDs (
			[in] int32 nIdx,
			[in] [out] int32& nPropID,
			[in] [out] int32& nDerivativeID
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetDerivativePropIDs(int32, int32&, int32&)
	} // end of method COTHPhaseClass::GetDerivativePropIDs

	.method public hidebysig newslot virtual 
		instance void SetNeedDerivative (
			[in] int32 nIdx,
			[in] uint8 bNeeded
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::SetNeedDerivative(int32, uint8)
	} // end of method COTHPhaseClass::SetNeedDerivative

	.method public hidebysig newslot virtual 
		instance void GetNeedDerivative (
			[in] int32 nIdx,
			[in] [out] uint8& bNeeded
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetNeedDerivative(int32, uint8&)
	} // end of method COTHPhaseClass::GetNeedDerivative

	.method public hidebysig newslot virtual 
		instance void SetDerivativeStatus (
			[in] int32 nIdx,
			[in] valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum eStatus
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::SetDerivativeStatus(int32, valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum)
	} // end of method COTHPhaseClass::SetDerivativeStatus

	.method public hidebysig newslot virtual 
		instance void GetDerivativeStatus (
			[in] int32 nIdx,
			[in] [out] valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum& eStatus
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetDerivativeStatus(int32, valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum&)
	} // end of method COTHPhaseClass::GetDerivativeStatus

	.method public hidebysig newslot virtual 
		instance void PutPointDerivative (
			[in] int32 nIdx,
			[in] float64 dVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::PutPointDerivative(int32, float64)
	} // end of method COTHPhaseClass::PutPointDerivative

	.method public hidebysig newslot virtual 
		instance void GetPointDerivative (
			[in] int32 nIdx,
			[in] [out] float64& dVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetPointDerivative(int32, float64&)
	} // end of method COTHPhaseClass::GetPointDerivative

	.method public hidebysig newslot virtual 
		instance void PutArrayDerivative (
			[in] int32 nIdx,
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) pIArr
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::PutArrayDerivative(int32, class AspenTech.Interop.ThContainers.IRealArrayDisp)
	} // end of method COTHPhaseClass::PutArrayDerivative

	.method public hidebysig newslot virtual 
		instance void GetArrayDerivative (
			[in] int32 nIdx,
			[in] [out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) pIArr
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetArrayDerivative(int32, class AspenTech.Interop.ThContainers.IRealArrayDisp&)
	} // end of method COTHPhaseClass::GetArrayDerivative

	.method public hidebysig newslot virtual 
		instance void PutMatrixDerivative (
			[in] int32 nIdx,
			[in] class AspenTech.Interop.ThContainers.IRealMatrixDisp marshal(interface) pIMat
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::PutMatrixDerivative(int32, class AspenTech.Interop.ThContainers.IRealMatrixDisp)
	} // end of method COTHPhaseClass::PutMatrixDerivative

	.method public hidebysig newslot virtual 
		instance void GetMatrixDerivative (
			[in] int32 nIdx,
			[in] [out] class AspenTech.Interop.ThContainers.IRealMatrixDisp& marshal(interface) pIMat
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetMatrixDerivative(int32, class AspenTech.Interop.ThContainers.IRealMatrixDisp&)
	} // end of method COTHPhaseClass::GetMatrixDerivative

	.method public hidebysig newslot virtual 
		instance void PutVariantDerivative (
			[in] int32 nIdx,
			[in] object marshal(struct) varPropVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::PutVariantDerivative(int32, object)
	} // end of method COTHPhaseClass::PutVariantDerivative

	.method public hidebysig newslot virtual 
		instance void GetVariantDerivative (
			[in] int32 nIdx,
			[in] [out] object& marshal(struct) pVarPropVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetVariantDerivative(int32, object&)
	} // end of method COTHPhaseClass::GetVariantDerivative

	.method public hidebysig newslot virtual 
		instance void GetResultValueType (
			[in] int32 nIdx,
			[in] [out] valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum& ePropResultType,
			[in] [out] valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum& eDevResultType
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetResultValueType(int32, valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum&, valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum&)
	} // end of method COTHPhaseClass::GetResultValueType

	.method public hidebysig newslot virtual 
		instance void PutDerivativeType (
			[in] int32 nIdx,
			[in] valuetype AspenTech.Interop.ThContainers.tagDerivativeTypeEnum eDevType
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::PutDerivativeType(int32, valuetype AspenTech.Interop.ThContainers.tagDerivativeTypeEnum)
	} // end of method COTHPhaseClass::PutDerivativeType

	.method public hidebysig newslot virtual 
		instance void GetDerivativeType (
			[in] int32 nIdx,
			[in] valuetype AspenTech.Interop.ThContainers.tagDerivativeTypeEnum& eDevType
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IDerivativeProp::GetDerivativeType(int32, valuetype AspenTech.Interop.ThContainers.tagDerivativeTypeEnum&)
	} // end of method COTHPhaseClass::GetDerivativeType

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHPhaseClass::.ctor

	// Properties
	.property instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum AspenTech.Interop.ThContainers.IBasicPhase.PhaseType()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
		.get instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum AspenTech.Interop.ThContainers.COTHPhaseClass::get_PhaseType()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_PhaseType(valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum)
	}
	.property instance valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum AspenTech.Interop.ThContainers.IBasicPhase.PhaseStatus()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
		.get instance valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum AspenTech.Interop.ThContainers.COTHPhaseClass::get_PhaseStatus()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_PhaseStatus(valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum)
	}
	.property instance float64 AspenTech.Interop.ThContainers.IBasicPhase.PhaseFraction()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.COTHPhaseClass::get_PhaseFraction()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_PhaseFraction(float64)
	}
	.property instance float64 AspenTech.Interop.ThContainers.IBasicPhase.PhaseMassFraction()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.COTHPhaseClass::get_PhaseMassFraction()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_PhaseMassFraction(float64)
	}
	.property instance float64 AspenTech.Interop.ThContainers.IBasicPhase.Pressure()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.COTHPhaseClass::get_Pressure()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_Pressure(float64)
	}
	.property instance float64 AspenTech.Interop.ThContainers.IBasicPhase.Temperature()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.COTHPhaseClass::get_Temperature()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_Temperature(float64)
	}
	.property instance float64 AspenTech.Interop.ThContainers.IBasicPhase.Homotopy()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.COTHPhaseClass::get_Homotopy()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_Homotopy(float64)
	}
	.property instance float64 AspenTech.Interop.ThContainers.IBasicPhase.Enthalpy()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.COTHPhaseClass::get_Enthalpy()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_Enthalpy(float64)
	}
	.property instance float64 AspenTech.Interop.ThContainers.IBasicPhase.Entropy()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.COTHPhaseClass::get_Entropy()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_Entropy(float64)
	}
	.property instance float64 AspenTech.Interop.ThContainers.IBasicPhase.Cp()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.COTHPhaseClass::get_Cp()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_Cp(float64)
	}
	.property instance float64 AspenTech.Interop.ThContainers.IBasicPhase.MolarVolume()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.COTHPhaseClass::get_MolarVolume()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_MolarVolume(float64)
	}
	.property instance float64 AspenTech.Interop.ThContainers.IBasicPhase.MolecularWeight()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 16 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.COTHPhaseClass::get_MolecularWeight()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_MolecularWeight(float64)
	}
	.property instance object AspenTech.Interop.ThContainers.IBasicPhase.MolarComposition()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 18 00 02 60 00 00
		)
		.get instance object AspenTech.Interop.ThContainers.COTHPhaseClass::get_MolarComposition()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_MolarComposition(object)
	}
	.property instance object AspenTech.Interop.ThContainers.IBasicPhase.MassComposition()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1a 00 02 60 00 00
		)
		.get instance object AspenTech.Interop.ThContainers.COTHPhaseClass::get_MassComposition()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_MassComposition(object)
	}
	.property instance int32 AspenTech.Interop.ThContainers.IBasicPhase.NumberOfCompounds()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1d 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.COTHPhaseClass::get_NumberOfCompounds()
	}
	.property instance object AspenTech.Interop.ThContainers.IBasicPhase.Compounds()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1e 00 02 60 00 00
		)
		.get instance object AspenTech.Interop.ThContainers.COTHPhaseClass::get_Compounds()
	}
	.property instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.IBasicPhase.MolarCompositionDisp()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 23 00 02 60 00 00
		)
		.get instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.COTHPhaseClass::get_MolarCompositionDisp()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_MolarCompositionDisp(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	}
	.property instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.IBasicPhase.LnFugacity()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 25 00 02 60 00 00
		)
		.get instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.COTHPhaseClass::get_LnFugacity()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_LnFugacity(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	}
	.property instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.IBasicPhase.LnFugacityCoeff()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 27 00 02 60 00 00
		)
		.get instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.COTHPhaseClass::get_LnFugacityCoeff()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_LnFugacityCoeff(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	}
	.property instance uint8 AspenTech.Interop.ThContainers.IBasicPhase.IsPseudoRoot()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 29 00 02 60 00 00
		)
		.get instance uint8 AspenTech.Interop.ThContainers.COTHPhaseClass::get_IsPseudoRoot()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_IsPseudoRoot(uint8)
	}
	.property instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum AspenTech.Interop.ThContainers.IUserPhaseType.UserPhaseType()
	{
		.get instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum AspenTech.Interop.ThContainers.COTHPhaseClass::get_UserPhaseType()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseClass::set_UserPhaseType(valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum)
	}

} // end of class AspenTech.Interop.ThContainers.COTHPhaseClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.COTHPhase
	implements AspenTech.Interop.ThContainers.IBasicPhase
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 43 30 37 44 44 38 42 42 2d 31 36 38 41
		2d 31 31 44 32 2d 42 38 42 39 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 2d 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 43 6f 6e 74 61 69 6e 65 72
		73 2e 43 4f 54 48 50 68 61 73 65 43 6c 61 73 73
		00 00
	)
} // end of class AspenTech.Interop.ThContainers.COTHPhase

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IBasicPhase
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 43 30 37 44 44 38 42 42 2d 31 36 38 41
		2d 31 31 44 32 2d 42 38 42 39 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum get_PhaseType () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_PhaseType

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_PhaseType (
			[in] valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_PhaseType

	.method public hidebysig specialname newslot abstract virtual 
		instance valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum get_PhaseStatus () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_PhaseStatus

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_PhaseStatus (
			[in] valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_PhaseStatus

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PhaseFraction () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_PhaseFraction

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_PhaseFraction (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_PhaseFraction

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_PhaseMassFraction () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_PhaseMassFraction

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_PhaseMassFraction (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_PhaseMassFraction

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_Pressure () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_Pressure

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Pressure (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_Pressure

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_Temperature () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_Temperature

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Temperature (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_Temperature

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_Homotopy () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_Homotopy

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Homotopy (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_Homotopy

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_Enthalpy () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_Enthalpy

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Enthalpy (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_Enthalpy

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_Entropy () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_Entropy

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Entropy (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_Entropy

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_Cp () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_Cp

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Cp (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_Cp

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_MolarVolume () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_MolarVolume

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_MolarVolume (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_MolarVolume

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_MolecularWeight () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 16 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_MolecularWeight

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_MolecularWeight (
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 16 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_MolecularWeight

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_MolarComposition () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 18 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_MolarComposition

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_MolarComposition (
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 18 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_MolarComposition

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_MassComposition () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1a 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_MassComposition

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_MassComposition (
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1a 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_MassComposition

	.method public hidebysig newslot abstract virtual 
		instance void Finalize (
			[in] object marshal(idispatch) pCompList
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1c 00 02 60 00 00
		)
	} // end of method IBasicPhase::Finalize

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfCompounds () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1d 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_NumberOfCompounds

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_Compounds () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1e 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_Compounds

	.method public hidebysig newslot abstract virtual 
		instance void ResetProperties (
			[in] int32 dwSettings
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1f 00 02 60 00 00
		)
	} // end of method IBasicPhase::ResetProperties

	.method public hidebysig newslot abstract virtual 
		instance bool IsActivePhase () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 20 00 02 60 00 00
		)
	} // end of method IBasicPhase::IsActivePhase

	.method public hidebysig newslot abstract virtual 
		instance void CopyProperties (
			[in] object marshal(idispatch) pPhase
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 21 00 02 60 00 00
		)
	} // end of method IBasicPhase::CopyProperties

	.method public hidebysig newslot abstract virtual 
		instance void GetCompounds (
			[out] class AspenTech.Interop.ThContainers.COTHCompoundCollection& marshal(interface) ppCompList
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 22 00 02 60 00 00
		)
	} // end of method IBasicPhase::GetCompounds

	.method public hidebysig specialname newslot abstract virtual 
		instance class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) get_MolarCompositionDisp () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 23 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_MolarCompositionDisp

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_MolarCompositionDisp (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 23 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_MolarCompositionDisp

	.method public hidebysig specialname newslot abstract virtual 
		instance class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) get_LnFugacity () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 25 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_LnFugacity

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_LnFugacity (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 25 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_LnFugacity

	.method public hidebysig specialname newslot abstract virtual 
		instance class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) get_LnFugacityCoeff () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 27 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_LnFugacityCoeff

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_LnFugacityCoeff (
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 27 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_LnFugacityCoeff

	.method public hidebysig specialname newslot abstract virtual 
		instance uint8 get_IsPseudoRoot () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 29 00 02 60 00 00
		)
	} // end of method IBasicPhase::get_IsPseudoRoot

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IsPseudoRoot (
			[in] uint8 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 29 00 02 60 00 00
		)
	} // end of method IBasicPhase::set_IsPseudoRoot

	.method public hidebysig newslot abstract virtual 
		instance void GetLnFugacity (
			[out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) ppFugacity
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2b 00 02 60 00 00
		)
	} // end of method IBasicPhase::GetLnFugacity

	.method public hidebysig newslot abstract virtual 
		instance void GetLnFugacityCoeff (
			[out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) ppFugacityCoeff
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 2c 00 02 60 00 00
		)
	} // end of method IBasicPhase::GetLnFugacityCoeff

	// Properties
	.property instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum PhaseType()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
		.get instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum AspenTech.Interop.ThContainers.IBasicPhase::get_PhaseType()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_PhaseType(valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum)
	}
	.property instance valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum PhaseStatus()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
		.get instance valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum AspenTech.Interop.ThContainers.IBasicPhase::get_PhaseStatus()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_PhaseStatus(valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum)
	}
	.property instance float64 PhaseFraction()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_PhaseFraction()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_PhaseFraction(float64)
	}
	.property instance float64 PhaseMassFraction()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_PhaseMassFraction()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_PhaseMassFraction(float64)
	}
	.property instance float64 Pressure()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Pressure()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Pressure(float64)
	}
	.property instance float64 Temperature()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Temperature()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Temperature(float64)
	}
	.property instance float64 Homotopy()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Homotopy()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Homotopy(float64)
	}
	.property instance float64 Enthalpy()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Enthalpy()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Enthalpy(float64)
	}
	.property instance float64 Entropy()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Entropy()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Entropy(float64)
	}
	.property instance float64 Cp()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_Cp()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_Cp(float64)
	}
	.property instance float64 MolarVolume()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_MolarVolume()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_MolarVolume(float64)
	}
	.property instance float64 MolecularWeight()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 16 00 02 60 00 00
		)
		.get instance float64 AspenTech.Interop.ThContainers.IBasicPhase::get_MolecularWeight()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_MolecularWeight(float64)
	}
	.property instance object MolarComposition()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 18 00 02 60 00 00
		)
		.get instance object AspenTech.Interop.ThContainers.IBasicPhase::get_MolarComposition()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_MolarComposition(object)
	}
	.property instance object MassComposition()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1a 00 02 60 00 00
		)
		.get instance object AspenTech.Interop.ThContainers.IBasicPhase::get_MassComposition()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_MassComposition(object)
	}
	.property instance int32 NumberOfCompounds()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1d 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.IBasicPhase::get_NumberOfCompounds()
	}
	.property instance object Compounds()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1e 00 02 60 00 00
		)
		.get instance object AspenTech.Interop.ThContainers.IBasicPhase::get_Compounds()
	}
	.property instance class AspenTech.Interop.ThContainers.IRealArrayDisp MolarCompositionDisp()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 23 00 02 60 00 00
		)
		.get instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.IBasicPhase::get_MolarCompositionDisp()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_MolarCompositionDisp(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	}
	.property instance class AspenTech.Interop.ThContainers.IRealArrayDisp LnFugacity()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 25 00 02 60 00 00
		)
		.get instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.IBasicPhase::get_LnFugacity()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_LnFugacity(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	}
	.property instance class AspenTech.Interop.ThContainers.IRealArrayDisp LnFugacityCoeff()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 27 00 02 60 00 00
		)
		.get instance class AspenTech.Interop.ThContainers.IRealArrayDisp AspenTech.Interop.ThContainers.IBasicPhase::get_LnFugacityCoeff()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_LnFugacityCoeff(class AspenTech.Interop.ThContainers.IRealArrayDisp)
	}
	.property instance uint8 IsPseudoRoot()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 29 00 02 60 00 00
		)
		.get instance uint8 AspenTech.Interop.ThContainers.IBasicPhase::get_IsPseudoRoot()
		.set instance void AspenTech.Interop.ThContainers.IBasicPhase::set_IsPseudoRoot(uint8)
	}

} // end of class AspenTech.Interop.ThContainers.IBasicPhase

.class public auto ansi sealed AspenTech.Interop.ThContainers.tagPhaseTypeEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptUnknownPhase = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptOverall = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptFeed = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptVapour = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptLiquid = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptAqueous = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptSolid = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptInsolubleSolid = int32(7)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptDensePhase = int32(8)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptHydrate = int32(9)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptWax = int32(10)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptUserType = int32(11)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptMultiPhase = int32(12)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum xptLastPhaseType = int32(13)

} // end of class AspenTech.Interop.ThContainers.tagPhaseTypeEnum

.class public auto ansi sealed AspenTech.Interop.ThContainers.tagPhaseStatusEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum xpsUnknownStatus = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum xpsActivePhase = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum xpsGarbagePhase = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum xpsDeletedPhase = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum xpsVirtualPhase = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagPhaseStatusEnum xpsLastPhaseStatus = int32(1000)

} // end of class AspenTech.Interop.ThContainers.tagPhaseStatusEnum

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IEnumeratedPropertyContainer
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 46 39 31 35 43 42 38 35 2d 33 37 41 39
		2d 31 31 44 32 2d 42 38 43 36 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance int32 GetNumberOfProperties () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IEnumeratedPropertyContainer::GetNumberOfProperties

	.method public hidebysig newslot abstract virtual 
		instance object marshal(idispatch) GetPropertyIDs (
			[in] int32 nMax
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IEnumeratedPropertyContainer::GetPropertyIDs

	.method public hidebysig newslot abstract virtual 
		instance bool SupportsProperty (
			[in] int32 nPropID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IEnumeratedPropertyContainer::SupportsProperty

	.method public hidebysig newslot abstract virtual 
		instance void AddProperty (
			[in] int32 nPropID,
			[in] object marshal(struct) varPropVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IEnumeratedPropertyContainer::AddProperty

	.method public hidebysig newslot abstract virtual 
		instance void RemoveProperty (
			[in] int32 nPropID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IEnumeratedPropertyContainer::RemoveProperty

	.method public hidebysig newslot abstract virtual 
		instance void PutPropertyValue (
			[in] int32 nPropID,
			[in] object marshal(struct) varPropVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IEnumeratedPropertyContainer::PutPropertyValue

	.method public hidebysig newslot abstract virtual 
		instance object marshal(struct) GetPropertyValue (
			[in] int32 nPropID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method IEnumeratedPropertyContainer::GetPropertyValue

} // end of class AspenTech.Interop.ThContainers.IEnumeratedPropertyContainer

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IRegisterableObject
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 34 38 31 34 43 45 31 2d 35 45 31 32
		2d 31 31 44 32 2d 42 38 44 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void RegisterProperties (
			[in] object marshal(idispatch) pEnumeratedPropertyRegistry
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRegisterableObject::RegisterProperties

} // end of class AspenTech.Interop.ThContainers.IRegisterableObject

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IUserPhaseType
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 37 30 38 44 38 42 34 30 2d 42 46 34 32
		2d 31 31 44 35 2d 42 46 41 34 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum get_UserPhaseType () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method IUserPhaseType::get_UserPhaseType

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_UserPhaseType (
			[in] valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method IUserPhaseType::set_UserPhaseType

	// Properties
	.property instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum UserPhaseType()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
		.get instance valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum AspenTech.Interop.ThContainers.IUserPhaseType::get_UserPhaseType()
		.set instance void AspenTech.Interop.ThContainers.IUserPhaseType::set_UserPhaseType(valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum)
	}

} // end of class AspenTech.Interop.ThContainers.IUserPhaseType

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IDerivativeProp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 34 41 42 33 34 43 45 30 2d 35 45 32 34
		2d 31 31 44 37 2d 42 38 42 32 2d 30 30 30 33 34
		37 41 37 34 36 36 30 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void ClearDerivativesProps () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method IDerivativeProp::ClearDerivativesProps

	.method public hidebysig newslot abstract virtual 
		instance void AddDerivativeProp (
			[in] int32 nPropID,
			[in] int32 nDerivativeID,
			[in] valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum ePropResultType,
			[in] valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum eDevResultType,
			[in] [out] int32& nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method IDerivativeProp::AddDerivativeProp

	.method public hidebysig newslot abstract virtual 
		instance void GetDerivativePropIndex (
			[in] int32 nPropID,
			[in] int32 nDerivativeID,
			[in] [out] int32& nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetDerivativePropIndex

	.method public hidebysig newslot abstract virtual 
		instance void RemoveDerivativeProp (
			[in] int32 nIdx,
			[in] int32 nPropID,
			[in] int32 nDerivativeID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
	} // end of method IDerivativeProp::RemoveDerivativeProp

	.method public hidebysig newslot abstract virtual 
		instance void GetNumDerivativeProps (
			[in] [out] int32& nNumDerivativeProps
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetNumDerivativeProps

	.method public hidebysig newslot abstract virtual 
		instance void GetDerivativePropIDs (
			[in] int32 nIdx,
			[in] [out] int32& nPropID,
			[in] [out] int32& nDerivativeID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetDerivativePropIDs

	.method public hidebysig newslot abstract virtual 
		instance void SetNeedDerivative (
			[in] int32 nIdx,
			[in] uint8 bNeeded
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method IDerivativeProp::SetNeedDerivative

	.method public hidebysig newslot abstract virtual 
		instance void GetNeedDerivative (
			[in] int32 nIdx,
			[in] [out] uint8& bNeeded
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetNeedDerivative

	.method public hidebysig newslot abstract virtual 
		instance void SetDerivativeStatus (
			[in] int32 nIdx,
			[in] valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum eStatus
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
	} // end of method IDerivativeProp::SetDerivativeStatus

	.method public hidebysig newslot abstract virtual 
		instance void GetDerivativeStatus (
			[in] int32 nIdx,
			[in] [out] valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum& eStatus
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetDerivativeStatus

	.method public hidebysig newslot abstract virtual 
		instance void PutPointDerivative (
			[in] int32 nIdx,
			[in] float64 dVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
	} // end of method IDerivativeProp::PutPointDerivative

	.method public hidebysig newslot abstract virtual 
		instance void GetPointDerivative (
			[in] int32 nIdx,
			[in] [out] float64& dVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetPointDerivative

	.method public hidebysig newslot abstract virtual 
		instance void PutArrayDerivative (
			[in] int32 nIdx,
			[in] class AspenTech.Interop.ThContainers.IRealArrayDisp marshal(interface) pIArr
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 02 60 00 00
		)
	} // end of method IDerivativeProp::PutArrayDerivative

	.method public hidebysig newslot abstract virtual 
		instance void GetArrayDerivative (
			[in] int32 nIdx,
			[in] [out] class AspenTech.Interop.ThContainers.IRealArrayDisp& marshal(interface) pIArr
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0d 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetArrayDerivative

	.method public hidebysig newslot abstract virtual 
		instance void PutMatrixDerivative (
			[in] int32 nIdx,
			[in] class AspenTech.Interop.ThContainers.IRealMatrixDisp marshal(interface) pIMat
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 02 60 00 00
		)
	} // end of method IDerivativeProp::PutMatrixDerivative

	.method public hidebysig newslot abstract virtual 
		instance void GetMatrixDerivative (
			[in] int32 nIdx,
			[in] [out] class AspenTech.Interop.ThContainers.IRealMatrixDisp& marshal(interface) pIMat
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0f 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetMatrixDerivative

	.method public hidebysig newslot abstract virtual 
		instance void PutVariantDerivative (
			[in] int32 nIdx,
			[in] object marshal(struct) varPropVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 02 60 00 00
		)
	} // end of method IDerivativeProp::PutVariantDerivative

	.method public hidebysig newslot abstract virtual 
		instance void GetVariantDerivative (
			[in] int32 nIdx,
			[in] [out] object& marshal(struct) pVarPropVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 11 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetVariantDerivative

	.method public hidebysig newslot abstract virtual 
		instance void GetResultValueType (
			[in] int32 nIdx,
			[in] [out] valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum& ePropResultType,
			[in] [out] valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum& eDevResultType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetResultValueType

	.method public hidebysig newslot abstract virtual 
		instance void PutDerivativeType (
			[in] int32 nIdx,
			[in] valuetype AspenTech.Interop.ThContainers.tagDerivativeTypeEnum eDevType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 13 00 02 60 00 00
		)
	} // end of method IDerivativeProp::PutDerivativeType

	.method public hidebysig newslot abstract virtual 
		instance void GetDerivativeType (
			[in] int32 nIdx,
			[in] valuetype AspenTech.Interop.ThContainers.tagDerivativeTypeEnum& eDevType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 02 60 00 00
		)
	} // end of method IDerivativeProp::GetDerivativeType

} // end of class AspenTech.Interop.ThContainers.IDerivativeProp

.class public auto ansi sealed AspenTech.Interop.ThContainers.tagResultTypeEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum NoResultType = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum RealPoint = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum RealArray = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum RealMatrix = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum IntPoint = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum IntArray = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum IntMatrix = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagResultTypeEnum VariantType = int32(7)

} // end of class AspenTech.Interop.ThContainers.tagResultTypeEnum

.class public auto ansi sealed AspenTech.Interop.ThContainers.tagDerivativeStatusEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum NoDerivativeStatus = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum ToBeCalculated = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum DoNotCalculate = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum CanNotCalculate = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum Calculated = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum CalculatedAnalytically = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum CalculatedNumerically = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeStatusEnum CalculatedPartialAnalytically = int32(7)

} // end of class AspenTech.Interop.ThContainers.tagDerivativeStatusEnum

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IRealMatrixDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 36 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfColumns () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfRows () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_IthRow (
			[in] int32 nRow
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_IthColumn (
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_IthColumn

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_IthColumn

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::Reset

	// Properties
	.property instance int32 NumberOfColumns()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.IRealMatrixDisp::get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThContainers.IRealMatrixDisp::set_NumberOfColumns(int32)
	}
	.property instance int32 NumberOfRows()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.IRealMatrixDisp::get_NumberOfRows()
		.set instance void AspenTech.Interop.ThContainers.IRealMatrixDisp::set_NumberOfRows(int32)
	}

} // end of class AspenTech.Interop.ThContainers.IRealMatrixDisp

.class public auto ansi sealed AspenTech.Interop.ThContainers.tagDerivativeTypeEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeTypeEnum NoDerivativeType = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeTypeEnum AnalyticalOnly = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeTypeEnum NumericalOnly = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThContainers.tagDerivativeTypeEnum NumericalBackup = int32(3)

} // end of class AspenTech.Interop.ThContainers.tagDerivativeTypeEnum

.class public auto ansi import beforefieldinit AspenTech.Interop.ThContainers.COTHPhaseCollectionClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThContainers.IPhaseCollection,
	           AspenTech.Interop.ThContainers.COTHPhaseCollection,
	           AspenTech.Interop.ThContainers.IFlashPhaseCollection,
	           AspenTech.Interop.ThContainers.IRegisterableObject,
	           AspenTech.Interop.ThContainers.IReplacePhase
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 35 42 37 46 42 39 37 2d 35 32 33 36
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_Compounds () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
		.override method instance object AspenTech.Interop.ThContainers.IPhaseCollection::get_Compounds()
	} // end of method COTHPhaseCollectionClass::get_Compounds

	.method public hidebysig specialname newslot virtual 
		instance int32 get_MaximumNumberOfEquilibriumPhases () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
		.override method instance int32 AspenTech.Interop.ThContainers.IPhaseCollection::get_MaximumNumberOfEquilibriumPhases()
	} // end of method COTHPhaseCollectionClass::get_MaximumNumberOfEquilibriumPhases

	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfFeedPhases () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
		.override method instance int32 AspenTech.Interop.ThContainers.IPhaseCollection::get_NumberOfFeedPhases()
	} // end of method COTHPhaseCollectionClass::get_NumberOfFeedPhases

	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfEquilibriumPhases () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
		.override method instance int32 AspenTech.Interop.ThContainers.IPhaseCollection::get_NumberOfEquilibriumPhases()
	} // end of method COTHPhaseCollectionClass::get_NumberOfEquilibriumPhases

	.method public hidebysig specialname newslot virtual 
		instance void set_NumberOfEquilibriumPhases (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IPhaseCollection::set_NumberOfEquilibriumPhases(int32)
	} // end of method COTHPhaseCollectionClass::set_NumberOfEquilibriumPhases

	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfActivePhases () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
		.override method instance int32 AspenTech.Interop.ThContainers.IPhaseCollection::get_NumberOfActivePhases()
	} // end of method COTHPhaseCollectionClass::get_NumberOfActivePhases

	.method public hidebysig newslot virtual 
		instance void Finalize (
			[in] object marshal(idispatch) pCompList,
			[in] int32 nPhase,
			[in] int32 nFeed
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IPhaseCollection::Finalize(object, int32, int32)
	} // end of method COTHPhaseCollectionClass::Finalize

	.method public hidebysig newslot virtual 
		instance void PutFeedComposition (
			[in] object marshal(idispatch) pRealArray,
			[in] int32 nFeed
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IPhaseCollection::PutFeedComposition(object, int32)
	} // end of method COTHPhaseCollectionClass::PutFeedComposition

	.method public hidebysig newslot virtual 
		instance void ResetCollection (
			[in] int32 dwSettings
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IPhaseCollection::ResetCollection(int32)
	} // end of method COTHPhaseCollectionClass::ResetCollection

	.method public hidebysig newslot virtual 
		instance object marshal(idispatch) LocatePhase (
			[in] valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum ePhaseType,
			[in] int32 nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.override method instance object AspenTech.Interop.ThContainers.IPhaseCollection::LocatePhase(valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum, int32)
	} // end of method COTHPhaseCollectionClass::LocatePhase

	.method public hidebysig newslot virtual 
		instance object marshal(idispatch) GetEquilibriumPhase (
			[in] int32 nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 02 60 00 00
		)
		.override method instance object AspenTech.Interop.ThContainers.IPhaseCollection::GetEquilibriumPhase(int32)
	} // end of method COTHPhaseCollectionClass::GetEquilibriumPhase

	.method public hidebysig newslot virtual 
		instance object marshal(idispatch) GetActivePhase (
			[in] int32 nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 02 60 00 00
		)
		.override method instance object AspenTech.Interop.ThContainers.IPhaseCollection::GetActivePhase(int32)
	} // end of method COTHPhaseCollectionClass::GetActivePhase

	.method public hidebysig newslot virtual 
		instance void ApplyActor (
			[in] object marshal(idispatch) pIPhaseCollectionActor
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThContainers.IPhaseCollection::ApplyActor(object)
	} // end of method COTHPhaseCollectionClass::ApplyActor

	.method public hidebysig newslot virtual 
		instance void RelocatePhaseAfter (
			[in] int32 nAfterThis,
			[in] int32 nTarget
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IFlashPhaseCollection::RelocatePhaseAfter(int32, int32)
	} // end of method COTHPhaseCollectionClass::RelocatePhaseAfter

	.method public hidebysig newslot virtual 
		instance void SwapEquilibriumPhases (
			[in] int32 nIdx,
			[in] int32 nJdx
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IFlashPhaseCollection::SwapEquilibriumPhases(int32, int32)
	} // end of method COTHPhaseCollectionClass::SwapEquilibriumPhases

	.method public hidebysig newslot virtual 
		instance void RegisterProperties (
			[in] object marshal(idispatch) pEnumeratedPropertyRegistry
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IRegisterableObject::RegisterProperties(object)
	} // end of method COTHPhaseCollectionClass::RegisterProperties

	.method public hidebysig newslot virtual 
		instance int32 LocateEqmPhaseIndex (
			[in] valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum ePhaseType,
			[in] int32 nIdx
		) runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThContainers.IReplacePhase::LocateEqmPhaseIndex(valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum, int32)
	} // end of method COTHPhaseCollectionClass::LocateEqmPhaseIndex

	.method public hidebysig newslot virtual 
		instance void ReplaceEquilibriumPhase (
			[in] int32 nIdx,
			[in] object marshal(idispatch) pPhase
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThContainers.IReplacePhase::ReplaceEquilibriumPhase(int32, object)
	} // end of method COTHPhaseCollectionClass::ReplaceEquilibriumPhase

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHPhaseCollectionClass::.ctor

	// Properties
	.property instance object AspenTech.Interop.ThContainers.IPhaseCollection.Compounds()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
		.get instance object AspenTech.Interop.ThContainers.COTHPhaseCollectionClass::get_Compounds()
	}
	.property instance int32 AspenTech.Interop.ThContainers.IPhaseCollection.MaximumNumberOfEquilibriumPhases()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.COTHPhaseCollectionClass::get_MaximumNumberOfEquilibriumPhases()
	}
	.property instance int32 AspenTech.Interop.ThContainers.IPhaseCollection.NumberOfFeedPhases()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.COTHPhaseCollectionClass::get_NumberOfFeedPhases()
	}
	.property instance int32 AspenTech.Interop.ThContainers.IPhaseCollection.NumberOfEquilibriumPhases()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.COTHPhaseCollectionClass::get_NumberOfEquilibriumPhases()
		.set instance void AspenTech.Interop.ThContainers.COTHPhaseCollectionClass::set_NumberOfEquilibriumPhases(int32)
	}
	.property instance int32 AspenTech.Interop.ThContainers.IPhaseCollection.NumberOfActivePhases()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.COTHPhaseCollectionClass::get_NumberOfActivePhases()
	}

} // end of class AspenTech.Interop.ThContainers.COTHPhaseCollectionClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.COTHPhaseCollection
	implements AspenTech.Interop.ThContainers.IPhaseCollection
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 42 32 35 43 39 36 31 31 2d 33 36 30 43
		2d 31 31 44 32 2d 42 38 43 36 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 37 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 43 6f 6e 74 61 69 6e 65 72
		73 2e 43 4f 54 48 50 68 61 73 65 43 6f 6c 6c 65
		63 74 69 6f 6e 43 6c 61 73 73 00 00
	)
} // end of class AspenTech.Interop.ThContainers.COTHPhaseCollection

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IPhaseCollection
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 42 32 35 43 39 36 31 31 2d 33 36 30 43
		2d 31 31 44 32 2d 42 38 43 36 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void Finalize (
			[in] object marshal(idispatch) pCompList,
			[in] int32 nPhase,
			[in] int32 nFeed
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method IPhaseCollection::Finalize

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_Compounds () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method IPhaseCollection::get_Compounds

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_MaximumNumberOfEquilibriumPhases () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method IPhaseCollection::get_MaximumNumberOfEquilibriumPhases

	.method public hidebysig newslot abstract virtual 
		instance void PutFeedComposition (
			[in] object marshal(idispatch) pRealArray,
			[in] int32 nFeed
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
	} // end of method IPhaseCollection::PutFeedComposition

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfFeedPhases () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method IPhaseCollection::get_NumberOfFeedPhases

	.method public hidebysig newslot abstract virtual 
		instance void ResetCollection (
			[in] int32 dwSettings
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 02 60 00 00
		)
	} // end of method IPhaseCollection::ResetCollection

	.method public hidebysig newslot abstract virtual 
		instance object marshal(idispatch) LocatePhase (
			[in] valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum ePhaseType,
			[in] int32 nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method IPhaseCollection::LocatePhase

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfEquilibriumPhases () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
	} // end of method IPhaseCollection::get_NumberOfEquilibriumPhases

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfEquilibriumPhases (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
	} // end of method IPhaseCollection::set_NumberOfEquilibriumPhases

	.method public hidebysig newslot abstract virtual 
		instance object marshal(idispatch) GetEquilibriumPhase (
			[in] int32 nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 02 60 00 00
		)
	} // end of method IPhaseCollection::GetEquilibriumPhase

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfActivePhases () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
	} // end of method IPhaseCollection::get_NumberOfActivePhases

	.method public hidebysig newslot abstract virtual 
		instance object marshal(idispatch) GetActivePhase (
			[in] int32 nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 02 60 00 00
		)
	} // end of method IPhaseCollection::GetActivePhase

	.method public hidebysig newslot abstract virtual 
		instance void ApplyActor (
			[in] object marshal(idispatch) pIPhaseCollectionActor
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 02 60 00 00
		)
	} // end of method IPhaseCollection::ApplyActor

	// Properties
	.property instance object Compounds()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
		.get instance object AspenTech.Interop.ThContainers.IPhaseCollection::get_Compounds()
	}
	.property instance int32 MaximumNumberOfEquilibriumPhases()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.IPhaseCollection::get_MaximumNumberOfEquilibriumPhases()
	}
	.property instance int32 NumberOfFeedPhases()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.IPhaseCollection::get_NumberOfFeedPhases()
	}
	.property instance int32 NumberOfEquilibriumPhases()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.IPhaseCollection::get_NumberOfEquilibriumPhases()
		.set instance void AspenTech.Interop.ThContainers.IPhaseCollection::set_NumberOfEquilibriumPhases(int32)
	}
	.property instance int32 NumberOfActivePhases()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThContainers.IPhaseCollection::get_NumberOfActivePhases()
	}

} // end of class AspenTech.Interop.ThContainers.IPhaseCollection

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IFlashPhaseCollection
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 39 32 44 42 39 42 32 30 2d 34 45 37 30
		2d 31 31 44 32 2d 42 42 32 31 2d 32 30 34 43 34
		46 34 46 35 30 32 30 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void RelocatePhaseAfter (
			[in] int32 nAfterThis,
			[in] int32 nTarget
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method IFlashPhaseCollection::RelocatePhaseAfter

	.method public hidebysig newslot abstract virtual 
		instance void SwapEquilibriumPhases (
			[in] int32 nIdx,
			[in] int32 nJdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method IFlashPhaseCollection::SwapEquilibriumPhases

} // end of class AspenTech.Interop.ThContainers.IFlashPhaseCollection

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IReplacePhase
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 32 36 44 38 44 33 43 30 2d 43 45 38 43
		2d 34 36 42 39 2d 39 31 37 42 2d 46 43 42 34 38
		33 33 34 45 46 43 43 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance int32 LocateEqmPhaseIndex (
			[in] valuetype AspenTech.Interop.ThContainers.tagPhaseTypeEnum ePhaseType,
			[in] int32 nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method IReplacePhase::LocateEqmPhaseIndex

	.method public hidebysig newslot abstract virtual 
		instance void ReplaceEquilibriumPhase (
			[in] int32 nIdx,
			[in] object marshal(idispatch) pPhase
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method IReplacePhase::ReplaceEquilibriumPhase

} // end of class AspenTech.Interop.ThContainers.IReplacePhase

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ILoad
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 42 45 31 43 33 36 32 44 2d 33 38 43 43
		2d 31 31 44 34 2d 41 35 46 38 2d 30 30 39 30 32
		37 31 32 30 35 33 37 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void Get_SupportedPropList (
			[out] object& marshal(struct) pvecPropList,
			[out] object& marshal(struct) pvecSearchKey
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ILoad::Get_SupportedPropList

	.method public hidebysig newslot abstract virtual 
		instance void Set_Path (
			[in] string marshal(bstr) path,
			[out] string& marshal(bstr) Msg
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ILoad::Set_Path

	.method public hidebysig newslot abstract virtual 
		instance void Get_DBIdentification (
			[out] string& marshal(bstr) Name,
			[out] string& marshal(bstr) Version,
			[out] string& marshal(bstr) Note
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ILoad::Get_DBIdentification

	.method public hidebysig newslot abstract virtual 
		instance void Get_AllCompounds (
			[in] string marshal(bstr) propname,
			[out] object& marshal(struct) PropArray,
			[out] int32& ArraySize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ILoad::Get_AllCompounds

	.method public hidebysig newslot abstract virtual 
		instance void Get_Prop (
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] string marshal(bstr) propname,
			[out] valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum& 'type',
			[out] object& marshal(idispatch) IPropCalculate,
			[out] object& marshal(struct) Val,
			[out] int32& ValSize,
			[out] valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum& EqShape,
			[out] object& marshal(struct) Coeff,
			[out] int32& CoeffSize,
			[out] float64& tmin,
			[out] float64& tmax,
			[out] float64& pmin,
			[out] float64& pmax,
			[out] string& marshal(bstr) Note
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ILoad::Get_Prop

	.method public hidebysig newslot abstract virtual 
		instance void Get_PropType (
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] string marshal(bstr) propname,
			[out] valuetype AspenTech.Interop.ThContainers.tagPropTypeEnum& 'type'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ILoad::Get_PropType

	.method public hidebysig newslot abstract virtual 
		instance void Get_PropSingleVal (
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] string marshal(bstr) propname,
			[out] object& marshal(struct) Val,
			[out] string& marshal(bstr) Note
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ILoad::Get_PropSingleVal

	.method public hidebysig newslot abstract virtual 
		instance void Get_PropEquation (
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] string marshal(bstr) propname,
			[out] valuetype AspenTech.Interop.ThContainers.tagEquationShapeEnum& EqShape,
			[out] object& marshal(struct) Coeff,
			[out] int32& CoeffSize,
			[out] float64& tmin,
			[out] float64& tmax,
			[out] float64& pmin,
			[out] float64& pmax,
			[out] string& marshal(bstr) Note
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ILoad::Get_PropEquation

	.method public hidebysig newslot abstract virtual 
		instance void Get_PropCOM (
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] string marshal(bstr) propname,
			[out] object& marshal(idispatch) IPropCalculate,
			[out] string& marshal(bstr) Note
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ILoad::Get_PropCOM

	.method public hidebysig newslot abstract virtual 
		instance void Get_PropMultiVal (
			[in] string marshal(bstr) searchkey,
			[in] string marshal(bstr) id,
			[in] string marshal(bstr) propname,
			[out] object& marshal(struct) Val,
			[out] int32& ValSize,
			[out] string& marshal(bstr) Note
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ILoad::Get_PropMultiVal

	.method public hidebysig newslot abstract virtual 
		instance void Get_AllSynonyms (
			[in] string marshal(bstr) searchkey,
			[out] object& marshal(struct) SynonymList
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ILoad::Get_AllSynonyms

} // end of class AspenTech.Interop.ThContainers.ILoad

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.ICOMUserProp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 39 32 32 43 42 44 30 2d 33 31 43 33
		2d 31 31 44 34 2d 42 46 34 46 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetClassID (
			[out] string& marshal(bstr) ClassID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICOMUserProp::GetClassID

	.method public hidebysig newslot abstract virtual 
		instance void GetClassName (
			[out] string& marshal(bstr) ClassName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICOMUserProp::GetClassName

	.method public hidebysig newslot abstract virtual 
		instance void Store (
			[out] string& marshal(bstr) data
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICOMUserProp::Store

	.method public hidebysig newslot abstract virtual 
		instance void Recall (
			[in] string marshal(bstr) data
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICOMUserProp::Recall

	.method public hidebysig newslot abstract virtual 
		instance void Copy (
			[in] object marshal(idispatch) prop
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICOMUserProp::Copy

} // end of class AspenTech.Interop.ThContainers.ICOMUserProp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThContainers.IPurePropEstimator
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 42 36 38 35 43 30 30 2d 33 30 38 35
		2d 31 31 44 36 2d 42 38 37 45 2d 30 30 30 33 34
		37 41 37 34 36 36 30 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void EstimatorInfo (
			[in] [out] string& marshal(bstr) Name,
			[in] [out] string& marshal(bstr) Version,
			[in] [out] uint8& NeedPath,
			[in] [out] string& marshal(bstr) Note
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IPurePropEstimator::EstimatorInfo

	.method public hidebysig newslot abstract virtual 
		instance void SetPath (
			[in] string marshal(bstr) path,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IPurePropEstimator::SetPath

	.method public hidebysig newslot abstract virtual 
		instance void GetSupportedProps (
			[in] [out] int32& nProp,
			[in] [out] object& marshal(struct) Props
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IPurePropEstimator::GetSupportedProps

	.method public hidebysig newslot abstract virtual 
		instance void CanDo (
			[in] string marshal(bstr) prop,
			[in] [out] int32& nMethods,
			[in] [out] object& marshal(struct) Methods,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IPurePropEstimator::CanDo

	.method public hidebysig newslot abstract virtual 
		instance void EstUnknownProps (
			[in] object marshal(idispatch) pCompound,
			[in] int32 nSpecProps,
			[in] object marshal(struct) SpecProps,
			[in] object marshal(struct) SpecMethods,
			[in] object marshal(idispatch) errorLog,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IPurePropEstimator::EstUnknownProps

	.method public hidebysig newslot abstract virtual 
		instance void EstProp (
			[in] object marshal(idispatch) pCompound,
			[in] string marshal(bstr) prop,
			[in] string marshal(bstr) 'method',
			[in] uint8 Replace,
			[in] object marshal(idispatch) errorLog,
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IPurePropEstimator::EstProp

	.method public hidebysig newslot abstract virtual 
		instance void IsReady (
			[in] [out] int32& Status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method IPurePropEstimator::IsReady

} // end of class AspenTech.Interop.ThContainers.IPurePropEstimator

You are not using the latest version of the tool, please update.
Latest version is '11.2.0.10050' (yours is '9.1.0.7988')
