using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: Guid("8915f1f0-5707-11d2-b8d8-00a0c986f9f7")]
[assembly: ImportedFromTypeLib("ThContainersLib")]
[assembly: PrimaryInteropAssembly(1, 0)]
[assembly: AssemblyVersion("1.0.0.0")]
namespace AspenTech.Interop.ThContainers;

[ComImport]
[TypeLibType(2)]
[Guid("4CA3B834-4CB3-11D2-B8D4-00A0C986F9F7")]
[ClassInterface((short)0)]
public class COTHCompoundClass : IBasicCompound, COTHCompound, ICompoundReferenceStateProperties, ICompoundPR, ICompoundCOSTALD, ICompoundCavett, ICompoundViscosity, ICompoundChaoSeader, ICompoundChienNull, ICompoundVirial, ICompoundPRSV, ICompoundSRK, ICompoundWilson, ICompoundID, ICompoundFamily, ICompoundUNIFAC1, ICompoundUNIQUAC1, ICompoundSolidProperties, ICompoundIDPut, ICompoundFamilyPut, ICompoundUNIFAC1Put, ICompoundInitFromHypDB, ICompoundProp, ICompoundPropPut, ICompoundCopy, XMLParserClient, IXMLStore, IUserProperty, ICompEqnXYShape
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	extern double IBasicCompound.get_MW([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern double IBasicCompound.get_TC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	extern double IBasicCompound.get_PC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	extern double IBasicCompound.get_VC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	extern double IBasicCompound.get_ACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	extern double IBasicCompound.get_NBP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(13)]
	extern double IBasicCompound.get_SLDN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(15)]
	extern double IBasicCompound.get_DM([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(17)]
	extern double IBasicCompound.get_RG([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(19)]
	extern double IBasicCompound.get_MP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(21)]
	extern double IBasicCompound.get_HFUS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(23)]
	extern double IBasicCompound.get_RI([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(25)]
	extern double IBasicCompound.get_FP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(27)]
	extern double IBasicCompound.get_FLML([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(29)]
	extern double IBasicCompound.get_FLMU([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(31)]
	extern double IBasicCompound.get_AIT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(33)]
	extern double IBasicCompound.get_SVEL([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(35)]
	extern double IBasicCompound.get_LDN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(37)]
	extern double IBasicCompound.get_VDN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(39)]
	extern double IBasicCompound.get_VP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(41)]
	extern double IBasicCompound.get_SP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(43)]
	extern double IBasicCompound.get_HVP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(45)]
	extern double IBasicCompound.get_LCP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(47)]
	extern double IBasicCompound.get_VCP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(49)]
	extern double IBasicCompound.get_SVR([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(51)]
	extern double IBasicCompound.get_LVS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(53)]
	extern double IBasicCompound.get_VVS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(55)]
	extern double IBasicCompound.get_LTC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(57)]
	extern double IBasicCompound.get_VTC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(59)]
	extern double IBasicCompound.get_ST([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(61)]
	extern double IBasicCompound.get_IT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(63)]
	extern double IBasicCompound.get_LIQH([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(65)]
	extern double IBasicCompound.get_VAPH([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(67)]
	extern double IBasicCompound.get_LIQS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(69)]
	extern double IBasicCompound.get_VAPS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[DispId(71)]
	extern int IBasicCompound.HyprotechID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(71)]
		get;
	}

	[DispId(72)]
	public virtual extern tagCompoundFamilyEnum Family
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(72)]
		get;
	}

	[DispId(73)]
	extern string IBasicCompound.SubFamily
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(73)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(75)]
	extern double IBasicCompound.get_IGH([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(76)]
	extern double IBasicCompound.get_IGS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(77)]
	extern double IBasicCompound.get_IGCP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(78)]
	extern double IBasicCompound.get_CavettParameter([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(79)]
	extern double IBasicCompound.get_COSTALDACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(80)]
	extern double IBasicCompound.get_COSTALDVCHAR([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(81)]
	extern double IBasicCompound.get_SRKACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(82)]
	extern double IBasicCompound.get_IGHF25([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(83)]
	extern double IBasicCompound.get_IGSF25([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundReferenceStateProperties.get_IGG([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundReferenceStateProperties.get_IGH([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundReferenceStateProperties.get_IGS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundReferenceStateProperties.get_IGCP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundReferenceStateProperties.get_IGHF25([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundReferenceStateProperties.get_IGSF25([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundReferenceStateProperties.get_IGHC25([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPR.get_PRTC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPR.get_PRPC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPR.get_PRVC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPR.get_PRACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPR.get_PRMC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPR.get_PRPVOLT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundCOSTALD.get_COSTALDACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundCOSTALD.get_COSTALDVCHAR([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundCavett.get_CavettParameter([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundChaoSeader.get_ChaoSeaderACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundChaoSeader.get_ChaoSeaderMVOL([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundChaoSeader.get_ChaoSeaderPVOLT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundChaoSeader.get_ChaoSeaderSOLP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundChienNull.get_ChienNullMVOL([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundChienNull.get_ChienNullPVOLT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundChienNull.get_ChienNullSOLP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundVirial.get_VirialSOLV([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPRSV.get_PRSVTC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPRSV.get_PRSVPC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPRSV.get_PRSVVC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPRSV.get_PRSVACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPRSV.get_PRSVKAPPA([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundPRSV.get_PRSVPVOLT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSRK.get_SRKTC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSRK.get_SRKPC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSRK.get_SRKVC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSRK.get_SRKACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSRK.get_SRKMC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSRK.get_SRKPVOLT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundWilson.get_WilsonKVAL([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundWilson.get_WilsonMVOL([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	extern string ICompoundID.Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	extern int ICompoundID.NumberOfSynonymNames
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.BStr)]
	extern string ICompoundID.get_SynonymName([In] int nIdx);

	extern int ICompoundID.PPAttribute
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	extern string ICompoundID.CASN
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	extern string ICompoundID.IUPACName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	extern int ICompoundID.HyprotechID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	extern int ICompoundID.PPDSID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	extern int ICompoundID.DDBID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	extern int ICompoundID.DIPPRID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	extern int ICompoundID.CMAID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	extern string ICompoundID.ChemicalFormula
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	public virtual extern tagCompoundFamilyEnum ICompoundFamily_Family
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	extern string ICompoundFamily.SubFamily
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	extern bool ICompoundFamily.NonCondensable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	extern int ICompoundUNIFAC1.UNIFAC1NumberOfGroups
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object ICompoundUNIFAC1.get_UNIFAC1Groups([Out] [MarshalAs(UnmanagedType.IDispatch)] out object ppGroupTypeNo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSolidProperties.get_SolidAverageDiameter([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSolidProperties.get_SolidSphericity([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSolidProperties.get_SolidSurfaceArea([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSolidProperties.get_SolidCarbon([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSolidProperties.get_SolidHydrogen([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSolidProperties.get_SolidNitrogen([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSolidProperties.get_SolidOxygen([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSolidProperties.get_SolidSulphur([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double ICompoundSolidProperties.get_SolidChlorine([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	extern string ICompoundIDPut.Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	extern int ICompoundIDPut.NumberOfSynonymNames
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundIDPut.set_SynonymName([In] int nIdx, [In] [MarshalAs(UnmanagedType.BStr)] string value);

	extern int ICompoundIDPut.PPAttribute
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern string ICompoundIDPut.CASN
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	extern string ICompoundIDPut.IUPACName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	extern int ICompoundIDPut.HyprotechID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern int ICompoundIDPut.PPDSID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern int ICompoundIDPut.DDBID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern int ICompoundIDPut.DIPPRID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern int ICompoundIDPut.CMAID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern string ICompoundIDPut.ChemicalFormula
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	extern tagCompoundFamilyEnum ICompoundFamilyPut.Family
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern string ICompoundFamilyPut.SubFamily
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	extern bool ICompoundFamilyPut.NonCondensable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern int ICompoundUNIFAC1Put.UNIFAC1NumberOfGroups
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundUNIFAC1Put.set_UNIFAC1Groups([In] int nNumGroup, [In] [MarshalAs(UnmanagedType.IDispatch)] object ppGroupTypeNo, [In] [MarshalAs(UnmanagedType.IDispatch)] object value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundUNIFAC1Put.set_HYPUNIFACNoGr([In] int nNumGroup, [In] [MarshalAs(UnmanagedType.Interface)] IIntegerArrayDisp value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundUNIFAC1Put.set_HYPUNIFACSubGr([In] int nNumGroup, [In] [MarshalAs(UnmanagedType.Interface)] IIntegerArrayDisp value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	extern void IBasicCompound.get_MWTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	extern void IBasicCompound.get_TCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	extern void IBasicCompound.get_PCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	extern void IBasicCompound.get_VCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	extern void IBasicCompound.get_ACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	extern void IBasicCompound.get_NBPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(14)]
	extern void IBasicCompound.get_SLDNTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(16)]
	extern void IBasicCompound.get_DMTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(18)]
	extern void IBasicCompound.get_RGTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(20)]
	extern void IBasicCompound.get_MPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(22)]
	extern void IBasicCompound.get_HFUSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(24)]
	extern void IBasicCompound.get_RITPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(26)]
	extern void IBasicCompound.get_FPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(28)]
	extern void IBasicCompound.get_FLMLTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(30)]
	extern void IBasicCompound.get_FLMUTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(32)]
	extern void IBasicCompound.get_AITTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(34)]
	extern void IBasicCompound.get_SVELTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(36)]
	extern void IBasicCompound.get_LDNTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(38)]
	extern void IBasicCompound.get_VDNTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(40)]
	extern void IBasicCompound.get_VPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(42)]
	extern void IBasicCompound.get_SPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(44)]
	extern void IBasicCompound.get_HVPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(46)]
	extern void IBasicCompound.get_LCPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(48)]
	extern void IBasicCompound.get_VCPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(50)]
	extern void IBasicCompound.get_SVRTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(52)]
	extern void IBasicCompound.get_LVSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(54)]
	extern void IBasicCompound.get_VVSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(56)]
	extern void IBasicCompound.get_LTCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(58)]
	extern void IBasicCompound.get_VTCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(60)]
	extern void IBasicCompound.get_STTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(62)]
	extern void IBasicCompound.get_ITTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(64)]
	extern void IBasicCompound.get_LIQHTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(66)]
	extern void IBasicCompound.get_VAPHTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(68)]
	extern void IBasicCompound.get_LIQSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(70)]
	extern void IBasicCompound.get_VAPSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(74)]
	extern void IBasicCompound.GetNonCondensable(out byte pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundReferenceStateProperties.get_IGGTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundReferenceStateProperties.get_IGHTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundReferenceStateProperties.get_IGSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundReferenceStateProperties.get_IGCPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundReferenceStateProperties.get_IGHF25TPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundReferenceStateProperties.get_IGSF25TPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundReferenceStateProperties.get_IGHC25TPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPR.get_PRTCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPR.get_PRPCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPR.get_PRVCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPR.get_PRACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPR.get_PRMCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPR.get_PRPVOLTTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundCOSTALD.get_COSTALDACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundCOSTALD.get_COSTALDVCHARTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundCavett.get_CavettParameterTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundViscosity.get_ViscosityThetas(out double THETAA, out double THETAB);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundChaoSeader.get_ChaoSeaderACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundChaoSeader.get_ChaoSeaderMVOLTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundChaoSeader.get_ChaoSeaderPVOLTTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundChaoSeader.get_ChaoSeaderSOLPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundChienNull.get_ChienNullMVOLTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundChienNull.get_ChienNullPVOLTTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundChienNull.get_ChienNullSOLPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundVirial.get_VirialSOLVTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPRSV.get_PRSVTCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPRSV.get_PRSVPCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPRSV.get_PRSVVCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPRSV.get_PRSVACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPRSV.get_PRSVKAPPATPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPRSV.get_PRSVPVOLTTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSRK.get_SRKTCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSRK.get_SRKPCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSRK.get_SRKVCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSRK.get_SRKACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSRK.get_SRKMCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSRK.get_SRKPVOLTTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundWilson.get_WilsonKVALTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundWilson.get_WilsonMVOLTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundID.IsWater();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundID.IsDEG();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundID.IsTEG();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundID.IsEG();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundID.IsMethanol();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundUNIQUAC1.get_UNIQUAC1Parameters(out double pdR, out double pdQ);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSolidProperties.get_SolidAverageDiameterTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSolidProperties.get_SolidSphericityTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSolidProperties.get_SolidSurfaceAreaTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSolidProperties.get_SolidCarbonTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSolidProperties.get_SolidHydrogenTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSolidProperties.get_SolidNitrogenTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSolidProperties.get_SolidOxygenTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSolidProperties.get_SolidSulphurTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundSolidProperties.get_SolidChlorineTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundInitFromHypDB.Init([In][MarshalAs(UnmanagedType.BStr)] string strPath, [In] int nCompIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundProp.GetNumbOfProperty([In] byte bFixed, out int nProps);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundProp.GetPropertyName([In] byte bFixed, [In] int iProp, [MarshalAs(UnmanagedType.BStr)] out string Name, out tagPropTypeEnum type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundProp.GetPropertyValue([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, out int pDependencies, out double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundProp.GetPropertyType([In][MarshalAs(UnmanagedType.BStr)] string Name, out tagPropTypeEnum type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundProp.GetEquationProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, out tagEquationShapeEnum shape, [MarshalAs(UnmanagedType.BStr)] out string form, out double tmin, out double tmax, out double pmin, out double pmax, out int nParameters, [MarshalAs(UnmanagedType.Interface)] out IRealArrayDisp pCoeff);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundProp.GetCOMProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, [MarshalAs(UnmanagedType.BStr)] out string ClassID, [MarshalAs(UnmanagedType.Interface)] out IPCProperty prop);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundProp.GetNumbOfCommonProperty(out int nProps);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundProp.GetCommonPropertyName([In] int iProp, [MarshalAs(UnmanagedType.BStr)] out string Name, out tagPropTypeEnum type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPropPut.SetPointProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] byte @fixed, [In] double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPropPut.SetEquationProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] byte @fixed, [In] tagEquationShapeEnum shape, [In] double tmin, [In] double tmax, [In] double pmin, [In] double pmax, [In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp pCoeff);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPropPut.SetCOMProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] byte @fixed, [In][MarshalAs(UnmanagedType.BStr)] string ClassName, [In][MarshalAs(UnmanagedType.Interface)] IPCProperty prop);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPropPut.ErasePropFromMap([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] byte @fixed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPropPut.FindProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, out byte find, out byte @fixed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPropPut.GetEquationInfo([In] tagEquationShapeEnum shape, [MarshalAs(UnmanagedType.BStr)] out string form, out int nParameters);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPropPut.SetVoidProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] byte @fixed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPropPut.GetPropertyLoader([In][MarshalAs(UnmanagedType.BStr)] string propname, [MarshalAs(UnmanagedType.BStr)] out string loader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundPropPut.SetPropertyLoader([In][MarshalAs(UnmanagedType.BStr)] string propname, [In][MarshalAs(UnmanagedType.BStr)] string loader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundCopy.CopyToThis([In] int NewID, [In][MarshalAs(UnmanagedType.IDispatch)] object OrigComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.CharacterData([In][MarshalAs(UnmanagedType.BStr)] string userData);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.StartElement([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.EndElement([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.Comment([In][MarshalAs(UnmanagedType.BStr)] string bstrComment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.ProcessElement([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.Error([In][MarshalAs(UnmanagedType.BStr)] string Error);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.StartDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.EndDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.BStr)]
	extern string IXMLStore.StoreAsXML();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IUserProperty.SetUserProperty([In][MarshalAs(UnmanagedType.BStr)] string strName, [In][MarshalAs(UnmanagedType.BStr)] string ClassID, [In][MarshalAs(UnmanagedType.IDispatch)] object pProp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IUserProperty.GetUserProperty([In][MarshalAs(UnmanagedType.BStr)] string strName, [MarshalAs(UnmanagedType.IDispatch)] out object pProp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IUserProperty.GetUserPropertyClassID([In][MarshalAs(UnmanagedType.BStr)] string strName, [MarshalAs(UnmanagedType.BStr)] out string ClassID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IUserProperty.DeleteUserProperty([In][MarshalAs(UnmanagedType.BStr)] string strName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IUserProperty.GetNumbOfUserProperty(out int nProp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IUserProperty.GetUserPropertyI([In] int iProp, [MarshalAs(UnmanagedType.BStr)] out string Name, [MarshalAs(UnmanagedType.BStr)] out string ClassID, [MarshalAs(UnmanagedType.IDispatch)] out object pProp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompEqnXYShape.GetEquationPropertyXYShape([In][MarshalAs(UnmanagedType.BStr)] string Name, out tagXYShapeEnum xshape, out tagXYShapeEnum yshape, out double xnorm, out double ynorm, out double xpow, out double ypow, out double a, out double b);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompEqnXYShape.SetEquationPropertyXYShape([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] tagXYShapeEnum xshape, [In] tagXYShapeEnum yshape, [In] double xnorm, [In] double ynorm, [In] double xpow, [In] double ypow, [In] double a, [In] double b);
}
[ComImport]
[Guid("4CA3B833-4CB3-11D2-B8D4-00A0C986F9F7")]
[CoClass(typeof(COTHCompoundClass))]
public interface COTHCompound : IBasicCompound
{
}
[ComImport]
[TypeLibType(4160)]
[Guid("4CA3B833-4CB3-11D2-B8D4-00A0C986F9F7")]
public interface IBasicCompound
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_MW([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_MWTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_TC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void get_TCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	double get_PC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void get_PCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	double get_VC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void get_VCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	double get_ACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void get_ACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	double get_NBP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	void get_NBPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(13)]
	double get_SLDN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(14)]
	void get_SLDNTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(15)]
	double get_DM([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(16)]
	void get_DMTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(17)]
	double get_RG([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(18)]
	void get_RGTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(19)]
	double get_MP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(20)]
	void get_MPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(21)]
	double get_HFUS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(22)]
	void get_HFUSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(23)]
	double get_RI([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(24)]
	void get_RITPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(25)]
	double get_FP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(26)]
	void get_FPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(27)]
	double get_FLML([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(28)]
	void get_FLMLTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(29)]
	double get_FLMU([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(30)]
	void get_FLMUTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(31)]
	double get_AIT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(32)]
	void get_AITTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(33)]
	double get_SVEL([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(34)]
	void get_SVELTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(35)]
	double get_LDN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(36)]
	void get_LDNTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(37)]
	double get_VDN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(38)]
	void get_VDNTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(39)]
	double get_VP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(40)]
	void get_VPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(41)]
	double get_SP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(42)]
	void get_SPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(43)]
	double get_HVP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(44)]
	void get_HVPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(45)]
	double get_LCP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(46)]
	void get_LCPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(47)]
	double get_VCP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(48)]
	void get_VCPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(49)]
	double get_SVR([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(50)]
	void get_SVRTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(51)]
	double get_LVS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(52)]
	void get_LVSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(53)]
	double get_VVS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(54)]
	void get_VVSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(55)]
	double get_LTC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(56)]
	void get_LTCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(57)]
	double get_VTC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(58)]
	void get_VTCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(59)]
	double get_ST([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(60)]
	void get_STTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(61)]
	double get_IT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(62)]
	void get_ITTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(63)]
	double get_LIQH([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(64)]
	void get_LIQHTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(65)]
	double get_VAPH([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(66)]
	void get_VAPHTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(67)]
	double get_LIQS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(68)]
	void get_LIQSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(69)]
	double get_VAPS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(70)]
	void get_VAPSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[DispId(71)]
	int HyprotechID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(71)]
		get;
	}

	[DispId(72)]
	tagCompoundFamilyEnum Family
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(72)]
		get;
	}

	[DispId(73)]
	string SubFamily
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(73)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(74)]
	void GetNonCondensable(out byte pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(75)]
	double get_IGH([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(76)]
	double get_IGS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(77)]
	double get_IGCP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(78)]
	double get_CavettParameter([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(79)]
	double get_COSTALDACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(80)]
	double get_COSTALDVCHAR([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(81)]
	double get_SRKACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(82)]
	double get_IGHF25([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(83)]
	double get_IGSF25([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);
}
public enum tagExtrapolationEnum
{
	eNoExtrapolation,
	eNothingDefinedYet
}
public enum tagCompoundFamilyEnum
{
	eHydrocarbon,
	eSolid,
	eMiscellaneous,
	eAmine,
	eAlcohol,
	eKetone,
	eAldehyde,
	eEster,
	eCarboxylicAcid,
	eHalogen,
	eNitrile,
	ePhenol,
	eEther,
	ePolymer
}
[ComImport]
[Guid("6C1E01E0-4DC9-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundReferenceStateProperties
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_IGG([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_IGGTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_IGH([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void get_IGHTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	double get_IGS([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void get_IGSTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	double get_IGCP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void get_IGCPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	double get_IGHF25([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void get_IGHF25TPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	double get_IGSF25([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	void get_IGSF25TPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(13)]
	double get_IGHC25([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(14)]
	void get_IGHC25TPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[Guid("6C1E01E1-4DC9-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundPR
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_PRTC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_PRTCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_PRPC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void get_PRPCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	double get_PRVC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void get_PRVCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	double get_PRACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void get_PRACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	double get_PRMC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void get_PRMCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	double get_PRPVOLT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	void get_PRPVOLTTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[Guid("6C1E01E2-4DC9-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundCOSTALD
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_COSTALDACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_COSTALDACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_COSTALDVCHAR([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void get_COSTALDVCHARTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[Guid("EDAF4430-54BC-11D2-B8D6-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundCavett
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_CavettParameter([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_CavettParameterTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[Guid("EDAF4431-54BC-11D2-B8D6-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundViscosity
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void get_ViscosityThetas(out double THETAA, out double THETAB);
}
[ComImport]
[Guid("6C1E01E3-4DC9-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundChaoSeader
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_ChaoSeaderACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_ChaoSeaderACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_ChaoSeaderMVOL([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void get_ChaoSeaderMVOLTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	double get_ChaoSeaderPVOLT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void get_ChaoSeaderPVOLTTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	double get_ChaoSeaderSOLP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void get_ChaoSeaderSOLPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[TypeLibType(4160)]
[Guid("80F388E0-E6D8-11D2-A5B4-00A0C9DF4EE2")]
public interface ICompoundChienNull
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_ChienNullMVOL([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_ChienNullMVOLTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_ChienNullPVOLT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void get_ChienNullPVOLTTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	double get_ChienNullSOLP([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void get_ChienNullSOLPTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[TypeLibType(4160)]
[Guid("912F1450-D323-11D2-A5B2-00A0C9DF4EE2")]
public interface ICompoundVirial
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_VirialSOLV([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_VirialSOLVTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[Guid("6C1E01E4-4DC9-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundPRSV
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_PRSVTC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_PRSVTCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_PRSVPC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void get_PRSVPCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	double get_PRSVVC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void get_PRSVVCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	double get_PRSVACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void get_PRSVACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	double get_PRSVKAPPA([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void get_PRSVKAPPATPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	double get_PRSVPVOLT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	void get_PRSVPVOLTTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[TypeLibType(4160)]
[Guid("83062BA0-5182-11D2-B8D5-00A0C986F9F7")]
public interface ICompoundSRK
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_SRKTC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_SRKTCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_SRKPC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void get_SRKPCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	double get_SRKVC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void get_SRKVCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	double get_SRKACEN([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void get_SRKACENTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	double get_SRKMC([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void get_SRKMCTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	double get_SRKPVOLT([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	void get_SRKPVOLTTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[TypeLibType(4160)]
[Guid("6C1E01E5-4DC9-11D2-B8D5-00A0C986F9F7")]
public interface ICompoundWilson
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_WilsonKVAL([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_WilsonKVALTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_WilsonMVOL([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void get_WilsonMVOLTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[Guid("A7F2D980-5182-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundID
{
	[DispId(1)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(2)]
	int NumberOfSynonymNames
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string get_SynonymName([In] int nIdx);

	[DispId(4)]
	int PPAttribute
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(4)]
		get;
	}

	[DispId(5)]
	string CASN
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(5)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(6)]
	string IUPACName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(6)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(7)]
	int HyprotechID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(7)]
		get;
	}

	[DispId(8)]
	int PPDSID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(8)]
		get;
	}

	[DispId(9)]
	int DDBID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(9)]
		get;
	}

	[DispId(10)]
	int DIPPRID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(10)]
		get;
	}

	[DispId(11)]
	int CMAID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(11)]
		get;
	}

	[DispId(12)]
	string ChemicalFormula
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(12)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(13)]
	void IsWater();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(14)]
	void IsDEG();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(15)]
	void IsTEG();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(16)]
	void IsEG();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(17)]
	void IsMethanol();
}
[ComImport]
[Guid("A7F2D981-5182-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundFamily
{
	[DispId(1)]
	tagCompoundFamilyEnum Family
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
	}

	[DispId(2)]
	string SubFamily
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(3)]
	bool NonCondensable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(3)]
		get;
	}
}
[ComImport]
[Guid("A7F2D982-5182-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundUNIFAC1
{
	[DispId(1)]
	int UNIFAC1NumberOfGroups
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_UNIFAC1Groups([Out] [MarshalAs(UnmanagedType.IDispatch)] out object ppGroupTypeNo);
}
[ComImport]
[Guid("59DC9780-533E-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundUNIQUAC1
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void get_UNIQUAC1Parameters(out double pdR, out double pdQ);
}
[ComImport]
[Guid("A7F2D983-5182-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(4160)]
public interface ICompoundSolidProperties
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	double get_SolidAverageDiameter([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void get_SolidAverageDiameterTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_SolidSphericity([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void get_SolidSphericityTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	double get_SolidSurfaceArea([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void get_SolidSurfaceAreaTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	double get_SolidCarbon([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void get_SolidCarbonTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	double get_SolidHydrogen([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void get_SolidHydrogenTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	double get_SolidNitrogen([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	void get_SolidNitrogenTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(13)]
	double get_SolidOxygen([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(14)]
	void get_SolidOxygenTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(15)]
	double get_SolidSulphur([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(16)]
	void get_SolidSulphurTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(17)]
	double get_SolidChlorine([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, [Out] out int pDependencies);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(18)]
	void get_SolidChlorineTPRange(out double pdTMin, out double pdTMax, out double pdPMin, out double pdPMax);
}
[ComImport]
[Guid("504436BC-6C7A-11D3-BF17-00A0C9B465F6")]
[TypeLibType(4160)]
public interface ICompoundIDPut
{
	[DispId(1)]
	string Name
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(2)]
	int NumberOfSynonymNames
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void set_SynonymName([In] int nIdx, [In] [MarshalAs(UnmanagedType.BStr)] string value);

	[DispId(4)]
	int PPAttribute
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(4)]
		[param: In]
		set;
	}

	[DispId(5)]
	string CASN
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(5)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(6)]
	string IUPACName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(6)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(7)]
	int HyprotechID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(7)]
		[param: In]
		set;
	}

	[DispId(8)]
	int PPDSID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(8)]
		[param: In]
		set;
	}

	[DispId(9)]
	int DDBID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(9)]
		[param: In]
		set;
	}

	[DispId(10)]
	int DIPPRID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(10)]
		[param: In]
		set;
	}

	[DispId(11)]
	int CMAID
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(11)]
		[param: In]
		set;
	}

	[DispId(12)]
	string ChemicalFormula
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(12)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}
}
[ComImport]
[Guid("504436BD-6C7A-11D3-BF17-00A0C9B465F6")]
[TypeLibType(4160)]
public interface ICompoundFamilyPut
{
	[DispId(1)]
	tagCompoundFamilyEnum Family
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[DispId(2)]
	string SubFamily
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(3)]
	bool NonCondensable
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(3)]
		[param: In]
		set;
	}
}
[ComImport]
[TypeLibType(4160)]
[Guid("504436BE-6C7A-11D3-BF17-00A0C9B465F6")]
public interface ICompoundUNIFAC1Put
{
	[DispId(1)]
	int UNIFAC1NumberOfGroups
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void set_UNIFAC1Groups([In] int nNumGroup, [In] [MarshalAs(UnmanagedType.IDispatch)] object ppGroupTypeNo, [In] [MarshalAs(UnmanagedType.IDispatch)] object value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void set_HYPUNIFACNoGr([In] int nNumGroup, [In] [MarshalAs(UnmanagedType.Interface)] IIntegerArrayDisp value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void set_HYPUNIFACSubGr([In] int nNumGroup, [In] [MarshalAs(UnmanagedType.Interface)] IIntegerArrayDisp value);
}
[ComImport]
[TypeLibType(4160)]
[Guid("A4BC2B71-5D6F-11D2-B8DF-00A0C986F9F7")]
public interface IIntegerArrayDisp
{
	[DispId(1)]
	int Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	int get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void set_IthValue([In] int i, [In] int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void Reset();
}
[ComImport]
[TypeLibType(4160)]
[Guid("B777BE90-4DB8-11D2-B8D5-00A0C986F9F7")]
public interface ICompoundInitFromHypDB
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void Init([In][MarshalAs(UnmanagedType.BStr)] string strPath, [In] int nCompIdx);
}
[ComImport]
[Guid("4B9A8242-53FE-11D3-BF15-00A0C9B465F6")]
[TypeLibType(4160)]
public interface ICompoundProp
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetNumbOfProperty([In] byte bFixed, out int nProps);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void GetPropertyName([In] byte bFixed, [In] int iProp, [MarshalAs(UnmanagedType.BStr)] out string Name, out tagPropTypeEnum type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void GetPropertyValue([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, out int pDependencies, out double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void GetPropertyType([In][MarshalAs(UnmanagedType.BStr)] string Name, out tagPropTypeEnum type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void GetEquationProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, out tagEquationShapeEnum shape, [MarshalAs(UnmanagedType.BStr)] out string form, out double tmin, out double tmax, out double pmin, out double pmax, out int nParameters, [MarshalAs(UnmanagedType.Interface)] out IRealArrayDisp pCoeff);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void GetCOMProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, [MarshalAs(UnmanagedType.BStr)] out string ClassID, [MarshalAs(UnmanagedType.Interface)] out IPCProperty prop);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void GetNumbOfCommonProperty(out int nProps);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void GetCommonPropertyName([In] int iProp, [MarshalAs(UnmanagedType.BStr)] out string Name, out tagPropTypeEnum type);
}
public enum tagPropTypeEnum
{
	VoidProp,
	PointProp,
	EquationProp,
	COMProp,
	PointPropBSTR,
	PointPropLong,
	MultiPointPropBSTR,
	MultiPointPropLong,
	MultiPointPropReal
}
public enum tagEquationShapeEnum
{
	PropCurveHYPDB1 = 0,
	PropCurveHYPDB2 = 1,
	PropCurveHYPDB3 = 2,
	PropCurveHYPDB4 = 3,
	PropCurveHYPDB5 = 4,
	PropCurveHYPDB6 = 5,
	PropCurveHYPDB7 = 6,
	PropCurveHYPDB8 = 7,
	PropCurveDIPPR107 = 8,
	PropCurveHYPDB9 = 9,
	PropCurveHYPDB10 = 10,
	PropCurveDIPPR101 = 11,
	PropCurveDIPPR102 = 12,
	PropCurveDIPPR103 = 13,
	PropCurveDIPPR104 = 14,
	PropCurveDIPPR106 = 15,
	PropCurveDIPPR114 = 16,
	PropCurveDIPPR115 = 17,
	PropCurveDIPPR116 = 18,
	PropCurvePOLY2 = 19,
	PropCurvePOLY3 = 20,
	PropCurveANTO1 = 21,
	PropCurveANTO2 = 22,
	PropCurveQUOT1 = 23,
	PropCurveEXPO1 = 24,
	PropCurveEXPO2 = 25,
	PropCurveWTSN1 = 26,
	PropCurveKFAC2 = 27,
	PropCurveKFAC4 = 28,
	PropCurvePPDS1 = 29,
	PropCurvePPDS8 = 30,
	PropCurvePPDS9 = 31,
	PropCurvePPDS10 = 32,
	PropCurvePPDS12 = 33,
	PropCurvePPDS14 = 34,
	PropCurvePPDS15 = 35,
	PropCurvePPDS16 = 36,
	PropCurvePPDS17 = 37,
	PropCurveVoid = 1000
}
[ComImport]
[Guid("5E58EFB4-3C34-11D2-B8CA-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IRealArrayDisp
{
	[DispId(1)]
	int Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	double get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void set_IthValue([In] int i, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void Copy([In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp pArray);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	double get_Values([In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void set_Values([In] int nSize, [In] ref double pVal);
}
[ComImport]
[Guid("5F65CF90-2832-11D4-BF4F-00A0C9B465F6")]
[TypeLibType(4160)]
public interface IPCProperty
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetProperty([In] double dTemp, [In] double dPres, [In] tagExtrapolationEnum eExtrapolationMethod, out int pDependencies, out double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void GetClassID([MarshalAs(UnmanagedType.BStr)] out string ClassID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void GetClassName([MarshalAs(UnmanagedType.BStr)] out string ClassName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void Store([MarshalAs(UnmanagedType.BStr)] out string data);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void Recall([In][MarshalAs(UnmanagedType.BStr)] string data);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void Copy([In][MarshalAs(UnmanagedType.Interface)] IPCProperty prop);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void GetMethod([MarshalAs(UnmanagedType.BStr)] out string method);
}
[ComImport]
[TypeLibType(4160)]
[Guid("4EEFB8B0-2A87-11D4-BF4F-00A0C9B465F6")]
public interface ICompoundPropPut
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void SetPointProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] byte @fixed, [In] double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void SetEquationProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] byte @fixed, [In] tagEquationShapeEnum shape, [In] double tmin, [In] double tmax, [In] double pmin, [In] double pmax, [In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp pCoeff);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void SetCOMProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] byte @fixed, [In][MarshalAs(UnmanagedType.BStr)] string ClassName, [In][MarshalAs(UnmanagedType.Interface)] IPCProperty prop);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void ErasePropFromMap([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] byte @fixed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void FindProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, out byte find, out byte @fixed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void GetEquationInfo([In] tagEquationShapeEnum shape, [MarshalAs(UnmanagedType.BStr)] out string form, out int nParameters);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void SetVoidProperty([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] byte @fixed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void GetPropertyLoader([In][MarshalAs(UnmanagedType.BStr)] string propname, [MarshalAs(UnmanagedType.BStr)] out string loader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	void SetPropertyLoader([In][MarshalAs(UnmanagedType.BStr)] string propname, [In][MarshalAs(UnmanagedType.BStr)] string loader);
}
[ComImport]
[TypeLibType(4160)]
[Guid("4B9A8241-53FE-11D3-BF15-00A0C9B465F6")]
public interface ICompoundCopy
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void CopyToThis([In] int NewID, [In][MarshalAs(UnmanagedType.IDispatch)] object OrigComp);
}
[ComImport]
[TypeLibType(4160)]
[Guid("55F78994-66E8-11D3-8EB3-00A0C9DF3D2C")]
public interface XMLParserClient
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void CharacterData([In][MarshalAs(UnmanagedType.BStr)] string userData);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void StartElement([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void EndElement([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void Comment([In][MarshalAs(UnmanagedType.BStr)] string bstrComment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void ProcessElement([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void Error([In][MarshalAs(UnmanagedType.BStr)] string Error);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void StartDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void EndDocument();
}
[ComImport]
[TypeLibType(4160)]
[Guid("577EDBB0-4F5B-11D3-8EAE-00A0C9DF3D2C")]
public interface TaggedAttributes
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void Add([In][MarshalAs(UnmanagedType.BStr)] string tag, [In][MarshalAs(UnmanagedType.BStr)] string value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void AddMultiple([In][MarshalAs(UnmanagedType.Struct)] object tags, [In][MarshalAs(UnmanagedType.Struct)] object Values);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void find([In][MarshalAs(UnmanagedType.BStr)] string tag, [MarshalAs(UnmanagedType.BStr)] out string retValue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void GetByIndex([In] int index, [MarshalAs(UnmanagedType.BStr)] out string retTag, [MarshalAs(UnmanagedType.BStr)] out string retValue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void GetMultiple([MarshalAs(UnmanagedType.Struct)] out object retTags, [MarshalAs(UnmanagedType.Struct)] out object retValues);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void Size(out int Size);
}
[ComImport]
[Guid("F6FCFD40-F91B-11D3-BF46-00A0C9B465F6")]
[TypeLibType(4160)]
public interface IXMLStore
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string StoreAsXML();
}
[ComImport]
[Guid("BB9B3370-01DA-11D4-BF4B-00A0C9B465F6")]
[TypeLibType(4160)]
public interface IUserProperty
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void SetUserProperty([In][MarshalAs(UnmanagedType.BStr)] string strName, [In][MarshalAs(UnmanagedType.BStr)] string ClassID, [In][MarshalAs(UnmanagedType.IDispatch)] object pProp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void GetUserProperty([In][MarshalAs(UnmanagedType.BStr)] string strName, [MarshalAs(UnmanagedType.IDispatch)] out object pProp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void GetUserPropertyClassID([In][MarshalAs(UnmanagedType.BStr)] string strName, [MarshalAs(UnmanagedType.BStr)] out string ClassID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void DeleteUserProperty([In][MarshalAs(UnmanagedType.BStr)] string strName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void GetNumbOfUserProperty(out int nProp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void GetUserPropertyI([In] int iProp, [MarshalAs(UnmanagedType.BStr)] out string Name, [MarshalAs(UnmanagedType.BStr)] out string ClassID, [MarshalAs(UnmanagedType.IDispatch)] out object pProp);
}
[ComImport]
[TypeLibType(4160)]
[Guid("3AB21E30-C1A3-11D5-BFA5-00A0C9B465F6")]
public interface ICompEqnXYShape
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetEquationPropertyXYShape([In][MarshalAs(UnmanagedType.BStr)] string Name, out tagXYShapeEnum xshape, out tagXYShapeEnum yshape, out double xnorm, out double ynorm, out double xpow, out double ypow, out double a, out double b);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void SetEquationPropertyXYShape([In][MarshalAs(UnmanagedType.BStr)] string Name, [In] tagXYShapeEnum xshape, [In] tagXYShapeEnum yshape, [In] double xnorm, [In] double ynorm, [In] double xpow, [In] double ypow, [In] double a, [In] double b);
}
public enum tagXYShapeEnum
{
	COMx = 1,
	COMxr = 2,
	COM1mxr = 3,
	COMlogx = 4,
	COMlogxr = 5,
	COMlog1mxr = 6,
	COMlnx = 7,
	COMlnxr = 8,
	COMln1mxr = 9,
	COMexpx = 10,
	COMexpxr = 11,
	COMexp1mxr = 12,
	COMsinx = 13,
	COMcosx = 14,
	COMtanx = 15,
	COMsinxr = 16,
	COMcosxr = 17,
	COMtanxr = 18,
	COMsin1mxr = 19,
	COMcos1mxr = 20,
	COMtan1mxr = 21,
	COM1mx = 22,
	COMxm1 = 23,
	COMxrm1 = 24,
	COMcuberoot1mxr = 25,
	COMxppdsm1 = 26,
	COMlnxxo = 27,
	COMxscale = 28,
	COMxxo = 29,
	COMrootxodx = 30,
	COMscalexy = 31,
	COMydx = 32,
	COMrootxdy = 33,
	COMxdp = 34,
	COMxp = 35,
	COMlnxp = 36,
	eNoShapeDefined = 1000
}
[ComImport]
[ClassInterface((short)0)]
[Guid("7ED318E3-51B6-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(2)]
public class COTHCompoundCollectionClass : ICompoundCollection, COTHCompoundCollection, ICompoundCollectionSetup, ICompoundManipulation, ICompCollnIPInfo, XMLParserClient, IXMLStore, ILoadCompoundProp, ISubCompList, IQueryLoader, IPureEstimatorHandler, ISubCompList1
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object ICompoundCollection.get_Compound([In] int nIndex);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	extern void ICompoundCollection.set_Compound([In] int nIndex, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[DispId(2)]
	extern int ICompoundCollection.NumberOfCompounds
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object ICompoundCollection.get_InteractionParameters([In] [MarshalAs(UnmanagedType.BStr)] string strModel);

	extern object ICompoundCollectionSetup.InteractionParameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern void ICompoundCollection.AddCompound([In][MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	extern void ICompoundCollection.Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	extern void ICompoundCollection.GetBasicCompound([In] int nIndex, [MarshalAs(UnmanagedType.Interface)] out COTHCompound pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	extern void ICompoundCollection.GetOffsetH([MarshalAs(UnmanagedType.Interface)] out IRealArrayDisp OffsetH);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	extern void ICompoundCollection.PutOffsetH([In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp OffsetH);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	extern void ICompoundCollection.GetOffsetS([MarshalAs(UnmanagedType.Interface)] out IRealArrayDisp OffsetS);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	extern void ICompoundCollection.PutOffsetS([In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp OffsetS);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	extern void ICompoundCollection.AddCompoundFromLoader([In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In][MarshalAs(UnmanagedType.BStr)] string loader, [In] byte useloader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundManipulation.MoveCompound([In] int compToMove, [In] int moveBeforeComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundManipulation.RemoveLastCompound();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompoundManipulation.AddLastCompoundLoadIPs([In][MarshalAs(UnmanagedType.IDispatch)] object pVal, [In][MarshalAs(UnmanagedType.BStr)] string databasedir);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICompCollnIPInfo.CompCollnIPInfo(out int numbIPs, [MarshalAs(UnmanagedType.Struct)] out object modelnames, [MarshalAs(UnmanagedType.Struct)] out object modelpanes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.CharacterData([In][MarshalAs(UnmanagedType.BStr)] string userData);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.StartElement([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.EndElement([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.Comment([In][MarshalAs(UnmanagedType.BStr)] string bstrComment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.ProcessElement([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.Error([In][MarshalAs(UnmanagedType.BStr)] string Error);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.StartDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.EndDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.BStr)]
	extern string IXMLStore.StoreAsXML();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.LoadAllCompounds([In][MarshalAs(UnmanagedType.BStr)] string loader, [In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In] byte useloader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.LoadOneCompound([In] int iComp, [In][MarshalAs(UnmanagedType.BStr)] string loader, [In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In] byte useloader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.LoadOneProperty([In] int iComp, [In][MarshalAs(UnmanagedType.BStr)] string propname, [In][MarshalAs(UnmanagedType.BStr)] string loader, [In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In] byte useloader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.SetDefaultLoader([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.BStr)] string ClassName, [In][MarshalAs(UnmanagedType.BStr)] string path, [In][MarshalAs(UnmanagedType.IDispatch)] object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.AddLoader([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.BStr)] string ClassName, [In][MarshalAs(UnmanagedType.BStr)] string path, [In][MarshalAs(UnmanagedType.IDispatch)] object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.RemoveLoader([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.GetLoader([In][MarshalAs(UnmanagedType.BStr)] string Name, [MarshalAs(UnmanagedType.IDispatch)] out object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.GetDefaultLoader([MarshalAs(UnmanagedType.BStr)] out string Name, [MarshalAs(UnmanagedType.IDispatch)] out object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.GetNumOfLoaders(out int nloader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.GetLoaderI([In] int iloader, [MarshalAs(UnmanagedType.BStr)] out string Name, [MarshalAs(UnmanagedType.IDispatch)] out object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ILoadCompoundProp.SetAsDefaultLoader([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISubCompList.SetUpSubCompList([In][MarshalAs(UnmanagedType.Interface)] COTHCompoundCollection pMasterCompList, [In] int nComp, [In][MarshalAs(UnmanagedType.Interface)] IIntegerArrayDisp pMapping);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISubCompList.GetSubCompList(out int nComp, [MarshalAs(UnmanagedType.Interface)] out IIntegerArrayDisp pMapping);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IQueryLoader.GetHypIDs([In][MarshalAs(UnmanagedType.BStr)] string strPath, [In] int nComp, [In][MarshalAs(UnmanagedType.BStr)] string identifierName, [In][MarshalAs(UnmanagedType.Struct)] ref object identifiers, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object hyprotechIDs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.GetNumbEstimators([In][Out] ref int nEstimators, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Names);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.GetEstimatorInfo([In] int iEstimator, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Version, [In][Out] ref byte NeedPath, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Note, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.GetEstSupportedProps([In] int iEstimator, [In][Out] ref int nProp, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Props, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.EstCanDo([In] int iEstimator, [In][MarshalAs(UnmanagedType.BStr)] string prop, [In][Out] ref int nMethods, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Methods, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.EstUnknownProps([In] int iEstimator, [In] int iComp, [In] int nSpecProps, [In][MarshalAs(UnmanagedType.Struct)] object SpecProps, [In][MarshalAs(UnmanagedType.Struct)] object SpecMethods, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.EstProp([In] int iEstimator, [In] int iComp, [In][MarshalAs(UnmanagedType.BStr)] string prop, [In][MarshalAs(UnmanagedType.BStr)] string method, [In] byte Replace, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.IsEstReady([In] int iEstimator, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.FindEstimator([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][Out] ref int iEstimator, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.GetEstimator([In] int iEstimator, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object pEstimator, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.AddEstimator([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.BStr)] string ClassName, [In][MarshalAs(UnmanagedType.BStr)] string path, [In][MarshalAs(UnmanagedType.IDispatch)] object pEstimator);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.SetAsDefault([In] int iEstimator, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPureEstimatorHandler.RemoveEstimator([In] int iEstimator, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISubCompList1.SetUpSubCompList([In][MarshalAs(UnmanagedType.Interface)] COTHCompoundCollection pMasterCompList, [In] int nComp, [In][MarshalAs(UnmanagedType.Interface)] IIntegerArrayDisp pMapping);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISubCompList1.GetSubCompList(out int nComp, [MarshalAs(UnmanagedType.Interface)] out IIntegerArrayDisp pMapping);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISubCompList1.GetSubCompList1(out int nComp, [In][MarshalAs(UnmanagedType.Interface)] IIntegerArrayDisp pMapping, [In] int nSize);
}
[ComImport]
[Guid("9722A6D1-5185-11D2-B8D5-00A0C986F9F7")]
[CoClass(typeof(COTHCompoundCollectionClass))]
public interface COTHCompoundCollection : ICompoundCollection
{
}
[ComImport]
[TypeLibType(4160)]
[Guid("9722A6D1-5185-11D2-B8D5-00A0C986F9F7")]
public interface ICompoundCollection
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_Compound([In] int nIndex);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void set_Compound([In] int nIndex, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[DispId(2)]
	int NumberOfCompounds
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void AddCompound([In][MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_InteractionParameters([In] [MarshalAs(UnmanagedType.BStr)] string strModel);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void GetBasicCompound([In] int nIndex, [MarshalAs(UnmanagedType.Interface)] out COTHCompound pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void GetOffsetH([MarshalAs(UnmanagedType.Interface)] out IRealArrayDisp OffsetH);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void PutOffsetH([In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp OffsetH);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	void GetOffsetS([MarshalAs(UnmanagedType.Interface)] out IRealArrayDisp OffsetS);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void PutOffsetS([In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp OffsetS);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	void AddCompoundFromLoader([In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In][MarshalAs(UnmanagedType.BStr)] string loader, [In] byte useloader);
}
[ComImport]
[TypeLibType(4096)]
[Guid("894E0DF0-62D9-11D2-B8E0-00A0C986F9F7")]
public interface ICompoundCollectionSetup
{
	[DispId(1610743808)]
	object InteractionParameters
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}
}
[ComImport]
[TypeLibType(4160)]
[Guid("34B02991-6C70-11D3-A5D3-00A0C9DF422B")]
public interface ICompoundManipulation
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void MoveCompound([In] int compToMove, [In] int moveBeforeComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void RemoveLastCompound();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void AddLastCompoundLoadIPs([In][MarshalAs(UnmanagedType.IDispatch)] object pVal, [In][MarshalAs(UnmanagedType.BStr)] string databasedir);
}
[ComImport]
[Guid("F81DEA91-EA3A-11D3-A619-00A0C9DF422B")]
[TypeLibType(4160)]
public interface ICompCollnIPInfo
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void CompCollnIPInfo(out int numbIPs, [MarshalAs(UnmanagedType.Struct)] out object modelnames, [MarshalAs(UnmanagedType.Struct)] out object modelpanes);
}
[ComImport]
[Guid("D7880E80-47AF-11D4-BF51-00A0C9B465F6")]
[TypeLibType(4160)]
public interface ILoadCompoundProp
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void LoadAllCompounds([In][MarshalAs(UnmanagedType.BStr)] string loader, [In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In] byte useloader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void LoadOneCompound([In] int iComp, [In][MarshalAs(UnmanagedType.BStr)] string loader, [In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In] byte useloader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void LoadOneProperty([In] int iComp, [In][MarshalAs(UnmanagedType.BStr)] string propname, [In][MarshalAs(UnmanagedType.BStr)] string loader, [In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In] byte useloader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void SetDefaultLoader([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.BStr)] string ClassName, [In][MarshalAs(UnmanagedType.BStr)] string path, [In][MarshalAs(UnmanagedType.IDispatch)] object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void AddLoader([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.BStr)] string ClassName, [In][MarshalAs(UnmanagedType.BStr)] string path, [In][MarshalAs(UnmanagedType.IDispatch)] object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void RemoveLoader([In][MarshalAs(UnmanagedType.BStr)] string Name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void GetLoader([In][MarshalAs(UnmanagedType.BStr)] string Name, [MarshalAs(UnmanagedType.IDispatch)] out object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void GetDefaultLoader([MarshalAs(UnmanagedType.BStr)] out string Name, [MarshalAs(UnmanagedType.IDispatch)] out object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	void GetNumOfLoaders(out int nloader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void GetLoaderI([In] int iloader, [MarshalAs(UnmanagedType.BStr)] out string Name, [MarshalAs(UnmanagedType.IDispatch)] out object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	void SetAsDefaultLoader([In][MarshalAs(UnmanagedType.BStr)] string Name);
}
[ComImport]
[Guid("E28E0220-F171-11D4-BF8F-00A0C9B465F6")]
[TypeLibType(4160)]
public interface ISubCompList
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void SetUpSubCompList([In][MarshalAs(UnmanagedType.Interface)] COTHCompoundCollection pMasterCompList, [In] int nComp, [In][MarshalAs(UnmanagedType.Interface)] IIntegerArrayDisp pMapping);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void GetSubCompList(out int nComp, [MarshalAs(UnmanagedType.Interface)] out IIntegerArrayDisp pMapping);
}
[ComImport]
[TypeLibType(4160)]
[Guid("CF6995B8-8AB9-4513-8A40-62DD46CD8D31")]
public interface IQueryLoader
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetHypIDs([In][MarshalAs(UnmanagedType.BStr)] string strPath, [In] int nComp, [In][MarshalAs(UnmanagedType.BStr)] string identifierName, [In][MarshalAs(UnmanagedType.Struct)] ref object identifiers, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object hyprotechIDs);
}
[ComImport]
[Guid("4FFF55A0-312E-11D6-B87E-000347A74660")]
[TypeLibType(4160)]
public interface IPureEstimatorHandler
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetNumbEstimators([In][Out] ref int nEstimators, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Names);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void GetEstimatorInfo([In] int iEstimator, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Version, [In][Out] ref byte NeedPath, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Note, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void GetEstSupportedProps([In] int iEstimator, [In][Out] ref int nProp, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Props, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void EstCanDo([In] int iEstimator, [In][MarshalAs(UnmanagedType.BStr)] string prop, [In][Out] ref int nMethods, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Methods, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void EstUnknownProps([In] int iEstimator, [In] int iComp, [In] int nSpecProps, [In][MarshalAs(UnmanagedType.Struct)] object SpecProps, [In][MarshalAs(UnmanagedType.Struct)] object SpecMethods, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void EstProp([In] int iEstimator, [In] int iComp, [In][MarshalAs(UnmanagedType.BStr)] string prop, [In][MarshalAs(UnmanagedType.BStr)] string method, [In] byte Replace, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void IsEstReady([In] int iEstimator, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void FindEstimator([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][Out] ref int iEstimator, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	void GetEstimator([In] int iEstimator, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object pEstimator, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void AddEstimator([In][MarshalAs(UnmanagedType.BStr)] string Name, [In][MarshalAs(UnmanagedType.BStr)] string ClassName, [In][MarshalAs(UnmanagedType.BStr)] string path, [In][MarshalAs(UnmanagedType.IDispatch)] object pEstimator);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	void SetAsDefault([In] int iEstimator, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	void RemoveEstimator([In] int iEstimator, [In][Out] ref int Status);
}
[ComImport]
[TypeLibType(4160)]
[Guid("06BAB310-C1C2-11D6-B896-000347A74660")]
public interface ISubCompList1
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void SetUpSubCompList([In][MarshalAs(UnmanagedType.Interface)] COTHCompoundCollection pMasterCompList, [In] int nComp, [In][MarshalAs(UnmanagedType.Interface)] IIntegerArrayDisp pMapping);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void GetSubCompList(out int nComp, [MarshalAs(UnmanagedType.Interface)] out IIntegerArrayDisp pMapping);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void GetSubCompList1(out int nComp, [In][MarshalAs(UnmanagedType.Interface)] IIntegerArrayDisp pMapping, [In] int nSize);
}
[ComImport]
[Guid("A5B7FB92-5236-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(2)]
[ClassInterface((short)0)]
public class COTHPhaseClass : IBasicPhase, COTHPhase, IEnumeratedPropertyContainer, IRegisterableObject, IUserPhaseType, IDerivativeProp
{
	[DispId(1610743808)]
	extern tagPhaseTypeEnum IBasicPhase.PhaseType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[param: In]
		set;
	}

	[DispId(1610743810)]
	extern tagPhaseStatusEnum IBasicPhase.PhaseStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[param: In]
		set;
	}

	[DispId(1610743812)]
	extern double IBasicPhase.PhaseFraction
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[param: In]
		set;
	}

	[DispId(1610743814)]
	extern double IBasicPhase.PhaseMassFraction
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[param: In]
		set;
	}

	[DispId(1610743816)]
	extern double IBasicPhase.Pressure
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		[param: In]
		set;
	}

	[DispId(1610743818)]
	extern double IBasicPhase.Temperature
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[param: In]
		set;
	}

	[DispId(1610743820)]
	extern double IBasicPhase.Homotopy
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		[param: In]
		set;
	}

	[DispId(1610743822)]
	extern double IBasicPhase.Enthalpy
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		[param: In]
		set;
	}

	[DispId(1610743824)]
	extern double IBasicPhase.Entropy
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[param: In]
		set;
	}

	[DispId(1610743826)]
	extern double IBasicPhase.Cp
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[param: In]
		set;
	}

	[DispId(1610743828)]
	extern double IBasicPhase.MolarVolume
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743828)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743828)]
		[param: In]
		set;
	}

	[DispId(1610743830)]
	extern double IBasicPhase.MolecularWeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[param: In]
		set;
	}

	[DispId(1610743832)]
	extern object IBasicPhase.MolarComposition
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743832)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743832)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	[DispId(1610743834)]
	extern object IBasicPhase.MassComposition
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	[DispId(1610743837)]
	extern int IBasicPhase.NumberOfCompounds
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743837)]
		get;
	}

	[DispId(1610743838)]
	extern object IBasicPhase.Compounds
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743838)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
	}

	[DispId(1610743843)]
	extern IRealArrayDisp IBasicPhase.MolarCompositionDisp
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743845)]
	extern IRealArrayDisp IBasicPhase.LnFugacity
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743845)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743845)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743847)]
	extern IRealArrayDisp IBasicPhase.LnFugacityCoeff
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743847)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743847)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743849)]
	extern byte IBasicPhase.IsPseudoRoot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743849)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743849)]
		[param: In]
		set;
	}

	extern tagPhaseTypeEnum IUserPhaseType.UserPhaseType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743836)]
	extern void IBasicPhase.Finalize([In][MarshalAs(UnmanagedType.IDispatch)] object pCompList);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743839)]
	extern void IBasicPhase.ResetProperties([In] int dwSettings);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	extern bool IBasicPhase.IsActivePhase();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743841)]
	extern void IBasicPhase.CopyProperties([In][MarshalAs(UnmanagedType.IDispatch)] object pPhase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	extern void IBasicPhase.GetCompounds([MarshalAs(UnmanagedType.Interface)] out COTHCompoundCollection ppCompList);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743851)]
	extern void IBasicPhase.GetLnFugacity([MarshalAs(UnmanagedType.Interface)] out IRealArrayDisp ppFugacity);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	extern void IBasicPhase.GetLnFugacityCoeff([MarshalAs(UnmanagedType.Interface)] out IRealArrayDisp ppFugacityCoeff);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IEnumeratedPropertyContainer.GetNumberOfProperties();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IEnumeratedPropertyContainer.GetPropertyIDs([In] int nMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern bool IEnumeratedPropertyContainer.SupportsProperty([In] int nPropID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IEnumeratedPropertyContainer.AddProperty([In] int nPropID, [In][MarshalAs(UnmanagedType.Struct)] object varPropVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IEnumeratedPropertyContainer.RemoveProperty([In] int nPropID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IEnumeratedPropertyContainer.PutPropertyValue([In] int nPropID, [In][MarshalAs(UnmanagedType.Struct)] object varPropVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.Struct)]
	extern object IEnumeratedPropertyContainer.GetPropertyValue([In] int nPropID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IRegisterableObject.RegisterProperties([In][MarshalAs(UnmanagedType.IDispatch)] object pEnumeratedPropertyRegistry);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.ClearDerivativesProps();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.AddDerivativeProp([In] int nPropID, [In] int nDerivativeID, [In] tagResultTypeEnum ePropResultType, [In] tagResultTypeEnum eDevResultType, [In][Out] ref int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetDerivativePropIndex([In] int nPropID, [In] int nDerivativeID, [In][Out] ref int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.RemoveDerivativeProp([In] int nIdx, [In] int nPropID, [In] int nDerivativeID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetNumDerivativeProps([In][Out] ref int nNumDerivativeProps);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetDerivativePropIDs([In] int nIdx, [In][Out] ref int nPropID, [In][Out] ref int nDerivativeID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.SetNeedDerivative([In] int nIdx, [In] byte bNeeded);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetNeedDerivative([In] int nIdx, [In][Out] ref byte bNeeded);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.SetDerivativeStatus([In] int nIdx, [In] tagDerivativeStatusEnum eStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetDerivativeStatus([In] int nIdx, [In][Out] ref tagDerivativeStatusEnum eStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.PutPointDerivative([In] int nIdx, [In] double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetPointDerivative([In] int nIdx, [In][Out] ref double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.PutArrayDerivative([In] int nIdx, [In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp pIArr);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetArrayDerivative([In] int nIdx, [In][Out][MarshalAs(UnmanagedType.Interface)] ref IRealArrayDisp pIArr);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.PutMatrixDerivative([In] int nIdx, [In][MarshalAs(UnmanagedType.Interface)] IRealMatrixDisp pIMat);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetMatrixDerivative([In] int nIdx, [In][Out][MarshalAs(UnmanagedType.Interface)] ref IRealMatrixDisp pIMat);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.PutVariantDerivative([In] int nIdx, [In][MarshalAs(UnmanagedType.Struct)] object varPropVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetVariantDerivative([In] int nIdx, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object pVarPropVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetResultValueType([In] int nIdx, [In][Out] ref tagResultTypeEnum ePropResultType, [In][Out] ref tagResultTypeEnum eDevResultType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.PutDerivativeType([In] int nIdx, [In] tagDerivativeTypeEnum eDevType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeProp.GetDerivativeType([In] int nIdx, [In] ref tagDerivativeTypeEnum eDevType);
}
[ComImport]
[Guid("C07DD8BB-168A-11D2-B8B9-00A0C986F9F7")]
[CoClass(typeof(COTHPhaseClass))]
public interface COTHPhase : IBasicPhase
{
}
[ComImport]
[Guid("C07DD8BB-168A-11D2-B8B9-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IBasicPhase
{
	[DispId(1610743808)]
	tagPhaseTypeEnum PhaseType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[param: In]
		set;
	}

	[DispId(1610743810)]
	tagPhaseStatusEnum PhaseStatus
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		[param: In]
		set;
	}

	[DispId(1610743812)]
	double PhaseFraction
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		[param: In]
		set;
	}

	[DispId(1610743814)]
	double PhaseMassFraction
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[param: In]
		set;
	}

	[DispId(1610743816)]
	double Pressure
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		[param: In]
		set;
	}

	[DispId(1610743818)]
	double Temperature
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		[param: In]
		set;
	}

	[DispId(1610743820)]
	double Homotopy
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743820)]
		[param: In]
		set;
	}

	[DispId(1610743822)]
	double Enthalpy
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743822)]
		[param: In]
		set;
	}

	[DispId(1610743824)]
	double Entropy
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743824)]
		[param: In]
		set;
	}

	[DispId(1610743826)]
	double Cp
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743826)]
		[param: In]
		set;
	}

	[DispId(1610743828)]
	double MolarVolume
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743828)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743828)]
		[param: In]
		set;
	}

	[DispId(1610743830)]
	double MolecularWeight
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743830)]
		[param: In]
		set;
	}

	[DispId(1610743832)]
	object MolarComposition
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743832)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743832)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	[DispId(1610743834)]
	object MassComposition
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743834)]
		[param: In]
		[param: MarshalAs(UnmanagedType.IDispatch)]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743836)]
	void Finalize([In][MarshalAs(UnmanagedType.IDispatch)] object pCompList);

	[DispId(1610743837)]
	int NumberOfCompounds
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743837)]
		get;
	}

	[DispId(1610743838)]
	object Compounds
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743838)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743839)]
	void ResetProperties([In] int dwSettings);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743840)]
	bool IsActivePhase();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743841)]
	void CopyProperties([In][MarshalAs(UnmanagedType.IDispatch)] object pPhase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743842)]
	void GetCompounds([MarshalAs(UnmanagedType.Interface)] out COTHCompoundCollection ppCompList);

	[DispId(1610743843)]
	IRealArrayDisp MolarCompositionDisp
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743843)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743845)]
	IRealArrayDisp LnFugacity
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743845)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743845)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743847)]
	IRealArrayDisp LnFugacityCoeff
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743847)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743847)]
		[param: In]
		[param: MarshalAs(UnmanagedType.Interface)]
		set;
	}

	[DispId(1610743849)]
	byte IsPseudoRoot
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743849)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743849)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743851)]
	void GetLnFugacity([MarshalAs(UnmanagedType.Interface)] out IRealArrayDisp ppFugacity);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743852)]
	void GetLnFugacityCoeff([MarshalAs(UnmanagedType.Interface)] out IRealArrayDisp ppFugacityCoeff);
}
public enum tagPhaseTypeEnum
{
	xptUnknownPhase,
	xptOverall,
	xptFeed,
	xptVapour,
	xptLiquid,
	xptAqueous,
	xptSolid,
	xptInsolubleSolid,
	xptDensePhase,
	xptHydrate,
	xptWax,
	xptUserType,
	xptMultiPhase,
	xptLastPhaseType
}
public enum tagPhaseStatusEnum
{
	xpsUnknownStatus = 0,
	xpsActivePhase = 1,
	xpsGarbagePhase = 2,
	xpsDeletedPhase = 3,
	xpsVirtualPhase = 4,
	xpsLastPhaseStatus = 1000
}
[ComImport]
[Guid("F915CB85-37A9-11D2-B8C6-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IEnumeratedPropertyContainer
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	int GetNumberOfProperties();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object GetPropertyIDs([In] int nMax);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	bool SupportsProperty([In] int nPropID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void AddProperty([In] int nPropID, [In][MarshalAs(UnmanagedType.Struct)] object varPropVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void RemoveProperty([In] int nPropID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void PutPropertyValue([In] int nPropID, [In][MarshalAs(UnmanagedType.Struct)] object varPropVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	[return: MarshalAs(UnmanagedType.Struct)]
	object GetPropertyValue([In] int nPropID);
}
[ComImport]
[TypeLibType(4160)]
[Guid("D4814CE1-5E12-11D2-B8DF-00A0C986F9F7")]
public interface IRegisterableObject
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void RegisterProperties([In][MarshalAs(UnmanagedType.IDispatch)] object pEnumeratedPropertyRegistry);
}
[ComImport]
[TypeLibType(4160)]
[Guid("708D8B40-BF42-11D5-BFA4-00A0C9B465F6")]
public interface IUserPhaseType
{
	[DispId(1610743808)]
	tagPhaseTypeEnum UserPhaseType
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743808)]
		[param: In]
		set;
	}
}
[ComImport]
[Guid("4AB34CE0-5E24-11D7-B8B2-000347A74660")]
[TypeLibType(4160)]
public interface IDerivativeProp
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void ClearDerivativesProps();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void AddDerivativeProp([In] int nPropID, [In] int nDerivativeID, [In] tagResultTypeEnum ePropResultType, [In] tagResultTypeEnum eDevResultType, [In][Out] ref int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void GetDerivativePropIndex([In] int nPropID, [In] int nDerivativeID, [In][Out] ref int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void RemoveDerivativeProp([In] int nIdx, [In] int nPropID, [In] int nDerivativeID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void GetNumDerivativeProps([In][Out] ref int nNumDerivativeProps);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void GetDerivativePropIDs([In] int nIdx, [In][Out] ref int nPropID, [In][Out] ref int nDerivativeID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void SetNeedDerivative([In] int nIdx, [In] byte bNeeded);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void GetNeedDerivative([In] int nIdx, [In][Out] ref byte bNeeded);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	void SetDerivativeStatus([In] int nIdx, [In] tagDerivativeStatusEnum eStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	void GetDerivativeStatus([In] int nIdx, [In][Out] ref tagDerivativeStatusEnum eStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	void PutPointDerivative([In] int nIdx, [In] double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743819)]
	void GetPointDerivative([In] int nIdx, [In][Out] ref double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	void PutArrayDerivative([In] int nIdx, [In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp pIArr);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743821)]
	void GetArrayDerivative([In] int nIdx, [In][Out][MarshalAs(UnmanagedType.Interface)] ref IRealArrayDisp pIArr);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743822)]
	void PutMatrixDerivative([In] int nIdx, [In][MarshalAs(UnmanagedType.Interface)] IRealMatrixDisp pIMat);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743823)]
	void GetMatrixDerivative([In] int nIdx, [In][Out][MarshalAs(UnmanagedType.Interface)] ref IRealMatrixDisp pIMat);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743824)]
	void PutVariantDerivative([In] int nIdx, [In][MarshalAs(UnmanagedType.Struct)] object varPropVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743825)]
	void GetVariantDerivative([In] int nIdx, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object pVarPropVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743826)]
	void GetResultValueType([In] int nIdx, [In][Out] ref tagResultTypeEnum ePropResultType, [In][Out] ref tagResultTypeEnum eDevResultType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743827)]
	void PutDerivativeType([In] int nIdx, [In] tagDerivativeTypeEnum eDevType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743828)]
	void GetDerivativeType([In] int nIdx, [In] ref tagDerivativeTypeEnum eDevType);
}
public enum tagResultTypeEnum
{
	NoResultType,
	RealPoint,
	RealArray,
	RealMatrix,
	IntPoint,
	IntArray,
	IntMatrix,
	VariantType
}
public enum tagDerivativeStatusEnum
{
	NoDerivativeStatus,
	ToBeCalculated,
	DoNotCalculate,
	CanNotCalculate,
	Calculated,
	CalculatedAnalytically,
	CalculatedNumerically,
	CalculatedPartialAnalytically
}
[ComImport]
[TypeLibType(4160)]
[Guid("5E58EFB6-3C34-11D2-B8CA-00A0C986F9F7")]
public interface IRealMatrixDisp
{
	[DispId(1)]
	int NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[DispId(2)]
	int NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void set_IJthValue([In] int nRow, [In] int nColumn, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_IthRow([In] int nRow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void set_IthRow([In] int nRow, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_IthColumn([In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void set_IthColumn([In] int nColumn, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void Reset();
}
public enum tagDerivativeTypeEnum
{
	NoDerivativeType,
	AnalyticalOnly,
	NumericalOnly,
	NumericalBackup
}
[ComImport]
[Guid("A5B7FB97-5236-11D2-B8D5-00A0C986F9F7")]
[TypeLibType(2)]
[ClassInterface((short)0)]
public class COTHPhaseCollectionClass : IPhaseCollection, COTHPhaseCollection, IFlashPhaseCollection, IRegisterableObject, IReplacePhase
{
	[DispId(1610743809)]
	extern object IPhaseCollection.Compounds
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
	}

	[DispId(1610743810)]
	extern int IPhaseCollection.MaximumNumberOfEquilibriumPhases
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}

	[DispId(1610743812)]
	extern int IPhaseCollection.NumberOfFeedPhases
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[DispId(1610743815)]
	extern int IPhaseCollection.NumberOfEquilibriumPhases
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		[param: In]
		set;
	}

	[DispId(1610743818)]
	extern int IPhaseCollection.NumberOfActivePhases
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	extern void IPhaseCollection.Finalize([In][MarshalAs(UnmanagedType.IDispatch)] object pCompList, [In] int nPhase, [In] int nFeed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	extern void IPhaseCollection.PutFeedComposition([In][MarshalAs(UnmanagedType.IDispatch)] object pRealArray, [In] int nFeed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	extern void IPhaseCollection.ResetCollection([In] int dwSettings);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IPhaseCollection.LocatePhase([In] tagPhaseTypeEnum ePhaseType, [In] int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IPhaseCollection.GetEquilibriumPhase([In] int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743819)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IPhaseCollection.GetActivePhase([In] int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	extern void IPhaseCollection.ApplyActor([In][MarshalAs(UnmanagedType.IDispatch)] object pIPhaseCollectionActor);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IFlashPhaseCollection.RelocatePhaseAfter([In] int nAfterThis, [In] int nTarget);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IFlashPhaseCollection.SwapEquilibriumPhases([In] int nIdx, [In] int nJdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IRegisterableObject.RegisterProperties([In][MarshalAs(UnmanagedType.IDispatch)] object pEnumeratedPropertyRegistry);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IReplacePhase.LocateEqmPhaseIndex([In] tagPhaseTypeEnum ePhaseType, [In] int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IReplacePhase.ReplaceEquilibriumPhase([In] int nIdx, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase);
}
[ComImport]
[Guid("B25C9611-360C-11D2-B8C6-00A0C986F9F7")]
[CoClass(typeof(COTHPhaseCollectionClass))]
public interface COTHPhaseCollection : IPhaseCollection
{
}
[ComImport]
[Guid("B25C9611-360C-11D2-B8C6-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IPhaseCollection
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void Finalize([In][MarshalAs(UnmanagedType.IDispatch)] object pCompList, [In] int nPhase, [In] int nFeed);

	[DispId(1610743809)]
	object Compounds
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743809)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		get;
	}

	[DispId(1610743810)]
	int MaximumNumberOfEquilibriumPhases
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743810)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void PutFeedComposition([In][MarshalAs(UnmanagedType.IDispatch)] object pRealArray, [In] int nFeed);

	[DispId(1610743812)]
	int NumberOfFeedPhases
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743812)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void ResetCollection([In] int dwSettings);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object LocatePhase([In] tagPhaseTypeEnum ePhaseType, [In] int nIdx);

	[DispId(1610743815)]
	int NumberOfEquilibriumPhases
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743815)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object GetEquilibriumPhase([In] int nIdx);

	[DispId(1610743818)]
	int NumberOfActivePhases
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743818)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743819)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object GetActivePhase([In] int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	void ApplyActor([In][MarshalAs(UnmanagedType.IDispatch)] object pIPhaseCollectionActor);
}
[ComImport]
[Guid("92DB9B20-4E70-11D2-BB21-204C4F4F5020")]
[TypeLibType(4160)]
public interface IFlashPhaseCollection
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void RelocatePhaseAfter([In] int nAfterThis, [In] int nTarget);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void SwapEquilibriumPhases([In] int nIdx, [In] int nJdx);
}
[ComImport]
[TypeLibType(4160)]
[Guid("26D8D3C0-CE8C-46B9-917B-FCB48334EFCC")]
public interface IReplacePhase
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	int LocateEqmPhaseIndex([In] tagPhaseTypeEnum ePhaseType, [In] int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void ReplaceEquilibriumPhase([In] int nIdx, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase);
}
[ComImport]
[TypeLibType(4160)]
[Guid("BE1C362D-38CC-11D4-A5F8-009027120537")]
public interface ILoad
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void Get_SupportedPropList([MarshalAs(UnmanagedType.Struct)] out object pvecPropList, [MarshalAs(UnmanagedType.Struct)] out object pvecSearchKey);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void Set_Path([In][MarshalAs(UnmanagedType.BStr)] string path, [MarshalAs(UnmanagedType.BStr)] out string Msg);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void Get_DBIdentification([MarshalAs(UnmanagedType.BStr)] out string Name, [MarshalAs(UnmanagedType.BStr)] out string Version, [MarshalAs(UnmanagedType.BStr)] out string Note);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void Get_AllCompounds([In][MarshalAs(UnmanagedType.BStr)] string propname, [MarshalAs(UnmanagedType.Struct)] out object PropArray, out int ArraySize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void Get_Prop([In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In][MarshalAs(UnmanagedType.BStr)] string propname, out tagPropTypeEnum type, [MarshalAs(UnmanagedType.IDispatch)] out object IPropCalculate, [MarshalAs(UnmanagedType.Struct)] out object Val, out int ValSize, out tagEquationShapeEnum EqShape, [MarshalAs(UnmanagedType.Struct)] out object Coeff, out int CoeffSize, out double tmin, out double tmax, out double pmin, out double pmax, [MarshalAs(UnmanagedType.BStr)] out string Note);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void Get_PropType([In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In][MarshalAs(UnmanagedType.BStr)] string propname, out tagPropTypeEnum type);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void Get_PropSingleVal([In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In][MarshalAs(UnmanagedType.BStr)] string propname, [MarshalAs(UnmanagedType.Struct)] out object Val, [MarshalAs(UnmanagedType.BStr)] out string Note);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void Get_PropEquation([In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In][MarshalAs(UnmanagedType.BStr)] string propname, out tagEquationShapeEnum EqShape, [MarshalAs(UnmanagedType.Struct)] out object Coeff, out int CoeffSize, out double tmin, out double tmax, out double pmin, out double pmax, [MarshalAs(UnmanagedType.BStr)] out string Note);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	void Get_PropCOM([In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In][MarshalAs(UnmanagedType.BStr)] string propname, [MarshalAs(UnmanagedType.IDispatch)] out object IPropCalculate, [MarshalAs(UnmanagedType.BStr)] out string Note);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void Get_PropMultiVal([In][MarshalAs(UnmanagedType.BStr)] string searchkey, [In][MarshalAs(UnmanagedType.BStr)] string id, [In][MarshalAs(UnmanagedType.BStr)] string propname, [MarshalAs(UnmanagedType.Struct)] out object Val, out int ValSize, [MarshalAs(UnmanagedType.BStr)] out string Note);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	void Get_AllSynonyms([In][MarshalAs(UnmanagedType.BStr)] string searchkey, [MarshalAs(UnmanagedType.Struct)] out object SynonymList);
}
[ComImport]
[Guid("6922CBD0-31C3-11D4-BF4F-00A0C9B465F6")]
[TypeLibType(4160)]
public interface ICOMUserProp
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetClassID([MarshalAs(UnmanagedType.BStr)] out string ClassID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void GetClassName([MarshalAs(UnmanagedType.BStr)] out string ClassName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void Store([MarshalAs(UnmanagedType.BStr)] out string data);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void Recall([In][MarshalAs(UnmanagedType.BStr)] string data);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void Copy([In][MarshalAs(UnmanagedType.IDispatch)] object prop);
}
[ComImport]
[TypeLibType(4160)]
[Guid("DB685C00-3085-11D6-B87E-000347A74660")]
public interface IPurePropEstimator
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void EstimatorInfo([In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Version, [In][Out] ref byte NeedPath, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Note);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void SetPath([In][MarshalAs(UnmanagedType.BStr)] string path, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void GetSupportedProps([In][Out] ref int nProp, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Props);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void CanDo([In][MarshalAs(UnmanagedType.BStr)] string prop, [In][Out] ref int nMethods, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Methods, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void EstUnknownProps([In][MarshalAs(UnmanagedType.IDispatch)] object pCompound, [In] int nSpecProps, [In][MarshalAs(UnmanagedType.Struct)] object SpecProps, [In][MarshalAs(UnmanagedType.Struct)] object SpecMethods, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void EstProp([In][MarshalAs(UnmanagedType.IDispatch)] object pCompound, [In][MarshalAs(UnmanagedType.BStr)] string prop, [In][MarshalAs(UnmanagedType.BStr)] string method, [In] byte Replace, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void IsReady([In][Out] ref int Status);
}
