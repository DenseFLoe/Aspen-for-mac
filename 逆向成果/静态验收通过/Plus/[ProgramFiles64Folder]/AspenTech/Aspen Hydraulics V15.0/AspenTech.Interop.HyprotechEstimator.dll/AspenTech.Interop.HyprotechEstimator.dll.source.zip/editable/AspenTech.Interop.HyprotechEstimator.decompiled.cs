using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: Guid("0e659e60-2a3a-11d6-b230-00d0b75ad1d3")]
[assembly: PrimaryInteropAssembly(1, 0)]
[assembly: ImportedFromTypeLib("HYPROTECHESTIMATORLib")]
[assembly: AssemblyVersion("1.0.0.0")]
namespace AspenTech.Interop.HyprotechEstimator;

[ComImport]
[ClassInterface((short)0)]
[Guid("0E659E72-2A3A-11D6-B230-00D0B75AD1D3")]
[TypeLibType(2)]
public class HyprotechEstimatorClass : IPurePropEstimator, HyprotechEstimator
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	extern void IPurePropEstimator.EstimatorInfo([In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Version, [In][Out] ref byte NeedPath, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Note);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	extern void IPurePropEstimator.SetPath([In][MarshalAs(UnmanagedType.BStr)] string Path, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern void IPurePropEstimator.GetSupportedProps([In][Out] ref int nProp, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Props);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	extern void IPurePropEstimator.CanDo([In][MarshalAs(UnmanagedType.BStr)] string prop, [In][Out] ref int nMethods, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Methods, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	extern void IPurePropEstimator.EstUnknownProps([In][MarshalAs(UnmanagedType.IDispatch)] object pCompound, [In] int nSpecProps, [In][MarshalAs(UnmanagedType.Struct)] object SpecProps, [In][MarshalAs(UnmanagedType.Struct)] object SpecMethods, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	extern void IPurePropEstimator.EstProp([In][MarshalAs(UnmanagedType.IDispatch)] object pCompound, [In][MarshalAs(UnmanagedType.BStr)] string prop, [In][MarshalAs(UnmanagedType.BStr)] string Method, [In] byte Replace, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	extern void IPurePropEstimator.IsReady([In][Out] ref int Status);
}
[ComImport]
[Guid("DB685C00-3085-11D6-B87E-000347A74660")]
[CoClass(typeof(HyprotechEstimatorClass))]
public interface HyprotechEstimator : IPurePropEstimator
{
}
[ComImport]
[TypeLibType(4160)]
[Guid("DB685C00-3085-11D6-B87E-000347A74660")]
public interface IPurePropEstimator
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void EstimatorInfo([In][Out][MarshalAs(UnmanagedType.BStr)] ref string Name, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Version, [In][Out] ref byte NeedPath, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string Note);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void SetPath([In][MarshalAs(UnmanagedType.BStr)] string Path, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void GetSupportedProps([In][Out] ref int nProp, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Props);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void CanDo([In][MarshalAs(UnmanagedType.BStr)] string prop, [In][Out] ref int nMethods, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object Methods, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void EstUnknownProps([In][MarshalAs(UnmanagedType.IDispatch)] object pCompound, [In] int nSpecProps, [In][MarshalAs(UnmanagedType.Struct)] object SpecProps, [In][MarshalAs(UnmanagedType.Struct)] object SpecMethods, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void EstProp([In][MarshalAs(UnmanagedType.IDispatch)] object pCompound, [In][MarshalAs(UnmanagedType.BStr)] string prop, [In][MarshalAs(UnmanagedType.BStr)] string Method, [In] byte Replace, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][Out] ref int Status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void IsReady([In][Out] ref int Status);
}
