using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("Aspen Hydraulics")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2024")]
[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("..\\..\\..\\packages\\AspenTech.StrongName.SNK.1.0.0\\content\\AspenTech.snk")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyFileVersion("41.0.0.99")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace GuidResources.DynamicSolver
{
	public static class GuidInfo
	{
		public const string DynamicSolver = "DCFD6117-EC0C-42EB-822A-148F5C06EA9B";

		public const string DynamicSolver_3phase = "97F50606-0EA2-4656-89ED-A2101F99F40A";

		public const string DynamicSolver_Compositional = "0C74949B-3545-4140-B001-79C6CE284A8E";

		public const string IDynamicSolver = "15965056-2AE6-4782-8E10-A6E5ED8FD9C3";

		public const string IDynamicSolver_Compositional = "B071DD82-DBB3-41CF-BCDD-5D5128B725F8";
	}
}
namespace GuidResources.AspenHydraulicsFramework
{
	public static class GuidInfo
	{
		public const string IHydraulicPhase = "47189B3A-9165-4016-AB46-C6D2E73F66EE";

		public const string HydraulicPhase = "7728ADF7-EED3-4776-BB8E-0897ABBF0BA6";

		public const string ILayerCollection = "7983536A-AA6C-4AA3-B987-60FDB4BD229E";

		public const string IInsulation = "38A16082-C53F-4775-9015-81862410AF7B";

		public const string IInsulationLayer = "B3A3E999-424C-43A0-BB84-B535AD22ADB3";

		public const string InsulationLayer = "AEF6497C-337F-463A-8B00-0E5610312CDC";

		public const string Insulation = "0C8320BF-97E9-42C4-888F-D09E3FF13831";

		public const string ExternalMediaType = "60A199B5-F16C-4099-A956-C258C6E90F07";

		public const string BasicMedia = "D02C8C02-81D4-4A57-9A7B-378E1F4E831A";

		public const string IExternalFluid = "66607EAF-84BD-492F-8E3E-9A5ABE402757";

		public const string ExternalFluid = "86A957E4-8A9C-48F2-9B17-47C05314E9F8";

		public const string IBuried = "F50B88CB-5261-42B9-952B-E35761304CA9";

		public const string Buried = "943C0570-0F26-4722-AFA5-D043C2AE7565";

		public const string IExternalMedia = "4CB53584-11D4-49FB-8AC8-46ED86601769";

		public const string ExternalMedia = "E90A7E3E-7D2B-45E8-B92B-70188AC5E5C9";

		public const string PigSortEnum = "5007E873-7EAF-422E-84EA-FD9FF7D30763";

		public const string CPig = "F15ED6CF-B159-4C7E-AC04-8F26565FCEDF";

		public const string IPig = "A321A2F2-22A6-4202-9AD8-C0F0A8D8162C";

		public const string IPigging = "C4671649-BED6-470F-A397-C1EA665EF1F3";

		public const string SolverMessageTypeEnum = "A1E5F570-B97E-444D-A70C-6FA45D57ACDA";

		public const string ICOMDelegateHelper = "F333C49D-61A2-4B5D-ADA3-DA275AD022C3";

		public const string ISolver = "B9E3CB4A-B135-4305-9D1E-818EA64AE65B";

		public const string INotifible = "E2AECB53-BF2E-4D1E-9DBC-078AF126A369";

		public const string CSolver = "5A581105-3322-4105-8EDA-BC9FB52B324B";

		public const string ISolverSS = "5F34DC14-D5FA-46A0-9685-C98D94600443";

		public const string CSolverSS = "005F4589-9B66-4CEC-AABD-853C7A48D54A";

		public const string ISolverDynamic = "9EE73088-9F69-4AD0-9D2E-E68007F51442";

		public const string CSolverDynamic = "0CEBBE6F-C090-4E66-BAA8-51CDF271746F";

		public const string IUnitOpSolver = "C96F772B-92E2-41CD-9BFF-CAB02033AAAB";

		public const string UnitOpSolver = "E1957AEC-77C0-4AE6-9B58-67A2B26ACC15";

		public const string ISolverCollectionClass = "14C8BF94-59C0-4171-9968-ACED34320C07";

		public const string SolverCollectionClass = "11AF7665-0FE2-4560-85E6-2D23046A1759";

		public const string IUnitOpCollection = "9E1BFCBA-3677-4E18-BC64-C178E412A678";

		public const string UnitOpCollection = "5B9CD459-65CF-4BB9-9AB6-873212C5DE98";

		public const string INetwork = "7740EE29-BAB1-4199-B83D-6AAEE8EDE2DC";

		public const string IErase = "06DDAD39-9AD3-40B3-93DB-D0CC7D289E76";

		public const string IHYSYSSecurityInterface = "5348E9CC-E303-4A6B-9B94-7BE2F8966FFF";

		public const string IHYSYSHydraulicsSecurityInterface = "E90C971D-98C3-4FD3-B44B-B3155B838079";

		public const string Network = "38091D85-86C1-4D5A-BCDD-366D09370105";

		public const string IHydraulicFlowStream = "D80AE29E-D493-4F6D-AD90-BCE9D8448C99";

		public const string HydraulicFlowStream = "010CF799-D346-477F-BE66-3F9B48B95114";

		public const string IPointValue = "289614FE-DA26-4ABD-BFB2-D7CC97C31339";

		public const string PointValue = "9374989D-39E9-4D06-A2C0-E5BB5BDAF6F1";

		public const string IPort = "990AF79E-9829-4E59-B5FB-10123D80BE1A";

		public const string Port = "E7132374-813B-40DF-8A04-F70441A96090";

		public const string IPortCollectionSet = "066E9EC8-16B4-454A-B580-3572C76C02F1";

		public const string IPortCollection = "7BDEBEC5-8D2C-4D57-A1ED-B19022EEFCD6";

		public const string PortCollection = "75AF68AE-E3AC-4FA8-9862-6B0B19348958";

		public const string PortDirectionEnum = "D69911E2-1351-4668-8941-ADEA32514D80";

		public const string PortInOutEnum = "D46C3A3B-CD29-4A26-8E5D-665492A31ED8";

		public const string TypeUnitOp = "B7D44848-F63A-4F04-AF87-3C330BED9CCB";

		public const string TeeFlowDirection = "BAFD89EB-B817-4DFC-A740-99BC4DD3B20B";

		public const string BleedPressureDrop = "9B2C2C3D-302B-43B3-BDCA-35A691052914";

		public const string IUnitOp = "F5C11EB6-2122-4512-AFA7-6FB5E7ED83E2";

		public const string UnitOp = "20F21103-2CF2-423D-938E-702ADF1B29E8";

		public const string IPipeSegment = "F75F53F1-8320-4DE1-A8A0-25566082A1E5";

		public const string SegmentAttrib = "2220FE22-7CE3-4518-A230-6C4F9AD6EA55";

		public const string IMultiSegPipe = "D01900DB-D33C-4DAC-BF3F-6C7E6625CB5B";

		public const string IFaceFitting = "0144B5D6-86B1-4997-9FD8-A66D0DB5E043";

		public const string ISwage = "F2B79EC1-BC54-4A49-A0F0-B5CC9F85C0DF";

		public const string IOrifice = "EF0B07E3-9BAE-4E95-9F50-69C8F92E7D4C";

		public const string IBend = "447FEC3A-FEDD-4C6C-8AE6-559A9F10E967";

		public const string IBleed = "C110814C-5034-45BF-BC66-A72821157630";

		public const string ISeparator = "4367A31C-CBB1-4B91-B7FD-78B9F100434B";

		public const string IFlareTip = "5D2F18A2-634C-4D16-A8A7-507715190F83";

		public const string ISource = "775D5F36-ACBD-4A7F-B08F-53F8F96B4FDF";

		public const string IControlValve = "F554B950-D1EB-4544-9DAE-1AA7263D8ACE";

		public const string IReliefValve = "8007B702-17C0-497E-81D1-15A1BF9E5621";

		public const string IPump = "D3393459-D08E-4F46-A71C-C4A03841CCE8";

		public const string ICompressor = "9B77BE8F-70DE-470F-8636-40C3ACB36A1F";

		public const string IPointValueSet = "3BC7F0C0-8EDC-4A8C-A626-78561B1D4AB3";

		public const string IPointValueGet = "6818C1E9-6104-4585-B544-ED790F94C3B9";

		public const string Swage = "5107112C-85D9-4C5C-8E3A-581A45957463";

		public const string PipeSegment = "C5A58348-7A4B-4C1B-9181-F9E89079E0A5";

		public const string MultiSegPipe = "39312963-D719-4357-BB49-9A9C399E3247";

		public const string IValve = "2BB92D3B-5F0B-4D76-BE76-34A70541EAC3";

		public const string Valve = "A28812EB-82A1-460C-B639-ADD1A0BF8E86";

		public const string IT_Junction = "8FABBD69-DCA4-4772-B922-059EA2F72597";

		public const string T_Junction = "7854B1C9-7AEB-4131-98CD-D8F1C0F4131E";

		public const string Orifice = "14EE6EEB-426A-4412-A570-A0105EE8C3A3";

		public const string Bend = "13750156-D75C-4BC3-9151-7046A1A7B3F3";

		public const string Bleed = "951F8DD7-6A3F-41EA-8D80-6BE01F5364A2";

		public const string Separator = "F0977A0F-6AC3-4448-91C8-592DD2A78E91";

		public const string FlareTip = "C3AE3A61-C7B9-4BEC-A9F1-482A72D4D917";

		public const string Source = "3B9C0BA2-6DCE-49DF-AD6A-EB8C23A3A1F9";

		public const string ControlValve = "6A7E3772-3472-43F8-93F1-373A26B12A14";

		public const string ReliefValve = "E608FE40-E518-4988-A92E-DA1FCCF11301";

		public const string Pump = "B649E446-A7E2-4A84-B8C1-1F0A1CBF0C5B";

		public const string Compressor = "63503C34-66B2-4F6D-8E5C-C09161B064A9";
	}
}
namespace GuidResources.SSSolver
{
	public static class GuidInfo
	{
		public const string ISSNetworkSolver = "34601972-4ABC-4657-A5D8-830533437DD7";

		public const string SSNetworkSolver = "5E3CC19D-0395-4F9E-8C19-995289D9B411";
	}
}
namespace GuidResources.Data
{
	public static class GuidInfo
	{
		public const string IBooleanProperty = "7B0E693F-3B54-421C-BD7F-7EAE9C6868F1";

		public const string BooleanProperty = "A39A40A3-857C-4069-B41F-C50B413930B2";

		public const string PropertyType = "F443D963-B601-4259-8F3B-6D8DD5E0509F";

		public const string PropertyCategory = "DBB4682E-EE42-48EA-9704-936B1AC9529D";

		public const string ValueState = "EAE58482-2B68-4571-A802-C9430FF22141";

		public const string OutOfBoundsException = "FA563123-6A8B-45FA-8727-371336399E32";

		public const string IEnumProperty = "A5E11058-5AA6-4D69-B191-7C859B345526";

		public const string EnumProperty = "54111C33-9BC8-44FD-996D-9495DB7B122B";

		public const string EnumValues = "015ABCEC-792F-4C68-A097-08E183A44714";

		public const string IIntegerProperty = "E762328F-D571-4CBD-BE89-F4B7392D0643";

		public const string IntegerProperty = "56EBE0D6-63A9-4A85-B60C-EF462A0BF9C6";

		public const string IProperties = "D7E0414C-0615-4DAE-AB0C-385E74E19B72";

		public const string Properties = "82DF7755-D6E4-4E18-977B-82FFF96DB0BC";

		public const string PropertyEnumerator = "E019C197-6918-4348-9B5B-AE52DD6AC252";

		public const string IProperty = "D685EA21-7CCC-4D77-B381-24F4E46AA422";

		public const string ValueChangeHandler = "06E7852C-4510-4B05-8558-5832FB835B26";

		public const string ErrorHandler = "D6DABAE7-C88C-4D00-948D-263C3B05AF8D";

		public const string Property = "316EBF5B-75B9-4718-BB9C-814C0B294569";

		public const string IRealProperty = "8E9CF26A-55E7-4F10-BD32-2F9A3C9E114B";

		public const string RealProperty = "31FBB393-DE7C-4199-AE45-1D7F34CF988C";

		public const string IStringProperty = "A16A9D4D-F8BD-4816-8EA2-D1B754BB03F4";

		public const string StringProperty = "C6DEA428-1A19-4C82-AB6D-44D57A2676BC";
	}
}
namespace GuidResources.NetworkPlugin
{
	public static class GuidInfo
	{
		public const string INetworkSolverSupport = "18556D74-7913-4A80-B016-FC4EA30CEFD8";

		public const string NetworkSolverSupport = "D928D4A5-F854-4629-B41A-0B929E0AA943";
	}
}
namespace GuidResources.PluginsSupport
{
	public static class GuidInfo
	{
		public const string IPlugin = "44E311B2-5562-4F5F-BD54-59A85A03716C";

		public const string Plugin = "2CAAB725-1ACE-4EE0-9522-C1EC6F3A0E9A";

		public const string IPluginManager = "0A97A37B-D766-4578-A90A-7E725FCF4AB9";

		public const string PluginManager = "F447C52F-30E8-473F-BEAE-FA92E2E006CD";

		public const string IPlugins = "40733608-90A1-407D-94FB-6BD45C0A48F5";

		public const string Plugins = "103BC927-893D-4720-ADEE-3FA1FD07AAB3";

		public const string PluginEnumerator = "7C55586B-A25E-4DBE-B3E6-43E035BA1035";
	}
}
namespace AHResources
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	public class Resources
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		internal Resources()
		{
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static ResourceManager ResourceManager
		{
			get
			{
				if (resourceMan == null)
				{
					resourceMan = new ResourceManager("AHResources.Resources", typeof(Resources).Assembly);
				}
				return resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static CultureInfo Culture
		{
			get
			{
				return resourceCulture;
			}
			set
			{
				resourceCulture = value;
			}
		}

		public static string AbortedByUser => ResourceManager.GetString("AbortedByUser", resourceCulture);

		public static string AccelerationalPressureDrop => ResourceManager.GetString("AccelerationalPressureDrop", resourceCulture);

		public static string AccelerationPressureDrop => ResourceManager.GetString("AccelerationPressureDrop", resourceCulture);

		public static string ActiveTxt => ResourceManager.GetString("ActiveTxt", resourceCulture);

		public static string AdiabaticEfficiency => ResourceManager.GetString("AdiabaticEfficiency", resourceCulture);

		public static string AdiabaticGas => ResourceManager.GetString("AdiabaticGas", resourceCulture);

		public static string AdiabaticTxt => ResourceManager.GetString("AdiabaticTxt", resourceCulture);

		public static string AdvectionOnly => ResourceManager.GetString("AdvectionOnly", resourceCulture);

		public static string AGAHeadOption => ResourceManager.GetString("AGAHeadOption", resourceCulture);

		public static string AGFMethod => ResourceManager.GetString("AGFMethod", resourceCulture);

		public static string AllPortsSet => ResourceManager.GetString("AllPortsSet", resourceCulture);

		public static string AlwaysStratified => ResourceManager.GetString("AlwaysStratified", resourceCulture);

		public static string Angle0to180 => ResourceManager.GetString("Angle0to180", resourceCulture);

		public static string Angle0to180Swage => ResourceManager.GetString("Angle0to180Swage", resourceCulture);

		public static string AngleAbove180Warning => ResourceManager.GetString("AngleAbove180Warning", resourceCulture);

		public static string AngleAbove180WarningB => ResourceManager.GetString("AngleAbove180WarningB", resourceCulture);

		public static string AngleTxt => ResourceManager.GetString("AngleTxt", resourceCulture);

		public static string AreaRatioSqaured => ResourceManager.GetString("AreaRatioSqaured", resourceCulture);

		public static string ArrayDimDifferent => ResourceManager.GetString("ArrayDimDifferent", resourceCulture);

		public static string AttribNotSupportedBoolean => ResourceManager.GetString("AttribNotSupportedBoolean", resourceCulture);

		public static string AttribNotSupportedInteger => ResourceManager.GetString("AttribNotSupportedInteger", resourceCulture);

		public static string AttribNotSupportedReal => ResourceManager.GetString("AttribNotSupportedReal", resourceCulture);

		public static string AttribNotSupportedString => ResourceManager.GetString("AttribNotSupportedString", resourceCulture);

		public static string AutomaticRecoveryIncreasePeriod => ResourceManager.GetString("AutomaticRecoveryIncreasePeriod", resourceCulture);

		public static string AutoRecoveryDecreaseFactor => ResourceManager.GetString("AutoRecoveryDecreaseFactor", resourceCulture);

		public static string AutoRecoveryIncreaseFactor => ResourceManager.GetString("AutoRecoveryIncreaseFactor", resourceCulture);

		public static string AutoRecoverySnapshotInterval => ResourceManager.GetString("AutoRecoverySnapshotInterval", resourceCulture);

		public static string BadNetworkLinkage => ResourceManager.GetString("BadNetworkLinkage", resourceCulture);

		public static string BadSolution => ResourceManager.GetString("BadSolution", resourceCulture);

		public static string BeggsBrill1979 => ResourceManager.GetString("BeggsBrill1979", resourceCulture);

		public static string BeggsBrillInvalidHoldup => ResourceManager.GetString("BeggsBrillInvalidHoldup", resourceCulture);

		public static string BeggsBrillNoFlowRegime => ResourceManager.GetString("BeggsBrillNoFlowRegime", resourceCulture);

		public static string BeggsBrillPGInvalidRe => ResourceManager.GetString("BeggsBrillPGInvalidRe", resourceCulture);

		public static string BeggsBrillPgNegativeHoldup => ResourceManager.GetString("BeggsBrillPgNegativeHoldup", resourceCulture);

		public static string BendAngle90MoreThan1Cut => ResourceManager.GetString("BendAngle90MoreThan1Cut", resourceCulture);

		public static string BendType => ResourceManager.GetString("BendType", resourceCulture);

		public static string BleedNotSupportedDyn => ResourceManager.GetString("BleedNotSupportedDyn", resourceCulture);

		public static string BlindAngle => ResourceManager.GetString("BlindAngle", resourceCulture);

		public static string BlindAngleNotBetween5And45 => ResourceManager.GetString("BlindAngleNotBetween5And45", resourceCulture);

		public static string BlindAngleNotBetween5And45B => ResourceManager.GetString("BlindAngleNotBetween5And45B", resourceCulture);

		public static string BOMassBalEqnFail => ResourceManager.GetString("BOMassBalEqnFail", resourceCulture);

		public static string BothPortsNotSetAbort => ResourceManager.GetString("BothPortsNotSetAbort", resourceCulture);

		public static string BothPortsUnknown => ResourceManager.GetString("BothPortsUnknown", resourceCulture);

		public static string BoundaryMassFlow => ResourceManager.GetString("BoundaryMassFlow", resourceCulture);

		public static string BoundaryMW => ResourceManager.GetString("BoundaryMW", resourceCulture);

		public static string BoundaryPortDirectionMismatch => ResourceManager.GetString("BoundaryPortDirectionMismatch", resourceCulture);

		public static string BoundaryPressure => ResourceManager.GetString("BoundaryPressure", resourceCulture);

		public static string BrinkmanTxt => ResourceManager.GetString("BrinkmanTxt", resourceCulture);

		public static string BuildMoleBalEqnFail => ResourceManager.GetString("BuildMoleBalEqnFail", resourceCulture);

		public static string BuildPartialFlowEqnFail => ResourceManager.GetString("BuildPartialFlowEqnFail", resourceCulture);

		public static string BuildPFEqnFail => ResourceManager.GetString("BuildPFEqnFail", resourceCulture);

		public static string CalcCloseButNotConverged => ResourceManager.GetString("CalcCloseButNotConverged", resourceCulture);

		public static string CalcDHDeadLoop => ResourceManager.GetString("CalcDHDeadLoop", resourceCulture);

		public static string CalcNotFullyConverged => ResourceManager.GetString("CalcNotFullyConverged", resourceCulture);

		public static string CalculatedKFactor => ResourceManager.GetString("CalculatedKFactor", resourceCulture);

		public static string CalculationMethod => ResourceManager.GetString("CalculationMethod", resourceCulture);

		public static string CannotCalculateKFactor3Cuts => ResourceManager.GetString("CannotCalculateKFactor3Cuts", resourceCulture);

		public static string CantFindPort => ResourceManager.GetString("CantFindPort", resourceCulture);

		public static string CantFindPThroat => ResourceManager.GetString("CantFindPThroat", resourceCulture);

		public static string CantGetSonicVelocity => ResourceManager.GetString("CantGetSonicVelocity", resourceCulture);

		public static string CantRemovePipeWall => ResourceManager.GetString("CantRemovePipeWall", resourceCulture);

		public static string CEstConstructorFail => ResourceManager.GetString("CEstConstructorFail", resourceCulture);

		public static string CEstVarConstructorFail => ResourceManager.GetString("CEstVarConstructorFail", resourceCulture);

		public static string CEstVarEqualFail => ResourceManager.GetString("CEstVarEqualFail", resourceCulture);

		public static string CEstVarEqualsMethodFail => ResourceManager.GetString("CEstVarEqualsMethodFail", resourceCulture);

		public static string CEstVarHashError => ResourceManager.GetString("CEstVarHashError", resourceCulture);

		public static string CEstVarNotEqualFail => ResourceManager.GetString("CEstVarNotEqualFail", resourceCulture);

		public static string CheckBoundaryComponentsFailed => ResourceManager.GetString("CheckBoundaryComponentsFailed", resourceCulture);

		public static string CheckChokedFlow => ResourceManager.GetString("CheckChokedFlow", resourceCulture);

		public static string CheckingMassFlow => ResourceManager.GetString("CheckingMassFlow", resourceCulture);

		public static string CheckingMassFlowFE => ResourceManager.GetString("CheckingMassFlowFE", resourceCulture);

		public static string CheckXMLFileFailed => ResourceManager.GetString("CheckXMLFileFailed", resourceCulture);

		public static string ChenMethod => ResourceManager.GetString("ChenMethod", resourceCulture);

		public static string ChokeCalcError => ResourceManager.GetString("ChokeCalcError", resourceCulture);

		public static string ChokeCalcFailed => ResourceManager.GetString("ChokeCalcFailed", resourceCulture);

		public static string ChokedFlowInletPSpec => ResourceManager.GetString("ChokedFlowInletPSpec", resourceCulture);

		public static string ChokedFlowTxt => ResourceManager.GetString("ChokedFlowTxt", resourceCulture);

		public static string ChokeFlow => ResourceManager.GetString("ChokeFlow", resourceCulture);

		public static string ChurchillBernsteinUsedInstead => ResourceManager.GetString("ChurchillBernsteinUsedInstead", resourceCulture);

		public static string ChurchillCorrFailed => ResourceManager.GetString("ChurchillCorrFailed", resourceCulture);

		public static string ChurchillFFFFailed => ResourceManager.GetString("ChurchillFFFFailed", resourceCulture);

		public static string ChurchillMethod => ResourceManager.GetString("ChurchillMethod", resourceCulture);

		public static string ColdStart => ResourceManager.GetString("ColdStart", resourceCulture);

		public static string ColdStartPPascal => ResourceManager.GetString("ColdStartPPascal", resourceCulture);

		public static string ColdStartTKelvin => ResourceManager.GetString("ColdStartTKelvin", resourceCulture);

		public static string CombinedPhase => ResourceManager.GetString("CombinedPhase", resourceCulture);

		public static string CompareObjectsMustBeType => ResourceManager.GetString("CompareObjectsMustBeType", resourceCulture);

		public static string CompositionalCompositionCriteria => ResourceManager.GetString("CompositionalCompositionCriteria", resourceCulture);

		public static string CompositionalModeOption => ResourceManager.GetString("CompositionalModeOption", resourceCulture);

		public static string CompositionalPressureCriteria => ResourceManager.GetString("CompositionalPressureCriteria", resourceCulture);

		public static string CompositionalTemperatureCriteria => ResourceManager.GetString("CompositionalTemperatureCriteria", resourceCulture);

		public static string CompositionSolver => ResourceManager.GetString("CompositionSolver", resourceCulture);

		public static string CompoundsEmpty => ResourceManager.GetString("CompoundsEmpty", resourceCulture);

		public static string CompressibleTransition => ResourceManager.GetString("CompressibleTransition", resourceCulture);

		public static string ConductivityTxt => ResourceManager.GetString("ConductivityTxt", resourceCulture);

		public static string ConstantFriction => ResourceManager.GetString("ConstantFriction", resourceCulture);

		public static string ConstantTxt => ResourceManager.GetString("ConstantTxt", resourceCulture);

		public static string ContractionExpansion => ResourceManager.GetString("ContractionExpansion", resourceCulture);

		public static string ConvectiveAndTransient => ResourceManager.GetString("ConvectiveAndTransient", resourceCulture);

		public static string ConvectiveTxt => ResourceManager.GetString("ConvectiveTxt", resourceCulture);

		public static string CoolDown => ResourceManager.GetString("CoolDown", resourceCulture);

		public static string Crane2Phase => ResourceManager.GetString("Crane2Phase", resourceCulture);

		public static string CraneHomogeneous => ResourceManager.GetString("CraneHomogeneous", resourceCulture);

		public static string CranfieldTxt => ResourceManager.GetString("CranfieldTxt", resourceCulture);

		public static string CreateExpansion => ResourceManager.GetString("CreateExpansion", resourceCulture);

		public static string CreateExpansionFE => ResourceManager.GetString("CreateExpansionFE", resourceCulture);

		public static string CurrentUnitOp => ResourceManager.GetString("CurrentUnitOp", resourceCulture);

		public static string CylinderNotBuried => ResourceManager.GetString("CylinderNotBuried", resourceCulture);

		public static string CylinderNotFullyBuried => ResourceManager.GetString("CylinderNotFullyBuried", resourceCulture);

		public static string DarcyFullyTurbulent => ResourceManager.GetString("DarcyFullyTurbulent", resourceCulture);

		public static string DarcyMethod => ResourceManager.GetString("DarcyMethod", resourceCulture);

		public static string DataPropBuildFail => ResourceManager.GetString("DataPropBuildFail", resourceCulture);

		public static string DataPropertyBuildFailed => ResourceManager.GetString("DataPropertyBuildFailed", resourceCulture);

		public static string DefaultDiscToPipeRatio1 => ResourceManager.GetString("DefaultDiscToPipeRatio1", resourceCulture);

		public static string DefaultValueOutOfBoundsEnum => ResourceManager.GetString("DefaultValueOutOfBoundsEnum", resourceCulture);

		public static string DefaultValueTooHigh => ResourceManager.GetString("DefaultValueTooHigh", resourceCulture);

		public static string DefaultValueTooLow => ResourceManager.GetString("DefaultValueTooLow", resourceCulture);

		public static string DelayKEIterationsDescription => ResourceManager.GetString("DelayKEIterationsDescription", resourceCulture);

		public static string DeltaP => ResourceManager.GetString("DeltaP", resourceCulture);

		public static string DiameterTxt => ResourceManager.GetString("DiameterTxt", resourceCulture);

		public static string DifferentDiamCannotConnect => ResourceManager.GetString("DifferentDiamCannotConnect", resourceCulture);

		public static string DiscreteLiquidPhase => ResourceManager.GetString("DiscreteLiquidPhase", resourceCulture);

		public static string DiscretePhase => ResourceManager.GetString("DiscretePhase", resourceCulture);

		public static string DiscToPipeDiameterRatio => ResourceManager.GetString("DiscToPipeDiameterRatio", resourceCulture);

		public static string DiscToPipeRatioSetTo1 => ResourceManager.GetString("DiscToPipeRatioSetTo1", resourceCulture);

		public static string DissipationDuringHeatTransfer => ResourceManager.GetString("DissipationDuringHeatTransfer", resourceCulture);

		public static string DivideByZero => ResourceManager.GetString("DivideByZero", resourceCulture);

		public static string DoNotInclude => ResourceManager.GetString("DoNotInclude", resourceCulture);

		public static string DuklerMethod => ResourceManager.GetString("DuklerMethod", resourceCulture);

		public static string DunsRos => ResourceManager.GetString("DunsRos", resourceCulture);

		public static string DynamicInit => ResourceManager.GetString("DynamicInit", resourceCulture);

		public static string DynLicenseValidationFailed => ResourceManager.GetString("DynLicenseValidationFailed", resourceCulture);

		public static string DynSolver => ResourceManager.GetString("DynSolver", resourceCulture);

		public static string DynSolver3p => ResourceManager.GetString("DynSolver3p", resourceCulture);

		public static string EffGreaterThan100Err => ResourceManager.GetString("EffGreaterThan100Err", resourceCulture);

		public static string EffGreaterThan100ErrComp => ResourceManager.GetString("EffGreaterThan100ErrComp", resourceCulture);

		public static string EffGreaterThan100ErrPump => ResourceManager.GetString("EffGreaterThan100ErrPump", resourceCulture);

		public static string EfficiencyTxt => ResourceManager.GetString("EfficiencyTxt", resourceCulture);

		public static string EfficiencyType => ResourceManager.GetString("EfficiencyType", resourceCulture);

		public static string EnergyBalKE => ResourceManager.GetString("EnergyBalKE", resourceCulture);

		public static string EquilibriumRelaxation => ResourceManager.GetString("EquilibriumRelaxation", resourceCulture);

		public static string ErrorBuildingEqnFor => ResourceManager.GetString("ErrorBuildingEqnFor", resourceCulture);

		public static string ErrorBuildingMolarEqn => ResourceManager.GetString("ErrorBuildingMolarEqn", resourceCulture);

		public static string ErrorBuildingMoleBalEqn => ResourceManager.GetString("ErrorBuildingMoleBalEqn", resourceCulture);

		public static string ErrorBuildingMoleBalEqns => ResourceManager.GetString("ErrorBuildingMoleBalEqns", resourceCulture);

		public static string ErrorBuildingPFEqn => ResourceManager.GetString("ErrorBuildingPFEqn", resourceCulture);

		public static string ErrorCalcInletP => ResourceManager.GetString("ErrorCalcInletP", resourceCulture);

		public static string ErrorCalcOutletP => ResourceManager.GetString("ErrorCalcOutletP", resourceCulture);

		public static string ErrorCode => ResourceManager.GetString("ErrorCode", resourceCulture);

		public static string ErrorSettingUpInternalPorts => ResourceManager.GetString("ErrorSettingUpInternalPorts", resourceCulture);

		public static string ErrorSolvingBalFor => ResourceManager.GetString("ErrorSolvingBalFor", resourceCulture);

		public static string EstimatorEngFail => ResourceManager.GetString("EstimatorEngFail", resourceCulture);

		public static string EstimatorFail => ResourceManager.GetString("EstimatorFail", resourceCulture);

		public static string EstimatorFailed => ResourceManager.GetString("EstimatorFailed", resourceCulture);

		public static string EstimatorMoleBal => ResourceManager.GetString("EstimatorMoleBal", resourceCulture);

		public static string EstimatorPF => ResourceManager.GetString("EstimatorPF", resourceCulture);

		public static string ExternalPortsUndefined => ResourceManager.GetString("ExternalPortsUndefined", resourceCulture);

		public static string FailedLocalMin => ResourceManager.GetString("FailedLocalMin", resourceCulture);

		public static string FailedToAllocateGlobalStore => ResourceManager.GetString("FailedToAllocateGlobalStore", resourceCulture);

		public static string FailedToConverge => ResourceManager.GetString("FailedToConverge", resourceCulture);

		public static string FailedToCreateVars => ResourceManager.GetString("FailedToCreateVars", resourceCulture);

		public static string FailedToDeallocateGlobalStore1 => ResourceManager.GetString("FailedToDeallocateGlobalStore1", resourceCulture);

		public static string FailedToDeallocateGlobalStore2 => ResourceManager.GetString("FailedToDeallocateGlobalStore2", resourceCulture);

		public static string FailedToGetVar => ResourceManager.GetString("FailedToGetVar", resourceCulture);

		public static string FailedToSolveConvNet => ResourceManager.GetString("FailedToSolveConvNet", resourceCulture);

		public static string FailedToSolveInIterationLimit => ResourceManager.GetString("FailedToSolveInIterationLimit", resourceCulture);

		public static string FailedToSolveLoopedNet => ResourceManager.GetString("FailedToSolveLoopedNet", resourceCulture);

		public static string FastNewton => ResourceManager.GetString("FastNewton", resourceCulture);

		public static string FatalErrorChoked => ResourceManager.GetString("FatalErrorChoked", resourceCulture);

		public static string FFStatic => ResourceManager.GetString("FFStatic", resourceCulture);

		public static string FFTotal => ResourceManager.GetString("FFTotal", resourceCulture);

		public static string FilePathEmpty => ResourceManager.GetString("FilePathEmpty", resourceCulture);

		public static string FinishedTxt => ResourceManager.GetString("FinishedTxt", resourceCulture);

		public static string FittingBallValve => ResourceManager.GetString("FittingBallValve", resourceCulture);

		public static string FittingBend => ResourceManager.GetString("FittingBend", resourceCulture);

		public static string FittingBordaInlet => ResourceManager.GetString("FittingBordaInlet", resourceCulture);

		public static string FittingButterflyValve => ResourceManager.GetString("FittingButterflyValve", resourceCulture);

		public static string FittingCircularBend => ResourceManager.GetString("FittingCircularBend", resourceCulture);

		public static string FittingCompressor => ResourceManager.GetString("FittingCompressor", resourceCulture);

		public static string FittingContraction => ResourceManager.GetString("FittingContraction", resourceCulture);

		public static string FittingEnlargement => ResourceManager.GetString("FittingEnlargement", resourceCulture);

		public static string FittingFlushInlet => ResourceManager.GetString("FittingFlushInlet", resourceCulture);

		public static string FittingGateValve => ResourceManager.GetString("FittingGateValve", resourceCulture);

		public static string FittingGlobeValve => ResourceManager.GetString("FittingGlobeValve", resourceCulture);

		public static string FittingGradualContraction => ResourceManager.GetString("FittingGradualContraction", resourceCulture);

		public static string FittingGradualEnlargement => ResourceManager.GetString("FittingGradualEnlargement", resourceCulture);

		public static string FittingMitreBend => ResourceManager.GetString("FittingMitreBend", resourceCulture);

		public static string FittingMustBeConnectedToPipes => ResourceManager.GetString("FittingMustBeConnectedToPipes", resourceCulture);

		public static string FittingNozzle => ResourceManager.GetString("FittingNozzle", resourceCulture);

		public static string FittingOrifice => ResourceManager.GetString("FittingOrifice", resourceCulture);

		public static string FittingOutlet => ResourceManager.GetString("FittingOutlet", resourceCulture);

		public static string FittingPipeCell => ResourceManager.GetString("FittingPipeCell", resourceCulture);

		public static string FittingPipeFitting => ResourceManager.GetString("FittingPipeFitting", resourceCulture);

		public static string FittingPort => ResourceManager.GetString("FittingPort", resourceCulture);

		public static string FittingPump => ResourceManager.GetString("FittingPump", resourceCulture);

		public static string FittingSuddenContraction => ResourceManager.GetString("FittingSuddenContraction", resourceCulture);

		public static string FittingSuddenEnlargement => ResourceManager.GetString("FittingSuddenEnlargement", resourceCulture);

		public static string FittingSwage => ResourceManager.GetString("FittingSwage", resourceCulture);

		public static string FittingTeeJunction => ResourceManager.GetString("FittingTeeJunction", resourceCulture);

		public static string FittingThrottleElement => ResourceManager.GetString("FittingThrottleElement", resourceCulture);

		public static string FittingValve => ResourceManager.GetString("FittingValve", resourceCulture);

		public static string FittingWithInvalidNumberOfPorts => ResourceManager.GetString("FittingWithInvalidNumberOfPorts", resourceCulture);

		public static string FixedHoldUp => ResourceManager.GetString("FixedHoldUp", resourceCulture);

		public static string FlowChoked => ResourceManager.GetString("FlowChoked", resourceCulture);

		public static string FlowChokedAtDownstreamUpstreamEstimated => ResourceManager.GetString("FlowChokedAtDownstreamUpstreamEstimated", resourceCulture);

		public static string FlowChokedOrNot => ResourceManager.GetString("FlowChokedOrNot", resourceCulture);

		public static string FlowChokedUpstreamEstimated => ResourceManager.GetString("FlowChokedUpstreamEstimated", resourceCulture);

		public static string FlowEstByNLSolver => ResourceManager.GetString("FlowEstByNLSolver", resourceCulture);

		public static string FlowPortMissingComposition => ResourceManager.GetString("FlowPortMissingComposition", resourceCulture);

		public static string FlowPortMissingFlowSpec => ResourceManager.GetString("FlowPortMissingFlowSpec", resourceCulture);

		public static string FlowPortMissingThermoSpec => ResourceManager.GetString("FlowPortMissingThermoSpec", resourceCulture);

		public static string FlowSpecOnlyAllowedAtBoundary => ResourceManager.GetString("FlowSpecOnlyAllowedAtBoundary", resourceCulture);

		public static string FluidAlreadyCreated => ResourceManager.GetString("FluidAlreadyCreated", resourceCulture);

		public static string FrictionalPressureDrop => ResourceManager.GetString("FrictionalPressureDrop", resourceCulture);

		public static string FrictionFactor => ResourceManager.GetString("FrictionFactor", resourceCulture);

		public static string FrictionFactorMethod => ResourceManager.GetString("FrictionFactorMethod", resourceCulture);

		public static string FullyStratified => ResourceManager.GetString("FullyStratified", resourceCulture);

		public static string FunctionEvaluation => ResourceManager.GetString("FunctionEvaluation", resourceCulture);

		public static string FunctionNotImplemented => ResourceManager.GetString("FunctionNotImplemented", resourceCulture);

		public static string GAMMethod => ResourceManager.GetString("GAMMethod", resourceCulture);

		public static string GardelTxt => ResourceManager.GetString("GardelTxt", resourceCulture);

		public static string GasOilFriction => ResourceManager.GetString("GasOilFriction", resourceCulture);

		public static string GlobalStoreIndexOutOfBounds => ResourceManager.GetString("GlobalStoreIndexOutOfBounds", resourceCulture);

		public static string GravitationalPressureDrop => ResourceManager.GetString("GravitationalPressureDrop", resourceCulture);

		public static string HagedornBrown => ResourceManager.GetString("HagedornBrown", resourceCulture);

		public static string HeatTransfer => ResourceManager.GetString("HeatTransfer", resourceCulture);

		public static string HillWood => ResourceManager.GetString("HillWood", resourceCulture);

		public static string HomogeneousEquilibrium => ResourceManager.GetString("HomogeneousEquilibrium", resourceCulture);

		public static string HomogeneousFrozen => ResourceManager.GetString("HomogeneousFrozen", resourceCulture);

		public static string HomogeneousFrozenSplit => ResourceManager.GetString("HomogeneousFrozenSplit", resourceCulture);

		public static string HomogeneousLiquidPhase => ResourceManager.GetString("HomogeneousLiquidPhase", resourceCulture);

		public static string HomogeneousPGInvalidRe => ResourceManager.GetString("HomogeneousPGInvalidRe", resourceCulture);

		public static string HomogeneousTxt => ResourceManager.GetString("HomogeneousTxt", resourceCulture);

		public static string HTFSMethod => ResourceManager.GetString("HTFSMethod", resourceCulture);

		public static string IDNotPresent => ResourceManager.GetString("IDNotPresent", resourceCulture);

		public static string IgnoreDownhillRecovery => ResourceManager.GetString("IgnoreDownhillRecovery", resourceCulture);

		public static string IgnoreTxt => ResourceManager.GetString("IgnoreTxt", resourceCulture);

		public static string ImperialCollege => ResourceManager.GetString("ImperialCollege", resourceCulture);

		public static string InclinedAngleOutside90Deg => ResourceManager.GetString("InclinedAngleOutside90Deg", resourceCulture);

		public static string IncludeForAll => ResourceManager.GetString("IncludeForAll", resourceCulture);

		public static string IncludeForAllExceptSep => ResourceManager.GetString("IncludeForAllExceptSep", resourceCulture);

		public static string IncludeTxt => ResourceManager.GetString("IncludeTxt", resourceCulture);

		public static string IncompleteConnectivity => ResourceManager.GetString("IncompleteConnectivity", resourceCulture);

		public static string InconsistentEnergy => ResourceManager.GetString("InconsistentEnergy", resourceCulture);

		public static string InconsistentMassFlow => ResourceManager.GetString("InconsistentMassFlow", resourceCulture);

		public static string IncorrectGeometryAbort => ResourceManager.GetString("IncorrectGeometryAbort", resourceCulture);

		public static string IncorrectObjectTypeForArgument => ResourceManager.GetString("IncorrectObjectTypeForArgument", resourceCulture);

		public static string IndeterminiteFlowDirection => ResourceManager.GetString("IndeterminiteFlowDirection", resourceCulture);

		public static string IndexLargerThanCount => ResourceManager.GetString("IndexLargerThanCount", resourceCulture);

		public static string IndexLargerThanNumPorts => ResourceManager.GetString("IndexLargerThanNumPorts", resourceCulture);

		public static string IndexMustBe0or1 => ResourceManager.GetString("IndexMustBe0or1", resourceCulture);

		public static string IndexOutOfBounds => ResourceManager.GetString("IndexOutOfBounds", resourceCulture);

		public static string InhibitedTxt => ResourceManager.GetString("InhibitedTxt", resourceCulture);

		public static string InitGasHoldup => ResourceManager.GetString("InitGasHoldup", resourceCulture);

		public static string InitialEstimateMultiplier => ResourceManager.GetString("InitialEstimateMultiplier", resourceCulture);

		public static string InitialEstimateMultiplierDescription => ResourceManager.GetString("InitialEstimateMultiplierDescription", resourceCulture);

		public static string InitialLiquidHeightTooLarge => ResourceManager.GetString("InitialLiquidHeightTooLarge", resourceCulture);

		public static string InletPCalcFail => ResourceManager.GetString("InletPCalcFail", resourceCulture);

		public static string InletPipeCalcMethod => ResourceManager.GetString("InletPipeCalcMethod", resourceCulture);

		public static string InletPipeFFMethod => ResourceManager.GetString("InletPipeFFMethod", resourceCulture);

		public static string InnerDampingFactor => ResourceManager.GetString("InnerDampingFactor", resourceCulture);

		public static string InnerDiam => ResourceManager.GetString("InnerDiam", resourceCulture);

		public static string InnerDutyTol => ResourceManager.GetString("InnerDutyTol", resourceCulture);

		public static string InnerEError => ResourceManager.GetString("InnerEError", resourceCulture);

		public static string InnerIter => ResourceManager.GetString("InnerIter", resourceCulture);

		public static string InnerLoopFail => ResourceManager.GetString("InnerLoopFail", resourceCulture);

		public static string InnerPError => ResourceManager.GetString("InnerPError", resourceCulture);

		public static string InnerPTol => ResourceManager.GetString("InnerPTol", resourceCulture);

		public static string InOrOutDiamNeeded => ResourceManager.GetString("InOrOutDiamNeeded", resourceCulture);

		public static string InOrOutDiamNeededContraction => ResourceManager.GetString("InOrOutDiamNeededContraction", resourceCulture);

		public static string InOrOutDiamNeededEnlargement => ResourceManager.GetString("InOrOutDiamNeededEnlargement", resourceCulture);

		public static string InOrOutDiamNeededThrottle => ResourceManager.GetString("InOrOutDiamNeededThrottle", resourceCulture);

		public static string InputDPTooLarge => ResourceManager.GetString("InputDPTooLarge", resourceCulture);

		public static string InputDPTooLargeFE => ResourceManager.GetString("InputDPTooLargeFE", resourceCulture);

		public static string InsensitiveDensity => ResourceManager.GetString("InsensitiveDensity", resourceCulture);

		public static string InsufficientBCs => ResourceManager.GetString("InsufficientBCs", resourceCulture);

		public static string InsufficientInletOutletPorts => ResourceManager.GetString("InsufficientInletOutletPorts", resourceCulture);

		public static string InsulationAlreadyCreated => ResourceManager.GetString("InsulationAlreadyCreated", resourceCulture);

		public static string InsulationAlreadySetUp => ResourceManager.GetString("InsulationAlreadySetUp", resourceCulture);

		public static string IntegrationTimeStep => ResourceManager.GetString("IntegrationTimeStep", resourceCulture);

		public static string InterfacialVaporFrictionFactorRatio => ResourceManager.GetString("InterfacialVaporFrictionFactorRatio", resourceCulture);

		public static string InvalidBoundaryFlow => ResourceManager.GetString("InvalidBoundaryFlow", resourceCulture);

		public static string InvalidBoundaryPressure => ResourceManager.GetString("InvalidBoundaryPressure", resourceCulture);

		public static string InvalidCallToSetSolver1 => ResourceManager.GetString("InvalidCallToSetSolver1", resourceCulture);

		public static string InvalidCallToSetSolver2 => ResourceManager.GetString("InvalidCallToSetSolver2", resourceCulture);

		public static string InvalidDiscToPipeRatio => ResourceManager.GetString("InvalidDiscToPipeRatio", resourceCulture);

		public static string InvalidLossCoeff => ResourceManager.GetString("InvalidLossCoeff", resourceCulture);

		public static string InvalidNetworkID => ResourceManager.GetString("InvalidNetworkID", resourceCulture);

		public static string InvalidNumOutPorts => ResourceManager.GetString("InvalidNumOutPorts", resourceCulture);

		public static string InvalidNumPorts => ResourceManager.GetString("InvalidNumPorts", resourceCulture);

		public static string InvalidSolverClass => ResourceManager.GetString("InvalidSolverClass", resourceCulture);

		public static string InvalidTol => ResourceManager.GetString("InvalidTol", resourceCulture);

		public static string InvalidTolTooLarge => ResourceManager.GetString("InvalidTolTooLarge", resourceCulture);

		public static string InvalidTolTooSmall => ResourceManager.GetString("InvalidTolTooSmall", resourceCulture);

		public static string InvalidVarIdx => ResourceManager.GetString("InvalidVarIdx", resourceCulture);

		public static string IsNull => ResourceManager.GetString("IsNull", resourceCulture);

		public static string IsothermalGas => ResourceManager.GetString("IsothermalGas", resourceCulture);

		public static string IsSolvableFailed => ResourceManager.GetString("IsSolvableFailed", resourceCulture);

		public static string IterateUnitOpsOnIncreasingErrorDescription => ResourceManager.GetString("IterateUnitOpsOnIncreasingErrorDescription", resourceCulture);

		public static string JacobianTxt => ResourceManager.GetString("JacobianTxt", resourceCulture);

		public static string LargestErrorUnitOp => ResourceManager.GetString("LargestErrorUnitOp", resourceCulture);

		public static string LevenbergMarquardt => ResourceManager.GetString("LevenbergMarquardt", resourceCulture);

		public static string LevenbergMarquardtCPR => ResourceManager.GetString("LevenbergMarquardtCPR", resourceCulture);

		public static string LinearTxt => ResourceManager.GetString("LinearTxt", resourceCulture);

		public static string LineSearch => ResourceManager.GetString("LineSearch", resourceCulture);

		public static string LineSearchRoundoffError => ResourceManager.GetString("LineSearchRoundoffError", resourceCulture);

		public static string LiquidModel => ResourceManager.GetString("LiquidModel", resourceCulture);

		public static string LockhartMartinelli => ResourceManager.GetString("LockhartMartinelli", resourceCulture);

		public static string LoggerAlreadySet => ResourceManager.GetString("LoggerAlreadySet", resourceCulture);

		public static string LowerBoundGTUpperBound => ResourceManager.GetString("LowerBoundGTUpperBound", resourceCulture);

		public static string MassBalError => ResourceManager.GetString("MassBalError", resourceCulture);

		public static string MassBalFail => ResourceManager.GetString("MassBalFail", resourceCulture);

		public static string MassBalFor => ResourceManager.GetString("MassBalFor", resourceCulture);

		public static string Max3Ports => ResourceManager.GetString("Max3Ports", resourceCulture);

		public static string MaxAutoRecoveryAttempts => ResourceManager.GetString("MaxAutoRecoveryAttempts", resourceCulture);

		public static string MaxInnerIter => ResourceManager.GetString("MaxInnerIter", resourceCulture);

		public static string MaxIter => ResourceManager.GetString("MaxIter", resourceCulture);

		public static string MaxJacStep => ResourceManager.GetString("MaxJacStep", resourceCulture);

		public static string MaxLiquidHoldup => ResourceManager.GetString("MaxLiquidHoldup", resourceCulture);

		public static string MaxOuterIter => ResourceManager.GetString("MaxOuterIter", resourceCulture);

		public static string MaxOuterLoopIter => ResourceManager.GetString("MaxOuterLoopIter", resourceCulture);

		public static string MethodCalledForBaseClass => ResourceManager.GetString("MethodCalledForBaseClass", resourceCulture);

		public static string MethodError => ResourceManager.GetString("MethodError", resourceCulture);

		public static string MethodFailed => ResourceManager.GetString("MethodFailed", resourceCulture);

		public static string MethodFailedWithException => ResourceManager.GetString("MethodFailedWithException", resourceCulture);

		public static string MethodFailure => ResourceManager.GetString("MethodFailure", resourceCulture);

		public static string MethodForObjectFailed => ResourceManager.GetString("MethodForObjectFailed", resourceCulture);

		public static string MillerAreaLimited => ResourceManager.GetString("MillerAreaLimited", resourceCulture);

		public static string MillerCharts => ResourceManager.GetString("MillerCharts", resourceCulture);

		public static string MillerExtrapolationMethod => ResourceManager.GetString("MillerExtrapolationMethod", resourceCulture);

		public static string MinJacStep => ResourceManager.GetString("MinJacStep", resourceCulture);

		public static string MinTimeStep => ResourceManager.GetString("MinTimeStep", resourceCulture);

		public static string MissingPSpec => ResourceManager.GetString("MissingPSpec", resourceCulture);

		public static string ModelAnalysisFail => ResourceManager.GetString("ModelAnalysisFail", resourceCulture);

		public static string ModelInitFail => ResourceManager.GetString("ModelInitFail", resourceCulture);

		public static string MolarFlowEquals => ResourceManager.GetString("MolarFlowEquals", resourceCulture);

		public static string MoleBalFor => ResourceManager.GetString("MoleBalFor", resourceCulture);

		public static string MoodyMethod => ResourceManager.GetString("MoodyMethod", resourceCulture);

		public static string MultiphaseStream => ResourceManager.GetString("MultiphaseStream", resourceCulture);

		public static string MultiplePressureFlowBCs => ResourceManager.GetString("MultiplePressureFlowBCs", resourceCulture);

		public static string MustBeGreaterThanZero => ResourceManager.GetString("MustBeGreaterThanZero", resourceCulture);

		public static string MustBeGreaterThanZero2 => ResourceManager.GetString("MustBeGreaterThanZero2", resourceCulture);

		public static string MustBeGreaterThanZero3 => ResourceManager.GetString("MustBeGreaterThanZero3", resourceCulture);

		public static string Need1In1Out => ResourceManager.GetString("Need1In1Out", resourceCulture);

		public static string Need1In1OutPort => ResourceManager.GetString("Need1In1OutPort", resourceCulture);

		public static string NeedDPAndFlowForSizing => ResourceManager.GetString("NeedDPAndFlowForSizing", resourceCulture);

		public static string NeedDPAndFlowForSizingFE => ResourceManager.GetString("NeedDPAndFlowForSizingFE", resourceCulture);

		public static string NeedsMoreInOutParams => ResourceManager.GetString("NeedsMoreInOutParams", resourceCulture);

		public static string NeedsOneSolvableUnitOp => ResourceManager.GetString("NeedsOneSolvableUnitOp", resourceCulture);

		public static string NeedsOneUnitOp => ResourceManager.GetString("NeedsOneUnitOp", resourceCulture);

		public static string NeedsRatioOrAngle => ResourceManager.GetString("NeedsRatioOrAngle", resourceCulture);

		public static string NegativeEffErr => ResourceManager.GetString("NegativeEffErr", resourceCulture);

		public static string NegativeEffErrComp => ResourceManager.GetString("NegativeEffErrComp", resourceCulture);

		public static string NegativeEffErrPump => ResourceManager.GetString("NegativeEffErrPump", resourceCulture);

		public static string NegativePRatioErr => ResourceManager.GetString("NegativePRatioErr", resourceCulture);

		public static string NegativePRatioErrComp => ResourceManager.GetString("NegativePRatioErrComp", resourceCulture);

		public static string NegativePRatioErrPump => ResourceManager.GetString("NegativePRatioErrPump", resourceCulture);

		public static string NegativePressure => ResourceManager.GetString("NegativePressure", resourceCulture);

		public static string NegativePressureContinueWithZeroDP => ResourceManager.GetString("NegativePressureContinueWithZeroDP", resourceCulture);

		public static string NegativeRadiusWarning => ResourceManager.GetString("NegativeRadiusWarning", resourceCulture);

		public static string NegativeRadiusWarningB => ResourceManager.GetString("NegativeRadiusWarningB", resourceCulture);

		public static string NetworkNeedsPressureConstraint => ResourceManager.GetString("NetworkNeedsPressureConstraint", resourceCulture);

		public static string NetworkSolution => ResourceManager.GetString("NetworkSolution", resourceCulture);

		public static string NewtonHybrid => ResourceManager.GetString("NewtonHybrid", resourceCulture);

		public static string NewtonLine => ResourceManager.GetString("NewtonLine", resourceCulture);

		public static string NLConditionalRequested => ResourceManager.GetString("NLConditionalRequested", resourceCulture);

		public static string NLIdxRequested => ResourceManager.GetString("NLIdxRequested", resourceCulture);

		public static string NoChangeInSignOfY => ResourceManager.GetString("NoChangeInSignOfY", resourceCulture);

		public static string NoInterfacial => ResourceManager.GetString("NoInterfacial", resourceCulture);

		public static string NoneTxt => ResourceManager.GetString("NoneTxt", resourceCulture);

		public static string NonlinearMethod => ResourceManager.GetString("NonlinearMethod", resourceCulture);

		public static string NonSymmetricOrifice => ResourceManager.GetString("NonSymmetricOrifice", resourceCulture);

		public static string NoPluginFoundForUnitOp => ResourceManager.GetString("NoPluginFoundForUnitOp", resourceCulture);

		public static string NoPlugins => ResourceManager.GetString("NoPlugins", resourceCulture);

		public static string NoPropertyInPhase => ResourceManager.GetString("NoPropertyInPhase", resourceCulture);

		public static string NoSlip => ResourceManager.GetString("NoSlip", resourceCulture);

		public static string NoSolvableUnitOps => ResourceManager.GetString("NoSolvableUnitOps", resourceCulture);

		public static string NoSolver => ResourceManager.GetString("NoSolver", resourceCulture);

		public static string NotAllHydraulicsPhasesMassFlowUpdateFailed => ResourceManager.GetString("NotAllHydraulicsPhasesMassFlowUpdateFailed", resourceCulture);

		public static string NotInstanted => ResourceManager.GetString("NotInstanted", resourceCulture);

		public static string NotSpecified => ResourceManager.GetString("NotSpecified", resourceCulture);

		public static string NotValidSegPos => ResourceManager.GetString("NotValidSegPos", resourceCulture);

		public static string NotVertical => ResourceManager.GetString("NotVertical", resourceCulture);

		public static string NotYetImplemented => ResourceManager.GetString("NotYetImplemented", resourceCulture);

		public static string NullCallback => ResourceManager.GetString("NullCallback", resourceCulture);

		public static string NullVectorResid => ResourceManager.GetString("NullVectorResid", resourceCulture);

		public static string NullVectorVars => ResourceManager.GetString("NullVectorVars", resourceCulture);

		public static string NumberOfCuts => ResourceManager.GetString("NumberOfCuts", resourceCulture);

		public static string NumberOfGuideVanes => ResourceManager.GetString("NumberOfGuideVanes", resourceCulture);

		public static string NumberOfLayersAlreadySet => ResourceManager.GetString("NumberOfLayersAlreadySet", resourceCulture);

		public static string NumElementsInNetwork => ResourceManager.GetString("NumElementsInNetwork", resourceCulture);

		public static string NumPhasesDifferentCannotAverage => ResourceManager.GetString("NumPhasesDifferentCannotAverage", resourceCulture);

		public static string ObjFuncEquals => ResourceManager.GetString("ObjFuncEquals", resourceCulture);

		public static string OffTxt => ResourceManager.GetString("OffTxt", resourceCulture);

		public static string OilWaterFrictionLimit => ResourceManager.GetString("OilWaterFrictionLimit", resourceCulture);

		public static string OilWaterFrictionMethod => ResourceManager.GetString("OilWaterFrictionMethod", resourceCulture);

		public static string OilWaterInversionPt => ResourceManager.GetString("OilWaterInversionPt", resourceCulture);

		public static string OilWaterSlugFreq => ResourceManager.GetString("OilWaterSlugFreq", resourceCulture);

		public static string OilWaterVisc => ResourceManager.GetString("OilWaterVisc", resourceCulture);

		public static string OnTxt => ResourceManager.GetString("OnTxt", resourceCulture);

		public static string OpeningAngle => ResourceManager.GetString("OpeningAngle", resourceCulture);

		public static string OpeningAngleNotBetween10And90 => ResourceManager.GetString("OpeningAngleNotBetween10And90", resourceCulture);

		public static string OpeningAngleNotBetween10And90B => ResourceManager.GetString("OpeningAngleNotBetween10And90B", resourceCulture);

		public static string OpeningAngleNotBetweenBlindAnd90 => ResourceManager.GetString("OpeningAngleNotBetweenBlindAnd90", resourceCulture);

		public static string OpeningAngleNotBetweenBlindAnd90B => ResourceManager.GetString("OpeningAngleNotBetweenBlindAnd90B", resourceCulture);

		public static string OpeningAngleSetTo90 => ResourceManager.GetString("OpeningAngleSetTo90", resourceCulture);

		public static string OperatorError => ResourceManager.GetString("OperatorError", resourceCulture);

		public static string OrkiszewskiMethod => ResourceManager.GetString("OrkiszewskiMethod", resourceCulture);

		public static string OuterDiam => ResourceManager.GetString("OuterDiam", resourceCulture);

		public static string OuterError => ResourceManager.GetString("OuterError", resourceCulture);

		public static string OuterIter => ResourceManager.GetString("OuterIter", resourceCulture);

		public static string OuterIterEquals => ResourceManager.GetString("OuterIterEquals", resourceCulture);

		public static string OuterLoopTol => ResourceManager.GetString("OuterLoopTol", resourceCulture);

		public static string OuterTol => ResourceManager.GetString("OuterTol", resourceCulture);

		public static string OutletSmallerError => ResourceManager.GetString("OutletSmallerError", resourceCulture);

		public static string OutletSmallerErrorEnlargement => ResourceManager.GetString("OutletSmallerErrorEnlargement", resourceCulture);

		public static string OutOfRange => ResourceManager.GetString("OutOfRange", resourceCulture);

		public static string OverallMassBalFail => ResourceManager.GetString("OverallMassBalFail", resourceCulture);

		public static string PartialAnalysisFail => ResourceManager.GetString("PartialAnalysisFail", resourceCulture);

		public static string PartialBCNotSupported => ResourceManager.GetString("PartialBCNotSupported", resourceCulture);

		public static string PartialBCNotSupported2 => ResourceManager.GetString("PartialBCNotSupported2", resourceCulture);

		public static string PartialBCNotSupportedFE => ResourceManager.GetString("PartialBCNotSupportedFE", resourceCulture);

		public static string PartialBodyFlowArea => ResourceManager.GetString("PartialBodyFlowArea", resourceCulture);

		public static string PartiallyOpenedNotSupported => ResourceManager.GetString("PartiallyOpenedNotSupported", resourceCulture);

		public static string PartiallyOpenedNotSupportedBall => ResourceManager.GetString("PartiallyOpenedNotSupportedBall", resourceCulture);

		public static string PartiallyOpenedNotSupportedButterfly => ResourceManager.GetString("PartiallyOpenedNotSupportedButterfly", resourceCulture);

		public static string PartiallyOpenedNotSupportedGate => ResourceManager.GetString("PartiallyOpenedNotSupportedGate", resourceCulture);

		public static string PartiallyOpenedNotSupportedGlobe => ResourceManager.GetString("PartiallyOpenedNotSupportedGlobe", resourceCulture);

		public static string PassIPFStoPFS => ResourceManager.GetString("PassIPFStoPFS", resourceCulture);

		public static string PBoundaryMW => ResourceManager.GetString("PBoundaryMW", resourceCulture);

		public static string PDropFor => ResourceManager.GetString("PDropFor", resourceCulture);

		public static string PFElementMustConnectToPipes => ResourceManager.GetString("PFElementMustConnectToPipes", resourceCulture);

		public static string PGradPaPerM => ResourceManager.GetString("PGradPaPerM", resourceCulture);

		public static string PhaseChange => ResourceManager.GetString("PhaseChange", resourceCulture);

		public static string PhaseChangeRelaxFactor => ResourceManager.GetString("PhaseChangeRelaxFactor", resourceCulture);

		public static string PhaseDoesNotSupportIHydraulic => ResourceManager.GetString("PhaseDoesNotSupportIHydraulic", resourceCulture);

		public static string PhaseIndexGTNumPhases => ResourceManager.GetString("PhaseIndexGTNumPhases", resourceCulture);

		public static string PigConstantVel => ResourceManager.GetString("PigConstantVel", resourceCulture);

		public static string PigEntryLocation => ResourceManager.GetString("PigEntryLocation", resourceCulture);

		public static string PigExitLocation => ResourceManager.GetString("PigExitLocation", resourceCulture);

		public static string PigGasVel => ResourceManager.GetString("PigGasVel", resourceCulture);

		public static string PigHighPerformance => ResourceManager.GetString("PigHighPerformance", resourceCulture);

		public static string PigLeakage => ResourceManager.GetString("PigLeakage", resourceCulture);

		public static string PigLiquidVel => ResourceManager.GetString("PigLiquidVel", resourceCulture);

		public static string PigModel => ResourceManager.GetString("PigModel", resourceCulture);

		public static string PigName => ResourceManager.GetString("PigName", resourceCulture);

		public static string PigStatus => ResourceManager.GetString("PigStatus", resourceCulture);

		public static string PigTransitTime => ResourceManager.GetString("PigTransitTime", resourceCulture);

		public static string PigVelocity => ResourceManager.GetString("PigVelocity", resourceCulture);

		public static string PipeAngle => ResourceManager.GetString("PipeAngle", resourceCulture);

		public static string PipeAngleDeg => ResourceManager.GetString("PipeAngleDeg", resourceCulture);

		public static string PipeDiam => ResourceManager.GetString("PipeDiam", resourceCulture);

		public static string PipeDiamInconsistent => ResourceManager.GetString("PipeDiamInconsistent", resourceCulture);

		public static string PipeDiamInconsistent2 => ResourceManager.GetString("PipeDiamInconsistent2", resourceCulture);

		public static string PipeDiamMeter => ResourceManager.GetString("PipeDiamMeter", resourceCulture);

		public static string PipeDiamNeeded => ResourceManager.GetString("PipeDiamNeeded", resourceCulture);

		public static string PipeDiamNeededFE => ResourceManager.GetString("PipeDiamNeededFE", resourceCulture);

		public static string PipeEqLength => ResourceManager.GetString("PipeEqLength", resourceCulture);

		public static string PipeFittingServerCalcFailed => ResourceManager.GetString("PipeFittingServerCalcFailed", resourceCulture);

		public static string PipeInclineTooLarge1 => ResourceManager.GetString("PipeInclineTooLarge1", resourceCulture);

		public static string PipeInclineTooLarge2 => ResourceManager.GetString("PipeInclineTooLarge2", resourceCulture);

		public static string PipeLengthNeeded1 => ResourceManager.GetString("PipeLengthNeeded1", resourceCulture);

		public static string PipeLengthNeeded2 => ResourceManager.GetString("PipeLengthNeeded2", resourceCulture);

		public static string PipeRoughMeter => ResourceManager.GetString("PipeRoughMeter", resourceCulture);

		public static string PipeRoughness => ResourceManager.GetString("PipeRoughness", resourceCulture);

		public static string PipeWallCannotBeRemoved => ResourceManager.GetString("PipeWallCannotBeRemoved", resourceCulture);

		public static string PleaseSetDiam => ResourceManager.GetString("PleaseSetDiam", resourceCulture);

		public static string PolynomialCurve => ResourceManager.GetString("PolynomialCurve", resourceCulture);

		public static string PolytropicTxt => ResourceManager.GetString("PolytropicTxt", resourceCulture);

		public static string PortDiamNeededSizing => ResourceManager.GetString("PortDiamNeededSizing", resourceCulture);

		public static string PortNeedsStream => ResourceManager.GetString("PortNeedsStream", resourceCulture);

		public static string PortsAllSameType => ResourceManager.GetString("PortsAllSameType", resourceCulture);

		public static string PortTypeNotFound => ResourceManager.GetString("PortTypeNotFound", resourceCulture);

		public static string PPortConnError => ResourceManager.GetString("PPortConnError", resourceCulture);

		public static string PreserveDPDescription => ResourceManager.GetString("PreserveDPDescription", resourceCulture);

		public static string PressureCurveCalc => ResourceManager.GetString("PressureCurveCalc", resourceCulture);

		public static string PressureDropMethod => ResourceManager.GetString("PressureDropMethod", resourceCulture);

		public static string PressureGrad => ResourceManager.GetString("PressureGrad", resourceCulture);

		public static string PressurePortMissingComposition => ResourceManager.GetString("PressurePortMissingComposition", resourceCulture);

		public static string PressurePortMissingThermoSpec => ResourceManager.GetString("PressurePortMissingThermoSpec", resourceCulture);

		public static string PressureRatio => ResourceManager.GetString("PressureRatio", resourceCulture);

		public static string PressureSpecOnlyAllowedAtBoundary => ResourceManager.GetString("PressureSpecOnlyAllowedAtBoundary", resourceCulture);

		public static string ProductPressureRelaxationFactor => ResourceManager.GetString("ProductPressureRelaxationFactor", resourceCulture);

		public static string PropertyTypeNotSupported => ResourceManager.GetString("PropertyTypeNotSupported", resourceCulture);

		public static string RadiusTxt => ResourceManager.GetString("RadiusTxt", resourceCulture);

		public static string RaOutOfRange => ResourceManager.GetString("RaOutOfRange", resourceCulture);

		public static string ReadyToLaunch => ResourceManager.GetString("ReadyToLaunch", resourceCulture);

		public static string RecycleDetected => ResourceManager.GetString("RecycleDetected", resourceCulture);

		public static string ReEstimateTears => ResourceManager.GetString("ReEstimateTears", resourceCulture);

		public static string ReNotLaminar => ResourceManager.GetString("ReNotLaminar", resourceCulture);

		public static string ReNotTransitional => ResourceManager.GetString("ReNotTransitional", resourceCulture);

		public static string ReNotTurbulent => ResourceManager.GetString("ReNotTurbulent", resourceCulture);

		public static string ReOutOfRange => ResourceManager.GetString("ReOutOfRange", resourceCulture);

		public static string RequiredVsCurrentNumberOfBCs => ResourceManager.GetString("RequiredVsCurrentNumberOfBCs", resourceCulture);

		public static string RequiredVsCurrentNumberOfBCs2 => ResourceManager.GetString("RequiredVsCurrentNumberOfBCs2", resourceCulture);

		public static string RestartTxt => ResourceManager.GetString("RestartTxt", resourceCulture);

		public static string ResultsPropBuildFail => ResourceManager.GetString("ResultsPropBuildFail", resourceCulture);

		public static string ReverseFlowAborted => ResourceManager.GetString("ReverseFlowAborted", resourceCulture);

		public static string ReverseFlowAsymmetryWarning => ResourceManager.GetString("ReverseFlowAsymmetryWarning", resourceCulture);

		public static string RevFlowFlareTip => ResourceManager.GetString("RevFlowFlareTip", resourceCulture);

		public static string ReynoldsNumber => ResourceManager.GetString("ReynoldsNumber", resourceCulture);

		public static string RootFound => ResourceManager.GetString("RootFound", resourceCulture);

		public static string RootNotFoundMaxIter => ResourceManager.GetString("RootNotFoundMaxIter", resourceCulture);

		public static string RoughnessM => ResourceManager.GetString("RoughnessM", resourceCulture);

		public static string RoughPipe => ResourceManager.GetString("RoughPipe", resourceCulture);

		public static string RoughPipeAnnular => ResourceManager.GetString("RoughPipeAnnular", resourceCulture);

		public static string RoughPipeFormLoss => ResourceManager.GetString("RoughPipeFormLoss", resourceCulture);

		public static string RoughPipeFormLossAnnular => ResourceManager.GetString("RoughPipeFormLossAnnular", resourceCulture);

		public static string RoundMethod => ResourceManager.GetString("RoundMethod", resourceCulture);

		public static string SequenceFail => ResourceManager.GetString("SequenceFail", resourceCulture);

		public static string SetBasicGeometry => ResourceManager.GetString("SetBasicGeometry", resourceCulture);

		public static string SetMassFlowRate => ResourceManager.GetString("SetMassFlowRate", resourceCulture);

		public static string SetPortStateParams => ResourceManager.GetString("SetPortStateParams", resourceCulture);

		public static string SetRightBCs => ResourceManager.GetString("SetRightBCs", resourceCulture);

		public static string SimpleStratified => ResourceManager.GetString("SimpleStratified", resourceCulture);

		public static string SimpleTxt => ResourceManager.GetString("SimpleTxt", resourceCulture);

		public static string SinaiTxt => ResourceManager.GetString("SinaiTxt", resourceCulture);

		public static string SinglePhaseFlowEncountered => ResourceManager.GetString("SinglePhaseFlowEncountered", resourceCulture);

		public static string SinglePhaseSonicVFailed => ResourceManager.GetString("SinglePhaseSonicVFailed", resourceCulture);

		public static string SingletonInsufficientBCs => ResourceManager.GetString("SingletonInsufficientBCs", resourceCulture);

		public static string SingletonWithMultipleFlows => ResourceManager.GetString("SingletonWithMultipleFlows", resourceCulture);

		public static string SingletonWithoutPressure => ResourceManager.GetString("SingletonWithoutPressure", resourceCulture);

		public static string SizingCalcAborted => ResourceManager.GetString("SizingCalcAborted", resourceCulture);

		public static string SmoothPipe => ResourceManager.GetString("SmoothPipe", resourceCulture);

		public static string SmoothPipeFormLoss => ResourceManager.GetString("SmoothPipeFormLoss", resourceCulture);

		public static string SolvedAtMin => ResourceManager.GetString("SolvedAtMin", resourceCulture);

		public static string SolvedAtMinLocal => ResourceManager.GetString("SolvedAtMinLocal", resourceCulture);

		public static string SolvedOnFlowPTol => ResourceManager.GetString("SolvedOnFlowPTol", resourceCulture);

		public static string SolvedOnP => ResourceManager.GetString("SolvedOnP", resourceCulture);

		public static string SolvedOnPInit => ResourceManager.GetString("SolvedOnPInit", resourceCulture);

		public static string SolveFailed => ResourceManager.GetString("SolveFailed", resourceCulture);

		public static string SolverAlreadyExists => ResourceManager.GetString("SolverAlreadyExists", resourceCulture);

		public static string SolverNotFound => ResourceManager.GetString("SolverNotFound", resourceCulture);

		public static string SolverStatus => ResourceManager.GetString("SolverStatus", resourceCulture);

		public static string SolverXMLNotFound => ResourceManager.GetString("SolverXMLNotFound", resourceCulture);

		public static string SolverXMLNotValid => ResourceManager.GetString("SolverXMLNotValid", resourceCulture);

		public static string SortOptionNotImplemented => ResourceManager.GetString("SortOptionNotImplemented", resourceCulture);

		public static string SpecifyEnthalpyAsStagnationDescription => ResourceManager.GetString("SpecifyEnthalpyAsStagnationDescription", resourceCulture);

		public static string SplitterMWMatchFor => ResourceManager.GetString("SplitterMWMatchFor", resourceCulture);

		public static string SSLicenseValidationFailed => ResourceManager.GetString("SSLicenseValidationFailed", resourceCulture);

		public static string StaplebergTronconi => ResourceManager.GetString("StaplebergTronconi", resourceCulture);

		public static string StaticHeadContribution => ResourceManager.GetString("StaticHeadContribution", resourceCulture);

		public static string StaticPBalance => ResourceManager.GetString("StaticPBalance", resourceCulture);

		public static string StatusPropBuildFail => ResourceManager.GetString("StatusPropBuildFail", resourceCulture);

		public static string SteadyState => ResourceManager.GetString("SteadyState", resourceCulture);

		public static string SteadyStateSolver => ResourceManager.GetString("SteadyStateSolver", resourceCulture);

		public static string StoreSolverFailed => ResourceManager.GetString("StoreSolverFailed", resourceCulture);

		public static string StreamIDGasLift => ResourceManager.GetString("StreamIDGasLift", resourceCulture);

		public static string String1 => ResourceManager.GetString("String1", resourceCulture);

		public static string SwageCalcMethod => ResourceManager.GetString("SwageCalcMethod", resourceCulture);

		public static string SwageCompressibleTransition => ResourceManager.GetString("SwageCompressibleTransition", resourceCulture);

		public static string TearFlowConstrained => ResourceManager.GetString("TearFlowConstrained", resourceCulture);

		public static string TearLocationRevision => ResourceManager.GetString("TearLocationRevision", resourceCulture);

		public static string TearPipeFlowMessage => ResourceManager.GetString("TearPipeFlowMessage", resourceCulture);

		public static string TearsTxt => ResourceManager.GetString("TearsTxt", resourceCulture);

		public static string TeeCalcMethod => ResourceManager.GetString("TeeCalcMethod", resourceCulture);

		public static string ThreePhaseFlowNotSet => ResourceManager.GetString("ThreePhaseFlowNotSet", resourceCulture);

		public static string ThroatLargerThanPort => ResourceManager.GetString("ThroatLargerThanPort", resourceCulture);

		public static string ThrottleBadThroatDiam1 => ResourceManager.GetString("ThrottleBadThroatDiam1", resourceCulture);

		public static string ThrottleBadThroatDiam2 => ResourceManager.GetString("ThrottleBadThroatDiam2", resourceCulture);

		public static string TooManyBCs => ResourceManager.GetString("TooManyBCs", resourceCulture);

		public static string TooManyPigs => ResourceManager.GetString("TooManyPigs", resourceCulture);

		public static string TotalPBalance => ResourceManager.GetString("TotalPBalance", resourceCulture);

		public static string TransientTxt => ResourceManager.GetString("TransientTxt", resourceCulture);

		public static string TransitionFlowLimitsTooClose => ResourceManager.GetString("TransitionFlowLimitsTooClose", resourceCulture);

		public static string Tulsa2Phase => ResourceManager.GetString("Tulsa2Phase", resourceCulture);

		public static string Tulsa3Phase => ResourceManager.GetString("Tulsa3Phase", resourceCulture);

		public static string TwoInletSeparatorsNotSupportedDyn => ResourceManager.GetString("TwoInletSeparatorsNotSupportedDyn", resourceCulture);

		public static string TwoPhaseFlowEncountered => ResourceManager.GetString("TwoPhaseFlowEncountered", resourceCulture);

		public static string UnableToMapPorts => ResourceManager.GetString("UnableToMapPorts", resourceCulture);

		public static string UndefDPCalcs => ResourceManager.GetString("UndefDPCalcs", resourceCulture);

		public static string UndefEnergyAtPPort => ResourceManager.GetString("UndefEnergyAtPPort", resourceCulture);

		public static string UndefFlowAtFlowBoundary => ResourceManager.GetString("UndefFlowAtFlowBoundary", resourceCulture);

		public static string UndefFlowAtTear => ResourceManager.GetString("UndefFlowAtTear", resourceCulture);

		public static string UndefinedProp => ResourceManager.GetString("UndefinedProp", resourceCulture);

		public static string UndefMWAtFlowBoundary => ResourceManager.GetString("UndefMWAtFlowBoundary", resourceCulture);

		public static string UndefPressAtPressBoundary => ResourceManager.GetString("UndefPressAtPressBoundary", resourceCulture);

		public static string UndeterminedFlowDirection => ResourceManager.GetString("UndeterminedFlowDirection", resourceCulture);

		public static string UnequalPortDiameters => ResourceManager.GetString("UnequalPortDiameters", resourceCulture);

		public static string UnexpectedTermination => ResourceManager.GetString("UnexpectedTermination", resourceCulture);

		public static string UnitOpTypeNotAvailable => ResourceManager.GetString("UnitOpTypeNotAvailable", resourceCulture);

		public static string UnknownBoundaryFlow => ResourceManager.GetString("UnknownBoundaryFlow", resourceCulture);

		public static string UnknownBoundaryPressure => ResourceManager.GetString("UnknownBoundaryPressure", resourceCulture);

		public static string UnknownCv => ResourceManager.GetString("UnknownCv", resourceCulture);

		public static string UnknownDensity => ResourceManager.GetString("UnknownDensity", resourceCulture);

		public static string UnknownFindRootError => ResourceManager.GetString("UnknownFindRootError", resourceCulture);

		public static string UnknownFlowAtTear => ResourceManager.GetString("UnknownFlowAtTear", resourceCulture);

		public static string UnknownPhaseSplitNotPossible => ResourceManager.GetString("UnknownPhaseSplitNotPossible", resourceCulture);

		public static string UnknownPortDiameters => ResourceManager.GetString("UnknownPortDiameters", resourceCulture);

		public static string UnknownRoot => ResourceManager.GetString("UnknownRoot", resourceCulture);

		public static string UnknownRoot100 => ResourceManager.GetString("UnknownRoot100", resourceCulture);

		public static string UnknownStreamState => ResourceManager.GetString("UnknownStreamState", resourceCulture);

		public static string UnknownStructure => ResourceManager.GetString("UnknownStructure", resourceCulture);

		public static string UnknownStyle => ResourceManager.GetString("UnknownStyle", resourceCulture);

		public static string UnknownTeeAngle => ResourceManager.GetString("UnknownTeeAngle", resourceCulture);

		public static string UnknownTeeType1 => ResourceManager.GetString("UnknownTeeType1", resourceCulture);

		public static string UnknownTeeType2 => ResourceManager.GetString("UnknownTeeType2", resourceCulture);

		public static string UnknownVarBlockSize => ResourceManager.GetString("UnknownVarBlockSize", resourceCulture);

		public static string UnrecognizedTeeMethod => ResourceManager.GetString("UnrecognizedTeeMethod", resourceCulture);

		public static string UnsupportedBCs => ResourceManager.GetString("UnsupportedBCs", resourceCulture);

		public static string UnsupportedProperty => ResourceManager.GetString("UnsupportedProperty", resourceCulture);

		public static string UpperBoundLTLowerBound => ResourceManager.GetString("UpperBoundLTLowerBound", resourceCulture);

		public static string UsedTimeStep => ResourceManager.GetString("UsedTimeStep", resourceCulture);

		public static string UserDefFFFailed => ResourceManager.GetString("UserDefFFFailed", resourceCulture);

		public static string UserFlowEstimate => ResourceManager.GetString("UserFlowEstimate", resourceCulture);

		public static string ValueOutOfBounds => ResourceManager.GetString("ValueOutOfBounds", resourceCulture);

		public static string ValueOutOfBoundsEnum => ResourceManager.GetString("ValueOutOfBoundsEnum", resourceCulture);

		public static string ValueTooHigh => ResourceManager.GetString("ValueTooHigh", resourceCulture);

		public static string ValueTooLow => ResourceManager.GetString("ValueTooLow", resourceCulture);

		public static string ValveBadInletAngle1 => ResourceManager.GetString("ValveBadInletAngle1", resourceCulture);

		public static string ValveBadInletAngle2 => ResourceManager.GetString("ValveBadInletAngle2", resourceCulture);

		public static string ValveBadThroatDiam1 => ResourceManager.GetString("ValveBadThroatDiam1", resourceCulture);

		public static string ValveBadThroatDiam2 => ResourceManager.GetString("ValveBadThroatDiam2", resourceCulture);

		public static string ValveInletAngleSetToZero => ResourceManager.GetString("ValveInletAngleSetToZero", resourceCulture);

		public static string ValveOpening => ResourceManager.GetString("ValveOpening", resourceCulture);

		public static string ValveOpeningLimitGate => ResourceManager.GetString("ValveOpeningLimitGate", resourceCulture);

		public static string ValveOpeningLimitGate2 => ResourceManager.GetString("ValveOpeningLimitGate2", resourceCulture);

		public static string ValveOpeningLimitGlobe => ResourceManager.GetString("ValveOpeningLimitGlobe", resourceCulture);

		public static string ValveOpeningLimitGlobe2 => ResourceManager.GetString("ValveOpeningLimitGlobe2", resourceCulture);

		public static string ValveOpeningSetTo1 => ResourceManager.GetString("ValveOpeningSetTo1", resourceCulture);

		public static string ValveThroatSetToUpstream => ResourceManager.GetString("ValveThroatSetToUpstream", resourceCulture);

		public static string ValveType => ResourceManager.GetString("ValveType", resourceCulture);

		public static string VoidFrac => ResourceManager.GetString("VoidFrac", resourceCulture);

		public static string VoidFracPct => ResourceManager.GetString("VoidFracPct", resourceCulture);

		public static string WallFriction => ResourceManager.GetString("WallFriction", resourceCulture);

		public static string WettedAreaCalcFailed => ResourceManager.GetString("WettedAreaCalcFailed", resourceCulture);

		public static string WithLength => ResourceManager.GetString("WithLength", resourceCulture);

		public static string WithPressure => ResourceManager.GetString("WithPressure", resourceCulture);

		public static string XMLFileFailed => ResourceManager.GetString("XMLFileFailed", resourceCulture);

		public static string XmlFileSolverSupportNotValid => ResourceManager.GetString("XmlFileSolverSupportNotValid", resourceCulture);

		public static string XMLMissingSupportedUnitOpList => ResourceManager.GetString("XMLMissingSupportedUnitOpList", resourceCulture);

		public static string XMLMissingSupportedUnitOpList2 => ResourceManager.GetString("XMLMissingSupportedUnitOpList2", resourceCulture);

		public static string ZeroMassFlow => ResourceManager.GetString("ZeroMassFlow", resourceCulture);

		public static string ZeroMW => ResourceManager.GetString("ZeroMW", resourceCulture);

		public static string ZeroVisc => ResourceManager.GetString("ZeroVisc", resourceCulture);

	}
}
