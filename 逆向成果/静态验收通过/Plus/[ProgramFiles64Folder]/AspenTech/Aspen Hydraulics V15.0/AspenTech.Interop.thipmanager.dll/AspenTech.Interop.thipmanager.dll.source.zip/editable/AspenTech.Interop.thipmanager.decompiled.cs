using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: Guid("260a86f2-3fa5-11d3-a5bf-00a0c9df422b")]
[assembly: PrimaryInteropAssembly(1, 0)]
[assembly: ImportedFromTypeLib("THIPMANAGERLib")]
[assembly: AssemblyVersion("1.0.0.0")]
namespace AspenTech.Interop.ThIPManager;

[ComImport]
[ClassInterface((short)0)]
[Guid("69629623-3FB3-11D3-A5BF-00A0C9DF422B")]
[TypeLibType(2)]
public class COTHIPManagerClass : IIPManager, COTHIPManager
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	extern void IIPManager.SetPropertyManager([In][MarshalAs(UnmanagedType.IDispatch)] object pPropManager);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	extern void IIPManager.CreateIPs([In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [In][MarshalAs(UnmanagedType.BStr)] string defaultpath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern void IIPManager.CreateOneIPObject([In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [In][MarshalAs(UnmanagedType.BStr)] string modelname, [In] int numpanes, [In][MarshalAs(UnmanagedType.BStr)] string defaultpath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	extern void IIPManager.SetDefaultDBDirForIPs([In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [In][MarshalAs(UnmanagedType.BStr)] string path);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	extern void IIPManager.AttachLoaderToIPObject([In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [MarshalAs(UnmanagedType.IDispatch)] object pLoader, [In][MarshalAs(UnmanagedType.BStr)] string modelname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	extern void IIPManager.LoadIPObjects([In][MarshalAs(UnmanagedType.IDispatch)] object pCC);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	extern void IIPManager.LoadOneIPObject([In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [In][MarshalAs(UnmanagedType.BStr)] string modelname);
}
[ComImport]
[Guid("69629624-3FB3-11D3-A5BF-00A0C9DF422B")]
[CoClass(typeof(COTHIPManagerClass))]
public interface COTHIPManager : IIPManager
{
}
[ComImport]
[TypeLibType(4160)]
[Guid("69629624-3FB3-11D3-A5BF-00A0C9DF422B")]
public interface IIPManager
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void SetPropertyManager([In][MarshalAs(UnmanagedType.IDispatch)] object pPropManager);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void CreateIPs([In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [In][MarshalAs(UnmanagedType.BStr)] string defaultpath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void CreateOneIPObject([In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [In][MarshalAs(UnmanagedType.BStr)] string modelname, [In] int numpanes, [In][MarshalAs(UnmanagedType.BStr)] string defaultpath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void SetDefaultDBDirForIPs([In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [In][MarshalAs(UnmanagedType.BStr)] string path);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void AttachLoaderToIPObject([In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [MarshalAs(UnmanagedType.IDispatch)] object pLoader, [In][MarshalAs(UnmanagedType.BStr)] string modelname);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void LoadIPObjects([In][MarshalAs(UnmanagedType.IDispatch)] object pCC);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void LoadOneIPObject([In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [In][MarshalAs(UnmanagedType.BStr)] string modelname);
}
