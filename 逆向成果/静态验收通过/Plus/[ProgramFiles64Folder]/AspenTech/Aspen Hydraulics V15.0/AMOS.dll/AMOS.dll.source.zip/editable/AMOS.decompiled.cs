using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows.Forms;
using AMOS;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
[assembly: TargetFramework(".NETFramework,Version=v4.5.1", FrameworkDisplayName = ".NET Framework 4.5.1")]
[assembly: AssemblyVersion("41.0.0.1")]
namespace AMOSCommon
{
	public class AMOSParamDialog : Form
	{
		private int X;

		private int Y;

		private ListViewItem m_EditedItem;

		private ListView m_paramList;

		private Button m_OKButton;

		private Label statuslabel;

		private TextBox m_ValueEditor;

		private ComboBox m_stringOptionsCombo;

		private bool running;

		private IAMOSParameterTable m_table;

		private Container components;

		public AMOSParamDialog(IAMOSParameterTable aTable)
		{
			InitializeComponent();
			m_table = aTable;
			base.Closing += AMOSParamDialog_Closing;
			m_ValueEditor.KeyPress += EditOver;
			m_paramList.DoubleClick += ListDoubleClicked;
			m_paramList.MouseDown += ListMouseDown;
			InitParams();
		}

		public void Execute()
		{
			running = true;
			Show();
			while (running)
			{
				Application.DoEvents();
			}
			Hide();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.m_paramList = new System.Windows.Forms.ListView();
			this.m_OKButton = new System.Windows.Forms.Button();
			this.statuslabel = new System.Windows.Forms.Label();
			this.m_ValueEditor = new System.Windows.Forms.TextBox();
			this.m_stringOptionsCombo = new System.Windows.Forms.ComboBox();
			base.SuspendLayout();
			this.m_paramList.GridLines = true;
			this.m_paramList.Location = new System.Drawing.Point(0, 0);
			this.m_paramList.Name = "m_paramList";
			this.m_paramList.Size = new System.Drawing.Size(864, 360);
			this.m_paramList.TabIndex = 1;
			this.m_paramList.View = System.Windows.Forms.View.Details;
			this.m_OKButton.Location = new System.Drawing.Point(16, 376);
			this.m_OKButton.Name = "m_OKButton";
			this.m_OKButton.Size = new System.Drawing.Size(75, 25);
			this.m_OKButton.TabIndex = 0;
			this.m_OKButton.Text = "OK";
			this.m_OKButton.Click += new System.EventHandler(m_OKButton_Click);
			this.statuslabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.statuslabel.ForeColor = System.Drawing.SystemColors.WindowText;
			this.statuslabel.Location = new System.Drawing.Point(152, 384);
			this.statuslabel.Name = "statuslabel";
			this.statuslabel.Size = new System.Drawing.Size(488, 16);
			this.statuslabel.TabIndex = 3;
			this.statuslabel.Text = "Ready";
			this.statuslabel.Click += new System.EventHandler(label1_Click);
			this.m_ValueEditor.BackColor = System.Drawing.SystemColors.ControlLight;
			this.m_ValueEditor.Location = new System.Drawing.Point(664, 376);
			this.m_ValueEditor.Name = "m_ValueEditor";
			this.m_ValueEditor.TabIndex = 2;
			this.m_ValueEditor.Text = "textBox1";
			this.m_ValueEditor.Visible = false;
			this.m_stringOptionsCombo.Location = new System.Drawing.Point(776, 376);
			this.m_stringOptionsCombo.Name = "m_stringOptionsCombo";
			this.m_stringOptionsCombo.Size = new System.Drawing.Size(121, 21);
			this.m_stringOptionsCombo.TabIndex = 4;
			this.m_stringOptionsCombo.Text = "Options";
			this.m_stringOptionsCombo.Visible = false;
			this.m_stringOptionsCombo.SelectedIndexChanged += new System.EventHandler(m_stringOptionsCombo_SelectedIndexChanged);
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			base.ClientSize = new System.Drawing.Size(912, 414);
			base.Controls.Add(this.m_stringOptionsCombo);
			base.Controls.Add(this.m_ValueEditor);
			base.Controls.Add(this.statuslabel);
			base.Controls.Add(this.m_OKButton);
			base.Controls.Add(this.m_paramList);
			base.Name = "AMOSParamDialog";
			this.Text = "AMOSParamDialog";
			base.Load += new System.EventHandler(AMOSParamDialog_Load);
			base.ResumeLayout(false);
		}

		private void AMOSParamDialog_Load(object sender, EventArgs e)
		{
		}

		private void label1_Click(object sender, EventArgs e)
		{
		}

		private void m_OKButton_Click(object sender, EventArgs e)
		{
			running = false;
		}

		public void InitParams()
		{
			m_paramList.Columns.Add("ParamName", -2, HorizontalAlignment.Left);
			m_paramList.Columns.Add("ParamValue", -2, HorizontalAlignment.Right);
			m_paramList.Columns.Add("Description", -2, HorizontalAlignment.Left);
			ArrayList arrayList = new ArrayList();
			ArrayList arrayList2 = new ArrayList();
			m_table.GetParameterNames(arrayList);
			for (int i = 0; i < arrayList.Count; i++)
			{
				arrayList2.Clear();
				m_table.GetParameterInfo(arrayList[i].ToString(), arrayList2);
				ListViewItem listViewItem = new ListViewItem(arrayList[i].ToString());
				listViewItem.SubItems.Add(arrayList2[1].ToString());
				listViewItem.SubItems.Add(arrayList2[0].ToString());
				m_paramList.Items.Add(listViewItem);
			}
		}

		public void AMOSParamDialog_Closing(object sender, CancelEventArgs e)
		{
			running = false;
		}

		public void ListDoubleClicked(object sender, EventArgs e)
		{
			m_EditedItem = m_paramList.GetItemAt(X, Y);
			m_ValueEditor.Text = m_EditedItem.SubItems[1].Text;
			int num = m_paramList.Columns[0].Width + 2;
			int num2 = num + m_paramList.Columns[1].Width;
			Size size = new Size(num2 - num, m_EditedItem.Bounds.Height);
			Point location = new Point(num, m_EditedItem.Bounds.Y);
			ArrayList arrayList = new ArrayList();
			m_table.GetParameterInfo(m_EditedItem.SubItems[0].Text, arrayList);
			if (arrayList[1] is string)
			{
				StatusMessage(Color.Blue, "Enter value for " + m_EditedItem.SubItems[0].Text + " valid values are " + arrayList[2]);
				string[] array = arrayList[2].ToString().Split(';');
				m_stringOptionsCombo.Items.Clear();
				int num3 = 0;
				for (int i = 0; i < array.Length; i++)
				{
					if (array[i].Length > 0)
					{
						m_stringOptionsCombo.Items.Add(array[i]);
						if (array[i] == m_EditedItem.SubItems[1].Text)
						{
							num3 = i;
						}
					}
				}
				m_stringOptionsCombo.Text = array[num3];
				m_stringOptionsCombo.Size = size;
				m_stringOptionsCombo.Location = location;
				m_stringOptionsCombo.SelectedIndex = num3;
				m_stringOptionsCombo.Show();
			}
			else
			{
				StatusMessage(Color.Blue, "Enter value for " + m_EditedItem.SubItems[0].Text + " in range [" + arrayList[2]?.ToString() + "-" + arrayList[3].ToString() + "]");
				m_ValueEditor.Size = size;
				m_ValueEditor.Location = location;
				m_ValueEditor.Show();
				m_ValueEditor.SelectAll();
				m_ValueEditor.Focus();
			}
		}

		public void ListMouseDown(object sender, MouseEventArgs e)
		{
			X = e.X;
			Y = e.Y;
		}

		private void StatusMessage(Color color, string message)
		{
			statuslabel.ForeColor = color;
			statuslabel.Text = message;
		}

		private void EditOver(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r')
			{
				m_ValueEditor.Hide();
				if (UpdateSolver(m_EditedItem.SubItems[0].Text, m_ValueEditor.Text) == AMOSretcode.AMSuccess)
				{
					m_EditedItem.SubItems[1].Text = m_ValueEditor.Text;
					StatusMessage(Color.Green, "Parameter " + m_EditedItem.SubItems[0].Text + " successfully changed to " + m_ValueEditor.Text);
				}
			}
			if (e.KeyChar == '\u001b')
			{
				m_ValueEditor.Hide();
				StatusMessage(Color.Black, "Cancelled");
			}
		}

		private AMOSretcode UpdateSolver(string paramName, string paramValue)
		{
			AMOSretcode aMOSretcode = AMOSretcode.AMError;
			ArrayList arrayList = new ArrayList();
			m_table.GetParameterInfo(paramName, arrayList);
			try
			{
				if (arrayList[1] is int)
				{
					int num = Convert.ToInt32(paramValue);
					aMOSretcode = m_table.SetParameter(paramName, num);
				}
				else if (arrayList[1] is double)
				{
					double num2 = Convert.ToDouble(paramValue);
					aMOSretcode = m_table.SetParameter(paramName, num2);
				}
				else if (arrayList[1] is string)
				{
					aMOSretcode = m_table.SetParameter(paramName, paramValue);
				}
				if (aMOSretcode == AMOSretcode.AMSuccess)
				{
					statuslabel.Text = "Param val successfully changed :-)";
				}
				else if (aMOSretcode == AMOSretcode.AMParamOutOfBounds)
				{
					statuslabel.ForeColor = Color.Red;
					if (arrayList[1] is int)
					{
						statuslabel.Text = $"Int param out of range [{arrayList[2]}-{arrayList[3]}]";
					}
					else if (arrayList[2] is double)
					{
						statuslabel.Text = $"Dbl param out of range [{arrayList[2]}-{arrayList[3]}]";
					}
					else
					{
						statuslabel.Text = $"String arg invalid; valid values: {arrayList[2]}";
					}
				}
				else
				{
					statuslabel.Text = "Unexpected failure setting param - AOS didn't like it :-(";
				}
			}
			catch (FormatException)
			{
				StatusMessage(Color.Red, "Data entered in incorrect format - ignored");
			}
			return aMOSretcode;
		}

		private void m_stringOptionsCombo_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (UpdateSolver(m_EditedItem.SubItems[0].Text, m_stringOptionsCombo.Text) == AMOSretcode.AMSuccess)
			{
				m_EditedItem.SubItems[1].Text = m_stringOptionsCombo.Text;
				StatusMessage(Color.Green, "Parameter " + m_EditedItem.SubItems[0].Text + " successfully changed to " + m_stringOptionsCombo.Text);
			}
			m_stringOptionsCombo.Hide();
		}
	}
	[ComVisible(false)]
	public sealed class StopWatch
	{
		private long m_StartTime;

		private long m_Frequency;

		private long StartTime
		{
			get
			{
				return m_StartTime;
			}
			set
			{
				m_StartTime = value;
			}
		}

		private long Frequency
		{
			get
			{
				return m_Frequency;
			}
			set
			{
				m_Frequency = value;
			}
		}

		[DllImport("kernel32.dll")]
		private static extern int QueryPerformanceCounter(ref long x);

		[DllImport("kernel32.dll")]
		private static extern int QueryPerformanceFrequency(ref long x);

		public StopWatch()
		{
			Frequency = GetFrequency();
			Reset();
		}

		public void Reset()
		{
			StartTime = GetValue();
		}

		public long Peek()
		{
			return (long)((double)(GetValue() - StartTime) / (double)Frequency * 10000.0);
		}

		public double cpuSecs()
		{
			return (double)Peek() / 10000.0;
		}

		private long GetValue()
		{
			long x = 0L;
			if (QueryPerformanceCounter(ref x) == 0)
			{
				throw new NotSupportedException("Error while querying the high-resolution performance counter.");
			}
			return x;
		}

		private long GetFrequency()
		{
			long x = 0L;
			if (QueryPerformanceFrequency(ref x) == 0)
			{
				throw new NotSupportedException("Error while querying the performance counter frequency.");
			}
			return x;
		}
	}
	public class CRandMT
	{
		private static int MT_N = 624;

		private static int MT_M = 397;

		private static uint MAT_A = 2567483615u;

		private static uint UMASK = 2147483648u;

		private static uint LMASK = 2147483647u;

		private static double dFac = 2.3283064365386963E-10;

		private uint[] state;

		private uint[] mag01;

		private uint counter;

		private uint seed;

		private double dInHand;

		private bool bInHand;

		private double dInHand64;

		private bool bInHand64;

		public uint Seed
		{
			get
			{
				return seed;
			}
			set
			{
				seed = value;
				reSeed();
			}
		}

		public CRandMT(uint seed)
		{
			state = new uint[MT_N];
			mag01 = new uint[2];
			if (seed == 0)
			{
				this.seed = (uint)DateTime.Now.Ticks;
			}
			else
			{
				this.seed = seed;
			}
			reSeed();
		}

		public uint lRand()
		{
			uint num;
			if (counter >= MT_N)
			{
				int i;
				for (i = 0; i < MT_N - MT_M; i++)
				{
					num = (state[i] & UMASK) | (state[i + 1] & LMASK);
					state[i] = state[i + MT_M] ^ (num >> 1) ^ mag01[num & 1];
				}
				for (; i < MT_N - 1; i++)
				{
					num = (state[i] & UMASK) | (state[i + 1] & LMASK);
					state[i] = state[i + (MT_M - MT_N)] ^ (num >> 1) ^ mag01[num & 1];
				}
				num = (state[MT_N - 1] & UMASK) | (state[0] & LMASK);
				state[MT_N - 1] = state[MT_M - 1] ^ (num >> 1) ^ mag01[num & 1];
				counter = 0u;
			}
			num = state[counter++];
			num ^= num >> 11;
			num ^= (num << 7) & 0x9D2C5680u;
			num ^= (num << 15) & 0xEFC60000u;
			num ^= num >> 18;
			return num;
		}

		public int iRand(int lo, int hi)
		{
			if (lo == 0 && hi == 0)
			{
				return (int)lRand();
			}
			return (int)Math.Floor((double)(hi - lo + 1) * dRand64()) + lo;
		}

		public double dRand()
		{
			return dFac * (double)lRand();
		}

		public double dRand64()
		{
			uint num = lRand() >> 5;
			uint num2 = lRand() >> 6;
			return ((double)num * 67108864.0 + (double)num2) * 1.1102230246251565E-16;
		}

		public double nRand()
		{
			if (bInHand)
			{
				bInHand = false;
				return dInHand;
			}
			double num;
			double num2;
			double num3;
			do
			{
				num = 2.0 * dFac * (double)lRand() - 1.0;
				num2 = 2.0 * dFac * (double)lRand() - 1.0;
				num3 = num * num + num2 * num2;
			}
			while (num3 >= 1.0 || num3 == 0.0);
			double num4 = -2.0 * Math.Log(num3) / num3;
			dInHand = num * num4;
			bInHand = true;
			return num2 * num4;
		}

		public double nRand64()
		{
			if (bInHand64)
			{
				bInHand64 = false;
				return dInHand64;
			}
			double num;
			double num2;
			double num3;
			do
			{
				num = 2.0 * dRand64() - 1.0;
				num2 = 2.0 * dRand64() - 1.0;
				num3 = num * num + num2 * num2;
			}
			while (num3 >= 1.0 || num3 == 0.0);
			double num4 = Math.Sqrt(-2.0 * Math.Log(num3) / num3);
			dInHand64 = num * num4;
			bInHand64 = true;
			return num2 * num4;
		}

		public double eRand()
		{
			uint num;
			do
			{
				num = lRand();
			}
			while (num == 0);
			return -Math.Log((double)(dFac * (double)num));
		}

		private void reSeed()
		{
			state[0] = seed & 0xFFFFFFFFu;
			for (counter = 1u; counter < MT_N; counter++)
			{
				state[counter] = 1812433253 * (state[counter - 1] ^ (state[counter - 1] >> 30)) + counter;
			}
			mag01[0] = 0u;
			mag01[1] = MAT_A;
			bInHand = false;
			bInHand64 = false;
		}
	}
	public class Utils
	{
		public static double TestLinearSolverSolution(int[] irn, int[] jcn, double[] vals, double[] x, double[] rhs, out double rms)
		{
			for (int i = 0; i < irn.Length; i++)
			{
				rhs[irn[i] - 1] -= vals[i] * x[jcn[i] - 1];
			}
			double num = 0.0;
			rms = 0.0;
			for (int j = 0; j < rhs.Length; j++)
			{
				double num2 = Math.Abs(rhs[j]);
				rms += num2 * num2;
				if (num2 > num)
				{
					num = num2;
				}
			}
			rms /= rhs.Length;
			rms = Math.Sqrt(rms);
			return num;
		}

		public static int ReadFormattedInt(StreamReader f, int width)
		{
			char[] array = new char[width];
			f.Read(array, 0, width);
			return Convert.ToInt32(new string(array));
		}

		public static int[] ReadFormattedIntegerArray(StreamReader f, int nvals)
		{
			int[] array = new int[nvals];
			int num = 0;
			while (num < nvals)
			{
				string[] array2 = f.ReadLine().Split(' ');
				for (int i = 0; i < array2.Length; i++)
				{
					if (array2[i].Length > 0)
					{
						array[num] = Convert.ToInt32(array2[i]);
						num++;
					}
				}
			}
			return array;
		}

		public static double[] ReadFormattedDoubleArray(StreamReader f, int nvals)
		{
			double[] array = new double[nvals];
			int num = 0;
			while (num < nvals)
			{
				string[] array2 = f.ReadLine().Split(' ');
				for (int i = 0; i < array2.Length; i++)
				{
					if (array2[i].Length > 0)
					{
						array[num] = Convert.ToDouble(array2[i].Replace('D', 'E'));
						num++;
					}
				}
			}
			return array;
		}

		public static void ReadHarwellBoeing(string Filename, ref int[] irn, ref int[] jcn, ref double[] values, out int nr, out int nc, out int nz)
		{
			_ = new char[1] { ' ' };
			char[] buffer = new char[72];
			char[] buffer2 = new char[8];
			char[] buffer3 = new char[14];
			int num, num2, num3, num4, num5;
			StreamReader streamReader = new StreamReader(Filename, detectEncodingFromByteOrderMarks: false);
			streamReader.Read(buffer, 0, 72);
			streamReader.Read(buffer2, 0, 8);
			streamReader.ReadLine();
			Console.WriteLine(buffer);
			num = ReadFormattedInt(streamReader, 14);
			num2 = ReadFormattedInt(streamReader, 14);
			num3 = ReadFormattedInt(streamReader, 14);
			num4 = ReadFormattedInt(streamReader, 14);
			num5 = ReadFormattedInt(streamReader, 14);
			streamReader.ReadLine();
			Console.WriteLine("{0} {1} {2} {3} {4}", num, num2, num3, num4, num5);
			streamReader.Read(buffer3, 0, 14);
			Console.WriteLine(buffer3);
			nr = ReadFormattedInt(streamReader, 14);
			nc = ReadFormattedInt(streamReader, 14);
			nz = ReadFormattedInt(streamReader, 14);
			ReadFormattedInt(streamReader, 14);
			Console.WriteLine("nr = {0} nc = {1} nz = {2}", nr, nc, nz);
			streamReader.ReadLine();
			streamReader.ReadLine();
			int[] array = new int[nc + 1];
			array = ReadFormattedIntegerArray(streamReader, nc + 1);
			irn = ReadFormattedIntegerArray(streamReader, nz);
			values = ReadFormattedDoubleArray(streamReader, nz);
			jcn = new int[nz];
			int num6 = 1;
			int num7 = 0;
			for (int i = 0; i < nc; i++)
			{
				for (int j = array[i]; j < array[i + 1]; j++)
				{
					jcn[num7] = num6;
					num7++;
				}
				num6++;
			}
			Console.WriteLine("Dunnit");
			streamReader.Close();
		}

		public static IAMOSMessagesHandler HandleToMessagesHandler(long handle)
		{
			return ((GCHandle)(IntPtr)handle).Target as IAMOSMessagesHandler;
		}

		public static long MessagesHandlerToHandle(IAMOSMessagesHandler mh)
		{
			return ((IntPtr)GCHandle.Alloc(mh)).ToInt64();
		}

		public static void FreeHandle(long handle)
		{
			((GCHandle)(IntPtr)handle).Free();
		}

		public static object HandleToObject(long handle)
		{
			return ((GCHandle)(IntPtr)handle).Target;
		}

		public static long ObjectToHandle(object obj)
		{
			return ((IntPtr)GCHandle.Alloc(obj)).ToInt64();
		}
	}
}
namespace AMOS
{
	public enum AMOSretcode
	{
		AMError = -15,
		AMResidEvalError = -14,
		AMGetJacobianStructError = -13,
		AMGetJacobianValuesError = -12,
		AMParamNotFoundError = -11,
		AMParamOutOfBounds = -10,
		AMExtSolverError = -9,
		AMReqError = -8,
		AMGetJacobianValuesDimError = -7,
		AMGetNLASFactoryError = -6,
		AMGetNLASError = -5,
		AMErrorWritingToOD = -4,
		AMNoFortranUnitAvail = -3,
		AMSuccess = 0,
		AMSolving = 1
	}
	public enum AMOSExceptionCode
	{
		AMUnknownException,
		AMLoadLibraryFailed,
		AMGetProcAddressFailed,
		AMGetFactoryInterfaceFailed,
		AMGetParameterInterfaceFailed
	}
	public class AMOSException
	{
		private AMOSExceptionCode m_Code;

		public AMOSExceptionCode Code
		{
			get
			{
				return m_Code;
			}
			set
			{
				m_Code = value;
			}
		}

		public AMOSException()
		{
			m_Code = AMOSExceptionCode.AMUnknownException;
		}
	}
	public enum AMOSTask
	{
		EVAL_COND = 1,
		EVAL_RESID = 2,
		EVAL_ADERIVS = 4,
		EVAL_NDERIVS = 8,
		EVAL_DERIVS = 12
	}
	public enum AMOSNLPTask
	{
		NO_TASK = 0,
		EVAL_COND = 1,
		EVAL_OBJ = 2,
		EVAL_CONSTR = 4,
		EVAL_ODERIVS = 8,
		EVAL_ODHESSIAN = 16,
		EVAL_CADERIVS = 32,
		EVAL_CNDERIVS = 64,
		EVAL_CDERIVS = 96
	}
	public enum AMOSSolverDirective
	{
		do_first_step,
		do_solve_step
	}
	public enum AMOSNLPSolverDirective
	{
		new_cycle,
		continue_cycle,
		continue_cycle_with_error,
		new_cycle_locked,
		continue_cycle_locked,
		continue_cycle_with_error_locked
	}
	public enum AMOS_EJacobianEntryType
	{
		EDconstant = 1,
		EDanalytic,
		EDnumeric
	}
	public enum AMOS_OptimizationSign
	{
		minimize = -1,
		maximize = 1
	}
	public enum AMNLPretcode
	{
		AMError = -15,
		AMObjEvalError = -14,
		AMObjGradEvalError = -13,
		AMObjHessEvalError = -12,
		AMConstrEvalError = -11,
		AMConstrJacError = -10,
		AMGetConstrJacobianStructError = -9,
		AMExtSolverError = -8,
		AMGetJacobianValuesDimError = -7,
		AMGetNLPFactoryError = -6,
		AMGetNLPSError = -5,
		AMAttrNotAvailable = -4,
		AMNotImplemented = -3,
		AMSuccess = 0,
		Solving = 1
	}
	public enum AMOSparam_type
	{
		int_p,
		real_p,
		string_p
	}
	public enum AMOSattribute_type
	{
		int_p,
		real_p,
		string_p
	}
	public enum AMOSconstraint_type
	{
		equality,
		inequality
	}
	public struct AMOSAttribute
	{
		public string Name;

		public string Description;

		public AMOSattribute_type Type;
	}
	public struct AMEval_data
	{
		public ArrayList c_list;

		public double objective;

		public double[] ogradient;

		public double[] ohess_diag;

		public double[] constr;

		public double[] cjac_values;
	}
	public interface IAMOSMessagesHandler
	{
		void WriteToOutputDevice(string s);

		void FlushOutputDevice();
	}
	public interface IAMOSNonLinearAlgebraicESO
	{
		int GetNumVars();

		int GetNumEqns();

		int GetNumNonzeros();

		AMOSretcode GetBounds(ArrayList indices, ref double[] lowerb_CA, ref double[] upperb_CA);

		AMOSretcode SetVariables(ArrayList indices, ref double[] var_values);

		AMOSretcode GetVariables(ArrayList indices, ref double[] var_values_CA);

		AMOSretcode GetVariableName(int var_offset, out string var_name);

		AMOSretcode GetEquationName(int equ_offset, out string equ_name);

		AMOSretcode GetResidDeriv(ArrayList indices, ref double[] residuals_CA, ref double[] jac_values_CA, int task);

		AMOSretcode GetJacobianStruct(ref int[] irows, ref int[] icols, ref int[] etype);
	}
	public interface IAMOSNonLinearProgramESO
	{
		int GetNumVars();

		int GetNumEqConstr();

		int GetNumIneqConstr();

		AMNLPretcode GetBounds(ArrayList indices, ref double[] lowerb_CA, ref double[] upperb_CA);

		AMNLPretcode SetVariables(ArrayList indices, ref double[] var_values);

		AMNLPretcode GetVariables(ArrayList indices, ref double[] var_values);

		AMNLPretcode GetVariableName(int var_offset, out string var_name);

		AMNLPretcode GetVariableAttr(int var_offset, string attr_name, out object attr_val);

		AMNLPretcode GetConstrName(int c_offset, out string c_name);

		AMNLPretcode GetConstrGroups(out int n_cgroups, out int[] c_group_list);

		AMNLPretcode GetConstrAttr(int c_offset, string attr_name, out object attr_value);

		AMNLPretcode GetObjAttr(string attr_name, out object attr_value);

		AMNLPretcode Evaluate(IAMOSNonLinearProgramESOResults edata, int task);

		AMNLPretcode GetNonzeros(ref int obj_nonzeros, ref int constr_nonzeros);

		AMNLPretcode GetConstrJacStruct(ref int[] irows, ref int[] icols, ref int[] etype);

		AMNLPretcode GetObjGradStruct(int[] GradStruct_CA);

		AMOS_OptimizationSign GetOptimSign();

		AMNLPretcode SetLagrangeMultipliers(double[] varbound_multipliers, double[] constr_multipliers);
	}
	public interface IAMOSParameterTable
	{
		AMOSretcode GetParameterNames(ArrayList nameList);

		AMOSretcode GetParameterInfo(string paramName, ArrayList infoList);

		AMOSretcode SetParameter(string paramName, object paramValue);
	}
	public interface IAMOSExtendedParameterTable
	{
		AMOSretcode GetInfo(string paramName, out object value);

		AMOSretcode SetInfo(string paramName, object paramValue);
	}
	public interface IAMOSLinearEquationSolver
	{
		AMOSretcode SetMatrixVals(double[] pdValues);

		AMOSretcode SetRHS(double[] pdRHS);

		AMOSretcode GetSolution(double[] pdSolution);

		AMOSretcode SetPattern(int iNumEqns, int iNumVars, int iNZ, int[] piRows, int[] piCols);
	}
	public interface IAMOSNonLinearEquationSolver
	{
		AMOSretcode SolveStep(AMOSSolverDirective directive, out int iterations);
	}
	public interface IAMOSNonLinearProgramESOResults
	{
		double Objective { set; }

		double[] ObjectiveGradient { get; }

		double[] ObjectiveHessianDiagonal { get; }

		double[] ConstraintValues { get; }

		double[] ConstraintJacobianValues { get; }
	}
	public interface IAMOSNLPSolver
	{
		int Iterations { get; }

		int Task { get; }

		AMNLPretcode PerformIterations(AMOSNLPSolverDirective directive);
	}
	public interface IAMOSNLPSolverFactory
	{
		AMNLPretcode CreateNLPSystem(IAMOSNonLinearProgramESO givenESO, IAMOSMessagesHandler messages, out IAMOSNLPSolver createdSolver);
	}
	public interface IAMOSNonLinearEquationSolverFactory
	{
		AMOSretcode CreateSolver(IAMOSNonLinearAlgebraicESO givenESO, IAMOSMessagesHandler messages, out IAMOSNonLinearEquationSolver createdSolver);
	}
	[ComVisible(false)]
	public interface IManagedObjStore
	{
		int Count { get; }

		int AddObject(object obj);

		object RetrieveObject(int at_index);

		void DeleteObject(int at_index);
	}
	internal class UManagedObjStore : IManagedObjStore
	{
		private ArrayList mList;

		private int mObjCount;

		private static UManagedObjStore gInstance;

		public int Count => mObjCount;

		private UManagedObjStore()
		{
			mList = new ArrayList();
			mObjCount = 0;
		}

		public static IManagedObjStore GetInstance()
		{
			if (gInstance == null)
			{
				gInstance = new UManagedObjStore();
			}
			return gInstance;
		}

		public int AddObject(object obj)
		{
			int result = mList.Add(obj);
			mObjCount++;
			return result;
		}

		public object RetrieveObject(int at_index)
		{
			return mList[at_index];
		}

		public void DeleteObject(int at_index)
		{
			mList[at_index] = 0;
			mObjCount--;
			if (mObjCount == 0)
			{
				mList.Clear();
			}
		}
	}
	internal class SManagedObjStore : IManagedObjStore
	{
		private ArrayList mList;

		private int mObjCount;

		private static SManagedObjStore gInstance;

		public int Count => mObjCount;

		private SManagedObjStore()
		{
			lock (this)
			{
				mList = new ArrayList();
				mObjCount = 0;
			}
		}

		public static IManagedObjStore GetInstance()
		{
			if (gInstance == null)
			{
				gInstance = new SManagedObjStore();
			}
			return gInstance;
		}

		public int AddObject(object obj)
		{
			int result;
			lock (this)
			{
				result = mList.Add(obj);
				mObjCount++;
			}
			return result;
		}

		public object RetrieveObject(int at_index)
		{
			return mList[at_index];
		}

		public void DeleteObject(int at_index)
		{
			lock (this)
			{
				mList[at_index] = 0;
				mObjCount--;
				if (mObjCount == 0)
				{
					mList.Clear();
				}
			}
		}
	}
	public class ManagedObjStoreFactory
	{
		public static IManagedObjStore uInstance()
		{
			return UManagedObjStore.GetInstance();
		}

		public static IManagedObjStore sInstance()
		{
			return SManagedObjStore.GetInstance();
		}
	}
}
